# DAAN

DAAN is a workspace with a FastAPI backend in `service/` and a Next.js UI in `ui/`.

DAAN is a governed AI orchestration framework for Data and Analytics delivery.

It is designed to automate high-value parts of the Data and Analytics SDLC through:

- role-based agents
- configurable prompts and policies
- tool and MCP-based integrations
- retrieval and knowledge access
- validation, feedback, and governed execution

The framework is intended to generate, validate, and operationalize delivery outputs such as mappings, code, tests, and related artifacts.

## Prerequisites

- Python 3.11+
- Node.js 18+
- pip
- npm

## Setup

Install backend dependencies:

```sh
cd service
pip install -r requirements.txt
```

Install frontend dependencies:

```sh
cd ui
npm install
```

## Configuration

Main config files live in the top-level `config/` folder:

- `config/.env`
- `config/llm_config.yml`
- `config/mcp_config.yml`
- `config/rag_config.yml`

Use `config/env.template` as the starting point for environment values.

## Run

Run the backend:

```sh
cd service
python -m uvicorn daan.main:app --reload --port 8000
```

Run the frontend:

```sh
cd ui
npm run dev
```

Or run both from the workspace root:

```sh
npm run dev
```

## API Docs

- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Docker

Backend container build is defined in `service/Dockerfile`.

## Useful Commands

```sh
npm run dev
npm run test:service
npm run lint:service
```
