# Newsletter Usecase Guide

## Purpose
This guide explains the DnA Newsletter workflow, why its number of **published
items** swings from run to run, and how to improve generation, validation and
scoring without adding use-case-specific behavior to shared workflow code. It
uses UC_AN_001 and AGENT_854 as the observed case while keeping the recommended
runtime controls generic and reusable.

---

## 1. Observed behaviour

Across recent runs the upstream scout (AGENT_853) produced a stable ~129–131
items, yet AGENT_854's published count varied wildly on essentially the same
prompt:

| Session (AGENT_854) | retrieved | after_dedup | after_relevance | dropped_unreachable | published (actual sections) |
|---|---|---|---|---|---|
| 9dbbe34f | 131 | 7   | 6   | 0  | 5  |
| fed818fa | 131 | 131 | 105 | 26 | 2  |
| 968e1a28 | 129 | 129 | 52  | 0  | 13 |
| 5601600e | 129 | 129 | 55  | 0  | 12 |
| 954e1086 | 129 | 100 | 85  | 26 | 4  |
| b65d7748 | 129 | 129 | 3   | 0  | 3  |
| 84a2da13 | 129 | 129 | 40  | 26 | 14 |

Same input volume, same contract — published output ranges from **2 to 14**.
Note also that each stage is unstable independently:
- semantic dedup: `131 → 7` one run, `129 → 129` another
- relevance: `129 → 3` one run, `129 → 105` another
- link-hygiene drop: `0` one run, `26` another

`run_stats.items_published` is also frequently wrong (e.g. reports 19 while the
section arrays contain 14), which is itself a symptom (see root cause).

### 1.1 Why output appeared to improve after undoing context-scoring changes

Session `84a2da13` looked substantially better after a context-scoring change was
partially undone:

- AGENT_854 published 14 actual section items, compared with 3 in `b65d7748`
- AGENT_854's score rose to 90
- AGENT_855's score rose to 95, including a context score of 100

This improvement is **correlated with the partial undo, but was not caused by
it**. The workflow chronology proves that scoring cannot change an agent's saved
output:

1. AGENT_853, AGENT_854 and AGENT_855 execute in sequence.
2. Each output is written to `session_storage` immediately after execution.
3. Only after all outputs are saved does the scoring loop start.

Therefore, changing scoring context can change only the displayed quality score
and feedback. It cannot change deduplication, relevance decisions, section fill,
published count, or newsletter content for that run.

The undo was also only partial. The shared `_score_and_persist_agent_outputs`
helper was reverted to file-only context, but the primary
`/run-dynamic-agents` scoring loop still augmented each agent's context with its
declared upstream dependency output. That active code explains why AGENT_855
received a context score of 100 instead of the earlier false `no context /
fabricated` verdict.

The most likely explanation for the better 14-item output is ordinary model
variance at temperature 0.7. The same high-variance curator has already produced
2, 3, 4, 12, 13 and 14 items from near-identical input volumes and prompt states.
The `84a2da13` run simply landed on a better combination of deduplication,
relevance and section-fill decisions.

**Practical conclusion:** do not use scoring changes to tune published-item
count. Keep or revert them solely based on whether score attribution is correct.
Tune AGENT_854 through generation controls such as temperature, deterministic
filters, explicit item-count targets and splitting tool work out of the curator
turn.

---

## 2. Root cause

**The published-item count is an emergent, non-deterministic property of several
stacked subjective LLM judgments executed in a single large model turn.**

There is no single deterministic "publish N items" lever in the prompt. The final
count is whatever survives this chain of stochastic decisions over ~130 items:

```
dedup → section assignment → source filters → relevance → ranking → caps → enrichment → link hygiene
```

Two structural facts make this inherently unstable:

1. **Temperature is 0.7.** Dynamic agents run through the LiteLLM provider, which
   defaults to `temperature = 0.7`
   (`service/daan/llm/providers/litellm_provider.py`). A high temperature is
   correct for creative writing (AGENT_855) but wrong for a deterministic
   filtering/classification task (AGENT_854). At 0.7 the same filtering step
   legitimately returns different survivors on each run.

2. **Compounding variance in one mega-turn.** Each of the ~7 filtering stages is a
   separate probabilistic judgment. Small per-stage differences multiply. When an
   early stage over-cuts (e.g. semantic dedup `131 → 7`, or relevance `129 → 3`),
   nothing downstream can recover it — the caps only bound the **maximum**, they
   cannot raise a low count.

Everything else we tuned (relevance floor %, section/publisher caps,
non-destructive link hygiene) only shifts the **ceiling or the average**. It does
not remove the variance, because the variance comes from temperature + stacked
subjective judgments, not from the parameter values.

Supporting evidence: `run_stats` is self-narrated by the model, not computed. When
the model reports `items_published: 19` but only places 14 items in the arrays,
it confirms the counts are emergent guesses, not the result of a deterministic
procedure.

---

## 3. Contributing factors (ranked by impact)

1. **Temperature 0.7** — largest single driver of run-to-run variance.
2. **Subjective relevance stage** — "decide if D&A-relevant" is open-ended; a soft
   `55%` floor is easily ignored under stochastic drift (`129 → 3` happened).
3. **Semantic dedup treated as a volume filter** — occasionally collapses distinct
   vendor items into one "cluster" (`131 → 7`).
4. **Single mega-turn over ~190k input tokens** — high cognitive load raises
   variance and risks ending the turn on a tool echo.
5. **Soft, percentage-based floors** — the model rounds/ignores them; there is no
   hard minimum item count.
6. **run_stats narrated, not computed** — counts drift from the actual arrays.

---

## 4. Tips to control published count (prompt + config)

Ordered from highest to lowest leverage. Prefer the top items.

### 4.1 Lower the temperature for AGENT_854 (highest leverage)
Set this agent's `temperature` to `0.0–0.2`. Filtering/curation should be
near-deterministic. This is the single most effective change and directly reduces
run-to-run swing. Keep AGENT_855 (the writer) at its normal temperature.

### 4.2 Give an explicit hard target range, not a percentage
Replace soft "preserve at least 55%" language with a concrete, checkable target,
e.g.:
> "Publish between 15 and 25 items total across all sections. If fewer than 15
> relevant items remain, publish all of them; never publish fewer than the number
> of genuinely relevant items available."

Concrete integer bounds are far more reliable than percentages.

### 4.3 Make relevance inclusion-by-default with a short, closed exclude list
Convert relevance from "decide if relevant" to "keep everything EXCEPT items that
clearly match one of these N exclusion categories." A closed exclusion list is a
near-deterministic predicate; an open "is this relevant?" judgment is not.

### 4.4 Constrain semantic dedup to same-story only
Explicitly forbid topic-level or vendor-level clustering. Only merge items that
describe the **same announcement** (same event, same release, same report).
Everything else stays separate. This stops the `131 → 7` collapses.

### 4.5 Deterministic section fill
After ranking, instruct: "Fill each section from its ranked, relevant pool up to
`max_items_per_section`. Only stop when the pool for that section is empty." This
turns the caps into a floor-seeking fill rather than an upper bound only.

### 4.6 Keep link hygiene non-destructive (already applied)
`verify_links_batch` false-negatives on bot-protected vendor sites. Never drop on
`reachable=false`; only drop on malformed/empty URLs. This removed the `105 → 2`
collapse.

### 4.7 Do NOT compute run_stats via an extra in-prompt "self-check" pass
Adding a final recount instruction destabilised output (published dropped to 4).
If exact counts matter, compute `items_published` and the section totals in code
after the agent returns, and overwrite the model's `run_stats` — do not ask the
model to recount inside the same turn.

### 4.8 Reduce input volume before the curator
Pre-cap items per source upstream (AGENT_853) so the curator juggles fewer items.
Lower turn load = lower variance and lower cost (AGENT_854 currently spends
~$0.9–1.0 and ~350k input tokens per run).

### 4.9 Structural (durable) fix — split the mega-turn
Make AGENT_854 a pure text→JSON curator (no MCP tools), and move enrichment +
link verification to a separate deterministic step that runs after the curated
JSON exists. This removes the tool-loop instability entirely and is the most
reliable long-term option. Larger change; do behind approval.

---

## 5. Scope of improvement

Session `b84421ae` confirmed that the generic DAG handoff and structured-output
preservation work, but it also exposed contract failures that prompt instructions
and LLM scoring did not catch:

- the curator emitted 15 section entries but reported 24 published items
- one canonical URL appeared in two sections
- every curated record omitted `content_hash`, `section_hint` and
  `date_confidence`
- the newsletter rendered only 10 of 14 unique curated URLs
- automated scores still passed both outputs and incorrectly reported complete
  coverage

The next improvement scope should add deterministic, schema-driven validation
after generation. These controls must operate on output shape and configured
contracts, not on UC_AN_001 or specific agent IDs.

### 5.1 Deduplicate curated records

Traverse every configured section and retain each story once. Use a non-empty
`content_hash` as the primary identity and normalized `canonical_url` as the
fallback. If the same story appears in multiple sections, keep the first or
highest-ranked occurrence according to configured section/ranking policy and log
the removed occurrence.

This validation should distinguish a missing hash from a duplicate hash. Multiple
records with no hash must not all be treated as the same item; URL fallback must
be used instead.

### 5.2 Preserve required identity fields

When a curated record corresponds to an upstream item, carry forward the
upstream identity and provenance fields, including at minimum:

- `content_hash`
- `canonical_url`
- `source_id`
- `section_hint`
- `date_confidence`
- `published_at`

Match on `content_hash` first and canonical URL second. Reject ambiguous matches
rather than inventing identity values. Editorial fields may be enriched, but
identity and provenance fields should remain unchanged unless a deterministic
normalization rule explicitly permits it.

### 5.3 Compute published counts from section arrays

After deduplication, calculate `run_stats.items_published` in code as the sum of
the validated section lengths:

```text
items_published = sum(len(items) for items in sections.values())
```

Overwrite any model-narrated value before persistence, downstream handoff and
scoring. Derived per-section and unique-item counts should use the same validated
collection so the newsletter footer cannot repeat a stale or hallucinated total.

### 5.4 Validate newsletter coverage

Build the expected story-identity set from the validated curator output and the
rendered story-identity set from the newsletter. Every expected unique story must
appear exactly once in the newsletter body, with its canonical URL preserved
character for character. Top-three references may point to body stories but must
not count as additional body occurrences.

Report missing, duplicated and unexpected stories as structured validation
findings. This check should run before the newsletter is accepted as the final
agent output.

### 5.5 Reject or rescore failed outputs

Treat deterministic contract failures separately from subjective LLM quality
scores. An output must not pass solely because an evaluator assigns a high
semantic score.

Recommended policy:

1. Run structural validation before quality scoring.
2. If repair is deterministic, normalize the output and record the changes.
3. If required fields cannot be recovered or newsletter coverage is incomplete,
   reject the output or trigger a bounded rerun with the validation findings.
4. Score only the validated output and include structural findings in the scorer
   context.
5. Cap completeness and overall scores below the pass threshold whenever an
   unresolved required-field, uniqueness, count or coverage failure remains.

This creates a reliable gate around stochastic generation while preserving the
shared workflow's generic behavior.

---

## 6. Recommended target configuration

| Lever | Current | Recommended |
|---|---|---|
| AGENT_854 temperature | 0.7 (default) | 0.0–0.2 |
| Relevance rule | subjective + 55% floor | include-by-default + closed exclude list |
| Target count | none | explicit range, e.g. 15–25 |
| Semantic dedup | narrow (good) | keep; forbid topic/vendor clustering |
| Section cap | 12 | keep |
| Publisher cap / section | 4 | keep |
| Link hygiene | non-destructive (good) | keep |
| run_stats | model-narrated | compute in code post-return |
| Tool loops in curator turn | present | move out (durable) |

---

## 7. What NOT to do (lessons from regressions)

- **Do not keep adding instructions to the mega-prompt.** Every added block
  (e.g. the `items_published` self-check) increased instability. Prefer fewer,
  sharper rules and lower temperature.
- **Do not use semantic dedup as a coverage control.** It is the least
  predictable stage.
- **Do not treat percentage floors as guarantees.** Use integer bounds.
- **Do not judge quality from a single run.** This agent is high-variance until
  temperature is lowered; evaluate over 2–3 runs.

---

## 8. Suggested first changes

1. Set AGENT_854 temperature to `0.1` and add an explicit 15–25 item target
   (Sections 4.1 and 4.2). Re-run UC_AN_001 2–3 times and confirm the published
   count stabilises.
2. Add the generic deterministic validation gate described in Section 5 before
   treating the newsletter workflow as production-ready.
