# RAG + Graph RAG + Advanced RAG   Implementation Plan

## Overview

Greenfield RAG layer built on top of the existing factory/registry patterns in DAAN.
KuzuDB is the primary graph store but all components are swappable via factory registries.
RAG is **opt-in per agent** via a `rag:` block in agent YAML   no forced changes to existing flow.

---

## Phase 1   Abstractions & Factories

> All tasks in this phase are independent and can run in parallel.

### T1   Embedding Provider Abstraction

**New files:**
- `service/daan/llm/embeddings/base_embedding_provider.py`
  - `BaseEmbeddingProvider` ABC
  - Methods: `embed_text(text: str) -> list[float]`, `embed_batch(texts: list[str]) -> list[list[float]]`
- `service/daan/llm/embeddings/embedding_factory.py`
  - `EmbeddingProviderFactory` with `EMBEDDING_MAP: dict[str, str]` + `create_provider(name, config)` via `importlib`
  - **Mirror exactly** the pattern in `service/daan/llm/providers/provider_factory.py`
- `service/daan/llm/embeddings/openai_embedding_provider.py`   `OpenAIEmbeddingProvider`
- `service/daan/llm/embeddings/azure_openai_embedding_provider.py`   `AzureOpenAIEmbeddingProvider`
- `service/daan/llm/embeddings/litellm_embedding_provider.py`   `LiteLLMEmbeddingProvider`
- `service/daan/llm/embeddings/sentence_transformer_embedding_provider.py`   `SentenceTransformerEmbeddingProvider`

**Modified files:**
- `config/llm_config.yml`   add `embeddings:` section with `default_provider` and provider-specific keys

---

### T2   Vector Store Abstraction

**New files:**
- `service/daan/vector_stores/document.py`
  - `RagDocument` Pydantic model: `id`, `content`, `metadata: dict`, `source`, `chunk_index: int`, `embedding: list[float] | None`
- `service/daan/vector_stores/base_vector_store.py`
  - `BaseVectorStore` ABC
  - Methods: `add_documents(docs)`, `similarity_search(query_embedding, k)`, `hybrid_search(query, query_embedding, k)`, `delete(doc_id)`, `upsert(doc)`
- `service/daan/vector_stores/vector_store_factory.py`
  - `VectorStoreFactory` with `VECTOR_STORE_MAP` + `create_store(name, config)` via importlib
- `service/daan/vector_stores/chroma_vector_store.py`   `ChromaVectorStore`
- `service/daan/vector_stores/faiss_vector_store.py`   `FAISSVectorStore`
- `service/daan/vector_stores/in_memory_vector_store.py`   `InMemoryVectorStore` (for testing)

---

### T3   Graph Store Abstraction

**New directory:** `service/daan/graph_stores/`

**New files:**
- `graph_document.py`   `GraphNode` Pydantic model: `id`, `label`, `properties: dict`; `GraphEdge`: `source_id`, `target_id`, `type`, `properties: dict`
- `base_graph_store.py`
  - `BaseGraphStore` ABC
  - Methods: `add_node(node: GraphNode)`, `add_edge(edge: GraphEdge)`, `query(cypher: str) -> list[dict]`, `get_neighbors(node_id, depth: int)`, `get_subgraph(node_ids)`, `upsert_node()`, `upsert_edge()`, `close()`
- `graph_store_factory.py`   `GraphStoreFactory` with `GRAPH_STORE_MAP` + `create_store(name, config)`
- `kuzu_store.py`   `KuzuGraphStore` (primary): kuzu Python client, schema init on startup, Cypher queries, connection lifecycle management
- `in_memory_graph_store.py`   dict-backed, for unit tests
- `neo4j_store.py`   `Neo4jGraphStore` stub: all methods raise `NotImplementedError`

---

## Phase 2   Indexing Pipeline

> Depends on Phase 1 being complete.

### T4   Chunking Strategies

**New directory:** `service/daan/rag/chunking/`

**New files:**
- `base_chunker.py`   `BaseChunker` ABC: `chunk(doc: RagDocument) -> list[RagDocument]`
- `chunker_factory.py`   `ChunkerFactory` with registry dict + `create_chunker(type, config)`
- `fixed_size_chunker.py`   `FixedSizeChunker`: character/token window with configurable overlap
- `recursive_text_chunker.py`   `RecursiveTextChunker`: split on paragraph ? sentence ? word separators
- `semantic_chunker.py`   `SemanticChunker`: embedding-distance breakpoints (requires embedding provider)
- `sentence_chunker.py`   `SentenceChunker`: split on sentence boundaries

Config params per chunker: `chunk_size`, `chunk_overlap`

---

### T5   Indexing Service

**New directory:** `service/daan/rag/indexing/`

**New files:**
- `rag_indexing_service.py`   `RagIndexingService`:
  - `async index_documents(session_id, files, vector_store, graph_store, embedding_provider, chunker)`
  - `async index_knowledge_base(kb_id, source_dir, config)`
  - Internally reuses existing `FileToJsonConverter` + `FilePartitioner` for initial file parsing before chunking

Pipeline order: `Convert (FileToJsonConverter) ? Partition (FilePartitioner) ? Chunk (BaseChunker) ? Embed (BaseEmbeddingProvider) ? Store (BaseVectorStore + BaseGraphStore)`

---

### T6   Knowledge Graph Builder

**New directory:** `service/daan/rag/graph/`

**New files:**
- `knowledge_graph_builder.py`   `KnowledgeGraphBuilder`:
  - `build_graph(chunks: list[RagDocument], graph_store: BaseGraphStore, llm_provider) -> None`
  - `extract_entities_and_relations(text: str) -> tuple[list[GraphNode], list[GraphEdge]]` (LLM call)
  - Chunk nodes linked to extracted entity nodes via `MENTIONS` edges
- `data/core/prompts/graph_extraction.prompt.md`   extraction prompt with configurable entity types and relation types

---

## Phase 3   Retrieval

> Depends on Phases 1 and 2.

### T7   Base Retriever & Vector Retriever

**New directory:** `service/daan/rag/retrieval/`

**New files:**
- `base_retriever.py`   `BaseRetriever` ABC: `retrieve(query: str, k: int) -> list[RagDocument]`
- `retriever_factory.py`   `RetrieverFactory` with `RETRIEVER_MAP` + `create_retriever(type, config)`
- `vector_retriever.py`   `VectorRetriever`: embed query ? `BaseVectorStore.similarity_search()`

---

### T8   Graph RAG Retriever

**New files (in `service/daan/rag/retrieval/`):**
- `graph_retriever.py`   `GraphRetriever`: embed query ? find seed entities in vector store ? BFS/DFS via `BaseGraphStore.get_neighbors()` ? rescore traversal results by relevance
- `graph_rag_retriever.py`   `GraphRagRetriever`: merges `VectorRetriever` + `GraphRetriever` outputs using **Reciprocal Rank Fusion (RRF)**

---

### T9   Advanced RAG Retrievers

**New files (in `service/daan/rag/retrieval/`), all independent:**
- `hybrid_retriever.py`   `HybridRetriever`: vector similarity + BM25 keyword search merged via RRF; uses `rank-bm25`
- `hyde_retriever.py`   `HyDERetriever`: LLM generates hypothetical answer ? embed it ? retrieve against actual docs
- `multi_query_retriever.py`   `MultiQueryRetriever`: LLM expands query to N variants ? retrieve for each ? deduplicate by doc id
- `contextual_compression_retriever.py`   `ContextualCompressionRetriever`: wraps any `BaseRetriever`; LLM extracts only relevant sentences from each retrieved chunk
- `parent_document_retriever.py`   `ParentDocumentRetriever`: index small child chunks, return full parent document on match via metadata link

---

### T10   Reranker

**New directory:** `service/daan/rag/reranking/`

**New files:**
- `base_reranker.py`   `BaseReranker` ABC: `rerank(query: str, docs: list[RagDocument]) -> list[RagDocument]`
- `reranker_factory.py`   `RerankerFactory` with registry
- `cross_encoder_reranker.py`   `CrossEncoderReranker`: sentence-transformers cross-encoder model
- `llm_reranker.py`   `LLMReranker`: LLM-as-judge, score each doc vs. query
- `cohere_reranker.py`   `CohereReranker`: Cohere Rerank API

---

## Phase 4   Graph Analytics (GraphRAG Style)

> Depends on Phase 2 (T3, T6).

### T11   Community Detection

**New files (in `service/daan/rag/graph/`):**
- `community_detector.py`   `GraphCommunityDetector`:
  - Export kuzu graph ? NetworkX graph object
  - Run Louvain community detection (`python-louvain`)
  - Write `community_id` back to each node via `BaseGraphStore.upsert_node()`
- `community_summarizer.py`   `CommunitySummarizer`:
  - Retrieve all nodes per community, generate LLM summary
  - Store as `CommunitySummary` node in graph store

---

### T12   Global & Local Search

**New files (in `service/daan/rag/retrieval/`):**
- `global_search_retriever.py`   `GlobalSearchRetriever`: map-reduce over `CommunitySummary` nodes (for broad/thematic queries)
- `local_search_retriever.py`   `LocalSearchRetriever`: entity-centric graph traversal from matched nodes (for specific/factual queries)

Both registered in `RetrieverFactory.RETRIEVER_MAP`.

---

## Phase 5   Native Tool & Agent Integration

> Depends on Phases 1 3.

### T13   RAG Native Tool

**New file:** `service/daan/native_tools/rag_tool.py`

`RagTool` class following existing `"ClassName.method_name"` native tool convention:
- `RagTool.search(query: str, k: int, retriever_type: str, kb_id: str) -> str`   returns formatted context string for agent prompt
- `RagTool.index_file(file_path: str, kb_id: str) -> str`   triggers indexing pipeline
- `RagTool.list_knowledge_bases() -> str`   returns available KB ids

Internally uses `RetrieverFactory`, `VectorStoreFactory`, `EmbeddingProviderFactory` with config from `rag_config.yml`.

---

### T14   RAG Config File

**New file:** `config/rag_config.yml`

```yaml
embedding_provider: azure_openai
vector_store_type: chroma
graph_store_type: kuzu
chunker_type: recursive_text
chunk_size: 512
chunk_overlap: 64
default_retriever_type: graph_rag
reranker_type: cross_encoder
top_k: 5
knowledge_bases:
  - id: default
    source_dir: data/knowledge
    enabled: true
```

**Modified file:** `service/daan/core/config.py`   extend `Settings` (Pydantic `BaseSettings`) to load `rag_config.yml`; add `rag_config_path` field.

---

### T15   Agent Config Integration

**Modified file:** `service/daan/agents/dynamic_builders/dynamic_adk_agent.py`
- Parse optional `rag:` block from agent config dict in `create_adk_agent()`
- If present, auto-inject `"RagTool.search"` into `local_tools` list
- Pass `rag` config dict to `RagContextInjector`

**New file:** `service/daan/rag/rag_context_injector.py`   `RagContextInjector`:
- Pre-run step that retrieves context for the session's primary query
- Injects retrieved context as an additional block in the agent system prompt

**Agent YAML example (additive only, no schema changes):**
```yaml
rag:
  kb_id: "default"
  retriever_type: "graph_rag"
  top_k: 5
  reranker: "cross_encoder"
```

---

## Phase 6   Session & API Integration

> Depends on Phase 5.

### T16   Session-Scoped RAG

**New file:** `service/daan/rag/rag_session_manager.py`   `RagSessionManager`:
- `create_session_store(session_id)`   instantiate per-session `BaseVectorStore` + `BaseGraphStore`
- `destroy_session_store(session_id)`   cleanup connections
- Artifacts stored under `session_storage/{session_id}/rag/` (consistent with existing `session_service.py` pattern)

**Modified file:** `service/daan/flow/session_service.py`   add `init_rag_session()` + `cleanup_rag_session()` calls

---

### T17   RAG API Endpoints

**New file:** `service/daan/api/rag_router.py`   FastAPI router:

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/rag/knowledge-bases/{kb_id}/index` | Index documents into a KB |
| `POST` | `/rag/search` | Direct retrieval with retriever config |
| `GET` | `/rag/knowledge-bases` | List all KBs |
| `DELETE` | `/rag/knowledge-bases/{kb_id}` | Delete a KB |

**Modified file:** `service/daan/main.py`   register `rag_router`

---

## Phase 7   Observability & Evaluation

> Depends on Phase 5.

### T18   RAG Tracing

**New file:** `service/daan/rag/observability/rag_tracer.py`
- `RagTrace` Pydantic model: `query`, `retrieved_docs`, `reranked_docs`, `final_context`, `retriever_type`, `latency_ms`, `session_id`, `timestamp`
- `RagTracer.record(trace)`   appends to `session_storage/{session_id}/rag_traces.jsonl`

**New endpoint** (add to `rag_router.py`): `GET /rag/traces/{session_id}`

---

### T19   RAG Evaluation

**New file:** `service/daan/rag/evaluation/rag_evaluator.py`
- `RagEvaluator`   LLM-as-judge, same pattern as existing `quality_check_agent`
- Metrics: `faithfulness`, `answer_relevance`, `context_precision`, `context_recall`
- Uses ADK agent internally via `create_adk_agent()` factory

**New file:** `data/core/prompts/rag_evaluation.prompt.md`   evaluation prompt template

---

## Phase 8   Dependencies & Tests

### T20   Add Dependencies

Add to `requirements.txt` and `pyproject.toml`:

| Package | Purpose |
|---------|---------|
| `kuzu` | Primary graph store |
| `chromadb` | Default vector store |
| `faiss-cpu` | FAISS vector store |
| `sentence-transformers` | Local embeddings + cross-encoder reranker |
| `rank-bm25` | BM25 for hybrid retrieval |
| `networkx` | Graph export for community detection |
| `python-louvain` | Louvain community detection algorithm |
| `cohere` | Optional Cohere reranker |

---

### T21   Tests

**Location:** `service/daan/tests/`

- Unit tests for all 5 factories: `EmbeddingProviderFactory`, `VectorStoreFactory`, `GraphStoreFactory`, `RetrieverFactory`, `RerankerFactory`
- Abstract interface contract tests per base class
- Integration test: full pipeline   `index_documents ? VectorRetriever.retrieve ? CrossEncoderReranker.rerank` using `InMemoryVectorStore` + `InMemoryGraphStore`
- KuzuDB integration test with a small fixture dataset (10 nodes, 15 edges)
- `RagTool` agent integration test   load YAML with `rag:` block and assert tool is injected

---

## Summary: New Directory Structure

```
service/daan/
+-- llm/
    +-- embeddings/                       # T1   Embedding factory + providers
+-- vector_stores/                         # T2   Vector store factory + stores
+-- graph_stores/                          # T3   Graph store factory (Kuzu, Neo4j, InMemory)
+-- native_tools/
    +-- rag_tool.py                        # T13
+-- rag/
    +-- chunking/                           # T4
    +-- indexing/                           # T5
    +-- graph/                              # T6, T11
    +-- retrieval/                          # T7 T9, T12
    +-- reranking/                          # T10
    +-- observability/                      # T18
    +-- evaluation/                         # T19
    +-- rag_context_injector.py             # T15
config/
+-- rag_config.yml                          # T14
data/core/prompts/
+-- graph_extraction.prompt.md              # T6
+-- rag_evaluation.prompt.md               # T19
```

---

## Key Files Modified

| File | Change |
|------|--------|
| `service/daan/core/config.py` | Load `rag_config.yml` in `Settings` |
| `service/daan/main.py` | Register `rag_router` |
| `service/daan/agents/dynamic_builders/dynamic_adk_agent.py` | Inject `RagTool` from `rag:` block |
| `service/daan/flow/session_service.py` | Add RAG session init/cleanup |
| `config/llm_config.yml` | Add `embeddings:` section |
| `requirements.txt` / `pyproject.toml` | Add RAG dependencies |

---

## Scope Boundaries

**In scope:** Indexing, retrieval, graph construction, community detection, reranking, native tool, API endpoints, tracing, evaluation.

**Out of scope:** UI changes, auth changes, modifications to existing agent YAML schemas (the `rag:` block is purely additive), real-time streaming retrieval.
