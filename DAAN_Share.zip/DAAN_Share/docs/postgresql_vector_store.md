# PostgreSQL Vector Store Guide

## Purpose

DAAN now uses PostgreSQL with pgvector as the primary vector store for RAG instead of the earlier ChromaDB-backed setup.

This document explains:

1. what changed
2. how chatbot and chat-agent retrieval use PostgreSQL vectors
3. what configuration is required
4. how to verify the setup

## What Changed

The active RAG configuration in [config/rag_config.yml](cp/GENAI%20COE/TASKS/DAAN_v5.0/DAAN_5/config/rag_config.yml):/Users/10842420/OneDrive%20-%20LTIMindtree/Deskto now sets:

```yaml
vector_store_type: pgvector
```

That means DAAN resolves the vector store through [service/daan/vector_stores/vector_store_factory.py](c:/Users/10842420/OneDrive%20-%20LTIMindtree/Desktop/GENAI%20COE/TASKS/DAAN_v5.0/DAAN_5/service/daan/vector_stores/vector_store_factory.py), which maps both `postgres` and `pgvector` to the PostgreSQL-backed implementation in [service/daan/vector_stores/providers/postgres_vector_store.py](c:/Users/10842420/OneDrive%20-%20LTIMindtree/Desktop/GENAI%20COE/TASKS/DAAN_v5.0/DAAN_5/service/daan/vector_stores/providers/postgres_vector_store.py).

## Current Retrieval Path

Both chat modes use vector retrieval explicitly.

### Classic Chatbot

In [service/daan/api/v1/endpoints/chat.py](c:/Users/10842420/OneDrive%20-%20LTIMindtree/Desktop/GENAI%20COE/TASKS/DAAN_v5.0/DAAN_5/service/daan/api/v1/endpoints/chat.py), the classic chatbot path calls:

```python
docs = tool.search_documents(
    query=message.strip(),
    k=8,
    retriever_type="vector",
    kb_id=DAAN_KB_ID,
    metadata_filter=metadata_filter,
)
```

### Chat-Agent

In the same file, the chat-agent path calls:

```python
docs = tool.search_documents(
    query=message,
    k=8,
    retriever_type="vector",
    kb_id=resolved_kb_id,
    metadata_filter=None,
)
```

So both paths force `retriever_type="vector"` even though the global default retriever in `rag_config.yml` is `graph_rag`.

## Why This Uses PostgreSQL

`RagTool.search_documents()` builds runtime components through [service/daan/native_tools/rag_tool.py](c:/Users/10842420/OneDrive%20-%20LTIMindtree/Desktop/GENAI%20COE/TASKS/DAAN_v5.0/DAAN_5/service/daan/native_tools/rag_tool.py).

That runtime builder creates the vector store using the configured `vector_store_type`.

Because `config/rag_config.yml` currently contains:

```yaml
vector_store_type: pgvector
```

the vector store factory resolves the PostgreSQL implementation.

## Required Configuration

### RAG Config

The key entries in [config/rag_config.yml](c:/Users/10842420/OneDrive%20-%20LTIMindtree/Desktop/GENAI%20COE/TASKS/DAAN_v5.0/DAAN_5/config/rag_config.yml) are:

```yaml
vector_store_type: pgvector
vector_store_config:
  embedding_dimension: 1536
  schema: rag_vectors
```

### Environment Variables

The PostgreSQL vector store reads the vector DB connection from the `VECTOR_DB_*` settings in `service/daan/core/config.py`.

Required values:

```text
VECTOR_DB_TYPE=postgresql
VECTOR_DB_HOST=<postgres-host>
VECTOR_DB_PORT=5432
VECTOR_DB_NAME=<database-name>
VECTOR_DB_USER=<database-user>
VECTOR_DB_PASSWORD=<database-password>
```

Optional override:

```text
VECTOR_DATABASE_URL=postgresql+psycopg://user:password@host:5432/dbname
```

If `VECTOR_DATABASE_URL` is set, DAAN uses it directly.

## Migration Notes From ChromaDB

Earlier ChromaDB setups relied on a local persisted directory and `vector_store_type: chroma`.

The PostgreSQL setup changes that behavior:

1. vectors are stored in PostgreSQL, not local Chroma files
2. knowledge-base stats are read from the PostgreSQL vector store implementation
3. KB deletion removes rows from PostgreSQL instead of Chroma collections

If you are moving from ChromaDB to PostgreSQL:

1. update `config/rag_config.yml` to `vector_store_type: pgvector`
2. configure `VECTOR_DB_*` or `VECTOR_DATABASE_URL`
3. ensure `vector_store_config.embedding_dimension` matches the active embedding model
4. re-index your knowledge bases into PostgreSQL

## How To Verify

### 1. Verify Available Knowledge Bases

Call:

```text
GET /api/rag/knowledge-bases
```

### 2. Verify Chatbot Uses Vector Retrieval

Call:

```text
POST /api/chat/message
```

and confirm the classic path returns grounded references.

### 3. Verify Chat-Agent Uses Vector Retrieval

Use this flow:

1. `POST /api/sessions` with `mode="chat_agent"`
2. `POST /api/sessions/{session_id}/upload-files`
3. `POST /api/chat/message`

The chat-agent path will retrieve documents through the same RAG vector search pipeline.

### 4. Verify The Active Store Type

Inspect [config/rag_config.yml](c:/Users/10842420/OneDrive%20-%20LTIMindtree/Desktop/GENAI%20COE/TASKS/DAAN_v5.0/DAAN_5/config/rag_config.yml) and confirm:

```yaml
vector_store_type: pgvector
```

## Current Status

At the moment:

1. classic chatbot uses vector retrieval over the configured PostgreSQL vector store
2. chat-agent uses vector retrieval over the configured PostgreSQL vector store
3. KB selection for chat-agent is supported through `kb_id`
4. the graph store remains separately configured and is not required for these vector-only chat paths