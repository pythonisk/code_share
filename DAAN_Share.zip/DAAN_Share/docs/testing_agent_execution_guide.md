# Agent Execution Testing Guide

## Full Workflow Testing Guide

### Prerequisites

**1. Activate venv and start server**
```powershell
$ROOT = "C:\Users\10842420\OneDrive - LTIMindtree\Desktop\GENAI COE\TASKS\DAAN_v5.0\DAAN_5"
cd $ROOT
& "$ROOT\virtual\Scripts\Activate.ps1"
cd "$ROOT\service"

# IMPORTANT: Run from the `service` folder so `daan` imports work.
fastapi run daan\main.py
```
Swagger UI: `http://localhost:8000/docs`

If you install Python packages or change server code/tools, restart the server.

**1b. Install / update dependencies (recommended)**

Jira publishing requires the `jira` Python package (installed via `service/requirements.txt`).

```powershell
cd "$ROOT\service"
python -m pip install -r requirements.txt
```

**2. Configure `.env`**

The `.env` file must be at `config/.env`.

Note: a `.env` file in the repo root is NOT read by the service. If you already have a root `.env`, copy the needed keys into `config/.env`.

Ensure the following keys are set:
```env
SECRET_KEY=any-random-string-for-dev
GOOGLE_GEMINI_KEY=your-gemini-key

# Jira action agent (UC_CP_001 / AGENT_2):
JIRA_BASE_URL=https://dk12.atlassian.net
JIRA_USERNAME=dheeraj.khobragade@ltimindtree.com
JIRA_API_TOKEN=your-token
JIRA_PROJECT_KEY=DAAN
JIRA_CLOUD=True
```

**3. Prepare input folder**

Create a directory with at least two files:
```
C:\...\DAAN_5\service\Inputs\session_001\
    questionnaire.txt        ← answers to requirements questions
    metadata_mapping.txt     ← field/column mapping details
    project_context.txt      ← (optional) project background
```
`SmartContextManager` reads all files in this directory. The filenames don't need to match exactly — any text files work. The more relevant context, the better the generated stories.

---

### Step 1 — Get an Auth Token (Current API)

> **Note**: `bootstrap-admin` currently has a `role_id NOT NULL` DB bug. If you have already fixed it (seed roles + assign role_id in user_service), proceed here. Otherwise create a user directly in SQLite first.

```http
POST http://localhost:8000/api/users/bootstrap-admin
Content-Type: application/json

{
  "username": "admin",
  "email": "admin@test.com",
  "firstname": "Test",
  "lastname": "Admin",
  "password": "Admin123!"
}
```
Expected: `201` with `access_token`.

Then login to get a fresh token (or re-use the bootstrap token):
```http
POST http://localhost:8000/api/users/generateToken
Content-Type: application/json

{
  "username_or_email": "admin@test.com",
  "password": "Admin123!"
}
```
Save the `access_token` — all subsequent requests need `Authorization: Bearer <token>`.

---

### Step 2 — Create a Session

This test uses **UC_CP_001** (User Stories → Jira).

```http
POST http://localhost:8000/api/usecases/session
Authorization: Bearer <token>
Content-Type: application/x-www-form-urlencoded

userid=admin@test.com&usecaseid=UC_CP_001&archType=Customer Proposed Use Cases
```
Expected response:
```json
{
  "sessionID": "550e8400-e29b-41d4-a716-446655440000",
  "userid": "admin@test.com",
  "archetype": "Customer Proposed Use Cases"
}
```
> This sets the module-level `generated_session_id` global. **Do not skip this step** — `/plan` will return `400` without it. Save `sessionID`.

**Session ID note (DAAN vs ADK):**

- DAAN uses this `sessionID` as the key for its in-memory workflow session store.
- Google ADK also uses a `session_id` internally inside `InMemoryRunner`.
- In this project we intentionally pass the *same string value* into ADK so logs and outputs correlate, but the ADK session store and DAAN session store are separate.
- Both are in-memory: restarting the server resets them, so you must re-run `/api/usecases/session` and `/api/plan`.

---

### Step 3 — Plan (Enrich Agents with Context)

```http
POST http://localhost:8000/api/plan
Authorization: Bearer <token>
Content-Type: application/json

{
  "session_id": "<sessionID from step 2>",
  "input_path": "C:/.../DAAN_5/service/Inputs/session_001",
  "usecase_id": "UC_CP_001",
  "archetype": "Customer Proposed Use Cases"
}
```
Expected: `200` with a `PlanResponse` that includes an enriched `agents` array. Each agent dict will have a `context` field populated by `SmartContextManager`.

> Use `UC_CP_001` (Jira). The `agents` array will contain `AGENT_1` (dynamic_agent) and `AGENT_2` (actionagent).

NOTE (current workflow): `/plan` now also caches the enriched agent configs in the in-memory workflow session store under the same `sessionID`, so `/workflow/run-dynamic-agents` can run by `session_id` alone.

---

### Step 4 — Run Sub-Agents (User Story Generation)

This runs `AGENT_1` (`UserStoryGeneration(Questionnaire)` — a `dynamic_agent`). Its output is the user stories that `AGENT_2` will post to Jira.

```http
POST http://localhost:8000/api/workflow/run-dynamic-agents
Authorization: Bearer <token>
Content-Type: application/json

{
  "session_id": "<sessionID>"
}
```
Recommended: send only `session_id`. The server uses the plan cached during `POST /api/plan`.

Backward compatible: you *may* also send `archetype`, `usecase_id`, and `agents` (enriched agent list), but they are optional.
Expected response:
```json
{
  "session_id": "550e8400-...",
  "state": "AGENTS_DONE",
  "dynamic_agent_outputs": {
    "AGENT_1": "As a user, I want to...\n..."
  }
}
```
> This is synchronous and may take 15–60s depending on the LLM. If it returns `500`, check server logs — the most common cause is a missing/invalid LLM API key.

---

### Step 5 — Fetch Output + Provide Feedback (Per-Agent)

This workflow now provides two feedback endpoints:

1) Fetch output from the in-memory session store:

```http
GET http://localhost:8000/api/workflow/agent/output?session_id=<sessionID>&agent_id=AGENT_1&usecase_id=UC_CP_001
Authorization: Bearer <token>
```

2) Rerun a single agent using base output + user feedback:

```http
POST http://localhost:8000/api/workflow/agent/feedback
Authorization: Bearer <token>
Content-Type: application/json

{
  "session_id": "<sessionID>",
  "usecase_id": "UC_CP_001",
  "agent_id": "AGENT_1",
  "user_feedback": "Please add acceptance criteria to each story and use Gherkin format.",
  "sample_output": null
}
```

Expected: `200` with `feedback_id`, `rerun_id`, and `new_output`.

> This can be called up to **3 times** (max feedback rounds). After 3 rounds, you must call `/proceed`.

NOTE: The legacy `POST /api/workflow/feedback` endpoint has been removed. Use per-agent rerun instead (`/api/workflow/agent/feedback`).

### Step 6 — Proceed (Run Action Agents)

This triggers `AGENT_2` (Jira) or `AGENT_3` (Trello) depending on which agents are in the plan. Each action agent receives only its `depends_on` dynamic_agent outputs (DAG-aware routing).

```http
POST http://localhost:8000/api/workflow/run-action-agents
Authorization: Bearer <token>
Content-Type: application/json

{
  "session_id": "<sessionID>"
}
```
Expected response:
```json
{
  "session_id": "...",
  "state": "ACTIONS_DONE",
  "action_agent_outputs": {
    "AGENT_2": "Posted 5 user stories to Jira project DAAN. Issue keys: DAAN-1, DAAN-2..."
  }
}
```
> `AGENT_2` receives the executed dynamic_agent outputs and the server passes them as a structured JSON payload to the action agent:
>
> - `reviewed_output`: combined text of executed dynamic_agent outputs
> - `dynamic_agent_outputs`: full map of outputs
>
> The Jira publisher tool expects `reviewed_output`.

> `/proceed` can only be called when state is `AGENTS_DONE`. Calling it prematurely returns `409`.

---

### Step 7 — Reporter Agent (Uses Latest Session Output)

Reporter can now read the latest dynamic_agent outputs from the session store when `agent_outputs` is empty.

```http
POST http://localhost:8000/api/reporter-agent/run
Authorization: Bearer <token>
Content-Type: application/json

{
  "archetype": "Customer Proposed Use Cases",
  "usecase_id": "UC_CP_001",
  "session_id": "<sessionID>",
  "agent_outputs": {},
  "metadata": null,
  "role": null,
  "provider": null
}
```

Expected: `200` with `report`.

---

### Step 8 — Quality Check (Final Assessment)

```http
POST http://localhost:8000/api/qualityagent/run
Authorization: Bearer <token>
Content-Type: application/json

{
  "session_id": "<sessionID>",
  "archetype": "Customer Proposed Use Cases",
  "usecase_id": "UC_CP_001",
  "report": "<paste report from reporter step>",
  "role": null,
  "provider": null
}
```

Expected: `200` with `assessment`.

---

### Step 9 — Check Session Status

```http
GET http://localhost:8000/api/workflow/session/<sessionID>
Authorization: Bearer <token>
```
Expected final state:
```json
{
  "session_id": "...",
  "archetype": "Customer Proposed Use Cases",
  "usecase_id": "UC_CP_001",
  "state": "ACTIONS_DONE",
  "feedback_count": 0,
  "max_feedback": 3,
  "dynamic_agent_outputs": { "AGENT_1": "..." },
  "action_agent_outputs": { "AGENT_2": "..." },
  "created_at": "2025-01-01T00:00:00",
  "updated_at": "2025-01-01T00:01:30",
  "error": null
}
```

---

### State Machine Reference

```
/api/usecases/session             →  INITIALIZED
/api/plan                         →  PLANNED
/api/workflow/run-dynamic-agents          →  AGENTS_RUNNING → AGENTS_DONE
/api/workflow/agent/feedback          →  AGENTS_RUNNING → AGENTS_DONE  (repeatable per agent, max 3x)
/api/workflow/run-action-agents       →  ACTIONS_RUNNING → ACTIONS_DONE
```

Notes:

- `GET /api/workflow/agent/output` is a read-only fetch and does not change state.
- Use `POST /api/workflow/agent/feedback` for feedback-driven improvements.

---

### Quick Reference — Use Case and Agents (Jira)

| Use Case ID | Name | Sub-Agent | Action Agent | Target |
|---|---|---|---|---|
| `UC_CP_001` | User Stories (Questionnaire) - Jira | `AGENT_1` | `AGENT_2` | Jira |

| Agent ID | Type | Description | Depends On |
|---|---|---|---|
| `AGENT_1` | `dynamic_agent` | `UserStoryGeneration(Questionnaire)` | — |
| `AGENT_2` | `actionagent` | `PostUserStories_Jira` | `AGENT_1` |

---

### Quick Curl Reference (PowerShell)

This script runs the whole workflow end-to-end in one go.

```powershell
$BaseUrl = "http://localhost:8000"
$AdminEmail = "admin@test.com"
$AdminPassword = "Admin123!"

# 0) Get token (bootstrap if first run, else login)
$bootstrapBody = @{
  username  = "admin"
  email     = $AdminEmail
  firstname = "Test"
  lastname  = "Admin"
  password  = $AdminPassword
} | ConvertTo-Json

$TOKEN = $null
try {
  $bootstrapResp = Invoke-RestMethod -Method Post `
    -Uri "$BaseUrl/api/users/bootstrap-admin" `
    -ContentType "application/json" `
    -Body $bootstrapBody
  $TOKEN = $bootstrapResp.access_token
} catch {
  # If admin already exists, bootstrap returns 409. Fall through to login.
}

if (-not $TOKEN) {
  $loginBody = @{
    username_or_email = $AdminEmail
    password          = $AdminPassword
  } | ConvertTo-Json

  $loginResp = Invoke-RestMethod -Method Post `
    -Uri "$BaseUrl/api/users/generateToken" `
    -ContentType "application/json" `
    -Body $loginBody
  $TOKEN = $loginResp.access_token
}

# 1) Create session (required; sets generated_session_id on server)
$SID = (Invoke-RestMethod -Method Post `
  -Uri "$BaseUrl/api/usecases/session" `
  -Headers @{ Authorization = "Bearer $TOKEN" } `
  -ContentType "application/x-www-form-urlencoded" `
  -Body "userid=admin@test.com&usecaseid=UC_CP_001&archType=Customer Proposed Use Cases").sessionID

# 2) Plan (enrich agents + caches plan into session store)
$planBody = @{
  session_id = $SID
  input_path = "C:/.../DAAN_5/service/Inputs/session_001"
  usecase_id = "UC_CP_001"
  archetype   = "Customer Proposed Use Cases"
} | ConvertTo-Json -Depth 10

Invoke-RestMethod -Method Post `
  -Uri "$BaseUrl/api/plan" `
  -Headers @{ Authorization = "Bearer $TOKEN" } `
  -ContentType "application/json" `
  -Body $planBody | Out-Null

# 3) Run dynamic_agents (session-only)
$runBody = @{ session_id = $SID } | ConvertTo-Json
$runResp = Invoke-RestMethod -Method Post `
  -Uri "$BaseUrl/api/workflow/run-dynamic-agents" `
  -Headers @{ Authorization = "Bearer $TOKEN" } `
  -ContentType "application/json" `
  -Body $runBody

$runResp.dynamic_agent_outputs

# 4) Fetch agent output view
$outView = Invoke-RestMethod -Method Get `
  -Uri "$BaseUrl/api/workflow/agent/output?session_id=$SID&agent_id=AGENT_1&usecase_id=UC_CP_001" `
  -Headers @{ Authorization = "Bearer $TOKEN" }

$outView | Select-Object session_id, agent_id, feedback_id, rerun_id

# 5) Per-agent rerun
$rerunBody = @{
  session_id    = $SID
  usecase_id    = "UC_CP_001"
  agent_id      = "AGENT_1"
  user_feedback = "Please add acceptance criteria to each story and use Gherkin format."
  sample_output = $null
} | ConvertTo-Json -Depth 10

$rerunResp = Invoke-RestMethod -Method Post `
  -Uri "$BaseUrl/api/workflow/agent/feedback" `
  -Headers @{ Authorization = "Bearer $TOKEN" } `
  -ContentType "application/json" `
  -Body $rerunBody

$rerunResp | Select-Object feedback_id, rerun_id

# 6) Proceed (action agents)
$proceedBody = @{ session_id = $SID } | ConvertTo-Json
$proceedResp = Invoke-RestMethod -Method Post `
  -Uri "$BaseUrl/api/workflow/run-action-agents" `
  -Headers @{ Authorization = "Bearer $TOKEN" } `
  -ContentType "application/json" `
  -Body $proceedBody

$proceedResp.action_agent_outputs

# 7) Reporter (agent_outputs empty => load from session store)
$reportBody = @{
  archetype      = "Customer Proposed Use Cases"
  usecase_id    = "UC_CP_001"
  session_id    = $SID
  agent_outputs = @{}
  metadata      = $null
  role          = $null
  provider      = $null
} | ConvertTo-Json -Depth 10

$reportResp = Invoke-RestMethod -Method Post `
  -Uri "$BaseUrl/api/reporter-agent/run" `
  -Headers @{ Authorization = "Bearer $TOKEN" } `
  -ContentType "application/json" `
  -Body $reportBody

# 8) Quality
$qualityBody = @{
  session_id = $SID
  archetype   = "Customer Proposed Use Cases"
  usecase_id = "UC_CP_001"
  report     = $reportResp.report
  role       = $null
  provider   = $null
} | ConvertTo-Json -Depth 10

$qualityResp = Invoke-RestMethod -Method Post `
  -Uri "$BaseUrl/api/qualityagent/run" `
  -Headers @{ Authorization = "Bearer $TOKEN" } `
  -ContentType "application/json" `
  -Body $qualityBody

$qualityResp | Select-Object assessment


# 9) Status
Invoke-RestMethod -Method Get `
  -Uri "$BaseUrl/api/workflow/session/$SID" `
  -Headers @{ Authorization = "Bearer $TOKEN" }
```

---

### Common Errors

| Error | Cause | Fix |
|---|---|---|
| `ModuleNotFoundError: No module named 'daan'` | Server started from wrong directory | Run `fastapi run daan\main.py` from `service\`, not from `service\daan\` |
| `400 No dynamic_agents found` | Planned agents missing from session store | Call `/api/plan` first for the same sessionID (or pass agents list in the /run-dynamic-agents body) |
| `404 Session not found` | Called `/api/workflow/run-action-agents` or agent endpoints with wrong session ID | Use the ID from `/api/usecases/session`, not from `/api/plan` |
| `500 dynamic_agent execution failed: Session not found: <id>` | ADK runner session not created (or app/session mismatch) | Update code to enable ADK auto session creation (already applied in this repo); restart server and retry |
| `409 Cannot give feedback in state` | Called `/api/workflow/agent/feedback` after `/api/workflow/run-action-agents` | State machine is one-way; start a new session |
| `409 Maximum feedback rounds reached` | Called `/api/workflow/agent/feedback` (or legacy `/api/workflow/feedback`) more than 3 times | Call `/api/workflow/run-action-agents` instead |
| `ActionAgent execution failed: Failed to create MCP session: ...` | MCP toolset misconfigured/unreachable | MCP is best-effort: keep `atlassian-mcp` in `config/mcp_config.yml` and restart; if an agent references an MCP server not in YAML (e.g., `trello-mcp-server`), DAAN tries a repo-local MCP module fallback and otherwise continues with local publisher tools |
| `500 dynamic_agent execution failed` | LLM API key missing/invalid, or `input_path` empty | Check server logs, verify `.env` keys and that input folder has files |
| `ActionAgent execution failed: No module named 'jira'` | Missing Jira Python dependency | Run `cd service; python -m pip install -r requirements.txt` and restart server |
| `ActionAgent output mentions "missing module" / "Jira integration"` | Jira dependency or import-path issue in publisher/MCP | Verify `jira` is installed, and restart server after code changes |
| `NOT NULL constraint failed: users.role_id` | Role seeding not done | Seed roles table in DB before calling bootstrap-admin |
