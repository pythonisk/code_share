# Frontend Guide

## Overview

The frontend is a simple Next.js 14 MVP UI focused on user management:

- Login
- Register
- Profile view/update
- Admin users list (promote, demote, delete)

## Prerequisites

- Node.js 18+
- npm 9+

## Install

```bash
cd ui
npm install
```

## Run

```bash
npm run dev
```

Frontend URL:

- http://127.0.0.1:3000

## Windows One-Command Startup

From repository root:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\dev.ps1
```

Optional custom ports:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\dev.ps1 -BackendPort 8001 -UiPort 3001
```

## Environment Variable

Use `ui/.env.local`:

```env
NEXT_PUBLIC_API_URL=http://127.0.0.1:8000
```

## Important Notes

- UI calls backend `/api` routes (not `/api/v1`).
- Auth uses JWT bearer token stored in localStorage.
- Current MVP uses simple fetch-based API helpers in `ui/lib/api.ts`.

## Current Pages

- `/`
- `/login`
- `/register`
- `/profile`
- `/admin/users`
