# D&A Knowledge Management Implementation Plan

## Table Of Contents

- [1. Use Case](#1-use-case)
  - [1.1 What We Are Building](#11-what-we-are-building)
  - [1.2 First Business Slice](#12-first-business-slice)
  - [1.3 Primary User Story](#13-primary-user-story)
  - [1.4 Why This Is Not Just Search](#14-why-this-is-not-just-search)
  - [1.5 What Context Fabric Means](#15-what-context-fabric-means)
  - [1.6 First Demo Target](#16-first-demo-target)
- [2. Flow](#2-flow)
  - [2.1 MVP User Flow](#21-mvp-user-flow)
  - [2.2 Chat-Style Context Capture](#22-chat-style-context-capture)
  - [2.3 Context Extrapolation Flow](#23-context-extrapolation-flow)
  - [2.4 Retrieval And Evidence Flow](#24-retrieval-and-evidence-flow)
  - [2.5 Artifact Generation Flow](#25-artifact-generation-flow)
- [3. Scope](#3-scope)
  - [3.1 MVP Scope](#31-mvp-scope)
  - [3.2 Implementation Split](#32-implementation-split)
- [4. Data Preparation](#4-data-preparation)
  - [4.1 Repository Inventory](#41-repository-inventory)
  - [4.2 File Triage](#42-file-triage)
  - [4.3 Metadata Taxonomy](#43-metadata-taxonomy)
  - [4.4 Metadata Classification](#44-metadata-classification)
  - [4.5 Knowledge Extraction](#45-knowledge-extraction)
  - [4.6 Ingestion Manifest](#46-ingestion-manifest)
- [5. DAAN Ingestion And Retrieval](#5-daan-ingestion-and-retrieval)
  - [5.1 Existing DAAN Capabilities To Reuse](#51-existing-daan-capabilities-to-reuse)
  - [5.2 High-Level Architecture](#52-high-level-architecture)
  - [5.3 DAAN Configuration](#53-daan-configuration)
  - [5.4 DAAN Ingestion Metadata Contract](#54-daan-ingestion-metadata-contract)
  - [5.5 Persona-Aware Search Contract](#55-persona-aware-search-contract)
  - [5.6 Evidence Grading](#56-evidence-grading)
  - [5.7 Context Extrapolation Service](#57-context-extrapolation-service)
  - [5.8 Artifact Generation](#58-artifact-generation)
  - [5.9 Feedback Loop](#59-feedback-loop)
  - [5.10 Separate KM Solution Components](#510-separate-km-solution-components)
  - [5.11 API Plan](#511-api-plan)
  - [5.12 Storage Plan](#512-storage-plan)
  - [5.13 Transfer Learning Plan - Later](#513-transfer-learning-plan---later)
  - [5.14 Scalability Design](#514-scalability-design)
  - [5.15 MVP Implementation Plan](#515-mvp-implementation-plan)
 


## 1. Use Case

### 1.1 What We Are Building

Build a scalable Knowledge Management (KM) solution that uses DAAN APIs as the retrieval and reasoning platform. The first business slice is D&A Sales / Presales / Solution Architecture, but the design must support many future personas, business domains, repositories, and knowledge bases.

The product should feel like a persona-aware KM workbench with a chat-style experience. Users should be able to ask naturally, get evidence-backed responses quickly, and generate reusable business artifacts with traceability.

At a high level, we are building a **knowledge operating layer** for D&A teams that connects:

```text
repository content
business context
persona and task intent
DAAN retrieval and reasoning
artifact generation
feedback and reuse
```

The workbench should deliver five core capabilities:

```text
1. Context capture
  Capture user intent through chat and lightweight context chips (persona, task, industry, technology, output type).

2. Context extrapolation
  Expand the initial question into deeper sub-questions, probes, and assumptions before retrieval.

3. Evidence retrieval and grading
  Retrieve candidate evidence from DAAN and grade it for persona relevance, task relevance, and evidence quality.

4. Artifact generation
  Produce cited outputs such as RFP responses, POV drafts, solution narratives, and reference summaries.

5. Feedback-driven reuse
  Capture edits and usefulness feedback so better responses can be generated over time.
```

The expected business outcomes are:

```text
faster first draft generation for RFP and POV work
more consistent response quality across teams
better reuse of approved assets
clear citation and explainability for trust
scalable expansion to more personas and KBs
```

The solution should help users turn unmanaged repository content into reusable business outputs:

```text
RFP responses
POV drafts
solution narratives
reference architecture summaries
case-study evidence packs
delivery playbooks
technical guidance
reusable answer snippets
```

### 1.2 First Business Slice

Start with a small, valuable slice:

```text
Domain: D&A
Knowledge base: DnA
First personas: Presales, Solution Architect, Sales
First tasks: RFP response, POV draft, case-study evidence discovery
First output: cited, client-ready RFP / POV draft
```

This is the first implementation slice only. The platform must later support:

```text
Future personas: Delivery, Data Engineer, Architect, QA, Product, Leadership, Support
Future KBs: Claims, DAAN, D&A, industry KBs, client-specific KBs, accelerator KBs
Future tasks: onboarding, delivery planning, architecture review, code migration, test design, solution comparison
```

### 1.3 Primary User Story

```text
As a D&A Solution Architect,
I want to ask a natural question about a client situation,
so that the KM system can find relevant approved evidence,
expand my question into deeper sub-questions,
and generate a cited response draft that I can reuse in an RFP or POV.
```

Example:

```text
User: Help me respond to a retail client asking about Databricks modernization.

System:
  - detects persona and task
  - asks short follow-up questions only if needed
  - expands context internally
  - searches DAAN D&A KB
  - grades evidence
  - generates a cited RFP draft
  - shows missing information and assumptions
```

### 1.4 Why This Is Not Just Search

Normal RAG:

```text
query -> similar chunks -> answer
```

KM Context Fabric:

```text
persona + task + query + context
  -> context extrapolation
  -> retrieval probes
  -> DAAN GraphRAG search
  -> evidence grading
  -> cited artifact generation
  -> feedback and reuse
```

The same file may be useful in different ways for different users:

```text
Presales:
  proof points, quantified value, client-safe story

Solution Architect:
  architecture pattern, technology choices, assumptions, risks

Delivery Lead:
  timeline, roles, delivery approach, implementation risks

Data Engineer:
  technical patterns, pipeline details, code conversion, data quality
```

### 1.5 What Context Fabric Means

Context Fabric is the metadata, relationship, feedback, and reasoning layer that makes knowledge useful for a specific person and task.

Context Mesh is the connected set of context dimensions:

```text
Persona -> Task -> Domain -> Offering -> Industry -> Technology -> Asset -> Evidence -> Outcome
```

Example:

```text
Solution Architect
  -> RFP response
  -> D&A
  -> Data Modernization
  -> Retail
  -> Databricks
  -> Case Study
  -> quantified migration acceleration
  -> reusable architecture narrative
```

### 1.6 First Demo Target

Build this demo first:

```text
Persona: Solution Architect
Task: RFP response
Domain: D&A
Industry: Retail
Technology: Databricks + Azure
Question: How do we modernize legacy ETL and data warehouse workloads into a lakehouse?
Output: Cited, client-ready RFP answer with approach, accelerators, proof points, assumptions, and missing information.
```

This demo proves:

```text
DAAN APIs can power KM workflows.
Persona changes evidence and output.
Context extrapolation extends the user's question.
The output is an artifact, not just a chat answer.
The design can scale beyond Sales/Presales.
```

## 2. Flow

### 2.1 MVP User Flow

The first flow should be chat-first, with optional chips. Avoid a large mandatory context form.

```text
1. User opens D&A KM Workbench.
2. User selects or confirms persona: Solution Architect.
3. User selects or types task: RFP response.
   OR User asks naturally:
   "Help me respond to a retail client asking about Databricks modernization."
5. System extracts available context:
   persona = Solution Architect
   task = RFP response
   industry = Retail
   technology = Databricks
6. System asks 1-3 short follow-up questions only if important context is missing.
7. System runs Context Extrapolation.
8. System calls DAAN search using original query + extrapolated retrieval probes.
9. System grades evidence by persona/task relevance.
10. System generates a cited artifact draft.
11. User edits, accepts, rejects, or gives feedback.
12. Artifact and feedback are saved for reuse.
```

### 2.2 Chat-Style Context Capture

The initial experience should be conversational:

```text
User: Need a POV for Databricks modernization for a retail prospect.

System: I can draft that. Is this for an executive POV, an RFP response, or a solution architecture note?

User: RFP response.

System: Got it. I will look for D&A modernization assets, Databricks references, retail or adjacent case studies, accelerators, proof points, assumptions, and risks.
```

Use optional chips to reduce typing:

```text
Persona: Presales | Solution Architect | Sales | Delivery | Data Engineer
Task: RFP response | POV | Case studies | Architecture | Technical deep dive
Industry: Retail | BFSI | Insurance | Healthcare | Manufacturing
Technology: Databricks | Snowflake | Fabric | Azure | AWS | dbt
Output: executive answer | detailed response | slide bullets | architecture note
```

The chips should assist the chat. They should not become a mandatory form.

### 2.3 Context Extrapolation Flow

Context extrapolation is the system extending the user's original ask into more questions before retrieval.

Input:

```text
user query
persona
task type
domain / KB
available context
chat history if available
uploaded file context if available
```

Output:

```text
intent summary
expanded questions
retrieval probes
metadata filters
missing context
clarifying questions
artifact outline
reasoning checkpoints
```

Example expansion:

```text
Original question:
  Help me respond to a retail client asking about Databricks modernization.

Expanded questions:
  What modernization pattern applies: migration, re-platforming, re-engineering, or lakehouse buildout?
  Which D&A offerings map to this situation?
  Which accelerators can be credibly mentioned?
  Which case studies provide retail or adjacent-industry proof?
  Which metrics are client-shareable?
  Which assumptions and risks should be stated?
  What final output format is expected?

Retrieval probes:
  Databricks modernization retail case study
  legacy ETL to PySpark accelerator
  lakehouse migration reference architecture
  D&A data modernization proof points

Missing context:
  current source platform
  target cloud
  migration timeline
  data volume
```

Structured output:

```json
{
  "intent": "Generate a client-ready RFP response for Databricks modernization",
  "expanded_questions": ["..."],
  "retrieval_probes": ["..."],
  "metadata_filters": {
    "domain": "D&A",
    "technologies": ["Databricks"],
    "industries": ["Retail"],
    "client_shareability": ["client_shareable", "anonymous_only"]
  },
  "missing_context": ["client current platform", "target cloud", "timeline", "data volume"],
  "clarifying_questions": ["Is the client asking for migration approach, timeline, or commercial differentiation?"],
  "artifact_sections": ["Executive answer", "Approach", "Reference architecture", "Proof points", "Assumptions"]
}
```

### 2.4 Retrieval And Evidence Flow

```text
1. Use the original user query.
2. Use context extrapolation retrieval probes.
3. Call DAAN GraphRAG search with a wider candidate pool.
4. Merge and deduplicate candidates.
5. Apply metadata filters where safe.
6. Grade candidates for persona/task usefulness.
7. Select top evidence for generation.
8. Keep DAAN citations and explainability trace.
```

Candidate grading should consider:

```text
persona relevance
task relevance
evidence strength
specificity
freshness
client shareability
reuse value
quality tier
```

### 2.5 Artifact Generation Flow

```text
graded evidence
  + artifact outline
  + persona style
  + task rules
  + citations
  + missing context
  -> generated draft
```

Artifact output should include:

```text
draft markdown
section list
citations
evidence table
assumptions
missing information
follow-up questions
confidence / readiness indicator
```

## 3. Scope

### 3.1 MVP Scope

The MVP should include:

```text
D&A domain setup
Presales / Solution Architect / Sales personas
RFP response and POV tasks
small curated D&A document set
data preparation before ingestion
ingestion through DAAN
retrieval through DAAN
context extrapolation
persona/task evidence grading
cited RFP / POV artifact generation
basic feedback capture
chat-style KM workbench
```


They can be later phases after the first search/artifact workflow is useful.

### 3.2 Implementation Split

The implementation should be planned in three simple blocks:

```text
Data Preparation
  Clean, classify, tag, and approve documents before indexing.

DAAN Ingestion And Retrieval
  Use DAAN APIs to ingest prepared files, store metadata, retrieve evidence, return citations, and provide explainability.

KM Workbench
  Provide the chat-style user experience, context extrapolation, evidence grading, artifact generation, and feedback capture.
```

## 4. Data Preparation

### 4.1 Repository Inventory

Create a repository inventory before ingestion. This can initially be CSV, SQLite, PostgreSQL, or a lightweight metadata table.

Minimum fields:

```text
file_id
file_path
repository_name
source_system
business_domain
knowledge_base_id
document_title
document_type
owner
last_modified
created_at
version
confidentiality
client_shareability
quality_tier
duplicate_status
obsolete_status
approved_for_ingestion
```


### 4.2 File Triage

Every file should be assigned a readiness tier:

```text
gold       ready for KM and safe to use
silver     useful but needs review or metadata enrichment
bronze     raw material, partial, or low confidence
reject     duplicate, obsolete, irrelevant, or unsafe
restricted confidential or not client-shareable
```

For the MVP, ingest only gold and selected silver files.

### 4.3 Metadata Taxonomy

Create a reusable taxonomy across all KBs, not just D&A.

Core dimensions:

```text
persona
task_type
business_domain
knowledge_base_id
industry
offering
technology
asset_type
evidence_type
confidentiality
client_shareability
delivery_phase
geography
account_type
reuse_status
```

Example personas: Presales, Solution Architect,Sales, Delivery Lead, Data Engineer

Example task types: rfp_response,pov_generation,case_study_finder,reference_architecture,solution_comparison,risk_assessment

Example asset types:case_study,rfp_response,proposal,solution_architecture,pov,accelerator,delivery_plan,estimation_model,technical_design


### 4.4 Metadata Classification

Build a metadata classifier as part of the data preparation pipeline.

Maturity levels:

```text
Level 1: filename/path rules
Level 2: document text heuristics
Level 3: LLM classification
Level 4: human review and approval
Level 5: feedback-improved classifier
```

Metadata example:

```json
{
  "knowledge_base_id": "DnA",
  "business_domain": "Data & Analytics",
  "document_type": "case_study",
  "personas": ["Presales", "Solution Architect"],
  "task_types": ["rfp_response", "case_study_finder", "pov_generation"],
  "industries": ["Retail"],
  "offerings": ["Data Modernization", "Lakehouse"],
  "technologies": ["Databricks", "Azure", "PySpark"],
  "client_shareability": "anonymous_only",
  "quality_tier": "gold",
  "evidence_strength": 0.82,
  "source_repository": "dna-case-studies",
  "asset_owner": "D&A Presales"
}
```

### 4.5 Knowledge Extraction

Extract reusable knowledge units from selected documents:

```text
problem_statement
client_context
solution_approach
architecture_pattern
accelerators_used
technology_stack
business_outcomes
delivery_timeline
metrics
risks
assumptions
lessons_learned
client_safe_summary
reusable_response_snippets
```

These can be stored in the KM metadata store and optionally indexed into DAAN as separate curated knowledge documents.


### 4.6 Ingestion Manifest

The output of data curation should be an ingestion manifest.

Example:

```json
{
  "file_path": "repositories/dna/case-studies/retail-databricks-modernization.pptx",
  "kb_id": "DnA",
  "document_type": "case_study",
  "personas": ["Presales", "Solution Architect"],
  "task_types": ["rfp_response", "pov_generation"],
  "industries": ["Retail"],
  "technologies": ["Databricks", "Azure"],
  "offerings": ["Data Modernization"],
  "client_shareability": "anonymous_only",
  "quality_tier": "gold",
  "approved_for_ingestion": true
}
```

Developer takeaway: build the data preparation pipeline first. Its job is to convert messy repositories into clean, tagged, approved ingestion packages.


## 5. DAAN Ingestion And Retrieval

Prepared files and metadata should flow into DAAN for indexing. Search, citations, GraphRAG, ontology expansion, and explainability should also come from DAAN. The KM layer should orchestrate these APIs and add persona/task logic, context extrapolation, evidence grading, artifact generation, and feedback.

### 5.1 Existing DAAN Capabilities To Reuse

Current DAAN already has these building blocks:

```text
RAG config and KB definitions in config/rag_config.yml
D&A KB entry with id DnA and collection D&A
persona starter questions in data/knowledge_chat_persona_questions.json
pgvector vector store using schema rag_vectors
Cosmos graph store for ontology / concept graph
GraphRAG retrieval with concept overlap
chunk-level concept tagging through metadata concept_ids
RAG search API with synthesis and explainability
chat UI and reusable chat panel
KB management UI
explainability and traversal graph APIs
```

Reuse these through stable APIs instead of rebuilding retrieval in the KM solution.

### 5.2 High-Level Architecture

The architecture has two connected flows:

1. **Knowledge preparation and ingestion**: repositories become curated, metadata-rich knowledge in DAAN.
2. **Runtime KM experience**: users ask through the KM Workbench, which uses DAAN retrieval and adds context extrapolation, grading, and artifact generation.

Knowledge preparation and ingestion flow:

```text
+----------------------+      +-------------------------+      +----------------------+
| Unmanaged Repos      | ---> | Data Preparation        | ---> | Ingestion Manifest   |
| SharePoint / Git     |      | inventory, triage,      |      | file + metadata +    |
| folders / decks      |      | taxonomy, classification|      | approval status      |
+----------------------+      +-------------------------+      +----------+-----------+
                                                                        |
                                                                        v
                     +--------------------------------------------------+--+
                     |                  DAAN Ingestion APIs                |
                     | upload/index files, pass metadata, chunk, embed     |
                     +---------------------------+-------------------------+
                                                 |
                                                 v
                     +-----------------------------------------------------+
                     |                 DAAN Knowledge Stores               |
                     | pgvector chunks + JSONB metadata + concept_ids      |
                     | Cosmos curated ontology / concept graph             |
                     +-----------------------------------------------------+
```

Runtime KM flow:

```text
+----------------------+      +-------------------------+      +----------------------+
| KM Workbench UI      | ---> | KM Orchestration API    | ---> | DAAN Search APIs     |
| chat, persona, task, |      | context extrapolation,  |      | GraphRAG, vector,    |
| optional chips       |      | probes, grading, draft  |      | ontology, citations  |
+----------+-----------+      +------------+------------+      +----------+-----------+
           ^                               |                              |
           |                               v                              v
           |                  +-------------------------+      +----------------------+
           |                  | Evidence + Artifact     | <--- | DAAN Results         |
           |                  | graded references,      |      | chunks, traces,      |
           |                  | assumptions, citations  |      | graph, documents     |
           |                  +------------+------------+      +----------------------+
           |                               |
           +-------------------------------+
                    feedback, edits, accepted artifact
```

End-to-end simplified view:

```text
Repositories
  -> Data Preparation
  -> DAAN Ingestion
  -> DAAN Retrieval
  -> KM Context Extrapolation + Evidence Grading
  -> Cited Artifact Draft
  -> User Feedback
```

### 5.3 DAAN Configuration

Keep existing `knowledge_bases`, but add a generic KM section later.

Example target configuration:

```yaml
km:
  enabled: true
  domains:
    - id: dna
      name: D&A Knowledge Management
      default_kb_id: DnA
      enabled: true
      personas:
        - Presales
        - Solution Architect
        - Sales
        - Delivery Lead
        - Data Engineer
      task_types:
        - rfp_response
        - pov_generation
        - case_study_finder
        - reference_architecture
      default_client_shareability_filter:
        - client_shareable
        - anonymous_only
      grading:
        enabled: true
        model_profile: reasoning
        candidate_pool: 30
      artifact_generation:
        enabled: true
        require_citations: true
        default_output_type: markdown
```

### 5.4 DAAN Ingestion Metadata Contract

DAAN indexing should accept optional metadata and persist it on chunks.

Target payload from the data preparation pipeline:

```json
{
  "kb_id": "DnA",
  "file_path": "...",
  "source_type": "repository",
  "metadata": {
    "business_domain": "Data & Analytics",
    "document_type": "case_study",
    "personas": ["Presales", "Solution Architect"],
    "task_types": ["rfp_response", "pov_generation"],
    "industries": ["Retail"],
    "offerings": ["Data Modernization"],
    "technologies": ["Databricks", "Azure"],
    "client_shareability": "anonymous_only",
    "quality_tier": "gold",
    "source_repository": "dna-case-studies"
  }
}
```

DAAN should store this metadata in the pgvector JSONB metadata column and preserve existing `concept_ids` behavior.

### 5.5 Persona-Aware Search Contract

Target request:

```json
{
  "query": "Draft a response for a retail Databricks modernization RFP",
  "kb_id": "DnA",
  "persona": "Solution Architect",
  "task_type": "rfp_response",
  "industry": "Retail",
  "technologies": ["Databricks"],
  "offerings": ["Data Modernization"],
  "output_type": "client_ready_rfp_answer",
  "top_k": 8,
  "candidate_pool": 30,
  "include_explainability": true
}
```

Search flow:

```text
1. Build context-aware search query.
2. Retrieve candidate pool from DAAN GraphRAG.
3. Apply metadata filters where safe.
4. Grade candidates using persona/task reasoning.
5. Rerank evidence.
6. Return graded references and reasoning.
```

### 5.6 Evidence Grading

Each retrieved chunk/document should receive structured grades:

```json
{
  "document_id": "...",
  "chunk_id": "...",
  "persona_relevance": 0.91,
  "task_relevance": 0.88,
  "evidence_strength": 0.82,
  "specificity": 0.76,
  "freshness": 0.69,
  "client_shareability_score": 1.0,
  "reuse_value": 0.84,
  "overall_score": 0.86,
  "reason": "Contains client-safe outcome metrics and a reusable Databricks modernization narrative."
}
```

### 5.7 Context Extrapolation Service

Implement as a reusable `ContextExtrapolationService` in the KM orchestration layer.

Implementation sequence:

```text
1. Normalize the user query.
2. Resolve persona and task type.
3. Load task-specific extrapolation template.
4. Ask the reasoning model to expand the context.
5. Convert expansion into structured JSON.
6. Use retrieval probes to call DAAN search multiple times or as an expanded multi-query request.
7. Merge and deduplicate candidate evidence.
8. Grade evidence against the original query and expanded questions.
9. Pass graded evidence and missing context into artifact generation.
```

### 5.8 Artifact Generation

Target artifact types:

```text
rfp_response
pov_draft
case_study_pack
solution_architecture_summary
reference_architecture_narrative
delivery_playbook
technical_deep_dive
```

Target response:

```json
{
  "artifact_id": "...",
  "artifact_type": "rfp_response",
  "persona": "Solution Architect",
  "task_type": "rfp_response",
  "draft_markdown": "...",
  "sections": [
    {
      "title": "Proposed Approach",
      "content": "...",
      "reference_ids": ["..."]
    }
  ],
  "evidence": [
    {
      "reference_id": "...",
      "source": "...",
      "grade": 0.86,
      "reason": "..."
    }
  ],
  "missing_information": ["..."],
  "assumptions": ["..."],
  "follow_up_questions": ["..."]
}
```

### 5.9 Feedback Loop

Capture feedback at these levels:

```text
source useful / not useful
wrong persona
wrong task
not client-shareable
outdated
high-value reusable snippet
artifact accepted
artifact edited
artifact rejected
missing evidence
```

Feedback schema:

```json
{
  "feedback_id": "...",
  "user_id": "...",
  "kb_id": "DnA",
  "persona": "Presales",
  "task_type": "rfp_response",
  "artifact_id": "...",
  "document_id": "...",
  "chunk_id": "...",
  "rating": "useful",
  "comment": "Strong metric but should be anonymized before client use."
}
```

### 5.10 Separate KM Solution Components

Recommended services:

```text
km-api
  PersonaService
  TaskService
  ContextFabricService
  ContextExtrapolationService
  EvidenceGradingService
  ArtifactGenerationService
  FeedbackService
  DaanClient
  optional later: InterviewService
  optional later: WinLossService

km-data-prep
  RepositoryScanner
  MetadataClassifier
  KnowledgeExtractor
  DuplicateDetector
  ConfidentialityClassifier
  DaanIngestionClient
```

Recommended UI modules:

```text
KM Home
Persona Workspace
Task Workspace
Chat-Style Context Capture
Evidence Explorer
Artifact Generator
Feedback Review
Admin Configuration
Optional Later: Expert Interview Bot
Optional Later: Win/Loss Capture
```

### 5.11 API Plan

DAAN APIs to reuse:

```text
GET  /api/rag/knowledge-bases
POST /api/rag/search
GET  /api/rag/knowledge-bases/{kb_id}/persona-questions
GET  /api/rag/knowledge-bases/{kb_id}/explainability/{query_link}
GET  /api/rag/knowledge-bases/{kb_id}/graph/{query_link}
GET  /api/rag/knowledge-bases/{kb_id}/documents/open
POST /api/rag/knowledge-bases/{kb_id}/upload-and-index
```

New KM APIs:

```text
GET  /api/km/domains
GET  /api/km/domains/{domain_id}/personas
GET  /api/km/domains/{domain_id}/task-types
POST /api/km/context/extrapolate
POST /api/km/search
POST /api/km/generate-artifact
GET  /api/km/artifacts/{artifact_id}
POST /api/km/artifacts/{artifact_id}/feedback
POST /api/km/evidence/grade
GET  /api/km/admin/taxonomy
POST /api/km/admin/taxonomy
```

Context extrapolation API request:

```json
{
  "domain_id": "dna",
  "kb_ids": ["DnA"],
  "persona": "Solution Architect",
  "task_type": "rfp_response",
  "query": "How do we respond to a retail client asking for Databricks modernization?",
  "known_context": {
    "industry": "Retail",
    "technologies": ["Databricks", "Azure"],
    "offerings": ["Data Modernization"]
  },
  "options": {
    "generate_clarifying_questions": true,
    "generate_retrieval_probes": true,
    "generate_artifact_outline": true
  }
}
```

Generic KM artifact request:

```json
{
  "domain_id": "dna",
  "kb_ids": ["DnA"],
  "persona": "Presales",
  "task_type": "rfp_response",
  "artifact_type": "client_ready_rfp_answer",
  "query": "Respond to a client asking how we modernize legacy ETL to Databricks.",
  "context": {
    "industry": "Retail",
    "technologies": ["Databricks", "PySpark", "Azure"],
    "tone": "professional",
    "length": "medium"
  },
  "options": {
    "require_citations": true,
    "include_missing_information": true,
    "include_assumptions": true,
    "use_context_extrapolation": true
  }
}
```

### 5.12 Storage Plan

Recommended KM tables:

```text
km_domains
km_personas
km_task_types
km_taxonomy_terms
km_repository_inventory
km_document_metadata
km_context_extrapolations
km_document_grades
km_artifacts
km_artifact_sections
km_feedback
km_approved_knowledge_units
optional later: km_interviews
optional later: km_interview_messages
optional later: km_win_loss_records
```

Vector metadata should include:

```json
{
  "kb_id": "DnA",
  "business_domain": "Data & Analytics",
  "document_type": "case_study",
  "personas": ["Presales", "Solution Architect"],
  "task_types": ["rfp_response"],
  "industries": ["Retail"],
  "offerings": ["Data Modernization"],
  "technologies": ["Databricks"],
  "client_shareability": "anonymous_only",
  "quality_tier": "gold",
  "concept_ids": ["..."]
}
```

Keep Cosmos focused on curated concepts and relationships:

```text
Persona
Task
Offering
Technology
Industry
Architecture Pattern
Accelerator
Outcome
Risk
Evidence Type
```

Avoid writing every chunk as a graph vertex. Keep chunk-to-concept mapping in pgvector metadata through `concept_ids`.

### 5.13 Transfer Learning Plan - Later

Do not begin with fine-tuning. Use progressive maturity levels.

```text
Level 1: Template Transfer
  approved artifact -> reusable section template -> prompt template -> generated artifact

Level 2: Feedback Transfer
  accepted evidence -> boost similar evidence
  rejected evidence -> reduce similar evidence

Level 3: Small Ranking Model
  train on query + persona + task + document metadata + useful/not useful label

Level 4: Fine-Tuning Artifact Generation
  only after enough approved artifacts exist
```

For MVP, use:

```text
metadata + reasoning model grading + templates + feedback loop
```

### 5.14 Scalability Design

Multi-domain: Every API should accept domain_id and kb_ids.
Do not hard-code D&A.
```

Multi-persona:

```text
Personas must be data-driven.
Each persona defines default tasks, output formats, ranking weights, allowed confidentiality, and prompt style.
```

Multi-KB:

```text
A task should search one or many KBs:
DnA only
DnA + DAAN
Claims + delivery playbooks
Client-specific KB + accelerator KB
```

Pluggable ranking:

```text
vector similarity
graph concept overlap
persona relevance
task relevance
quality tier
client shareability
freshness
user feedback
evidence strength
```

Async processing:

```text
repository scanning
metadata classification
knowledge extraction
document grading
large artifact generation
approved knowledge indexing
```

### 5.15 MVP Implementation Plan

Phase 0: Alignment and dataset selection

```text
Duration: 3-5 days
Select D&A as first domain.
Select 2-3 first personas: Presales, Solution Architect, Sales.
Select 2 first tasks: RFP response and POV generation.
Select 30-50 high-value documents.
Define initial taxonomy.
Define confidentiality/shareability rules.
```

Phase 1: Data preparation pipeline

```text
Duration: 1-2 weeks
Build repository scanner.
Create file inventory.
Classify metadata.
Assign quality tiers.
Detect duplicate/obsolete files.
Create ingestion manifest.
```

Phase 2: DAAN ingestion with metadata

```text
Duration: 1 week
Build ingestion client that calls DAAN APIs.
Pass metadata into DAAN chunk storage.
Index D&A KB.
Validate search, citations, and concept IDs.
```

Phase 3: KM search and evidence grading

```text
Duration: 1-2 weeks
Build KM search API.
Call DAAN search with candidate pool.
Run context extrapolation.
Grade evidence by persona/task.
Return evidence reasons.
Capture feedback.
```

Phase 4: Artifact generator MVP

```text
Duration: 1-2 weeks
Generate RFP response draft.
Generate POV draft.
Include citations.
Include missing information.
Include assumptions.
```

Phase 5: KM Workbench UI

```text
Duration: 2 weeks
Create persona selector.
Create task selector.
Create chat-style context capture.
Create optional context chips.
Create evidence explorer.
Create artifact editor/viewer.
Create feedback controls.
```

Phase 6: Optional knowledge enrichment

```text
Not part of initial flow.
Add expert interviews or win/loss capture only after the main artifact workflow is useful.
```

### 5.16 Implementation Backlog

Data preparation backlog:

```text
Build repository scanner.
Create document inventory schema.
Create taxonomy seed file.
Build metadata classifier.
Build confidentiality classifier.
Build duplicate detector.
Build knowledge extractor.
Build ingestion manifest generator.
Build DAAN ingestion client.
```

DAAN backlog:

```text
Add generic KM config section.
Ensure ingestion APIs accept extra metadata.
Ensure metadata arrays are preserved in vector metadata.
Add metadata filters for persona/task/domain where needed.
Add KM search wrapper or endpoint.
Add context extrapolation service or API integration.
Add task-specific extrapolation templates.
Persist extrapolated questions, retrieval probes, missing context, and clarification questions.
Add document grading service.
Add artifact generation service.
Add feedback persistence.
Add tests for metadata persistence and persona-aware ranking.
```

KM Workbench backlog:

```text
Create domain selector.
Create persona selector.
Create task selector.
Create chat-style context capture.
Create optional context chips instead of requiring a large form.
Create context extrapolation preview.
Create evidence panel.
Create generated artifact panel.
Create citations view.
Create feedback controls.
Create artifact history.
Create admin taxonomy editor.
```
