# DAAN Service High-Level Structure

Below is a high-level overview of the main folders in the `service/daan` backend, with a brief description of each. The LLM folder is expanded as a sample to illustrate the base provider and providers concept.

---

## Folders Overview

- **admin/**: User, role, and authentication logic (admin endpoints, user management, role-based access, password reset, etc.)
- **agents/**: Agent logic and core agent abstractions (dynamic builders, agent orchestration)
- **api/**: FastAPI routers and endpoints (API versioning, route definitions)
- **archetypes/**: Business logic for architecture types (CRUD, domain logic)
- **core/**: Core utilities (configuration, database, dependencies, health checks, logging, security)
- **data/**: Data objects and static data
- **flow/**: Workflow logic (core workflow engine, dynamic creators)
- **guardrails/**: Validation and guardrail logic
- **llm/**: Language Model Providers (see below for details)
- **mcp_servers/**: MCP server integrations
- **models/**: ORM models and entity definitions
- **native_tools/**: Native tool integrations
- **prompt_catalog/**: Prompt templates and catalog logic
- **schemas/**: Pydantic schemas for request/response validation
- **utils/**: Helper utilities (transformations, validations)
- **vector_stores/**: Vector database integrations

---

## LLM Folder (Expanded)

- **llm/base_provider.py**: 
    - Defines the `BaseLLMProvider` abstract class. All LLM providers must inherit from this and implement methods like `setup_environment()` and `create_model()`.

- **llm/provider_factory.py**: 
    - Contains `ProviderFactory`, which dynamically loads and instantiates the correct provider (Azure, Google, OpenAI) based on configuration. Uses a mapping and Python importlib for dynamic loading.

- **llm/azure_openai_provider.py**, **llm/google_provider.py**, **llm/openai_provider.py**: 
    - Concrete provider implementations. Each inherits from `BaseLLMProvider` and implements provider-specific logic for environment setup and model creation.

### Example: Provider Pattern

```python
# base_provider.py
class BaseLLMProvider(ABC):
    def __init__(self, config):
        self.config = config
    @abstractmethod
    def setup_environment(self):
        pass
    @abstractmethod
    def create_model(self, model_name):
        pass

# azure_openai_provider.py
class AzureOpenAIProvider(BaseLLMProvider):
    def setup_environment(self):
        # Azure-specific setup
        ...
    def create_model(self, model_name):
        # Azure-specific model creation
        ...

# provider_factory.py
class ProviderFactory:
    PROVIDER_MAP = { ... }
    @classmethod
    def create_provider(cls, provider_name, config):
        # Dynamically load and instantiate provider
        ...
```

- The factory allows you to add new providers with minimal changes.
- All providers share a common interface, making them interchangeable in the rest of the codebase.

---

This structure enables modular, extensible, and maintainable backend development for DAAN.