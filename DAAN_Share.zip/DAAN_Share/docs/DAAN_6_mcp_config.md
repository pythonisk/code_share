================================================================================
DAAN6 MCP CREDENTIALS MANAGEMENT FEATURE - TECHNICAL DOCUMENTATION
================================================================================

OVERVIEW
========
This feature enables users to securely store, manage, and use credentials for 
Model Context Protocol (MCP) servers. It provides a production-ready system for 
credential encryption, validation, and lifecycle management with enterprise-grade 
security practices.

SUPPORTED MCP SERVERS (12 Total)
=================================

CUSTOM REPO-LOCAL SERVERS (10):
--------------------------------
Server Name                   Script File                           Transport
-----------                   -----------                           ---------
jira-mcp-server              jira_mcp_server.py                    stdio
confluence-mcp-server        confluence_mcp_server.py              stdio
databricks-mcp-server        databricks_mcp_server.py              stdio
adf-mcp-server               adf_mcp_server.py                     stdio
dbt-cloud-mcp-server         dbt_cloud_mcp_server.py               stdio
ado-mcp-server               ado_mcp_server.py                     stdio
trello-mcp-server            trello_mcp_server.py                  stdio
snowflake-mcp-server         snowflake_mcp_server.py               stdio
sdg-snowflake-mcp-server     sdg_snowflake_mcp_server.py           stdio
testing-automation-mcp       testing_automation_mcp_server.py      stdio

OFFICIAL NPM-BACKED SERVERS (3):
---------------------------------
Server Name                   Command                                   Transport
-----------                   -------                                   ---------
atlassian-mcp                npx mcp-remote https://mcp.atlassian...  sse/stdio
azure-devops-mcp             npx @azure-devops/mcp@latest             stdio
azure-devops-wiki-mcp        npx @azure-devops/mcp@latest (wiki)      stdio


================================================================================
ARCHITECTURE & DESIGN DECISIONS
================================================================================

LAYERED ARCHITECTURE:
---------------------
┌─────────────────────────────────────────────────────────────┐
│  API Layer              (REST endpoints)                    │
│  service/daan/api/v1/endpoints/mcp_credentials.py           │
└────────────────────┬────────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────────┐
│  Schema/Validation  (Pydantic models)                       │
│  service/daan/schemas/mcp_credential.py                     │
└────────────────────┬────────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────────┐
│  Business Logic     (CRUD operations)                       │
│  service/daan/admin/mcp_service.py                          │
└─┬────────────┬──────────────┬──────────────┬───────────────┘
  │            │              │              │
  ▼            ▼              ▼              ▼
┌───── ┐  ┌──────────┐  ┌──────────┐  ┌────────────┐
│Cipher│  │Validator │  │Registry  │  │Process Mgr │
│      │  │          │  │(YAML)    │  │            │
└──┬───┘  └──────────┘  └──────────┘  └────────────┘
   │
   ▼ (MCP_ENCRYPTION_KEY from .env)
┌───────────────────────────────────────────────────────────┐
│  Data Layer          (SQLAlchemy models)                  │
│  service/daan/models/user_mcp.py                          │
│  Tables: user_mcp_configs, user_mcp_secrets               │
└───────────────────────────────────────────────────────────┘


SECURITY DESIGN PRINCIPLES:
----------------------------
1. Separation of Concerns - Metadata and encrypted secrets in separate tables
2. Encryption at Rest - All credentials encrypted using Fernet (AES-128-CBC)
3. Key Management - Master key stored in MCP_ENCRYPTION_KEY env variable (.env)
4. Rate Limiting - Decryption operations limited (60 req/min per user)
5. Breach Detection - SHA256 hash stored separately for leak detection
6. Soft Delete - Deleted credentials retained for audit/recovery


================================================================================
FILE-BY-FILE COMPONENT BREAKDOWN
================================================================================

1. CONFIGURATION FILES
======================

config/mcp_servers_registry.yml
--------------------------------
PURPOSE: Central configuration registry for all MCP servers
SIZE: ~380 lines
IMPORTANCE: ★★★★★ (Critical)

WHAT IT CONTAINS:
- Server definitions for all 12 MCP servers
- Required/optional credential fields per server
- Field descriptions for UI display
- Validation endpoints and methods
- Connection timeouts and retry policies
- Resource limits (max connections, memory limits)
- Global rate limiting policies

WHY IT'S CRITICAL:
✓ Single source of truth - One place to manage all server configs
✓ Dynamic validation - Add new servers without code changes
✓ Self-documenting - Field descriptions guide users
✓ UI-driven - Frontend reads this to generate forms dynamically
✓ Maintainability - Change server configs without touching code

EXAMPLE ENTRY:
  jira-mcp-server:
    display_name: "Jira MCP Server"
    required_fields: [host, email, api_token]
    field_descriptions:
      host: "Jira instance URL (e.g., https://your-domain.atlassian.net)"
    connection:
      timeout: 30
      idle_timeout: 1800

config/env.template
-------------------
UPDATED SECTION: Added MCP credential management environment variables

NEW VARIABLES:
- MCP_ENCRYPTION_KEY: Master encryption key (base64-encoded Fernet key)
- MCP_DECRYPT_RATE_LIMIT: Max decryption requests per time window
- MCP_DECRYPT_RATE_WINDOW: Time window in seconds


2. DATABASE MODELS
==================

service/daan/models/user_mcp.py
-------------------------------
PURPOSE: SQLAlchemy models for credential storage
SIZE: ~120 lines
IMPORTANCE: ★★★★★ (Critical)

CONTAINS:
- ValidationStatus Enum (NOT_TESTED, VALID, INVALID, EXPIRED, CONNECTION_FAILED)
- UserMcpConfig Model (metadata table)
- UserMcpSecret Model (encrypted credentials table)

UserMcpConfig FIELDS:
  id: Primary key
  user_id: Foreign key to users table (indexed)
  mcp_server_name: MCP server identifier (indexed)
  is_active: Enable/disable credential
  validation_status: Last validation result
  last_validation_at: When credentials were last validated
  last_accessed_at: Last decryption timestamp
  access_count: Number of times accessed
  expires_at: Credential expiration date
  credential_version: Encryption key version (supports key rotation)
  server_metadata: JSON text for non-sensitive config (workspace paths, etc.)
  created_at, updated_at, deleted_at: Timestamps
  
  UNIQUE CONSTRAINT: (user_id, mcp_server_name) - One credential per user per server

UserMcpSecret FIELDS:
  id: Primary key
  config_id: Foreign key to user_mcp_configs (CASCADE DELETE)
  encrypted_credentials: Fernet-encrypted JSON blob
  credential_hash: SHA256 hash for breach detection
  created_at, updated_at: Timestamps

DESIGN DECISIONS:
✓ Separate tables - Metadata vs encrypted data isolation
✓ Cascade delete - Secret automatically deleted when config is removed
✓ Soft delete - deleted_at allows recovery and audit trails
✓ Access tracking - Monitor credential usage patterns
✓ Key versioning - Support zero-downtime key rotation

service/daan/models/__init__.py
-------------------------------
UPDATED: Added MCP model imports from user_mcp.py
- UserMcpConfig, UserMcpSecret, ValidationStatus


3. CORE SERVICES
================

service/daan/core/mcp_encryption.py
------------------------------------
PURPOSE: Encrypt/decrypt credentials using Fernet symmetric encryption
SIZE: ~300 lines
IMPORTANCE: ★★★★★ (Critical)

KEY CLASSES:
- RateLimiter: In-memory rate limiting for decryption
- CredentialCipher: Main encryption service
- Global singleton: get_cipher_service()

METHODS:
  encrypt(credentials, key_version): Encrypt credential dictionary
  decrypt(encrypted_data, key_version, user_id): Decrypt credentials
  verify_hash(credentials, expected_hash): Verify credential integrity
  rotate_key(encrypted_data, old_version, new_version): Re-encrypt with new key
  clear_key_cache(): Clear cached encryption keys

ENCRYPTION ALGORITHM:
- Library: cryptography (PyCA)
- Algorithm: Fernet (AES-128-CBC + HMAC)
- Key size: 256-bit (URL-safe base64-encoded)
- Authentication: Built-in message authentication
- Key source: MCP_ENCRYPTION_KEY environment variable

RATE LIMITING:
- Default: 60 decryptions per 60 seconds per user
- Configurable via environment variables
- In-memory sliding window implementation
- Returns 429 Too Many Requests when exceeded

CREDENTIAL HASH:
- Algorithm: SHA256
- Purpose: Breach detection without decryption
- Stored separately in user_mcp_secrets table
- Can compare against known leaked credentials

SECURITY FEATURES:
✓ Authenticated encryption - Prevents tampering
✓ Rate limiting - Prevents brute force attacks
✓ Key caching - Performance optimization
✓ Hash verification - Detect compromised credentials

service/daan/mcp_servers/credential_validator.py
-------------------------------------------------
PURPOSE: Validate credentials against server registry
SIZE: ~200 lines
IMPORTANCE: ★★★★☆ (High)

KEY CLASSES:
- McpCredentialValidator: Main validator
- Global singleton: get_credential_validator()

METHODS:
  get_server_definition(server_name): Get server config from registry
  list_servers(): List all available server names
  validate_credentials(server_name, credentials, strict): Validate fields
  get_field_description(server_name, field_name): Get UI help text
  get_validation_config(server_name): Get validation endpoint/method
  get_connection_config(server_name): Get timeout/retry settings
  get_resource_limits(server_name): Get max connections/memory limits
  reload_registry(): Hot-reload configuration file

VALIDATION LOGIC:
1. Load server definition from registry YAML
2. Check for missing required fields
3. Identify extra fields (not in required or optional)
4. Return (is_valid, missing_fields, extra_fields)

STRICT MODE:
- strict=True: Raises InvalidCredentialFormatException on validation failure
- strict=False: Returns validation result without raising exception

UI INTEGRATION:
Frontend calls GET /mcp/servers/{name} to:
- Show required/optional fields
- Display field descriptions as help text
- Guide users on what to provide

BENEFITS:
✓ Early validation - Catch errors before encryption/storage
✓ Clear messages - Tell users exactly what's missing
✓ Dynamic config - Add servers without code changes
✓ Hot reload - Update configs without restart

service/daan/core/exceptions.py
--------------------------------
UPDATED: MCP exceptions merged into this existing file

ADDED COMPONENTS:
- McpErrorCode Enum (error codes for all MCP operations)
- McpException: Base MCP exception class
- Specialized exceptions: CredentialNotFoundException,
  CredentialExpiredException, DecryptionFailedException,
  EncryptionFailedException, ValidationFailedException,
  ServerUnreachableException, ProcessLimitReachedException,
  RateLimitExceededException, InvalidCredentialFormatException

NOTE: Previously a separate mcp_exceptions.py file. Merged into the
codebase's single exception file following project conventions.

EXCEPTION FEATURES:
✓ Structured data - error_code, message, details dict
✓ API-friendly - to_dict() method for JSON responses
✓ Contextual info - Include relevant data (server_name, user_id, etc.)
✓ HTTP mapping - Easy conversion to HTTP status codes

EXAMPLE ERROR RESPONSE:
{
  "error_code": "credential_expired",
  "message": "Credential for server 'jira-mcp-server' expired at 2026-07-20",
  "details": {
    "server_name": "jira-mcp-server",
    "expired_at": "2026-07-20T10:00:00"
  }
}


4. MCP PROCESS MANAGEMENT
==========================

service/daan/mcp_servers/process_manager.py
--------------------------------------------
PURPOSE: Manage lifecycle of stdio-based MCP server processes
SIZE: ~350 lines
IMPORTANCE: ★★★★★ (Critical for resource management)

KEY CLASSES:
- ProcessState Enum (STARTING, RUNNING, IDLE, FAILED, TERMINATED)
- McpProcess: Dataclass representing a single process
- McpProcessManager: Main manager class
- Global singleton: get_process_manager()

MANAGER METHODS:
  start(): Start manager and cleanup background task
  stop(): Stop manager and terminate all processes
  start_process(user_id, server_name, script_path, env): Start MCP server
  terminate_process(process_id): Gracefully terminate a process
  get_process(process_id): Retrieve process by ID
  get_user_processes(user_id): Get all processes for a user
  get_process_count(user_id): Count active processes
  get_statistics(): Get manager statistics

BACKGROUND TASKS:
- Cleanup loop runs every 5 minutes (configurable)
- Identifies idle processes (30 min default timeout)
- Terminates dead processes
- Frees up memory

RESOURCE LIMITS:
- Max 3 processes per user (configurable)
- Idle timeout: 1800 seconds (30 minutes)
- Memory monitoring per process
- Connection pooling and reuse

PROCESS LIFECYCLE:
1. User makes API call requiring MCP server
2. Check if process exists for this user+server
3. If exists and alive: Reuse
4. If not exists: Start new process (if under limit)
5. Track access time and count
6. After idle timeout: Terminate process

PROBLEM SOLVED:
WITHOUT Process Manager:
- Every API call starts new process
- Processes never terminated
- Memory leaks and crashes
- Resource exhaustion

WITH Process Manager:
- Process reuse
- Automatic cleanup
- Resource limits enforced
- Stable memory usage

MONITORING:
- Track uptime per process
- Count processes by state
- Average uptime across all processes
- Active user count


5. BUSINESS LOGIC LAYER
========================

service/daan/admin/mcp_service.py
----------------------------------
PURPOSE: CRUD operations for MCP credentials with encryption
SIZE: ~360 lines
IMPORTANCE: ★★★★★ (Critical)

KEY CLASS:
- McpCredentialsService: Main service class (in mcp_service.py)
- Global singleton: get_credentials_service()

CRUD METHODS:
  create_credential(): Validate, encrypt, and store credentials
  get_credential(): Retrieve and optionally decrypt credentials
  list_credentials(): List all credentials for a user
  update_credential(): Update existing credentials
  delete_credential(): Soft or hard delete credentials

CREATE WORKFLOW:
1. Validate credentials against server registry
2. Check for existing credential (prevent duplicates)
3. Encrypt credentials using cipher service
4. Create UserMcpConfig record (metadata)
5. Create UserMcpSecret record (encrypted data)
6. Commit transaction (atomic operation)
7. Return config without decrypted secrets

GET WORKFLOW:
1. Query database for config + secret (joinedload optimization)
2. Check if credential expired
3. If decrypt=True:
   a. Check rate limit
   b. Decrypt credentials
   c. Update access tracking (last_accessed_at, access_count)
4. Return config and optionally decrypted credentials

UPDATE WORKFLOW:
1. Retrieve existing credential
2. Validate new credentials (if provided)
3. Re-encrypt with same key version
4. Update config and secret records
5. Commit transaction

DELETE WORKFLOW:
- Soft delete: Set deleted_at timestamp
- Hard delete: Remove from database (cascade deletes secret)

TRANSACTION SAFETY:
✓ All operations wrapped in try-catch
✓ Rollback on any failure
✓ Atomic operations (all or nothing)
✓ Database constraints enforced

ORCHESTRATION:
Service coordinates between:
- Validator (check required fields)
- Cipher (encrypt/decrypt)
- Database (persist data)
- Process Manager (for MCP operations)


6. API SCHEMAS
==============

service/daan/schemas/mcp.py
---------------------------
PURPOSE: Pydantic models for request/response validation
SIZE: ~160 lines
IMPORTANCE: ★★★★☆ (High)

INPUT SCHEMAS:
  McpCredentialCreate: Create new credential
    - server_name (API request field), credentials, expires_at, server_metadata
    - Field validators for server_name format and credentials non-empty
  
  McpCredentialUpdate: Update credential
    - credentials, expires_at, server_metadata, is_active (all optional)
  
  McpCredentialValidate: Validate credential request
    - server_name only

OUTPUT SCHEMAS:
  McpCredentialResponse: Standard response (NO secrets)
    - All metadata fields (id, user_id, mcp_server_name, validation_status, etc.)
    - Never includes decrypted credentials
  
  McpCredentialWithSecrets: Response with decrypted credentials
    - Extends McpCredentialResponse
    - Adds credentials field
    - Only used when ?decrypt=true query param
  
  McpCredentialValidationResult: Validation response
    - is_valid, validation_message, tested_at
  
  McpProcessInfo: Process information
    - process_id, server_name, state, uptime, etc.
  
  McpServerDefinition: Server registry entry
    - Display name, description, required/optional fields, etc.
  
  McpServerListResponse: List of servers
    - servers[], total count
  
  McpStatistics: Process manager statistics

BENEFITS:
✓ Type safety - Ensures data structure correctness
✓ Input validation - Rejects malformed requests
✓ Auto-documentation - FastAPI generates OpenAPI/Swagger docs
✓ Serialization - Converts DB models to JSON
✓ Security - Response schemas prevent accidental secret leaks


7. REST API ENDPOINTS
======================

service/daan/api/v1/endpoints/mcp_credentials.py
-------------------------------------------------
PURPOSE: HTTP REST API for credential management
SIZE: ~480 lines
IMPORTANCE: ★★★★★ (Critical - User-facing interface)

10 ENDPOINTS:

CREDENTIAL MANAGEMENT:
  POST   /mcp/credentials
    Create new credential
    Body: McpCredentialCreate
    Returns: 201 Created + McpCredentialResponse
    Errors: 400 (validation), 500 (internal)
  
  GET    /mcp/credentials
    List user's credentials
    Query: include_inactive (bool)
    Returns: list[McpCredentialResponse]
  
  GET    /mcp/credentials/{server_name}
    Get specific credential
    Query: decrypt (bool) - return decrypted credentials
    Returns: McpCredentialResponse or McpCredentialWithSecrets
    Errors: 404 (not found), 410 (expired), 429 (rate limited)
  
  PUT    /mcp/credentials/{server_name}
    Update credential
    Body: McpCredentialUpdate
    Returns: McpCredentialResponse
    Errors: 404 (not found), 400 (validation)
  
  DELETE /mcp/credentials/{server_name}
    Delete credential
    Query: hard_delete (bool) - permanent vs soft delete
    Returns: 204 No Content
    Errors: 404 (not found)

VALIDATION:
  POST   /mcp/credentials/{server_name}/validate
    Validate against registry (doesn't test connectivity)
    Returns: McpCredentialValidationResult
    Errors: 404 (not found), 429 (rate limited)

SERVER REGISTRY:
  GET    /mcp/servers
    List all available MCP servers
    Returns: McpServerListResponse (12 servers)
  
  GET    /mcp/servers/{server_name}
    Get server definition details
    Returns: McpServerDefinition
    Errors: 404 (server not in registry)

PROCESS MANAGEMENT:
  GET    /mcp/processes
    List active processes for current user
    Returns: list[McpProcessInfo]
  
  GET    /mcp/statistics
    Get process manager statistics
    Returns: McpStatistics

FEATURES:
✓ Authentication - All endpoints require logged-in user (JWT)
✓ Authorization - Users can only access their own credentials
✓ IP tracking - Client IP captured for security logging
✓ Correlation IDs - X-Correlation-ID header for request tracing
✓ Error handling - Comprehensive HTTP status code mapping
✓ Rate limiting - Enforced at service layer
✓ Input validation - Pydantic schemas validate all inputs

HTTP STATUS CODES:
- 200: Success
- 201: Created
- 204: No Content (successful deletion)
- 400: Bad Request (validation failed)
- 404: Not Found
- 410: Gone (expired)
- 429: Too Many Requests (rate limited)
- 500: Internal Server Error

service/daan/api/router.py
--------------------------
UPDATED: Added MCP credentials router
- Registered at /api/v1/mcp prefix
- Tagged as "MCP Credentials" in OpenAPI docs


8. REQUIREMENTS & DEPENDENCIES
===============================

service/requirements.txt
------------------------
ADDED DEPENDENCIES:
  cryptography>=41.0.0,<43.0.0
    - Encryption library (Fernet implementation)
    - Industry-standard, well-audited

NOTE: azure-keyvault-secrets and azure-identity (MCP section) were removed.
Key management now uses MCP_ENCRYPTION_KEY from the .env file directly.


================================================================================
DATABASE SCHEMA
================================================================================

TABLE: user_mcp_configs
------------------------
Stores metadata and configuration for user MCP server credentials.

CREATE TABLE user_mcp_configs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    mcp_server_name VARCHAR(100) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    validation_status VARCHAR(50) DEFAULT 'not_tested' NOT NULL,
    last_validation_at TIMESTAMP WITH TIME ZONE,
    last_accessed_at TIMESTAMP WITH TIME ZONE,
    access_count INTEGER DEFAULT 0 NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE,
    credential_version INTEGER DEFAULT 1 NOT NULL,
    server_metadata TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    deleted_at TIMESTAMP WITH TIME ZONE,
    CONSTRAINT uq_user_server UNIQUE (user_id, mcp_server_name)
);

CREATE INDEX idx_user_mcp_configs_user_id ON user_mcp_configs(user_id);
CREATE INDEX idx_user_mcp_configs_mcp_server_name ON user_mcp_configs(mcp_server_name);

TABLE: user_mcp_secrets
------------------------
Stores encrypted credentials separately for security isolation.

CREATE TABLE user_mcp_secrets (
    id SERIAL PRIMARY KEY,
    config_id INTEGER NOT NULL UNIQUE REFERENCES user_mcp_configs(id) 
        ON DELETE CASCADE,
    encrypted_credentials TEXT NOT NULL,
    credential_hash VARCHAR(64) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

CREATE INDEX idx_user_mcp_secrets_config_id ON user_mcp_secrets(config_id);
CREATE INDEX idx_user_mcp_secrets_credential_hash ON user_mcp_secrets(credential_hash);


================================================================================
CONFIGURATION & DEPLOYMENT
================================================================================

ENVIRONMENT VARIABLES:
----------------------
Required:
  DATABASE_URL: PostgreSQL connection string
  MCP_ENCRYPTION_KEY: Base64-encoded Fernet key (master encryption key)
    Generate: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

Optional:
  MCP_DECRYPT_RATE_LIMIT: Max decryptions per time window (default: 60)
  MCP_DECRYPT_RATE_WINDOW: Time window in seconds (default: 60)


================================================================================
SECURITY CONSIDERATIONS
================================================================================

ENCRYPTION:
-----------
✓ Algorithm: Fernet (AES-128-CBC + HMAC-SHA256)
✓ Key size: 256-bit URL-safe base64-encoded
✓ Authentication: Built-in authenticated encryption
✓ Key storage: MCP_ENCRYPTION_KEY environment variable (.env)
✓ Key generation: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

RATE LIMITING:
--------------
✓ Decryption operations limited to 60 per minute per user
✓ Prevents brute force attacks
✓ In-memory sliding window implementation
✓ Configurable via environment variables

ACCESS CONTROL:
---------------
✓ Authentication required for all endpoints
✓ Users can only access their own credentials
✓ JWT token validation
✓ IP address tracking for audit

DATA PROTECTION:
----------------
✓ Credentials never logged in plaintext
✓ Encrypted at rest (database)
✓ Encrypted in transit (HTTPS)
✓ Separate table for encrypted data
✓ Soft delete with recovery option

BREACH DETECTION:
-----------------
✓ SHA256 hash stored separately
✓ Can compare against known leaked credentials
✓ No need to decrypt for breach checking
✓ Hash verification on retrieval

PROCESS ISOLATION:
------------------
✓ MCP processes run with limited permissions
✓ Environment variables passed securely
✓ Process cleanup after timeout
✓ Resource limits enforced


================================================================================
MONITORING & OBSERVABILITY
================================================================================

METRICS TO TRACK:
-----------------
- Credential creation/update/deletion rates
- Failed decryption attempts (potential security issue)
- Rate limit violations
- Active MCP process count
- Process memory usage
- Average credential age
- Expired credentials count
- Validation success/failure rates

LOGGING:
--------
All operations logged with:
- User ID
- Server name
- Operation type
- Success/failure
- IP address
- Correlation ID (if provided)

ALERTS:
-------
Recommended alerts:
- High rate of failed decryptions (> 10 in 5 min)
- MCP process count > threshold
- Credential expiry warnings (7 days before)
- Rate limit violations


================================================================================
TESTING ENDPOINTS
================================================================================

EXAMPLE API CALLS:
------------------

1. List Available Servers:
   curl -X GET "http://localhost:8000/api/v1/mcp/servers" \
     -H "Authorization: Bearer YOUR_TOKEN"

2. Get Jira Server Definition:
   curl -X GET "http://localhost:8000/api/v1/mcp/servers/jira-mcp-server" \
     -H "Authorization: Bearer YOUR_TOKEN"

3. Create Jira Credentials:
   curl -X POST "http://localhost:8000/api/v1/mcp/credentials" \
     -H "Authorization: Bearer YOUR_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{
       "server_name": "jira-mcp-server",
       "credentials": {
         "host": "https://your-domain.atlassian.net",
         "email": "user@example.com",
         "api_token": "your-api-token"
       }
     }'

4. List Your Credentials:
   curl -X GET "http://localhost:8000/api/v1/mcp/credentials" \
     -H "Authorization: Bearer YOUR_TOKEN"

5. Validate Credentials:
   curl -X POST "http://localhost:8000/api/v1/mcp/credentials/jira-mcp-server/validate" \
     -H "Authorization: Bearer YOUR_TOKEN"

6. Get with Decryption (use with caution):
   curl -X GET "http://localhost:8000/api/v1/mcp/credentials/jira-mcp-server?decrypt=true" \
     -H "Authorization: Bearer YOUR_TOKEN"

7. Update Credentials:
   curl -X PUT "http://localhost:8000/api/v1/mcp/credentials/jira-mcp-server" \
     -H "Authorization: Bearer YOUR_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{
       "credentials": {
         "host": "https://your-domain.atlassian.net",
         "email": "new-email@example.com",
         "api_token": "new-token"
       }
     }'

8. Delete Credentials (soft delete):
   curl -X DELETE "http://localhost:8000/api/v1/mcp/credentials/jira-mcp-server" \
     -H "Authorization: Bearer YOUR_TOKEN"

9. Check Active Processes:
   curl -X GET "http://localhost:8000/api/v1/mcp/processes" \
     -H "Authorization: Bearer YOUR_TOKEN"

10. Get Process Statistics:
    curl -X GET "http://localhost:8000/api/v1/mcp/statistics" \
      -H "Authorization: Bearer YOUR_TOKEN"


================================================================================
DEPLOYMENT CHECKLIST
================================================================================

PRE-DEPLOYMENT:
---------------
☐ Create database tables (user_mcp_configs, user_mcp_secrets)
☐ Install dependencies: pip install -r service/requirements.txt
☐ Generate MCP_ENCRYPTION_KEY and add to .env
☐ Set all required environment variables
☐ Run database migrations
☐ Test encryption/decryption locally

POST-DEPLOYMENT:
----------------
☐ Verify API endpoints are accessible
☐ Test credential creation flow
☐ Verify encryption is working (check encrypted_credentials field)
☐ Test rate limiting (make 61 decrypt requests)
☐ Verify process manager cleanup (wait 30 min)
☐ Check logs for errors
☐ Set up monitoring/alerts
☐ Document for users

ROLLBACK PLAN:
--------------
If issues occur:
1. API endpoints return errors → Check service logs
2. Encryption fails → Verify MCP_ENCRYPTION_KEY is set in .env
3. Process manager issues → Check process limits and cleanup task
4. Database errors → Verify table creation and constraints


================================================================================
FUTURE ENHANCEMENTS
================================================================================

PLANNED IMPROVEMENTS:
---------------------
1. Connection Testing - Validate credentials against actual MCP servers
2. Credential Sharing - Share credentials within teams/organizations
3. Audit Logging - Track all credential access (add audit table back)
4. Backup/Export - Export encrypted credentials for backup
5. Credential Templates - Pre-configured templates for common servers
6. Multi-tenancy - Organization-level credentials
7. Webhook Notifications - Alert on credential expiry
8. Usage Analytics - Track most-used servers and tools
9. Credential Rotation - Automatic password rotation integration
10. SSO Integration - OAuth/SAML for external services


================================================================================
SUPPORT & TROUBLESHOOTING
================================================================================

COMMON ISSUES:
--------------

Issue: "Encryption key not found"
Solution:
  - Verify MCP_ENCRYPTION_KEY is set in your .env file
  - Generate a new key: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
  - Ensure the value is a valid base64-encoded Fernet key

Issue: "Rate limit exceeded"
Solution:
  - Wait 60 seconds for rate limit to reset
  - Increase MCP_DECRYPT_RATE_LIMIT if legitimate high usage

Issue: "Process limit reached"
Solution:
  - Wait for idle processes to be cleaned up (30 min)
  - Manually terminate processes via API
  - Increase max_connections_per_user in process manager

Issue: "Credential expired"
Solution:
  - Update credential with new expires_at date
  - Or remove expires_at for no expiration

Issue: "Missing required fields"
Solution:
  - Check server definition in mcp_servers_registry.yml
  - Ensure all required fields are provided
  - Use GET /mcp/servers/{name} to see requirements


================================================================================
CONCLUSION
================================================================================

This MCP credentials management feature provides a production-ready, secure,
and scalable solution for storing and managing user credentials for 12 different
MCP servers. The architecture follows best practices for:

✓ Security (encryption, key management, rate limiting)
✓ Maintainability (layered architecture, separation of concerns)
✓ Scalability (connection pooling, resource management)
✓ Observability (logging, metrics, error handling)
✓ User experience (clear errors, validation, self-documenting API)

Total Lines of Code: ~2,000 lines across 8 files
Time to Implement: Complete end-to-end solution
Production Ready: Yes (with MCP_ENCRYPTION_KEY configured in .env)

================================================================================
