# Backend Guide

## Overview

The backend is a FastAPI service with a simple MVP scope:

- JWT auth (login/register/me)
- User management
- Admin role actions (promote/demote/list)
- SQLite by default
- Token and cost tracking for workflow LLM usage

Current app entrypoint is `daan.main:app` in the `service/daan` package.

## Token and Cost Tracking

The backend now tracks token consumption and cost for workflow-side LLM calls, including agent scoring side-calls.

### Storage Model

Persistent event ledger:
- Table: `token_usage_events`
- Model: `TokenUsageEvent`
- Schema fields include:
    - `session_id`
    - `created_at`
    - `user_id`
    - `usecase_id`
    - `prompt_tokens`
    - `completion_tokens`
    - `total_tokens`
    - `cost_usd`
    - `provider`
    - `model`
    - `run_type`
    - `estimated_tokens`
    - `estimated_cost`

Session-level snapshot:
- File: `session_storage/<session_id>/session_token_usage.json`
- Contains cumulative per-session totals and per-agent token usage records.

### Runtime Flow

1. LLM calls produce usage metadata through the LiteLLM-backed provider flow when available.
2. Cost records are normalized and attached to the workflow session.
3. `WorkflowSession.record_agent_cost(...)` updates in-memory totals.
4. Each cost record is persisted best-effort into `token_usage_events`.
5. Session snapshots are written to `session_token_usage.json` for session artifact inspection.

### Token Usage Module Layout

The token usage domain is now grouped under `service/daan/token_usage`.

Current files:
- `access.py`: authorization helpers for token analytics visibility
- `queries.py`: SQLAlchemy aggregation helpers used by dashboards
- `dashboard_service.py`: API-facing orchestration for dashboard payloads
- `persistence.py`: best-effort `token_usage_events` insert helper

### Dashboard Analytics APIs

The token analytics APIs read live values from `token_usage_events` and aggregate them for dashboard cards and charts.

Supported views:
- by user
- by use case
- top use case selector options

Access model:
- Admin users can view any user's token usage and any use case.
- Non-admin users can view only their own user-level token usage.
- Non-admin use case visibility is restricted to use cases reachable through their assigned archetypes.

### Aggregation Rules

- Time range filtering uses `created_at`.
- Sessions are calculated with `COUNT(DISTINCT session_id)`.
- Token totals use `SUM(total_tokens)`.
- Cost totals use `SUM(cost_usd)`.
- Time-series data is grouped by day.
- Top use case selector results are ranked by `total_tokens` descending.

## Prerequisites

- Python 3.11+
- `pip`

## Install

```bash
cd service
python -m pip install -r requirements.txt
```

## Environment Configuration

Configuration is loaded from:

- `config/.env`

Minimal keys currently used:

```env
ENVIRONMENT=development
HOST=0.0.0.0
PORT=8000

SECRET_KEY=change-this-in-production
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
ALLOWED_HOSTS=["*"]

DATABASE_URL=sqlite:///./daan.db

LOG_LEVEL=INFO
```

## Run the Server

From repository root:

```bash
python -m uvicorn daan.main:app --app-dir service --host 0.0.0.0 --port 8000
```

Useful URLs:

- API docs: http://127.0.0.1:8000/docs
- OpenAPI: http://127.0.0.1:8000/openapi.json
- ReDoc: http://127.0.0.1:8000/redoc

## Reset Admin Password (Local Recovery)

If you are locked out of an existing admin account, run this local utility:

```bash
cd service
python -m daan.admin.reset_admin_password --username-or-email daanadmin
```

You can also pass the password directly:

```bash
cd service
python -m daan.admin.reset_admin_password --username-or-email daanadmin --password "NewStrongPass123!"
```

Notes:

- The target user must already exist.
- The target user must have the `Admin` role.
- This utility is for local recovery and does not expose a public API endpoint.

## Current Backend Structure

```text
service/
└── daan/
    ├── main.py
    ├── api/
    │   └── router.py
    ├── admin/
    │   ├── auth_router.py
    │   ├── users_router.py
    │   ├── admin_router.py
    │   ├── auth_service.py
    │   ├── user_service.py
    │   └── role_service.py
    ├── core/
    │   ├── config.py
    │   ├── database.py
    │   ├── dependencies.py
    │   ├── health.py
    │   ├── logging.py
    │   └── security.py
    ├── models/
    └── schemas/

Additional active domain modules include:

```text
service/
└── daan/
    ├── llm/
    ├── flow/
    ├── models/
    ├── schemas/
    └── token_usage/
        ├── access.py
        ├── dashboard_service.py
        ├── persistence.py
        └── queries.py
```
```

## Notes

- Legacy `service/src` has been removed.
- Legacy `api/v1` route layout has been removed.
- Active API prefix is `/api`.
- `token_usage_events` acts as the durable ledger for dashboard analytics and cost audit trails.
