# Knowledge Graph, Publish, Refinement, and Run-History Implementation

**Date**: 2026-07-16  
**Status**: Implemented in the latest committed feature set  
**Commits Covered**:
- `332ae93` - `feat(knowledge-graph): add Kuzu graph store, query layer, and secured run-history APIs`
- `a02c7ab` - `feat(publish): add deterministic publish engine and Azure DevOps MCP work-item sync`
- `a404e0f` - `feat(workflow): add refinement lifecycle, proposal persistence, and feedback-aware reruns`
- `5804349` - `feat(UI): add run-history detail workflows, per-agent chat threads, and final report UX`
- `cba2fad` - `fix(startup): retry database initialization on transient MySQL handshake failures`

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Knowledge Graph Connection and Storage](#2-servicedaanknowledge_graphconnectionpy--connection-and-storage)
3. [Knowledge Graph Instrumentation Layer](#3-servicedaanknowledge_graphworkflow_instrumentationpy--workflow-instrumentation)
4. [Knowledge Graph API Endpoints](#4-servicedaanapiv1endpointsknowledge_graphpy--run-history-detail-chat-and-proposals)
5. [Refinement Agent and Workflow Lifecycle](#5-servicedaanagentscorerefinement_agentpy--refinement-lifecycle)
6. [Session Storage and Proposal Persistence](#6-servicedaanflowsession_servicepy--session-storage-and-proposal-lifecycle)
7. [Deterministic Publish Engine](#7-servicedaanpublish--deterministic-publish-engine)
8. [Frontend Run-History and Feedback UX](#8-ui-run-history-and-feedback-experience)
9. [Application Startup and Operational Guardrails](#9-servicedaanmainpy--startup-and-operational-guardrails)
10. [Complete End-to-End Data Flow](#10-complete-end-to-end-data-flow)
11. [Security, Multi-user, and Operational Notes](#11-security-multi-user-and-operational-notes)
12. [Files Changed Summary](#12-files-changed-summary)
13. [Reviewer Reading Order](#13-reviewer-reading-order)

---

## 1. Architecture Overview

This implementation adds a new review and execution loop to DAAN built on four connected subsystems:

1. **Knowledge Graph**: a Kuzu-backed lineage and analytics store for sessions, runs, agents, quality, issues, feedback, and external resources.
2. **Deterministic Publish Engine**: a reconcile-and-apply layer that parses reviewed output and syncs it to Azure DevOps work items through MCP.
3. **Refinement and Feedback Lifecycle**: a persistent workflow model where user feedback creates sequenced revisions and non-destructive proposals instead of overwriting outputs.
4. **Run-History UI**: a frontend surface that reads graph-backed history, shows full run detail, supports final report generation, and enables per-agent chat with Keep and Discard actions.

### High-level system flow

```mermaid
flowchart LR
	A[Workflow endpoints] --> B[Session storage]
	A --> C[Knowledge graph instrumentation]
	C --> D[(Kuzu knowledge graph)]
	D --> E[Run-history APIs]
	D --> F[Session-chat grounding]
	B --> F
	F --> G[Proposal persistence]
	G --> B
	A --> H[Deterministic publish engine]
	H --> I[ADO MCP tools]
	H --> C
	E --> J[Run History UI]
	F --> J
	B --> J
```

### What this feature set changes

```text
Before:
- workflow outputs were primarily file-based
- publish behavior depended on less deterministic output handling
- historical run review was limited
- feedback handling tended toward overwriting or shallow state retention

After:
- every workflow run is captured as graph lineage
- publish behavior is deterministic and MCP-driven
- run history is queryable by archetype / use case / session
- feedback becomes either a sequenced rerun or a non-destructive proposal
- refinement reuses historical issues and feedback from prior runs
```

---

## 2. [service/daan/knowledge_graph/connection.py](../service/daan/knowledge_graph/connection.py) -- Connection and Storage

### Changes Made

This file introduces the Kuzu knowledge-graph connection manager used by all graph APIs and instrumentation calls.

**Key responsibilities:**

- maintain a process-wide singleton Kuzu database and connection
- resolve the graph DB path from `KUZU_DB_PATH` or default to `data/knowledge_graph_db`
- initialize schema on first open
- surface a dedicated lock error when the embedded DB is already held by another process
- expose a shutdown hook to close the graph cleanly

### Core connection logic

```python
_lock = threading.Lock()
_db: kuzu.Database | None = None
_conn: kuzu.Connection | None = None

def get_kg_connection(db_path: str | None = None) -> kuzu.Connection:
	global _db, _conn

	if _conn is not None:
		return _conn

	with _lock:
		if _conn is not None:
			return _conn

		resolved_path = _resolve_db_path(db_path)
		_db = kuzu.Database(str(resolved_path))
		init_kg(_db)
		_conn = kuzu.Connection(_db)
		return _conn
```

### Path resolution and lock handling

```python
def _resolve_db_path(override: str | None) -> Path:
	if override:
		return _normalize_db_path(override)

	try:
		from daan.core.config import get_settings
		settings = get_settings()
		path = getattr(settings, "KUZU_DB_PATH", None)
		if path:
			return _normalize_db_path(path)
	except Exception:
		pass

	return _DEFAULT_DB_PATH


class KnowledgeGraphLockedError(RuntimeError):
	"""Raised when the KuzuDB store is already locked by another process."""
```

### How it works

```text
First KG call
	-> get_kg_connection()
	-> resolve path from override or settings
	-> open Kuzu database
	-> init schema if not present
	-> cache singleton connection

Later KG calls
	-> reuse cached connection

Application shutdown
	-> close_kg_connection()
	-> release embedded DB lock
```

### Why this matters

The knowledge graph is embedded and file-based, so a stable singleton access pattern is required. This file establishes the access contract used by:

- workflow instrumentation
- run-history and run-detail APIs
- session chat grounding
- final report regeneration
- publish resource persistence and cleanup

---

## 3. [service/daan/knowledge_graph/workflow_instrumentation.py](../service/daan/knowledge_graph/workflow_instrumentation.py) -- Workflow Instrumentation

### Changes Made

This module is the graph integration seam between workflow execution and the knowledge graph.

**Design rule:** graph bookkeeping must never break workflow execution.

That rule is enforced by making every instrumentation function best-effort:

- KG connection is acquired lazily
- lock or query failures degrade to no-op behavior
- instrumentation never raises back into the workflow path

### Best-effort connection behavior

```python
def _conn():
	try:
		from daan.knowledge_graph.connection import get_kg_connection
		return get_kg_connection()
	except Exception:
		logger.debug("KG connection unavailable; skipping instrumentation", exc_info=True)
		return None
```

### Session and run instrumentation

```python
def record_session_created(session_id, current_user, archetype, usecase_id, usecase_name=""):
	conn = _conn()
	if conn is None:
		return
	from daan.knowledge_graph.kg_events import on_session_created
	on_session_created(conn, session_id, _username(current_user), archetype, usecase_id, usecase_name)


def record_agent_run(session, current_user, agents, outputs, output_paths, trigger="manual"):
	conn = _conn()
	if conn is None:
		return None
	run_id = str(uuid4())
	run_number = _next_run_number(conn, session.session_id)
	previous_run_id = _latest_run_id(conn, session.session_id)
	...
```

### Feedback and chat-driven reruns

```python
def record_feedback_rerun(session, current_user, agent_id, agent, comment, output, output_path):
	conn = _conn()
	if conn is None:
		return
	...
	on_feedback_submitted(...)
	on_run_started(... trigger="feedback" ...)
	on_feedback_triggered_rerun(...)
	on_artifact_created(...)
	on_run_completed(...)


def record_chat_feedback_rerun(session_id, current_user, archetype, usecase_id, feedback_text, updated_agents, assessment=None):
	conn = _conn()
	if conn is None:
		return None
	...
```

### What is recorded in the graph

```text
Session creation
	-> User
	-> Use case
	-> Session

Agent execution
	-> Run
	-> AgentRun
	-> Output artifact

Feedback cycle
	-> Feedback node
	-> New rerun linked to previous run
	-> Updated output artifact

Quality lifecycle
	-> QualityAssessment
	-> Issue node when score falls below threshold

External publish resources
	-> resource nodes and links back to the originating run/session
```

### Why this matters

This module is what turns workflow execution into reusable historical memory. Without it, the later run-history UI and graph-backed chat endpoints would have no structured run lineage to query.

---

## 4. [service/daan/api/v1/endpoints/knowledge_graph.py](../service/daan/api/v1/endpoints/knowledge_graph.py) -- Run History, Detail, Chat, and Proposals

### Changes Made

This file adds the main user-facing graph API surface under `/api/knowledge-graph`.

It provides:

- run-history listing by archetype
- full run detail by session
- graph and output retrieval
- final report regeneration for historical sessions
- proposal keep and discard operations
- session-aware run chat
- row-level access control for normal users

### Key endpoint groups

| Endpoint | Purpose |
|---|---|
| `GET /run-history` | Return runs for an archetype, scoped to the current user unless admin |
| `GET /run-detail/{session_id}` | Return full session detail, agent outputs, feedback, proposals, and report state |
| `POST /generate-report/{session_id}` | Regenerate final report and quality for a historical run |
| `POST /session-chat` | Answer questions about a run or create feedback proposals |
| `POST /sessions/{session_id}/proposals/keep` | Promote proposal output to the live output |
| `POST /sessions/{session_id}/proposals/discard` | Remove pending proposals without changing output |

### Run-history endpoint

```python
@router.get("/run-history", response_model=RunHistoryResponse)
def get_run_history(current_user, db, archetype: str, usecase_id: str | None = None, limit: int = 200):
	conn = get_kg_connection()
	requester = str(getattr(current_user, "username", "") or "").strip()
	owner_filter = None if _is_admin(current_user) else requester
	runs = queries.get_run_history_for_archetype(
		conn, archetype.strip(), limit=limit, owner_username=owner_filter,
	)
	...
```

### What it does

```text
GET /run-history
	-> read graph runs by archetype
	-> restrict to owner unless current user is admin
	-> optionally filter to one use case
	-> enrich missing role / use-case name from SQL DB
	-> return summary items for UI listing
```

### Run-detail endpoint

```python
@router.get("/run-detail/{session_id}", response_model=RunDetailResponse)
def get_run_detail(session_id: str, current_user, db):
	conn = get_kg_connection()
	meta = queries.get_session_meta(conn, session_id)
	if meta is None:
		raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")
	...
	raw_agents = read_run_deliverables(session_id)
	...
```

### What run detail returns

```text
Session metadata
	-> archetype
	-> use case
	-> role
	-> status
	-> quality score

Deliverables
	-> one entry per agent
	-> current output
	-> feedback history
	-> proposal state

Report content
	-> final report markdown
	-> quality report markdown
	-> refinement output when available
```

### Session chat endpoint

This is one of the most important changes in the feature set.

The endpoint first classifies the message into one of two modes:

- **question**: answer from grounded graph and session state
- **feedback**: generate non-destructive proposed changes per agent

### Chat intent split

```python
intent = _classify_chat_intent(question, get_llm_response)

if intent == "feedback":
	answer, proposal_entries = await _propose_chat_feedback(
		session_id=session_id,
		usecase_id=usecase_id,
		instruction=question,
		role=role,
		name_by_agent=name_by_agent,
		target_agent_id=payload.agent_id,
	)
	return SessionChatResponse(... output_updated=False, proposals=proposals)
```

### Question-mode grounding

```python
timeline = queries.get_session_run_timeline(conn, session_id)
history = queries.get_recent_feedback_and_issues_for_usecase(conn, usecase_id, run_limit=5)

quality_report_md = read_session_file(session_id, QUALITY_OUTPUT_FILENAME) or ""
refinement_prompt_text = kg_instr.get_recurrence_guidance_text(usecase_id, run_limit=5)
refinement_output_md = read_session_file(session_id, REFINEMENT_OUTPUT_FILENAME) or ""
```

### Chat question context composition

```text
Question about a run
	-> load session metadata from graph
	-> load per-session run timeline from graph
	-> load recent issues for the same use case
	-> load recent feedback for the same use case
	-> load quality report from session storage
	-> load refinement prompt and output
	-> build grounded context prompt
	-> answer with LLM using only this run-specific context
```

### Feedback-mode safety model

```text
Feedback request in chat
	-> do not mutate output immediately
	-> generate proposed replacement per affected agent
	-> persist proposal.md and proposal.json
	-> return proposals to UI
	-> wait for explicit Keep or Discard action
```

### Proposal promotion endpoints

```text
POST /sessions/{session_id}/proposals/keep
	-> replace current agent output with proposal output
	-> delete proposal files
	-> refresh run detail / quality in UI
	-> instrument graph update

POST /sessions/{session_id}/proposals/discard
	-> remove proposal files only
	-> leave current output unchanged
	-> refresh run detail in UI
```

### Why this file matters

This API layer is where the knowledge graph becomes a product feature. It is not just exposing raw graph data; it assembles graph lineage, session artifacts, feedback history, proposals, and reporting into a single review surface.

---

## 5. [service/daan/agents/core/refinement_agent.py](../service/daan/agents/core/refinement_agent.py) -- Refinement Lifecycle

### Changes Made

This file adds the dedicated refinement agent used after dynamic and action-agent execution.

The refinement agent improves the current workflow output using lessons learned from the last several executions of the same use case.

### Base instruction

```python
_BASE_INSTRUCTION = (
	"You are the Refinement Agent. You receive an output produced by earlier "
	"agents, plus lessons learned from the last few executions of this same use "
	"case (prior user feedback and previously reported issues).\n\n"
	"Revise the output so it fully applies every piece of prior feedback and "
	"avoids every previously reported issue. ..."
)
```

### Instruction assembly

```python
def build_refinement_instruction(guidance_text: str) -> str:
	guidance_text = (guidance_text or "").strip()
	if not guidance_text:
		return _BASE_INSTRUCTION
	return f"{_BASE_INSTRUCTION}\n\n{guidance_text}"
```

### Agent creation and execution

```python
def create_refinement_agent(guidance_text: str, provider: str | None = None) -> Agent:
	provider_name = provider or get_default_provider_name()
	model, provider_info = create_litellm_model(provider_name)
	return Agent(
		name="refinement_agent",
		model=model,
		description="Refines combined agent output using prior feedback and issues",
		instruction=build_refinement_instruction(guidance_text),
		tools=[],
	)


async def run_refinement_agent_async(current_output: str, guidance_text: str, role: str | None = None, provider: str | None = None) -> str:
	agent = create_refinement_agent(guidance_text, provider=provider)
	...
```

### Block-preserving refinement for chat-driven edits

The same file also adds a second refinement mode for minimal, review-friendly edits.

```python
_BLOCK_REFINEMENT_INSTRUCTION = (
	"You are the Suggested-Changes Refinement Agent. You receive a current "
	"output and a single user feedback instruction. Produce a revised version "
	"of the SAME output that applies the feedback with the smallest possible "
	"change. ..."
)
```

```python
async def run_block_refinement_async(current_output: str, feedback_text: str, role: str | None = None, history_text: str | None = None, provider: str | None = None) -> str:
	agent = _create_block_refinement_agent(provider=provider)
	...
```

### How refinement works

```text
Workflow completes
	-> gather current combined output
	-> gather last-5 feedback and issues for same use case from graph
	-> build guidance text
	-> run refinement agent
	-> persist refinement output to session storage
	-> expose refinement prompt and output through workflow / graph endpoints
```

### Why this matters

This turns prior runs into a reusable correction layer. The graph is not just historical storage; it directly shapes future output quality.

---

## 6. [service/daan/flow/session_service.py](../service/daan/flow/session_service.py) -- Session Storage and Proposal Lifecycle

### Changes Made

This file becomes the authoritative storage layer for session artifacts, feedback revisions, and non-destructive proposals.

### Feedback-aware output persistence

```python
def write_agent_output(session_id: str, agent_id: str, content: str, *, feedback_seq: int | None = None) -> str:
	if feedback_seq is not None:
		output_path = session_dir / "agents" / safe_agent_id / "feedback" / f"{seq:03d}" / "output.md"
	else:
		output_path = session_dir / "agents" / safe_agent_id / "output.md"
	output_path.write_text(content, encoding="utf-8")
	return str(output_path)
```

This is the storage rule that preserves the full revision chain instead of overwriting the original output.

### Proposal persistence model

```python
def write_agent_proposal(session_id: str, agent_id: str, content: str, feedback_text: str) -> str:
	proposal_path = agent_dir / "proposal.md"
	metadata_path = agent_dir / "proposal.json"
	proposal_path.write_text(content or "", encoding="utf-8")
	metadata = {
		"agent_id": agent_id,
		"feedback_text": feedback_text or "",
		"created_at": datetime.now(timezone.utc).isoformat(),
	}
	metadata_path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
	return str(proposal_path)
```

### Proposal read, delete, and listing

```python
def read_agent_proposal(session_id: str, agent_id: str) -> dict[str, Any] | None:
	...


def delete_agent_proposal(session_id: str, agent_id: str) -> bool:
	...


def list_agent_proposals(session_id: str) -> list[dict[str, Any]]:
	...
```

### Proposal lifecycle

```text
Chat feedback request
	-> generate revised output draft
	-> persist proposal.md + proposal.json
	-> keep original output.md untouched

User clicks Keep
	-> replace current output with proposal
	-> delete proposal files

User clicks Discard
	-> delete proposal files only
	-> preserve current output exactly as-is
```

### Why this matters

This is the mechanical layer that makes the new review workflow safe. The UI and graph APIs depend on this storage contract to keep feedback reversible and inspectable.

---

## 7. [service/daan/publish](../service/daan/publish) -- Deterministic Publish Engine

### Changes Made

This subsystem replaces ad hoc publish behavior with a deterministic parse, reconcile, and execute flow.

It is made up of:

- [service/daan/publish/models.py](../service/daan/publish/models.py)
- [service/daan/publish/parser.py](../service/daan/publish/parser.py)
- [service/daan/publish/reconciler.py](../service/daan/publish/reconciler.py)
- [service/daan/publish/service.py](../service/daan/publish/service.py)
- ADO MCP work-item tooling added in [service/daan/mcp_servers/ado_mcp_server.py](../service/daan/mcp_servers/ado_mcp_server.py)

### 7.1 Parser

The parser converts approved agent output into `DesiredItem` records.

### Stable local identity

```python
def stable_local_key(prefix: str, identity: str) -> str:
	digest = hashlib.sha1((identity or "").strip().lower().encode("utf-8")).hexdigest()[:10]
	return f"{prefix}-{digest}"


def _local_key_for(story: dict[str, Any], prefix: str, title: str) -> str:
	ext_id = str(story.get("id") or story.get("local_key") or "").strip()
	if ext_id:
		return ext_id
	return stable_local_key(prefix, title)
```

### Embedded JSON extraction

```python
def _iter_balanced_json(text: str):
	...


def _iter_json_story_lists(text: str):
	for cand in _iter_balanced_json(text):
		data = json.loads(cand)
		...
```

### Why this parser was needed

The upstream generator can emit:

- raw JSON
- fenced JSON
- JSON wrapped inside `--- Output from AGENT_x ---` sections

This parser handles all of those and preserves stable identity across reruns so the same logical work item can be updated rather than recreated.

### 7.2 Publish backend selection

The publish service is backend-agnostic and resolves a tool bundle from the action agent's configured MCP server.

```python
def _ado_backend() -> dict[str, Any]:
	return {
		"name": "azure_devops_mcp",
		"resource_type": "ado_work_item",
		"is_configured": ado_is_configured,
		"create": lambda item, parent_id: AdoCreateWorkItemTool(...),
		"update": lambda item, resource_key, parent_id: AdoUpdateWorkItemTool(...),
		"remove": lambda resource_key, title, kind, local_key: AdoDeleteWorkItemTool(item_id=resource_key),
	}
```

```python
_MCP_BACKENDS = [
	(("azure-devops-mcp", "azure-devops", "ado-work", "ado_work"), _ado_backend),
]
```

### 7.3 Reconciliation and execution

```python
def sync_publish_target(agent_cfg: dict[str, Any], reviewed_output: str, existing_resources: list[dict[str, Any]]) -> Optional[dict[str, Any]]:
	backend = get_adapter_for_agent(agent_cfg)
	if backend is None:
		return None

	desired = parse_desired_items(reviewed_output)
	existing = _existing_from_kg(existing_resources)
	plan = reconcile(desired, existing)
	result = _execute_plan(plan, backend, desired)
	...
```

### Parent-child preservation during execution

```python
resolved_keys: dict[str, str] = {}
for action in plan.actions:
	if action.resource_key:
		resolved_keys[action.local_key] = action.resource_key

for action in plan.actions:
	item = desired_by_key.get(action.local_key)
	parent_key = resolved_keys.get(item.parent_local_key) if item and item.parent_local_key else None
	...
```

This pre-seeding is what prevents new children from being orphaned when their parent already exists in the backend.

### 7.4 Publish result manifest

```python
def _manifest_text(resources: list[dict[str, Any]], summary: dict[str, int]) -> str:
	body = json.dumps({"resources": resources}, ensure_ascii=False, indent=2)
	return (
		f"Deterministic publish sync complete. ...\n\n"
		"```daan-resources\n" + body + "\n```\n"
	)
```

### Deterministic publish flow

```text
Reviewed agent output
	-> parse into DesiredItem list
	-> load existing published resources from KG
	-> reconcile desired vs existing state
	-> call MCP create / update / remove tools
	-> capture result manifest
	-> persist resource links back into graph
	-> purge removed resource keys from KG
```

### Why this matters

This subsystem separates reasoning from side effects. Agents can still generate content, but publish operations now happen through a predictable reconciliation layer instead of free-form action behavior.

---

## 8. UI Run-History and Feedback Experience

### Files changed

- [ui/src/app/[archetype]/run-history/page.tsx](../ui/src/app/[archetype]/run-history/page.tsx)
- [ui/src/app/[archetype]/planner-output/page.tsx](../ui/src/app/[archetype]/planner-output/page.tsx)
- [ui/src/components/DiffView.tsx](../ui/src/components/DiffView.tsx)
- [ui/src/utils/lineDiff.ts](../ui/src/utils/lineDiff.ts)
- [ui/src/config/apiConfig.ts](../ui/src/config/apiConfig.ts)
- [ui/src/components/AppShell.tsx](../ui/src/components/AppShell.tsx)
- [ui/src/utils/reportRendering.tsx](../ui/src/utils/reportRendering.tsx)

### API endpoint wiring

```ts
RUN_HISTORY: (archetype: string, limit = 200, usecaseId?: string) =>
  `/api/knowledge-graph/run-history?archetype=${encodeURIComponent(archetype)}&limit=${limit}` +
  (usecaseId ? `&usecase_id=${encodeURIComponent(usecaseId)}` : ''),

RUN_DETAIL: (sessionId: string) =>
  `/api/knowledge-graph/run-detail/${encodeURIComponent(sessionId)}`,

GENERATE_REPORT: (sessionId: string) =>
  `/api/knowledge-graph/generate-report/${encodeURIComponent(sessionId)}`,

SESSION_CHAT: '/api/knowledge-graph/session-chat',
```

### Per-agent chat thread state

```tsx
const FINAL_REPORT_TAB = '__final_report__';

const [chatByAgent, setChatByAgent] = useState<Record<string, ChatMessage[]>>({});
const [activeTab, setActiveTab] = useState<string>('');

const chatMessages = useMemo<ChatMessage[]>(
  () => chatByAgent[activeTab] ?? [],
  [chatByAgent, activeTab],
);
```

### Run-history loading

```tsx
const response = await fetch(`${getBaseUrl()}${API_ENDPOINTS.RUN_HISTORY(archetypeTitle, 200, scopedUsecaseId || undefined)}`, {
  method: 'GET',
  headers: authHeaders(),
});
```

### Run-detail loading and thread seeding

```tsx
const response = await fetch(`${getBaseUrl()}${API_ENDPOINTS.RUN_DETAIL(sessionId)}`, {
  method: 'GET',
  headers: authHeaders(),
});

for (const agent of data.agents ?? []) {
  const thread: ChatMessage[] = [];
  for (const fb of agent.feedback ?? []) {
	if (fb.feedback_text) thread.push({ role: 'user', content: fb.feedback_text });
	thread.push({ role: 'assistant', content: `Applied feedback #${fb.seq}` });
  }
  ...
}
```

### Chat send behavior

```tsx
const response = await fetch(`${getBaseUrl()}${API_ENDPOINTS.SESSION_CHAT}`, {
  method: 'POST',
  headers: { ...authHeaders(), 'Content-Type': 'application/json' },
  body: JSON.stringify({
	session_id: detail.session_id,
	question,
	agent_id: activeTab && activeTab !== FINAL_REPORT_TAB ? activeTab : undefined,
  }),
});
```

### Keep and Discard actions

```tsx
const response = await fetch(`${getBaseUrl()}${API_ENDPOINTS.KEEP_PROPOSALS(detail.session_id)}`, {
  method: 'POST',
  headers: { ...authHeaders(), 'Content-Type': 'application/json' },
  body: JSON.stringify({ agent_ids: [agentId] }),
});
```

```tsx
const response = await fetch(`${getBaseUrl()}${API_ENDPOINTS.DISCARD_PROPOSALS(detail.session_id)}`, {
  method: 'POST',
  headers: { ...authHeaders(), 'Content-Type': 'application/json' },
  body: JSON.stringify({ agent_ids: [agentId] }),
});
```

### UI behavior flow

```text
User opens Run History
	-> load run summaries from knowledge-graph API

User opens one run
	-> load run detail
	-> hydrate agent outputs, feedback history, proposals, final report
	-> create one chat thread per agent

User asks a question
	-> call session-chat
	-> render grounded answer in active agent thread

User gives feedback
	-> call session-chat
	-> receive proposal payloads
	-> show inline diff
	-> user clicks Keep or Undo
	-> refresh run detail
```

### Why this matters

This frontend converts the graph and proposal mechanics into a usable review workflow. Without it, the backend changes would exist, but users would not have a coherent interface for historical runs and agent-specific feedback.

---

## 9. [service/daan/main.py](../service/daan/main.py) -- Startup and Operational Guardrails

### Changes Made

This file adds the startup retry guard that protects the new graph and reporting surfaces from transient MySQL startup failures.

### Retry wrapper

```python
def _init_db_with_retry(logger, attempts: int = 5, delay: float = 1.5) -> None:
	last_exc: Exception | None = None
	for attempt in range(1, attempts + 1):
		try:
			init_db()
			return
		except DBAPIError as exc:
			last_exc = exc
			logger.warning(
				"Database init attempt %s/%s failed (%s); disposing pool and retrying",
				attempt, attempts, exc.__class__.__name__,
			)
			engine.dispose()
			if attempt < attempts:
				time.sleep(delay)
	raise last_exc
```

### Lifespan integration

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
	logger = setup_logging()
	_init_db_with_retry(logger)
	yield
	from daan.knowledge_graph import close_kg_connection
	close_kg_connection()
```

### Why this matters

The knowledge graph is not stored in MySQL, but the application cannot serve graph, workflow, or publish APIs unless startup succeeds. This guard stabilizes the entire feature set under transient handshake failures.

---

## 10. Complete End-to-End Data Flow

### Full workflow and review loop

```text
1. User starts a workflow session
	   -> session directory created
	   -> session metadata available to workflow and graph instrumentation

2. Workflow agents run
	   -> outputs written to session_storage
	   -> graph instrumentation records session, run, agent runs, and artifacts

3. Action agents publish deterministic resources when applicable
	   -> reviewed output parsed into DesiredItem objects
	   -> existing resources read from knowledge graph
	   -> reconcile plan computed
	   -> MCP tools create / update / delete ADO work items
	   -> manifest written back to pipeline and graph

4. Refinement step runs
	   -> prior issues and feedback for same use case pulled from graph
	   -> refinement agent revises current output
	   -> refinement output persisted

5. Run-history UI loads graph-backed run summaries
	   -> user opens a run
	   -> run detail pulls session metadata, outputs, feedback, proposals, reports

6. User asks questions in run chat
	   -> graph timeline + issues + feedback + refinement state build context
	   -> grounded answer returned

7. User gives feedback in run chat
	   -> block-preserving refinement creates proposal drafts per agent
	   -> proposal files stored beside outputs
	   -> UI renders diff and waits for Keep / Discard

8. User keeps a proposal
	   -> output promoted
	   -> proposal removed
	   -> graph history updated to reflect new revision path
```

### Detailed publish flow

```text
Reviewed output
	-> parser scans balanced JSON or fallback markers
	-> DesiredItem list built with stable local keys
	-> existing published resources loaded from KG
	-> reconciler computes create, update, remove plan
	-> backend selected from MCP server config
	-> execute MCP work-item operations
	-> manifest resources returned
	-> removed keys purged from KG resource links
```

### Detailed chat flow

```text
POST /session-chat
	-> load session meta from graph
	-> classify message as question or feedback

Question path
	-> load session run timeline
	-> load recent use-case feedback and issues
	-> load quality report and refinement output
	-> assemble grounded answer prompt
	-> return answer only

Feedback path
	-> resolve current agent deliverables
	-> optionally target one agent
	-> run block-preserving refinement
	-> persist one proposal per affected agent
	-> return proposals to UI
```

---

## 11. Security, Multi-user, and Operational Notes

### Row-level user scoping

The graph is shared, but reads are scoped:

- normal users only see their own sessions and runs
- admins can view all sessions
- run-detail, session graph, and output access are guarded by ownership checks

### Embedded DB constraints

Kuzu is file-based and single-writer sensitive. This implementation handles that by:

- using a singleton process connection
- exposing a clear lock error
- allowing `KUZU_DB_PATH` override for environment-specific isolation

### Proposal safety model

Feedback chat is explicitly non-destructive:

- proposal drafts are stored separately from live output
- Keep is an explicit promotion step
- Discard is a clean delete
- unchanged sections remain untouched in block-preserving refinement

### Repo hygiene notes

Known operational callouts from this workstream:

- `service/.kuzu` and `data/knowledge_graph_db*` should not be tracked
- `config/mcp_config.yml` contains sensitive values and should be sanitized or moved to secrets storage
- startup logging around DB configuration should avoid leaking connection details

---

## 12. Files Changed Summary

| File | Change Area | Purpose |
|---|---|---|
| `service/daan/knowledge_graph/connection.py` | KG core | Singleton DB connection and path resolution |
| `service/daan/knowledge_graph/schema.py` | KG core | Graph schema definitions |
| `service/daan/knowledge_graph/kg_events.py` | KG core | Event writers for sessions, runs, feedback, resources |
| `service/daan/knowledge_graph/queries.py` | KG core | Run-history, detail, analytics, and feedback retrieval |
| `service/daan/knowledge_graph/workflow_instrumentation.py` | KG core | Best-effort instrumentation bridge |
| `service/daan/api/v1/endpoints/knowledge_graph.py` | KG API | Run history, run detail, session chat, proposal actions |
| `service/daan/agents/core/refinement_agent.py` | Workflow | Refinement and block-preserving edit agent |
| `service/daan/api/v1/endpoints/workflow.py` | Workflow | Refinement lifecycle and feedback-aware endpoints |
| `service/daan/flow/session_service.py` | Storage | Output persistence, feedback sequencing, proposals |
| `service/daan/publish/parser.py` | Publish | Parse desired publish state from reviewed output |
| `service/daan/publish/reconciler.py` | Publish | Compute create/update/remove plan |
| `service/daan/publish/service.py` | Publish | Execute deterministic MCP-backed sync |
| `service/daan/mcp_servers/ado_mcp_server.py` | Publish | ADO work-item MCP operations |
| `service/daan/flow/agent_runner.py` | Workflow / publish | Publish integration and resource persistence |
| `ui/src/app/[archetype]/run-history/page.tsx` | UI | Run-history modal, per-agent chat, proposal UX |
| `ui/src/app/[archetype]/planner-output/page.tsx` | UI | Planner-output integration and unified run detail |
| `ui/src/components/DiffView.tsx` | UI | Proposed-vs-current diff rendering |
| `ui/src/config/apiConfig.ts` | UI | Knowledge-graph endpoint builders |
| `service/daan/main.py` | Ops | Startup retry and KG shutdown hook |

---

## 13. Reviewer Reading Order

For a code walkthrough, this order is the most efficient:

1. [service/daan/knowledge_graph/workflow_instrumentation.py](../service/daan/knowledge_graph/workflow_instrumentation.py)
2. [service/daan/api/v1/endpoints/knowledge_graph.py](../service/daan/api/v1/endpoints/knowledge_graph.py)
3. [service/daan/flow/session_service.py](../service/daan/flow/session_service.py)
4. [service/daan/agents/core/refinement_agent.py](../service/daan/agents/core/refinement_agent.py)
5. [service/daan/publish/parser.py](../service/daan/publish/parser.py)
6. [service/daan/publish/service.py](../service/daan/publish/service.py)
7. [ui/src/app/[archetype]/run-history/page.tsx](../ui/src/app/[archetype]/run-history/page.tsx)
8. [service/daan/main.py](../service/daan/main.py)

---

**End of Document**  
Generated/updated: 2026-07-16  
Scope: Knowledge Graph + Deterministic Publish + Refinement + Run-History UI
