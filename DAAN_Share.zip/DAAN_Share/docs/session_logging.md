# Session Logging Implementation

## Overview

Session logging has been successfully implemented to save session-specific logs in individual session folders. This provides better organization and traceability for user sessions.

## What Was Implemented

### 1. **Path Consistency Fix**
- Fixed inconsistency between `logging.py` and `session_service.py` 
- Both now use `settings.SESSION_STORAGE_DIR` for consistent session storage paths

### 2. **Session-Aware Logging Classes**
- `SessionLogger`: Wrapper class that automatically adds `session_id` to all log records
- Enhanced `LoggingMixin`: Now supports session-aware logging via `get_session_logger(session_id)`

### 3. **Utility Functions**
- `get_session_logger(name, session_id)`: Get a session-aware logger
- `get_session_logger_for_id(session_id, name)`: Convenience function in session service

### 4. **Automatic Session Log Files**
- Logs with `session_id` attribute are automatically written to: `session_storage/{session_id}/session.log`
- System logs continue to go to both console and system log files

## Directory Structure

```
session_storage/
├── {session-id-1}/
│   ├── session.log          # ← Session-specific logs here
│   ├── inputs/
│   ├── agents/
│   └── ...other session files
├── {session-id-2}/
│   ├── session.log          # ← Another session's logs
│   └── ...
└── system logs/
    └── {timestamp}.log      # ← System-wide logs
```

## Usage Examples

### Basic Usage
```python
from daan.core.logging import get_session_logger

# Get session-aware logger
logger = get_session_logger("my_service", session_id="abc-123")

# These automatically go to session_storage/abc-123/session.log
logger.info("Processing user request")
logger.error("Something went wrong")
```

### With LoggingMixin
```python
from daan.core.logging import LoggingMixin

class MyService(LoggingMixin):
    def process(self, session_id: str):
        # System logs
        self.logger.info("Service started")
        
        # Session logs 
        session_logger = self.get_session_logger(session_id)
        session_logger.info("Processing session data")
```

### Session Service Integration
```python
from daan.flow.session_service import get_session_logger_for_id

# Easy access to session logger
logger = get_session_logger_for_id(session_id, "workflow_engine")
logger.info("Workflow step completed")
```

## Log Format

Session logs use the same format as system logs:
```
2026-04-20 13:58:26 | INFO | service_name | Log message | session_id='abc-123'
```

## Benefits

1. **✅ Organized Logs**: Each session has its own log file
2. **✅ Easy Debugging**: Quickly find logs for specific sessions  
3. **✅ Automatic**: No manual file handling required
4. **✅ Backward Compatible**: Existing logging continues to work
5. **✅ Configurable**: Uses existing `SESSION_STORAGE_DIR` setting

## Configuration

Session logging uses the existing configuration:
- `settings.SESSION_STORAGE_DIR`: Base directory for session storage
- `settings.LOG_LEVEL`: Controls logging level for both system and session logs

## Testing

Run the example to test session logging:
```bash
cd service
python daan/examples/session_logging_example.py
```

This will create test sessions and demonstrate all logging features.

## Migration Notes

- **No breaking changes**: Existing code continues to work unchanged
- **Optional enhancement**: Can gradually adopt session logging where needed
- **Automatic cleanup**: Session log files are cleaned up when sessions are deleted