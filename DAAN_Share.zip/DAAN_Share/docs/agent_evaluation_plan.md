# Standalone Agent Evaluation System - Implementation Plan

## Overview

Build a simple, independent evaluation toolkit that can assess any agent's outputs using code-based metrics (RAGAS-style) and LLM-as-judge. **Completely independent of DAAN framework** - purely file-based, portable, and works with any agent system.

## Input/Output

**Inputs:**
- Agent Input Files
- Agent output files (markdown, text, or PDF reports)
- Prompt files used by the agent
- Expected outputs for comparison

**Outputs:**
- Evaluation results (JSON, CSV)
- Summary report (Markdown)
- Comparison reports (for A/B testing)

## Implementation Steps

### Phase 1: Data Layer (3 steps - all can run in parallel)

1. **Create dataclass schemas** 
   - File: `service/agent_eval/schemas.py`
   - Models: `TestCase`, `EvalResult`, `MetricScore`
   - Features: JSON serialization, validation
   
2. **Build dataset loader**
   - File: `service/agent_eval/dataset_loader.py`
   - Supports: CSV and JSON formats
   - Validates: Required fields, file paths
   
3. **Create results writer**
   - File: `service/agent_eval/results_writer.py`
   - Outputs: JSON, CSV, Markdown
   - Features: Summary generation, pretty formatting

### Phase 2: Metrics (3 steps - can parallelize after Phase 1)

4. **Implement code-based metrics (RAGAS-style)**
   - File: `service/agent_eval/metrics/code_based.py`
   - Metrics:
     - Exact match (binary)
     - Fuzzy string matching (0-1 score)
     - BLEU score (translation quality)
     - ROUGE score (summarization quality)
     - Markdown structure validation (sections, headings)
     - Keyword presence (required terms)
   - Dependencies: Step 1

5. **Implement LLM-as-judge evaluator**
   - File: `service/agent_eval/metrics/llm_judge.py`
   - Evaluation dimensions (1-5 scale):
     - Factual correctness
     - Relevance to input
     - Completeness of answer
     - Clarity of presentation
   - Features: Rubric-based prompts, reasoning capture
   - LLM providers: OpenAI, Anthropic Claude
   - Dependencies: Step 1

6. **Create metrics registry**
   - File: `service/agent_eval/metrics/registry.py`
   - Features:
     - Unified `metric.evaluate(expected, actual) -> Score` interface
     - Metric registration and discovery
     - Weighted aggregation of multiple metrics
     - Configurable metric combinations
   - Dependencies: Steps 4, 5

### Phase 3: Evaluation Engine (3 steps - sequential)

7. **Build main evaluator**
   - File: `service/agent_eval/evaluator.py`
   - Features:
     - Loop over test cases
     - Load files (prompts, outputs, expected)
     - Run all selected metrics
     - Collect results with metadata
     - Parallel execution (ThreadPoolExecutor)
     - Per-test error handling (don't fail entire run)
     - Progress tracking
   - Dependencies: Steps 2, 6

8. **Add comparison tool**
   - File: `service/agent_eval/comparator.py`
   - Features:
     - Load two evaluation runs
     - Calculate metric deltas
     - Show improvements/regressions
     - Statistical significance testing (optional)
     - Generate comparison report
   - Dependencies: Step 7

9. **Create CLI interface**
   - File: `service/agent_eval/cli.py`
   - Commands:
     - `run` - Execute evaluation on dataset
     - `compare` - Compare two evaluation runs
     - `metrics` - List available metrics
     - `validate` - Check dataset format
   - Example usage:
     ```bash
     python -m agent_eval run --dataset tests.csv --output results/
     python -m agent_eval compare --run1 results/run1.json --run2 results/run2.json
     python -m agent_eval metrics --list
     ```
   - Dependencies: Steps 7, 8

### Phase 4: Polish (3 steps - can parallelize)

10. **Add file utilities**
    - File: `service/agent_eval/utils/file_utils.py`
    - Features:
      - PDF to text extraction (pypdf2 or pdfplumber)
      - Markdown parsing helpers
      - Prompt file loading (.txt, .md)
      - Text normalization utilities
    - Dependencies: None (parallel with all)

11. **Write tests**
    - Directory: `service/agent_eval/tests/`
    - Coverage:
      - Unit tests for each metric
      - Integration test with sample dataset
      - CLI command tests
      - Edge cases and error handling
    - Dependencies: Steps 1-9

12. **Create documentation**
    - File: `service/agent_eval/README.md`
    - Sections:
      - Quick start guide
      - Dataset format specification
      - Available metrics reference
      - Configuration options
      - Example evaluation workflows
      - API reference
    - Dependencies: None (parallel with 11)

## Directory Structure

```
service/agent_eval/
├── __init__.py
├── schemas.py              # TestCase, EvalResult dataclasses
├── dataset_loader.py       # Load CSV/JSON test datasets
├── results_writer.py       # Write JSON/CSV/markdown results
├── evaluator.py            # Main evaluation runner
├── comparator.py           # Compare two runs
├── cli.py                  # Command-line interface
├── metrics/
│   ├── __init__.py
│   ├── code_based.py      # String/structure metrics (RAGAS-style)
│   ├── llm_judge.py       # LLM-based quality scoring
│   └── registry.py        # Metric registration & orchestration
├── utils/
│   ├── __init__.py
│   └── file_utils.py      # PDF extraction, markdown parsing
├── tests/
│   ├── __init__.py
│   ├── test_metrics.py
│   ├── test_evaluator.py
│   └── fixtures/           # Sample test datasets
└── README.md              # Full documentation
```

## Test Dataset Format

### CSV Format (Recommended)

```csv
test_id,input_description,prompt_path,output_path,expected_output,metadata
test_001,"Analyze Q4 sales data","prompts/sales_analysis.txt","outputs/report_001.md","Revenue increased 15% YoY, profit margin improved","category=financial;priority=high"
test_002,"Summarize meeting notes","prompts/summarize.txt","outputs/report_002.md","Key decisions: approve budget, hire 2 engineers, launch product in Q2","category=operational"
test_003,"Create risk assessment","prompts/risk_analysis.txt","outputs/report_003.md","High risk: supply chain disruption; Medium risk: currency fluctuation","category=risk"
```

**Required Columns:**
- `test_id` - Unique identifier
- `output_path` - Path to agent's output file (relative or absolute)
- `expected_output` - Expected/reference output for comparison

**Optional Columns:**
- `input_description` - Human-readable description of the test
- `prompt_path` - Path to prompt file used
- `metadata` - Additional metadata (semicolon-separated key=value pairs)

### JSON Format (Alternative)

```json
{
  "test_cases": [
    {
      "test_id": "test_001",
      "input_description": "Analyze Q4 sales data",
      "prompt_path": "prompts/sales_analysis.txt",
      "output_path": "outputs/report_001.md",
      "expected_output": "Revenue increased 15% YoY, profit margin improved",
      "metadata": {
        "category": "financial",
        "priority": "high"
      }
    }
  ]
}
```

## Metrics Reference

### Code-Based Metrics (RAGAS-Style)

| Metric | Description | Range | Fast/Cheap |
|--------|-------------|-------|------------|
| **Exact Match** | Binary comparison: outputs match exactly | 0 or 1 | ✅ |
| **Fuzzy Match** | Similarity using Levenshtein distance | 0.0 - 1.0 | ✅ |
| **BLEU Score** | Precision-based n-gram overlap | 0.0 - 1.0 | ✅ |
| **ROUGE Score** | Recall-based n-gram overlap | 0.0 - 1.0 | ✅ |
| **Keyword Presence** | Required keywords found in output | 0.0 - 1.0 | ✅ |
| **Structure Validation** | Markdown sections, headings present | 0 or 1 | ✅ |

### LLM-as-Judge Metrics

| Dimension | Description | Range | Cost |
|-----------|-------------|-------|------|
| **Correctness** | Factual accuracy of information | 1-5 | 💰 |
| **Relevance** | How well output addresses input | 1-5 | 💰 |
| **Completeness** | Coverage of required information | 1-5 | 💰 |
| **Clarity** | Readability and presentation quality | 1-5 | 💰 |

Each LLM-as-judge metric includes:
- Numerical score (1-5)
- Reasoning explanation
- Configurable rubrics

### Metric Configuration

```python
# Example: Configure evaluation with weighted metrics
config = {
    "metrics": [
        {"name": "exact_match", "weight": 0.2},
        {"name": "bleu_score", "weight": 0.2},
        {"name": "llm_judge_correctness", "weight": 0.3},
        {"name": "llm_judge_completeness", "weight": 0.3}
    ],
    "llm_provider": "openai",
    "llm_model": "gpt-4"
}
```

## External Dependencies

Add to `requirements.txt`:

```
# Core
openai>=1.0.0                # For LLM-as-judge (OpenAI)
anthropic>=0.18.0           # For LLM-as-judge (Claude)

# Metrics
nltk>=3.8                   # For BLEU/ROUGE scores
rouge-score>=0.1.2          # ROUGE metric implementation
rapidfuzz>=3.0.0            # Fast fuzzy string matching

# File handling
pypdf2>=3.0.0               # PDF text extraction
pdfplumber>=0.10.0          # Alternative PDF extraction
markdown>=3.5.0             # Markdown parsing

# CLI
click>=8.1.0                # Command-line interface
rich>=13.0.0                # Pretty terminal output

# Utilities
pandas>=2.0.0               # CSV handling
python-dotenv>=1.0.0        # Environment variables
```

## Verification Steps

### Automated Tests

1. **Run unit tests:**
   ```bash
   pytest service/agent_eval/tests/ -v
   ```

2. **Run example evaluation:**
   ```bash
   python -m agent_eval run --dataset examples/test_cases.csv --output results/
   ```

3. **Verify output files:**
   - Check `results/run_TIMESTAMP.json` exists
   - Check `results/summary.md` exists
   - Validate JSON structure

### Manual Validation

1. **Create sample dataset:**
   - 3-5 test cases in CSV format
   - Include diverse scenarios
   - Mix of exact matches and variations

2. **Run evaluation:**
   ```bash
   python -m agent_eval run \
     --dataset examples/test_cases.csv \
     --output results/ \
     --metrics exact_match,bleu_score,llm_judge_correctness \
     --verbose
   ```

3. **Review results:**
   - Check summary markdown shows:
     - Overall score
     - Per-test breakdown
     - Metric distributions
     - Failed tests with reasons
   - Validate scores make sense

4. **Test comparison:**
   ```bash
   # Run evaluation with different prompts/outputs
   python -m agent_eval run --dataset tests_v1.csv --output results/v1/
   python -m agent_eval run --dataset tests_v2.csv --output results/v2/
   
   # Compare runs
   python -m agent_eval compare \
     --run1 results/v1/run_*.json \
     --run2 results/v2/run_*.json \
     --output results/comparison.md
   ```

5. **Verify comparison shows:**
   - Metric deltas (improved/regressed)
   - Statistical significance
   - Test-by-test differences

## Key Decisions

### 1. Standalone Architecture
- ✅ **No database** - All file-based (CSV, JSON, markdown)
- ✅ **No DAAN coupling** - Works with any agent system
- ✅ **Portable** - Can be moved to separate repository
- ✅ **Simple I/O** - Read from files, write to files

### 2. Metric Strategy
- **Code-based (50%)** - Fast, cheap, objective
  - Exact match, fuzzy match, BLEU, ROUGE
  - Structure validation, keyword presence
- **LLM-as-judge (50%)** - Flexible, subjective
  - Correctness, relevance, completeness, clarity
  - Configurable rubrics per use case

### 3. Execution Model
- **Parallel processing** - ThreadPoolExecutor for test cases
- **Error isolation** - One test failure doesn't break entire run
- **Progress tracking** - Show real-time progress
- **Configurable workers** - Default 4, user-configurable

### 4. Output Formats
- **JSON** - Machine-readable, structured data
- **CSV** - Spreadsheet-friendly, easy analysis
- **Markdown** - Human-readable summary reports
- **Comparison reports** - Side-by-side metric deltas

### 5. LLM Provider Support
- **Primary**: OpenAI (GPT-4, GPT-3.5)
- **Secondary**: Anthropic Claude (Claude 3 Opus, Sonnet)
- **Fallback**: Configurable via environment variables
- **Cost control**: Optional caching of LLM judgments

## Example Workflows

### Workflow 1: Basic Evaluation

```bash
# 1. Create test dataset
cat > tests.csv << EOF
test_id,output_path,expected_output
test_001,outputs/report_001.md,"Revenue grew 15% YoY"
test_002,outputs/report_002.md,"Hired 3 engineers"
test_003,outputs/report_003.md,"High risk identified"
EOF

# 2. Run evaluation
python -m agent_eval run \
  --dataset tests.csv \
  --output results/ \
  --metrics exact_match,bleu_score,llm_judge_correctness

# 3. View results
cat results/summary.md
```

### Workflow 2: A/B Testing (Compare Prompts)

```bash
# Version A: Original prompt
python -m agent_eval run \
  --dataset tests.csv \
  --output results/prompt_v1/

# Version B: Improved prompt
python -m agent_eval run \
  --dataset tests.csv \
  --output results/prompt_v2/

# Compare
python -m agent_eval compare \
  --run1 results/prompt_v1/run_*.json \
  --run2 results/prompt_v2/run_*.json \
  --output results/prompt_comparison.md

# Result shows which prompt performs better
```

### Workflow 3: Continuous Evaluation (CI/CD)

```yaml
# .github/workflows/agent_eval.yml
name: Agent Evaluation
on: [push, pull_request]

jobs:
  evaluate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Install dependencies
        run: pip install -r requirements.txt
      
      - name: Run agent evaluation
        run: |
          python -m agent_eval run \
            --dataset tests/regression_tests.csv \
            --output results/ \
            --metrics exact_match,bleu_score,llm_judge_correctness
      
      - name: Check pass threshold
        run: |
          python scripts/check_eval_threshold.py results/run_*.json --min-score 0.8
      
      - name: Upload results
        uses: actions/upload-artifact@v3
        with:
          name: evaluation-results
          path: results/
```

## Further Considerations

### 1. Metric Expansion
**Options:**
- A: Start minimal (exact match + LLM-judge) ✅ **Recommended**
- B: Include full BLEU/ROUGE suite from start
- C: Add domain-specific metrics as needed

**Decision:** Start minimal, add based on feedback

### 2. LLM Provider Support
**Options:**
- A: OpenAI only for MVP
- B: OpenAI + Anthropic ✅ **Recommended**
- C: Add local models via LiteLLM/Ollama

**Decision:** Support both OpenAI and Anthropic for flexibility

### 3. Parallel Execution
**Options:**
- A: Sequential only (simplest)
- B: ThreadPoolExecutor with configurable workers ✅ **Recommended**
- C: Async with asyncio (most complex)

**Decision:** ThreadPoolExecutor for good balance of simplicity and performance

### 4. Result Caching
**Options:**
- A: No caching for MVP ✅ **Recommended**
- B: File-based cache with hash keys
- C: Database-backed cache

**Decision:** No caching initially to keep it simple

### 5. PDF Support
**Options:**
- A: Markdown/text only
- B: Add PDF text extraction ✅ **Recommended**
- C: Full PDF parsing with layout analysis

**Decision:** Basic PDF-to-text extraction for agent reports

## Getting Started

### Minimal Example

1. **Install:**
   ```bash
   cd service/agent_eval
   pip install -r requirements.txt
   ```

2. **Create test case:**
   ```bash
   echo "test_id,output_path,expected_output" > test.csv
   echo "test_001,output.md,Hello World" >> test.csv
   echo "Hello World" > output.md
   ```

3. **Run evaluation:**
   ```bash
   export OPENAI_API_KEY="your-key-here"
   python -m agent_eval run --dataset test.csv --output results/
   ```

4. **View results:**
   ```bash
   cat results/summary.md
   ```

That's it! The system is designed to be simple and get out of your way.

## Timeline Estimate

| Phase | Steps | Estimated Time | Dependencies |
|-------|-------|----------------|--------------|
| Phase 1 | 1-3 | 1 day | None (parallel) |
| Phase 2 | 4-6 | 2 days | Phase 1 |
| Phase 3 | 7-9 | 2 days | Phases 1-2 |
| Phase 4 | 10-12 | 1 day | Phase 3 (testing) |
| **Total** | **12 steps** | **~6 days** | |

**Notes:**
- Assumes 1 developer working full-time
- Includes basic testing and documentation
- Does not include advanced features (caching, async, UI)

## Success Criteria

✅ **Functional:**
- Can load test datasets from CSV/JSON
- Evaluates outputs using code-based metrics
- Evaluates outputs using LLM-as-judge
- Generates readable summary reports
- Compares two evaluation runs
- Handles errors gracefully

✅ **Quality:**
- All unit tests pass
- Integration test completes successfully
- Metrics produce reasonable scores
- Documentation is clear and complete

✅ **Performance:**
- Evaluates 10 test cases in <60 seconds (excluding LLM calls)
- Parallel execution works correctly
- No memory leaks or resource issues

✅ **Usability:**
- CLI is intuitive and well-documented
- Error messages are helpful
- Output formats are easy to consume
- Works on Windows, Mac, Linux
