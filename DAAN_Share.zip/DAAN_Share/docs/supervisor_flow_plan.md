# Supervisor Flow Architecture Plan

## Data Hierarchy Diagram

```mermaid
graph TD
    subgraph "Data Structure"
        AT[ArchType]
        UC[Use Case]
        AG[Agents]
        SA[dynamic_agents]
        AA[ActionAgents]
        
        AT -->|contains| UC
        UC -->|defines| AG
        AG -->|type: dynamic_agent| SA
        AG -->|type: ActionAgent| AA
    end
    
    subgraph "dynamic_agents (LLM Processing)"
        SA1[Agent 1: Analysis]
        SA2[Agent 2: Generation]
        SA3[Agent 3: Validation]
        SA1 -->|DAG| SA2
        SA2 -->|DAG| SA3
    end
    
    subgraph "ActionAgents (External Actions)"
        AA1[Agent 4: Jira Publisher]
        AA2[Agent 5: Trello Publisher]
    end
    
    SA --> SA1
    AA --> AA1
    AA --> AA2
    SA3 -.->|depends_on| AA1
    SA3 -.->|depends_on| AA2
```

## Supervisor Flow Diagram

```mermaid
flowchart TB
    subgraph "User Actions"
        U1[Select ArchType]
        U2[Select Use Case]
        U3[Upload Files]
        U4[Review & Feedback]
        U5[Approve/Proceed]
    end
    
    subgraph "Supervisor Flow"
        INIT[INITIALIZED]
        PLAN[PLANNED]
        AGENTS[AGENTS_DONE]
        ACTIONS[ACTIONS_DONE]
        REPORT[REPORT_DONE]
        DONE[COMPLETED]
    end
    
    subgraph "Core Agents"
        PL[Planner Agent<br/>Python Script]
        RP[Reporter Agent<br/>ADK Agent]
        QA[Quality Check Agent<br/>ADK Agent]
    end
    
    subgraph "Dynamic Agents"
        SUB[dynamic_agents<br/>Sequential Pipeline]
        ACT[ActionAgents<br/>Sequential Pipeline]
    end
    
    U1 --> U2 --> U3 --> INIT
    INIT -->|plan| PL
    PL -->|agents + context + DAG| PLAN
    PLAN -->|run_agents| SUB
    SUB --> AGENTS
    
    AGENTS -->|feedback max 3x| U4
    U4 -->|rerun dynamic_agents| SUB
    
    AGENTS -->|proceed| U5
    U5 --> ACT
    ACT --> ACTIONS
    
    ACTIONS --> RP
    RP -->|report| REPORT
    REPORT --> QA
    QA -->|quality assessment| DONE
```

## Agent Execution Flow

```mermaid
sequenceDiagram
    participant UI as UI
    participant SV as Supervisor
    participant PL as Planner
    participant SA as dynamic_agents
    participant AA as ActionAgents
    participant RP as Reporter
    participant QA as QualityCheck

    UI->>SV: init(archtype, usecase, files)
    SV-->>UI: session_id
    
    UI->>SV: plan(session_id)
    SV->>PL: plan(usecase_details, files, agents)
    PL-->>SV: {agents, dag, context_map}
    SV-->>UI: plan_result
    
    UI->>SV: run_agents(session_id)
    SV->>SA: execute dynamic_agents (DAG order)
    SA-->>SV: dynamic_agent_outputs
    SV-->>UI: agent_outputs
    
    loop Feedback (max 3)
        UI->>SV: feedback(session_id, text, files?)
        SV->>SA: re-execute dynamic_agents with feedback
        SA-->>SV: updated_outputs
        SV-->>UI: agent_outputs
    end
    
    UI->>SV: proceed(session_id)
    SV->>AA: execute ActionAgents (DAG order)
    AA-->>SV: action_outputs
    
    SV->>RP: generate_report(all_outputs)
    RP-->>SV: report
    
    SV->>QA: assess_quality(report)
    QA-->>SV: quality_assessment
    
    SV-->>UI: {action_outputs, report, quality_assessment}
```

## Sample Data Specifications

### Sample Use Case (from UseCases.csv)

```json
{
  "usecaseid": "UC_001",
  "name": "User Story Generation",
  "task": "Generate user stories from questionnaire responses and metadata",
  "role": "Business Analyst",
  "premium": "false",
  "agents_involved": "AGENT_1:UserStoryGeneration|dynamic_agent;AGENT_2:PostUserStories_Jira|ActionAgent;AGENT_3:PostUserStories_Trello|ActionAgent",
  "flow_of_agents": "AGENT_1 -> AGENT_2, AGENT_3",
  "dag": "AGENT_1>AGENT_2>AGENT_3"
}
```

**Field Descriptions:**
| Field | Description |
|-------|-------------|
| `usecaseid` | Unique identifier for the use case |
| `name` | Human-readable name |
| `task` | Description of what the use case accomplishes |
| `role` | Required user role to access this use case |
| `agents_involved` | Semicolon-separated list of agents with format `ID:Name\|Type` |
| `dag` | Execution order using `>` separator |

### Sample Agent Specifications (from Agents.csv)

#### dynamic_agent Example (LLM Processing)

```json
{
  "agent_id": "AGENT_1",
  "agent_name": "UserStoryGeneration(Questionnaire)",
  "role": "Business Analyst",
  "agent_type": "dynamic_agent",
  "inputs": "{questionnaire_context}, {metadata_mapping_context}, {project_context(optional)}",
  "actions": "1) Read questionnaire and metadata context; 2) Generate epic and user stories in markdown; 3) Ensure output markers and structure validations are satisfied",
  "prompt_file_path": "data/ArchTypes/Customer Proposed Use Cases/prompts/UserStoryGeneration(Questionnaire).prompt.md",
  "prompt": "You are a Business Analyst agent...(loaded from file)",
  "output": "user_story_draft_markdown",
  "output_validators": "epic_marker_presence|story_marker_presence|story_structure_minimum|validation_criteria_check",
  "mcp_tools": "[]",
  "local_tools": "[]",
  "depends_on": "[]"
}
```

#### ActionAgent Example (External Actions)

```json
{
  "agent_id": "AGENT_2",
  "agent_name": "PostUserStories_Jira",
  "role": "Business Analyst",
  "agent_type": "ActionAgent",
  "inputs": "{user_story_draft_markdown}",
  "actions": "1) Accept markdown from AGENT_1; 2) Validate markdown is present; 3) Invoke JiraStoryPublisher local tool; 4) Return Jira publish result",
  "prompt_file_path": "data/ArchTypes/Customer Proposed Use Cases/prompts/PostStoriesToJira.prompt.md",
  "prompt": "You are a Jira Publishing agent...(loaded from file)",
  "output": "jira_publish_result",
  "output_validators": "publish_result_status_check",
  "mcp_tools": "[jira-mcp-server]",
  "local_tools": "JiraStoryPublisher.post_stories_to_jira",
  "depends_on": "[AGENT_1]"
}
```

**Agent Field Descriptions:**
| Field | Description |
|-------|-------------|
| `agent_id` | Unique identifier (e.g., AGENT_1, AGENT_2) |
| `agent_name` | Descriptive name for the agent |
| `agent_type` | `dynamic_agent` (LLM processing) or `ActionAgent` (external actions) |
| `inputs` | Expected input variables in `{variable}` format |
| `actions` | Step-by-step description of what the agent does |
| `prompt` | The actual LLM prompt (loaded from prompt_file_path) |
| `output` | Output key name for storing result |
| `output_validators` | Pipe-separated validators to check output |
| `mcp_tools` | MCP server tools available to this agent |
| `local_tools` | Local Python tools (e.g., JiraStoryPublisher) |
| `depends_on` | List of agent IDs that must complete first |

### Agent Types Comparison

| Aspect | dynamic_agent | ActionAgent |
|--------|-----------|-------------|
| **Purpose** | LLM processing, analysis, generation | External actions, API calls, publishing |
| **Feedback** | Supports feedback loop (max 3) | No feedback loop |
| **Tools** | Usually no external tools | Uses MCP/local tools |
| **Example** | Story generation, validation | Jira/Trello publishing |
| **Execution** | Runs during `run_agents()` | Runs during `proceed()` |

### DAG (Directed Acyclic Graph) Execution

The `dag` field defines execution order:

```
dag: "AGENT_1>AGENT_2>AGENT_3"
```

Parsed as:
```
AGENT_1 (dynamic_agent)
    ↓
AGENT_2 (ActionAgent) ← depends_on: [AGENT_1]
    ↓
AGENT_3 (ActionAgent) ← depends_on: [AGENT_1]
```

**Execution Flow:**
1. dynamic_agents execute first (AGENT_1)
2. User reviews output, provides feedback if needed
3. User clicks Proceed
4. ActionAgents execute (AGENT_2, AGENT_3)
5. Reporter generates summary
6. Quality Check assesses report

## File Structure

```
service/daan/
├── agents/
│   └── core/
│       ├── __init__.py
│       ├── planner_agent.py       # Python script - maps context to agents
│       ├── reporter_agent.py      # ADK agent - generates report
│       └── quality_check_agent.py # ADK agent - quality assessment
├── flow/
│   ├── supervisor.py              # Main orchestrator (entry point)
│   └── dynamic_flow_builder/
│       └── dynamic_adk_flow.py    # Already updated
```

## Supervisor Flow State Machine

```
┌─────────────────┐
│  INITIALIZED    │ ← User selects archtype + usecase + uploads files
└────────┬────────┘
         │ plan()
         ▼
┌─────────────────┐
│    PLANNED      │ ← Planner returns agents + context + DAG
└────────┬────────┘
         │ run_agents()
         ▼
┌─────────────────┐
│  AGENTS_DONE    │ ← All dynamic_agents executed, results available
└────────┬────────┘
         │
    ┌────┴────┐
    │         │
feedback   proceed()
(max 3)       │
    │         │
    ▼         │
  rerun       │
dynamic_agents    │
  only        │
    │         │
    └────►────┘
              │
              ▼
        ┌─────────────────┐
        │ ACTIONS_DONE    │ ← ActionAgents executed (no feedback loop)
        └────────┬────────┘
                 │
                 ▼
        ┌─────────────────┐
        │ REPORT_DONE     │ ← Reporter agent generates report
        └────────┬────────┘
                 │
                 ▼
        ┌─────────────────┐
        │   COMPLETED     │ ← Quality Assessment done
        └─────────────────┘
```

> **Note:** Feedback loop applies **only to dynamic_agents**. Once user clicks Proceed, Action Agents run without feedback.

## User Journey

1. **User selects ArchType** (from UI, calls existing API)
2. **User selects Use Case** (from UI, gets use case details from API)
3. **User uploads files** for the use case
4. **Plan** - Planner agent maps context to each agent in the use case
5. **Run dynamic_agents** - Execute all dynamic_agents, return results to UI
6. **Feedback Loop** (optional, max 3 times) - **dynamic_agents only**
   - User provides additional files + feedback text
   - Re-run dynamic_agents with feedback
7. **Proceed/Approve** - User approves the dynamic_agent output
8. **Run Action Agents** - Execute all ActionAgents in DAG (no feedback)
9. **Generate Report** - Reporter agent summarizes all agent outputs
10. **Generate Quality Assessment** - Quality assessor evaluates the report

## API Contract

| Method | Input | Output |
|--------|-------|--------|
| `init(archtype, usecase_details, files)` | Archtype, UseCase from API, uploaded files | Session ID |
| `plan()` | - | `{agents: [...], dag: [...], context_map: {...}}` |
| `run_agents()` | - | `{agent_outputs: {agent_id: output}}` (dynamic_agents only) |
| `feedback(feedback_text, files?)` | User feedback, optional files | `{agent_outputs: {...}, feedback_count: n}` (re-runs dynamic_agents only, max 3) |
| `proceed()` | - | `{action_outputs, report, quality_assessment}` (runs ActionAgents, then Report + QA) |

## Core Agent Placeholders

| Agent | File | Type | Function | Input | Output (Mock) |
|-------|------|------|----------|-------|---------------|
| **Planner** | `planner_agent.py` | Python script | `plan()` | `usecase_details, files, agents` | `{agents: [...], dag: "A1>A2>A3", context_map: {...}}` |
| **Reporter** | `reporter_agent.py` | ADK Agent | `create_reporter_agent()` | `all_agent_outputs` | Markdown report |
| **QualityCheck** | `quality_check_agent.py` | ADK Agent | `create_quality_check_agent()` | `report` | Quality assessment with scores |

## Supervisor Class Design

```python
class FlowState(Enum):
    INITIALIZED = "initialized"
    PLANNED = "planned"
    AGENTS_DONE = "agents_done"      # dynamic_agents completed
    ACTIONS_DONE = "actions_done"    # ActionAgents completed
    REPORT_DONE = "report_done"
    COMPLETED = "completed"

class SupervisorFlow:
    def __init__(self):
        self.sessions: dict[str, FlowSession] = {}
    
    def init(archtype, usecase_details, files) -> str:
        """Initialize a new flow session"""
        
    def plan(session_id) -> PlanResult:
        """Run planner agent to map context to agents"""
        
    def run_agents(session_id) -> AgentOutputs:
        """Execute all dynamic_agents in sequence (not ActionAgents)"""
        
    def feedback(session_id, feedback_text, files?) -> AgentOutputs:
        """Re-run dynamic_agents with user feedback (max 3 times)"""
        
    def proceed(session_id) -> FinalResult:
        """Run ActionAgents, then generate report and quality assessment"""
```

## Session Data Structure

```python
@dataclass
class FlowSession:
    id: str
    archtype: str
    usecase_details: dict
    files: list[str]
    state: FlowState
    
    # Planning output
    agents: list[dict]           # Agent configs from planner
    dynamic_agents: list[dict]   # Filtered dynamic_agents only
    action_agents: list[dict]    # Filtered ActionAgents only
    dag: str                     # Execution order
    context_map: dict[str, str]  # agent_id -> context
    
    # dynamic_agent execution (supports feedback loop)
    dynamic_agent_outputs: dict[str, str]   # agent_id -> output
    feedback_count: int = 0             # Max 3
    feedback_history: list[str] = field(default_factory=list)
    
    # ActionAgent execution (no feedback)
    action_outputs: dict[str, str]      # agent_id -> output
    
    # Final outputs
    report: str = ""
    quality_assessment: str = ""
```

## Implementation Order

1. **Create placeholder core agents** (`agents/core/`) ✅ DONE
   - `__init__.py` - Package exports
   - `planner_agent.py` - Python function `plan()` with mock output
   - `reporter_agent.py` - ADK agent `create_reporter_agent()` + mock `generate_report_mock()`
   - `quality_check_agent.py` - ADK agent `create_quality_check_agent()` + mock `assess_quality_mock()`

2. **Build SupervisorFlow class** in `supervisor.py`
   - Session management
   - State machine transitions
   - Method implementations
   - Separate dynamic_agent and ActionAgent execution paths

3. **Wire up dynamic agent execution** using `dynamic_adk_flow.py`
   - `create_pipeline_agent()` for dynamic_agents (with feedback support)
   - `create_pipeline_agent()` for ActionAgents (no feedback)

4. **Add state persistence** (in-memory dict for now, can be upgraded to Redis/DB later)

## Dependencies

- `google.adk.agents.Agent` - For Reporter and QualityAssessor
- `google.adk.agents.sequential_agent.SequentialAgent` - For pipeline execution
- `daan.agents.dynamic_builders.dynamic_adk_agent.create_adk_agent`
- `daan.flow.dynamic_flow_builder.dynamic_adk_flow.create_pipeline_agent`
