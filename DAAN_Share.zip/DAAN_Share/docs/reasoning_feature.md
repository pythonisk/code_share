# DAAN 6 — Reasoning Streaming Feature

End-to-end reference for the "Thinking Steps" reasoning capture pipeline that
surfaces model reasoning (extended thinking / o-series reasoning /
gemini thinking) in the Studio UI.

---

## 1. Purpose

Show each agent's internal reasoning ("thinking") in real time in the Studio
Agent card so users can see **what** the model is doing, **why** it made
certain choices, and gain trust in the output.

Supports every reasoning-capable model on our stack via a **profile-based
routing layer** (`service/daan/llm/reasoning_kwargs.py`). One helper decides,
per model, which vendor-specific parameter shape to emit:

| Profile              | Models                                      | Parameter shape emitted                                 |
|----------------------|---------------------------------------------|---------------------------------------------------------|
| `anthropic_extended` | Claude Haiku 4.5, Sonnet 5, Opus 5          | `thinking: {type: enabled\|adaptive, …}` + `output_config.effort` |
| `openai_reasoning`   | o1 / o3 / o4 / GPT-5 series                 | `reasoning_effort: low\|medium\|high`                    |
| `gemini_thinking`    | Gemini 2.5 Pro/Flash, Gemini 3+             | `reasoning_effort: low\|medium\|high`                    |
| `none`               | gpt-4o, gpt-4, gpt-3.5, gemini-1.5, mistral, llama, etc. | *(nothing — reasoning params stripped)* |

Within `anthropic_extended`, the *mode* is model-aware:

| Model             | Mode        | Anthropic payload                                    |
|-------------------|-------------|------------------------------------------------------|
| `claude-haiku-4-5`| `enabled`   | `thinking: {type: enabled, budget_tokens: N}`        |
| `claude-sonnet-5` | `adaptive`  | `thinking: {type: adaptive}` + `output_config.effort`|
| `claude-opus-5`   | `adaptive`  | same as Sonnet 5                                     |

Profile resolution priority (highest → lowest):

1. Explicit profile in the caller-supplied `reasoning` dict.
2. `core_agents.<component>.reasoning_profile` override in `llm_config.yml`.
3. Name inference against the resolved model id (24 regex patterns).
4. Sibling `reasoning_profile` on the provider config block.
5. Provider default (`anthropic_extended` for LiteLLM proxy; `none` for direct
   OpenAI/Azure/Google).

---

## 2. Architecture at a glance

```
┌────────────────────────────────────────────────────────────────────────┐
│                          BACKEND (Python / FastAPI)                    │
│                                                                        │
│   dynamic_adk_agent.py                                                 │
│         │ builds Agent + attaches reasoning callbacks                  │
│         ▼                                                              │
│   agent_runner.py                                                      │
│         │ Runner.run_async(RunConfig(streaming_mode=SSE))              │
│         │ per partial event ─► _emit_partial_event_to_bus(bus, ...)    │
│         ▼                                                              │
│   core/observers/reasoning_observer.py                                 │
│         ├─ ReasoningEventBus  (append-only log, monotonic seq)         │
│         ├─ get_or_create_bus / get_bus / discard_bus                   │
│         └─ build_reasoning_callbacks() ─► ADK before_*/after_* hooks   │
│                                                                        │
│   llm/thinking_capture_logger.py                                       │
│         └─ CustomLogger on litellm.callbacks                           │
│             ├─ log_stream_event   → emit `thought` (if hook fires)     │
│             └─ log_success_event  → fallback thought + model_call_end  │
│                                                                        │
│   api/v1/endpoints/workflow.py                                         │
│         ├─ POST /workflow/run-next-stage       (drives one stage)      │
│         │       └─ emits agent_complete / stage_complete / final       │
│         └─ GET  /workflow/session/{sid}/reasoning-events?after=N       │
│                    (polled every 500 ms by the UI)                     │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘

                              ▲
                      GET every 500 ms
                              │
┌────────────────────────────────────────────────────────────────────────┐
│                          FRONTEND (Next.js / React)                    │
│                                                                        │
│   StudioView.tsx                                                       │
│         ├─ state reasoningByAgent: Record<agentId, Event[]>            │
│         ├─ pollReasoningEvents() ─► fetch(after=cursor) loop           │
│         └─ renders the Reasoning chip inside each agent card           │
│                                                                        │
│   components/reasoning/ReasoningPanel.tsx                              │
│         └─ renders event rows; merges consecutive `thought` deltas;    │
│            drops `token`, `agent_start`, `model_call_start`            │
│                                                                        │
│   lib/reasoningStream.ts                                               │
│         └─ event types, EVENT_SYMBOL map, feature flag                 │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Event schema

Emitted by the bus and streamed to the UI. `seq` is a monotonic per-bus
counter; the polling client passes `after=<last_seq>` to fetch only new
events.

```jsonc
{
  "v": 1,
  "type": "thought" | "action" | "observation" | "token"
        | "agent_start" | "model_call_start" | "model_call_end"
        | "agent_complete" | "stage_complete" | "final" | "error",
  "seq": 42,
  "ts": 1725543210.482,
  "session_id": "abc123",
  // Optional payload fields depending on `type`:
  "agent_id":   "AGENT_6",
  "agent_name": "DatabricksNotebookGeneration",
  "text":       "Let me analyze the input context…",
  "token_count": 12,
  "tool":       "connect_to_databricks",
  "args":       {"workspace_path": "/Workspace/…"},
  "result":     {"status": "success"},
  "message":    "…"           // only on `error`
}
```

| Symbol | Type              | Meaning                                          |
|--------|-------------------|--------------------------------------------------|
| 🧠     | `thought`         | Model reasoning text (streamed / summarized)     |
| 🛠️     | `action`          | Tool / function call invoked by the model        |
| 👁️     | `observation`     | Result of a tool call                            |
| ✍️     | `token`           | Answer-text delta (hidden in UI; Responses tab)  |
| 🚀     | `agent_start`     | ADK `before_agent_callback` fired                |
| 📡     | `model_call_start`| `before_model_callback`                          |
| 📥     | `model_call_end`  | LiteLLM `log_success_event` (true end of call)   |
| ✅     | `agent_complete`  | Emitted by workflow endpoint per ran agent       |
| 🏁     | `stage_complete`  | Emitted by workflow endpoint at stage end        |
| 🎯     | `final`           | Emitted by workflow endpoint with full result    |
| ⚠️     | `error`           | Emitted on failures                              |

---

## 4. The reasoning bus

**File**: `service/daan/core/observers/reasoning_observer.py`

### `ReasoningEventBus`
- Per-session append-only event log, keyed by the DAAN session_id (base, no
  `__AGENT_N` suffix).
- `emit(event_type, payload)` — appends `{v, type, seq, ts, session_id, …}`.
- `events_since(after_seq)` — returns all events with `seq > after_seq`.
- `close()` — marks closed; the TTL sweep (`_DEFAULT_TTL_SECONDS = 900`)
  eventually purges idle buses.

### Registry
```python
_BUSES: dict[str, ReasoningEventBus] = {}   # session_id -> bus
get_or_create_bus(sid)  # create if absent, reuse if closed
get_bus(sid)            # None if absent
discard_bus(sid)        # close + remove
```

### Callback factory
`build_reasoning_callbacks(session_id, agent_id, agent_name)` returns ADK
callback kwargs:

| Callback                | Emits                                     |
|-------------------------|-------------------------------------------|
| `before_agent_callback` | `agent_start`                             |
| `before_model_callback` | `model_call_start`                        |
| `after_model_callback`  | no-op (streaming handles content)         |
| `after_tool_callback`   | `observation` (with `tool`, `result`)     |
| `after_agent_callback`  | no-op stub (workflow endpoint emits `agent_complete`) |

---

## 5. Where events come from

### 5.1 ADK partial events → `agent_runner._emit_partial_event_to_bus()`

**File**: `service/daan/flow/agent_runner.py`

With `RunConfig(streaming_mode=StreamingMode.SSE)`, ADK's `Runner.run_async`
yields per-chunk partial events. Each event's `content.parts` is inspected:

```python
for part in parts:
    if part.thought:                     # Haiku's `enabled` mode surfaces
        bus.emit("thought", {...})       #   reasoning here → live streaming
    elif part.function_call:
        bus.emit("action", {...})
    elif part.text:
        bus.emit("token", {...})         # regular answer chunk (UI hides it)
```

The reasoning bus key is the **base** session id (stripped of the ADK
runner's `__AGENT_N` suffix):

```python
real_session_key = str(session_id).split("__", 1)[0]
reasoning_bus = get_bus(real_session_key)
```

This runs in **both** loops in `agent_runner.py`:
- `_run_pipeline_async` — multi-agent stage runner.
- `run_single_agent_async` — single-agent execution (feedback / rerun).

### 5.2 LiteLLM CustomLogger → `thinking_capture_logger.py`

**File**: `service/daan/llm/thinking_capture_logger.py`

Registered on `litellm.callbacks` at import time. Two paths:

| Hook                          | Purpose                                            |
|-------------------------------|----------------------------------------------------|
| `async_log_stream_event`      | Would emit `thought` per LiteLLM chunk. On LiteLLM 1.93 proxy mode this hook is not invoked — the code is kept for future SDK upgrades. |
| `async_log_success_event`     | Fires once at true call completion. Extracts reasoning from the final response and emits a single `thought` event **if no thought was already emitted since the last `model_call_start`**. Then emits `model_call_end`. |

Session routing uses the `session:<sid>` tag stamped by `build_llm_tags` in
`extra_body.metadata.tags`. `_session_id_from_kwargs()` extracts it and
strips the `__AGENT_N` suffix so it matches the bus key.

Handles three response shapes:
- Real reasoning text → normal `thought` emission.
- Signature-only "redacted" thinking → `[reasoning captured but redacted by
  proxy]` indicator.
- No thinking → nothing emitted (model didn't reason).

Multi-agent guard: `_bus_has_thought_since_last_call_start(sid)` walks the
bus backwards to the most recent `model_call_start`, so an earlier agent's
thought doesn't suppress the current agent's success-hook fallback.

### 5.3 Terminal events → `workflow.py::run_next_stage_route`

**File**: `service/daan/api/v1/endpoints/workflow.py`

At the end of every `POST /workflow/run-next-stage`:

```python
for ran_aid in outputs.keys():
    bus.emit("agent_complete", {"agent_id": ran_aid, ...})
bus.emit("stage_complete", {"stage_index": ..., "ran_agents": [...]})
bus.emit("final", {"result": <serialized RunNextStageResponse>})
```

These are what turn the UI's `● Reasoning in progress` chip into
`Reasoning completed in N steps` after the run.

---

## 6. The transport: **polling**, not SSE

We tried both. Here's why polling won.

### 6.1 SSE — the road not taken

We initially built an SSE variant: `POST /workflow/run-next-stage/stream`
with `text/event-stream` responses and a fetch-based EventSource-style
client. It broke reliably on our target stack:

- Chrome on Windows sometimes dropped the connection after 2-3 seconds.
- Corporate proxies and the Next.js dev server buffered the stream, causing
  the client to time out and abort the underlying agent run.
- Debugging in the browser was awkward — `net::ERR_HTTP2_PROTOCOL_ERROR`
  masked the real cause.

The endpoint is still in the repo for reference (`run_next_stage_stream_route`
+ `run_next_stage_stream_get_route`), but the UI does not call it.

### 6.2 Polling — what we ship

The UI polls a plain JSON endpoint:

```http
GET /api/workflow/session/{session_id}/reasoning-events?after=<last_seq>
Authorization: Bearer <jwt>

200 OK
{
  "events": [ {"seq": 12, "type": "thought", ...}, ... ],
  "closed": false,
  "cursor": 27
}
```

- Idempotent, cacheable JSON — no proxy weirdness, no CORS-preflight streaming
  quirks.
- Each poll returns only events with `seq > after`. Client passes the last
  received `cursor` on the next call.
- Endpoint is a plain sync FastAPI handler; FastAPI runs it in a threadpool
  so it doesn't block the event loop while the agent run is in progress.

**Frontend polling loop** (StudioView.tsx, inside `handleStageRun`):

```ts
const reasoningAbort = new AbortController();
const pollReasoningEvents = (async () => {
  // Preflight: sync cursor to current bus high-water mark
  // (avoids replaying prior stages' events into this stage's panel).
  let cursor = -1;
  try {
    const pre = await fetch(`${url}?after=-1`, { signal, headers });
    const preData = await pre.json();
    if (typeof preData.cursor === 'number') cursor = preData.cursor;
  } catch { /* fall back to -1 */ }

  while (!reasoningAbort.signal.aborted) {
    const res = await fetch(`${url}?after=${cursor}`, { signal, headers });
    if (res.ok) {
      const data = await res.json();
      if (data.events.length > 0) {
        setReasoningByAgent(prev => { /* append by agent_id */ });
        cursor = data.cursor;
      }
    }
    await new Promise(r => setTimeout(r, 500));    // ← 500 ms interval
  }
})();

try {
  stageRes = await runNextStage(sid, ...);
} finally {
  setTimeout(() => reasoningAbort.abort(), 1500); // 1.5s tail after stage returns
}
```

### 6.3 Timing constants

| Constant           | Value    | Why                                             |
|--------------------|----------|-------------------------------------------------|
| Poll interval      | **500 ms** | Fast enough to feel live; low enough not to hammer the server. Empirically ~2 polls/sec matches ADK's partial-event cadence for streaming models. |
| Tail after stage   | **1.5 s** | Keeps polling after `runNextStage` returns so the final `agent_complete` / `stage_complete` / `final` events (emitted synchronously with the response) still get picked up. |
| Preflight cursor   | one call | Fetch `?after=-1` once, use `data.cursor` as the starting point. Prevents earlier agents' events from bleeding into the current agent's panel. |
| Bus TTL sweep      | 900 s    | Idle buses auto-close so we don't leak memory across abandoned sessions. |

### 6.4 Why not shorter than 500 ms?

- Auth check + FastAPI routing overhead per request is ~5-10 ms; 200 ms polls
  would work but generate 5×/sec load with no perceptual benefit.
- Each streaming chunk from the model arrives every ~200-800 ms anyway, so
  500 ms polls catch most chunks within a single tick.

---

## 7. Model-aware thinking-mode selection

**File**: `service/daan/llm/providers/litellm_provider.py`

Anthropic's thinking API takes two shapes and models accept only one:

```python
def _resolve_thinking_mode(config_mode: str, model_name: str) -> str:
    name = (model_name or "").lower()
    if "haiku" in name:                                        # Haiku 4.5
        return "enabled"
    if any(m in name for m in ("opus-5", "sonnet-5",
                                "opus-4-6", "opus-4-7",
                                "sonnet-4-6")):                # 5.x, late 4.x
        return "adaptive"
    return config_mode                                          # respect config
```

Then in `create_model`:

```python
if mode == "adaptive":
    model_kwargs["thinking"] = {"type": "adaptive"}
    model_kwargs["output_config"] = {"effort": effort}     # low / medium / high
    model_kwargs["max_tokens"] = max(max_tokens, 8192)
else:
    model_kwargs["thinking"] = {"type": "enabled", "budget_tokens": budget}
    model_kwargs["max_tokens"] = max(max_tokens, budget + 4096)
model_kwargs["temperature"] = 1.0                          # Anthropic requirement
```

A single `config/llm_config.yml` block covers all three models — the code
auto-corrects the mode per model at build time:

```yaml
litellm:
  reasoning:
    enabled: true
    mode: adaptive          # ignored for Haiku; auto-forced to `enabled`
    effort: high            # used when adaptive
    budget_tokens: 8000     # used when enabled
    expose_thoughts: true
```

---

## 8. Per-agent model override (UI dropdown)

Users can pick a specific LiteLLM model per agent in the Studio's Run
Configuration panel.

### 8.1 UI flow (`ui/src/components/StudioView.tsx`)

```ts
const [modelOverrides, setModelOverrides] =
  useState<Record<string, string>>({});
// user picks a model → modelOverrides[agent.id] = "claude-haiku-4-5"

// Sent on Build Context:
await buildContext(sid, ucId, archetype, uploadedFileCountRef.current,
                   modelOverrides);
```

### 8.2 Backend flow (`workflow.py::context_map_route`)

`ContextMapRequest` accepts `model_overrides: dict[str, str]`. Right after
`ContextMapper.run_detailed` returns the enriched agents:

```python
for a in enriched_agents:
    aid = str(a.get("agent_id") or "").strip()
    if override := model_overrides.get(aid):
        a["model"] = override.strip()

# Rewrite context_map_output.json so the rehydration path picks it up.
disk_map = read_context_map_output(sid) or {}
disk_map["agents"] = enriched_agents
write_context_map_output(sid, disk_map)
```

### 8.3 Read at runtime

`dynamic_adk_agent.get_agent_model(agent_config)` reads `model`, `llm_model`,
or `model_id` from the agent config. Passed to
`create_litellm_model(provider_name, tags=..., model_name=<override>,
reasoning=...)` which threads it through
`LiteLLMProvider.create_model(model_name, ...)`.

---

## 9. UI rendering

### 9.1 The chip (`StudioView.tsx`)

Between the agent card header and the tab bar:

```
● Reasoning in progress ›            ← while runningAgentId === agent.id
Reasoning completed in 12 steps ›    ← after run; click to collapse
```

- Auto-expanded during a run; user can toggle after completion.
- `stepCount` filter excludes `token`, `agent_start`, `model_call_start`
  so the number reflects meaningful steps.

### 9.2 The panel (`components/reasoning/ReasoningPanel.tsx`)

- Filters out `token`, `agent_start`, `model_call_start`.
- Coalesces consecutive same-agent `thought` chunks into one accumulating
  row (streaming deltas can be tiny).
- Compound React key `${seq}-${type}-${index}` prevents duplicate-key crashes
  if the same seq ever comes through twice.
- `max-h-[280px]` scroll container with auto-scroll to newest event.

### 9.3 Session isolation

Every session-reset code path clears `reasoningByAgent` and
`thinkingCollapsed`:
- `startFreshStudioSession` — New Session button.
- Build Context click.
- 5.0 → studio mode transition.
- `usecaseId` URL param change.
- `handleDeleteCurrentSession`.
- `viewSession` (loading a past session from History).

---

## 10. Files touched by the feature

| File                                                                             | Role                                              |
|----------------------------------------------------------------------------------|---------------------------------------------------|
| `service/daan/core/observers/reasoning_observer.py`                              | Bus + callback factory + registry                 |
| `service/daan/llm/thinking_capture_logger.py`                                    | LiteLLM CustomLogger (thought + model_call_end)   |
| `service/daan/llm/providers/litellm_provider.py`                                 | Model-aware thinking-mode selection               |
| `service/daan/llm/llm_provider.py`                                               | `create_litellm_model(model_name=..., reasoning=...)` glue |
| `service/daan/flow/agent_runner.py`                                              | SSE streaming + `_emit_partial_event_to_bus`      |
| `service/daan/agents/dynamic_builders/dynamic_adk_agent.py`                      | Wires `build_reasoning_callbacks` into every Agent |
| `service/daan/api/v1/endpoints/workflow.py`                                      | `run-next-stage` bus priming + terminal events + polling endpoint |
| `ui/src/lib/reasoningStream.ts`                                                  | Event types, glyph map, feature flag              |
| `ui/src/components/reasoning/ReasoningPanel.tsx`                                 | Panel rendering                                   |
| `ui/src/components/StudioView.tsx`                                               | Polling loop, chip, per-agent model dropdown, session resets |
| `ui/src/services/studioApi.ts`                                                   | `buildContext(model_overrides)` + type re-exports |
| `ui/src/services/llmApi.ts`                                                      | Fetch model list from `/api/llm/models`           |
| `ui/src/config/apiConfig.ts`                                                     | `LIST_LLM_MODELS`, `GET_DEFAULT_LLM_MODEL`        |
| `config/llm_config.yml`                                                          | `litellm.reasoning` block                         |

---

## 11. Diagnostic scripts

Under `scripts/`:

- `probe_proxy_thinking.py` — non-streaming + streaming probe against LiteLLM proxy.
- `probe_proxy_thinking2.py` — measures stream cadence and thinking content.
- `probe_anthropic_direct.py` — bypasses proxy, calls Anthropic directly.
- `probe_azure_anthropic.py` — bypasses LiteLLM proxy, calls Azure AI
  Foundry's Anthropic passthrough (`genaicoe.services.ai.azure.com/anthropic/v1/messages`).

Backend also exposes `GET /api/workflow/reasoning-diagnostics` for a live
snapshot of active buses and module counters.

---

## 12. Known constraints / limits

- **LiteLLM 1.93 proxy** does not invoke `log_stream_event`. Thoughts arrive
  via one of two paths: (a) ADK partial events with `part.thought=True` for
  Haiku's `enabled` mode → truly live streaming, or (b) LiteLLM's
  `log_success_event` fallback for Sonnet/Opus adaptive mode → single
  summary thought at end-of-run.
- **Azure AI Foundry Anthropic passthrough** must have "thinking passthrough"
  enabled on each model deployment. If disabled, the response returns
  signature-only thinking blocks and the panel shows the redacted indicator.
- **Redacted-thinking indicator** is emitted by
  `_emit_thinking_indicator` when we detect empty-text-with-signature
  thinking blocks.

---

## 13. Verification checklist

1. **Backend up**: no `ImportError`, `🧠 ThinkingCaptureLogger registered on
   litellm.callbacks` in startup log.
2. **Fresh session**: pick use case → Build Context → select model per agent
   → click Continue.
3. **Backend log** shows:
   ```
   Applied per-agent model overrides: AGENT_6=claude-haiku-4-5
   🧠 LiteLLM reasoning enabled model=claude-haiku-4-5 mode=enabled ...
   Using litellm model: claude-haiku-4-5
   ```
4. **UI**: Reasoning chip appears (`● Reasoning in progress ›`) as soon as
   the model call starts.
5. Polling requests hit `GET .../reasoning-events?after=<N>` every 500 ms
   with steadily advancing cursor (visible in access log).
6. **After completion**: chip shows `Reasoning completed in N steps ›`;
   expand shows `🧠 …reasoning…`, `📥 model response received`, `✅ agent
   complete`, `🏁 stage complete`, `🎯 answer ready`.
