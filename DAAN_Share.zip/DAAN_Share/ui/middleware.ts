import { withAuth } from "next-auth/middleware";

export default withAuth(
  function middleware(req) {
    // Add any additional middleware logic here
    console.log("Middleware executed for:", req.nextUrl.pathname);
  },
  {
    callbacks: {
      authorized: ({ token, req }) => {
        // Allow access to auth routes without authentication
        if (req.nextUrl.pathname.startsWith("/auth/")) {
          return true;
        }

        // Allow the demo showcase to remain publicly viewable (linked from login)
        if (req.nextUrl.pathname === "/demo-showcase") {
          return true;
        }

        // For all other routes (including "/" and "/overview"), require authentication
        return !!token;
      },
    },
  }
);

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api/auth (authentication routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    "/((?!api/auth|_next/static|_next/image|favicon.ico|public).*)",
  ],
};