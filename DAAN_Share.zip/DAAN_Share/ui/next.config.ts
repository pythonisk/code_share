
// next.config.ts
import type { NextConfig } from 'next';
import path from 'path';

const BACKEND_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';

const nextConfig: NextConfig = {
  reactCompiler: true,
  output: 'standalone', // Enable standalone output for Docker
  outputFileTracingRoot: path.resolve(__dirname, '..'),
  turbopack: {
    root: path.resolve(__dirname, '..'),
  },
  async rewrites() {
    return [
      {
        // Proxy all /api/** calls to the FastAPI backend.
        // Excludes /api/auth/** which is handled by NextAuth internally.
        source: '/api/:path((?!auth).*)',
        destination: `${BACKEND_URL}/api/:path*`,
      },
    ];
  },
};

export default nextConfig;

