"use client";

import type { ReactNode } from "react";
import { useRouter } from "next/navigation";

type AuthShowcaseShellProps = {
  children: ReactNode;
  cardWidthClassName?: string;
};

const authHighlights = [
  "Planner & dynamic agents — decompose a use case into executable steps.",
  "Reviewer & Reporter — quality gates and stakeholder-ready output.",
  "Prompt Catalog — reusable, versioned prompts across archetypes.",
  "Guardrails & observability — every run traceable end to end.",
];

export function AuthShowcaseShell({ children, cardWidthClassName = "max-w-lg" }: AuthShowcaseShellProps) {
  const router = useRouter();

  return (
    <div
      className="h-screen overflow-hidden bg-white lg:grid lg:grid-cols-[minmax(0,1.05fr)_minmax(560px,1fr)]"
      style={{ fontFamily: "var(--font-regular, 'esklarheit-regular', 'ESKlarheitGrotesk')" }}
    >
      <aside
        className="relative hidden h-screen overflow-hidden lg:flex lg:flex-col lg:justify-between"
        style={{
          padding: "56px 60px",
          color: "#FFFFFF",
          background:
            "radial-gradient(circle at 18% 22%, rgba(255,255,255,.16), transparent 45%)," +
            "radial-gradient(circle at 78% 78%, rgba(200,60,25,.32), transparent 50%)," +
            "linear-gradient(140deg, #E8452E 0%, #D93B28 55%, #B23A12 100%)",
        }}
      >
        <div
          aria-hidden
          style={{
            position: "absolute",
            insetBlockStart: "-20%",
            insetInlineEnd: "-25%",
            inlineSize: "70%",
            blockSize: "140%",
            background:
              "repeating-linear-gradient(115deg, rgba(255,255,255,.06) 0 1px, transparent 1px 26px)," +
              "repeating-linear-gradient(25deg, rgba(255,255,255,.05) 0 1px, transparent 1px 26px)",
            transform: "rotate(8deg)",
            pointerEvents: "none",
          }}
        />

        <button
          type="button"
          className="relative z-[1] cursor-pointer text-left"
          style={{ display: "flex", alignItems: "center", gap: "14px" }}
          onClick={() => router.push("/overview")}
          aria-label="Go to overview"
          title="Go to overview"
        >
          <div
            style={{
              inlineSize: "52px",
              blockSize: "52px",
              borderRadius: "16px",
              display: "grid",
              placeItems: "center",
              background: "linear-gradient(135deg, #FF5E4F 0%, #FF8A5C 100%)",
              boxShadow: "0 10px 26px rgba(255, 94, 79, .35)",
              fontWeight: 700,
              fontSize: "20px",
              letterSpacing: ".5px",
              color: "#2A0808",
            }}
          >
            <span>D</span>
          </div>
          <div>
            <p
              style={{
                fontSize: "26px",
                fontWeight: 700,
                letterSpacing: "3px",
                margin: 0,
              }}
            >
              DAAN
            </p>
            <p
              style={{
                fontSize: "12.5px",
                color: "rgba(255,255,255,.88)",
                letterSpacing: ".6px",
                margin: 0,
              }}
            >
              Data &amp; AI Automation Network
            </p>
          </div>
        </button>

        <div className="relative z-[1]">
          <h1
            style={{
              fontSize: "40px",
              lineHeight: 1.18,
              margin: "36px 0 16px",
              fontWeight: 650,
              maxInlineSize: "16ch",
            }}
          >
            Agentic 
            <br/>
            automation for{" "}
            <em style={{ fontStyle: "normal", color: "#FFC7A3",fontWeight: 650  }}>Data &amp; AI</em> delivery.
          </h1>
          <p
            style={{
              fontSize: "16px",
              lineHeight: 1.65,
              color: "rgba(255,255,255,.92)",
              maxInlineSize: "55ch",
              margin: "0 0 30px",
            }}
          >
            A spec-driven network of planning, action and review agents that turns your delivery artefacts into governed, auditable outcomes — without a rebuild for every new use case.
          </p>

          <ul
            style={{
              listStyle: "none",
              margin: 0,
              padding: 0,
              display: "grid",
              gap: "14px",
              maxInlineSize: "55ch",
            }}
          >
            {authHighlights.map((highlight) => {
              const [title, description] = highlight.split(" — ");

              return (
                <li
                  key={highlight}
                  style={{
                    display: "flex",
                    gap: "12px",
                    alignItems: "flex-start",
                    fontSize: "14.5px",
                    color: "#FFFFFF",
                  }}
                >
                  <span
                    style={{
                      inlineSize: "9px",
                      blockSize: "9px",
                      borderRadius: "50%",
                      marginBlockStart: "6px",
                      flex: "0 0 auto",
                      background: "linear-gradient(135deg, #FF5E4F, #FF8A5C)",
                      boxShadow: "0 0 0 4px rgba(255, 94, 79, .15)",
                    }}
                  />
                  <span>
                    <strong>{title}</strong>
                    {description ? ` — ${description}` : ""}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>

        <div className="relative z-[1]">
          <p
            style={{
              fontSize: "12.5px",
              color: "white",
              margin: 0,
            }}
          >
            LTM · Data &amp; Analytics — GenAI CoE
          </p>
        </div>
      </aside>

      <section className="relative flex h-screen items-center justify-center overflow-hidden bg-[linear-gradient(180deg,#fff2ef_0%,#ffe1db_100%)] px-4 py-4 sm:px-6 lg:px-10 lg:py-6">
        <div className="absolute right-0 top-0 hidden h-[42rem] w-[42rem] translate-x-1/4 -translate-y-1/4 rounded-full bg-[radial-gradient(circle,rgba(255,94,79,0.16)_0%,rgba(255,94,79,0.08)_32%,transparent_68%)] lg:block" />
        <div className="absolute bottom-0 right-0 hidden h-[26rem] w-[26rem] translate-x-1/4 translate-y-1/4 rounded-full bg-[radial-gradient(circle,rgba(18,72,160,0.12)_0%,transparent_70%)] lg:block" />
        <div className={`relative z-10 w-full max-h-full ${cardWidthClassName}`}>
          {children}
        </div>
      </section>
    </div>
  );
}