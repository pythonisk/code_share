"use client";

import { useSession, signIn, signOut } from "next-auth/react";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function AuthButton() {
  const { data: session, status } = useSession();
  const [loading, setLoading] = useState(false);
  const [storedUsername, setStoredUsername] = useState("");
  const router = useRouter();

  useEffect(() => {
    if (typeof window === "undefined") {
      return;
    }

    const username =
      localStorage.getItem("daan_username") ||
      localStorage.getItem("username") ||
      "";
    setStoredUsername(username);
  }, [session]);

  const handleSignIn = async () => {
    router.push("/auth/signin");
  };

  const handleSignOut = async () => {
    setLoading(true);
    try {
      // Sign out from NextAuth which will clear the session and redirect
      await signOut({ 
        callbackUrl: "/",
        redirect: true 
      });
    } catch (error) {
      console.error("Sign-out error:", error);
      // Fallback: force redirect to signin page
      window.location.href = "/";
    } finally {
      setLoading(false);
    }
  };

  if (status === "loading") {
    return (
      <div className="flex items-center space-x-2">
        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
        <span>Loading...</span>
      </div>
    );
  }

  if (session) {
    const displayName = storedUsername || session.user?.name || session.user?.email || "User";

    return (
      <div className="flex items-center gap-3">
        <button
          onClick={handleSignOut}
          disabled={loading}
          className="w-10 h-10 flex items-center justify-center text-white rounded-full hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
          style={{ backgroundColor: '#4b0082' }}
          title={loading ? "Signing out..." : "Sign Out"}
        >
          {loading ? (
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
          ) : (
            <svg 
              className="w-5 h-5" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" 
              />
            </svg>
          )}
        </button>
        <span className="text-sm font-medium text-slate-900 dark:text-white whitespace-nowrap">
          {displayName}
        </span>
      </div>
    );
  }

  return (
    <button
      onClick={handleSignIn}
      className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
    >
      Sign In
    </button>
  );
}