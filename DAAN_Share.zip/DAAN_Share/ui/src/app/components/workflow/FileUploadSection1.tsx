'use client';

import { useCallback, useState } from 'react';

interface FileUploadSectionProps {
  onFileUpload: (files: File[]) => void;
  uploadedFiles: File[];
}

export default function FileUploadSection({ onFileUpload, uploadedFiles }: FileUploadSectionProps) {
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    onFileUpload(files);
  }, [onFileUpload]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      onFileUpload(files);
    }
  }, [onFileUpload]);

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleProceed = () => {
    if (uploadedFiles.length > 0) {
      // Handle proceed logic here
      console.log('Processing files:', uploadedFiles);
    }
  };

  return (
    <div className="p-6" style={{marginTop:'2%'}}>
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">File Upload</h3>
        <p className="text-gray-600 text-sm" style={{paddingBottom:'1%'}}>
          Upload relevant files (code, data, documentation)
        </p>
      </div>

      {/* Drag and Drop Area */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          border-2 border-dashed rounded-lg p-6 transition-colors h-20
          ${isDragOver 
            ? 'border-purple-400 bg-purple-50' 
            : 'border-gray-300 hover:border-gray-400'
          }
        `}
      >
        <div className="flex items-center justify-between h-full pr-4">
          <div className="flex items-center space-x-3 gap-2" style={{paddingLeft:'4px'}}>
            <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center pl-4">
              <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 12 12">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
              </svg>
            </div>
            
            <div className="text-left">
              <p className="text-sm font-medium text-gray-700">
                Drag and drop files here
              </p>
              <p className="text-xs text-gray-500">
                Limit 200MB per file • CSV, TXT, XLSX, PDF, DOCX
              </p>
            </div>
          </div>

          <input
            type="file"
            multiple
            onChange={handleFileSelect}
            accept=".csv,.txt,.xlsx,.pdf,.docx"
            className="hidden"
            id="file-upload"
          />
          
          <label
            htmlFor="file-upload"
            className="inline-flex items-center justify-center px-6 py-2 border border-gray-300 rounded-md text-xs font-medium text-gray-700 bg-white hover:bg-gray-50 cursor-pointer transition-colors min-w-[100px] mr-4"
          >
            Browse files
          </label>
        </div>
      </div>

      {/* Uploaded Files List */}
      {uploadedFiles.length > 0 && (
        <div className="mt-6">
          <h4 className="text-sm font-medium text-gray-700 mb-3">Uploaded Files ({uploadedFiles.length})</h4>
          <div className="space-y-2">
            {uploadedFiles.map((file, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded flex items-center justify-center">
                    <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{file.name}</p>
                    <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    const newFiles = uploadedFiles.filter((_, i) => i !== index);
                    onFileUpload(newFiles.slice(uploadedFiles.length)); // This is a simplified approach
                  }}
                  className="text-red-500 hover:text-red-700"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex justify-end space-x-4 mt-8">
        <button
          onClick={handleProceed}
          disabled={uploadedFiles.length === 0}
          className={`
            px-6 py-2 rounded-lg font-medium transition-colors
            ${uploadedFiles.length > 0
              ? 'bg-purple-600 text-white hover:bg-purple-700'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }
          `}
        >
          Proceed
        </button>
      </div>
    </div>
  );
}