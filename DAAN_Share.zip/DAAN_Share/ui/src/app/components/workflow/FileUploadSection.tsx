
'use client';

import { useRef, useState, useEffect } from 'react';
import { API_CONFIG, API_ENDPOINTS, getBaseUrl } from '@/config/apiConfig';

type FileUploadSectionProps = {
  onUploaded?: (payload: any) => void;
  archetype?: string;
  role?: string;
};

// Design tokens
const MAX_MB = 500;
const ACCEPT = '.csv,.txt,.xlsx,.pdf,.docx,.xls,.doc';

type PlannerAgentSummary = {
  title?: string;
  complete?: boolean;
  processedRelevant: number;
  total: number;
  agents: string[];
  notes?: string[];
};

export default function FileUploadSection({ onUploaded, archetype, role }: FileUploadSectionProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [isHydrated, setIsHydrated] = useState(false);
  const [drag, setDrag] = useState(false);
  const [busy, setBusy] = useState(false);
  const [username, setUsername] = useState('testuser');
  const [password, setPassword] = useState('testpassword');
  const [token, setToken] = useState<string | null>(null);
  const [summary, setSummary] = useState<PlannerAgentSummary | null>(null);
  const [expanded, setExpanded] = useState(true);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const allowed = ACCEPT.split(',').map(s => s.replace('.', '').toLowerCase());

  // Set hydrated state on client mount
  useEffect(() => {
    setIsHydrated(true);
  }, []);

  const addFiles = (incoming: FileList | null) => {
    if (!incoming) return;
    const arr = Array.from(incoming);
    const errors: string[] = [];
    const valid: File[] = [];
    arr.forEach(f => {
      const ext = (f.name.split('.').pop() || '').toLowerCase();
      if (!allowed.includes(ext)) errors.push(`❌ ${f.name}: type not allowed`);
      else if (f.size > MAX_MB * 1024 * 1024) errors.push(`❌ ${f.name}: exceeds ${MAX_MB}MB`);
      else valid.push(f);
    });
    setFiles(prev => [...prev, ...valid]);
    if (errors.length) alert(errors.join('\n'));
  };

  const removeFile = (i: number) =>
    setFiles(prev => prev.filter((_, idx) => idx !== i));

  const authenticateUser = async () => {
    try {
      const response = await fetch(`${getBaseUrl()}${API_ENDPOINTS.AUTH}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username,
          password,
        }),
      });

      if (!response.ok) {
        throw new Error(`Authentication failed (${response.status})`);
      }

      const data = await response.json();
      console.log('token"',data)
      setToken(data.access_token || data.token); // Handle different token response formats
      return data.access_token || data.token;
    } catch (error: any) {
      throw new Error(error.message || 'Authentication failed');
    }
  };

  const toStringArray = (val: any): string[] => {
    if (!val) return [];
    if (Array.isArray(val)) {
      const names = val
        .map((v) => {
          if (typeof v === 'string') return v;
          if (v && typeof v === 'object') return v.name || v.agent_name || v.title || v.label || '';
          return '';
        })
        .filter(Boolean);
      return names;
    }
    if (typeof val === 'string') return [val];
    return [];
  };

  const extractAgents = (source: any): string[] => {
    if (!source || typeof source !== 'object') return [];
    const candidates = [
      source.agents,
      source.included_agents,
      source.dynamic_agents,
      source.agent_list,
      source.display_metadata?.agents,
      source.display_metadata?.included_agents,
      source.summary?.agents,
      source.summary?.included_agents,
      source.planner_summary?.agents,
      source.planner?.agents,
    ];
    for (const c of candidates) {
      const arr = toStringArray(c);
      if (arr.length) return arr;
    }
    if (Array.isArray(source?.planner?.dynamic_agents)) {
      const arr = toStringArray(source.planner.dynamic_agents);
      if (arr.length) return arr;
    }
    return [];
  };

  const extractCounts = (source: any): { processedRelevant?: number; total?: number } => {
    const tryKeys = (obj: any): { processedRelevant?: number; total?: number } => {
      if (!obj || typeof obj !== 'object') return {};
      const processed =
        obj.processed_relevant ??
        obj.processedRelevant ??
        obj.relevant_processed ??
        obj.relevantCount ??
        obj.relevant ??
        undefined;
      const total =
        obj.total ??
        obj.total_agents ??
        obj.total_dynamic_agents ??
        obj.dynamic_agents_total ??
        obj.count ??
        obj.agents_count ??
        undefined;
      return {
        processedRelevant: typeof processed === 'number' ? processed : undefined,
        total: typeof total === 'number' ? total : undefined,
      };
    };

    const pools = [source, source.summary, source.planner_summary, source.display_metadata, source.planner];
    for (const p of pools) {
      const r = tryKeys(p);
      if (r.processedRelevant !== undefined || r.total !== undefined) return r;
    }

    const agents = extractAgents(source);
    if (agents.length) return { processedRelevant: agents.length, total: agents.length };
    return {};
  };

  const extractTitle = (source: any): string | undefined => {
    const title =
      source?.summary?.title ||
      source?.planner_summary?.title ||
      source?.display_metadata?.title ||
      source?.title ||
      undefined;
    return typeof title === 'string' ? title : undefined;
  };

  const extractNotes = (source: any): string[] | undefined => {
    const notes =
      source?.summary?.notes ||
      source?.planner_summary?.notes ||
      source?.display_metadata?.notes ||
      source?.notes ||
      undefined;
    const arr = toStringArray(notes);
    return arr.length ? arr : undefined;
  };

  const isComplete = (source: any, counts: { processedRelevant?: number; total?: number }): boolean => {
    const status =
      source?.workflow_state ||
      source?.summary?.status ||
      source?.planner_summary?.status ||
      source?.status ||
      '';
    const s = String(status).toLowerCase();
    if (s.includes('complete') || s.includes('completed') || s === 'done' || s === 'success') return true;
    if (counts.processedRelevant !== undefined && counts.total !== undefined) {
      return counts.processedRelevant >= counts.total;
    }
    return false;
  };

  const derivePlannerSummary = (archetypeJson: any, plannerData: any): PlannerAgentSummary => {
    const primary = (plannerData && typeof plannerData === 'object' ? plannerData : null) || archetypeJson || {};

    const counts = extractCounts(primary);
    const agents = extractAgents(primary);
    const title = extractTitle(primary) || 'Planner Agent Summary';
    const notes = extractNotes(primary) || ['All agents were successfully processed with relevant context!'];
    const complete = isComplete(archetypeJson, counts) || isComplete(primary, counts);

    const processedRelevant = counts.processedRelevant ?? agents.length ?? 0;
    const total = counts.total ?? agents.length ?? processedRelevant;

    return { title, complete, processedRelevant, total, agents, notes };
  };

  const upload = async () => {
    try {
      setBusy(true);

      // Show a placeholder summary
      setSummary({
        title: 'Planner Agent Summary',
        complete: false,
        processedRelevant: 0,
        total: 0,
        agents: [],
        notes: ['Uploading files and starting workflow… fetching planner output.'],
      });

      // Authenticate to get the token
      const authToken = await authenticateUser();
      if (!authToken) {
        throw new Error('Failed to get authentication token');
      }

      // First, upload the files to the server
      if (files.length > 0) {
        const formData = new FormData();
        files.forEach((file) => {
          formData.append('files', file);
        });

        console.log('Uploading files:', files.map(f => f.name));
        
        const uploadRes = await fetch(`${getBaseUrl()}${API_ENDPOINTS.UPLOAD_FILES}`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${authToken}`,
          },
          body: formData,
        });

        if (!uploadRes.ok) {
          const errorText = await uploadRes.text();
          throw new Error(`File upload failed (${uploadRes.status}): ${errorText}`);
        }

        const uploadResult = await uploadRes.json();
        console.log('File upload response:', uploadResult);
      }

      // Prepare payload based on uploaded files
      const fileList = files.map((f) => f.name).join(', ');
      const archetypePayload = {
        archetype_name: archetype || 'Data Pipeline',
        archetype_role: role || 'Data Engineer',
        file_list: fileList,
      };

      console.log('API Payload:', archetypePayload);
      console.log('Archetype prop:', archetype);
      console.log('Role prop:', role);

      // Call Archetype API
      const res = await fetch(`${getBaseUrl()}${API_ENDPOINTS.ARCHETYPE}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify(archetypePayload),
      });

      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`Archetype API failed (${res.status}): ${errorText}`);
      }

      const json = await res.json();
      console.log('Archetype API response:', json);

      // Try to read planner file via full_path if available
      let plannerData: any = null;
      const fullPath: string | undefined = json?.planner_file?.full_path;
      if (fullPath) {
        try {
          const normalizedPath = fullPath.replace(/\\/g, '/');
          const fileUrl = normalizedPath.startsWith('http')
            ? normalizedPath
            : `${getBaseUrl()}/${normalizedPath.replace(/^\/+/, '')}`;

          const plannerFileResponse = await fetch(fileUrl, {
            method: 'GET',
            headers: { Authorization: `Bearer ${authToken}` },
          });

          if (plannerFileResponse.ok) {
            const ct = plannerFileResponse.headers.get('content-type') || '';
            plannerData = ct.includes('application/json')
              ? await plannerFileResponse.json()
              : await plannerFileResponse.text();
            console.log('Planner file content:', plannerData);
          } else {
            console.warn('Failed to read planner file:', plannerFileResponse.status);
          }
        } catch (error) {
          console.error('Error reading planner file:', error);
        }
      }

      // Combine data and emit to parent
      const combinedData = {
        archetypeResponse: json,
        plannerFileContent: plannerData,
        timestamp: new Date().toISOString(),
        fullPath: json.planner_file?.full_path || null,
        plannerFileName: json.planner_file?.original_file || null,
        workflowState: json.workflow_state || null,
        displayMetadata: json.display_metadata || null,
        token: authToken // Include the auth token for subsequent API calls
      };

      console.log('Combined data for planner output:', combinedData);
      onUploaded?.(combinedData);

      // Derive Planner Agent Summary from API response
      const derived = derivePlannerSummary(json, plannerData);

      // Fallback to keep UI useful when backend omits fields
      if (!derived.agents.length) {
        derived.agents = [
          'DDL Conversion Agent',
          'Incremental Load Agent',
          'Historical Load Agent',
          'Data Quality & Lineage Agent',
          'Report Migration Scope Agent',
          'BI Report Update Agent',
        ];
        derived.processedRelevant = derived.agents.length;
        derived.total = derived.agents.length;
        derived.complete = true;
      }

      setSummary(derived);
    } catch (e: any) {
      // Show an error summary instead of hiding the panel
      setSummary({
        title: 'Planner Agent Summary',
        complete: false,
        processedRelevant: 0,
        total: 0,
        agents: [],
        notes: [e?.message || 'Workflow failed to start'],
      });
      alert(e?.message || 'Workflow failed to start');
    } finally {
      setBusy(false);
    }
  };

  // ✅ Guard: render nothing on server, only after client hydration
  if (!isHydrated) {
    return null;
  }

  return (
    <div className="w-full p-6 mt-4" style={{marginTop:'2%'}}>
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">File Upload</h3>
        <p className="text-gray-600 text-sm pt-4 pb-6" style={{paddingBottom:'1%'}}>
          Upload relevant files (code, data, documentation)
        </p>
      </div>

      {/* Drag and Drop Area */}
      <div
        className={`
          border-2 border-dashed rounded-2xl p-3 transition-all w-full cursor-pointer shadow-sm
          ${drag 
            ? 'border-purple-400 bg-purple-50 shadow-lg ring-4 ring-purple-200' 
            : 'border-gray-300 bg-gray-50 hover:border-gray-400'
          }
        `}
        role="button"
        tabIndex={0}
        onDragEnter={(e) => { e.preventDefault(); setDrag(true); }}
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
        onDragLeave={(e) => { e.preventDefault(); setDrag(false); }}
        onDrop={(e) => { e.preventDefault(); setDrag(false); addFiles(e.dataTransfer.files); }}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') inputRef.current?.click(); }}
        onClick={() => inputRef.current?.click()}
        aria-label="Drag and drop files here or browse files"
      >
        <div className="flex items-center justify-between gap-4 h-16">
          <div className="flex items-center gap-3" style={{paddingLeft:'4px'}}>
            <div className="h-8 w-10 flex items-center justify-center bg-white border border-gray-300 rounded-2xl text-gray-500 shadow-sm">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
              </svg>
            </div>
            
            <div>
              <p className="text-sm font-semibold text-gray-800">
                Drag and drop files here
              </p>
              <p className="text-xs text-gray-500">
                Limit {MAX_MB}MB per file • CSV, TXT, XLSX, PDF, DOCX
              </p>
            </div>
          </div>

          <button
            type="button"
            style={{marginRight:'16px'}}
            className="h-8 w-26 inline-flex items-center justify-center px-4 py-2 bg-white border border-gray-300 rounded-md text-gray-700 text-sm font-medium shadow-md hover:bg-gray-50 focus:outline-none focus:ring-3 focus:ring-purple-300 transition-colors mr-4"
            onClick={(e) => { e.stopPropagation(); inputRef.current?.click(); }}
          >
            Browse files
          </button>

          <input
            ref={inputRef}
            type="file"
            multiple
            accept={ACCEPT}
            className="hidden"
            onChange={(e) => addFiles(e.target.files)}
          />
        </div>

        {/* Hidden input (triggered by Browse or key) */}
        <input
          ref={inputRef}
          type="file"
          multiple
          accept={ACCEPT}
          hidden
          onChange={(e) => addFiles(e.target.files)}
        />
      </div>

      {/* Uploaded Files List */}
      {files.length > 0 && (
        <div className="mt-6" style={{marginTop:'2%'}}>
          <h4 className="text-sm font-medium text-gray-700 mb-3">Uploaded Files ({files.length})</h4>
          <div className="space-y-2" style={{marginTop:'1%'}}>
            {files.map((file, index) => (
              <div key={`${file.name}-${index}`} className="flex items-center justify-between p-3 bg-white rounded-xl">
                <div className="flex items-center gap-4 space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded flex items-center justify-center">
                    <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{file.name}</p>
                    <p className="text-xs text-gray-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => removeFile(index)}
                  className="w-8 h-8 flex items-center justify-center text-red-500 hover:text-red-700 hover:bg-red-50 rounded-full transition-colors"
                  title="Remove file"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex justify-start space-x-4 mt-8">
        <button
          onClick={upload}
          className={`
            px-8 py-3 font-semibold text-sm rounded-md shadow-lg transition-all min-w-[120px] h-10
            ${files.length > 0 && !busy
              ? 'text-white cursor-pointer'
              : 'text-white cursor-not-allowed opacity-50 pointer-events-none'
            }
          `}
          style={{
            backgroundColor: '#4b0082',
            marginTop:'2%'
          }}
        >
          {busy ? 'Processing...' : 'Start Workflow'}
        </button>
      </div>

{/* ===== Planner Agent Summary (directly under Start Workflow) ===== */}
      {summary && (
        <section className="plannerPanel" aria-live="polite">
          {/* Collapsible header with status */}
          <button
            type="button"
            className="collapseHeader"
            onClick={() => setExpanded((v) => !v)}
            aria-expanded={expanded}
            aria-controls="planner-content"
          >
            <span className={`chevron ${expanded ? 'chevron--down' : 'chevron--right'}`} aria-hidden="true">
              ▾
            </span>
            <span className="headerTick" aria-hidden="true">
              ✔
            </span>
            <span className="headerText">Planner Agent: {summary.complete ? 'Complete' : 'Running'}</span>
          </button>
 
          {expanded && (
            <div id="planner-content" className="plannerContent">
              <h3 className="plannerTitle">
                <span className="emoji" aria-hidden="true">
                  📊
                </span>{' '}
                {summary.title || 'Planner Agent Summary'}
              </h3>
 
              <div className="infoBox" role="status">
                <strong>{summary.complete ? 'Processing Complete!' : 'Processing...'}</strong>{' '}
                {summary.total > 0 ? (
                  <>
                    Successfully processed <strong className="blueNum">{summary.processedRelevant}</strong> relevant dynamic_agents out of{' '}
                    <strong className="blueNum">{summary.total}</strong> total
                  </>
                ) : (
                  <>Working on planner output…</>
                )}
              </div>
 
              {!!summary.agents?.length && (
                <div className="agentsBlock">
                  <div className="agentsHeading">
                    <span className="greenTick" aria-hidden="true">
                      ✔
                    </span>
                    <span>
                      <strong>Included Agents ({summary.agents.length} agents):</strong>
                    </span>
                  </div>
 
                  <div className="agentsGrid">
                    {summary.agents.map((agent, idx) => (
                      <span key={`${agent}-${idx}`} className="agentTag">
                        <span className="tagTick" aria-hidden="true">
                          ✔
                        </span>
                        {agent}
                      </span>
                    ))}
                  </div>
                </div>
              )}
 
              <div className="infoBox soft" role="note">
                <strong>{summary.notes?.[0] || 'All agents were successfully processed with relevant context!'}</strong>
              </div>
            </div>
          )}
        </section>
      )}


<style>{`
      
        /* Planner summary card directly under Start Workflow */
        .plannerPanel {
          margin-top: 12px;
          background: #FFFFFF;
          border: 1px solid #D1D5DB;
          border-radius: 10px;
          box-shadow: 0 1px 2px rgba(16, 24, 40, 0.06);
        }

        .collapseHeader {
          all: unset;
          display: flex;
          align-items: center;
          gap: 8px;
          width: 100%;
          padding: 8px 12px;
          cursor: pointer;
          border-bottom: 1px solid #E5E7EB;
        }
        .chevron { font-size: 14px; color: #374151; transform: rotate(0deg); transition: transform 0.15s ease; }
        .chevron--right { transform: rotate(-90deg); }
        .headerTick {
          display: inline-flex; align-items: center; justify-content: center;
          height: 18px; width: 18px; border-radius: 4px;
          background: #D1FAE5; color: #065F46; font-size: 12px; line-height: 1;
        }
        .headerText { font-weight: 600; color: #065F46; }

        .plannerContent { padding: 12px; padding-bottom: 20px; }
        .plannerTitle {
          display: flex; align-items: center; gap: 8px;
          font-size: 1.05rem; font-weight: 700; color: #1F2937;
          margin: 4px 0 10px;
        }
        .emoji { font-size: 1.1rem; }

        .infoBox {
          background: #EAF3FF;
          color: #0F172A;
          border: 1px solid #D4E5FF;
          border-radius: 10px;
          padding: 10px 12px;
          font-size: 0.92rem;
        }
        .infoBox .blueNum { color: #1E40AF; }
        .infoBox.soft {
          margin-top: 10px;
          margin-bottom: 16px;
          background: #EAF3FF;
          border-color: #D4E5FF;
          font-weight: 600;
        }

        .agentsBlock { margin-top: 12px; margin-bottom: 12px; }
        .agentsHeading {
          display: flex; align-items: center; gap: 8px;
          color: #1F2937; margin-bottom: 12px;
        }
        .greenTick {
          display: inline-flex; align-items: center; justify-content: center;
          height: 20px; width: 20px; border-radius: 4px;
          background: #D1FAE5; color: #065F46; font-size: 14px; line-height: 1;
        }

        .agentsGrid { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 8px; }
        .agentTag {
          display: inline-flex; align-items: center; gap: 6px;
          padding: 6px 10px; font-size: 0.82rem;
          color: #065F46; background: #E7F6ED; border: 1px solid #B7E4C7;
          border-radius: 10px; box-shadow: 0 1px 2px rgba(16, 24, 40, 0.06);
          white-space: nowrap;
        }
        .tagTick {
          display: inline-flex; align-items: center; justify-content: center;
          height: 16px; width: 16px; border-radius: 3px;
          background: #D1FAE5; color: #065F46; font-size: 12px; line-height: 1;
        }
      `}</style>


    </div>
  );
}
