
// components/Card.tsx
'use client';

import Link from 'next/link';
import styles from './Card.module.css';
import type React from 'react';

type CardProps = {
  title: string;
  subtitle?: string; // optional line-break title like "Data\nModernization"
  description: string;
  href: string;
  icon?: React.ReactNode; // emoji icon
 
};

export default function Card({
  title,
  subtitle,
  description,
  href,
  icon = '💻',
  
}: CardProps) {
  // If subtitle is provided, render on next line to mimic the screenshot
  const [first, second] = subtitle ? [title, subtitle] : [undefined, undefined];

  return (
    <article className={styles.card }>
      <div className={styles.content}>
        {/* Icon + Title */}
        <div className={styles.headerRow}>
          {icon && (
            <div className={styles.iconWrap}>
              <span style={{ fontSize: '24px' }}>{icon}</span>
            </div>
          )}

          <div className={styles.titleWrap}>
            {/* Bold, dark title; second line if provided */}
            {first ? (
              <>
                <h3 className={styles.title}>{first}</h3>
                <h3 className={styles.title}>{second}</h3>
              </>
            ) : (
              <h3 className={styles.title}>{title}</h3>
            )}
          </div>
        </div>

        {/* Body copy */}
        <p className={styles.body}>{description}</p>
      </div>

      {/* CTA bar */}
      <Link href={href} className={`${styles.cta} rounded-xl`} aria-label="Explore">
        <span>Explore</span>
        <span className={styles.arrow}>➜</span>
      </Link>
    </article>
  );
}
