"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { AlertCircle, Eye, EyeOff, LockKeyhole, Mail, UserPlus, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { API_CONFIG, API_ENDPOINTS, getBaseUrl } from "@/config/apiConfig";
import { useTheme } from "@/contexts/ThemeContext";
import { AuthShowcaseShell } from "./AuthShowcaseShell";

type SignUpFormData = {
  username: string;
  email: string;
  firstname: string;
  lastname: string;
  password: string;
  confirmPassword: string;
  role: string;
};

type SignupRole = {
  id?: number;
  name?: string | null;
  description?: string;
};

const USERNAME_PATTERN = /^[a-zA-Z0-9_.]+$/;

function getRoleName(role: SignupRole): string {
  if (typeof role?.name === "string") {
    return role.name.trim();
  }

  return "";
}

function formatApiError(detail: unknown, fallback: string): string {
  if (!detail) {
    return fallback;
  }

  if (typeof detail === "string") {
    return detail;
  }

  if (Array.isArray(detail)) {
    const messages = detail
      .map((item) => {
        if (typeof item === "string") {
          return item;
        }

        if (item && typeof item === "object" && "msg" in item) {
          const message = String((item as { msg?: unknown }).msg ?? "");
          const location = Array.isArray((item as { loc?: unknown }).loc)
            ? (item as { loc?: unknown[] }).loc?.filter(Boolean).join(" > ")
            : "";
          return location ? `${location}: ${message}` : message;
        }

        return "";
      })
      .filter(Boolean);

    return messages.length > 0 ? messages.join("; ") : fallback;
  }

  if (typeof detail === "object" && detail !== null && "msg" in detail) {
    return String((detail as { msg?: unknown }).msg ?? fallback);
  }

  return fallback;
}

export default function SignUpScreen() {
  const router = useRouter();
  const { theme, brand } = useTheme();
  const [isMounted, setIsMounted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [rolesLoading, setRolesLoading] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [availableRoles, setAvailableRoles] = useState<string[]>([]);
  const [formData, setFormData] = useState<SignUpFormData>({
    username: "",
    email: "",
    firstname: "",
    lastname: "",
    password: "",
    confirmPassword: "",
    role: "",
  });

  const isLtmTheme = brand === "blueverse" && theme === "light";
  const passwordTooShort = formData.password.length > 0 && formData.password.length < 8;
  const confirmPasswordTooShort = formData.confirmPassword.length > 0 && formData.confirmPassword.length < 8;
  const usernameHasInvalidChars = formData.username.length > 0 && !USERNAME_PATTERN.test(formData.username.trim());

  useEffect(() => {
    setIsMounted(true);

    return () => {
      setIsMounted(false);
    };
  }, []);

  useEffect(() => {
    let isActive = true;

    const loadRoles = async () => {
      setRolesLoading(true);
      try {
        const token = typeof window !== "undefined" ? localStorage.getItem("daan_access_token") : null;
        const headers: HeadersInit = {};
        if (token) {
          headers.Authorization = `Bearer ${token}`;
        }

        const response = await fetch(`${getBaseUrl()}${API_ENDPOINTS.GET_ALL_ROLES}`, {
          method: "GET",
          headers,
        });

        if (!response.ok) {
          if (isActive) {
            setAvailableRoles([]);
            setFormData((current) => ({
              ...current,
              role: "",
            }));
          }
          return;
        }

        const rolePayload = await response.json().catch(() => [] as SignupRole[]);
        if (!Array.isArray(rolePayload) || !isActive) {
          return;
        }

        const roles = Array.from(
          new Set(
            rolePayload
              .map((role) => getRoleName(role as SignupRole))
              .filter(Boolean)
          )
        )
          .filter((role) => role !== "admin")
          .sort((left, right) => left.localeCompare(right));

        if (roles.length > 0) {
          setAvailableRoles(roles);
          setFormData((current) => ({
            ...current,
            role: roles.includes(current.role) ? current.role : "",
          }));
        } else if (isActive) {
          setAvailableRoles([]);
          setFormData((current) => ({
            ...current,
            role: "",
          }));
        }
      } catch {
        if (isActive) {
          setAvailableRoles([]);
          setFormData((current) => ({
            ...current,
            role: "",
          }));
        }
      } finally {
        if (isActive) {
          setRolesLoading(false);
        }
      }
    };

    loadRoles();

    return () => {
      isActive = false;
    };
  }, []);

  const updateField = (field: keyof SignUpFormData, value: string) => {
    setFormData((current) => ({
      ...current,
      [field]: value,
    }));

    if (error) {
      setError("");
    }
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsLoading(true);
    setError("");
    setSuccessMessage("");

    const normalizedUsername = formData.username.trim();

    if (!USERNAME_PATTERN.test(normalizedUsername)) {
      setError("Username can contain only letters, numbers, underscores, and periods.");
      setIsLoading(false);
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError("Password and confirm password must match.");
      setIsLoading(false);
      return;
    }

    if (formData.password.length < 8 || formData.confirmPassword.length < 8) {
      setError("Password and confirm password must be at least 8 characters.");
      setIsLoading(false);
      return;
    }

    if (!formData.role) {
      setError("No roles available.");
      setIsLoading(false);
      return;
    }

    let timeoutId: ReturnType<typeof setTimeout> | null = null;

    try {
      const controller = new AbortController();
      timeoutId = setTimeout(() => controller.abort(), API_CONFIG.TIMEOUT);

      const response = await fetch(`${getBaseUrl()}${API_ENDPOINTS.CREATE_USER}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: normalizedUsername,
          email: formData.email.trim(),
          firstname: formData.firstname.trim(),
          lastname: formData.lastname.trim(),
          password: formData.password,
          role: formData.role,
          team_ids: [1],
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        setError(formatApiError((errData as { detail?: unknown })?.detail, `Sign up failed (${response.status}).`));
        setIsLoading(false);
        return;
      }

      setFormData({
        username: "",
        email: "",
        firstname: "",
        lastname: "",
        password: "",
        confirmPassword: "",
        role: "",
      });
      setSuccessMessage("Account created successfully. Redirecting to login...");

      setTimeout(() => {
        router.push("/auth/signin");
      }, 1200);
    } catch (submitError) {
      if (submitError instanceof Error) {
        if (submitError.name === "AbortError") {
          setError("Request timed out. Please try again.");
        } else if (submitError.message.includes("fetch")) {
          setError("Network error. Please check your connection and try again.");
        } else {
          setError(submitError.message || "Unable to create account right now.");
        }
      } else {
        setError("Unable to create account right now.");
      }
    } finally {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      setIsLoading(false);
    }
  };

  return (
    <AuthShowcaseShell cardWidthClassName="max-w-2xl">
      <div className="relative z-10 w-full">
        <div className="absolute inset-[-3.5rem] -z-10 pointer-events-none">
          <div className="tech-pulse-ring h-[26rem] w-[26rem]" />
          <div className="tech-pulse-ring tech-pulse-ring--delay h-[26rem] w-[26rem]" />
        </div>

        <Card className={`tech-network-frame relative border border-white/15 dark:border-white/15 ${isLtmTheme ? 'bg-gradient-to-b from-[#f8f3f4] to-[#dceff2]' : 'bg-gradient-to-b from-slate-50 dark:from-slate-800/50 to-slate-100 dark:to-slate-900/50'} shadow-2xl backdrop-blur-2xl transition-all duration-1000 ${isMounted ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}>
          <div className={`absolute inset-0 rounded-lg ${isLtmTheme ? 'bg-gradient-to-r from-[#fb7185]/10 via-transparent to-[#f97316]/10' : 'bg-gradient-to-r from-fuchsia-500/10 via-transparent to-cyan-500/10'} pointer-events-none`} />
          <div className={`absolute left-4 top-4 h-4 w-4 border-l border-t ${isLtmTheme ? 'border-[#f97316]/35' : 'border-cyan-400/35'}`} />
          <div className={`absolute right-4 top-4 h-4 w-4 border-r border-t ${isLtmTheme ? 'border-[#f97316]/35' : 'border-cyan-400/35'}`} />
          <div className={`absolute bottom-4 left-4 h-4 w-4 border-b border-l ${isLtmTheme ? 'border-[#fb7185]/35' : 'border-cyan-400/35'}`} />
          <div className={`absolute bottom-4 right-4 h-4 w-4 border-b border-r ${isLtmTheme ? 'border-[#fb7185]/35' : 'border-cyan-400/35'}`} />

          <CardHeader className="relative space-y-4 pb-5 pt-7 text-center sm:space-y-5 sm:pb-6 sm:pt-8">
            <div className={`flex justify-center transition-all duration-1000 ${isMounted ? 'opacity-100 scale-100' : 'opacity-0 scale-75'}`} style={{ transitionDelay: '0.2s' }}>
              <div className="relative">
                <div className={`absolute inset-0 rounded-2xl blur-xl opacity-75 animate-pulse ${isLtmTheme ? 'bg-gradient-to-br from-[#f97316] via-[#fb7185] to-[#ef4444]' : 'bg-gradient-to-br from-fuchsia-500 via-violet-500 to-cyan-500'}`} />
                <div className={`relative flex h-20 w-20 items-center justify-center rounded-2xl text-white shadow-2xl sm:h-24 sm:w-24 ${isLtmTheme ? 'bg-gradient-to-br from-[#f97316] via-[#fb7185] to-[#ef4444]' : 'bg-gradient-to-br from-fuchsia-500 via-violet-500 to-cyan-500'}`}>
                  <UserPlus className="h-10 w-10 sm:h-12 sm:w-12" />
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <CardTitle className="text-4xl font-black sm:text-5xl text-brand-muted">SIGN UP</CardTitle>
              <p className="text-sm font-semibold tracking-widest text-brand-accent">Create your DAAN access profile</p>
            </div>
          </CardHeader>

          <CardContent className="relative space-y-5 pb-7 sm:pb-8">
            <form className="space-y-5" onSubmit={handleSubmit}>
              <div className="grid gap-4 md:grid-cols-2">
                <div className={`space-y-2.5 transition-all duration-1000 ${isMounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`} style={{ transitionDelay: '0.3s' }}>
                  <Label htmlFor="signup-username" className="text-base font-semibold text-brand-muted">Username</Label>
                  <div className="relative group">
                    <UserRound className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-brand-accent" />
                    <Input
                      id="signup-username"
                      type="text"
                      autoComplete="username"
                      placeholder="Enter username"
                      pattern="[A-Za-z0-9_.]+"
                      title="Username can contain letters, numbers, underscores, and periods."
                      className={`h-[3.25rem] w-full rounded-xl border bg-white pl-12 pr-4 text-base text-slate-900 placeholder-slate-500 transition-all focus-visible:border-brand-accent focus-visible:ring-brand-accent dark:bg-slate-800/50 dark:text-white sm:h-14 ${usernameHasInvalidChars ? 'border-red-400 focus-visible:ring-red-400' : 'border-slate-300'}`}
                      value={formData.username}
                      onChange={(event) => updateField("username", event.target.value)}
                      required
                    />
                  </div>
                  {usernameHasInvalidChars ? (
                    <p className="text-sm text-red-500 dark:text-red-300">Username can contain only letters, numbers, underscores, and periods.</p>
                  ) : null}
                </div>

                <div className={`space-y-2.5 transition-all duration-1000 ${isMounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`} style={{ transitionDelay: '0.35s' }}>
                  <Label htmlFor="signup-email" className="text-base font-semibold text-brand-muted">Email</Label>
                  <div className="relative group">
                    <Mail className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-brand-accent" />
                    <Input
                      id="signup-email"
                      type="email"
                      autoComplete="email"
                      placeholder="Enter your email"
                      className="h-[3.25rem] w-full rounded-xl border border-slate-300 bg-white pl-12 pr-4 text-base text-slate-900 placeholder-slate-500 transition-all focus-visible:border-brand-accent focus-visible:ring-brand-accent dark:bg-slate-800/50 dark:text-white sm:h-14"
                      value={formData.email}
                      onChange={(event) => updateField("email", event.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className={`space-y-2.5 transition-all duration-1000 ${isMounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`} style={{ transitionDelay: '0.4s' }}>
                  <Label htmlFor="signup-firstname" className="text-base font-semibold text-brand-muted">First name</Label>
                  <Input
                    id="signup-firstname"
                    type="text"
                    autoComplete="given-name"
                    placeholder="Enter first name"
                    className="h-[3.25rem] w-full rounded-xl border border-slate-300 bg-white px-4 text-base text-slate-900 placeholder-slate-500 transition-all focus-visible:border-brand-accent focus-visible:ring-brand-accent dark:bg-slate-800/50 dark:text-white sm:h-14"
                    value={formData.firstname}
                    onChange={(event) => updateField("firstname", event.target.value)}
                    required
                  />
                </div>

                <div className={`space-y-2.5 transition-all duration-1000 ${isMounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`} style={{ transitionDelay: '0.45s' }}>
                  <Label htmlFor="signup-lastname" className="text-base font-semibold text-brand-muted">Last name</Label>
                  <Input
                    id="signup-lastname"
                    type="text"
                    autoComplete="family-name"
                    placeholder="Enter last name"
                    className="h-[3.25rem] w-full rounded-xl border border-slate-300 bg-white px-4 text-base text-slate-900 placeholder-slate-500 transition-all focus-visible:border-brand-accent focus-visible:ring-brand-accent dark:bg-slate-800/50 dark:text-white sm:h-14"
                    value={formData.lastname}
                    onChange={(event) => updateField("lastname", event.target.value)}
                    required
                  />
                </div>

                <div className={`space-y-2.5 transition-all duration-1000 ${isMounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`} style={{ transitionDelay: '0.5s' }}>
                  <Label htmlFor="signup-password" className="text-base font-semibold text-brand-muted">Password</Label>
                  <div className="relative group">
                    <LockKeyhole className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-brand-accent" />
                    <input
                      id="signup-password"
                      type={showPassword ? "text" : "password"}
                      autoComplete="new-password"
                      placeholder="Create a password"
                      minLength={8}
                      className={`h-[3.25rem] w-full rounded-xl border bg-white pl-12 pr-12 text-base text-slate-900 placeholder-slate-500 transition-all focus-visible:border-brand-accent focus-visible:ring-brand-accent dark:bg-slate-800/50 dark:text-white sm:h-14 ${passwordTooShort ? 'border-red-400 focus-visible:ring-red-400' : 'border-slate-300'}`}
                      value={formData.password}
                      onChange={(event) => updateField("password", event.target.value)}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((current) => !current)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 transition-colors duration-200 hover:text-brand-accent active:text-brand-accent"
                      aria-label={showPassword ? "Hide password" : "Show password"}
                    >
                      {showPassword ? <Eye className="h-5 w-5" /> : <EyeOff className="h-5 w-5" />}
                    </button>
                  </div>
                  {passwordTooShort ? (
                    <p className="text-sm text-red-500 dark:text-red-300">Password must be at least 8 characters.</p>
                  ) : null}
                </div>

                <div className={`space-y-2.5 transition-all duration-1000 ${isMounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`} style={{ transitionDelay: '0.55s' }}>
                  <Label htmlFor="signup-confirm-password" className="text-base font-semibold text-brand-muted">Confirm password</Label>
                  <div className="relative group">
                    <LockKeyhole className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-brand-accent" />
                    <input
                      id="signup-confirm-password"
                      type={showPassword ? "text" : "password"}
                      autoComplete="new-password"
                      placeholder="Re-enter your password"
                      minLength={8}
                      className={`h-[3.25rem] w-full rounded-xl border bg-white pl-12 pr-4 text-base text-slate-900 placeholder-slate-500 transition-all focus-visible:border-brand-accent focus-visible:ring-brand-accent dark:bg-slate-800/50 dark:text-white sm:h-14 ${confirmPasswordTooShort ? 'border-red-400 focus-visible:ring-red-400' : 'border-slate-300'}`}
                      value={formData.confirmPassword}
                      onChange={(event) => updateField("confirmPassword", event.target.value)}
                      required
                    />
                  </div>
                  {confirmPasswordTooShort ? (
                    <p className="text-sm text-red-500 dark:text-red-300">Confirm password must be at least 8 characters.</p>
                  ) : null}
                </div>

                <div className={`space-y-2.5 transition-all duration-1000 ${isMounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`} style={{ transitionDelay: '0.6s' }}>
                  <Label htmlFor="signup-role" className="text-base font-semibold text-brand-muted">Role</Label>
                  <select
                    id="signup-role"
                    className="h-[3.25rem] w-full rounded-xl border border-slate-300 bg-white px-4 text-base text-slate-900 transition-all focus:outline-none focus:ring-2 focus:ring-brand-accent dark:bg-slate-800/50 dark:text-white sm:h-14"
                    value={formData.role}
                    onChange={(event) => updateField("role", event.target.value)}
                    disabled={rolesLoading || availableRoles.length === 0}
                  >
                    {rolesLoading ? (
                      <option value="">Loading roles...</option>
                    ) : availableRoles.length === 0 ? (
                      <option value="">No roles available</option>
                    ) : (
                      <option value="">Select role</option>
                    )}
                    {availableRoles.map((role) => (
                      <option key={role} value={role}>
                        {role}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {error ? (
                <div className="flex items-center gap-3 rounded-xl border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-700 backdrop-blur-sm animate-in fade-in slide-in-from-top-2 duration-300 dark:border-red-500/50 dark:bg-red-500/10 dark:text-red-300">
                  <AlertCircle className="h-5 w-5 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              ) : null}

              {successMessage ? (
                <div className="rounded-xl border border-emerald-300 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-300">
                  {successMessage}
                </div>
              ) : null}

              <Button
                type="submit"
                disabled={isLoading}
                className={`h-[3.25rem] w-full text-lg font-bold uppercase tracking-wider text-black shadow-2xl transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl disabled:cursor-not-allowed disabled:opacity-75 sm:h-14 ${isMounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
                style={{ transitionDelay: '0.7s' }}
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <div className="h-4 w-4 animate-spin border-2 border-black border-t-white" />
                    Creating...
                  </span>
                ) : "CREATE ACCOUNT"}
              </Button>
            </form>

            <div className="text-center text-sm text-slate-600 dark:text-slate-300">
              Already have an account?{" "}
              <Link href="/auth/signin" className="font-semibold text-brand-accent transition hover:opacity-80">
                Back to login
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </AuthShowcaseShell>
  );
}