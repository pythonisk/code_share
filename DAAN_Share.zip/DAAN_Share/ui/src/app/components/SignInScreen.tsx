"use client";

import Link from "next/link";
import { signIn, useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import { AlertCircle, Eye, EyeOff, PlayCircle, ArrowUpRight } from "lucide-react";
import { API_ENDPOINTS } from "@/config/apiConfig";
import { BlueverseLogo } from "@/components/BlueverseLogo";

// Exact palette from the reference HTML :root variables
const BRAND_1 = "#ff6b57";
const BRAND_2 = "#e24a3b";
const BG_SOFT = "#fff9f8";
const BORDER_SOFT = "#ffd8d2";
const TEXT_DARK = "#0f172a";
const TEXT_MUTED = "#475569";

const capabilities = [
  {
    title: "DAAN Builder",
    description:
      "Design and configure reusable AI agents with templates, tools, prompts, and policy controls.",
  },
  {
    title: "Reasoning Engine",
    description:
      "Enable planner, reviewer, and executor agent patterns for dependable multi-step decisioning.",
  },
  {
    title: "Workflow Orchestration at Scale",
    description:
      "Upload Excel-defined flows and orchestrate 40-50+ agents across complex business processes.",
  },
  {
    title: "Skills-Based Deployment",
    description:
      "Package agents as skills, import/export .md skill files, and deploy into GitHub Copilot environments.",
  },
  {
    title: "Session Observability",
    description:
      "Track traces, logs, latency, token usage, and quality signals across every execution.",
  },
  {
    title: "Guardrails and Governance",
    description:
      "Apply validation, policy checks, and feedback loops for safe enterprise-scale operations.",
  },
  {
    title: "LiteLLM Gateway and Multi-Model Access",
    description:
      "Route across model providers with normalized integration, dynamic selection, and fallback support.",
  },
  {
    title: "Advanced RAG and Persistent Memory",
    description:
      "Ground responses in enterprise knowledge while preserving contextual continuity across sessions.",
  },
  {
    title: "Knowledge Graphs and Ontology Generation",
    description:
      "Leverage Data for AI archetype capabilities to auto-generate knowledge graphs and domain ontologies for richer enterprise context.",
  },
  {
    title: "Agent Marketplace",
    description:
      "Discover and reuse prebuilt enterprise agents from the DAAN marketplace to accelerate delivery and standardize quality.",
  },
];

const businessImpact = [
  "Higher output quality with governed feedback loops",
  "Faster delivery cycles through reusable agent workflows",
  "Reduced time-to-value for enterprise AI transformation",
];

const cardBaseStyle: React.CSSProperties = {
  background: "#fff",
  border: `1px solid ${BORDER_SOFT}`,
  borderRadius: "24px",
  boxShadow: "0 18px 40px rgba(255, 107, 87, 0.13)",
  padding: "30px",
};

export default function SignInScreen() {
  const router = useRouter();
  const { status } = useSession();
  const isAuthenticated = status === "authenticated";
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isMounted, setIsMounted] = useState(false);
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });

  useEffect(() => {
    setIsMounted(true);
    return () => {
      setIsMounted(false);
    };
  }, []);

  const handleChange = (field: "username" | "password", value: string) => {
    setFormData((current) => ({
      ...current,
      [field]: value,
    }));

    if (error) {
      setError("");
    }
  };

  const deckHref =
    "https://ltimindtree.sharepoint.com/:p:/r/sites/DAAN/Shared%20Documents/Artifacts/Pre-Sales%20Documents/AI%20for%20Data%20-%20Data%20AI%20%26%20Automation%20Network%20(DAAN)%20Version%201.0.pptx?d=w9bb093af086e4d17882a9ca4008b4f20&csf=1&web=1&e=dO39Dh";

  const openDeckInNewTab = () => {
    if (typeof window === "undefined") {
      return;
    }

    window.open(deckHref, "_blank", "noopener,noreferrer");
  };

  const handleCredentialsSignIn = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!isMounted) {
      setError("Please wait for the page to fully load.");
      return;
    }

    setIsLoading(true);
    setError("");

    try {
      // 1) Authenticate against backend and store JWT for API calls
      const tokenResponse = await fetch(API_ENDPOINTS.GENERATE_TOKEN, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username_or_email: formData.username,
          password: formData.password,
        }),
      });

      if (!tokenResponse.ok) {
        if (tokenResponse.status === 401) {
          setError("Invalid email or password.");
        } else if (tokenResponse.status >= 500) {
          setError("Server error. Please try again later.");
        } else {
          setError(`Authentication failed (${tokenResponse.status}). Please try again.`);
        }
        setIsLoading(false);
        return;
      }

      const tokenData = await tokenResponse.json();
      const accessToken: string | undefined = tokenData?.access_token;
      const userId: number | undefined = tokenData?.user_id;
      const username: string | undefined = tokenData?.username;
      const role: string | undefined = tokenData?.role;

      if (!accessToken) {
        setError("Unable to sign in right now. Please try again.");
        setIsLoading(false);
        return;
      }

      try {
        localStorage.setItem("daan_access_token", accessToken);
        if (userId) {
          localStorage.setItem("user_id", userId.toString());
        }
        if (username) {
          localStorage.setItem("daan_username", username);
          localStorage.setItem("username", username);
        }
        if (role) {
          localStorage.setItem("userRole", role);
        }
        window.dispatchEvent(new Event("daan-auth-changed"));
      } catch {
        // Ignore storage errors (private mode, blocked storage, etc.)
      }

      // 2) Also sign-in with NextAuth so middleware allows navigation
      const result = await signIn("credentials", {
        username: formData.username,
        password: formData.password,
        redirect: false,
        callbackUrl: "/dashboard",
      });

      if (result?.error) {
        setError("Invalid email or password.");
        setIsLoading(false);
        return;
      }

      if (typeof window !== "undefined") {
        window.location.href = result?.url || "/dashboard";
        return;
      }

      if (isMounted && router) {
        router.replace("/dashboard");
      }
    } catch (signInError) {
      console.error("Sign-in error:", signInError);

      if (signInError instanceof Error) {
        if (signInError.message.includes("fetch")) {
          setError("Network error. Please check your connection and try again.");
        } else {
          setError(signInError.message || "Unable to sign in right now. Please try again.");
        }
      } else {
        setError("Unable to sign in right now. Please try again.");
      }
      setIsLoading(false);
    }
  };

  return (
    <div
      className="daan-login-root"
      style={{
        height: isAuthenticated ? "auto" : "100vh",
        overflowY: isAuthenticated ? "visible" : "auto",
        color: TEXT_DARK,
        fontFamily: "var(--font-regular, 'esklarheit-regular')",
        fontSize: "16px",
        background: "linear-gradient(180deg, #fff8f6 0%, #ffffff 48%, #fff5f2 100%)",
      }}
    >
      <main
        className="daan-login-page"
        style={{
          width: "100%",
          margin: 0,
          padding: "20px 16px",
          display: "grid",
          gridTemplateColumns: isAuthenticated ? "1fr" : "1.25fr 0.75fr",
          gap: "28px",
          alignItems: "start",
        }}
      >
        {/* ── Left: scrolls with the page ──────────────────────────── */}
        <section className="daan-left-pane" style={cardBaseStyle}>
          {/* Brand (hidden when authenticated; the navbar already shows the logo) */}
          {!isAuthenticated && (
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "12px",
                marginBottom: "24px",
              }}
            >
              <BlueverseLogo theme="light" className="h-[44px] w-auto" />
            </div>
          )}

          {/* Headline */}
          <h1
            style={{
              margin: 0,
              maxWidth: "none",
              lineHeight: 1.2,
              fontFamily: "var(--font-semibold, 'esklarheit-semi')",
              fontWeight: 600,
            }}
          >
            <span
              style={{
                display: "inline-block",
                fontSize: "40px",
                lineHeight: 1,
                letterSpacing: "0.01em",
                color: "#d64a3a",
                fontFamily: "var(--font-semibold, 'esklarheit-semi')",
                fontWeight: 600,
                whiteSpace: "nowrap",
              }}
              className="main-title"
            >
              DAAN Studio
            </span>
            <span
              style={{
                display: "block",
                marginTop: "-6px",
                fontSize: "36px",
                fontFamily: "var(--font-semibold, 'esklarheit-semi')",
                fontWeight: 600,
                lineHeight: 1.08,
              }}
              className="main-subtitle"
            >
              AI-Assisted Engineering for Enterprise Delivery
            </span>
          </h1>

          <p
            style={{
              marginTop: "16px",
              width: "100%",
              fontSize: "16px",
              lineHeight: 1.7,
              color: TEXT_MUTED,
            }}
            className="main-description"
          >
            DAAN Studio unifies AI agent design, reasoning, observability, and deployment in one
            governed platform, helping teams move from idea to production faster and with
            confidence.
          </p>

          {/* Explore Demos / Show Deck */}
          <div
            style={{
              marginTop: "22px",
              display: "flex",
              flexWrap: "wrap",
              gap: "10px",
            }}
          >
            <button
              type="button"
              onClick={() => router.push("/demo-showcase")}
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "6px",
                borderRadius: "12px",
                border: "none",
                cursor: "pointer",
                background: "linear-gradient(135deg, #ff6b57 0%, #ff7d63 100%)",
                padding: "8px 14px",
                fontSize: "12px",
                fontWeight: 600,
                color: "#000",
                boxShadow: "0 8px 16px rgba(255, 107, 87, 0.28)",
              }}
            >
              <PlayCircle style={{ height: "14px", width: "14px" }} />
              Demo Videos
            </button>
            <button
              type="button"
              onClick={openDeckInNewTab}
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "6px",
                borderRadius: "12px",
                border: "none",
                cursor: "pointer",
                background: "linear-gradient(135deg, #ff6b57 0%, #ff7d63 100%)",
                padding: "8px 14px",
                fontSize: "12px",
                fontWeight: 600,
                color: "#000",
                boxShadow: "0 8px 16px rgba(255, 107, 87, 0.28)",
              }}
            >
              DAAN Deck
              <ArrowUpRight style={{ height: "14px", width: "14px" }} />
            </button>
          </div>

          {/* Highlight */}
          <div
            style={{
              marginTop: "22px",
              padding: "20px",
              borderRadius: "16px",
              border: "1px solid #ffe2dc",
              background: BG_SOFT,
            }}
          >
            <h2 style={{ margin: 0, color: "#d64a3a", fontSize: "24px", fontWeight: 700 }}>
              Build. Reason. Orchestrate. Deploy.
            </h2>
            <p style={{ margin: "10px 0 0", color: TEXT_MUTED, fontSize: "16px", lineHeight: 1.6 }}>
              From single-agent use cases to multi-agent programs, DAAN Studio enables secure,
              reusable, and measurable AI workflows across SDLC and business operations.
            </p>
          </div>

          {/* Capabilities grid */}
          <div
            className="daan-caps-grid"
            style={{
              marginTop: "28px",
              display: "grid",
              gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
              gap: "12px",
            }}
          >
            {capabilities.map((cap) => (
              <article
                key={cap.title}
                style={{
                  border: "1px solid #ffe3dd",
                  borderRadius: "16px",
                  background: "#fff",
                  padding: "16px",
                  boxShadow: "0 8px 18px rgba(255, 107, 87, 0.08)",
                }}
              >
                <h3 style={{ margin: 0, fontSize: "14px", fontWeight: 700 }}>{cap.title}</h3>
                <p
                  style={{
                    margin: "8px 0 0",
                    color: TEXT_MUTED,
                    fontSize: "14px",
                    lineHeight: 1.6,
                  }}
                >
                  {cap.description}
                </p>
              </article>
            ))}
          </div>

          {/* Business impact */}
          <div
            style={{
              marginTop: "28px",
              border: "1px solid #ffd9d1",
              borderRadius: "16px",
              background: "linear-gradient(130deg, #fff3ef 0%, #ffe3dc 100%)",
              padding: "20px",
            }}
          >
            <h2 style={{ margin: 0, fontSize: "20px", fontWeight: 700 }}>Business Impact</h2>
            <ul style={{ margin: "14px 0 0", padding: 0, listStyle: "none" }}>
              {businessImpact.map((item) => (
                <li
                  key={item}
                  style={{
                    margin: "8px 0",
                    color: "#334155",
                    lineHeight: 1.5,
                    display: "flex",
                    gap: "10px",
                    alignItems: "flex-start",
                  }}
                >
                  <span
                    style={{
                      width: "8px",
                      height: "8px",
                      marginTop: "8px",
                      borderRadius: "999px",
                      background: BRAND_1,
                      flex: "none",
                    }}
                  />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* DAAN overview image */}
          <div
            style={{
              marginTop: "28px",
              width: "100%",
              overflow: "hidden",
              borderRadius: "16px",
            }}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/DAAN5 overview.png"
              alt="DAAN framework specification overview"
              style={{
                width: "108%",
                marginLeft: "2%",
                height: "auto",
                display: "block",
              }}
            />
          </div>
        </section>

        {/* ── Right: sticky login card ─────────────────────────────────── */}        {!isAuthenticated && (        <section
          style={{
            ...cardBaseStyle,
            position: "sticky",
            top: "24px",
            height: "fit-content",
          }}
        >
          <h2 style={{ margin: 0, textAlign: "center", fontSize: "26px", fontWeight: 700 }}>
            Welcome to DAAN Studio
          </h2>
          <p
            style={{
              margin: "10px 0 24px",
              textAlign: "center",
              color: TEXT_MUTED,
              lineHeight: 1.5,
              fontSize: "14px",
            }}
          >
            Sign in to build, monitor, and deploy enterprise AI agents.
          </p>

          <form onSubmit={handleCredentialsSignIn}>
            <label htmlFor="work-email" style={labelStyle}>
              Work Email / Username
            </label>
            <input
              id="work-email"
              type="text"
              name="email"
              autoComplete="username"
              placeholder="name@company.com"
              value={formData.username}
              onChange={(event) => handleChange("username", event.target.value)}
              style={inputStyle}
              onFocus={applyInputFocus}
              onBlur={removeInputFocus}
            />

            <label htmlFor="password" style={labelStyle}>
              Password
            </label>
            <div style={{ position: "relative" }}>
              <input
                id="password"
                type={showPassword ? "text" : "password"}
                name="password"
                autoComplete="current-password"
                placeholder="Enter your password"
                value={formData.password}
                onChange={(event) => handleChange("password", event.target.value)}
                style={{ ...inputStyle, paddingRight: "44px" }}
                onFocus={applyInputFocus}
                onBlur={removeInputFocus}
              />
              <button
                type="button"
                onClick={() => setShowPassword((current) => !current)}
                tabIndex={-1}
                aria-label={showPassword ? "Hide password" : "Show password"}
                style={{
                  position: "absolute",
                  right: "12px",
                  top: "22px",
                  transform: "translateY(-50%)",
                  background: "transparent",
                  border: "none",
                  cursor: "pointer",
                  color: "#94a3b8",
                  display: "flex",
                  padding: 0,
                }}
              >
                {showPassword ? <Eye style={{ width: 18, height: 18 }} /> : <EyeOff style={{ width: 18, height: 18 }} />}
              </button>
            </div>

            {error ? (
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  border: "1px solid #fecaca",
                  background: "#fef2f2",
                  color: "#b91c1c",
                  borderRadius: "12px",
                  padding: "10px 12px",
                  fontSize: "14px",
                  marginBottom: "16px",
                }}
              >
                <AlertCircle style={{ width: 18, height: 18, flex: "none" }} />
                <span>{error}</span>
              </div>
            ) : null}

            <button
              type="submit"
              disabled={isLoading}
              style={{
                border: "none",
                width: "100%",
                height: "44px",
                borderRadius: "12px",
                fontWeight: 700,
                color: "#fff",
                cursor: isLoading ? "not-allowed" : "pointer",
                opacity: isLoading ? 0.8 : 1,
                background: `linear-gradient(135deg, ${BRAND_1} 0%, ${BRAND_2} 100%)`,
                boxShadow: "0 14px 26px rgba(226, 74, 59, 0.35)",
                fontSize: "14px",
              }}
            >
              {isLoading ? (
                <span style={{ display: "inline-flex", alignItems: "center", gap: "8px" }}>
                  <span
                    style={{
                      width: "16px",
                      height: "16px",
                      borderRadius: "999px",
                      border: "2px solid rgba(255,255,255,0.4)",
                      borderTopColor: "#fff",
                      display: "inline-block",
                      animation: "daan-spin 0.7s linear infinite",
                    }}
                  />
                  Signing in...
                </span>
              ) : (
                "Log In"
              )}
            </button>
          </form>

          <div style={{ marginTop: "22px", textAlign: "center", fontSize: "14px" }}>
            <Link
              href="/auth/signin"
              style={{
                display: "block",
                textDecoration: "none",
                marginBottom: "8px",
                color: "#d64a3a",
                fontWeight: 700,
              }}
            >
              Sign in with SSO
            </Link>
            <Link
              href="/auth/signin"
              style={{
                display: "block",
                textDecoration: "none",
                marginBottom: "8px",
                color: "#475569",
              }}
            >
              Forgot Password?
            </Link>
            <p style={{ margin: "10px 0 0", color: "#64748b", fontSize: "12px" }}>
              Don&apos;t have an account?{" "}
              <Link
                href="/auth/signup"
                style={{ color: "#d64a3a", fontWeight: 700, textDecoration: "none" }}
              >
                Sign up
              </Link>
            </p>
            <p style={{ margin: "10px 0 0", color: "#64748b", fontSize: "12px" }}>
              Need access? Contact your DAAN Studio administrator.
            </p>
          </div>
        </section>
        )}
      </main>

      <style>{`
        @keyframes daan-spin { to { transform: rotate(360deg); } }
        .daan-login-root,
        .daan-login-root p,
        .daan-login-root span,
        .daan-login-root div,
        .daan-login-root a,
        .daan-login-root li {
          font-family: var(--font-regular, 'esklarheit-regular') !important;
        }
        .daan-login-root h1,
        .daan-login-root h2,
        .daan-login-root h3,
        .daan-login-root h4,
        .daan-login-root h5,
        .daan-login-root h6,
        .daan-login-root strong,
        .daan-login-root b,
        .daan-login-root th {
          font-family: var(--font-semibold, 'esklarheit-semi') !important;
        }
        .daan-login-root button,
        .daan-login-root label,
        .daan-login-root input,
        .daan-login-root select,
        .daan-login-root textarea {
          font-family: var(--font-medium, 'esklarheit-medium') !important;
        }
        /* Specific override: ensure the DAAN Studio main title shows large */
        .daan-login-root .main-title {
          font-size: 40px !important;
          font-family: var(--font-semibold, 'esklarheit-semi') !important;
          font-weight: 600 !important;
          white-space: nowrap !important;
        }
        .daan-login-root .main-subtitle {
          font-size: 26px !important;
          font-family: var(--font-semibold, 'esklarheit-semi') !important;
          font-weight: 600 !important;
        }
        @media (max-width: 900px) {
          .daan-login-root .main-title { font-size: 32px !important; }
          .daan-login-root .main-subtitle { font-size: 20px !important; }
        }
        @media (max-width: 1100px) {
          .daan-login-page { grid-template-columns: 1fr !important; }
          .daan-login-page > section:last-child { position: static !important; }
        }
        @media (max-width: 700px) {
          .daan-caps-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  display: "block",
  fontSize: "12px",
  letterSpacing: "0.08em",
  textTransform: "uppercase",
  fontWeight: 400,
  color: "#334155",
  marginBottom: "8px",
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  height: "44px",
  border: "1px solid #ffd9d2",
  borderRadius: "12px",
  padding: "0 12px",
  fontSize: "14px",
  marginBottom: "16px",
  outline: "none",
  color: TEXT_DARK,
  background: "#fff",
};

function applyInputFocus(event: React.FocusEvent<HTMLInputElement>) {
  event.target.style.borderColor = BRAND_1;
  event.target.style.boxShadow = "0 0 0 3px rgba(255, 107, 87, 0.2)";
}

function removeInputFocus(event: React.FocusEvent<HTMLInputElement>) {
  event.target.style.borderColor = "#ffd9d2";
  event.target.style.boxShadow = "none";
}
