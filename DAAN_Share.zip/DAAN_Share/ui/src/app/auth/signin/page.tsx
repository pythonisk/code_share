import SignInScreen from "@/app/components/SignInScreen";

export default function SignInPage() {
  return <SignInScreen />;
}