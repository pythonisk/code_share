export default function AuthLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  // Auth pages bypass AppShell but still inherit providers from root layout
  return <>{children}</>;
}
