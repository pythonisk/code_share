"use client";

import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { Suspense } from "react";
import { useTheme } from "@/contexts/ThemeContext";

const errors: Record<string, string> = {
  Signin: "Try signing in with a different account.",
  OAuthSignin: "Try signing in with a different account.",
  OAuthCallback: "Try signing in with a different account.",
  OAuthCreateAccount: "Try signing in with a different account.",
  EmailCreateAccount: "Try signing in with a different account.",
  Callback: "Try signing in with a different account.",
  OAuthAccountNotLinked: "To confirm your identity, sign in with the same account you used originally.",
  EmailSignin: "Check your email address.",
  CredentialsSignin: "Sign in failed. Check the details you provided are correct.",
  default: "Unable to sign in.",
};

function AuthErrorContent() {
  const searchParams = useSearchParams();
  const { theme, brand } = useTheme();
  const error = searchParams.get("error");
  
  const errorMessage = error && errors[error] ? errors[error] : errors.default;
  const isLtmTheme = brand === "blueverse" && theme === "light";

  return (
    <div className={`min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 ${
      theme === 'dark' 
        ? 'bg-gradient-to-br from-slate-950 via-purple-900 to-slate-950' 
        : isLtmTheme 
          ? 'bg-gradient-to-br from-[#f5f1f4] via-[#e7d8e4] to-[#f2dfdf]'
          : 'bg-gradient-to-br from-slate-50 via-purple-100/50 to-slate-100'
    }`}>
      <div className="max-w-md w-full space-y-8">
        <div>
          <div className="mx-auto h-12 w-auto flex justify-center">
            <div className={`text-3xl font-bold ${theme === 'dark' ? 'text-red-400' : 'text-red-600'}`}>⚠️</div>
          </div>
          <h2 className={`mt-6 text-center text-3xl font-extrabold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
            Authentication Error
          </h2>
          <p className={`mt-2 text-center text-sm ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
            {errorMessage}
          </p>
        </div>
        
        <div className="mt-8 space-y-6">
          <div className={`rounded-md p-4 ${
            theme === 'dark' 
              ? 'bg-red-900/20 border border-red-500/30' 
              : 'bg-red-50 border border-red-200'
          }`}>
            <div className={`text-sm ${theme === 'dark' ? 'text-red-300' : 'text-red-700'}`}>
              <p className="font-medium">Error Code: {error || "Unknown"}</p>
              <p className="mt-1">{errorMessage}</p>
            </div>
          </div>
          
          <div className="flex flex-col space-y-3">
            <Link
              href="/auth/signin"
              className={`w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium transition duration-150 ease-in-out ${
                isLtmTheme
                  ? 'text-black bg-[#ff5e4f] hover:bg-[#ff6b5d]'
                  : theme === 'dark'
                    ? 'text-white bg-purple-600 hover:bg-purple-700'
                    : 'text-white bg-blue-600 hover:bg-blue-700'
              } focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                isLtmTheme ? 'focus:ring-[#ff5e4f]' : 'focus:ring-blue-500'
              }`}
            >
              Try Again
            </Link>
            
            <Link
              href="/"
              className={`w-full flex justify-center py-2 px-4 border rounded-md shadow-sm text-sm font-medium transition duration-150 ease-in-out ${
                theme === 'dark'
                  ? 'border-gray-600 text-gray-300 bg-gray-800 hover:bg-gray-700'
                  : 'border-gray-300 text-gray-700 bg-white hover:bg-gray-50'
              } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500`}
            >
              Go Home
            </Link>
          </div>
          
          <div className="text-center">
            <p className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
              If this problem persists, please contact your system administrator.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AuthError() {
  const { theme } = useTheme();
  
  return (
    <Suspense fallback={
      <div className={`min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 ${
        theme === 'dark' 
          ? 'bg-gradient-to-br from-slate-950 via-purple-900 to-slate-950' 
          : 'bg-gradient-to-br from-slate-50 via-purple-100/50 to-slate-100'
      }`}>
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <div className="mx-auto h-12 w-auto flex justify-center">
              <div className={`text-3xl font-bold ${theme === 'dark' ? 'text-blue-400' : 'text-blue-600'}`}>🔄</div>
            </div>
            <h2 className={`mt-6 text-center text-3xl font-extrabold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              Loading...
            </h2>
          </div>
        </div>
      </div>
    }>
      <AuthErrorContent />
    </Suspense>
  );
}