import SignUpScreen from "@/app/components/SignUpScreen";

export default function SignUpPage() {
  return <SignUpScreen />;
}