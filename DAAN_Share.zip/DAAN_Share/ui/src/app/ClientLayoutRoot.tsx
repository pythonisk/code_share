"use client";

import dynamic from "next/dynamic";
import AuthProvider from "@/app/components/AuthProvider";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { Toaster } from "@/components/ui/sonner";
import { FetchInterceptorProvider } from "@/components/FetchInterceptorProvider";
import { ModeTransitionWrapper } from "@/components/ModeTransitionWrapper";
import { ConditionalAppShell } from "@/components/ConditionalAppShell";

const StudioViewWrapper = dynamic(
  () => import("@/components/StudioViewWrapper").then((module) => module.StudioViewWrapper),
  {
    ssr: false,
    loading: () => null,
  }
);

export function ClientLayoutRoot({ children }: { children: React.ReactNode }) {
  return (
    <AuthProvider>
      <ThemeProvider>
        <FetchInterceptorProvider>
          <ConditionalAppShell>
            <ModeTransitionWrapper studio={<StudioViewWrapper />}>
              {children}
            </ModeTransitionWrapper>
          </ConditionalAppShell>
          <Toaster position="top-right" richColors />
        </FetchInterceptorProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}