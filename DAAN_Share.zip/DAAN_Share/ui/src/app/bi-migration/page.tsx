'use client';


import { Suspense } from 'react';
import ArchetypeWorkflow from '@/views/ArchetypeWorkflow';

export default function BiMigrationPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <ArchetypeWorkflow archetypeKey="bi-migration" />
    </Suspense>
  );
}
