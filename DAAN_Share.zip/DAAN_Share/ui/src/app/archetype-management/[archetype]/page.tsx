'use client';

import { useParams, useSearchParams } from 'next/navigation';
import ArchetypeManagementWorkflow from '@/views/ArchetypeManagementWorkflow';

export default function ArchetypeManagementWorkflowPage() {
  const params = useParams();
  const searchParams = useSearchParams();
  const archetypeKey = params.archetype as string;
  const customTitle = searchParams.get('title') || undefined;

  // Archetypes live in the DB — only reject a genuinely malformed slug
  const isValidSlug = typeof archetypeKey === 'string' && /^[a-z0-9]+(?:-[a-z0-9]+)*$/i.test(archetypeKey);
  if (!isValidSlug) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-500">Invalid Archetype</h1>
          <p className="text-gray-600 mt-2">The requested archetype does not exist.</p>
        </div>
      </div>
    );
  }

  return <ArchetypeManagementWorkflow archetypeKey={archetypeKey} customTitle={customTitle} />;
}
