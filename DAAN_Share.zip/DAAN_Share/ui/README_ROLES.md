# Archetype Role Management System

This system allows for dynamic role selection based on the selected archetype. Roles are loaded directly from Excel files that correspond to each archetype.

## Folder Structure

```
public/
  archetype-roles/
    data-modernization.xlsx
    platform-engineering.xlsx
    operations-support.xlsx
    data-consumption.xlsx
    bi-migration.xlsx
    data-pipeline.xlsx
    data-trust.xlsx
```

## Excel File Format

Each Excel file should have the following structure (based on your screenshot):

| Column A | Column B | Column C | Column D | Column E |
|----------|----------|----------|----------|----------|
| PMDG     | Role     | Target   | Agent Name | Agent Actions(Step by Step) |
| DM005    | QA Analyst | Final Tuned Target DDL | DDL Conversion Agent | 1. Connect to target... |

### Column Mapping
- **Column A (PMDG)** → `id` - Unique identifier for the role
- **Column B (Role)** → `role` - The role name that appears in dropdown  
- **Column C (Target)** → `target` - Target/input requirements
- **Column D (Agent Name)** → `agentName` - Name of the associated agent
- **Column E (Agent Actions)** → `agentActions` - Step-by-step actions

## Adding New Excel Files

To add new Excel role data:

1. **Prepare your Excel file** with the column structure above
2. **Name the file** using the archetype URL pattern:
   - `data-modernization.xlsx`
   - `platform-engineering.xlsx`  
   - `operations-support.xlsx`
   - `data-consumption.xlsx`
   - `bi-migration.xlsx`
   - `data-pipeline.xlsx`
   - `data-trust.xlsx`
3. **Place the file** in `public/archetype-roles/`
4. The file will be automatically loaded when the archetype is selected

## Excel Requirements

### Supported Formats
- `.xlsx` (Excel 2007+)
- `.xls` (Legacy Excel)
- First worksheet is used by default

### Flexible Headers
The system supports both:
1. **Fixed column positions** (Column A = ID, Column B = Role, etc.)
2. **Named headers** (automatically detects columns like "Role", "Agent Name", etc.)

### Header Variations Supported
- Role: `Role`, `role`
- ID: `PMDG`, `ID`, `Id`, `pmdg`, `id`
- Target: `Target`, `target`, `Input`, `input`
- Agent Name: `Agent Name`, `agentName`, `AgentName`, `Agent`
- Actions: `Agent Actions(Step by Step)`, `Agent Actions`, `agentActions`, `actions`

## How It Works

1. User selects an archetype from the landing page
2. The workflow page loads with the archetype parameter
3. RoleSelector component fetches the corresponding Excel file
4. Excel data is parsed using the xlsx library
5. Unique roles are extracted and displayed in the dropdown
6. When a role is selected, additional details are shown below

## Features

- **Direct Excel Reading**: No need to convert to JSON - reads Excel files directly
- **Flexible Column Detection**: Supports both fixed positions and named headers
- **Role Details**: When a role is selected, additional information is displayed
- **Error Handling**: Falls back to default roles if Excel file is missing or corrupt
- **Loading States**: Shows loading indicator while fetching and parsing Excel files
- **Archetype Context**: Display which archetype the roles belong to
- **Multiple Format Support**: Supports both .xlsx and .xls files

## Troubleshooting

### File Not Loading
- Check the file name matches the archetype URL pattern exactly
- Ensure the Excel file is in `public/archetype-roles/`
- Verify the Excel file is not corrupted

### No Roles Showing
- Check that Column B (or "Role" header) contains the role names
- Ensure there's data starting from row 2 (row 1 is headers)
- Look in browser console for parsing errors

### Wrong Role Data
- Verify the column mapping matches your Excel structure
- Check that headers match the expected variations
- Try both numbered columns and named headers approach

## File Locations

- **Role Utility**: `src/utils/roleUtils.ts`
- **RoleSelector Component**: `src/app/components/workflow/RoleSelector.tsx`
- **Excel Data Files**: `public/archetype-roles/*.xlsx`

## Installation

The system uses the `xlsx` library for Excel parsing:
```bash
npm install xlsx
```