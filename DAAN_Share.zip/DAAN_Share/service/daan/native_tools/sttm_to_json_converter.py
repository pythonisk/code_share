"""
STTM to JSON native tool.

Converts an STTM file from the current session inputs folder to JSON and
publishes the JSON into the session artifacts folder for universal download.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any

from daan.utils.file_to_json import FileToJsonConverter

logger = logging.getLogger(__name__)


class SttmToJsonConverter:
    """DAAN native tool for converting STTM files to JSON artifacts."""

    def __init__(self, data_dir: str | None = None):
        self.tool_name = "SttmToJsonConverter"
        self._data_dir = data_dir
        self._converter = FileToJsonConverter()
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    def convert_sttm_to_json(
        self,
        file_name: str | None = None,
        file_path: str | None = None,
        markdown_text: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Convert an STTM input file to JSON and save it into artifacts/.

        Args:
            file_name: Optional filename inside session inputs/.
            file_path: Optional absolute or relative file path.

        Returns:
            A status payload with artifact path and metadata.
        """
        try:
            artifacts_dir = self._resolve_artifacts_dir()
            artifacts_dir.mkdir(parents=True, exist_ok=True)

            generated_paths: list[Path] = []
            session_dir = self._resolve_session_dir()
            extracted_blocks = self._extract_json_artifacts(
                session_dir=session_dir,
                markdown_text=markdown_text,
                kwargs=kwargs,
            )

            if extracted_blocks:
                for artifact_name, payload in extracted_blocks:
                    artifact_path = self._next_available_artifact_path(artifacts_dir, artifact_name)
                    artifact_path.write_text(
                        json.dumps(payload, ensure_ascii=False, indent=2, default=str),
                        encoding="utf-8",
                    )
                    generated_paths.append(artifact_path)
                    logger.info("%s: wrote artifact %s", self.tool_name, artifact_path.name)
                logger.info(
                    "%s: Saved %d JSON artifacts from agent output markdown",
                    self.tool_name,
                    len(generated_paths),
                )
            else:
                logger.info(
                    "%s: No titled JSON blocks found in markdown output; skipping source-file conversion",
                    self.tool_name,
                )
                return {
                    "status": "ok",
                    "message": "No extracted JSON blocks found; no artifacts created.",
                    "source_file": None,
                    "generated_count": 0,
                    "artifact_files": [],
                    "artifact_paths": [],
                }

            return {
                "status": "ok",
                "message": "STTM converted to JSON successfully",
                "source_file": str(self._resolve_source_file(file_name=file_name, file_path=file_path))
                if self._resolve_source_file(file_name=file_name, file_path=file_path)
                else None,
                "generated_count": len(generated_paths),
                "artifact_files": [p.name for p in generated_paths],
                "artifact_paths": [str(p) for p in generated_paths],
            }
        except Exception as exc:
            logger.exception("%s: conversion failed", self.tool_name)
            return {
                "status": "error",
                "errors": [f"STTM to JSON conversion failed: {exc}"],
            }

    def save_json_artifacts(
        self,
        file_name: str | None = None,
        file_path: str | None = None,
        markdown_text: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Alias of convert_sttm_to_json for easier prompt/tool invocation."""
        return self.convert_sttm_to_json(
            file_name=file_name,
            file_path=file_path,
            markdown_text=markdown_text,
            **kwargs,
        )

    def extract_json_artifacts(
        self,
        file_name: str | None = None,
        file_path: str | None = None,
        markdown_text: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Alias of convert_sttm_to_json for easier prompt/tool invocation."""
        return self.convert_sttm_to_json(
            file_name=file_name,
            file_path=file_path,
            markdown_text=markdown_text,
            **kwargs,
        )

    def _resolve_source_file(self, file_name: str | None, file_path: str | None) -> Path | None:
        if file_path:
            candidate = Path(file_path).expanduser()
            if not candidate.is_absolute() and self._data_dir:
                candidate = Path(self._data_dir) / candidate
            if candidate.is_file():
                return candidate
            return None

        if file_name and self._data_dir:
            candidate = Path(self._data_dir) / file_name
            if candidate.is_file():
                return candidate
            return None

        if not self._data_dir:
            return None

        inputs_dir = Path(self._data_dir)
        if not inputs_dir.is_dir():
            return None

        supported_ext = {".xlsx", ".xls", ".csv", ".json", ".txt", ".md", ".xml"}
        candidates: list[Path] = []

        for item in sorted(inputs_dir.iterdir()):
            if not item.is_file():
                continue
            suffix = item.suffix.lower()
            name = item.name.lower()
            if suffix in supported_ext and "sttm" in name:
                candidates.append(item)

        if candidates:
            return candidates[0]

        for item in sorted(inputs_dir.iterdir()):
            if item.is_file() and item.suffix.lower() in {".xlsx", ".xls", ".csv"}:
                return item

        return None

    def _resolve_artifacts_dir(self) -> Path:
        if self._data_dir:
            data_path = Path(self._data_dir)
            session_dir = data_path.parent if data_path.name == "inputs" else data_path
            return session_dir / "artifacts"

        return Path(__file__).resolve().parent / "artifacts"

    def _resolve_session_dir(self) -> Path | None:
        if not self._data_dir:
            return None
        data_path = Path(self._data_dir)
        return data_path.parent if data_path.name == "inputs" else data_path

    def _extract_json_artifacts(
        self,
        session_dir: Path | None,
        markdown_text: str | None,
        kwargs: dict[str, Any],
    ) -> list[tuple[str, Any]]:
        pattern = re.compile(
            r"^###\s+([^\r\n]+?\.json)\s*$\s*```json\s*(.*?)\s*```",
            re.IGNORECASE | re.MULTILINE | re.DOTALL,
        )

        text_candidates: list[str] = []

        if markdown_text and markdown_text.strip():
            text_candidates.append(markdown_text)

        # Accept common payload keys when prompt passes generated markdown content.
        for key in ("text", "content", "output", "agent_output", "markdown"):
            value = kwargs.get(key)
            if isinstance(value, str) and value.strip():
                text_candidates.append(value)

        if session_dir is not None:
            agents_dir = session_dir / "agents"
            if agents_dir.is_dir():
                for output_md in sorted(agents_dir.glob("*/output.md")):
                    try:
                        text_candidates.append(output_md.read_text(encoding="utf-8"))
                    except Exception:
                        logger.warning("%s: unable to read %s", self.tool_name, output_md)

        extracted: list[tuple[str, Any]] = []
        for text in text_candidates:
            for match in pattern.finditer(text):
                file_name = Path(match.group(1).strip()).name
                if not file_name.lower().endswith(".json"):
                    continue

                json_block = match.group(2).strip()
                try:
                    payload = json.loads(json_block)
                except json.JSONDecodeError:
                    continue

                extracted.append((file_name, payload))

        return extracted

    def _next_available_artifact_path(self, artifacts_dir: Path, file_name: str) -> Path:
        candidate = artifacts_dir / file_name
        if not candidate.exists():
            return candidate

        stem = candidate.stem
        suffix = candidate.suffix
        index = 2
        while True:
            retry = artifacts_dir / f"{stem}_{index}{suffix}"
            if not retry.exists():
                return retry
            index += 1
