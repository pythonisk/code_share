"""
idmc_zip_builder.py — The single entry-point tool for LLM agents.

Usage by an LLM agent:
    result = build_idmc_zip(spec_dict)

If validation fails, result contains {"status": "error", "errors": [...]}.
If build succeeds, result contains {"status": "ok", "zip_path": "...", "message": "..."}.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

# Modified imports to point to the idmc_zip_builder package directory
from daan.native_tools.idmc_zip_builder.validator import validate
from daan.native_tools.idmc_zip_builder.compiler import compile_3bin
from daan.native_tools.idmc_zip_builder.packager import package

logger = logging.getLogger(__name__)

# Removed hardcoded _OUTPUT_DIR as it is now evaluated dynamically in build_idmc_zip.


class IdmcZipBuilder:
    """DAAN native tool for building IDMC ZIPs."""

    def __init__(self, data_dir: Optional[str] = None):
        self.tool_name = "IdmcZipBuilder"
        self._data_dir = data_dir
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    def build_idmc_zip(self, spec: dict[str, Any], **kwargs) -> dict[str, Any]:
        """
        Deterministic IDMC ZIP builder tool.

        Accepts a mapping spec dict, validates it, compiles @3.bin,
        packages everything into a final IDMC import ZIP.

        Args:
            spec: Mapping specification dict matching MAPPING_SPEC_SCHEMA.

        Returns:
            dict with either:
              {"status": "ok",    "zip_path": "<absolute path>", "message": "..."}
              {"status": "error", "errors":   ["...", ...]}
        """
        # ── Step 0: Persist raw input for post-mortem debugging ───────
        self._save_tool_input(spec)

        # ── Step 1: Validate ──────────────────────────────────────────
        errors = validate(spec)
        if errors:
            logger.warning("Validation failed with %d error(s).", len(errors))
            return {
                "status": "error",
                "errors": errors,
                "hint": "Fix the errors listed above and resubmit the spec.",
            }

        mapping_name = spec["mapping_name"]

        # ── Step 2: Compile @3.bin ────────────────────────────────────
        try:
            bin3_json = compile_3bin(spec)
        except Exception as exc:
            logger.exception("Compilation failed.")
            return {
                "status": "error",
                "errors": [f"Compilation error: {exc}"],
            }

        # ── Step 2b: Post-compilation integrity check ─────────────────
        integrity_errors = self._check_integrity(bin3_json)
        if integrity_errors:
            logger.warning("Post-compilation integrity check failed with %d error(s).", len(integrity_errors))
            return {
                "status": "error",
                "errors": integrity_errors,
                "hint": "The compiled @3.bin has structural issues. This is likely a compiler bug.",
            }

        # Resolve output directory — write into artifacts/ for universal download
        if self._data_dir:
            data_path = Path(self._data_dir)
            session_dir = data_path.parent if data_path.name == "inputs" else data_path
            output_dir = session_dir / "artifacts"
        else:
            output_dir = Path(__file__).resolve().parent / "idmc_zip_builder" / "output"
            
        output_dir.mkdir(parents=True, exist_ok=True)

        # ── Step 3: Package ZIP ───────────────────────────────────────
        try:
            zip_path = package(mapping_name, bin3_json, output_dir)
        except Exception as exc:
            logger.exception("Packaging failed.")
            return {
                "status": "error",
                "errors": [f"Packaging error: {exc}"],
            }

        msg = f"IDMC import ZIP created: {zip_path}"
        logger.info(msg)

        # Build a brief summary for the LLM
        content = json.loads(bin3_json) if isinstance(bin3_json, str) else bin3_json
        content = content.get("content", content)
        txs = content.get("transformations", [])
        summary = {
            "transformations": [
                {"name": t.get("name"), "class": t.get("$$class"), "fields": len(t.get("fields", []))}
                for t in txs
            ],
            "links": len(content.get("links", [])),
            "parameters": len(content.get("templateParameters", [])),
        }

        return {
            "status": "ok",
            "zip_path": str(zip_path),
            "message": msg,
            "summary": summary,
        }

    def _save_tool_input(self, spec: dict[str, Any]) -> None:
        """Persist the raw tool input JSON for post-mortem debugging."""
        try:
            if self._data_dir:
                data_path = Path(self._data_dir)
                session_dir = data_path.parent if data_path.name == "inputs" else data_path
            else:
                session_dir = Path(__file__).resolve().parent / "idmc_zip_builder" / "output"
            session_dir.mkdir(parents=True, exist_ok=True)
            dest = session_dir / "tool_input.json"
            dest.write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")
            logger.info("Saved tool input to %s", dest)
        except Exception:
            logger.warning("Could not save tool_input.json", exc_info=True)

    def _check_integrity(self, bin3_json) -> list[str]:
        """Post-compilation integrity checks on the compiled @3.bin."""
        import re

        raw = json.loads(bin3_json) if isinstance(bin3_json, str) else bin3_json
        content = raw.get("content", raw)
        text = json.dumps(content)

        errors: list[str] = []

        # 1. Collect all $$IDs and check for duplicates
        all_ids = [int(m) for m in re.findall(r'"\$\$ID"\s*:\s*(\d+)', text)]
        seen = set()
        dupes = set()
        for i in all_ids:
            if i in seen:
                dupes.add(i)
            seen.add(i)
        if dupes:
            errors.append(f"Duplicate $$ID values: {sorted(dupes)}")

        # 2. All ##ID refs must point to valid $$IDs
        all_refs = [int(m) for m in re.findall(r'"##ID"\s*:\s*(\d+)', text)]
        dangling = set(all_refs) - seen
        if dangling:
            errors.append(f"Dangling ##ID references (no matching $$ID): {sorted(dangling)}")

        # 3. Every Target must have at least one field mapping
        for tx in content.get("transformations", []):
            if tx.get("$$class") == 12:  # Target
                mm = tx.get("manualMappings", {})
                ml = mm.get("mappingList", []) if mm else []
                if not ml:
                    errors.append(
                        f"Target '{tx.get('name', '?')}' has no field mappings. "
                        f"IDMC will reject this with 'Field mapping must contain at least one mapped field'."
                    )

        return errors
