"""CRM Cosmos Offering Tool - single-agent Graph RAG offering mapper.

Single dynamic agent owns the whole flow. This tool exposes TWO methods:

  1. extract_keywords_and_candidates  (deterministic, no LLM, no hard filter)
       - Deterministic keyword/phrase extraction from raw CRM rows.
       - CosmosDB graph traversal to retrieve offering candidates.
       - Returns ``graph_confidence`` + raw sub-signals per candidate as a SIGNAL
         only. Candidates are NOT hard-filtered — every keyword-overlapping
         offering is surfaced so the agent's prompt rules decide the threshold.

  2. export_results  (deterministic export of the agent's decision)
       - Receives the agent's recommendation / no_recommendation decision JSON.
       - Writes JSON + CSV (recommended) + CSV (no recommendation) + Excel + Markdown.
       - BOTH lists carry: extracted_keywords, matched_terms, confidence_score, reason.

Agent flow (single dynamic_agent):
  raw CRM rows
    -> Tool call #1: extract_keywords_and_candidates
         * full candidate data is PERSISTED to the session cache on disk
         * the LLM receives a COMPACT view (keywords + candidate signals only)
    -> LLM applies recommendation RULES from the agent prompt, per row
    -> Tool call #2: export_results
         * re-reads the cache and MERGES the agent's per-row decisions by
           row_identifier, so heavy candidate data never round-trips the LLM
         * auto-fills any row the agent dropped into no_recommendation
         * writes JSON + CSV + Excel + Markdown

local_tools:
  "CrmCosmosOfferingTool.extract_keywords_and_candidates"
  "CrmCosmosOfferingTool.export_results"
"""

from __future__ import annotations

import csv
import hashlib
import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from daan.native_tools.crm_cosmos_graph_client import CosmosGraphClient

logger = logging.getLogger(__name__)

# Retrieval tuning ----------------------------------------------------------
# NOTE: min_score is intentionally 0.0 — we do NOT hard-filter candidates here.
# graph_confidence is returned as a SIGNAL; the agent prompt decides the cutoff.
DEFAULT_TOP_N = 5
RETRIEVAL_MIN_SCORE = 0.0

# Small, bounded, EXPLAINABLE bonus added to an offering's confidence when one of
# its matched input terms is corroborated by the offering's capabilities. This is
# the only adjustment on top of raw meaningful-term coverage — there is no
# verbose-offering "richness" bias and no LLM jitter.
CAPABILITY_BONUS = 0.10

# --- Hybrid retrieval (lexical precision + semantic recall) ---------------
# The graph gives EXACT discriminating-term overlap (high precision, but misses
# synonyms / word-forms / paraphrases). Azure OpenAI embeddings add a semantic
# layer that recovers those misses. The two are fused into the SINGLE confidence
# score. If embeddings are unavailable (offline / no config) the tool degrades
# gracefully to lexical-only — the pipeline never breaks.
LEXICAL_WEIGHT = 0.6
SEMANTIC_WEIGHT = 0.4
# A semantic-ONLY offering (no lexical overlap at all) must reach this PER-QUERY
# normalised similarity (0-1) to be surfaced as a candidate. Per-query min-max
# normalisation is used because embedding models (e.g. ada-002) have a high,
# uninformative absolute-cosine baseline — only the RELATIVE ordering matters.
SEMANTIC_CANDIDATE_FLOOR = 0.6
# ...but normalisation ALONE always forces the per-query best to 1.0, even when
# nothing is truly relevant. So a semantic-only candidate must ALSO clear this
# ABSOLUTE raw-cosine floor. Empirically, ada-002 scores genuine matches ≥0.85
# and unrelated text ≤0.78, so 0.82 cleanly separates "real match" from noise and
# lets irrelevant rows fall through to no_recommendation. Tune per embedding
# model with scripts/eval_offering_mapping.py.
SEMANTIC_RAW_FLOOR = 0.82
EMBED_BATCH = 64
EMBED_CACHE_FILENAME = "_crm_offering_embeddings.npz"

# --- Single-term match guardrail (precision) ------------------------------
# A recommendation resting on ONE single-word matched term is semantically thin
# (e.g. an opportunity matching an offering only because both mention "support"
# or "value"). Such a lone token is DEMOTED to no_recommendation UNLESS it is
# corroborated: the term is highly discriminating (rare across offerings), the
# embedding layer independently agrees (RAW cosine, not the per-query normalised
# score — which min-max forces the top candidate to ~1.0 and would nullify the
# gate), the term is named in the offering's capabilities, or there is more than
# one matched term. Multi-word phrase matches are never treated as weak.
SINGLE_TERM_MIN_POWER = 0.95

# Filename for the per-session candidate cache written by Stage A and re-read by
# Stage B. Heavy candidate/capability data is persisted here so it never has to
# round-trip through the LLM between the two tool calls.
CACHE_FILENAME = "_crm_offering_candidates_cache.json"

# --- Strict content-column selection -------------------------------------
# Keyword extraction reads ONLY these business-content columns. Every other
# column (customer, owner, sales person, LOB, stage, dates, etc.) is ignored
# entirely — we never harvest keywords from anything outside this whitelist.
CONTENT_NAME_COLUMNS = {
    "opportunity name", "opp name", "project name", "title",
    "opportunity title", "deal name", "engagement name",
}
CONTENT_DESC_COLUMNS = {
    "opportunity description", "opp description", "description",
    "scope", "scope of work", "summary", "objective", "objectives",
    "details", "notes", "requirement", "requirements", "solution summary",
}
# Safe substrings that always indicate genuine descriptive content.
CONTENT_DESC_SUBSTRINGS = ("description", "scope of", "objective")

# Universal, language/tech-generic terms that are too broad to drive a match on
# their own. This list is deliberately SMALL and STABLE — it is NOT meant to be
# extended per input file. Input-specific / domain-specific "common" terms are
# handled data-drivenly by the graph layer's document-frequency suppression
# (see GENERIC_DF_RATIO in cosmos_graph_client), so we never hand-maintain
# business/staffing word lists here.
GENERIC_KEYWORDS = {
    "application", "applications", "cloud", "data", "digital", "platform",
    "platforms", "process", "processes", "service", "services", "solution",
    "solutions", "system", "systems", "technology", "technologies", "tool",
    "tools",
}

# Stop words dropped from multi-word phrase generation.
_STOP_WORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "in", "into",
    "is", "of", "on", "or", "the", "to", "with", "we", "our", "their", "this",
    "that", "will", "shall", "would", "can", "could", "should", "it", "its",
}

_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9+\-]{1,}")


class CrmCosmosOfferingTool:
    """Single-agent CRM offering mapper: deterministic retrieval + LLM-driven export."""

    def __init__(self, data_dir: Optional[str] = None):
        self._data_dir = data_dir
        self._workspace_root = Path(__file__).resolve().parents[3]
        # Semantic layer state (lazily initialised; see _build_offering_index).
        self._embed_client = None
        self._embed_ready: Optional[bool] = None
        self._embed_model: Optional[str] = None
        self._sem_available = False
        self._sem_ids: List[str] = []
        self._sem_matrix = None
        self._sem_meta: Dict[str, Dict[str, str]] = {}

    # ==================================================================
    # METHOD 1 — deterministic keyword extraction + graph candidates
    # ==================================================================

    def extract_keywords_and_candidates(
        self,
        opportunities: Any,
        top_n: int = DEFAULT_TOP_N,
        cosmos_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Stage A: extract keywords deterministically and retrieve graph candidates.

        This method performs NO recommendation scoring and NO LLM calls. It hands
        the agent everything needed to apply its prompt rules:
          - extracted_keywords / extracted_phrases per row
          - offering candidates with graph_confidence + raw signals (unfiltered)

        Args:
            opportunities: raw CRM rows — list of dicts, dict with a rows/data key,
                           a JSON string, or a path to .json / .csv / .xlsx.
            top_n:         max candidates to surface per row (ranked by overlap).
            cosmos_key:    override CosmosDB Gremlin key (else env GREMLIN_KEY).

        Returns:
            {
              "status": "success",
              "summary": {...},
              "rows": [
                {
                  <all original row fields>,
                  "row_identifier": "...",
                  "evidence_string": "...",
                  "evidence_status": "sufficient|insufficient",
                  "extracted_keywords": [...],
                  "extracted_phrases": [...],
                  "retrieval_status": "candidates_found|no_candidates|"
                                      "insufficient_evidence|no_keyword_evidence",
                  "candidates": [
                    {
                      "offering_id": "...",
                      "name": "...",
                      "category": "...",
                      "graph_confidence": 0.0-100.0,   # SIGNAL only
                      "keyword_overlap_score": 0.0-1.0,
                      "matched_terms": [...],
                      "matched_input_terms": [...],
                      "capabilities": [...],
                      "platforms": [...],
                      "keywords": [...]
                    }
                  ]
                }
              ]
            }
        """
        try:
            rows = self._parse_rows(opportunities)
        except Exception as exc:
            return {"status": "error", "errors": [f"Invalid opportunities input: {exc}"]}

        row_results: List[Dict[str, Any]] = []
        try:
            with CosmosGraphClient(key=cosmos_key) as graph:
                # Build the semantic offering index ONCE per request (cached on
                # disk by content digest). No-op if embeddings are unavailable.
                self._build_offering_index(graph)
                for row in rows:
                    row_results.append(self._process_row(row, graph, top_n))
        except Exception as exc:
            return {"status": "error", "errors": [f"Graph retrieval failed: {exc}"]}

        summary = {
            "total_rows": len(row_results),
            "rows_with_candidates": sum(
                1 for r in row_results if r["retrieval_status"] == "candidates_found"
            ),
            "rows_without_candidates": sum(
                1 for r in row_results if r["retrieval_status"] == "no_candidates"
            ),
            "rows_with_insufficient_evidence": sum(
                1 for r in row_results if r["retrieval_status"] == "insufficient_evidence"
            ),
            "rows_with_no_keywords": sum(
                1 for r in row_results if r["retrieval_status"] == "no_keyword_evidence"
            ),
        }

        # Persist the FULL result to the session artifacts dir so export_results can
        # rebuild heavy candidate data by row_identifier — keeping it off the LLM
        # round-trip. The LLM receives a COMPACT view (enough to apply prompt rules).
        cache_status = self._persist_cache(row_results)
        compact_rows = [self._compact_row(r) for r in row_results]

        return {
            "status": "success",
            "tool": "CrmCosmosOfferingTool.extract_keywords_and_candidates",
            "message": (
                f"Extracted keywords and retrieved candidates for {len(row_results)} CRM rows. "
                "Full candidate data was persisted to the session cache; apply the decision "
                "rules to the compact rows below and pass your per-row decisions to export_results."
            ),
            "summary": summary,
            "cache_status": cache_status,
            "rows": compact_rows,
        }

    # ------------------------------------------------------------------
    # Per-row processing (deterministic)
    # ------------------------------------------------------------------

    def _process_row(
        self,
        row: Dict[str, Any],
        graph: CosmosGraphClient,
        top_n: int,
    ) -> Dict[str, Any]:
        row_id = self._get_row_id(row)
        evidence = self._extract_evidence(row)
        keywords = evidence["extracted_keywords"] + evidence["extracted_phrases"]

        base = {
            **row,
            "row_identifier": row_id,
            "evidence_string": evidence["evidence_string"],
            "evidence_status": evidence["evidence_status"],
            "description_fields_used": evidence["description_fields_used"],
            "name_fields_used": evidence["name_fields_used"],
            "extracted_keywords": evidence["extracted_keywords"],
            "extracted_phrases": evidence["extracted_phrases"],
            "gap_reason": evidence["gap_reason"],
        }

        if evidence["evidence_status"] == "insufficient":
            return {
                **base,
                "retrieval_status": "insufficient_evidence",
                "retrieval_reason": evidence["gap_reason"]
                or "No description or name fields found in the row",
                "candidates": [],
            }

        if not keywords:
            return {
                **base,
                "retrieval_status": "no_keyword_evidence",
                "retrieval_reason": "Only generic or empty terms were extracted from the row",
                "candidates": [],
            }

        # ---- HYBRID RETRIEVAL: lexical (precision) + semantic (recall) ----
        # 1) Lexical candidates from the graph — exact discriminating-term overlap.
        lexical = graph.query_offerings_by_keywords(
            row_keywords=keywords,
            top_n=max(int(top_n), 1),
            min_score=RETRIEVAL_MIN_SCORE,
        )
        lexical_map = {c.get("offering_id"): c for c in lexical if c.get("offering_id")}

        # 2) Semantic scores over ALL offerings (synonyms / word-forms / concepts
        #    that exact matching misses). Empty dict if embeddings unavailable.
        raw_sem = self._semantic_scores(evidence["evidence_string"])
        sem_norm = self._normalise_scores(raw_sem)

        # 3) Candidate id union: every lexical hit + the strongest semantic-only
        #    hits that clear BOTH the per-query relative floor AND the absolute
        #    raw-cosine floor (so irrelevant rows surface nothing semantically).
        cap_ids = max(int(top_n), 1) * 3
        candidate_ids: List[str] = list(lexical_map.keys())
        for oid, norm in sorted(sem_norm.items(), key=lambda kv: kv[1], reverse=True):
            if len(candidate_ids) >= cap_ids:
                break
            if oid in lexical_map:
                continue
            if norm >= SEMANTIC_CANDIDATE_FLOOR and raw_sem.get(oid, 0.0) >= SEMANTIC_RAW_FLOOR:
                candidate_ids.append(oid)

        if not candidate_ids:
            return {
                **base,
                "retrieval_status": "no_candidates",
                "retrieval_reason": "No offering matched the row lexically or semantically",
                "candidates": [],
            }

        enriched_candidates: List[Dict[str, Any]] = []
        for oid in candidate_ids:
            lex = lexical_map.get(oid)
            lexical_score = float(lex.get("score", 0.0)) if lex else 0.0
            semantic_score = float(sem_norm.get(oid, 0.0))
            semantic_raw = float(raw_sem.get(oid, 0.0))
            subgraph = graph.fetch_offering_subgraph(oid)
            capabilities = list(subgraph.get("capabilities", []))[:12]
            matched_inputs = lex.get("matched_input_terms", []) if lex else []
            matched_terms = lex.get("matched_terms", []) if lex else []
            meta = self._sem_meta.get(oid, {})
            name = (lex.get("name") if lex else "") or meta.get("name", "")
            category = (lex.get("category") if lex else "") or meta.get("category", "")
            enriched_candidates.append({
                "offering_id": oid,
                "name": name,
                "category": category,
                # ONE relevance score = fused lexical + semantic (+capability).
                "graph_confidence": self._fused_confidence(
                    lexical_score, semantic_score, matched_inputs, capabilities
                ),
                "keyword_overlap_score": round(lexical_score, 4),
                "semantic_score": round(semantic_score, 4),
                "semantic_raw": round(semantic_raw, 4),
                "term_discriminating_power": lex.get("term_discriminating_power", 1.0) if lex else 1.0,
                "term_specificity_breakdown": lex.get("term_specificity_breakdown", {}) if lex else {},
                # "strong" => safe to recommend; "weak" => single generic-word
                # overlap only, should route to no_recommendation.
                "match_strength": self._assess_match_strength(matched_inputs, capabilities),
                "matched_terms": matched_terms,
                "matched_input_terms": matched_inputs,
                "capabilities": capabilities,
                "platforms": list(subgraph.get("platforms", []))[:12],
                "keywords": list(subgraph.get("keywords", []))[:20],
            })

        # Rank by the fused confidence (best first) and cap to top_n.
        enriched_candidates.sort(
            key=lambda c: c.get("graph_confidence", 0.0), reverse=True
        )
        enriched_candidates = enriched_candidates[: max(int(top_n), 1)]

        return {
            **base,
            "retrieval_status": "candidates_found",
            "retrieval_reason": "Hybrid (lexical + semantic) candidates retrieved",
            "candidates": enriched_candidates,
        }

    # ------------------------------------------------------------------
    # Deterministic evidence + keyword extraction
    # ------------------------------------------------------------------

    def _extract_evidence(self, row: Dict[str, Any]) -> Dict[str, Any]:
        description_fields: List[str] = []
        name_fields: List[str] = []
        parts: List[str] = []

        for key, val in row.items():
            if val in (None, "") or isinstance(val, (list, dict, bool)):
                continue
            text = str(val).strip()
            if not text:
                continue
            lk = " ".join(str(key).strip().lower().split())

            # 1) Genuine descriptive content columns.
            if lk in CONTENT_DESC_COLUMNS or any(s in lk for s in CONTENT_DESC_SUBSTRINGS):
                description_fields.append(key)
                parts.append(text)
            # 2) The opportunity/project name column (exact match only, so that
            #    "Opportunity Owner" / "Opportunity Type" never slip through).
            elif lk in CONTENT_NAME_COLUMNS:
                name_fields.append(key)
                parts.append(text)
            # 3) Every other column is ignored — we only extract from the
            #    whitelisted name + description content above.

        evidence_string = " ".join(parts).strip()
        sufficient = bool((description_fields or name_fields) and evidence_string)

        tokens = [t.lower() for t in _TOKEN_RE.findall(evidence_string)]
        keywords = self._sanitize_row_keywords(tokens)
        phrases = self._extract_phrases(evidence_string)

        return {
            "evidence_string": evidence_string,
            "evidence_status": "sufficient" if sufficient else "insufficient",
            "description_fields_used": description_fields,
            "name_fields_used": name_fields,
            "extracted_keywords": keywords,
            "extracted_phrases": phrases,
            "gap_reason": "" if sufficient else "No description or name fields found in the row",
        }

    def _sanitize_row_keywords(self, tokens: List[str]) -> List[str]:
        cleaned: List[str] = []
        seen = set()
        for token in tokens:
            norm = " ".join(str(token).strip().lower().split())
            if not norm or norm in seen:
                continue
            # Drop stop words and overly-generic terms (data, platform, cloud, ...)
            # so they never enter keyword matching. These words appear across a
            # huge share of offerings and only pollute matched_terms, forcing weak
            # matches on rows whose only "signal" is a ubiquitous word. Removing
            # them upstream keeps matched_terms clean and lets genuinely
            # discriminating tokens / semantic similarity drive the recommendation.
            if norm in _STOP_WORDS or norm in GENERIC_KEYWORDS:
                continue
            seen.add(norm)
            cleaned.append(norm)
        return cleaned

    def _extract_phrases(self, text: str, max_phrases: int = 15) -> List[str]:
        words = [w.lower() for w in _TOKEN_RE.findall(text)]
        grams: List[str] = []
        seen = set()
        for n in (2, 3):
            for i in range(len(words) - n + 1):
                window = words[i:i + n]
                # Skip phrases that start/end on a stop word or are all generic.
                if window[0] in _STOP_WORDS or window[-1] in _STOP_WORDS:
                    continue
                if all(w in GENERIC_KEYWORDS or w in _STOP_WORDS for w in window):
                    continue
                gram = " ".join(window)
                if gram in seen:
                    continue
                seen.add(gram)
                grams.append(gram)
        return grams[:max_phrases]

    def _fused_confidence(
        self,
        lexical_score: float,
        semantic_score: float,
        matched_input_terms: List[str],
        capabilities: List[str],
    ) -> float:
        """ONE deterministic relevance score (0-100) — the fused confidence.

            confidence = LEXICAL_WEIGHT  * lexical_overlap   (exact discriminating
                                                              term coverage, 0-1)
                       + SEMANTIC_WEIGHT * semantic_sim       (per-query normalised
                                                              embedding similarity, 0-1)
                       + CAPABILITY_BONUS                     (matched term also
                                                              named in a capability)

        When embeddings are unavailable the score degrades to PURE lexical so the
        pipeline never regresses. This single number ranks candidates, drives the
        top-3 cut, and is surfaced as confidence_score — there is no separate
        "graph score" vs "confidence score".
        """
        lex = max(0.0, float(lexical_score or 0.0))
        sem = max(0.0, float(semantic_score or 0.0))
        if self._sem_available:
            confidence = LEXICAL_WEIGHT * lex + SEMANTIC_WEIGHT * sem
        else:
            confidence = lex

        # Capability corroboration (exact-token for single words, substring for
        # phrases) — a small, bounded, explainable boost.
        matched = [str(t).strip().lower() for t in (matched_input_terms or []) if str(t).strip()]
        cap_names = [str(c).lower() for c in (capabilities or [])]
        cap_tokens: set = set()
        for name in cap_names:
            cap_tokens.update(name.split())
        corroborated = any(
            (term in cap_tokens) if " " not in term
            else any(term in name for name in cap_names)
            for term in matched
        )
        if corroborated:
            confidence = min(1.0, confidence + CAPABILITY_BONUS)

        return max(0.0, min(100.0, round(confidence * 100, 1)))

    # ------------------------------------------------------------------
    # Semantic layer — Azure OpenAI embeddings (offline-safe fallback)
    # ------------------------------------------------------------------

    def _load_embed_config(self) -> Dict[str, Any]:
        """Read the azure_openai embeddings block from config/llm_config.yml."""
        try:
            import yaml
            cfg_path = self._workspace_root / "config" / "llm_config.yml"
            data = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
            prov = (((data.get("embeddings") or {}).get("providers") or {})
                    .get("azure_openai")) or {}
            if prov.get("api_key") and prov.get("endpoint"):
                return prov
        except Exception as exc:  # pragma: no cover - config/optional dep issues
            logger.debug("embedding config load failed: %s", exc)
        return {}

    def _ensure_embedder(self):
        """Lazily build the Azure embeddings client. Returns the client or None."""
        if self._embed_ready is not None:
            return self._embed_client
        try:
            cfg = self._load_embed_config()
            if not cfg:
                raise RuntimeError("no azure_openai embeddings config")
            from openai import AzureOpenAI
            self._embed_client = AzureOpenAI(
                api_key=cfg["api_key"],
                api_version=cfg.get("api_version", "2024-08-01-preview"),
                azure_endpoint=cfg["endpoint"],
            )
            self._embed_model = (
                cfg.get("deployment_name") or cfg.get("model") or "text-embedding-ada-002"
            )
            self._embed_ready = True
        except Exception as exc:
            logger.warning("Semantic embeddings unavailable (%s); using lexical-only.", exc)
            self._embed_client = None
            self._embed_ready = False
        return self._embed_client

    def _embed_texts(self, texts: List[str]):
        """Return an L2-normalised numpy matrix of embeddings (or None on failure)."""
        client = self._ensure_embedder()
        if client is None or not texts:
            return None
        try:
            import numpy as np
            vectors: List[List[float]] = []
            for i in range(0, len(texts), EMBED_BATCH):
                batch = [t if t and t.strip() else " " for t in texts[i:i + EMBED_BATCH]]
                resp = client.embeddings.create(model=self._embed_model, input=batch)
                vectors.extend(d.embedding for d in resp.data)
            arr = np.asarray(vectors, dtype="float32")
            norms = np.linalg.norm(arr, axis=1, keepdims=True)
            norms[norms == 0] = 1.0
            return arr / norms
        except Exception as exc:
            logger.warning("Embedding call failed (%s); disabling semantic layer.", exc)
            self._sem_available = False
            return None

    def _build_offering_index(self, graph: CosmosGraphClient) -> None:
        """Embed every offering once (name+category+keywords); cache by digest.

        Populates self._sem_ids / _sem_matrix / _sem_meta and sets
        self._sem_available. Safe no-op when embeddings are unavailable.
        """
        self._sem_available = False
        self._sem_ids = []
        self._sem_matrix = None
        self._sem_meta = {}
        if self._ensure_embedder() is None:
            return
        try:
            offerings = graph._fetch_offering_keyword_map()
        except Exception as exc:
            logger.warning("offering index fetch failed: %s", exc)
            return
        if not offerings:
            return

        combined: Dict[str, Dict[str, str]] = {}
        for o in offerings:
            oid = o.get("offering_id")
            if not oid:
                continue
            kw = str(o.get("keyword_value", "") or "")
            if oid in combined:
                combined[oid]["text"] += " " + kw
            else:
                name = str(o.get("offering_name", "") or "")
                category = str(o.get("category", "") or "")
                combined[oid] = {
                    "name": name,
                    "category": category,
                    "text": f"{name} {category} {kw}".strip(),
                }
        ids = list(combined.keys())
        texts = [combined[i]["text"] for i in ids]
        if not ids:
            return

        import numpy as np
        digest = hashlib.sha1(("||".join(texts)).encode("utf-8")).hexdigest()
        cache_file = self._get_output_dir() / EMBED_CACHE_FILENAME
        matrix = None
        if cache_file.exists():
            try:
                data = np.load(cache_file, allow_pickle=True)
                if str(data["digest"]) == digest and list(data["ids"]) == ids:
                    matrix = data["matrix"]
            except Exception:
                matrix = None
        if matrix is None:
            matrix = self._embed_texts(texts)
            if matrix is None:
                return
            try:
                np.savez(
                    cache_file,
                    digest=digest,
                    ids=np.array(ids, dtype=object),
                    matrix=matrix,
                )
            except Exception as exc:
                logger.debug("embedding cache save failed: %s", exc)

        self._sem_ids = ids
        self._sem_matrix = matrix
        self._sem_meta = combined
        self._sem_available = True

    def _semantic_scores(self, query_text: str) -> Dict[str, float]:
        """Raw cosine similarity of the opportunity text vs every offering."""
        if not self._sem_available or not query_text:
            return {}
        qm = self._embed_texts([query_text])
        if qm is None:
            return {}
        sims = self._sem_matrix @ qm[0]
        return {oid: float(sims[i]) for i, oid in enumerate(self._sem_ids)}

    @staticmethod
    def _normalise_scores(scores: Dict[str, float]) -> Dict[str, float]:
        """Per-query min-max normalise so a model's absolute-cosine baseline
        (which is high and uninformative for ada-002) does not dominate."""
        if not scores:
            return {}
        vals = list(scores.values())
        lo, hi = min(vals), max(vals)
        if hi - lo < 1e-9:
            return {k: 1.0 for k in scores}
        return {k: (v - lo) / (hi - lo) for k, v in scores.items()}

    def _assess_match_strength(
        self, matched_input_terms: List[str], capabilities: List[str]
    ) -> str:
        """Classify a candidate match as 'strong' or 'weak'.

        STRONG when EITHER:
          - at least one matched input term is a multi-word phrase, OR
          - there are >=2 distinct matched input terms AND at least one of them
            overlaps the offering's capabilities.
        Otherwise WEAK (a single isolated single-word overlap), which must NOT
        be surfaced as a recommendation.
        """
        terms = [str(t).strip().lower() for t in (matched_input_terms or []) if str(t).strip()]
        distinct = list(dict.fromkeys(terms))
        if not distinct:
            return "weak"

        # Multi-word phrase match is always strong evidence.
        if any(" " in t for t in distinct):
            return "strong"

        # Two or more distinct terms with at least one capability overlap.
        if len(distinct) >= 2:
            caps = [c.lower() for c in (capabilities or [])]
            if any(any(t in c for c in caps) for t in distinct):
                return "strong"
            # >=3 distinct terms is itself strong corroborating evidence.
            if len(distinct) >= 3:
                return "strong"

        return "weak"

    def _is_weak_single_term_match(self, candidate: Dict[str, Any]) -> bool:
        """Precision guardrail: True when a recommendation rests on ONE weak
        single-word term and should be demoted to no_recommendation.

        The match is KEPT (returns False) when ANY of these hold:
          - there are 2+ distinct matched input terms, OR
          - at least one matched term is a multi-word phrase, OR
          - the structural match_strength is already "strong", OR
          - the lone term is named in the offering's capabilities (corroborated), OR
          - the lone term is highly discriminating (power >= SINGLE_TERM_MIN_POWER,
            i.e. a rare/specific token such as "mdm" / "inventory"), OR
          - the semantic layer independently agrees — measured on the ABSOLUTE raw
            cosine (semantic_raw >= SEMANTIC_RAW_FLOOR), NOT the per-query
            normalised score, which min-max forces to ~1.0 and would let every
            row pass.
        Only a lone, low-power, uncorroborated single-word token is demoted — the
        exact case (matching only on "support" / "value") flagged as too thin.
        """
        terms = [
            str(t).strip().lower()
            for t in (candidate.get("matched_input_terms") or [])
            if str(t).strip()
        ]
        distinct = list(dict.fromkeys(terms))
        # Not a lone single-word term (incl. semantic-only rows) → keep.
        if len(distinct) != 1 or " " in distinct[0]:
            return False

        term = distinct[0]
        # Already strong (e.g. capability-corroborated by Stage A) → keep.
        if str(candidate.get("match_strength", "")).lower() == "strong":
            return False
        # Lone term explicitly named in the offering's capabilities → keep.
        cap_names = [str(c).lower() for c in (candidate.get("capabilities") or [])]
        if any(term in name for name in cap_names):
            return False
        # Rare/specific token → still a legitimate signal.
        try:
            power = float(candidate.get("term_discriminating_power", 0.0) or 0.0)
        except (TypeError, ValueError):
            power = 0.0
        if power >= SINGLE_TERM_MIN_POWER:
            return False
        # Embedding layer independently supports the concept — ABSOLUTE raw cosine
        # (older caches without semantic_raw fall back to 0.0 → no false rescue).
        try:
            sem_raw = float(candidate.get("semantic_raw", 0.0) or 0.0)
        except (TypeError, ValueError):
            sem_raw = 0.0
        if sem_raw >= SEMANTIC_RAW_FLOOR:
            return False
        return True

    # ------------------------------------------------------------------
    # Cross-call cache (persist Stage-A, re-read in Stage-B)
    # ------------------------------------------------------------------

    def _cache_path(self) -> Path:
        return self._get_output_dir() / CACHE_FILENAME

    def _persist_cache(self, row_results: List[Dict[str, Any]]) -> str:
        """Write the full Stage-A result keyed by row_identifier to the session dir."""
        try:
            cache: Dict[str, Any] = {}
            for idx, row in enumerate(row_results):
                rid = str(row.get("row_identifier") or f"row_{idx}")
                cache[rid] = row
            path = self._cache_path()
            path.write_text(
                json.dumps({"rows": cache}, indent=2, default=str),
                encoding="utf-8",
            )
            return f"persisted {len(cache)} rows to {path.name}"
        except Exception as exc:
            logger.warning("Failed to persist candidate cache: %s", exc)
            return f"cache_persist_failed: {exc}"

    def _load_cache(self) -> Dict[str, Dict[str, Any]]:
        """Re-read the Stage-A cache. Returns {} when absent (back-compatible)."""
        try:
            path = self._cache_path()
            if not path.exists():
                return {}
            payload = json.loads(path.read_text(encoding="utf-8"))
            rows = payload.get("rows", {})
            return rows if isinstance(rows, dict) else {}
        except Exception as exc:
            logger.warning("Failed to load candidate cache: %s", exc)
            return {}

    # ------------------------------------------------------------------
    # Compact LLM view + cache merge
    # ------------------------------------------------------------------

    def _compact_row(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """Trim a full Stage-A row to the minimum the agent needs to apply rules."""
        compact: Dict[str, Any] = {
            "row_identifier": row.get("row_identifier", ""),
            "evidence_status": row.get("evidence_status", ""),
            "retrieval_status": row.get("retrieval_status", ""),
            "retrieval_reason": row.get("retrieval_reason", ""),
            "extracted_keywords": row.get("extracted_keywords", []),
            "extracted_phrases": row.get("extracted_phrases", []),
            "candidates": [self._compact_candidate(c) for c in row.get("candidates", [])],
        }
        # Carry a couple of human-readable identifiers if present.
        for key in ("Opportunity Id", "opportunity_id", "Opportunity Name", "name", "title"):
            if key in row and key not in compact:
                compact[key] = row[key]
        return compact

    def _compact_candidate(self, candidate: Dict[str, Any]) -> Dict[str, Any]:
        """Drop heavy lists (platforms, full keyword/subgraph) for the LLM view."""
        # Format term specificity for readability: e.g. {"mdm": 0.95, "data": 0.3} → "mdm=0.95, data=0.3"
        breakdown = candidate.get("term_specificity_breakdown", {})
        if breakdown:
            breakdown_str = ", ".join(f"{t}={v}" for t, v in breakdown.items())
        else:
            breakdown_str = ""
        return {
            "offering_id": candidate.get("offering_id", ""),
            "name": candidate.get("name", ""),
            "category": candidate.get("category", ""),
            "graph_confidence": candidate.get("graph_confidence", 0.0),
            "keyword_overlap_score": candidate.get("keyword_overlap_score", 0.0),
            "semantic_score": candidate.get("semantic_score", 0.0),
            "semantic_raw": candidate.get("semantic_raw", 0.0),
            "term_discriminating_power": candidate.get("term_discriminating_power", 1.0),
            "term_specificity_breakdown": breakdown_str,
            "matched_terms": candidate.get("matched_terms", []),
            "matched_input_terms": candidate.get("matched_input_terms", []),
            # Keep a short capability sample so the agent can judge capability overlap.
            "capabilities": list(candidate.get("capabilities", []))[:6],
        }

    def _enrich_from_cache(
        self,
        row: Dict[str, Any],
        is_no_reco: bool,
        cache: Dict[str, Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Rebuild heavy fields for a decision row from the Stage-A cache by id."""
        if not isinstance(row, dict):
            row = {"raw": str(row)}
        rid = str(row.get("row_identifier") or self._get_row_id(row) or "")
        merged = dict(row)
        merged["row_identifier"] = rid

        cached = cache.get(rid) or {}
        if not cached:
            return merged

        # Deterministic keywords from Stage A are authoritative.
        if cached.get("extracted_keywords"):
            merged["extracted_keywords"] = cached["extracted_keywords"]

        # Bring back original row columns the LLM may have dropped.
        for key, val in cached.items():
            if key == "candidates":
                continue
            merged.setdefault(key, val)

        if not is_no_reco:
            chosen_id = str(merged.get("offering_id") or "").strip()
            chosen_name = str(merged.get("recommended_offering") or "").strip()
            candidate = self._find_candidate(cached.get("candidates", []), chosen_id, chosen_name)
            if candidate:
                merged.setdefault("recommended_offering", candidate.get("name", ""))
                merged["offering_id"] = candidate.get("offering_id", merged.get("offering_id", ""))
                merged.setdefault("category", candidate.get("category", ""))
                if not merged.get("matched_terms"):
                    merged["matched_terms"] = candidate.get("matched_terms", [])
                merged.setdefault("matched_input_terms", candidate.get("matched_input_terms", []))
                merged.setdefault("graph_confidence", candidate.get("graph_confidence", 0.0))
                # Deterministic confidence: the displayed confidence_score IS the
                # tool-computed graph_confidence. We OVERWRITE whatever the LLM
                # emitted so the number is always reproducible and auditable.
                merged["confidence_score"] = candidate.get("graph_confidence", 0.0)
                # Precision guardrail (A): flag weak single-term matches so the
                # exporter can demote them to no_recommendation.
                if self._is_weak_single_term_match(candidate):
                    merged["_demote_weak_single_term"] = True
        else:
            # For no_recommendation rows, surface the CLOSEST candidate offering
            # (highest graph_confidence) for reference — so a non-recommendable
            # opportunity still shows WHICH offering it came nearest to — plus a
            # deterministic reason explaining why it was not recommended.
            candidates = cached.get("candidates", [])
            if candidates:
                best = max(
                    candidates,
                    key=lambda c: float(c.get("graph_confidence", 0.0) or 0.0),
                )
                merged["best_candidate_confidence"] = float(
                    best.get("graph_confidence", 0.0) or 0.0
                )
                merged["closest_offering"] = best.get("name", "")
                merged["closest_offering_id"] = best.get("offering_id", "")
                merged["closest_category"] = best.get("category", "")
                merged.setdefault(
                    "closest_matched_terms", best.get("matched_input_terms", [])
                )
            else:
                merged.setdefault("best_candidate_confidence", 0.0)
            # Always attach a reason (generate one when the agent didn't supply it).
            if not str(merged.get("reason") or "").strip():
                merged["reason"] = self._no_reco_reason(cached, candidates)
        return merged

    def _find_candidate(
        self,
        candidates: List[Dict[str, Any]],
        offering_id: str,
        offering_name: str,
    ) -> Optional[Dict[str, Any]]:
        oid = (offering_id or "").strip().lower()
        oname = (offering_name or "").strip().lower()
        for cand in candidates:
            if oid and str(cand.get("offering_id", "")).strip().lower() == oid:
                return cand
        for cand in candidates:
            if oname and str(cand.get("name", "")).strip().lower() == oname:
                return cand
        return None

    def _no_reco_reason(
        self,
        cached: Dict[str, Any],
        candidates: List[Dict[str, Any]],
    ) -> str:
        """Deterministic explanation for why a row got no recommendation."""
        status = str(cached.get("retrieval_status") or "").strip()
        if status == "insufficient_evidence":
            return "No usable opportunity name or description text to analyse."
        if status == "no_keyword_evidence":
            return "Only generic or empty terms were extracted; nothing specific to match on."
        if not candidates:
            return "No offering matched the opportunity lexically or semantically."
        best = max(
            candidates, key=lambda c: float(c.get("graph_confidence", 0.0) or 0.0)
        )
        name = best.get("name") or "the closest offering"
        conf = round(float(best.get("graph_confidence", 0.0) or 0.0), 1)
        terms = [str(t) for t in (best.get("matched_input_terms") or []) if str(t).strip()]
        if terms:
            return (
                f"Closest offering '{name}' matched only on {terms} "
                f"(confidence {conf}) — too weak to recommend."
            )
        return (
            f"Closest offering '{name}' is only a weak semantic match "
            f"(confidence {conf}) — below the recommendation bar."
        )

    # ==================================================================
    # METHOD 2 — export the agent's recommendation decision
    # ==================================================================

    def export_results(
        self,
        decisions: Any,
        output_name_prefix: str = "crm_offering_mapping",
    ) -> Dict[str, Any]:
        """Stage B: export the agent's decision to JSON/CSV/Excel/Markdown.

        Args:
            decisions: agent output — dict or JSON string with keys
                       "recommended_mappings" and "no_recommendation" (lists of rows).
            output_name_prefix: prefix for artifact filenames.

        Both lists are normalised so every row carries extracted_keywords,
        matched_terms, confidence_score and reason before writing.
        """
        try:
            data = self._parse_json(decisions) if isinstance(decisions, str) else decisions
        except Exception as exc:
            return {"status": "error", "errors": [f"Invalid decisions input: {exc}"]}

        if not isinstance(data, dict):
            return {"status": "error", "errors": ["decisions must be a JSON object"]}

        recommended = list(data.get("recommended_mappings") or data.get("recommended") or [])
        no_reco = list(data.get("no_recommendation") or data.get("no_recommendations") or [])

        # Merge the agent's compact decisions with the full Stage-A cache by
        # row_identifier. Heavy candidate fields (matched_terms, capabilities,
        # category, extracted_keywords, original row columns) are rebuilt from disk
        # so they never had to round-trip through the LLM.
        cache = self._load_cache()
        recommended = [self._enrich_from_cache(r, is_no_reco=False, cache=cache) for r in recommended]
        no_reco = [self._enrich_from_cache(r, is_no_reco=True, cache=cache) for r in no_reco]

        # Precision guardrail (A): demote weak single-term recommendations. A
        # recommendation resting on ONE low-power, uncorroborated single-word
        # token is too thin to surface. Dropping it here lets the coverage
        # safeguard below re-add the opportunity to no_recommendation with a
        # deterministic "closest offering matched only on [term] — too weak" reason.
        recommended = [
            r for r in recommended
            if not r.pop("_demote_weak_single_term", False)
        ]

        # Safeguard: guarantee every cached row appears exactly once. Any row the
        # agent dropped is auto-added to no_recommendation so nothing is silently lost.
        covered = {
            str(r.get("row_identifier"))
            for r in recommended + no_reco
            if r.get("row_identifier")
        }
        for rid, cached in cache.items():
            if str(rid) not in covered:
                # Leave reason empty so _enrich_from_cache fills a real,
                # candidate-based explanation (closest offering / why no match).
                no_reco.append(
                    self._enrich_from_cache(
                        {
                            "row_identifier": rid,
                            "mapping_reason": "unclassified_autofilled",
                        },
                        is_no_reco=True,
                        cache=cache,
                    )
                )

        recommended = [self._normalise_row(r, is_no_reco=False) for r in recommended]
        no_reco = [self._normalise_row(r, is_no_reco=True) for r in no_reco]

        # Deterministically rank multiple offerings within the SAME opportunity by
        # confidence_score (desc) and assign recommendation_rank 1..N. Cap each row
        # to the top 3 offerings so we never emit more than 3 per opportunity.
        recommended = self._rank_and_cap_recommendations(recommended, max_per_row=3)

        # Preserve original column order across both lists.
        seen_cols: Dict[str, None] = {}
        for r in recommended + no_reco:
            for k in r.keys():
                if k not in seen_cols:
                    seen_cols[k] = None
        original_columns = list(seen_cols.keys())

        total_rows = len({r.get("row_identifier") for r in recommended + no_reco if r.get("row_identifier")}) \
            or (len(recommended) + len(no_reco))
        summary = self._build_summary(total_rows, recommended, no_reco)

        recommended = [self._reorder_columns(r, original_columns, is_no_reco=False) for r in recommended]
        no_reco = [self._reorder_columns(r, original_columns, is_no_reco=True) for r in no_reco]

        try:
            artifacts = self._export_artifacts(recommended, no_reco, summary, output_name_prefix)
        except Exception as exc:
            return {"status": "error", "errors": [f"Export failed: {exc}"]}

        offering_counts: Dict[str, int] = {}
        for rec in recommended:
            offering = rec.get("recommended_offering", "Unknown")
            offering_counts[offering] = offering_counts.get(offering, 0) + 1

        return {
            "status": "success",
            "tool": "CrmCosmosOfferingTool.export_results",
            "message": f"Exported {len(recommended)} recommendations and {len(no_reco)} no-recommendation rows",
            "summary": {
                "total_opportunities_analyzed": summary["total_rows"],
                "opportunities_with_recommendations": summary["rows_with_recommendations"],
                "total_recommendations_generated": summary["total_recommendations"],
                "recommendation_rate": f"{summary['recommendation_rate_percent']}%",
                "average_confidence": summary["average_confidence"],
                "opportunities_without_recommendations": summary["no_recommendation_count"],
            },
            "offering_breakdown": [
                {"offering": k, "recommendation_count": v}
                for k, v in sorted(offering_counts.items(), key=lambda x: x[1], reverse=True)
            ],
            "artifacts_location": artifacts,
        }

    def _rank_and_cap_recommendations(
        self,
        recommended: List[Dict[str, Any]],
        max_per_row: int = 3,
    ) -> List[Dict[str, Any]]:
        """Group recommendations by opportunity, rank by confidence, cap to top-N.

        The agent emits one object per offering (multiple share a row_identifier).
        We deterministically:
          - order a row's offerings by confidence_score (descending),
          - keep only the best `max_per_row`,
          - stamp recommendation_rank = 1, 2, 3 ...
        so the rank is always correct regardless of what the LLM returned.
        """
        def _conf(row: Dict[str, Any]) -> float:
            try:
                return float(row.get("confidence_score", 0.0) or 0.0)
            except (TypeError, ValueError):
                return 0.0

        grouped: Dict[str, List[Dict[str, Any]]] = {}
        order: List[str] = []
        for row in recommended:
            rid = str(row.get("row_identifier", ""))
            if rid not in grouped:
                grouped[rid] = []
                order.append(rid)
            grouped[rid].append(row)

        ranked: List[Dict[str, Any]] = []
        for rid in order:
            # De-duplicate by offering, keeping the highest-confidence variant.
            best_by_offering: Dict[str, Dict[str, Any]] = {}
            for off in grouped[rid]:
                key = str(off.get("offering_id") or off.get("recommended_offering") or id(off))
                existing = best_by_offering.get(key)
                if existing is None or _conf(off) > _conf(existing):
                    best_by_offering[key] = off

            unique = sorted(best_by_offering.values(), key=_conf, reverse=True)
            for idx, off in enumerate(unique[:max_per_row], start=1):
                off["recommendation_rank"] = idx
                ranked.append(off)

        return ranked

    def _normalise_row(self, row: Dict[str, Any], is_no_reco: bool) -> Dict[str, Any]:
        """Guarantee required reporting fields exist on every row."""
        if not isinstance(row, dict):
            row = {"raw": str(row)}
        normalised = dict(row)
        normalised.setdefault("row_identifier", self._get_row_id(normalised))
        normalised.setdefault("extracted_keywords", normalised.get("matched_terms", []) or [])
        normalised.setdefault("matched_terms", [])
        normalised.setdefault("term_specificity_breakdown", "")
        normalised.setdefault("recommended_offering", "")
        normalised.setdefault("offering_id", "")
        normalised.setdefault("category", "")
        try:
            normalised["confidence_score"] = round(float(normalised.get("confidence_score", 0.0)), 1)
        except (TypeError, ValueError):
            normalised["confidence_score"] = 0.0
        normalised.setdefault("confidence_label", "none")
        normalised.setdefault("reason", "")
        if is_no_reco:
            normalised.setdefault("mapping_reason", "")
            normalised.setdefault("extra_info_needed", "")
            normalised.setdefault("recommendation_rank", 0)
            normalised.setdefault("closest_offering", "")
            normalised.setdefault("closest_offering_id", "")
            normalised.setdefault("closest_category", "")
            normalised.setdefault("closest_matched_terms", [])
            # For no_recommendation rows, add best_candidate_confidence (highest available)
            try:
                best_conf = float(normalised.get("best_candidate_confidence", 0.0))
                normalised["best_candidate_confidence"] = round(best_conf, 1)
            except (TypeError, ValueError):
                normalised.setdefault("best_candidate_confidence", 0.0)
        else:
            normalised.setdefault("mapping_reason", "")
            normalised.setdefault("recommendation_rank", 0)
        return normalised

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------

    def _build_summary(
        self,
        total: int,
        recommended: List[Dict],
        no_reco: List[Dict],
    ) -> Dict[str, Any]:
        row_ids = {r.get("row_identifier") for r in recommended if r.get("row_identifier")}
        scores = [r.get("confidence_score", 0) for r in recommended]
        return {
            "total_rows": total,
            "rows_with_recommendations": len(row_ids),
            "total_recommendations": len(recommended),
            "no_recommendation_count": len(no_reco),
            "recommendation_rate_percent": round(len(row_ids) / total * 100, 2) if total else 0,
            "average_confidence": round(sum(scores) / len(scores), 2) if scores else 0,
        }

    def _reorder_columns(
        self,
        row: Dict[str, Any],
        original_columns: List[str],
        is_no_reco: bool = False,
    ) -> Dict[str, Any]:
        """Produce a clean, fixed column layout for the output tables.

        Layout:
          1. A curated set of ORIGINAL CRM columns (input data) first.
          2. The extracted / decision columns (keywords, matched terms, offering,
             confidence, reasons).
        All other original columns and internal diagnostic fields are dropped.
        """
        # Curated original CRM columns to keep, in display order. Matched
        # case-insensitively against the row's actual column names.
        keep_original = [
            "Opportunity Id", "Opportunity Name", "Opportunity Description",
            "Name", "Customer Group",
        ]

        # Extracted / decision columns, in display order (after original data).
        if is_no_reco:
            decision_fields = [
                "extracted_keywords", "extracted_phrases",
                "closest_offering", "closest_offering_id", "closest_category",
                "closest_matched_terms", "term_specificity_breakdown",
                "best_candidate_confidence",
                "reason", "extra_info_needed",
            ]
        else:
            decision_fields = [
                "extracted_keywords", "extracted_phrases", "matched_terms", "matched_input_terms",
                "term_specificity_breakdown",
                "recommended_offering", "offering_id", "category",
                "confidence_score", "mapping_reason", "recommendation_rank",
            ]

        # Build a case-insensitive lookup of the row's keys.
        lower_map = {str(k).strip().lower(): k for k in row.keys()}

        ordered: Dict[str, Any] = {}
        # 1) curated original CRM columns (input data) first
        for col in keep_original:
            actual = lower_map.get(col.strip().lower())
            if actual is not None and actual not in ordered:
                ordered[col] = row[actual]
        # 2) extracted / decision columns
        for field in decision_fields:
            if field in row and field not in ordered:
                ordered[field] = row[field]
        return ordered

    def _get_output_dir(self) -> Path:
        if self._data_dir:
            data_path = Path(self._data_dir)
            session_dir = data_path.parent if data_path.name.lower() in ("inputs", "input") else data_path
            out = session_dir / "artifacts"
        else:
            out = Path(__file__).parent / "output"
        out.mkdir(parents=True, exist_ok=True)
        return out

    def _export_artifacts(
        self,
        recommended: List[Dict],
        no_reco: List[Dict],
        summary: Dict,
        prefix: str,
    ) -> Dict[str, Any]:
        out = self._get_output_dir()
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        base = f"{prefix}_{ts}"

        (out / f"{base}.json").write_text(
            json.dumps(
                {"recommended_mappings": recommended, "no_recommendation": no_reco, "summary": summary},
                indent=2,
            ),
            encoding="utf-8",
        )
        self._write_csv(out / f"{base}_recommended.csv", recommended)
        self._write_csv(out / f"{base}_no_recommendation.csv", no_reco)
        self._write_excel(out / f"{base}.xlsx", recommended, no_reco, summary)
        self._write_markdown(out / f"{base}.md", recommended, no_reco, summary)

        try:
            folder = str(out.relative_to(self._workspace_root))
        except ValueError:
            folder = str(out)
        return {
            "folder": folder,
            "files_generated": [
                f"{base}.json",
                f"{base}_recommended.csv",
                f"{base}_no_recommendation.csv",
                f"{base}.xlsx",
                f"{base}.md",
            ],
        }

    def _write_csv(self, path: Path, rows: List[Dict]) -> None:
        if not rows:
            path.write_text("", encoding="utf-8")
            return
        fieldnames = list(rows[0].keys())
        seen = set(fieldnames)
        for row in rows[1:]:
            for k in row.keys():
                if k not in seen:
                    fieldnames.append(k)
                    seen.add(k)
        with path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow({k: self._scalar(v) for k, v in row.items()})

    def _write_excel(
        self,
        path: Path,
        rec: List[Dict],
        no_rec: List[Dict],
        summary: Dict,
    ) -> None:
        from openpyxl import Workbook

        def _unified_headers(rows: List[Dict]) -> List[str]:
            seen: Dict[str, None] = {}
            for row in rows:
                for k in row.keys():
                    if k not in seen:
                        seen[k] = None
            return list(seen.keys())

        wb = Workbook()
        ws1 = wb.active
        ws1.title = "Recommended"
        if rec:
            headers = _unified_headers(rec)
            ws1.append(headers)
            for row in rec:
                ws1.append([self._scalar(row.get(h, "")) for h in headers])

        ws2 = wb.create_sheet("No Recommendation")
        if no_rec:
            headers = _unified_headers(no_rec)
            ws2.append(headers)
            for row in no_rec:
                ws2.append([self._scalar(row.get(h, "")) for h in headers])

        ws3 = wb.create_sheet("Summary")
        ws3.append(["Metric", "Value"])
        for k, v in summary.items():
            ws3.append([k, v])
        wb.save(path)

    def _write_markdown(
        self,
        path: Path,
        rec: List[Dict],
        no_rec: List[Dict],
        summary: Dict,
    ) -> None:
        lines = [
            "# CRM Offering Mapping Results (Single-Agent Graph RAG)",
            "",
            "## Summary",
            "",
            "| Metric | Value |",
            "|--------|------:|",
        ]
        lines.extend(f"| {k} | {v} |" for k, v in summary.items())
        lines += ["", "## Recommended Mappings", "", f"Total: {len(rec)}", ""]
        lines += ["", "## No Recommendations", "", f"Total: {len(no_rec)}", ""]
        path.write_text("\n".join(lines), encoding="utf-8")

    def _scalar(self, val: Any) -> Any:
        return json.dumps(val) if isinstance(val, (list, dict)) else val

    # ------------------------------------------------------------------
    # Input parsing (list / dict / JSON string / .json / .csv / .xlsx path)
    # ------------------------------------------------------------------

    def _parse_rows(self, data: Any) -> List[Dict[str, Any]]:
        if isinstance(data, str):
            path = Path(data)
            
            # Try exact path first
            if path.exists():
                if path.suffix.lower() in (".xlsx", ".xls"):
                    return self._read_excel_file(path)
                if path.suffix.lower() == ".csv":
                    return self._read_csv_file(path)
                data = json.loads(path.read_text(encoding="utf-8"))
            
            # If path doesn't exist, try as filename in data_dir
            elif self._data_dir and (data.endswith(".xlsx") or data.endswith(".xls") or data.endswith(".csv")):
                fallback_path = Path(self._data_dir) / data
                if fallback_path.exists():
                    if fallback_path.suffix.lower() in (".xlsx", ".xls"):
                        return self._read_excel_file(fallback_path)
                    if fallback_path.suffix.lower() == ".csv":
                        return self._read_csv_file(fallback_path)
                
                # Try as relative path from workspace root
                workspace_path = self._workspace_root / data
                if workspace_path.exists():
                    if workspace_path.suffix.lower() in (".xlsx", ".xls"):
                        return self._read_excel_file(workspace_path)
                    if workspace_path.suffix.lower() == ".csv":
                        return self._read_csv_file(workspace_path)
            
            # Fall back to JSON parsing
            try:
                data = json.loads(data)
            except Exception:
                pass

        if isinstance(data, dict):
            for key in ("enriched_rows", "opportunities", "rows", "data"):
                if key in data and isinstance(data[key], list):
                    return [r if isinstance(r, dict) else {"raw": str(r)} for r in data[key]]
            return [data]

        if isinstance(data, list):
            return [r if isinstance(r, dict) else {"raw": str(r)} for r in data]

        raise ValueError("Invalid opportunities format")

    def _read_excel_file(self, path: Path) -> List[Dict[str, Any]]:
        from openpyxl import load_workbook

        workbook = load_workbook(path, read_only=True, data_only=True)
        worksheet = workbook.active
        headers: List[str] = []
        rows: List[Dict[str, Any]] = []
        for row_index, values in enumerate(worksheet.iter_rows(values_only=True)):
            if row_index == 0:
                headers = [
                    str(cell) if cell is not None else f"Column_{idx}"
                    for idx, cell in enumerate(values)
                ]
                continue
            if all(cell is None or str(cell).strip() == "" for cell in values):
                continue
            row_dict: Dict[str, Any] = {}
            for col_idx, cell in enumerate(values):
                if col_idx < len(headers):
                    row_dict[headers[col_idx]] = "" if cell is None else cell
            rows.append(row_dict)
        workbook.close()
        return rows

    def _read_csv_file(self, path: Path) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                rows.append({k: (v if v is not None else "") for k, v in row.items()})
        return rows

    def _get_row_id(self, row: Dict[str, Any]) -> str:
        for key in [
            "row_identifier", "Opportunity Id", "opportunity_id", "id",
            "Opportunity Name", "name", "title",
        ]:
            if key in row and row[key]:
                return str(row[key])
        return ""

    def _parse_json(self, text: str) -> Dict:
        try:
            return json.loads(text)
        except Exception:
            text = text.strip()
            if text.startswith("```"):
                text = text.split("```", 2)[1].removeprefix("json").strip()
            start, end = text.find("{"), text.rfind("}")
            if start >= 0 and end > start:
                try:
                    return json.loads(text[start:end + 1])
                except Exception:
                    pass
        return {}
