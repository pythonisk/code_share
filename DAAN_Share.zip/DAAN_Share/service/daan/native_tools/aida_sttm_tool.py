from __future__ import annotations

import json
import logging
import tempfile
from pathlib import Path
from typing import Any

from daan.flow.session_service import get_artifacts_dir
from daan.utils.sttm import generate_sttm_from_files

logger = logging.getLogger(__name__)

SUPPORTED_INPUT_SUFFIXES = {
    ".cs",
    ".csv",
    ".java",
    ".js",
    ".json",
    ".kt",
    ".md",
    ".py",
    ".scala",
    ".sql",
    ".ts",
    ".txt",
    ".xls",
    ".xlsx",
    ".xml",
}


class AidaSttmTool:
    def __init__(self, data_dir: str | None = None):
        self.tool_name = "AidaSttmTool"
        self._data_dir = data_dir
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    def generate_sttm_excel(
        self,
        file_name: str | list[str] | None = None,
        file_path: str | list[str] | None = None,
        output_file_name: str | None = None,
        sttm_json: str | dict | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        try:
            # If the agent passes the STTM JSON inline, write it to a temp file
            # so generate_sttm_from_files can process it without needing a saved file.
            _temp_file: Any = None
            if sttm_json is not None:
                if isinstance(sttm_json, dict):
                    sttm_json_str = json.dumps(sttm_json)
                else:
                    sttm_json_str = str(sttm_json)
                _temp_file = tempfile.NamedTemporaryFile(
                    mode="w", suffix=".json", delete=False, encoding="utf-8"
                )
                _temp_file.write(sttm_json_str)
                _temp_file.flush()
                _temp_file.close()
                logger.info("%s: Using inline sttm_json (%d chars)", self.tool_name, len(sttm_json_str))
                input_files = [Path(_temp_file.name)]
            else:
                input_files = self._resolve_input_files(file_name=file_name, file_path=file_path, kwargs=kwargs)

            if not input_files:
                return {
                    "status": "error",
                    "errors": ["No STTM input files found in the current session inputs folder."],
                }

            artifacts_dir = self._resolve_artifacts_dir()
            artifact_path = self._next_available_artifact_path(artifacts_dir, output_file_name or "sttm_output.xlsx")
            result = generate_sttm_from_files(
                file_paths=[str(path) for path in input_files],
                output_folder=str(artifacts_dir),
                file_name=artifact_path.name,
            )

            # Clean up the temp file if we created one
            if _temp_file is not None:
                try:
                    Path(_temp_file.name).unlink(missing_ok=True)
                except Exception:
                    pass

            return {
                "status": result.get("status", "ok"),
                "message": f"Generated STTM workbook from {len(input_files)} input file(s).",
                "artifact_file": artifact_path.name,
                "artifact_path": str(artifact_path),
                "input_files": [str(path) for path in input_files],
                "mapping_count": result.get("mapping_count", 0),
                "validation_score": result.get("validation_score"),
                "validation_issues": result.get("validation_issues", []),
                "parser_summary": result.get("parser_summary"),
                "workflow_state_path": result.get("workflow_state_path"),
            }
        except Exception as exc:
            logger.exception("%s: STTM generation failed", self.tool_name)
            return {
                "status": "error",
                "errors": [f"STTM generation failed: {exc}"],
            }

    def _resolve_input_files(
        self,
        file_name: str | list[str] | None,
        file_path: str | list[str] | None,
        kwargs: dict[str, Any],
    ) -> list[Path]:
        inputs_dir = Path(self._data_dir) if self._data_dir else None

        def _coerce_many(value: Any) -> list[str]:
            if value is None:
                return []
            if isinstance(value, list):
                return [str(item).strip() for item in value if str(item).strip()]
            text = str(value).strip()
            if not text:
                return []
            if text.startswith("[") and text.endswith("]"):
                text = text[1:-1]
            return [item.strip() for item in text.split(",") if item.strip()]

        explicit_paths = _coerce_many(file_path) + _coerce_many(kwargs.get("file_paths"))
        explicit_names = _coerce_many(file_name) + _coerce_many(kwargs.get("file_names"))

        resolved: list[Path] = []
        for raw_path in explicit_paths:
            candidate = Path(raw_path).expanduser()
            if not candidate.is_absolute() and inputs_dir is not None:
                candidate = inputs_dir / candidate
            if candidate.is_file():
                resolved.append(candidate.resolve())

        for raw_name in explicit_names:
            if inputs_dir is None:
                continue
            candidate = (inputs_dir / raw_name).resolve()
            if candidate.is_file():
                resolved.append(candidate)

        if resolved:
            return self._unique_paths(resolved)

        if inputs_dir is None or not inputs_dir.is_dir():
            return []

        candidates = [
            item.resolve()
            for item in sorted(inputs_dir.iterdir())
            if item.is_file() and item.suffix.lower() in SUPPORTED_INPUT_SUFFIXES
        ]
        return self._unique_paths(candidates)

    def _resolve_artifacts_dir(self) -> Path:
        if not self._data_dir:
            artifacts_dir = Path(__file__).resolve().parent / "artifacts"
            artifacts_dir.mkdir(parents=True, exist_ok=True)
            return artifacts_dir

        data_path = Path(self._data_dir)
        session_dir = data_path.parent if data_path.name == "inputs" else data_path
        artifacts_dir = get_artifacts_dir(session_dir.name, create=True)
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        return artifacts_dir

    def _next_available_artifact_path(self, artifacts_dir: Path, file_name: str) -> Path:
        candidate = artifacts_dir / Path(file_name).name
        if not candidate.exists():
            return candidate
        stem = candidate.stem
        suffix = candidate.suffix
        index = 2
        while True:
            retry = artifacts_dir / f"{stem}_{index}{suffix}"
            if not retry.exists():
                return retry
            index += 1

    def _unique_paths(self, paths: list[Path]) -> list[Path]:
        unique: list[Path] = []
        seen: set[str] = set()
        for path in paths:
            normalized = str(path)
            if normalized in seen:
                continue
            seen.add(normalized)
            unique.append(path)
        return unique