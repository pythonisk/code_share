"""
dbt_model_artifacts_builder.py — Native tool for building dbt model artifacts.

Usage by an LLM agent:
    from daan.native_tools.dbt_model_artifacts_builder import DbtModelArtifactsBuilder
    builder = DbtModelArtifactsBuilder(data_dir=inputs_dir)
    result = builder.build_dbt_artifacts(agent_output, session_id)

Returns dict with:
    {"success": True, "files_extracted": N, "artifacts_directory": "...", ...}
    or {"success": False, "error": "...", ...}
"""

from __future__ import annotations

import logging
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

logger = logging.getLogger(__name__)


class DbtModelArtifactsBuilder:
    """DAAN native tool for building dbt model artifacts."""

    def __init__(self, data_dir: Optional[str] = None):
        """Initialize the dbt artifacts builder.
        
        Args:
            data_dir: Optional data directory (typically inputs dir from session)
        """
        self.tool_name = "DbtModelArtifactsBuilder"
        self._data_dir = data_dir
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    def _extract_session_id_from_data_dir(self) -> Optional[str]:
        """Extract session ID from data_dir path.
        
        Expected pattern: session_storage/{session_id}/inputs
        
        Returns:
            Session ID string or None if cannot be determined
        """
        if not self._data_dir:
            return None
        
        try:
            data_path = Path(self._data_dir)
            # data_dir is typically session_storage/{session_id}/inputs
            # So parent is session_storage/{session_id}
            if data_path.name == "inputs":
                session_dir = data_path.parent
            else:
                session_dir = data_path
            
            # Extract the session_id (directory name)
            session_id = session_dir.name
            
            # Validate it looks like a UUID (basic check)
            if len(session_id) > 10:  # UUIDs are 36 chars, simple validation
                logger.debug("Extracted session_id '%s' from data_dir", session_id)
                return session_id
            
            logger.warning("Could not extract valid session_id from data_dir: %s", self._data_dir)
            return None
        except Exception as exc:
            logger.warning("Error extracting session_id from data_dir: %s", exc)
            return None

    def build_dbt_artifacts(
        self,
        agent_output: str,
        session_id: Optional[str] = None,
        output_subdir: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Build dbt model artifacts from agent output.
        
        Extracts dbt SQL models and YAML schemas from agent markdown output,
        organizes them into proper dbt structure, and saves to session artifacts.
        
        Args:
            agent_output: Markdown output from agent containing dbt models
            session_id: Optional session ID. If not provided, extracted from data_dir.
            output_subdir: Optional subdirectory within artifacts/ (e.g., "dbt_models")
            
        Returns:
            Result dict with success status, file count, and artifact paths:
            {"success": True, "files_extracted": N, "artifacts_directory": "...", ...}
            or {"success": False, "error": "...", ...}
        """
        try:
            # ── Step 0: Resolve session_id from data_dir if not provided ─
            if not session_id and self._data_dir:
                session_id = self._extract_session_id_from_data_dir()
            
            if not session_id:
                return {
                    "success": False,
                    "error": "session_id must be provided or data_dir must be set",
                    "files_extracted": 0,
                }
            
            # ── Step 1: Extract files from markdown ──────────────────
            extracted_files = self._extract_dbt_files_from_markdown(agent_output)
            
            if not extracted_files:
                logger.warning("No dbt files extracted from agent output", extra={
                    "session_id": session_id,
                    "output_length": len(agent_output)
                })
                return {
                    "success": False,
                    "error": "No dbt model files found in agent output",
                    "files_extracted": 0,
                }
            
            # ── Step 2: Organize into proper structure ───────────────
            organized_files = self._organize_dbt_files(extracted_files)
            
            # ── Step 3: Resolve output directory ──────────────────────
            artifacts_dir = self._resolve_artifacts_dir(session_id, output_subdir)
            
            # ── Step 4: Write all files ───────────────────────────────
            saved_files = self._save_files(organized_files, artifacts_dir, session_id)
            
            logger.info(f"Built dbt artifacts successfully", extra={
                "session_id": session_id,
                "files_saved": len(saved_files),
                "artifacts_dir": str(artifacts_dir),
            })
            
            return {
                "success": True,
                "files_extracted": len(extracted_files),
                "files_saved": len(saved_files),
                "artifacts_directory": str(artifacts_dir),
                "saved_files": saved_files,
                "session_id": session_id,
            }
            
        except Exception as exc:
            logger.error(f"Failed to build dbt artifacts: {exc}", exc_info=True, extra={
                "session_id": session_id,
            })
            return {
                "success": False,
                "error": str(exc),
                "files_extracted": 0,
            }

    def _resolve_artifacts_dir(self, session_id: str, output_subdir: Optional[str]) -> Path:
        """Resolve the artifacts directory path.
        
        Args:
            session_id: Session ID
            output_subdir: Optional subdirectory name
            
        Returns:
            Path to artifacts directory
        """
        # Resolve output directory — write into artifacts/ for universal download
        if self._data_dir:
            data_path = Path(self._data_dir)
            session_dir = data_path.parent if data_path.name == "inputs" else data_path
            artifacts_dir = session_dir / "artifacts"
        else:
            from daan.flow.session_service import get_artifacts_dir
            artifacts_dir = get_artifacts_dir(session_id, create=True)
        
        # Create subdirectory if specified
        if output_subdir:
            artifacts_dir = artifacts_dir / output_subdir
        else:
            # Default to timestamped directory
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            artifacts_dir = artifacts_dir / f"dbt_models_{timestamp}"
        
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        return artifacts_dir

    def _save_files(
        self, 
        organized_files: Dict[str, str], 
        artifacts_dir: Path, 
        session_id: str
    ) -> List[str]:
        """Save organized files to artifacts directory.
        
        Args:
            organized_files: Dict of relative paths to contents
            artifacts_dir: Base artifacts directory
            session_id: Session ID for logging
            
        Returns:
            List of saved file paths (relative to artifacts_dir)
        """
        saved_files: List[str] = []
        
        for filepath, content in organized_files.items():
            full_path = artifacts_dir / filepath
            
            # Create parent directories
            full_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Write file
            with open(full_path, "w", encoding="utf-8") as f:
                f.write(content)
            
            saved_files.append(str(full_path.relative_to(artifacts_dir)))
            logger.info(f"Saved dbt file: {filepath}", extra={
                "session_id": session_id,
                "file_path": filepath,
            })
        
        return saved_files

    def _extract_dbt_files_from_markdown(self, markdown_text: str) -> Dict[str, str]:
        """Extract dbt SQL models and YAML files from agent output markdown.
        
        Uses multiple regex patterns to capture various markdown formats where
        dbt models and schemas might be presented.
        
        Args:
            markdown_text: The markdown content from agent output
            
        Returns:
            Dict mapping relative file paths to file contents
        """
        if not markdown_text:
            return {}

        files: Dict[str, str] = {}
        
        # Pattern 1: Explicit filename with code block
        # **Filename**: `models/staging/stg_customers.sql`
        # ```sql
        # SELECT ...
        # ```
        pattern_explicit = re.compile(
            r"\*\*Filename\*\*\s*:\s*`?(?P<filename>(?:models|tests|macros|analyses|seeds|snapshots)/[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`?\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        )
        
        # Pattern 2: Filename header (no bold)
        # Filename: models/marts/fct_sales.sql
        # ```sql
        # ...
        # ```
        pattern_header = re.compile(
            r"(?:^|\n)\s*Filename\s*:\s*`?(?P<filename>(?:models|tests|macros|analyses|seeds|snapshots)/[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`?\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        )
        
        # Pattern 2b: File header (short form without "name")
        # File: models/marts/fct_sales.sql
        # ```sql
        # ...
        # ```
        pattern_file_header = re.compile(
            r"(?:^|\n)\s*File\s*:\s*(?P<filename>(?:models|tests|macros|analyses|seeds|snapshots)/[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        )
        
        # Pattern 3: File path in bold followed by code
        # **models/staging/stg_orders.sql**
        # ```sql
        # ...
        # ```
        pattern_bold_path = re.compile(
            r"\*\*(?P<filename>(?:models|tests|macros|analyses|seeds|snapshots)/[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))\*\*\s*:?(?:\s*\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        )
        
        # Pattern 4: Inline path in backticks
        # `models/intermediate/int_customer_orders.sql`
        # ```sql
        # ...
        # ```
        pattern_backtick = re.compile(
            r"`(?P<filename>(?:models|tests|macros|analyses|seeds|snapshots)/[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        )
        
        # Pattern 5: YAML schema files with common names
        # schema.yml / sources.yml / _schema.yml
        pattern_schema = re.compile(
            r"(?:^|\n)\s*(?:_)?(?:schema|sources)\.ya?ml[^\n]*?(?:\r?\n)+\s*```yaml\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        )
        
        # Pattern 6: Code block with SQL comment indicating file path
        # ```sql
        # -- models/staging/stg_products.sql
        # SELECT ...
        # ```
        pattern_sql_comment = re.compile(
            r"\s*```(?P<lang>[A-Za-z0-9_\-]*)\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        )
        
        # Apply patterns in order
        all_patterns = [
            pattern_explicit,
            pattern_header,
            pattern_file_header,  # New: matches "File: path/file.sql" format
            pattern_bold_path,
            pattern_backtick,
        ]
        
        for pattern in all_patterns:
            for match in pattern.finditer(markdown_text):
                filename = match.group("filename").strip()
                code = match.group("code").strip()
                
                if not filename or not code:
                    continue
                
                # Normalize path separators
                filename = filename.replace("\\", "/")
                
                # Sanitize YAML if needed
                if filename.lower().endswith((".yml", ".yaml")):
                    code = self._sanitize_yaml_content(code)
                
                files[filename] = code + "\n"
        
        # Handle schema.yml pattern separately (no filename in match)
        for match in pattern_schema.finditer(markdown_text):
            code = match.group("code").strip()
            if code:
                code = self._sanitize_yaml_content(code)
                # Default to models/_schema.yml if not already present
                schema_path = "models/_schema.yml"
                if schema_path not in files:
                    files[schema_path] = code + "\n"
        
        # Check for SQL files with path comments
        for block_match in pattern_sql_comment.finditer(markdown_text):
            code = block_match.group("code").strip()
            if not code:
                continue
            
            # Look for path in SQL comment
            path_comment_pattern = re.compile(
                r"^\s*--\s*(?P<filepath>(?:models|tests|macros|analyses|seeds|snapshots)/[A-Za-z0-9_\-./]+\.sql)\s*$",
                re.IGNORECASE | re.MULTILINE,
            )
            
            comment_match = path_comment_pattern.search(code)
            if comment_match:
                filepath = comment_match.group("filepath").strip().replace("\\", "/")
                if filepath not in files:
                    files[filepath] = code + "\n"
        
        return files

    def _sanitize_yaml_content(self, content: str) -> str:
        """Best-effort YAML sanitizer for LLM-generated snippets.
        
        Handles common issues like unquoted comparison operators.
        """
        text = (content or "").replace("\r\n", "\n")
        
        # Try to parse as-is first
        try:
            yaml.safe_load(text)
            return text
        except Exception:
            pass
        
        # Fix common issues: unquoted comparison operators
        fixed_lines: List[str] = []
        line_re = re.compile(r"^(?P<prefix>\s*(?:-\s*)?[A-Za-z0-9_\-]+:\s*)(?P<value>.+?)\s*$")
        
        for line in text.split("\n"):
            m = line_re.match(line)
            if not m:
                fixed_lines.append(line)
                continue
            
            value = m.group("value").strip()
            needs_quote = (
                value
                and not value.startswith(("'", '"', "[", "{", "|", ">", "&", "*", "!"))
                and re.search(r"(>=|<=|==|!=|>|<)", value) is not None
            )
            
            if needs_quote:
                escaped = value.replace('"', '\\"')
                fixed_lines.append(f'{m.group("prefix")}"{escaped}"')
            else:
                fixed_lines.append(line)
        
        fixed_text = "\n".join(fixed_lines)
        
        # Verify the fix worked
        try:
            yaml.safe_load(fixed_text)
            return fixed_text
        except Exception:
            # Return original if fix didn't help
            return text

    def _organize_dbt_files(self, files: Dict[str, str]) -> Dict[str, str]:
        """Organize extracted files into proper dbt directory structure.
        
        Ensures files are in correct subdirectories (models/, tests/, etc.)
        and applies naming conventions.
        
        Args:
            files: Dict of relative paths to contents
            
        Returns:
            Organized dict with normalized paths
        """
        organized: Dict[str, str] = {}
        
        for filepath, content in files.items():
            # Normalize path
            normalized = filepath.strip().replace("\\", "/")
            
            # Ensure it starts with a valid dbt directory
            valid_dirs = ["models", "tests", "macros", "analyses", "seeds", "snapshots"]
            
            if not any(normalized.startswith(d + "/") for d in valid_dirs):
                # Try to infer directory from filename
                filename = os.path.basename(normalized)
                
                if filename.startswith("test_"):
                    normalized = f"tests/{filename}"
                elif filename.lower().endswith((".yml", ".yaml")):
                    normalized = f"models/{filename}"
                else:
                    # Default to models/
                    normalized = f"models/{filename}"
            
            organized[normalized] = content
        
        return organized


# ═══════════════════════════════════════════════════════════════════════════
# Standalone helper functions for backward compatibility and direct usage
# ═══════════════════════════════════════════════════════════════════════════

def build_dbt_artifacts(
    agent_output: str,
    session_id: Optional[str] = None,
    output_subdir: Optional[str] = None,
    data_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Standalone function: Build dbt artifacts from agent output.
    
    Args:
        agent_output: Markdown output from agent containing dbt models
        session_id: Optional session ID. If not provided, extracted from data_dir.
        output_subdir: Optional subdirectory within artifacts/
        data_dir: Optional data directory
        
    Returns:
        Result dict with success status and artifact info
    """
    builder = DbtModelArtifactsBuilder(data_dir=data_dir)
    return builder.build_dbt_artifacts(agent_output, session_id, output_subdir)


def load_agent_output_from_session(session_id: str, agent_name: str = "dbt_modeler") -> Optional[str]:
    """Load agent output markdown from session storage.
    
    Args:
        session_id: Session ID
        agent_name: Name of the agent whose output to load
        
    Returns:
        Agent output markdown or None if not found
    """
    try:
        from daan.flow.session_service import _storage_root
        
        session_dir = _storage_root() / session_id
        agents_dir = session_dir / "agents"
        
        if not agents_dir.exists():
            logger.warning(f"Agents directory not found for session {session_id}")
            return None
        
        # Look for output.md in agent subdirectory
        agent_output_path = agents_dir / agent_name / "output.md"
        
        if agent_output_path.exists():
            with open(agent_output_path, "r", encoding="utf-8") as f:
                return f.read()
        
        # Fallback: search for any .md file with agent_name in path
        for md_file in agents_dir.rglob("*.md"):
            if agent_name.lower() in str(md_file).lower():
                with open(md_file, "r", encoding="utf-8") as f:
                    return f.read()
        
        logger.warning(f"No output found for agent '{agent_name}' in session {session_id}")
        return None
        
    except Exception as exc:
        logger.error(f"Failed to load agent output: {exc}", exc_info=True)
        return None


def build_dbt_artifacts_from_agent(
    session_id: str,
    agent_name: str = "dbt_modeler",
    output_subdir: Optional[str] = None,
    data_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Standalone function: Build dbt artifacts by loading agent output from session storage.
    
    Args:
        session_id: Session ID
        agent_name: Name of the agent whose output contains dbt models
        output_subdir: Optional subdirectory for artifacts
        data_dir: Optional data directory
        
    Returns:
        Result dict with success status and artifact info
    """
    agent_output = load_agent_output_from_session(session_id, agent_name)
    
    if not agent_output:
        return {
            "success": False,
            "error": f"No output found for agent '{agent_name}' in session {session_id}",
            "files_extracted": 0,
        }
    
    return build_dbt_artifacts(agent_output, session_id, output_subdir, data_dir)


if __name__ == "__main__":
    # Example usage
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python dbt_model_artifacts_builder.py <session_id> [agent_name]")
        sys.exit(1)
    
    session_id = sys.argv[1]
    agent_name = sys.argv[2] if len(sys.argv) > 2 else "dbt_modeler"
    
    result = build_dbt_artifacts_from_agent(session_id, agent_name)
    
    print(f"\n=== dbt Artifacts Builder ===")
    print(f"Success: {result.get('success')}")
    print(f"Files extracted: {result.get('files_extracted', 0)}")
    print(f"Files saved: {result.get('files_saved', 0)}")
    
    if result.get("success"):
        print(f"Artifacts directory: {result.get('artifacts_directory')}")
        print(f"\nSaved files:")
        for filepath in result.get("saved_files", []):
            print(f"  - {filepath}")
    else:
        print(f"Error: {result.get('error')}")
