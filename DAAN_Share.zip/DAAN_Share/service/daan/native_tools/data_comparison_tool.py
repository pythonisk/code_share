"""
Data Comparison Tool — Denodo to Fabric Migration Testing Automation

Action tool executed by AGENT_TA_04 (Data Comparison Agent).
Performs data-level record comparison between Denodo (source) and
Microsoft Fabric (target) using an adaptive strategy (POC Section 8):

  - Small datasets (< COMPARISON_SAMPLE_THRESHOLD rows):
      Full record comparison — every row matched field by field.
  - Large datasets (>= threshold):
      Sampling-based comparison — random sample + SHA-256 hash of sorted
      concatenated values per column (KPI-level validation).

Threshold controlled by env var  COMPARISON_SAMPLE_THRESHOLD  (default 100000).

Connection config is resolved entirely from environment variables.
See sql_validation_tool.py for the full list of FABRIC_* / DENODO_* vars.
"""

from __future__ import annotations

import ast
import hashlib
import json
import logging
import os
import random
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
_SAMPLE_THRESHOLD = int(os.getenv("COMPARISON_SAMPLE_THRESHOLD", "100000"))
_SAMPLE_SIZE = int(os.getenv("COMPARISON_SAMPLE_SIZE", "1000"))
_FLOAT_TOLERANCE = float(os.getenv("COMPARISON_FLOAT_TOLERANCE", "1e-9"))

# ---------------------------------------------------------------------------
# Connection helpers (thin wrappers — same pattern as sql_validation_tool)
# ---------------------------------------------------------------------------

def _get_fabric_token() -> Optional[str]:
    token = os.getenv("FABRIC_BEARER_TOKEN", "").strip()
    if token:
        return token
    tenant = os.getenv("FABRIC_TENANT_ID", "").strip()
    client = os.getenv("FABRIC_CLIENT_ID", "").strip()
    secret = os.getenv("FABRIC_CLIENT_SECRET", "").strip()
    if not (tenant and client and secret):
        return None
    scope = "https://database.windows.net/.default"
    resp = requests.post(
        f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
        data={"grant_type": "client_credentials", "client_id": client,
              "client_secret": secret, "scope": scope},
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json().get("access_token")


def _fetch_fabric(sql: str, timeout: int = 180) -> List[Dict]:
    endpoint = os.getenv("FABRIC_SQL_ENDPOINT", "").strip()
    database = os.getenv("FABRIC_DATABASE", "").strip()
    if not endpoint or not database:
        raise RuntimeError("Set FABRIC_SQL_ENDPOINT and FABRIC_DATABASE env vars.")
    token = _get_fabric_token()
    if not token:
        raise RuntimeError("No Fabric auth credentials. Set FABRIC_BEARER_TOKEN or service-principal vars.")
    url = f"https://{endpoint}/v1/workspaces/query"
    resp = requests.post(
        url,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json={"query": sql, "database": database},
        timeout=timeout,
    )
    resp.raise_for_status()
    data = resp.json()
    rows = data.get("rows", data.get("results", []))
    cols = data.get("columns", [])
    # Normalise rows to list[dict]
    if rows and isinstance(rows[0], (list, tuple)):
        rows = [dict(zip(cols, r)) for r in rows]
    return rows


def _fetch_denodo(sql: str, timeout: int = 180) -> List[Dict]:
    host = os.getenv("DENODO_HOST", "localhost").strip()
    port = os.getenv("DENODO_PORT", "9090").strip()
    database = os.getenv("DENODO_DATABASE", "").strip()
    db_path = f"/{database}" if database else ""
    url = f"http://{host}:{port}/denodo-data-catalog/api{db_path}/views/query"

    session = requests.Session()
    token = os.getenv("DENODO_BEARER_TOKEN", "").strip()
    user = os.getenv("DENODO_USER", "").strip()
    pwd = os.getenv("DENODO_PASSWORD", "").strip()
    if token:
        session.headers["Authorization"] = f"Bearer {token}"
    elif user and pwd:
        session.auth = (user, pwd)
    else:
        raise RuntimeError("No Denodo auth credentials. Set DENODO_USER+DENODO_PASSWORD or DENODO_BEARER_TOKEN.")

    resp = session.post(url, json={"query": sql}, timeout=timeout)
    resp.raise_for_status()
    data = resp.json()
    rows = data.get("elements", data.get("rows", []))
    cols = data.get("name", data.get("columns", []))
    if rows and isinstance(rows[0], (list, tuple)):
        rows = [dict(zip(cols, r)) for r in rows]
    return rows


# ---------------------------------------------------------------------------
# Comparison helpers
# ---------------------------------------------------------------------------

def _normalise_value(val: Any) -> str:
    """Convert a cell value to a canonical string for comparison."""
    if val is None:
        return "__NULL__"
    if isinstance(val, float):
        return f"{val:.9f}"
    return str(val).strip()


def _row_hash(row: Dict) -> str:
    """SHA-256 hash of a sorted row dict for fast equality check."""
    canonical = json.dumps(
        {k: _normalise_value(v) for k, v in sorted(row.items())},
        sort_keys=True,
    )
    return hashlib.sha256(canonical.encode()).hexdigest()


def _full_compare(
    src_rows: List[Dict],
    tgt_rows: List[Dict],
    key_columns: List[str],
) -> Dict[str, Any]:
    """
    Full record comparison — match rows by key_columns (or by position if no keys).
    Returns mismatch_details list and accuracy stats.
    """
    mismatches: List[Dict] = []
    matched = 0
    src_index: Dict[str, Dict] = {}

    # Build lookup from source by composite key
    for row in src_rows:
        row_key = "|".join(_normalise_value(row.get(k)) for k in key_columns) if key_columns else None
        if row_key is not None:
            src_index[row_key] = row

    for tgt_row in tgt_rows:
        row_key = "|".join(_normalise_value(tgt_row.get(k)) for k in key_columns) if key_columns else None

        if row_key and row_key in src_index:
            src_row = src_index[row_key]
            all_cols = set(src_row) | set(tgt_row)
            row_mismatches = []
            for col in sorted(all_cols):
                sv = _normalise_value(src_row.get(col))
                tv = _normalise_value(tgt_row.get(col))
                if sv != tv:
                    row_mismatches.append(
                        {"column": col, "source_value": sv, "target_value": tv}
                    )
            if row_mismatches:
                mismatches.append({"row_key": row_key, "field_mismatches": row_mismatches})
            else:
                matched += 1
        else:
            mismatches.append({"row_key": row_key, "field_mismatches": [{"column": "_row_", "source_value": "missing", "target_value": str(tgt_row)[:200]}]})

    total = len(tgt_rows)
    return {
        "comparison_strategy": "full",
        "total_records_compared": total,
        "match_count": matched,
        "mismatch_count": len(mismatches),
        "mismatch_details": mismatches[:500],  # cap to 500 for payload size
        "accuracy_percentage": round(matched / total * 100, 4) if total else 100.0,
    }


def _sampling_compare(
    src_rows: List[Dict],
    tgt_rows: List[Dict],
    sample_size: int,
) -> Dict[str, Any]:
    """
    Sampling-based comparison — random sample + column-level hash check.
    Also computes per-column hash to detect systemic transformation errors.
    """
    src_sample = random.sample(src_rows, min(sample_size, len(src_rows)))
    tgt_sample = random.sample(tgt_rows, min(sample_size, len(tgt_rows)))

    src_hashes = {_row_hash(r) for r in src_sample}
    tgt_hashes = {_row_hash(r) for r in tgt_sample}
    common = src_hashes & tgt_hashes
    sample_match_rate = len(common) / len(src_hashes) if src_hashes else 0.0

    # Per-column KPI hash (sorted concatenation of sampled values)
    col_hashes_src: Dict[str, str] = {}
    col_hashes_tgt: Dict[str, str] = {}
    all_cols = sorted(set().union(*(r.keys() for r in src_sample)))
    for col in all_cols:
        src_vals = sorted(_normalise_value(r.get(col)) for r in src_sample)
        tgt_vals = sorted(_normalise_value(r.get(col)) for r in tgt_sample)
        col_hashes_src[col] = hashlib.sha256("|".join(src_vals).encode()).hexdigest()
        col_hashes_tgt[col] = hashlib.sha256("|".join(tgt_vals).encode()).hexdigest()

    column_mismatches = [
        col for col in all_cols if col_hashes_src.get(col) != col_hashes_tgt.get(col)
    ]

    return {
        "comparison_strategy": "sampling",
        "total_records_compared": len(src_sample),
        "sample_size": sample_size,
        "sample_match_rate": round(sample_match_rate * 100, 4),
        "column_hash_mismatches": column_mismatches,
        "mismatch_count": len(column_mismatches),
        "accuracy_percentage": round(sample_match_rate * 100, 4),
        "hash_match": len(column_mismatches) == 0,
        "mismatch_details": [{"column": c, "issue": "column-level hash mismatch"} for c in column_mismatches],
    }


# ---------------------------------------------------------------------------
# Input parser
# ---------------------------------------------------------------------------

def _parse_input(input_context) -> Optional[Dict]:
    if isinstance(input_context, dict):
        return input_context
    if not isinstance(input_context, str) or not input_context.strip():
        return None
    for loader in (json.loads, ast.literal_eval):
        try:
            obj = loader(input_context.strip())
            return obj if isinstance(obj, dict) else {"payload": obj}
        except (ValueError, SyntaxError):
            pass
    logger.warning("DataComparisonTool: cannot parse input_context")
    return None


# ---------------------------------------------------------------------------
# Public tool class
# ---------------------------------------------------------------------------

class DataComparisonTool:
    """
    DAAN5 native action tool — Data Comparison Agent (AGENT_TA_04).

    Selects full comparison for small datasets and sampling-based comparison
    for large datasets, as specified in POC Section 8.
    """

    def __init__(self, data_dir: str = "", **_kwargs):
        self._data_dir = data_dir

    def compare_data(self, input_context) -> str:
        """
        Execute data-level comparison between Denodo and Fabric.

        Args:
            input_context: dict or JSON string containing:
              - source_sql:    SQL to fetch source (Denodo) data
              - target_sql:    SQL to fetch target (Fabric) data
              - key_columns:   list of columns that uniquely identify a row
              - row_count_hint: 'small' | 'large'  (from AGENT_TA_01 metadata)
              - sample_size:   optional override for sampling size
              - env overrides: FABRIC_*, DENODO_* keys

        Returns:
            JSON string with comparison results.
        """
        payload = _parse_input(input_context)
        if payload is None:
            return json.dumps({"error": "Invalid or empty input_context"})

        # Apply optional per-call env overrides
        for env_key in (
            "FABRIC_SQL_ENDPOINT", "FABRIC_DATABASE", "FABRIC_BEARER_TOKEN",
            "FABRIC_TENANT_ID", "FABRIC_CLIENT_ID", "FABRIC_CLIENT_SECRET",
            "DENODO_HOST", "DENODO_PORT", "DENODO_DATABASE",
            "DENODO_USER", "DENODO_PASSWORD", "DENODO_BEARER_TOKEN",
        ):
            override = payload.get(env_key.lower()) or payload.get(env_key)
            if override:
                os.environ[env_key] = str(override)

        source_sql = payload.get("source_sql", "").strip()
        target_sql = payload.get("target_sql", "").strip()
        key_columns: List[str] = payload.get("key_columns", [])
        row_count_hint: str = payload.get("row_count_hint", "small").lower()
        sample_size: int = int(payload.get("sample_size", _SAMPLE_SIZE))

        if not source_sql or not target_sql:
            return json.dumps({"error": "source_sql and target_sql are required in input_context"})

        try:
            logger.info("DataComparisonTool: fetching source data (Denodo)...")
            src_rows = _fetch_denodo(source_sql)
            logger.info("DataComparisonTool: fetching target data (Fabric)...")
            tgt_rows = _fetch_fabric(target_sql)
        except Exception as exc:
            logger.error("DataComparisonTool: data fetch failed: %s", exc, exc_info=True)
            return json.dumps({"error": f"Data fetch failed: {exc}"})

        src_count = len(src_rows)
        tgt_count = len(tgt_rows)

        # Adaptive strategy selection (POC Section 8)
        use_full = row_count_hint == "small" or src_count < _SAMPLE_THRESHOLD

        try:
            if use_full:
                logger.info(
                    "DataComparisonTool: full comparison (src=%d, tgt=%d)", src_count, tgt_count
                )
                result = _full_compare(src_rows, tgt_rows, key_columns)
            else:
                logger.info(
                    "DataComparisonTool: sampling comparison (src=%d, tgt=%d, sample=%d)",
                    src_count, tgt_count, sample_size,
                )
                result = _sampling_compare(src_rows, tgt_rows, sample_size)

            result["source_row_count"] = src_count
            result["target_row_count"] = tgt_count
            result["row_count_delta"] = abs(src_count - tgt_count)
            return json.dumps(result, default=str)

        except Exception as exc:
            logger.error("DataComparisonTool: comparison failed: %s", exc, exc_info=True)
            return json.dumps({"error": f"Comparison failed: {exc}"})
