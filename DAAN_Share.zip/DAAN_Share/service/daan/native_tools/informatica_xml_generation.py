"""
DAAN 5 Native Tool: Informatica PowerCenter XML Generation

Entry point:
    local_tools = InformaticaXMLGeneration.generate_xml

This tool:
1) Normalizes STTM input (dict or JSON string or kwargs)
2) Loads and analyzes an optional reference Informatica XML template (RAG-lite)
3) Builds an LLM prompt grounded with extracted attribute patterns
4) Extracts XML from LLM output, validates well-formedness
5) Falls back to deterministic XML generator if LLM output is invalid
6) Returns either RAW XML or ESCAPED XML (UI-safe) based on escapeOutput flag

Design notes:
- DAAN 5 loads native tools via ClassName.method_name resolved through tools_loader,
  with CamelCase->snake_case module mapping. Keep class name + method stable.
"""

from __future__ import annotations

import html
import json
import logging
import os
import re
import difflib
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Optional
from xml.sax.saxutils import escape as xml_escape

import pandas as pd

from daan.flow.context_vars import daan_session_id
from daan.llm.llm_provider import get_llm_response_with_fallback

logger = logging.getLogger(__name__)

_TOOL_VERSION = "2.4"


# -----------------------------
# Helpers: XML normalization
# -----------------------------

_XML_HEADER_RAW = '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">'

_XML_START_PATTERNS = (
    r"<\?xml\b",
    r"<POWERMART\b",
    r"<REPOSITORY\b",
)


def _strip_doctype(xml_text: str) -> str:
    """Remove DOCTYPE for ElementTree parsing only."""
    return re.sub(r"<!DOCTYPE[^>]*>", "", xml_text, flags=re.IGNORECASE).strip()


def _extract_xml_text(text: str) -> str:
    """Best-effort extraction of PowerMart XML from raw, escaped, or wrapped content."""
    if not text:
        return ""

    candidate = text.strip()

    fenced = re.search(r"```(?:xml)?\s*([\s\S]+?)```", candidate, re.IGNORECASE)
    if fenced:
        candidate = fenced.group(1).strip()

    # Some paths return escaped XML or escaped XML inside HTML wrappers.
    for _ in range(1):
        unescaped = html.unescape(candidate).strip()
        if unescaped == candidate:
            break
        candidate = unescaped

    candidate = re.sub(r"^\s*<pre\b[^>]*>\s*<code\b[^>]*>", "", candidate, flags=re.IGNORECASE)
    candidate = re.sub(r"</code>\s*</pre>\s*$", "", candidate, flags=re.IGNORECASE)

    start_positions = []
    for pattern in _XML_START_PATTERNS:
        match = re.search(pattern, candidate, re.IGNORECASE)
        if match:
            start_positions.append(match.start())

    if start_positions:
        candidate = candidate[min(start_positions):]
    else:
        start = candidate.find("<")
        end = candidate.rfind(">")
        if start == -1 or end == -1 or end <= start:
            return ""
        candidate = candidate[start : end + 1]

    close_matches = list(re.finditer(r"</POWERMART>", candidate, re.IGNORECASE))
    if close_matches:
        candidate = candidate[: close_matches[-1].end()]

    candidate = candidate.strip()
    if candidate.startswith("<REPOSITORY") and "<POWERMART" not in candidate.upper():
        candidate = f"<POWERMART>\n{candidate}\n</POWERMART>"

    candidate = re.sub(r"<\?xml[^>]*\?>", "", candidate, flags=re.IGNORECASE).strip()
    candidate = re.sub(r"<!DOCTYPE[^>]*>", "", candidate, flags=re.IGNORECASE).strip()

    if candidate.startswith("<POWERMART"):
        return f"{_XML_HEADER_RAW}\n{candidate}"
    return candidate


def _is_well_formed_powermart_xml(raw_xml: str) -> bool:
    """Validate XML structure is parseable and has POWERMART root (DOCTYPE removed for parse)."""
    if not raw_xml:
        return False
    s = _extract_xml_text(raw_xml)
    if not s.startswith("<?xml"):
        return False
    if not re.search(r"</POWERMART>", s, flags=re.IGNORECASE):
        return False
    try:
        candidate = html.unescape(_strip_doctype(s))
        ET.fromstring(candidate)
        return True
    except Exception:
        return False


def _extract_xml_block(text: str) -> str:
    """Extract XML between <?xml ...?> and </POWERMART> (handles fenced blocks)."""
    return _extract_xml_text(text)


def _ensure_boundaries(raw_xml: str) -> str:
    """
    Ensure XML starts with standard header+doctype and ends with </POWERMART>.
    Removes duplicate headers/doctype and re-adds canonical header.
    """
    if not raw_xml:
        return ""
    s = raw_xml.strip()

    # remove existing declaration / doctype (if any)
    s = re.sub(r"^\s*<\?xml[^>]*>\s*", "", s, count=1)
    s = re.sub(r"^\s*<!DOCTYPE[^>]*>\s*", "", s, count=1, flags=re.IGNORECASE)

    # must start with POWERMART now
    if not re.match(r"^\s*<POWERMART\b", s, flags=re.IGNORECASE):
        # try to find POWERMART anywhere
        m = re.search(r"<POWERMART\b", s, flags=re.IGNORECASE)
        if not m:
            return ""
        s = s[m.start() :]

    # enforce closing
    close_matches = list(re.finditer(r"</POWERMART>", s, re.IGNORECASE))
    if not close_matches:
        return ""
    s = s[: close_matches[-1].end()].strip()

    return f"{_XML_HEADER_RAW}\n{s}"


# -----------------------------
# Template analysis (RAG-lite)
# -----------------------------


@dataclass
class TemplateInfo:
    xml_header: str = _XML_HEADER_RAW
    powermart_attrs: str = 'CREATION_DATE="MM/DD/YYYY HH:MM:SS" REPOSITORY_VERSION="189.98"'
    repository_attrs: str = 'NAME="Repository" VERSION="189" CODEPAGE="UTF-8" DATABASETYPE="Oracle"'
    folder_attrs: str = 'NAME="Folder" GROUP="" OWNER="owner" SHARED="NOTSHARED" DESCRIPTION="" PERMISSIONS="rwx------"'
    sourcefield_example: str = '<SOURCEFIELD BUSINESSNAME="" DATATYPE="string" FIELDNUMBER="1" FIELDPROPERTY="0" FIELDTYPE="SOURCE" HIDDEN="NO" KEYTYPE="NOT A KEY" LENGTH="50" NAME="FIELD_NAME" NULLABLE="NULL" OCCURS="0" PICTURETEXT="" PRECISION="50" SCALE="0"/>'
    targetfield_example: str = '<TARGETFIELD BUSINESSNAME="" DATATYPE="string" FIELDNUMBER="1" FIELDPROPERTY="0" FIELDTYPE="TARGET" HIDDEN="NO" KEYTYPE="NOT A KEY" LENGTH="50" NAME="FIELD_NAME" NULLABLE="NULL" OCCURS="0" PICTURETEXT="" PRECISION="50" SCALE="0"/>'
    connector_example: str = '<CONNECTOR FROMFIELD="SRC_FIELD" FROMINSTANCE="SQ_SOURCE" FROMINSTANCETYPE="Source Qualifier" TOFIELD="TGT_FIELD" TOINSTANCE="TARGET" TOINSTANCETYPE="Target Definition"/>'
    transformation_example: str = '<TRANSFORMATION DESCRIPTION="" NAME="SQ_SOURCE" OBJECTVERSION="1" REUSABLE="NO" TYPE="Source Qualifier" VERSIONNUMBER="1">\n  <TRANSFORMFIELD DATATYPE="string" DEFAULTVALUE="" DESCRIPTION="" GROUP="" NAME="FIELD_NAME" PICTURETEXT="" PORTTYPE="INPUT/OUTPUT" PRECISION="50" SCALE="0"/>\n</TRANSFORMATION>'


@dataclass
class FieldSpec:
    name: str
    datatype: str = "string"
    length: str = "255"
    precision: str = "255"
    scale: str = "0"
    nullable: str = "NULL"
    keytype: str = "NOT A KEY"
    picturetext: str = ""
    fieldproperty: str = "0"
    hidden: str = "NO"
    occurs: str = "0"


class _TemplateAnalyzer:
    """
    Read a reference XML and extract attribute patterns.
    """

    def __init__(self, template_xml_path: Optional[str] = None):
        self.template_xml_path = template_xml_path
        self.content = ""

    def load(self) -> str:
        src = (self.template_xml_path or os.getenv("INFORMATICA_TEMPLATE_XML") or "").strip()
        if not src:
            return ""

        # inline XML passed?
        if "<POWERMART" in html.unescape(src) and "</POWERMART>" in html.unescape(src):
            self.content = html.unescape(src)
            return self.content

        # path?
        try:
            p = Path(src)
            if p.exists() and p.is_file():
                self.content = html.unescape(p.read_text(encoding="utf-8"))
                return self.content
        except Exception:
            pass

        return ""

    def analyze(self) -> TemplateInfo:
        info = TemplateInfo()
        if not self.content:
            return info

        c = self.content

        # header + doctype
        hdr = re.search(r"<\?xml[^>]+\?>.*?<!DOCTYPE[^>]+>", c, re.DOTALL | re.IGNORECASE)
        if hdr:
            info.xml_header = hdr.group(0).strip()

        # attributes
        for key, pattern in (
            ("powermart_attrs", r"<POWERMART\s+([^>]+)>"),
            ("repository_attrs", r"<REPOSITORY\s+([^>]+)>"),
            ("folder_attrs", r"<FOLDER\s+([^>]+)>"),
        ):
            m = re.search(pattern, c, re.IGNORECASE)
            if m:
                setattr(info, key, m.group(1).strip())

        # field + connector examples (take first occurrence)
        sf = re.findall(r"<SOURCEFIELD\s+([^>]+)/>", c, re.IGNORECASE)
        if sf:
            info.sourcefield_example = f"<SOURCEFIELD {sf[0]}/>"

        tf = re.findall(r"<TARGETFIELD\s+([^>]+)/>", c, re.IGNORECASE)
        if tf:
            info.targetfield_example = f"<TARGETFIELD {tf[0]}/>"

        cn = re.findall(r"<CONNECTOR\s+([^>]+)/>", c, re.IGNORECASE)
        if cn:
            info.connector_example = f"<CONNECTOR {cn[0]}/>"

        transformation_blocks = re.findall(
            r"<TRANSFORMATION\s+.*?</TRANSFORMATION>",
            c,
            re.IGNORECASE | re.DOTALL,
        )
        if transformation_blocks:
            info.transformation_example = transformation_blocks[0].strip()

        return info

    def _format_xml_example(self, xml_text: str, escape_output: bool) -> str:
        return html.escape(xml_text) if escape_output else xml_text

    def build_generation_guide(self, info: TemplateInfo, *, escape_output: bool) -> str:
        header_text = self._format_xml_example(info.xml_header, escape_output)
        powermart_text = self._format_xml_example(f'<POWERMART {info.powermart_attrs}>', escape_output)
        repository_text = self._format_xml_example(f'<REPOSITORY {info.repository_attrs}>', escape_output)
        folder_text = self._format_xml_example(f'<FOLDER {info.folder_attrs}>', escape_output)
        sourcefield_text = self._format_xml_example(info.sourcefield_example, escape_output)
        targetfield_text = self._format_xml_example(info.targetfield_example, escape_output)
        connector_text = self._format_xml_example(info.connector_example, escape_output)
        transformation_text = self._format_xml_example(info.transformation_example, escape_output)

        return f"""
# INFORMATICA POWERCENTER XML STRUCTURE GUIDE (FROM VERIFIED TEMPLATE)

## 1. XML HEADER AND DOCTYPE (MANDATORY - COPY EXACTLY):
{header_text}

## 2. POWERMART ROOT ELEMENT (REQUIRED ATTRIBUTES):
{powermart_text}

## 3. REPOSITORY ELEMENT (REQUIRED ATTRIBUTES):
{repository_text}

## 4. FOLDER ELEMENT (REQUIRED ATTRIBUTES):
{folder_text}

## 5. SOURCE DEFINITION STRUCTURE:

### Complete SOURCE Example:
<SOURCE BUSINESSNAME="" DATABASETYPE="Oracle" DBDNAME="DATABASE_NAME" DESCRIPTION="" NAME="SOURCE_TABLE_NAME" OBJECTVERSION="1" OWNERNAME="OWNER" VERSIONNUMBER="1">

### SOURCEFIELD Attribute Pattern (FROM TEMPLATE):
{sourcefield_text}

### Critical SOURCEFIELD Attributes (NEVER OMIT):
- BUSINESSNAME (can be empty: BUSINESSNAME="")
- DATATYPE (e.g., "string", "number(p,s)", "date", "varchar2", "nvarchar2")
- FIELDNUMBER (sequential: "1", "2", "3"...)
- FIELDPROPERTY="0"
- FIELDTYPE="ELEMITEM"
- HIDDEN="NO"
- KEYTYPE ("PRIMARY KEY" or "NOT A KEY")
- LENGTH (numeric value)
- LEVEL="0"
- NAME (field name)
- NULLABLE ("NULL" or "NOTNULL")
- OCCURS="0"
- OFFSET (calculated value)
- PHYSICALLENGTH (numeric value)
- PHYSICALOFFSET (calculated value)
- PICTURETEXT=""
- PRECISION (numeric value)
- SCALE (numeric value)
- USAGE_FLAGS=""

## 6. TARGET DEFINITION STRUCTURE:

### Complete TARGET Example:
<TARGET BUSINESSNAME="" CONSTRAINT="" DATABASETYPE="Flat File" DESCRIPTION="" NAME="TARGET_FILE_NAME" OBJECTVERSION="1" TABLEOPTIONS="" VERSIONNUMBER="1">

### TARGETFIELD Attribute Pattern (FROM TEMPLATE):
{targetfield_text}

### Critical TARGETFIELD Attributes (NEVER OMIT):
- BUSINESSNAME (can be empty: BUSINESSNAME="")
- DATATYPE (e.g., "string", "number", "date")
- FIELDNUMBER (sequential: "1", "2", "3"...)
- KEYTYPE ("PRIMARY KEY" or "NOT A KEY")
- NAME (field name)
- NULLABLE ("NULL" or "NOTNULL")
- PICTURETEXT=""
- PRECISION (numeric value)
- SCALE (numeric value)

## 7. MAPPING STRUCTURE:

### MAPPING Element:
<MAPPING DESCRIPTION="Mapping description" ISVALID="YES" NAME="m_Mapping_Name" OBJECTVERSION="1" VERSIONNUMBER="1">

## 8. TRANSFORMATION PATTERNS (FROM TEMPLATE):

### Example Transformation:
{transformation_text}

### Lookup Transformation Structure (FROM TEMPLATE):
- TYPE must be "Lookup" (NOT "Lookup Procedure" for table lookups)
- Must include TABLEATTRIBUTE with lookup table name
- Must include TABLEATTRIBUTE with lookup condition (use :INPUT. prefix for input ports)
- Port types: INPUT, OUTPUT, LOOKUP, LOCAL VARIABLE
- EXPRESSION attribute for calculated fields

## 9. CONNECTOR PATTERNS (FROM TEMPLATE):

### Complete CONNECTOR Attribute Pattern:
{connector_text}

### Critical CONNECTOR Attributes (ALL REQUIRED):
- FROMFIELD (source field name)
- FROMINSTANCE (source object name: SOURCE_NAME or TRANSFORMATION_NAME)
- FROMINSTANCETYPE ("Source Definition", "Expression", "Lookup", "Filter", etc.)
- TOFIELD (target field name)
- TOINSTANCE (target object name: TARGET_NAME or TRANSFORMATION_NAME)
- TOINSTANCETYPE ("Target Definition", "Expression", "Lookup", etc.)

## 10. CRITICAL RULES FROM TEMPLATE ANALYSIS:

### Attribute Formatting:
- Use spaces between attributes: BUSINESSNAME="" DATATYPE="string"
- Use double quotes for all values
- Empty strings must be explicit: BUSINESSNAME=""
- Boolean values: "YES"/"NO", not "true"/"false"

### Data Types (FROM TEMPLATE):
- Strings: "string", "varchar2", "nvarchar2", "nchar"
- Numbers: "number(p,s)", "decimal", "number"
- Dates: "date"
- Use precision and scale appropriately

### Field Numbering:
- FIELDNUMBER starts at "1" and increments sequentially
- NO gaps in field numbers
- Must match the actual field count

### Object Versioning:
- OBJECTVERSION="1"
- VERSIONNUMBER (increments with changes)

### DBDNAME Usage:
- SOURCE elements MUST have DBDNAME attribute with database name
- TARGET elements for flat files may not need DBDNAME

## 11. CLOSING TAGS (REQUIRED):
</MAPPING>
</FOLDER>
</REPOSITORY>
</POWERMART>

## 12. VALIDATION CHECKLIST:
✅ XML header and DOCTYPE exactly as template
✅ All POWERMART/REPOSITORY/FOLDER attributes present
✅ SOURCEFIELD count matches input source fields
✅ TARGETFIELD count matches input target fields
✅ All required attributes present (no missing attributes)
✅ FIELDNUMBER sequential from 1 to N (no gaps)
✅ CONNECTOR count matches field mapping count
✅ Lookup transformations have TABLEATTRIBUTE elements
✅ All FROMINSTANCE/TOINSTANCE names match actual object names
✅ No placeholder comments like <!-- Add remaining fields -->
✅ Proper spacing in attributes: BUSINESSNAME="" not BUSINESSNAME=""
✅ All tags properly closed

## 13. CRITICAL GENERATION RULES:
- Copy attribute names and ordering style from the template examples
- Generate only XML code. No headings, prose, markdown fences, comments, or placeholders
- FIELDNUMBER must start at 1 and increment sequentially with no gaps
- Every source field needs a SOURCEFIELD and every target field needs a TARGETFIELD
- Every target mapping path must be connected with CONNECTOR elements using real instance names
- Preserve Informatica object wrappers: POWERMART, REPOSITORY, FOLDER, SOURCE, TARGET, MAPPING, TRANSFORMATION, INSTANCE, CONNECTOR
- Include lookup or expression transformations only when justified by transformation logic
- Close all tags properly and end exactly at the POWERMART closing tag
- Include ALL attributes shown in template examples for each element type
""".strip()


# -----------------------------
# Main DAAN 5 native tool
# -----------------------------


class InformaticaXMLGeneration:
    """
    DAAN 5 Native Tool class.
    Keep class+method stable for tools_loader mapping.
    """

    def __init__(self, template_xml_path: Optional[str] = None, data_dir: Optional[str] = None, **_: Any) -> None:
        self.tool_name = "InformaticaXMLGeneration"
        self.template_xml_path = template_xml_path
        self.data_dir = data_dir  # Store session input directory for auto-detection
        self._sttm_excel_cache: dict[tuple[str, float], dict[str, Any]] = {}
        self._tokens_cache: dict[str, set[str]] = {}
        logger.info("InformaticaXMLGeneration v%s loaded (data_dir=%s)", _TOOL_VERSION, data_dir)

    def generate_xml(
        self,
        sttm_payload: dict[str, Any] | str | None = None,
        template_xml_path: str | None = None,
        escapeOutput: bool | str | None = None,
        **kwargs: Any,
    ) -> str:
        """
        Generate Informatica PowerCenter Mapping XML from Source-to-Target Mapping (STTM) specifications.
        
        This tool creates complete Informatica PowerCenter XML mappings including sources, targets,
        transformations (Expression, Lookup, Filter, Joiner, Aggregator, Router, Sorter), and connections.
        
        Args:
            sttm_payload: Source-to-Target Mapping data in one of these formats:
                         - dict: Structured mapping with keys like 'Mapping Name', 'Source Name', 
                           'Target Name', 'Source Field', 'Target Field', 'Transformation Logic', etc.
                         - JSON string: String-encoded version of the dict format
                         - None: Tool will auto-detect and read from uploaded Excel/CSV STTM file
                         
                         Example dict format:
                         {
                           "Mapping Name": "m_Load_Customer",
                           "Mapping Complexity": "Simple",
                           "Source Name": "SRC_CUSTOMER",
                           "Target Name": "TGT_CUSTOMER", 
                           "Source Type": "Oracle",
                           "Target Type": "SQL Server",
                           "Source Object": "CUSTOMERS",
                           "Source Field": "CUST_ID,CUST_NAME,EMAIL",
                           "Target Object": "DIM_CUSTOMER",
                           "Target Field": "CUSTOMER_ID,CUSTOMER_NAME,EMAIL_ADDRESS",
                           "Transformation Logic": "Direct mapping with EMAIL validation"
                         }
            
            template_xml_path: Optional path to reference Informatica XML template for pattern extraction.
                              If not provided, tool uses built-in patterns and auto-detection.
            
                        escapeOutput: Controls output format:
                                                 - True: Returns HTML-escaped XML wrapped in <pre><code> for UI safety
                                                 - False: Returns raw PowerMart XML starting with <?xml version="1.0"?>
                                                 - None (default): Returns UI-safe escaped XML for session-backed agent calls,
                                                     otherwise returns raw XML
        
        Returns:
            Complete Informatica PowerCenter XML mapping as a string. Format depends on resolved escapeOutput behavior.
            XML includes: POWERMART structure, REPOSITORY, FOLDER, SOURCE definitions, TARGET definitions,
            MAPPING with all specified transformations, INSTANCE connections, and CONNECTOR links.
        
        Examples:
            # Auto-detect from uploaded file
            xml = generate_xml()
            
            # Provide STTM as dict
            xml = generate_xml(sttm_payload={
                "Mapping Name": "m_Load_Sales",
                "Source Name": "SRC_SALES",
                "Target Name": "TGT_SALES",
                "Source Field": "SALE_ID,AMOUNT",
                "Target Field": "TRANSACTION_ID,REVENUE"
            })
            
            # Get raw XML for direct import
            raw_xml = generate_xml(sttm_payload=my_sttm_dict, escapeOutput=False)
        """
        should_escape_output = self._resolve_escape_output(escapeOutput, kwargs)
        fields = self._normalize_input(sttm_payload, kwargs)

        analyzer = _TemplateAnalyzer(template_xml_path or self.template_xml_path)
        analyzer.load()
        template = analyzer.analyze()

        llm_xml = ""
        if self._should_attempt_llm(kwargs):
            prompt = self._build_prompt(fields, template, escapeOutput=should_escape_output)
            try:
                llm_output = get_llm_response_with_fallback(prompt=prompt, temperature=0.0)
                llm_xml = _ensure_boundaries(_extract_xml_block(llm_output))
            except Exception as e:
                logger.warning("LLM call failed, using fallback. err=%s", e)
        else:
            logger.info(
                "%s v%s: skipping LLM generation and using deterministic XML path",
                self.tool_name,
                _TOOL_VERSION,
            )

        # 1) Validate; fallback if needed
        if not _is_well_formed_powermart_xml(llm_xml):
            llm_xml = self._deterministic_fallback(fields, template)
        elif self._should_prefer_deterministic_output(llm_xml, fields):
            logger.info("%s v%s: using deterministic fallback because LLM XML missed required STTM-aligned structure", self.tool_name, _TOOL_VERSION)
            llm_xml = self._deterministic_fallback(fields, template)

        llm_xml = _ensure_boundaries(_extract_xml_block(llm_xml))
        if not _is_well_formed_powermart_xml(llm_xml):
            raise ValueError("Failed to generate valid Informatica POWERMART XML")

        artifact_path = self._write_xml_artifact(
            llm_xml,
            mapping_name=self._pick(fields, "Mapping Name", "mapping_name") or "STTM_Mapping",
        )
        if artifact_path is not None:
            logger.info("%s: wrote XML artifact %s", self.tool_name, artifact_path)

        # 3) Return escaped or raw
        if should_escape_output:
            return self._escape_xml_for_ui(llm_xml)
        return llm_xml

    def _resolve_escape_output(self, escape_output: Any, kwargs: dict[str, Any]) -> bool:
        explicit_value = escape_output
        if explicit_value is None:
            for key in ("escapeOutput", "escape_output", "ui_safe_output", "escape_xml_for_ui"):
                if kwargs.get(key) is not None:
                    explicit_value = kwargs.get(key)
                    break

        if explicit_value is not None:
            return self._is_truthy(explicit_value)

        return self._is_session_backed_request(kwargs)

    def _is_session_backed_request(self, kwargs: dict[str, Any]) -> bool:
        if self.data_dir or kwargs.get("data_dir"):
            return True

        if daan_session_id.get():
            return True

        reviewed_output = kwargs.get("reviewed_output")
        if isinstance(reviewed_output, dict):
            for path_key in ("excel_path", "file_path", "sttm_path", "input_file"):
                maybe_path = reviewed_output.get(path_key)
                if isinstance(maybe_path, str) and "session_storage" in maybe_path.replace("\\", "/"):
                    return True

        return False

    def _should_attempt_llm(self, kwargs: dict[str, Any]) -> bool:
        explicit_value = kwargs.get("use_llm")
        if explicit_value is None:
            explicit_value = kwargs.get("prefer_llm")
        if explicit_value is not None:
            return self._is_truthy(explicit_value)

        env_value = os.getenv("INFORMATICA_XML_USE_LLM")
        if env_value is not None:
            return self._is_truthy(env_value)

        return False

    def _is_truthy(self, value: Any) -> bool:
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}

    # -----------------------------
    # Input normalization
    # -----------------------------

    def _normalize_input(self, payload: Any, kwargs: dict[str, Any]) -> dict[str, Any]:
        merged: dict[str, Any] = {}

        if isinstance(payload, dict):
            merged.update(payload)
            for path_key in ("excel_path", "file_path", "sttm_path", "input_file"):
                maybe_path = payload.get(path_key)
                if isinstance(maybe_path, str) and self._is_excel_path(maybe_path):
                    merged.update(self._get_cached_sttm_payload_from_excel(maybe_path))
        elif isinstance(payload, str) and payload.strip():
            raw = payload.strip()
            # Accept direct STTM file path input and parse it to DAAN payload shape.
            if self._is_excel_path(raw):
                merged.update(self._extract_sttm_payload_from_excel(raw))
            else:
                try:
                    parsed = json.loads(raw)
                    if isinstance(parsed, dict):
                        merged.update(parsed)
                    else:
                        merged["Raw Input"] = raw
                except Exception:
                    merged["Raw Input"] = raw

        # Support common path-style kwargs for uploaded STTM workbook locations.
        for path_key in ("excel_path", "file_path", "sttm_path", "input_file"):
            maybe_path = kwargs.get(path_key)
            if isinstance(maybe_path, str) and self._is_excel_path(maybe_path):
                merged.update(self._get_cached_sttm_payload_from_excel(maybe_path))

        # Handle reviewed output wrappers that may carry an inner path.
        reviewed = kwargs.get("reviewed_output")
        if isinstance(reviewed, dict):
            for path_key in ("excel_path", "file_path", "sttm_path", "input_file"):
                maybe_path = reviewed.get(path_key)
                if isinstance(maybe_path, str) and self._is_excel_path(maybe_path):
                    merged.update(self._get_cached_sttm_payload_from_excel(maybe_path))

            inner_payload = reviewed.get("sttm_payload")
            if isinstance(inner_payload, dict):
                merged.update(inner_payload)

        for k, v in kwargs.items():
            if k in {"excel_path", "file_path", "sttm_path", "input_file", "reviewed_output"}:
                continue
            if v in (None, ""):
                continue
            human_key = k.replace("_", " ").title()
            merged[human_key] = v

        if not self._has_structured_sttm_content(merged):
            # Try to auto-detect Excel file from session storage or data_dir
            # Use the data_dir from constructor if available, otherwise check kwargs
            data_dir_to_check = self.data_dir or kwargs.get("data_dir")
            auto_excel_path = self._auto_detect_excel_file(data_dir_to_check)
            if auto_excel_path:
                logger.info(f"Auto-detected Excel file: {auto_excel_path}")
                merged.update(self._get_cached_sttm_payload_from_excel(auto_excel_path))
                merged.setdefault("Input File", auto_excel_path)

        return merged

    def _has_structured_sttm_content(self, fields: dict[str, Any]) -> bool:
        mapping_name = self._clean_value(fields.get("Mapping Name") or fields.get("mapping_name") or "")
        source_field = self._clean_value(fields.get("Source Field") or fields.get("source_field") or "")
        target_field = self._clean_value(fields.get("Target Field") or fields.get("target_field") or "")
        transformation_logic = self._clean_value(fields.get("Transformation Logic") or fields.get("transformation_logic") or "")

        return any(
            value and value.lower() not in {"unknown", "unknown_to_unknown", "unknown_source", "unknown_target"}
            for value in (mapping_name, source_field, target_field, transformation_logic)
        )

    def _auto_detect_excel_file(self, data_dir: Any) -> str | None:
        """
        Auto-detect Excel file from multiple sources:
        1. Provided data_dir parameter (absolute or relative path)
        2. Session storage inputs directory (for uploaded files)
        3. Current working directory
        """
        # Priority 1: Check provided data_dir (could be absolute session path)
        if isinstance(data_dir, str) and data_dir.strip():
            excel_path = self._find_excel_in_dir(Path(data_dir))
            if excel_path:
                logger.info(f"Found Excel file in provided data_dir: {excel_path}")
                return excel_path
        
        # Priority 2: Check session storage inputs directory via context variable
        session_id = daan_session_id.get()
        if session_id:
            # Standard DAAN 5 session storage structure: session_storage/<session_id>/inputs/
            session_input_dir = Path("session_storage") / session_id / "inputs"
            if session_input_dir.exists() and session_input_dir.is_dir():
                excel_path = self._find_excel_in_dir(session_input_dir)
                if excel_path:
                    logger.info(f"Found Excel file in session storage: {excel_path}")
                    return excel_path
        
        # Priority 3: Check current working directory
        excel_path = self._find_excel_in_dir(Path.cwd())
        if excel_path:
            logger.info(f"Found Excel file in current directory: {excel_path}")
            return excel_path
        
        logger.warning("No Excel file found in data_dir, session storage, or current directory")
        return None

    def _find_excel_in_dir(self, directory: Path) -> str | None:
        """Find the most recent Excel file in the given directory."""
        if not directory or not directory.exists() or not directory.is_dir():
            return None

        try:
            excel_files = sorted(
                [path for path in directory.iterdir() if path.is_file() and re.search(r"\.(xlsx|xlsm|xls)$", path.name, flags=re.IGNORECASE)],
                key=lambda path: path.stat().st_mtime,
                reverse=True,
            )
            if excel_files:
                return str(excel_files[0])
        except Exception as e:
            logger.warning(f"Error scanning directory {directory}: {e}")
        
        return None

    def _is_excel_path(self, value: str) -> bool:
        v = (value or "").strip()
        if not v:
            return False
        if not re.search(r"\.(xlsx|xlsm|xls)\s*$", v, flags=re.IGNORECASE):
            return False
        return Path(v).expanduser().exists()

    def _get_cached_sttm_payload_from_excel(self, excel_path: str) -> dict[str, Any]:
        try:
            resolved_path = Path(excel_path).expanduser().resolve()
            stat = resolved_path.stat()
            cache_key = (str(resolved_path), stat.st_mtime)
        except Exception:
            return self._extract_sttm_payload_from_excel(excel_path)

        cached_payload = self._sttm_excel_cache.get(cache_key)
        if cached_payload is not None:
            logger.info("%s: reusing cached STTM workbook parse for %s", self.tool_name, resolved_path)
            return dict(cached_payload)

        payload = self._extract_sttm_payload_from_excel(str(resolved_path))
        self._sttm_excel_cache = {cache_key: dict(payload)}
        return payload

    def _extract_sttm_payload_from_excel(self, excel_path: str) -> dict[str, Any]:
        defaults: dict[str, Any] = {
            "Mapping Name": "Unknown_to_Unknown",
            "Mapping Complexity": "Simple",
            "Source Name": "Unknown_Source",
            "Source Type": "Unknown",
            "Source Object": "Unknown",
            "Source Field": "",
            "Target Name": "Unknown_Target",
            "Target Type": "Unknown",
            "Target Object": "Unknown",
            "Target Field": "",
            "Transformation Logic": "",
        }

        try:
            book = pd.read_excel(excel_path, sheet_name=None, dtype=str, header=None)
        except Exception:
            logger.exception("%s: failed to read STTM workbook %s", self.tool_name, excel_path)
            return defaults

        if not book:
            return defaults

        prepared: dict[str, pd.DataFrame] = {
            name: self._prepare_sheet(df) for name, df in book.items()
        }
        prepared = {k: v for k, v in prepared.items() if not v.empty}
        if not prepared:
            return defaults

        mapping_sheet = self._pick_mapping_sheet(prepared)
        mapping_df = prepared.get(mapping_sheet, pd.DataFrame())
        if mapping_df.empty:
            return defaults

        metadata_df = self._pick_metadata_sheet(prepared, mapping_sheet)
        metadata = self._extract_metadata(metadata_df)

        cols = list(mapping_df.columns)
        src_obj_col = self._pick_column_by_priority(
            cols,
            preferred=["source_table_name", "source_object_name", "source_object", "source_entity_name", "source_name"],
            include=[["source", "src"], ["table", "object", "entity"]],
            exclude={"attribute", "field", "column"},
        )
        tgt_obj_col = self._pick_column_by_priority(
            cols,
            preferred=["target_table_name", "target_object_name", "target_object", "target_entity_name", "target_name"],
            include=[["target", "tgt", "destination"], ["table", "object", "entity"]],
            exclude={"attribute", "field", "column"},
        )
        src_field_col = self._pick_column_by_priority(
            cols,
            preferred=["source_attribute_name", "source_field_name", "source_column_name", "source_field", "source_column"],
            include=[["source", "src"], ["field", "column", "attribute"]],
        )
        tgt_field_col = self._pick_column_by_priority(
            cols,
            preferred=["target_attribute_name", "target_field_name", "target_column_name", "target_field", "target_column"],
            include=[["target", "tgt", "destination"], ["field", "column", "attribute"]],
        )

        src_type_col = self._pick_column_by_priority(
            cols,
            preferred=["source_data_type", "source_datatype", "src_data_type", "src_datatype"],
            include=[["source", "src"], ["data", "datatype", "type"]],
        )
        tgt_type_col = self._pick_column_by_priority(
            cols,
            preferred=["target_data_type", "target_datatype", "tgt_data_type", "tgt_datatype"],
            include=[["target", "tgt", "destination"], ["data", "datatype", "type"]],
        )
        src_len_col = self._pick_column_by_priority(
            cols,
            preferred=["source_data_length_precision", "source_length", "source_precision", "src_length", "src_precision"],
            include=[["source", "src"], ["length", "precision", "scale"]],
        )
        tgt_len_col = self._pick_column_by_priority(
            cols,
            preferred=["target_data_length_precision", "target_length", "target_precision", "tgt_length", "tgt_precision"],
            include=[["target", "tgt", "destination"], ["length", "precision", "scale"]],
        )

        logic_cols = [
            c
            for c in cols
            if self._contains_any(c, {"mapping", "transform", "rule", "business", "validation", "clean", "standard", "mask", "logic"})
            and c not in {src_obj_col, tgt_obj_col, src_field_col, tgt_field_col}
        ]

        source_objects: list[str] = []
        target_objects: list[str] = []
        source_fields: list[str] = []
        target_fields: list[str] = []
        source_field_specs: list[dict[str, str]] = []
        target_field_specs: list[dict[str, str]] = []
        row_logic: list[str] = []

        for _, row in mapping_df.iterrows():
            row_text = self._row_text(row)
            s_obj = self._clean_value(row.get(src_obj_col, "")) if src_obj_col else ""
            t_obj = self._clean_value(row.get(tgt_obj_col, "")) if tgt_obj_col else ""
            s_fld = self._clean_value(row.get(src_field_col, "")) if src_field_col else ""
            t_fld = self._clean_value(row.get(tgt_field_col, "")) if tgt_field_col else ""
            source_nullable = self._derive_nullable_from_row(row_text)
            target_nullable = self._derive_nullable_from_row(row_text)
            source_keytype = self._derive_keytype_from_row(row_text, role="source")
            target_keytype = self._derive_keytype_from_row(row_text, role="target")
            if target_keytype == "PRIMARY KEY" and source_keytype == "NOT A KEY":
                source_keytype = "PRIMARY KEY"

            if s_obj:
                source_objects.append(s_obj)
            if t_obj:
                target_objects.append(t_obj)
            if s_fld:
                source_fields.append(s_fld)
            if t_fld:
                target_fields.append(t_fld)

            if s_fld:
                source_field_specs.append(
                    self._build_field_spec_dict(
                        name=s_fld,
                        datatype=self._clean_value(row.get(src_type_col, "")) if src_type_col else "",
                        length_precision=self._clean_value(row.get(src_len_col, "")) if src_len_col else "",
                        nullable=source_nullable,
                        keytype=source_keytype,
                    )
                )
            if t_fld:
                target_field_specs.append(
                    self._build_field_spec_dict(
                        name=t_fld,
                        datatype=self._clean_value(row.get(tgt_type_col, "")) if tgt_type_col else "",
                        length_precision=self._clean_value(row.get(tgt_len_col, "")) if tgt_len_col else "",
                        nullable=target_nullable,
                        keytype=target_keytype,
                    )
                )

            parts: list[str] = []
            for lc in logic_cols:
                val = self._clean_value(row.get(lc, ""))
                if val:
                    parts.append(f"{lc.replace('_', ' ').title()}: {val}")
            if parts:
                row_logic.append(" | ".join(parts))

        source_objects = self._unique_keep_order(source_objects)
        target_objects = self._unique_keep_order(target_objects)
        source_fields = self._unique_keep_order(source_fields)
        target_fields = self._unique_keep_order(target_fields)

        source_object = source_objects[0] if source_objects else "Unknown"
        target_object = target_objects[0] if target_objects else "Unknown"

        source_name = self._derive_name(source_object, "Unknown_Source")
        target_name = self._derive_name(target_object, "Unknown_Target")
        mapping_name = f"{self._derive_name(source_object, 'Unknown')}_to_{self._derive_name(target_object, 'Unknown')}"

        source_type = metadata.get("Source Type", "Unknown")
        target_type = metadata.get("Target Type", "Unknown")
        if source_type == "Unknown":
            source_type = self._infer_type([mapping_sheet, source_object] + source_objects[:3])
        if target_type == "Unknown":
            target_type = self._infer_type([mapping_sheet, target_object] + target_objects[:3])

        payload = {
            "Mapping Name": mapping_name,
            "Mapping Complexity": self._mapping_complexity(row_logic),
            "Source Name": source_name,
            "Source Type": source_type,
            "Source Object": source_object,
            "Source Field": ", ".join(source_fields),
            "Source Field Specs": self._dedupe_field_specs(source_field_specs),
            "Target Name": target_name,
            "Target Type": target_type,
            "Target Object": target_object,
            "Target Field": ", ".join(target_fields),
            "Target Field Specs": self._dedupe_field_specs(target_field_specs),
            "Transformation Logic": "\n".join(row_logic),
            "Repository Name": metadata.get("Repository Name", "DataEngineeringRepo"),
            "Folder Name": metadata.get("Folder Name", mapping_name),
            "Folder Description": metadata.get("Folder Description", ""),
            "Mapping Description": metadata.get("Mapping Description", ""),
            "Mapping Owner": metadata.get("Mapping Owner", "owner"),
            "Source Database Name": metadata.get("Source Database Name", f"{source_name}_DB"),
        }

        for k, dv in defaults.items():
            if self._clean_value(payload.get(k, "")) == "":
                payload[k] = dv

        return payload

    def _build_field_spec_dict(
        self,
        name: str,
        datatype: str,
        length_precision: str,
        *,
        nullable: str = "NULL",
        keytype: str = "NOT A KEY",
    ) -> dict[str, str]:
        normalized_type = self._normalize_informatica_datatype(datatype)
        length, precision, scale = self._extract_precision_parts(length_precision, normalized_type)
        return {
            "name": name,
            "datatype": normalized_type,
            "length": length,
            "precision": precision,
            "scale": scale,
            "nullable": nullable,
            "keytype": keytype,
        }

    def _dedupe_field_specs(self, specs: list[dict[str, str]]) -> list[dict[str, str]]:
        deduped: list[dict[str, str]] = []
        seen: set[str] = set()
        for spec in specs:
            name = self._clean_value(spec.get("name", ""))
            if not name:
                continue
            key = name.lower()
            if key in seen:
                continue
            seen.add(key)
            deduped.append(spec)
        return deduped

    def _normalize_informatica_datatype(self, datatype: str) -> str:
        dt = self._clean_value(datatype).lower()
        if not dt:
            return "VARCHAR"
        if dt in {"char", "nchar"}:
            return "CHAR"
        if dt == "date":
            return "DATE"
        if dt in {"datetime", "timestamp"}:
            return "TIMESTAMP"
        if dt in {"bool", "boolean"}:
            return "BOOLEAN"
        if dt in {"number", "numeric", "decimal", "int", "integer", "bigint", "smallint", "float", "double"}:
            return "INT"
        if dt in {"varchar", "varchar2", "nvarchar", "nvarchar2", "text", "string"}:
            return "VARCHAR"
        return dt.upper()

    def _row_text(self, row: pd.Series) -> str:
        values = [self._clean_value(value) for value in row.tolist()]
        return " | ".join(value for value in values if value)

    def _derive_nullable_from_row(self, row_text: str) -> str:
        text = self._clean_value(row_text).lower()
        if any(token in text for token in {"must not be null", "not null", "cannot be null", "mandatory", "required"}):
            return "NOTNULL"
        return "NULL"

    def _derive_keytype_from_row(self, row_text: str, *, role: str) -> str:
        text = self._clean_value(row_text).lower()
        if "primary key in dw" in text:
            return "PRIMARY KEY"
        if role == "target" and any(token in text for token in {"target primary key", "dw primary key"}):
            return "PRIMARY KEY"
        if role == "source" and any(token in text for token in {"source primary key", "primary key in source"}):
            return "PRIMARY KEY"
        if re.search(r"\bpk\b", text):
            return "PRIMARY KEY"
        return "NOT A KEY"

    def _extract_precision_parts(self, length_precision: str, datatype: str) -> tuple[str, str, str]:
        raw = self._clean_value(length_precision)
        if not raw:
            default_metric = self._default_metric_for_type(datatype)
            return default_metric, default_metric, "0"

        parts = re.findall(r"\d+", raw)
        if not parts:
            default_metric = self._default_metric_for_type(datatype)
            return default_metric, default_metric, "0"

        if len(parts) >= 2:
            precision = parts[0]
            scale = parts[1]
            return precision, precision, scale

        metric = parts[0]
        return metric, metric, "0"

    def _clean_value(self, value: Any) -> str:
        if value is None:
            return ""
        text = str(value).strip()
        if not text or text.lower() in {"nan", "none", "null"}:
            return ""
        return re.sub(r"\s+", " ", text)

    def _norm_key(self, value: Any) -> str:
        text = self._clean_value(value)
        text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", text)
        text = text.lower()
        text = re.sub(r"[^a-z0-9]+", " ", text)
        return re.sub(r"\s+", " ", text).strip()

    def _tokens(self, value: Any) -> set[str]:
        nk = self._norm_key(value)
        if not nk:
            return set()
        
        # Memoization: cache tokenization results
        if nk in self._tokens_cache:
            return self._tokens_cache[nk]
        
        aliases = {
            "src": "source",
            "tgt": "target",
            "trg": "target",
            "dest": "target",
            "destination": "target",
            "tbl": "table",
            "obj": "object",
            "ent": "entity",
            "attr": "attribute",
            "attrib": "attribute",
            "col": "column",
            "fld": "field",
            "nm": "name",
            "desc": "description",
            "dt": "datatype",
            "dtype": "datatype",
            "len": "length",
            "prec": "precision",
            "xform": "transformation",
            "xfm": "transformation",
            "expr": "expression",
            "calc": "logic",
            "derivation": "logic",
            "mappinglogic": "logic",
        }
        expanded: set[str] = set()
        for token in nk.split():
            expanded.add(token)
            if token in aliases:
                expanded.add(aliases[token])
            if token.endswith("nm") and len(token) > 2:
                expanded.add(token[:-2])
                expanded.add("name")
            if token.endswith("tbl") and len(token) > 3:
                expanded.add(token[:-3])
                expanded.add("table")
            if token.endswith("col") and len(token) > 3:
                expanded.add(token[:-3])
                expanded.add("column")
            if token.endswith("fld") and len(token) > 3:
                expanded.add(token[:-3])
                expanded.add("field")
        
        self._tokens_cache[nk] = expanded
        return expanded

    def _contains_any(self, value: Any, words: set[str]) -> bool:
        return bool(self._tokens(value).intersection(words))

    def _best_header_row(self, df: pd.DataFrame, max_scan_rows: int = 10) -> int:
        if df.empty:
            return 0
        keywords = {
            "source",
            "target",
            "column",
            "field",
            "attribute",
            "transformation",
            "rule",
            "mapping",
            "table",
            "object",
        }
        best_idx = 0
        best_score = -1.0
        rows = min(max_scan_rows, len(df))

        for idx in range(rows):
            row = [self._clean_value(v) for v in df.iloc[idx].tolist()]
            row = [v for v in row if v]
            if not row:
                continue
            hit = sum(1 for c in row if self._tokens(c).intersection(keywords))
            score = hit * 3.0 + len(row) * 0.3
            if score > best_score:
                best_score = score
                best_idx = idx
            # Early termination: if >=70% of non-empty cells match keywords, this is likely the header
            if len(row) >= 3 and hit / len(row) >= 0.7:
                return idx

        return best_idx

    def _prepare_sheet(self, raw_df: pd.DataFrame) -> pd.DataFrame:
        if raw_df is None or raw_df.empty:
            return pd.DataFrame()

        header_row = self._best_header_row(raw_df)
        headers = []
        seen: dict[str, int] = {}
        for i, h in enumerate(raw_df.iloc[header_row].tolist()):
            base = self._norm_key(h).replace(" ", "_") or f"col_{i}"
            seen[base] = seen.get(base, 0) + 1
            headers.append(base if seen[base] == 1 else f"{base}_{seen[base]}")

        data = raw_df.iloc[header_row + 1 :].copy()
        data.columns = headers
        data = data.dropna(axis=0, how="all").dropna(axis=1, how="all")
        for c in data.columns:
            data[c] = data[c].map(self._clean_value)
        return data

    def _sheet_scores(self, sheet_name: str, df: pd.DataFrame) -> tuple[float, float]:
        if df.empty:
            return 0.0, 0.0
        headers = list(df.columns)
        name_toks = self._tokens(sheet_name)
        mapping_words = {"source", "target", "field", "column", "attribute", "transformation", "rule", "mapping", "table", "object"}
        metadata_words = {"metadata", "system", "owner", "version", "source", "target", "type", "application", "project"}
        m_hits = sum(1 for h in headers if self._contains_any(h, mapping_words))
        md_hits = sum(1 for h in headers if self._contains_any(h, metadata_words))
        m_bonus = 2.0 if name_toks.intersection({"mapping", "sttm", "map"}) else 0.0
        md_bonus = 2.0 if name_toks.intersection({"meta", "metadata", "config", "info"}) else 0.0
        return m_hits * 1.6 + m_bonus, md_hits * 1.5 + md_bonus

    def _pick_mapping_sheet(self, sheets: dict[str, pd.DataFrame]) -> str:
        best_name = ""
        best_score = -1.0
        for name, df in sheets.items():
            m_score, _ = self._sheet_scores(name, df)
            if m_score > best_score:
                best_score = m_score
                best_name = name
        return best_name

    def _pick_metadata_sheet(self, sheets: dict[str, pd.DataFrame], mapping_sheet_name: str) -> pd.DataFrame:
        best_df = pd.DataFrame()
        best_score = -1.0
        for name, df in sheets.items():
            if name == mapping_sheet_name:
                continue
            _, md_score = self._sheet_scores(name, df)
            if md_score > best_score:
                best_score = md_score
                best_df = df
        return best_df

    def _best_col(self, columns: list[str], include: list[list[str]]) -> Optional[str]:
        candidates: list[tuple[int, str]] = []
        for c in columns:
            toks = self._tokens(c)
            score = 0
            for group in include:
                if toks.intersection(set(group)):
                    score += 1
            if score > 0:
                candidates.append((score, c))
        if not candidates:
            return None
        candidates.sort(key=lambda x: x[0], reverse=True)
        return candidates[0][1]

    def _pick_column_by_priority(
        self,
        columns: list[str],
        *,
        preferred: list[str],
        include: list[list[str]],
        exclude: set[str] | None = None,
    ) -> Optional[str]:
        normalized = {self._norm_key(column).replace(" ", "_"): column for column in columns}
        normalized_tokens = {column: self._tokens(column) for column in columns}
        blocked = exclude or set()

        for key in preferred:
            normalized_key = self._norm_key(key).replace(" ", "_")
            if normalized_key in normalized:
                return normalized[normalized_key]

        fuzzy_match: tuple[float, str] | None = None
        for key in preferred:
            normalized_key = self._norm_key(key).replace(" ", "_")
            for candidate_key, candidate_column in normalized.items():
                ratio = difflib.SequenceMatcher(None, normalized_key, candidate_key).ratio()
                if ratio >= 0.84 and (fuzzy_match is None or ratio > fuzzy_match[0]):
                    fuzzy_match = (ratio, candidate_column)
        if fuzzy_match is not None:
            return fuzzy_match[1]

        candidates: list[tuple[int, str]] = []
        for column in columns:
            toks = normalized_tokens[column]
            if blocked and toks.intersection(blocked):
                continue
            score = 0
            for group in include:
                normalized_group = {alias for token in group for alias in self._tokens(token)}
                hits = toks.intersection(normalized_group)
                if hits:
                    score += 2 if len(hits) == len(normalized_group.intersection(toks)) and len(hits) > 0 else 1
            if score > 0:
                normalized_name = self._norm_key(column)
                if "name" in toks and all(word not in toks for word in {"field", "column", "attribute"}):
                    score += 1
                if normalized_name.startswith("source") or normalized_name.startswith("target"):
                    score += 1
                candidates.append((score, column))

        if not candidates:
            return None
        candidates.sort(key=lambda item: item[0], reverse=True)
        return candidates[0][1]

    def _extract_metadata(self, metadata_df: pd.DataFrame) -> dict[str, str]:
        out = {
            "Source Type": "Unknown",
            "Target Type": "Unknown",
            "Mapping Version": "Unknown",
            "Mapping Owner": "Unknown",
            "Repository Name": "DataEngineeringRepo",
            "Folder Name": "",
            "Folder Description": "",
            "Mapping Description": "",
            "Source Database Name": "",
        }
        if metadata_df.empty:
            return out

        if len(metadata_df.columns) >= 2:
            first_key = self._norm_key(metadata_df.columns[0])
            first_value = self._clean_value(metadata_df.columns[1])
            if first_key and first_value:
                self._apply_metadata_value(out, first_key, first_value)

        for _, row in metadata_df.iterrows():
            vals = [self._clean_value(v) for v in row.tolist() if self._clean_value(v)]
            if len(vals) < 2:
                continue
            key = self._norm_key(vals[0])
            val = vals[1]
            self._apply_metadata_value(out, key, val)

        return out

    def _apply_metadata_value(self, out: dict[str, str], key: str, value: str) -> None:
        if not key or not value:
            return
        if "source" in key and ("type" in key or "system" in key) and out["Source Type"] == "Unknown":
            out["Source Type"] = value
        elif "target" in key and ("type" in key or "system" in key) and out["Target Type"] == "Unknown":
            out["Target Type"] = value
        elif "version" in key and out["Mapping Version"] == "Unknown":
            out["Mapping Version"] = value
        elif ("owner" in key or "author" in key) and out["Mapping Owner"] == "Unknown":
            out["Mapping Owner"] = value
        elif "repository" in key and "name" in key and out["Repository Name"] == "DataEngineeringRepo":
            out["Repository Name"] = value
        elif "folder" in key and "name" in key and not out["Folder Name"]:
            out["Folder Name"] = value
        elif "folder" in key and ("description" in key or "desc" in key) and not out["Folder Description"]:
            out["Folder Description"] = value
        elif "mapping" in key and ("description" in key or "desc" in key) and not out["Mapping Description"]:
            out["Mapping Description"] = value
        elif "source" in key and ("database" in key or "schema" in key or "dbdname" in key or "db name" in key) and not out["Source Database Name"]:
            out["Source Database Name"] = value

    def _infer_type(self, texts: list[str]) -> str:
        joined = " ".join(self._clean_value(t).lower() for t in texts if self._clean_value(t))
        if not joined:
            return "Unknown"
        if "snowflake" in joined:
            return "Snowflake"
        if "oracle" in joined:
            return "Oracle"
        if "sql server" in joined or "mssql" in joined or "ms sql" in joined:
            return "SQL Server"
        return "Unknown"

    def _unique_keep_order(self, values: list[str]) -> list[str]:
        out: list[str] = []
        seen: set[str] = set()
        for v in values:
            cv = self._clean_value(v)
            if not cv:
                continue
            k = cv.lower()
            if k in seen:
                continue
            seen.add(k)
            out.append(cv)
        return out

    def _derive_name(self, obj: str, fallback: str) -> str:
        v = self._clean_value(obj)
        if not v:
            return fallback
        if "." in v:
            v = v.split(".")[-1]
        v = re.sub(r"[^A-Za-z0-9_]+", "_", v).strip("_")
        return v or fallback

    def _mapping_complexity(self, row_logic: list[str]) -> str:
        joined = " ".join(row_logic).lower()
        if not joined:
            return "Simple"
        if any(term in joined for term in ["lookup", "join", "aggregate", "aggregation", "window", "rank", "union", "group by"]):
            return "Complex"
        if any(term in joined for term in ["expression", "case", "decode", "trim", "cast", "convert", "validation", "standard", "clean", "mask", "coalesce", "business rule"]):
            return "Medium"
        return "Simple"

    def _pick(self, data: dict[str, Any], *keys: str) -> str:
        norm = {k.lower().replace(" ", "_").replace("-", "_"): v for k, v in data.items()}
        for key in keys:
            if key in data and str(data[key]).strip():
                return str(data[key]).strip()
            nk = key.lower().replace(" ", "_").replace("-", "_")
            if nk in norm and str(norm[nk]).strip():
                return str(norm[nk]).strip()
        return ""

    def _split_fields(self, value: str) -> list[str]:
        if not value:
            return []
        return [item.strip() for item in re.split(r"[,\n;|]", value) if item.strip()]

    def _field_specs_from_payload(self, fields: dict[str, Any]) -> tuple[list[FieldSpec], list[FieldSpec]]:
        source_specs = self._parse_field_specs(
            fields,
            primary_keys=("Source Field Specs", "Source Fields Detailed", "source_field_specs", "source_fields_detailed"),
            fallback_keys=("Source Field", "Source Fields", "source_field", "source_fields"),
        )
        target_specs = self._parse_field_specs(
            fields,
            primary_keys=("Target Field Specs", "Target Fields Detailed", "target_field_specs", "target_fields_detailed"),
            fallback_keys=("Target Field", "Target Fields", "target_field", "target_fields"),
        )

        if not source_specs:
            source_specs = [FieldSpec(name="SOURCE_FIELD")]
        if not target_specs:
            target_specs = [self._clone_field_spec(spec) for spec in source_specs]

        target_specs = [
            self._clone_field_spec(spec, name=spec.name, keytype=spec.keytype, nullable=spec.nullable)
            for spec in target_specs
        ]

        count = max(len(source_specs), len(target_specs))
        while len(source_specs) < count:
            source_specs.append(self._clone_field_spec(source_specs[-1]))
        while len(target_specs) < count:
            target_specs.append(self._clone_field_spec(target_specs[-1]))

        return source_specs, target_specs

    def _parse_field_specs(
        self,
        fields: dict[str, Any],
        *,
        primary_keys: tuple[str, ...],
        fallback_keys: tuple[str, ...],
    ) -> list[FieldSpec]:
        candidates = [fields.get(key) for key in primary_keys if key in fields]
        candidates.extend(fields.get(key) for key in fallback_keys if key in fields)

        for candidate in candidates:
            specs = self._coerce_field_specs(candidate)
            if specs:
                return specs
        return []

    def _coerce_field_specs(self, value: Any) -> list[FieldSpec]:
        if value is None:
            return []

        if isinstance(value, list):
            specs = [self._field_spec_from_value(item, index + 1) for index, item in enumerate(value)]
            return [spec for spec in specs if spec is not None]

        if isinstance(value, dict):
            normalized = {str(k).strip().lower().replace(" ", "_"): v for k, v in value.items()}
            for key in ("fields", "source_fields", "target_fields", "columns", "items"):
                nested = normalized.get(key)
                nested_specs = self._coerce_field_specs(nested)
                if nested_specs:
                    return nested_specs
            spec = self._field_spec_from_value(value, 1)
            return [spec] if spec is not None else []

        if isinstance(value, str):
            raw = value.strip()
            if not raw:
                return []
            if raw.startswith("[") or raw.startswith("{"):
                try:
                    parsed = json.loads(raw)
                except Exception:
                    parsed = None
                if parsed is not None:
                    return self._coerce_field_specs(parsed)

            items = [item.strip() for item in re.split(r"[,\n;]", raw) if item.strip()]
            specs = [self._field_spec_from_value(item, index + 1) for index, item in enumerate(items)]
            return [spec for spec in specs if spec is not None]

        return []

    def _field_spec_from_value(self, value: Any, position: int) -> Optional[FieldSpec]:
        if isinstance(value, FieldSpec):
            return value

        if isinstance(value, dict):
            normalized = {str(k).strip().lower().replace(" ", "_"): v for k, v in value.items()}
            name = self._clean_value(
                normalized.get("name")
                or normalized.get("field_name")
                or normalized.get("column_name")
                or normalized.get("source_field")
                or normalized.get("target_field")
                or normalized.get("field")
                or normalized.get("column")
            )
            if not name:
                return None

            datatype = self._normalize_informatica_datatype(
                self._clean_value(normalized.get("datatype") or normalized.get("data_type") or normalized.get("type")) or "VARCHAR"
            )
            length = self._clean_numeric_attr(normalized.get("length"), self._default_metric_for_type(datatype))
            precision = self._clean_numeric_attr(normalized.get("precision"), length)
            scale = self._clean_numeric_attr(normalized.get("scale"), "0")
            nullable = self._normalize_nullable(normalized.get("nullable") or normalized.get("nullability"))
            keytype = self._normalize_keytype(normalized.get("keytype") or normalized.get("key_type") or normalized.get("key"))
            return FieldSpec(
                name=name,
                datatype=datatype,
                length=length,
                precision=precision,
                scale=scale,
                nullable=nullable,
                keytype=keytype,
            )

        text = self._clean_value(value)
        if not text:
            return None

        parts = [part.strip() for part in text.split("|")]
        name = parts[0]
        datatype = self._normalize_informatica_datatype(parts[1] if len(parts) > 1 and parts[1] else "VARCHAR")
        length = parts[2] if len(parts) > 2 and parts[2] else self._default_metric_for_type(datatype)
        nullable = parts[3] if len(parts) > 3 and parts[3] else "NULL"
        keytype = parts[4] if len(parts) > 4 and parts[4] else "NOT A KEY"
        return FieldSpec(
            name=name,
            datatype=datatype,
            length=self._clean_numeric_attr(length, self._default_metric_for_type(datatype)),
            precision=self._clean_numeric_attr(length, self._default_metric_for_type(datatype)),
            scale="0",
            nullable=self._normalize_nullable(nullable),
            keytype=self._normalize_keytype(keytype),
        )

    def _clone_field_spec(self, spec: FieldSpec, **overrides: str) -> FieldSpec:
        values = {
            "name": spec.name,
            "datatype": spec.datatype,
            "length": spec.length,
            "precision": spec.precision,
            "scale": spec.scale,
            "nullable": spec.nullable,
            "keytype": spec.keytype,
            "picturetext": spec.picturetext,
            "fieldproperty": spec.fieldproperty,
            "hidden": spec.hidden,
            "occurs": spec.occurs,
        }
        values.update({key: value for key, value in overrides.items() if value is not None})
        return FieldSpec(**values)

    def _clean_numeric_attr(self, value: Any, default: str) -> str:
        text = self._clean_value(value)
        if not text:
            return default
        match = re.search(r"\d+", text)
        return match.group(0) if match else default

    def _default_metric_for_type(self, datatype: str) -> str:
        dt = self._clean_value(datatype).lower()
        if not dt or dt in {"date", "timestamp", "datetime", "int", "integer", "bigint", "smallint", "boolean", "bool"}:
            return "0"
        if dt == "char":
            return "1"
        return "255"

    def _normalize_nullable(self, value: Any) -> str:
        text = self._clean_value(value).upper()
        if text in {"NOTNULL", "NOT NULL", "N", "NO"}:
            return "NOTNULL"
        return "NULL"

    def _normalize_keytype(self, value: Any) -> str:
        text = self._clean_value(value).upper()
        if "PRIMARY" in text:
            return "PRIMARY KEY"
        if "FOREIGN" in text:
            return "FOREIGN KEY"
        if "UNIQUE" in text:
            return "UNIQUE"
        return "NOT A KEY"

    def _format_specs_for_prompt(self, specs: list[FieldSpec]) -> str:
        if not specs:
            return ""
        return "\n".join(
            f'- {spec.name} | datatype={spec.datatype} | length={spec.length} | nullable={spec.nullable} | keytype={spec.keytype}'
            for spec in specs
        )

    def _attr_value(self, attrs: str, key: str, default: str) -> str:
        match = re.search(rf'{re.escape(key)}="([^"]*)"', attrs or "")
        return match.group(1) if match else default

    def _replace_attr(self, attrs: str, key: str, value: str) -> str:
        escaped = xml_escape(value, {'"': '&quot;'})
        if re.search(rf'{re.escape(key)}="[^"]*"', attrs or ""):
            return re.sub(rf'{re.escape(key)}="[^"]*"', f'{key}="{escaped}"', attrs)
        return f'{attrs} {key}="{escaped}"'.strip()

    # -----------------------------
    # Prompt builder
    # -----------------------------

    def _build_prompt(self, fields: dict[str, Any], t: TemplateInfo, escapeOutput: bool) -> str:
        source_specs, target_specs = self._field_specs_from_payload(fields)
        mapping_name = self._pick(fields, "Mapping Name", "mapping_name") or "STTM_Mapping"
        mapping_complexity = self._pick(fields, "Mapping Complexity", "mapping_complexity") or "Medium"
        source_name = self._pick(fields, "Source Name", "source_name") or "SOURCE"
        target_name = self._pick(fields, "Target Name", "target_name") or "TARGET"
        source_type = self._pick(fields, "Source Type", "source_type") or "Oracle"
        target_type = self._pick(fields, "Target Type", "target_type") or "Target"
        source_object = self._pick(fields, "Source Object", "source_object") or source_name
        target_object = self._pick(fields, "Target Object", "target_object") or target_name
        source_field = self._pick(fields, "Source Field", "Source Fields", "source_field") or ""
        target_field = self._pick(fields, "Target Field", "Target Fields", "target_field") or ""

        # If target fields absent, default to source fields (common STTM pattern)
        if not target_field:
            target_field = source_field

        # Output format selection (escaped vs raw)
        output_rules = "Generate RAW XML using < and > characters ONLY. Do NOT output &lt; or &gt; anywhere."

        header_start = t.xml_header
        closing_tag = "</POWERMART>"
        template_guide = _TemplateAnalyzer().build_generation_guide(t, escape_output=False)

        return f"""
You are a Senior Data Engineer with deep expertise in Informatica PowerCenter.

Your task is to generate a COMPLETE Informatica PowerCenter Mapping in XML format.

INPUT:
- Mapping Name: {mapping_name}
- Mapping Complexity: {mapping_complexity}
- Source Name: {source_name}
- Source Type: {source_type}
- Source Object: {source_object}
- Source Fields:
{self._format_specs_for_prompt(source_specs) or source_field}
- Target Name: {target_name}
- Target Type: {target_type}
- Target Object: {target_object}
- Target Fields:
{self._format_specs_for_prompt(target_specs) or target_field}
- Transformation Logic: {self._pick(fields, "Transformation Logic", "transformation_logic") or "Pass-through mapping"}

MANDATORY RULES:
1. Generate complete POWERMART XML with REPOSITORY, FOLDER, SOURCE, TARGET, MAPPING, TRANSFORMATION, INSTANCE, CONNECTOR.
2. FIELDNUMBER must start at 1 and increment sequentially without gaps.
3. Every source field must have SOURCEFIELD; every target field must have TARGETFIELD.
4. Every mapping must have CONNECTOR entries linking instances correctly.
5. No placeholders like [FIELD_NAME], no TODOs, no comments.
6. Output only XML code. No markdown fences, no explanations, no extra headings.

TEMPLATE PATTERNS (copy attribute style exactly):
{template_guide}

OUTPUT FORMAT (STRICT):
{output_rules}
Start exactly with the XML header shown above.
End exactly with: {closing_tag}
Final answer must contain only the XML code payload.
""".strip()

    # -----------------------------
    # Deterministic fallback
    # -----------------------------

    def _deterministic_fallback(self, fields: dict[str, Any], t: TemplateInfo) -> str:
        mapping_name = self._safe_name(self._pick(fields, "Mapping Name", "mapping_name") or "STTM_Mapping")
        source_name = self._safe_name(self._pick(fields, "Source Name", "source_name") or "SOURCE")
        target_name = self._safe_name(self._pick(fields, "Target Name", "target_name") or "TARGET")
        source_type = self._pick(fields, "Source Type", "source_type") or "Oracle"
        target_type = self._pick(fields, "Target Type", "target_type") or "Target"
        source_object = self._pick(fields, "Source Object", "source_object") or source_name
        target_object = self._pick(fields, "Target Object", "target_object") or target_name
        repository_name = self._pick(fields, "Repository Name", "repository_name") or "DataEngineeringRepo"
        folder_name = self._pick(fields, "Folder Name", "folder_name") or mapping_name
        folder_description = self._pick(fields, "Folder Description", "folder_description") or self._pick(fields, "Mapping Description", "mapping_description")
        mapping_description = self._pick(fields, "Mapping Description", "mapping_description")
        mapping_owner = self._pick(fields, "Mapping Owner", "mapping_owner") or "owner"
        source_database_name = self._pick(fields, "Source Database Name", "source_database_name") or f"{source_name}_DB"

        source_specs, target_specs = self._field_specs_from_payload(fields)
        field_plans = self._build_field_mapping_plan(fields, source_specs, target_specs)
        use_expression = any(plan["requires_expression"] for plan in field_plans)

        def esc(v: str) -> str:
            return xml_escape(str(v), {'"': '&quot;'})

        # update powermart attrs with actual creation date
        creation_date = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
        powermart_attrs = t.powermart_attrs or 'CREATION_DATE="MM/DD/YYYY HH:MM:SS" REPOSITORY_VERSION="189.98"'
        if "CREATION_DATE=" in powermart_attrs:
            powermart_attrs = re.sub(r'CREATION_DATE="[^"]*"', f'CREATION_DATE="{creation_date}"', powermart_attrs)
        else:
            powermart_attrs = f'CREATION_DATE="{creation_date}" {powermart_attrs}'.strip()

        repo_attrs = t.repository_attrs or 'NAME="Repository" VERSION="189" CODEPAGE="UTF-8" DATABASETYPE="Oracle"'
        repo_attrs = self._replace_attr(
            repo_attrs,
            "NAME",
            repository_name or self._attr_value(repo_attrs, "NAME", "Repository"),
        )
        repo_attrs = self._replace_attr(repo_attrs, "DATABASETYPE", source_type or self._attr_value(repo_attrs, "DATABASETYPE", "Oracle"))

        folder_attrs = t.folder_attrs or 'NAME="Folder" GROUP="" OWNER="owner" SHARED="NOTSHARED" DESCRIPTION="" PERMISSIONS="rwx------"'
        folder_attrs = self._replace_attr(folder_attrs, "NAME", folder_name)
        folder_attrs = self._replace_attr(folder_attrs, "OWNER", mapping_owner)
        folder_attrs = self._replace_attr(folder_attrs, "DESCRIPTION", folder_description)

        source_fields_xml = "\n".join(
            f'<SOURCEFIELD BUSINESSNAME="" DATATYPE="{esc(spec.datatype)}" FIELDNUMBER="{i}" FIELDPROPERTY="{esc(spec.fieldproperty)}" '
            f'FIELDTYPE="SOURCE" HIDDEN="{esc(spec.hidden)}" KEYTYPE="{esc(spec.keytype)}" LENGTH="{esc(spec.length)}" NAME="{esc(spec.name)}" '
            f'NULLABLE="{esc(spec.nullable)}" OCCURS="{esc(spec.occurs)}" PICTURETEXT="{esc(spec.picturetext)}" PRECISION="{esc(spec.precision)}" SCALE="{esc(spec.scale)}"/>'
            for i, spec in enumerate(source_specs, start=1)
        )

        target_fields_xml = "\n".join(
            f'<TARGETFIELD BUSINESSNAME="" DATATYPE="{esc(spec.datatype)}" FIELDNUMBER="{i}" FIELDPROPERTY="{esc(spec.fieldproperty)}" '
            f'FIELDTYPE="TARGET" HIDDEN="{esc(spec.hidden)}" KEYTYPE="{esc(spec.keytype)}" LENGTH="{esc(spec.length)}" NAME="{esc(spec.name)}" '
            f'NULLABLE="{esc(spec.nullable)}" OCCURS="{esc(spec.occurs)}" PICTURETEXT="{esc(spec.picturetext)}" PRECISION="{esc(spec.precision)}" SCALE="{esc(spec.scale)}"/>'
            for i, spec in enumerate(target_specs, start=1)
        )

        sq_name = f"SQ_{source_name}"
        exp_name = f"EXP_{mapping_name}"
        sq_transform_fields_xml = "\n".join(
            f'<TRANSFORMFIELD DATATYPE="{esc(spec.datatype)}" DEFAULTVALUE="" DESCRIPTION="" NAME="{esc(spec.name)}" '
            f'PICTURETEXT="{esc(spec.picturetext)}" PORTTYPE="INPUT/OUTPUT" PRECISION="{esc(spec.precision)}" SCALE="{esc(spec.scale)}"/>'
            for spec in source_specs
        )

        expression_transform_fields_xml = ""
        if use_expression:
            expression_inputs = "\n".join(
                f'<TRANSFORMFIELD DATATYPE="{esc(plan["source"].datatype)}" DEFAULTVALUE="" DESCRIPTION="" NAME="{esc(plan["source"].name)}" '
                f'PICTURETEXT="{esc(plan["source"].picturetext)}" PORTTYPE="INPUT" PRECISION="{esc(plan["source"].precision)}" SCALE="{esc(plan["source"].scale)}"/>'
                for plan in field_plans
            )
            expression_outputs = "\n".join(
                f'<TRANSFORMFIELD DATATYPE="{esc(plan["target"].datatype)}" DEFAULTVALUE="" DESCRIPTION="{esc(plan["logic"])}" EXPRESSION="{esc(plan["expression"])}" '
                f'NAME="{esc(plan["target"].name)}" PICTURETEXT="{esc(plan["target"].picturetext)}" PORTTYPE="OUTPUT" PRECISION="{esc(plan["target"].precision)}" SCALE="{esc(plan["target"].scale)}"/>'
                for plan in field_plans
            )
            expression_transform_fields_xml = "\n".join(part for part in (expression_inputs, expression_outputs) if part)

        source_to_sq_connectors_xml = "\n".join(
            f'<CONNECTOR FROMFIELD="{esc(plan["source"].name)}" FROMINSTANCE="{esc(source_name)}" FROMINSTANCETYPE="Source Definition" '
            f'TOFIELD="{esc(plan["source"].name)}" TOINSTANCE="{esc(sq_name)}" TOINSTANCETYPE="Source Qualifier"/>'
            for plan in field_plans
        )

        sq_to_expression_connectors_xml = "\n".join(
            f'<CONNECTOR FROMFIELD="{esc(plan["source"].name)}" FROMINSTANCE="{esc(sq_name)}" FROMINSTANCETYPE="Source Qualifier" '
            f'TOFIELD="{esc(plan["source"].name)}" TOINSTANCE="{esc(exp_name)}" TOINSTANCETYPE="Expression"/>'
            for plan in field_plans
        ) if use_expression else ""

        expression_to_target_connectors_xml = "\n".join(
            f'<CONNECTOR FROMFIELD="{esc(plan["target"].name)}" FROMINSTANCE="{esc(exp_name)}" FROMINSTANCETYPE="Expression" '
            f'TOFIELD="{esc(plan["target"].name)}" TOINSTANCE="{esc(target_name)}" TOINSTANCETYPE="Target Definition"/>'
            for plan in field_plans
        ) if use_expression else ""

        sq_to_target_connectors_xml = "\n".join(
            f'<CONNECTOR FROMFIELD="{esc(plan["source"].name)}" FROMINSTANCE="{esc(sq_name)}" '
            f'FROMINSTANCETYPE="Source Qualifier" TOFIELD="{esc(plan["target"].name)}" '
            f'TOINSTANCE="{esc(target_name)}" TOINSTANCETYPE="Target Definition"/>'
            for plan in field_plans
        ) if not use_expression else ""

        mapping_xml_name = mapping_name if mapping_name.lower().startswith("m_") else f"m_{mapping_name}"
        source_description = self._pick(fields, "Source Description", "source_description") or f"Source for {source_object}"
        target_description = self._pick(fields, "Target Description", "target_description") or f"Target for {target_object}"
        expression_block_xml = (
            f'<TRANSFORMATION DESCRIPTION="Derived from STTM transformation rules" NAME="{esc(exp_name)}" OBJECTVERSION="1" REUSABLE="NO" TYPE="Expression" VERSIONNUMBER="1">\n'
            f'{expression_transform_fields_xml}\n'
            f'</TRANSFORMATION>'
        ) if use_expression else ""
        expression_instance_xml = (
            f'<INSTANCE DESCRIPTION="" NAME="{esc(exp_name)}" REUSABLE="NO" TRANSFORMATION_NAME="{esc(exp_name)}" TRANSFORMATION_TYPE="Expression" TYPE="TRANSFORMATION"/>'
        ) if use_expression else ""
        connector_xml = "\n".join(
            part
            for part in (source_to_sq_connectors_xml, sq_to_expression_connectors_xml, expression_to_target_connectors_xml, sq_to_target_connectors_xml)
            if part
        )

        xml_text = f"""{_XML_HEADER_RAW}
<POWERMART {powermart_attrs}>
<REPOSITORY {repo_attrs}>
<FOLDER {folder_attrs}>
<SOURCE BUSINESSNAME="" DATABASETYPE="{esc(source_type)}" DBDNAME="{esc(source_database_name)}" DESCRIPTION="{esc(source_description)}" NAME="{esc(source_name)}" OBJECTVERSION="1" OWNERNAME="{esc(mapping_owner)}" VERSIONNUMBER="1">
{source_fields_xml}
</SOURCE>
<TARGET BUSINESSNAME="" CONSTRAINT="" DATABASETYPE="{esc(target_type)}" DESCRIPTION="{esc(target_description)}" NAME="{esc(target_name)}" OBJECTVERSION="1" TABLEOPTIONS="" VERSIONNUMBER="1">
{target_fields_xml}
</TARGET>
<MAPPING DESCRIPTION="{esc(mapping_description)}" ISVALID="YES" NAME="{esc(mapping_xml_name)}" OBJECTVERSION="1" VERSIONNUMBER="1">
<TRANSFORMATION DESCRIPTION="" NAME="{esc(sq_name)}" OBJECTVERSION="1" REUSABLE="NO" TYPE="Source Qualifier" VERSIONNUMBER="1">
{sq_transform_fields_xml}
</TRANSFORMATION>
{expression_block_xml}
<INSTANCE DESCRIPTION="" NAME="{esc(source_name)}" REUSABLE="NO" TRANSFORMATION_NAME="{esc(source_name)}" TRANSFORMATION_TYPE="Source Definition" TYPE="SOURCE"/>
<INSTANCE DESCRIPTION="" NAME="{esc(sq_name)}" REUSABLE="NO" TRANSFORMATION_NAME="{esc(sq_name)}" TRANSFORMATION_TYPE="Source Qualifier" TYPE="TRANSFORMATION"/>
{expression_instance_xml}
<INSTANCE DESCRIPTION="" NAME="{esc(target_name)}" REUSABLE="NO" TRANSFORMATION_NAME="{esc(target_name)}" TRANSFORMATION_TYPE="Target Definition" TYPE="TARGET"/>
{connector_xml}
</MAPPING>
</FOLDER>
</REPOSITORY>
</POWERMART>""".strip()

        return xml_text

    def _should_prefer_deterministic_output(self, candidate_xml: str, fields: dict[str, Any]) -> bool:
        """
        Reject well-formed but low-fidelity LLM XML when it falls back to generic defaults,
        logical datatypes, or misses STTM-implied transformation structure.
        """
        xml_text = _extract_xml_text(candidate_xml)
        if not xml_text:
            return True

        normalized_xml = xml_text.upper()
        mapping_name = self._safe_name(self._pick(fields, "Mapping Name", "mapping_name") or "STTM_Mapping")
        expected_repository = self._safe_name(self._pick(fields, "Repository Name", "repository_name") or "DataEngineeringRepo")
        expected_folder = self._safe_name(self._pick(fields, "Folder Name", "folder_name") or mapping_name)
        expected_source_db = self._safe_name(
            self._pick(fields, "Source Database Name", "source_database_name")
            or f"{self._safe_name(self._pick(fields, 'Source Name', 'source_name') or 'SOURCE')}_DB"
        )

        source_specs, target_specs = self._field_specs_from_payload(fields)
        field_plans = self._build_field_mapping_plan(fields, source_specs, target_specs)
        requires_expression = any(plan["requires_expression"] for plan in field_plans)

        expected_markers = [
            f'REPOSITORY NAME="{expected_repository.upper()}"',
            f'FOLDER NAME="{expected_folder.upper()}"',
            f'DBDNAME="{expected_source_db.upper()}"',
        ]
        for marker in expected_markers:
            if marker not in normalized_xml:
                return True

        # Reject generic placeholder ownership/defaults that previously slipped through.
        placeholder_markers = (
            'REPOSITORY NAME="REPOSITORY"',
            'FOLDER NAME="FOLDER"',
            'FOLDER NAME="CUSTOMER_FOLDER"',
            'OWNER="OWNER"',
            'OWNERNAME="DBO"',
            'DBDNAME="CUSTOMER_DB"',
        )
        if any(marker in normalized_xml for marker in placeholder_markers):
            return True

        # Enforce physical Informatica datatypes instead of the older logical strings.
        logical_datatype_markers = (
            'DATATYPE="STRING"',
            'DATATYPE="NUMBER"',
            'DATATYPE="BOOLEAN"',
            'DATATYPE="DATE"',
            'DATATYPE="TIMESTAMP"',
        )
        if any(marker in normalized_xml for marker in logical_datatype_markers):
            physical_types = {spec.datatype.upper() for spec in [*source_specs, *target_specs] if spec.datatype}
            if "VARCHAR" in physical_types or "CHAR" in physical_types or "INT" in physical_types:
                if 'DATATYPE="STRING"' in normalized_xml or 'DATATYPE="NUMBER"' in normalized_xml:
                    return True

        if requires_expression and 'TYPE="EXPRESSION"' not in normalized_xml:
            return True

        return False

    def _build_field_mapping_plan(
        self,
        fields: dict[str, Any],
        source_specs: list[FieldSpec],
        target_specs: list[FieldSpec],
    ) -> list[dict[str, Any]]:
        logic_lines = [self._clean_value(line) for line in self._pick(fields, "Transformation Logic", "transformation_logic").splitlines() if self._clean_value(line)]
        count = max(len(source_specs), len(target_specs))
        plan: list[dict[str, Any]] = []
        for index in range(count):
            source_spec = source_specs[min(index, len(source_specs) - 1)]
            target_spec = target_specs[min(index, len(target_specs) - 1)]
            logic = logic_lines[index] if index < len(logic_lines) else ""
            expression = self._expression_for_logic(source_spec.name, logic)
            plan.append(
                {
                    "source": source_spec,
                    "target": target_spec,
                    "logic": logic,
                    "expression": expression,
                    "requires_expression": bool(logic) and expression != source_spec.name,
                }
            )
        return plan

    def _expression_for_logic(self, source_field_name: str, logic: str) -> str:
        expression = source_field_name
        text = self._clean_value(logic).lower()
        if not text:
            return expression
        if "trim" in text or "leading/trailing spaces" in text or "extra spaces" in text:
            expression = f"LTRIM(RTRIM({expression}))"
        if "lowercase" in text:
            expression = f"LOWER({expression})"
        elif "uppercase" in text:
            expression = f"UPPER({expression})"
        elif "capitalize" in text or "standardize case" in text:
            expression = f"INITCAP({expression})"
        if "remove non-numeric" in text:
            expression = f"REG_REPLACE({expression}, '[^0-9]', '')"
        elif "remove spaces" in text:
            expression = f"REPLACECHR(0, {expression}, ' ')"
        elif "remove invalid characters" in text or "remove special characters" in text:
            expression = f"REG_REPLACE({expression}, '[^A-Za-z0-9@._ -]', '')"
        if "hash" in text or "masking" in text or "anonymize" in text:
            expression = f"MD5({expression})"
        if "m/f/u" in text:
            expression = f"IIF(UPPER({expression})='M','M',IIF(UPPER({expression})='F','F','U'))"
        if "active/inactive" in text:
            expression = f"IIF(UPPER({expression})='A','Active',IIF(UPPER({expression})='I','Inactive',{expression}))"
        if "true/false" in text or "boolean" in text:
            expression = f"IIF(UPPER({expression}) IN ('TRUE','FALSE'), UPPER({expression}), NULL)"
        if "yyyy-mm-dd hh:mm:ss" in text:
            expression = f"TO_CHAR({expression}, 'YYYY-MM-DD HH24:MI:SS')"
        elif "yyyy-mm-dd" in text:
            expression = f"TO_CHAR({expression}, 'YYYY-MM-DD')"
        return expression

    # -----------------------------
    # Output escaping (UI-safe)
    # -----------------------------

    def _escape_xml_for_ui(self, raw_xml: str) -> str:
        """
        Escape XML for safe UI display while allowing the UI to render
        a readable code block (DAAN-3 / DAAN-5 compatible).
        """
        escaped_xml = html.escape(raw_xml, quote=False)
        return f"<pre><code>{escaped_xml}</code></pre>"

    def _safe_name(self, value: str) -> str:
        stem = re.sub(r"[^A-Za-z0-9._-]+", "_", (value or "").strip())
        return stem.strip("._") or "STTM_Mapping"

    def _resolve_artifacts_dir(self) -> Path | None:
        if self.data_dir:
            data_path = Path(self.data_dir)
            session_dir = data_path.parent if data_path.name == "inputs" else data_path
            return session_dir / "artifacts"

        session_id = daan_session_id.get()
        if not session_id:
            return None

        session_storage_dir = Path(os.getenv("SESSION_STORAGE_DIR", "session_storage"))
        return session_storage_dir / session_id / "artifacts"

    def _write_xml_artifact(self, raw_xml: str, *, mapping_name: str) -> Path | None:
        artifacts_dir = self._resolve_artifacts_dir()
        if artifacts_dir is None:
            return None
        try:
            artifacts_dir.mkdir(parents=True, exist_ok=True)
            artifact_path = self._next_available_artifact_path(artifacts_dir, f"{self._safe_name(mapping_name)}.xml")
            artifact_path.write_text(raw_xml, encoding="utf-8")
            return artifact_path
        except Exception:
            logger.exception("%s: failed to persist generated XML artifact", self.tool_name)
            return None

    def _next_available_artifact_path(self, artifacts_dir: Path, file_name: str) -> Path:
        candidate = artifacts_dir / file_name
        if not candidate.exists():
            return candidate
        stem = candidate.stem
        suffix = candidate.suffix
        index = 2
        while True:
            retry = artifacts_dir / f"{stem}_{index}{suffix}"
            if not retry.exists():
                return retry
            index += 1
