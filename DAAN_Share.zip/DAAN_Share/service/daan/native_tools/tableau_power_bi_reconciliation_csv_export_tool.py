from __future__ import annotations

import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

from daan.flow.session_service import get_artifacts_dir

logger = logging.getLogger(__name__)


class TableauPowerBIReconciliationCSVExportTool:
    """
    Converts Tableau-to-Power BI reconciliation report (markdown format)
    into one consolidated Excel workbook with multiple sheets.

    MANDATORY: This tool is called at the end of the reconciliation agent's execution
    to export the markdown report as structured CSV files that can be downloaded.
    """

    def __init__(self, data_dir: str | None = None):
        self.tool_name = "TableauPowerBIReconciliationCSVExportTool"
        self._data_dir = data_dir
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    def export_reconciliation_to_csv(
        self,
        report_markdown: str,
        output_file_name: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Parse Tableau-to-Power BI reconciliation report markdown and export as one XLSX workbook.

        Args:
            report_markdown: Full markdown text of the reconciliation report
            output_file_name: Optional base name for output file (default: reconciliation_report)
            **kwargs: Additional parameters (ignored)

        Returns:
            Dictionary with status, artifact paths, and extraction summary
        """
        try:
            if not report_markdown or not report_markdown.strip():
                return {
                    "status": "error",
                    "errors": ["No report markdown provided"],
                }

            prefix = output_file_name or "reconciliation_report"
            artifacts_dir = self._resolve_artifacts_dir()

            # ✅ STEP 0: Validate but COLLECT WARNINGS ONLY (don't block export)
            validation = self._validate_report_completeness(report_markdown)
            validation_warnings = list(validation.get("warnings") or [])
            # Note: We collect warnings but DO NOT block export even if validation fails.
            # This allows partial or trimmed tables to be exported anyway.

            # ✅ STEP 1: Parse tables from markdown
            calculation_df = self._extract_calculation_table(report_markdown)
            visual_df = self._extract_visual_table(report_markdown)
            executive_summary_df = self._extract_executive_summary(report_markdown)
            gap_lists_df = self._extract_gap_lists(report_markdown)

            # ✅ STEP 2: Build workbook sheet data
            sheet_data: list[tuple[str, pd.DataFrame]] = []
            if not calculation_df.empty:
                sheet_data.append(("calculations", calculation_df))
                logger.info("%s: Prepared calculations sheet with %d rows", self.tool_name, len(calculation_df))

            if not visual_df.empty:
                sheet_data.append(("visuals", visual_df))
                logger.info("%s: Prepared visuals sheet with %d rows", self.tool_name, len(visual_df))

            if not executive_summary_df.empty:
                sheet_data.append(("executive_summary", executive_summary_df))
                logger.info("%s: Prepared executive_summary sheet with %d rows", self.tool_name, len(executive_summary_df))

            if not gap_lists_df.empty:
                sheet_data.append(("gap_analysis", gap_lists_df))
                logger.info("%s: Prepared gap_analysis sheet with %d rows", self.tool_name, len(gap_lists_df))

            if not sheet_data:
                return {
                    "status": "error",
                    "errors": ["No tables found in reconciliation report"],
                    "validation_summary": validation,
                }

            total_rows = sum(len(df) for _, df in sheet_data)
            consolidated_filename = f"{prefix}_report.xlsx"
            consolidated_path = self._save_consolidated_excel(
                artifacts_dir,
                sheet_data,
                consolidated_filename,
            )

            # ✅ STEP 3: Return comprehensive result
            message = f"Successfully exported reconciliation report to {consolidated_path.name} with {len(sheet_data)} sheets."
            if validation_warnings:
                message += " Export completed with validation warnings."

            return {
                "status": "ok",
                "message": message,
                "warnings": validation_warnings,
                "artifact_files": {"report": consolidated_path.name},
                "artifact_paths": {"report": str(consolidated_path)},
                "extraction_summary": {
                    "calculation_rows": len(calculation_df) if not calculation_df.empty else 0,
                    "visual_rows": len(visual_df) if not visual_df.empty else 0,
                    "summary_rows": len(executive_summary_df) if not executive_summary_df.empty else 0,
                    "gap_entries": len(gap_lists_df) if not gap_lists_df.empty else 0,
                    "total_rows": total_rows,
                    "sheets_in_workbook": len(sheet_data),
                    "files_generated": 1,
                    "validation": validation,
                    "validation_warnings": validation_warnings,
                    "timestamp": datetime.now().isoformat(),
                },
            }

        except Exception as exc:
            logger.exception("%s: CSV export failed", self.tool_name)
            return {
                "status": "error",
                "errors": [f"CSV export failed: {exc}"],
            }

    def _validate_report_completeness(self, markdown_text: str) -> dict[str, Any]:
        """
        Validate that report markdown is not truncated and has minimum required rows.

        Fails fast when truncation markers are present or extracted row counts are
        lower than coverage totals declared in the executive summary.
        """
        warnings: list[str] = []

        truncation_markers = self._find_truncation_markers(markdown_text)
        if truncation_markers:
            warnings.append(
                "Truncation markers found in report markdown. "
                f"Tables may be partial. Markers: {', '.join(truncation_markers)}"
            )

        calculation_df = self._extract_calculation_table(markdown_text)
        visual_df = self._extract_visual_table(markdown_text)

        if calculation_df.empty:
            warnings.append("Calculation Comparison Table is missing or empty.")
        if visual_df.empty:
            warnings.append("Visual Comparison Table is missing or empty.")

        coverage = self._extract_coverage_totals(markdown_text)
        expected_calc_total = coverage.get("tableau_calculations_total")
        expected_visual_total = coverage.get("tableau_visuals_total")

        if expected_calc_total is not None and len(calculation_df) < expected_calc_total:
            warnings.append(
                "Calculation table rows "
                f"({len(calculation_df)}) are below expected Tableau total ({expected_calc_total}). "
                "Partial export allowed."
            )

        if expected_visual_total is not None and len(visual_df) < expected_visual_total:
            warnings.append(
                "Visual table rows "
                f"({len(visual_df)}) are below expected Tableau total ({expected_visual_total}). "
                "Partial export allowed."
            )

        return {
            "is_valid": True,
            "truncation_markers": truncation_markers,
            "calculation_rows": len(calculation_df),
            "visual_rows": len(visual_df),
            "expected_tableau_calculations": expected_calc_total,
            "expected_tableau_visuals": expected_visual_total,
            "warnings": warnings,
        }

    def _find_truncation_markers(self, markdown_text: str) -> list[str]:
        """Detect common truncation/placeholder phrases in generated markdown."""
        marker_patterns = [
            r"table truncated",
            r"table continues",
            r"truncated for brevity",
            r"omitted for brevity",
            r"full\s+table\s+contains",
            r"\[\.\.\.\s*truncated",
            r"^\s*\.\.\.\s*$",
        ]

        matches: list[str] = []
        text_lower = markdown_text.lower()
        for pattern in marker_patterns:
            if re.search(pattern, text_lower, re.MULTILINE):
                matches.append(pattern)
        return matches

    def _extract_coverage_totals(self, markdown_text: str) -> dict[str, int | None]:
        """Extract Tableau totals from coverage lines in the executive summary."""
        result: dict[str, int | None] = {
            "tableau_calculations_total": None,
            "tableau_visuals_total": None,
        }

        calc_match = re.search(
            r"Calculations\s+compared\s*:\s*Tableau\s+\d+\s*/\s*(\d+)",
            markdown_text,
            re.IGNORECASE,
        )
        if calc_match:
            result["tableau_calculations_total"] = int(calc_match.group(1))

        visual_match = re.search(
            r"Visuals\s+compared\s*:\s*Tableau\s+\d+\s*/\s*(\d+)",
            markdown_text,
            re.IGNORECASE,
        )
        if visual_match:
            result["tableau_visuals_total"] = int(visual_match.group(1))

        return result

    def _extract_calculation_table(self, markdown_text: str) -> pd.DataFrame:
        """Extract Calculation Comparison Table from markdown"""
        df = self._extract_markdown_table(
            markdown_text,
            "Calculation Comparison Table"
        )
        if not df.empty:
            return df
        return self._extract_first_matching_table(
            markdown_text,
            required_headers=["Tableau Calc Field", "Tableau Formula", "Power BI Object"],
        )

    def _extract_visual_table(self, markdown_text: str) -> pd.DataFrame:
        """Extract Visual Comparison Table from markdown"""
        df = self._extract_markdown_table(
            markdown_text,
            "Visual Comparison Table"
        )
        if not df.empty:
            return df
        return self._extract_first_matching_table(
            markdown_text,
            required_headers=["Tableau Worksheet/Visual", "Tableau Visual Type", "Power BI Page/Visual"],
        )

    def _extract_executive_summary(self, markdown_text: str) -> pd.DataFrame:
        """Extract Executive Summary as key-value CSV"""
        # Tolerates bold markers: "### **1) Executive Summary**"
        section_pattern = r"#{2,3}[^\n]*?Executive Summary[^\n]*\n(.*?)(?=\n---|\n#{2,3}\s|\Z)"
        match = re.search(section_pattern, markdown_text, re.DOTALL)

        if not match:
            return pd.DataFrame()

        summary_text = match.group(1)

        # Parse bullet points with ** ** formatting
        bullets = re.findall(
            r"-\s*\*\*(.*?)\*\*:\s*(.*?)(?=\n-|\Z)",
            summary_text,
            re.DOTALL
        )

        data = [
            {"Metric": metric.strip(), "Value": value.strip()}
            for metric, value in bullets
        ]

        return pd.DataFrame(data) if data else pd.DataFrame()

    def _extract_gap_lists(self, markdown_text: str) -> pd.DataFrame:
        """Extract Final Gap Lists section"""
        # Tolerates bold markers: "### **5) Final Gap Lists**"
        section_pattern = r"#{2,3}[^\n]*?Final Gap Lists[^\n]*\n(.*?)(?=\n#{2,3}\s|\Z)"
        match = re.search(section_pattern, markdown_text, re.DOTALL)

        if not match:
            return pd.DataFrame()

        gap_text = match.group(1)

        # Parse gap categories and items
        data = []
        subsections = re.findall(
            r"#### (.*?)\n(.*?)(?=####|\Z)",
            gap_text,
            re.DOTALL
        )

        for gap_type, gap_content in subsections:
            items = re.findall(r"-\s*(.*?)(?=\n-|\Z)", gap_content)
            for item in items:
                item_clean = item.strip()
                if item_clean and item_clean != "None":
                    data.append({
                        "Gap Category": gap_type.strip(),
                        "Item": item_clean,
                    })

        return pd.DataFrame(data) if data else pd.DataFrame()

    def _extract_markdown_table(
        self,
        markdown_text: str,
        table_name: str
    ) -> pd.DataFrame:
        """
        Generic markdown table extractor.

        Extracts tables between section headers and pipes.
        Handles multi-line cell content.
        """
        # Find section with the table - handles headers like "### 2. Calculation Comparison Table"
        # Also tolerates bold markers: "### **2) Calculation Comparison Table (FULL LIST)**"
        section_pattern = rf"#{{2,3}}[^\n]*?{re.escape(table_name)}[^\n]*\n(.*?)(?=\n#{{2,3}}\s|\Z)"
        match = re.search(section_pattern, markdown_text, re.DOTALL)

        if not match:
            logger.debug(f"Table '{table_name}' not found in markdown")
            return pd.DataFrame()

        table_text = match.group(1)

        # Extract rows between pipes
        rows = []
        lines = table_text.strip().split('\n')

        for line in lines:
            # Skip empty lines and separator rows (contain ---)
            if not line.strip() or '---' in line:
                continue

            if line.startswith('|') and line.endswith('|'):
                # Split by | and remove empty first/last elements
                cells = [cell.strip() for cell in line.split('|')[1:-1]]
                if cells and len(cells) > 1:  # Ensure valid row
                    rows.append(cells)

        if len(rows) < 2:  # Need at least header + 1 data row
            logger.debug(f"Table '{table_name}' has insufficient rows ({len(rows)})")
            return pd.DataFrame()

        # First row is headers, rest is data
        headers = rows[0]
        data = rows[1:]

        # Validate consistency
        valid_data = [row for row in data if len(row) == len(headers)]

        if not valid_data:
            logger.warning(
                f"Table '{table_name}' has inconsistent column counts"
            )
            return pd.DataFrame()

        df = pd.DataFrame(valid_data, columns=headers)
        logger.debug(f"Extracted table '{table_name}' with {len(df)} rows and {len(headers)} columns")

        return df

    def _extract_first_matching_table(
        self,
        markdown_text: str,
        required_headers: list[str],
    ) -> pd.DataFrame:
        """Extract the first markdown table whose header contains all required headers."""
        lines = markdown_text.splitlines()
        index = 0

        while index < len(lines):
            line = lines[index].strip()
            if not (line.startswith("|") and line.endswith("|")):
                index += 1
                continue

            header_cells = [cell.strip() for cell in line.split("|")[1:-1]]
            if not header_cells:
                index += 1
                continue

            if not all(header in header_cells for header in required_headers):
                index += 1
                continue

            table_rows: list[list[str]] = [header_cells]
            index += 1

            while index < len(lines):
                candidate = lines[index].strip()
                if not candidate:
                    break
                if "---" in candidate:
                    index += 1
                    continue
                if not (candidate.startswith("|") and candidate.endswith("|")):
                    break

                cells = [cell.strip() for cell in candidate.split("|")[1:-1]]
                if len(cells) == len(header_cells):
                    table_rows.append(cells)
                index += 1

            if len(table_rows) < 2:
                continue

            df = pd.DataFrame(table_rows[1:], columns=table_rows[0])
            logger.debug(
                "Extracted fallback markdown table with %d rows for headers %s",
                len(df),
                required_headers,
            )
            return df

        return pd.DataFrame()

    def _save_consolidated_excel(
        self,
        output_dir: Path,
        sheet_data: list[tuple[str, pd.DataFrame]],
        filename: str,
    ) -> Path:
        """Save all extracted tables into one Excel workbook, overwriting prior artifact."""
        output_path = output_dir / filename
        with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
            for sheet_name, df in sheet_data:
                safe_sheet = self._sanitize_sheet_name(sheet_name)
                df.to_excel(writer, index=False, sheet_name=safe_sheet)
                self._autofit_columns(writer, df, safe_sheet)
        logger.debug("Consolidated Excel saved: %s", output_path)
        return output_path

    def _sanitize_sheet_name(self, name: str) -> str:
        cleaned = re.sub(r"[\\/*?\[\]:]", "", str(name or "")).strip()
        return (cleaned or "Table")[:31]

    def _autofit_columns(self, writer: pd.ExcelWriter, df: pd.DataFrame, sheet_name: str) -> None:
        worksheet = writer.sheets[sheet_name]
        for idx, col in enumerate(df.columns):
            series = df.iloc[:, idx]
            data_max_len = series.astype(str).map(len).max() if not series.empty else 0
            max_len = max(int(data_max_len), len(str(col)))
            worksheet.column_dimensions[
                worksheet.cell(row=1, column=idx + 1).column_letter
            ].width = min(max_len + 2, 60)

    def _resolve_artifacts_dir(self) -> Path:
        """
        Resolve the session artifacts directory.

        Pattern same as AidaSttmTool: extracts session_id from data_dir path.
        """
        if not self._data_dir:
            artifacts_dir = Path(__file__).resolve().parent / "artifacts"
            artifacts_dir.mkdir(parents=True, exist_ok=True)
            return artifacts_dir

        data_path = Path(self._data_dir)
        session_dir = data_path.parent if data_path.name == "inputs" else data_path

        artifacts_dir = get_artifacts_dir(session_dir.name, create=True)
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        return artifacts_dir