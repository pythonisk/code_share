"""Create a complete Community use case from a Use Case Builder definition."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import yaml
from sqlalchemy import func, text

from daan.core.database import SessionLocal
from daan.models.archetype import (
    Agent,
    Archetype,
    Category,
    GeneratedPrompt,
    PromptVersion,
    UseCase,
    UseCaseAgentMapping,
    UseCaseArchetypeMapping,
)
from daan.prompt_catalog.prompt_service import _generate_next_agent_id
from daan.usecases.usecase_service import _derive_usecase_initials, _generate_next_usecase_id


COMMUNITY_ARCHETYPE = "Community"
_AGENT_TYPES = {"dynamic_agent", "action_agent", "reporter_agent", "chat_agent"}

def _as_dependency_names(value: Any) -> list[str]:
    if value in (None, "", []):
        return []

    if isinstance(value, list):
        return [_as_text(item) for item in value if _as_text(item)]

    text_value = _as_text(value)
    if not text_value:
        return []

    parsed = None
    if text_value.startswith("[") and text_value.endswith("]"):
        try:
            parsed = yaml.safe_load(text_value)
        except Exception:
            parsed = None

    if isinstance(parsed, list):
        return [_as_text(item) for item in parsed if _as_text(item)]

    return [
        item.strip().strip("'\"")
        for item in re.split(r"[,;]", text_value)
        if item.strip().strip("'\"")
    ]

def _as_text(value: Any) -> str:
    return str(value or "").strip()


_DEFAULT_ROLE = "Default"


def _load_role_candidates() -> list[str]:
    """Distinct roles already used by Community use cases (empty on any error)."""
    try:
        from daan.usecases.usecase_service import list_archetype_roles
        return list_archetype_roles(COMMUNITY_ARCHETYPE)
    except Exception:
        return []


def _resolve_role(value: Any, candidates: list[str]) -> str:
    """Match a role to known archetype roles; never returns null/empty.

    Matches case-insensitively against ``candidates`` and returns the canonical
    spelling. When candidates exist but none match, returns 'Default'. When no
    candidate vocabulary exists, keeps the provided role (else 'Default').
    """
    text = _as_text(value)
    if candidates:
        low = text.casefold()
        for candidate in candidates:
            if _as_text(candidate).casefold() == low:
                return _as_text(candidate)
        return _DEFAULT_ROLE
    return text or _DEFAULT_ROLE


def _looks_like_agent(value: Any) -> bool:
    return isinstance(value, dict) and _as_text(value.get("agent_name")) != ""


def _collect_bare_agents(candidate: Any) -> list[dict[str, Any]]:
    """Flatten a payload into a list of agent objects (no usecase wrapper).

    Handles the spec-builder shape ``{builder_agent_id: [ {agent}, ... ]}`` plus
    bare lists and JSON-encoded strings, so an agent-only output can be ingested.
    """
    agents: list[dict[str, Any]] = []

    def _add(value: Any) -> None:
        if _looks_like_agent(value):
            agents.append(value)
        elif isinstance(value, list):
            for item in value:
                _add(item)
        elif isinstance(value, dict):
            for sub in value.values():
                _add(sub)
        elif isinstance(value, str) and value.strip():
            try:
                _add(json.loads(value.strip()))
            except Exception:
                return

    _add(candidate)
    return agents


def _derive_usecase_from_session(session_id: str | None) -> tuple[str, str]:
    """Derive a use-case name/task from the uploaded input file name."""
    if not session_id:
        return "", ""
    inputs_dir = Path(__file__).resolve().parents[3] / "session_storage" / session_id / "inputs"
    if not inputs_dir.is_dir():
        return "", ""
    for item in sorted(inputs_dir.iterdir()):
        if item.is_file() and item.suffix.lower() in {".xlsx", ".xls", ".csv"}:
            cleaned = re.sub(r"\s+", " ", re.sub(r"[_\-]+", " ", item.stem)).strip()
            if cleaned:
                name = cleaned[:200]
                return name, f"Create a use case from the uploaded specification file '{item.name}'."
    return "", ""


def _unique_community_name(db: Any, community_id: int, base: str) -> str:
    """Return a free Community use-case name, appending 'Copy N' if taken."""
    def _taken(candidate: str) -> bool:
        return db.query(UseCase.usecaseid).join(
            UseCaseArchetypeMapping,
            UseCase.usecaseid == UseCaseArchetypeMapping.usecase_id,
        ).filter(
            UseCaseArchetypeMapping.archetype_id == community_id,
            func.lower(UseCase.name) == candidate.casefold(),
        ).first() is not None

    if not _taken(base):
        return base
    n = 1
    while _taken(f"{base} Copy {n}"):
        n += 1
    return f"{base} Copy {n}"


def _read_definition_file(session_id: str | None) -> dict[str, Any] | None:
    """Load a deterministic ``definition.json`` written by the spec Excel writer."""
    if not session_id:
        return None
    path = Path(__file__).resolve().parents[3] / "session_storage" / session_id / "definition.json"
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    if isinstance(data, dict) and isinstance(data.get("agents"), list) and data.get("agents"):
        if not isinstance(data.get("usecase"), dict):
            data["usecase"] = {}
        return data
    return None


def _extract_definition(
    dynamic_agent_outputs_structured: Any,
    reviewed_output: Any,
    session_id: str | None = None,
) -> dict[str, Any]:
    """Extract one definition from the action agent's structured-first payload."""

    def parse_text(text: str) -> dict[str, Any] | None:
        text = text.strip()
        fenced = re.search(r"```(?:ya?ml|json)?\s*(.*?)```", text, re.DOTALL | re.IGNORECASE)
        if fenced:
            text = fenced.group(1).strip()

        yaml_start = re.search(r"(?m)^usecase:\s*$", text)
        if yaml_start:
            text = text[yaml_start.start():].strip()
        for loader in (json.loads, yaml.safe_load):
            try:
                parsed = loader(text)
            except Exception:
                continue
            if (
                isinstance(parsed, dict)
                and isinstance(parsed.get("usecase"), dict)
                and isinstance(parsed.get("agents"), list)
                and parsed.get("agents")
            ):
                return parsed
        return None

    candidates: list[Any] = [dynamic_agent_outputs_structured, reviewed_output]
    for candidate in candidates:
        if isinstance(candidate, dict):
            if isinstance(candidate.get("usecase"), dict) and isinstance(candidate.get("agents"), list):
                return candidate
            for value in candidate.values():
                if isinstance(value, dict) and isinstance(value.get("usecase"), dict):
                    return value
                if isinstance(value, str):
                    parsed = parse_text(value)
                    if parsed:
                        return parsed
                if isinstance(value, list):
                    for item in value:
                        if isinstance(item, dict) and isinstance(item.get("usecase"), dict):
                            return item
        if isinstance(candidate, str) and candidate.strip():
            parsed = parse_text(candidate)
            if parsed:
                return parsed

    # Fallback: the spec-builder emits only agent objects (no usecase wrapper).
    for candidate in candidates:
        bare_agents = _collect_bare_agents(candidate)
        if bare_agents:
            return {"usecase": {}, "agents": bare_agents}

    # Final fallback: a deterministic definition.json written to session storage
    # (avoids the LLM having to copy a large payload into its tool arguments).
    from_file = _read_definition_file(session_id)
    if from_file:
        return from_file

    raise ValueError("No valid use case definition found in the upstream agent output")
def _lock_id_allocation(db: Any) -> None:
    bind = db.get_bind()
    if bind is not None and bind.dialect.name == "postgresql":
        db.execute(text("SELECT pg_advisory_xact_lock(hashtext('daan_create_usecase_from_definition_ids'))"))

class CreateUseCaseFromDefinitionTool:
    """Persist a generated definition using the same records as Build's copy flow."""

    def create_usecase_from_definition(
        self,
        dynamic_agent_outputs_structured: Any = None,
        reviewed_output: Any = None,
        session_id: str | None = None,
    ) -> dict[str, Any]:
        """Create a new Community use case and its fresh prompts, agents, and mappings."""
        try:
            definition = _extract_definition(dynamic_agent_outputs_structured, reviewed_output, session_id)
            usecase_data = definition.get("usecase") or {}
            agent_definitions = definition.get("agents") or []
            if not isinstance(agent_definitions, list) or not agent_definitions:
                raise ValueError("The use case definition must contain at least one agent")

            name = _as_text(usecase_data.get("name"))
            task = _as_text(usecase_data.get("task"))
            role_candidates = _load_role_candidates()
            role = _resolve_role(usecase_data.get("role"), role_candidates)
            category = _as_text(usecase_data.get("category"))
            if not name or not task:
                derived_name, derived_task = _derive_usecase_from_session(session_id)
                name = name or derived_name or "Imported Use Case"
                task = task or derived_task or f"Create a use case from the uploaded specification for '{name}'."
            if _as_text(usecase_data.get("archetype")) not in ("", COMMUNITY_ARCHETYPE):
                raise ValueError("Generated use cases must use the Community archetype")

            with SessionLocal.begin() as db:
                _lock_id_allocation(db)
                community = db.query(Archetype).filter(
                    func.lower(Archetype.name) == COMMUNITY_ARCHETYPE.lower()
                ).first()
                if community is None:
                    raise ValueError("Community archetype does not exist")

                # Never fail on a name clash — auto-suffix with 'Copy N' instead.
                name = _unique_community_name(db, community.id, name)

                usecase_id = _generate_next_usecase_id(
                    db,
                    community.id,
                    _derive_usecase_initials(community.name),
                )
                usecase = UseCase(
                    usecaseid=usecase_id,
                    name=name,
                    task=task,
                    role=role,
                    premium="Yes" if str(usecase_data.get("premium", "No")).lower() in {"yes", "true", "1"} else "No",
                    category=category or None,
                    loop_config=int(usecase_data.get("loop_config") or 0),
                    agents_involved="",
                    flow_of_agents="",
                    dag="",
                )
                db.add(usecase)
                db.add(UseCaseArchetypeMapping(usecase_id=usecase_id, archetype_id=community.id, isactive=True))
                if category and not db.query(Category).filter(func.lower(Category.name) == category.casefold()).first():
                    db.add(Category(name=category))

                created: list[dict[str, Any]] = []
                names_to_ids: dict[str, str] = {}
                for position, agent_data in enumerate(agent_definitions, start=1):
                    if not isinstance(agent_data, dict):
                        raise ValueError(f"agents[{position}] must be an object")
                    agent_name = _as_text(agent_data.get("agent_name"))
                    agent_type = _as_text(agent_data.get("agent_type")).lower()
                    # Store system + user prompt as one instruction (DAAN uses a single prompt).
                    _system_p = _as_text(agent_data.get("system_prompt") or agent_data.get("prompt"))
                    _user_p = _as_text(agent_data.get("user_prompt"))
                    prompt_text = "\n\n".join(p for p in (_system_p, _user_p) if p)
                    if not agent_name or agent_type not in _AGENT_TYPES:
                        raise ValueError(f"agents[{position}] requires agent_name and a valid agent_type")
                    if agent_name in names_to_ids:
                        raise ValueError(f"Duplicate agent name '{agent_name}'")

                    agent_id = _generate_next_agent_id(db)
                    names_to_ids[agent_name] = agent_id

                    # A spec row may legitimately have no prompt — leave prompt_id NULL.
                    prompt_id = None
                    if prompt_text:
                        prompt = GeneratedPrompt(prompt_name=f"{agent_name}_prompt", prompt_text=prompt_text)
                        db.add(prompt)
                        db.flush()
                        db.add(PromptVersion(
                            prompt_id=prompt.id,
                            version_number=1,
                            prompt_text=prompt_text,
                        ))
                        prompt_id = prompt.id

                    agent = Agent(
                        agent_id=agent_id,
                        agent_name=agent_name,
                        agent_type=agent_type,
                        role=_resolve_role(agent_data.get("role"), role_candidates),
                        prompt_id=prompt_id,
                        mcp_server=_as_text(agent_data.get("mcp_servers") or agent_data.get("mcp_tools")) or None,
                        local_tools=_as_text(agent_data.get("local_tools")) or None,
                        input_context=_as_text(agent_data.get("inputs") or agent_data.get("input_context")) or None,
                        output_format=_as_text(agent_data.get("output_format")) or None,
                        agent_actions=_as_text(agent_data.get("actions") or agent_data.get("agent_actions")) or None,
                        guardrails=_as_text(agent_data.get("guardrails")) or None,
                        output_validators=_as_text(agent_data.get("output_validators")) or None,
                    )
                    db.add(agent)
                    db.flush()
                    db.add(UseCaseAgentMapping(usecase_id=usecase_id, agent_id=agent_id, execution_order=position))
                    created.append({
                        "agent_id": agent_id,
                        "agent_name": agent_name,
                        "prompt_id": prompt_id,
                        "agent_type": agent_type,
                    })

                ordered_ids = [item["agent_id"] for item in created]

                # Resolve dependencies by BOTH agent_name and logical_id so a spec
                # file may reference parents by either token.
                key_to_id: dict[str, str] = {}
                for index, item in enumerate(created):
                    key_to_id[item["agent_name"]] = item["agent_id"]
                    logical_id = _as_text(agent_definitions[index].get("logical_id"))
                    if logical_id:
                        key_to_id.setdefault(logical_id, item["agent_id"])

                resolved_parents: dict[str, list[str]] = {}
                for index, agent_data in enumerate(agent_definitions):
                    self_id = ordered_ids[index]
                    parent_ids: list[str] = []
                    for token in _as_dependency_names(agent_data.get("depends_on")):
                        parent_id = key_to_id.get(token)
                        if parent_id and parent_id != self_id and parent_id not in parent_ids:
                            parent_ids.append(parent_id)
                    resolved_parents[self_id] = parent_ids

                # Stage level from parents already placed earlier in input order;
                # this drops backward/loop-back edges, keeping the DAG acyclic.
                level_by_id: dict[str, int] = {}
                for agent_id in ordered_ids:
                    prior = [level_by_id[p] for p in resolved_parents[agent_id] if p in level_by_id]
                    level_by_id[agent_id] = 1 + max(prior) if prior else 0

                for agent_id in ordered_ids:
                    forward_parents = [
                        p for p in resolved_parents[agent_id]
                        if level_by_id.get(p, 0) < level_by_id[agent_id]
                    ]
                    db.query(Agent).filter(Agent.agent_id == agent_id).update(
                        {"depend_on": ",".join(forward_parents) if forward_parents else None}
                    )

                # Group agents by level into sequential/parallel DAG stages.
                max_level = max(level_by_id.values()) if level_by_id else 0
                stages: list[list[str]] = [[] for _ in range(max_level + 1)]
                for agent_id in ordered_ids:
                    stages[level_by_id[agent_id]].append(agent_id)

                # Agents flagged as looping are wrapped in {} so the DAG marks
                # them as batch/iterating stages (e.g. {A} or [A,{B}]).
                loop_ids = {
                    item["agent_id"]
                    for index, item in enumerate(created)
                    if str(agent_definitions[index].get("loop") or "").strip().lower() in {"true", "1", "yes"}
                }

                def _stage_token(aid: str) -> str:
                    return f"{{{aid}}}" if aid in loop_ids else aid

                dag_tokens: list[str] = []
                dag_ordered_ids: list[str] = []
                for stage_ids in stages:
                    if not stage_ids:
                        continue
                    dag_ordered_ids.extend(stage_ids)
                    dag_tokens.append(
                        _stage_token(stage_ids[0]) if len(stage_ids) == 1
                        else "[" + ",".join(_stage_token(a) for a in stage_ids) + "]"
                    )

                name_by_id = {item["agent_id"]: item["agent_name"] for item in created}
                type_by_id = {item["agent_id"]: item["agent_type"] for item in created}
                usecase.agents_involved = ";".join(
                    f"{aid}:{name_by_id[aid]}|{type_by_id[aid]}" for aid in dag_ordered_ids
                )
                usecase.flow_of_agents = usecase.agents_involved
                usecase.dag = ">".join(dag_tokens)

            return {
                "status": "success",
                "session_id": session_id,
                "archetype": COMMUNITY_ARCHETYPE,
                "usecase_id": usecase_id,
                "usecase_name": name,
                "created_agents": created,
                "message": f"Created Community use case '{name}' with {len(created)} agent(s)",
            }
        except Exception as exc:
            return {"status": "error", "session_id": session_id, "message": str(exc), "created_agents": []}