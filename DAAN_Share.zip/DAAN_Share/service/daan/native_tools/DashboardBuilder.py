"""
Generic Superset Dashboard Builder.

Packages a complete set of Superset YAML config files into a valid importable
Superset ZIP bundle.  It can be driven in three ways:

1. **Full yaml_files dict** – the caller provides every file (metadata, databases,
   datasets, charts, dashboards) as a dict mapping path → YAML string.

2. **Structured inputs** – the caller provides ``chart_inventory`` and
   ``dataset_manifest`` dicts (as produced by the upstream DAAN agents) and the
   tool generates *all* YAML files automatically, including one chart file per
   non-exception chart.

3. **Legacy bundle_dir** – an existing directory of YAML files is zipped as-is.

In case 1, if ``charts/`` entries are missing but ``chart_inventory`` and
``dataset_manifest`` are also supplied, the missing chart files (and a
regenerated dashboard layout) are synthesised automatically so the bundle is
always importable.

Expected bundle layout:
    <bundle>/
        metadata.yaml
        databases/<db_name>.yaml
        datasets/<db_name>/<table_name>.yaml
        charts/<slug>.yaml          (one per non-exception chart)
        dashboards/<dashboard>.yaml

The ZIP is saved to the session artifacts folder for universal access.
"""
from __future__ import annotations

import datetime
import json
import logging
import os
import re
import sys
import tempfile
import uuid
import zipfile
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_BUNDLE = os.path.join(os.path.dirname(__file__), "outputs", "bundle")
DEFAULT_ZIP    = os.path.join(os.path.dirname(__file__), "outputs", "Sales_Dashboard_Superset.zip")

# ---------------------------------------------------------------------------
# Per-viz-type param builders
# ---------------------------------------------------------------------------

def _chart_params(viz_type: str, dimensions: list, metrics: list, x_axis: str | None) -> dict:
    """Return the ``params`` mapping for a given Superset viz_type."""
    vt = viz_type or "table"
    dims = dimensions or []
    mets = metrics or []

    if vt == "big_number_total":
        return {"viz_type": vt, "metric": mets[0] if mets else "count"}

    if vt in ("pie",):
        return {"viz_type": vt, "groupby": dims or (["unknown"] if not dims else dims),
                "metric": mets[0] if mets else "count"}

    if vt in ("treemap_v2",):
        return {"viz_type": vt, "groupby": dims, "metrics": mets}

    if vt in ("table", "pivot_table_v2"):
        return {"viz_type": vt, "groupby": dims, "metrics": mets, "query_mode": "aggregate"}

    if vt in ("echarts_timeseries_bar", "echarts_timeseries_line"):
        axis = x_axis or (dims[0] if dims else "unknown")
        return {"viz_type": vt, "x_axis": axis, "metrics": mets}

    if vt in ("mixed_timeseries",):
        axis = x_axis or (dims[0] if dims else "unknown")
        return {"viz_type": vt, "x_axis": axis, "metrics": mets}

    if vt in ("gauge_chart",):
        return {"viz_type": vt, "metric": mets[0] if mets else "count"}

    if vt.startswith("deck_"):
        # deck maps need geo config – fall back to table
        return {"viz_type": "table", "groupby": dims, "metrics": mets, "query_mode": "aggregate"}

    # Generic fallback
    return {"viz_type": "table", "groupby": dims, "metrics": mets, "query_mode": "aggregate"}


_UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
    re.IGNORECASE,
)


def _ensure_uuid(value: str | None) -> str:
    """Return *value* if it is a valid UUID, otherwise generate a new one."""
    if value and _UUID_RE.match(str(value).strip()):
        return str(value).strip()
    return str(uuid.uuid4())


def _slugify(name: str) -> str:
    """Convert a chart name to a safe file-system slug."""
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", name).strip("_")
    return slug[:64] or "chart"


def _yaml_str(value: Any, indent: int = 0) -> str:
    """Very small YAML serialiser sufficient for Superset bundle structures."""
    pad = "  " * indent
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        # Quote if contains special chars
        if any(c in value for c in (':', '#', '{', '}', '[', ']', ',', '&', '*', '?', '|', '-', '<', '>', '=', '!', '%', '@', '`', "'", '"', '\n')):
            escaped = value.replace("'", "''")
            return f"'{escaped}'"
        return value
    if isinstance(value, list):
        if not value:
            return "[]"
        lines = [f"{pad}- {_yaml_str(item, indent)}" for item in value]
        return "\n" + "\n".join(lines)
    if isinstance(value, dict):
        if not value:
            return "{}"
        lines = []
        for k, v in value.items():
            rendered = _yaml_str(v, indent + 1)
            if isinstance(v, (dict, list)) and v:
                lines.append(f"{pad}{k}:{rendered}")
            else:
                lines.append(f"{pad}{k}: {rendered}")
        return "\n" + "\n".join(lines)
    return str(value)


def _reconcile_dataset_uuids(files: dict[str, str]) -> dict[str, str]:
    """Ensure every datasetUuid reference in dashboards/ and charts/ matches
    the actual uuid declared in the datasets/*.yaml files.

    When caller-supplied yaml_files override auto-generated ones (or vice-versa),
    the dataset UUID used in charts and native filters can get out of sync with
    the UUID in the datasets/ file that will actually be imported.  This pass
    does a text-level substitution to keep them consistent.
    """
    # Collect (stale_uuid → canonical_uuid) from datasets/*.yaml
    uuid_map: dict[str, str] = {}
    for path, content in files.items():
        if not path.startswith("datasets/"):
            continue
        # Extract `uuid: <value>` line
        m = re.search(r"(?m)^uuid:\s+([0-9a-f\-]{36})", content)
        if m:
            canonical = m.group(1)
            # Also find every UUID-like string in this file so we can build
            # the reverse map later; for now just note the canonical UUID.
            uuid_map[canonical] = canonical  # identity — it is already correct

    if not uuid_map:
        return files

    # Collect all UUIDs referenced as datasetUuid in charts/ and dashboards/
    # that are NOT already in uuid_map (i.e. they are stale / from a different run)
    canonical_uuids = set(uuid_map.keys())
    stale_map: dict[str, str] = {}

    if len(canonical_uuids) == 1:
        # Simple case: single dataset — any datasetUuid that differs gets remapped
        canonical = next(iter(canonical_uuids))
        for path, content in files.items():
            if not (path.startswith("charts/") or path.startswith("dashboards/")):
                continue
            for m in re.finditer(r"datasetUuid:\s+([0-9a-f\-]{36})", content):
                stale = m.group(1)
                if stale != canonical:
                    stale_map[stale] = canonical
            for m in re.finditer(r"dataset_uuid:\s+([0-9a-f\-]{36})", content):
                stale = m.group(1)
                if stale != canonical:
                    stale_map[stale] = canonical

    if not stale_map:
        return files

    logger.info("Reconciling %d stale dataset UUID(s): %s", len(stale_map), stale_map)

    result: dict[str, str] = {}
    for path, content in files.items():
        new_content = content
        for old_uuid, new_uuid in stale_map.items():
            new_content = new_content.replace(old_uuid, new_uuid)
        result[path] = new_content
    return result


def _build_chart_yaml(chart: dict, dataset_uuid: str) -> str:
    """Generate a single chart YAML string."""
    name = chart.get("chart", "chart")
    viz_type = chart.get("superset_viz_type") or "table"
    dims = chart.get("dimensions") or []
    mets = chart.get("metrics") or []
    x_axis = chart.get("x_axis")
    chart_uuid = str(uuid.uuid4())

    params = _chart_params(viz_type, dims, mets, x_axis)

    lines = [
        f"slice_name: {_yaml_str(name)}",
        f"viz_type: {viz_type}",
        f"dataset_uuid: {dataset_uuid}",
        f"uuid: {chart_uuid}",
        "version: 1.0.0",
        "cache_timeout: null",
        "params:",
    ]
    for k, v in params.items():
        rendered = _yaml_str(v, 1)
        if isinstance(v, list) and v:
            lines.append(f"  {k}:{rendered}")
        else:
            lines.append(f"  {k}: {rendered}")

    return "\n".join(lines) + "\n", chart_uuid


def _build_dashboard_yaml(
    dashboard_name: str,
    charts_meta: list[dict],
    dataset_uuid: str,
    native_filters: list[dict],
) -> str:
    """Generate the dashboards/<name>.yaml string."""
    dash_uuid = str(uuid.uuid4())
    slug = _slugify(dashboard_name).lower()

    lines = [
        f"dashboard_title: {_yaml_str(dashboard_name)}",
        f"uuid: {dash_uuid}",
        "version: 1.0.0",
        f"slug: {slug}",
    ]

    # Native filter configuration
    if native_filters:
        lines.append("metadata:")
        lines.append("  native_filter_configuration:")
        for idx, nf in enumerate(native_filters, 1):
            col = nf.get("column") or nf.get("name", "")
            label = nf.get("name") or col
            fid = f"NATIVE_FILTER-{idx}"
            lines += [
                f"    - id: {fid}",
                f"      name: {_yaml_str(label)}",
                "      filterType: filter_select",
                "      type: NATIVE_FILTER",
                "      targets:",
                f"        - datasetUuid: {dataset_uuid}",
                f"          column:",
                f"            name: {_yaml_str(col)}",
                "      controlValues:",
                "        multiSelect: true",
                "        enableEmptyFilter: false",
                "        searchAllOptions: true",
                "      scope:",
                "        rootPath: [ROOT_ID]",
                "        excluded: []",
            ]

    # Build position layout: 3 charts per row
    row_children_map: dict[int, list[str]] = {}
    chart_nodes: list[str] = []
    chart_int_id = 1

    for i, cm in enumerate(charts_meta):
        row_idx = i // 3
        cid = f"CHART-{i:04d}"
        row_children_map.setdefault(row_idx, []).append(cid)
        chart_nodes.append(
            f"  {cid}:\n"
            f"    type: CHART\n"
            f"    id: {cid}\n"
            f"    children: []\n"
            f"    meta:\n"
            f"      uuid: {cm['uuid']}\n"
            f"      chartId: {chart_int_id}\n"
            f"      sliceName: {_yaml_str(cm['name'])}\n"
            f"      width: 4\n"
            f"      height: 50"
        )
        chart_int_id += 1

    row_ids = [f"ROW-{r}" for r in sorted(row_children_map)]
    row_nodes: list[str] = []
    for r_idx, children in sorted(row_children_map.items()):
        rid = f"ROW-{r_idx}"
        children_str = "[" + ", ".join(children) + "]"
        row_nodes.append(
            f"  {rid}:\n"
            f"    type: ROW\n"
            f"    id: {rid}\n"
            f"    parents: [ROOT_ID, GRID_ID]\n"
            f"    children: {children_str}\n"
            f"    meta:\n"
            f"      background: BACKGROUND_TRANSPARENT"
        )

    grid_children_str = "[" + ", ".join(row_ids) + "]"
    pos_lines = [
        "position:",
        "  DASHBOARD_VERSION_KEY: v2",
        "  ROOT_ID:",
        "    type: ROOT",
        "    id: ROOT_ID",
        "    children: [GRID_ID]",
        "  GRID_ID:",
        "    type: GRID",
        "    id: GRID_ID",
        "    parents: [ROOT_ID]",
        f"    children: {grid_children_str}",
    ]
    pos_lines += row_nodes
    pos_lines += chart_nodes

    lines += pos_lines
    return "\n".join(lines) + "\n"


class DashboardBuilder:
    """Builds Superset dashboard ZIP bundles from YAML config files."""

    def __init__(self, data_dir: str | None = None, **kwargs):
        """Initialize the dashboard builder.
        
        Args:
            data_dir: Session data directory to resolve artifacts folder
            **kwargs: Additional arguments (ignored, for tool loader compatibility)
        """
        self.tool_name = "DashboardBuilder"
        self._data_dir = data_dir
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    # ------------------------------------------------------------------
    # Public tool method
    # ------------------------------------------------------------------

    def build_zip(
        self,
        yaml_files: dict[str, str] | None = None,
        chart_inventory: dict | list | None = None,
        dataset_manifest: dict | None = None,
        output_path: str | None = None,
        dashboard_name: str = "superset_dashboard",
        bundle_dir: str | None = None,
        zip_filename: str | None = None,
    ) -> dict[str, Any]:
        """Build a Superset dashboard ZIP bundle.

        Three calling modes (in priority order):

        **Mode 1 – structured inputs** (recommended):
          Pass ``chart_inventory`` and ``dataset_manifest``.  All YAML files,
          including one chart file per non-exception chart, are generated
          automatically.  If ``yaml_files`` is *also* given, those entries take
          precedence (they are merged on top of the generated ones).

        **Mode 2 – yaml_files only**:
          Pass a dict of ``{path: yaml_content}``.  If no ``charts/`` entries
          are present and no structured inputs are given, the bundle is zipped
          as-is (same behaviour as before this fix).

        **Mode 3 – legacy bundle_dir**:
          Pass ``bundle_dir`` pointing to an existing directory of YAML files.

        Args:
            yaml_files: Dict mapping relative file paths to YAML content strings.
            chart_inventory: Chart-inventory dict/list from upstream agent
                (must contain a ``charts`` list with ``chart``, ``superset_viz_type``,
                ``dimensions``, ``metrics``, ``x_axis``, ``complexity`` keys).
            dataset_manifest: Dataset manifest dict from upstream agent
                (must contain ``database``, ``dataset``, ``native_filters`` keys).
            output_path: Ignored – kept for backwards-compat.
            dashboard_name: Base name for the output ZIP (without ``.zip``).
            bundle_dir: (Legacy) Directory of YAML files to zip.
            zip_filename: (Legacy) Explicit output filename.

        Returns:
            Status dict with ``artifact_path``, ``file_count``, and ``files`` list.
        """
        try:
            artifacts_dir = self._resolve_artifacts_dir()
            artifacts_dir.mkdir(parents=True, exist_ok=True)

            # ---------------------------------------------------------------
            # Resolve the final set of YAML files to write
            # ---------------------------------------------------------------
            final_files: dict[str, str] = {}

            if chart_inventory is not None or dataset_manifest is not None:
                # Mode 1: generate from structured inputs, then overlay yaml_files
                generated = self._generate_yaml_files(
                    chart_inventory=chart_inventory,
                    dataset_manifest=dataset_manifest,
                    dashboard_name=dashboard_name,
                )
                final_files.update(generated)
                logger.info("%s: Generated %d YAML files from structured inputs",
                            self.tool_name, len(generated))

            if yaml_files:
                final_files.update(yaml_files)  # caller-supplied takes precedence
                logger.info("%s: Merged %d caller-supplied YAML files", self.tool_name, len(yaml_files))

            # ---------------------------------------------------------------
            # Auto-supplement: if charts/ are still missing, load from session
            # context_map_output.json + AGENT_814/output.md
            # ---------------------------------------------------------------
            has_charts = any(k.startswith("charts/") for k in final_files)
            if not has_charts and self._data_dir:
                logger.info("%s: No charts/ in bundle — attempting auto-load from session context",
                            self.tool_name)
                auto_ci, auto_dm = self._load_session_context()
                if auto_ci or auto_dm:
                    generated = self._generate_yaml_files(
                        chart_inventory=auto_ci,
                        dataset_manifest=auto_dm,
                        dashboard_name=dashboard_name,
                    )
                    # Merge strategy:
                    # - Start with auto-generated (has charts + correct dashboard layout)
                    # - Overlay caller's files for everything EXCEPT dashboards/
                    #   (caller's dashboard YAML has empty position — it must not win)
                    # - Remove any stale dashboards/ the caller supplied
                    merged = dict(generated)
                    for k, v in final_files.items():
                        if not k.startswith("dashboards/"):
                            merged[k] = v
                    final_files = merged
                    logger.info("%s: Auto-supplemented %d chart(s) from session context",
                                self.tool_name,
                                sum(1 for k in final_files if k.startswith("charts/")))

            # ---------------------------------------------------------------
            # UUID consistency pass: ensure dashboard datasetUuid references
            # match the actual UUID in the datasets/*.yaml that will be zipped.
            # This fixes KeyError when caller's dataset file has a different UUID
            # than the auto-generated dashboard's native filter references.
            # ---------------------------------------------------------------
            final_files = _reconcile_dataset_uuids(final_files)

            if final_files:
                # Write to temp dir and zip
                temp_bundle = Path(tempfile.mkdtemp(prefix="superset_bundle_"))
                for file_path, content in final_files.items():
                    target = temp_bundle / file_path
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_text(content, encoding="utf-8")
                    logger.info("%s: Wrote %s", self.tool_name, file_path)

                # Ensure metadata exists
                meta_path = temp_bundle / "metadata.yaml"
                if not meta_path.exists():
                    ts = datetime.datetime.now(datetime.timezone.utc).isoformat()
                    meta_path.write_text(
                        f"version: 1.0.0\ntype: Dashboard\ntimestamp: '{ts}'\n",
                        encoding="utf-8",
                    )

                bundle_to_zip = str(temp_bundle)
                root = temp_bundle.name

            else:
                # Mode 3: legacy bundle_dir
                if not bundle_dir or not os.path.isdir(bundle_dir):
                    bundle_dir = bundle_dir or DEFAULT_BUNDLE
                    if not os.path.isdir(bundle_dir):
                        logger.error("%s: Bundle dir not found: %s", self.tool_name, bundle_dir)
                        return {
                            "status": "error",
                            "errors": [f"Bundle dir not found: {bundle_dir}"],
                        }

                self._ensure_metadata(bundle_dir)
                bundle_to_zip = bundle_dir
                root = os.path.basename(bundle_dir.rstrip("/\\")) or "bundle"

            # ---------------------------------------------------------------
            # Create ZIP
            # ---------------------------------------------------------------
            if zip_filename is None:
                zip_filename = f"{dashboard_name}.zip"

            zip_path = artifacts_dir / zip_filename
            if zip_path.exists():
                os.remove(str(zip_path))

            files: list[str] = []
            with zipfile.ZipFile(str(zip_path), "w", zipfile.ZIP_DEFLATED) as z:
                for r, _, fs in os.walk(bundle_to_zip):
                    for fn in fs:
                        if not fn.lower().endswith((".yaml", ".yml")):
                            continue
                        fp = os.path.join(r, fn)
                        arc = os.path.join(root, os.path.relpath(fp, bundle_to_zip))
                        z.write(fp, arc)
                        files.append(arc.replace("\\", "/"))

            logger.info("%s: Built %s with %d files", self.tool_name, zip_path.name, len(files))

            return {
                "status": "ok",
                "message": "Superset dashboard ZIP built successfully",
                "artifact_path": str(zip_path),
                "artifact_filename": zip_path.name,
                "file_count": len(files),
                "files": sorted(files),
            }
        except Exception as exc:
            logger.exception("%s: build_zip failed", self.tool_name)
            return {
                "status": "error",
                "errors": [f"Dashboard ZIP build failed: {exc}"],
            }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _generate_yaml_files(
        self,
        chart_inventory: dict | list | None,
        dataset_manifest: dict | None,
        dashboard_name: str,
    ) -> dict[str, str]:
        """Generate the full set of Superset bundle YAML files from structured inputs."""
        ts = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result: dict[str, str] = {}

        # --- metadata.yaml ---
        result["metadata.yaml"] = f"version: 1.0.0\ntype: Dashboard\ntimestamp: '{ts}'\n"

        # --- Parse manifest ---
        manifest = dataset_manifest or {}
        db_info = manifest.get("database") or {}
        ds_info = manifest.get("dataset") or {}
        native_filters = manifest.get("native_filters") or []

        db_name = db_info.get("database_name") or dashboard_name
        db_uuid = _ensure_uuid(db_info.get("uuid"))
        _raw_uri = db_info.get("sqlalchemy_uri") or ""
        # Replace placeholder / template tokens that Superset rejects as null
        _placeholder_tokens = ("DB_USER", "DB_PASSWORD", "DB_HOST", "DB_PORT", "ENCODED_PASSWORD")
        if not _raw_uri or any(tok in _raw_uri for tok in _placeholder_tokens):
            _db = db_info.get("database_name") or dashboard_name
            sqlalchemy_uri = f"mysql+pymysql://user:password@localhost:3306/{_db}"
        else:
            sqlalchemy_uri = _raw_uri

        table_name = ds_info.get("table_name") or dashboard_name
        dataset_uuid = _ensure_uuid(ds_info.get("uuid"))
        schema = ds_info.get("schema")
        metrics = ds_info.get("metrics") or []
        columns = ds_info.get("columns") or []

        # --- databases/<db>.yaml ---
        db_yaml_lines = [
            f"database_name: {_yaml_str(db_name)}",
            f"sqlalchemy_uri: {_yaml_str(sqlalchemy_uri)}",
            f"uuid: {db_uuid}",
            "version: 1.0.0",
            "expose_in_sqllab: true",
            "extra:",
            "  allows_virtual_table_explore: true",
        ]
        result[f"databases/{db_name}.yaml"] = "\n".join(db_yaml_lines) + "\n"

        # --- datasets/<db>/<table>.yaml ---
        ds_yaml_lines = [
            f"table_name: {_yaml_str(table_name)}",
            f"uuid: {dataset_uuid}",
            f"database_uuid: {db_uuid}",
            "version: 1.0.0",
            f"schema: {_yaml_str(schema)}",
            "main_dttm_col: null",
            "sql: null",
        ]
        if metrics:
            ds_yaml_lines.append("metrics:")
            for m in metrics:
                ds_yaml_lines.append(f"  - metric_name: {_yaml_str(m.get('metric_name') or m.get('name', ''))}")
                ds_yaml_lines.append(f"    expression: {_yaml_str(m.get('expression') or m.get('sql', ''))}")
        else:
            ds_yaml_lines.append("metrics: []")
        if columns:
            ds_yaml_lines.append("columns:")
            for col in columns:
                ds_yaml_lines.append(f"  - column_name: {_yaml_str(col)}")
                ds_yaml_lines.append("    is_dttm: false")
        else:
            ds_yaml_lines.append("columns: []")
        result[f"datasets/{db_name}/{table_name}.yaml"] = "\n".join(ds_yaml_lines) + "\n"

        # --- charts/<slug>.yaml (one per non-exception chart) ---
        charts_list: list[dict] = []
        if isinstance(chart_inventory, dict):
            charts_list = chart_inventory.get("charts") or []
        elif isinstance(chart_inventory, list):
            charts_list = chart_inventory

        charts_meta: list[dict] = []
        slug_counts: dict[str, int] = {}
        for chart in charts_list:
            viz_type = chart.get("superset_viz_type")
            complexity = chart.get("complexity", "")
            if not viz_type:
                logger.info("%s: Skipping exception chart '%s'", self.tool_name, chart.get("chart"))
                continue

            chart_yaml_content, chart_uuid = _build_chart_yaml(chart, dataset_uuid)
            chart_name = chart.get("chart", "chart")
            slug = _slugify(chart_name)

            # Deduplicate slugs
            slug_counts[slug] = slug_counts.get(slug, 0) + 1
            if slug_counts[slug] > 1:
                slug = f"{slug}_{slug_counts[slug]}"

            result[f"charts/{slug}.yaml"] = chart_yaml_content
            charts_meta.append({"name": chart_name, "uuid": chart_uuid})
            logger.info("%s: Generated chart '%s' → charts/%s.yaml", self.tool_name, chart_name, slug)

        # --- dashboards/<name>.yaml ---
        if charts_meta or native_filters:
            dash_yaml = _build_dashboard_yaml(
                dashboard_name=dashboard_name,
                charts_meta=charts_meta,
                dataset_uuid=dataset_uuid,
                native_filters=native_filters,
            )
            dash_slug = _slugify(dashboard_name)
            result[f"dashboards/{dash_slug}.yaml"] = dash_yaml

        return result

    def _load_session_context(self) -> tuple[dict | None, dict | None]:
        """Load chart_inventory and dataset_manifest from the session directory.

        Reads:
          - ``context_map_output.json`` for chart_inventory (from the Qlik Visuals PDF section)
          - ``agents/AGENT_814/output.md`` for the dataset_manifest JSON block

        Returns:
            (chart_inventory, dataset_manifest) — either may be None if not found.
        """
        chart_inventory: dict | None = None
        dataset_manifest: dict | None = None

        if not self._data_dir:
            return None, None

        session_dir = Path(self._data_dir)
        if session_dir.name == "inputs":
            session_dir = session_dir.parent

        # --- Load chart_inventory from context_map_output.json ---
        ctx_path = session_dir / "context_map_output.json"
        if ctx_path.exists():
            try:
                ctx = json.loads(ctx_path.read_text(encoding="utf-8"))
                # Search every agent's context for a chart inventory section
                for agent in ctx.get("agents", []):
                    agent_ctx_raw = agent.get("context", "{}")
                    if not isinstance(agent_ctx_raw, str):
                        continue
                    try:
                        agent_ctx = json.loads(agent_ctx_raw)
                    except Exception:
                        continue
                    for file_name, partitions in agent_ctx.items():
                        if not isinstance(partitions, list):
                            continue
                        for part in partitions:
                            content = part.get("Content", "")
                            if "superset_viz_type" not in content:
                                continue
                            # Strip leading "Generated on …\n" prefix if present
                            body = content
                            if body.startswith("Generated on"):
                                body = body.split("\n", 1)[-1].strip()
                            try:
                                parsed = json.loads(body)
                                if isinstance(parsed, dict) and "charts" in parsed:
                                    chart_inventory = parsed
                                    logger.info("%s: Loaded chart_inventory from %s",
                                                self.tool_name, ctx_path.name)
                                    break
                            except Exception:
                                continue
                        if chart_inventory:
                            break
                    if chart_inventory:
                        break
            except Exception as exc:
                logger.warning("%s: Could not parse context_map_output.json: %s", self.tool_name, exc)

        # --- Load dataset_manifest from agents/AGENT_814/output.md ---
        agent814_output = session_dir / "agents" / "AGENT_814" / "output.md"
        if agent814_output.exists():
            try:
                text = agent814_output.read_text(encoding="utf-8")
                # Extract the first JSON fenced block
                import re as _re
                m = _re.search(r"```(?:json)?\s*(\{.*?)\s*```", text, _re.DOTALL)
                if m:
                    parsed = json.loads(m.group(1))
                    if isinstance(parsed, dict) and "dataset" in parsed:
                        dataset_manifest = parsed
                        logger.info("%s: Loaded dataset_manifest from AGENT_814/output.md",
                                    self.tool_name)
            except Exception as exc:
                logger.warning("%s: Could not parse AGENT_814/output.md: %s", self.tool_name, exc)

        return chart_inventory, dataset_manifest

    def _ensure_metadata(self, bundle_dir: str) -> None:
        """Create metadata.yaml if the LLM output didn't include one."""
        meta = os.path.join(bundle_dir, "metadata.yaml")
        if not os.path.exists(meta):
            ts = datetime.datetime.now(datetime.timezone.utc).isoformat()
            with open(meta, "w", encoding="utf-8") as f:
                f.write(f"version: 1.0.0\ntype: Dashboard\ntimestamp: '{ts}'\n")
            logger.info("%s: Created metadata.yaml", self.tool_name)

    def _resolve_artifacts_dir(self) -> Path:
        """Resolve the session artifacts directory."""
        if self._data_dir:
            data_path = Path(self._data_dir)
            session_dir = data_path.parent if data_path.name == "inputs" else data_path
            return session_dir / "artifacts"

        return Path(__file__).resolve().parent / "artifacts"


if __name__ == "__main__":
    builder = DashboardBuilder()
    bundle = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_BUNDLE
    out    = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_ZIP
    result = builder.build_zip(bundle_dir=bundle, zip_filename=os.path.basename(out))
    print(json.dumps(result, indent=2))
