from __future__ import annotations

import base64
import binascii
import logging
import re
import os
import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path
from collections.abc import Iterable
from typing import Any

from daan.flow.session_service import get_artifacts_dir

logger = logging.getLogger(__name__)

_VALID_EXTENSIONS = {"svg", "png", "pdf", "mmd", "txt"}
_MERMAID_CLI_PACKAGES = ["@mermaid-js/mermaid-cli", "@fortawesome/fontawesome-free"]


def _resolve_mmdc_command() -> str | None:
    return shutil.which("mmdc.cmd") or shutil.which("mmdc")


def _get_cli_cache_dir() -> Path:
    configured = str(os.getenv("MERMAID_CLI_CACHE_DIR") or "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    return Path(tempfile.gettempdir()).resolve() / "daan_mermaid_cli"


def _resolve_cached_mmdc_command(cache_dir: Path) -> Path:
    if os.name == "nt":
        return cache_dir / "node_modules" / ".bin" / "mmdc.cmd"
    return cache_dir / "node_modules" / ".bin" / "mmdc"


def _ensure_cached_mermaid_cli() -> str:
    cache_dir = _get_cli_cache_dir()
    cache_dir.mkdir(parents=True, exist_ok=True)

    package_json = cache_dir / "package.json"
    if not package_json.exists():
        package_json.write_text(
            '{\n  "name": "daan-mermaid-cli-cache",\n  "private": true\n}\n',
            encoding="utf-8",
        )

    cached_mmdc = _resolve_cached_mmdc_command(cache_dir)
    if cached_mmdc.exists():
        return str(cached_mmdc)

    npm_cmd = shutil.which("npm.cmd") or shutil.which("npm") or "npm"
    try:
        install_timeout = int(float(os.getenv("MERMAID_CLI_INSTALL_TIMEOUT_SECONDS", "300") or "300"))
    except ValueError:
        install_timeout = 300

    completed = subprocess.run(
        [npm_cmd, "install", *_MERMAID_CLI_PACKAGES, "--no-fund", "--no-audit"],
        cwd=str(cache_dir),
        capture_output=True,
        text=True,
        timeout=install_timeout,
        check=False,
    )
    if completed.returncode != 0 or not cached_mmdc.exists():
        stderr = (completed.stderr or completed.stdout or "Failed to install Mermaid CLI cache").strip()
        raise RuntimeError(stderr[:1000])

    return str(cached_mmdc)


def _render_with_mermaid_cli(input_path: Path, output_path: Path) -> None:
    scale = str(os.getenv("MERMAID_RENDER_SCALE", "3") or "3")
    mmdc_cmd = _resolve_mmdc_command()
    if mmdc_cmd:
        command = [mmdc_cmd, "-i", str(input_path), "-o", str(output_path), "-b", "transparent", "-s", scale]
    else:
        cached_mmdc_cmd = _ensure_cached_mermaid_cli()
        command = [cached_mmdc_cmd, "-i", str(input_path), "-o", str(output_path), "-b", "transparent", "-s", scale]

    try:
        render_timeout = int(float(os.getenv("MERMAID_RENDER_TIMEOUT_SECONDS", "300") or "300"))
    except ValueError:
        render_timeout = 300

    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=render_timeout,
        check=False,
    )
    if completed.returncode != 0:
        stderr = (completed.stderr or completed.stdout or "Unknown Mermaid CLI error").strip()
        raise RuntimeError(stderr[:1000])


class MermaidArtifactWriter:
    """Persist rendered Mermaid outputs into a session's downloadable artifacts folder."""

    def __init__(self, data_dir: str | None = None):
        self.tool_name = "MermaidArtifactWriter"
        self._data_dir = data_dir
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    def save_rendered_artifact(
        self,
        session_id: str | None = None,
        diagram_name: str | None = None,
        rendered_content: str | None = None,
        svg_content: str | None = None,
        base64_content: str | None = None,
        source_file_path: str | None = None,
        output_extension: str = "svg",
        mermaid_source: str | None = None,
        save_source: bool = True,
        save_source_only: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Save rendered Mermaid output or a rendered file path as downloadable artifacts."""
        try:
            resolved_session_id = str(session_id or kwargs.get("sessionId") or "").strip()
            if not resolved_session_id:
                return {"status": "error", "errors": ["session_id is required"]}

            safe_name = self._safe_stem(diagram_name or kwargs.get("file_name") or "diagram")
            extension = self._normalize_extension(output_extension or kwargs.get("format") or "svg")
            artifacts_dir = get_artifacts_dir(resolved_session_id, create=True)
            artifact_paths: list[str] = []
            source_only_mode = self._as_bool(save_source_only or kwargs.get("save_source_only") or kwargs.get("checkpoint_only"))

            if source_only_mode:
                if not mermaid_source:
                    return {"status": "error", "errors": ["mermaid_source is required when save_source_only is true"]}
                source_only_path = artifacts_dir / f"{safe_name}.mmd"
                source_only_path.write_text(str(mermaid_source), encoding="utf-8")
                artifact_paths.append(str(source_only_path))
                message = f"Saved Mermaid source artifact: {source_only_path.name}"
                return {
                    "status": "ok",
                    "message": message,
                    "artifact_name": source_only_path.name,
                    "artifact_path": str(source_only_path),
                    "artifact_paths": artifact_paths,
                    "ui_output": message,
                    "reviewed_output": message,
                    "session_id": resolved_session_id,
                    "diagram_name": safe_name,
                    "output_extension": "mmd",
                    "saved_source_only": True,
                }

            if save_source and mermaid_source:
                source_path = artifacts_dir / f"{safe_name}.mmd"
                source_path.write_text(str(mermaid_source), encoding="utf-8")
                artifact_paths.append(str(source_path))

            target_path = artifacts_dir / f"{safe_name}.{extension}"

            copied = self._try_copy_rendered_file(
                target_path=target_path,
                explicit_source=source_file_path,
                kwargs=kwargs,
            )
            if copied:
                artifact_paths.append(str(target_path))
            else:
                content = self._resolve_text_content(rendered_content, svg_content, kwargs)
                if content is not None:
                    target_path.write_text(content, encoding="utf-8")
                    artifact_paths.append(str(target_path))
                else:
                    resolved_base64 = self._resolve_base64_content(base64_content, kwargs)
                    if resolved_base64:
                        target_path.write_bytes(self._decode_base64(resolved_base64))
                        artifact_paths.append(str(target_path))
                    elif mermaid_source and extension in {"png", "svg", "pdf"}:
                        try:
                            self._render_from_mermaid_source(
                                mermaid_source=str(mermaid_source),
                                diagram_name=safe_name,
                                target_path=target_path,
                            )
                            artifact_paths.append(str(target_path))
                        except Exception as render_exc:
                            if artifact_paths:
                                message = (
                                    f"Saved Mermaid source artifact only: {', '.join(Path(p).name for p in artifact_paths)}. "
                                    f"Render failed: {render_exc}"
                                )
                                return {
                                    "status": "partial",
                                    "message": message,
                                    "artifact_name": Path(artifact_paths[0]).name,
                                    "artifact_path": artifact_paths[0],
                                    "artifact_paths": artifact_paths,
                                    "ui_output": message,
                                    "reviewed_output": message,
                                    "session_id": resolved_session_id,
                                    "diagram_name": safe_name,
                                    "output_extension": "mmd",
                                    "saved_source_only": True,
                                    "render_error": str(render_exc),
                                }
                            raise
                    else:
                        return {
                            "status": "error",
                            "errors": [
                                "No render output found. Provide source_file_path, rendered_content/svg_content, or base64_content."
                            ],
                        }

            message = f"Saved Mermaid artifact(s): {', '.join(Path(p).name for p in artifact_paths)}"
            return {
                "status": "ok",
                "message": message,
                "artifact_name": Path(target_path).name,
                "artifact_path": str(target_path),
                "artifact_paths": artifact_paths,
                "ui_output": message,
                "reviewed_output": message,
                "session_id": resolved_session_id,
                "diagram_name": safe_name,
                "output_extension": extension,
            }
        except Exception as exc:
            logger.exception("%s: failed to save Mermaid artifacts", self.tool_name)
            return {"status": "error", "errors": [f"Mermaid artifact save failed: {exc}"]}

    def _try_copy_rendered_file(
        self,
        target_path: Path,
        explicit_source: str | None,
        kwargs: dict[str, Any],
    ) -> bool:
        source_candidates = [
            explicit_source,
            kwargs.get("artifact_path"),
            kwargs.get("file_path"),
            kwargs.get("output_file"),
            kwargs.get("rendered_file_path"),
            kwargs.get("rendered_output"),
            kwargs.get("mcp_response"),
        ]
        for candidate in source_candidates:
            for value in self._iter_possible_paths(candidate):
                source_path = Path(value).expanduser()
                if source_path.is_file():
                    target_path.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(source_path, target_path)
                    return True
        return False

    def _resolve_text_content(
        self,
        rendered_content: str | None,
        svg_content: str | None,
        kwargs: dict[str, Any],
    ) -> str | None:
        candidates = [
            rendered_content,
            svg_content,
            kwargs.get("svg"),
            kwargs.get("content"),
            kwargs.get("result"),
            kwargs.get("output"),
            kwargs.get("rendered_output"),
            kwargs.get("mcp_response"),
        ]
        for candidate in candidates:
            for value in self._iter_text_candidates(candidate):
                if value.startswith("<svg") or "\n" in value:
                    return value
        return None

    def _resolve_base64_content(self, base64_content: str | None, kwargs: dict[str, Any]) -> str | None:
        if isinstance(base64_content, str) and base64_content.strip():
            return base64_content.strip()

        candidates = [
            kwargs.get("base64_content"),
            kwargs.get("image_data"),
            kwargs.get("data"),
            kwargs.get("content"),
            kwargs.get("result"),
            kwargs.get("output"),
            kwargs.get("rendered_output"),
            kwargs.get("mcp_response"),
        ]
        for candidate in candidates:
            for value in self._iter_base64_candidates(candidate):
                return value
        return None

    def _iter_possible_paths(self, candidate: Any) -> Iterable[str]:
        if isinstance(candidate, str):
            stripped = candidate.strip()
            if stripped and self._looks_like_path(stripped):
                yield stripped
            return
        if isinstance(candidate, dict):
            for key in ("artifact_path", "file_path", "output_file", "rendered_file_path", "path", "file"):
                value = candidate.get(key)
                if isinstance(value, str) and value.strip() and self._looks_like_path(value):
                    yield value.strip()
            for value in candidate.values():
                yield from self._iter_possible_paths(value)
            return
        if isinstance(candidate, list):
            for item in candidate:
                yield from self._iter_possible_paths(item)

    def _iter_text_candidates(self, candidate: Any) -> Iterable[str]:
        if isinstance(candidate, str):
            stripped = candidate.strip()
            if stripped and not self._looks_like_path(stripped) and not self._looks_like_base64(stripped):
                yield stripped
            return
        if isinstance(candidate, dict):
            for key in ("svg", "rendered_content", "content", "result", "output", "text", "value"):
                value = candidate.get(key)
                if isinstance(value, str):
                    yield from self._iter_text_candidates(value)
            for value in candidate.values():
                yield from self._iter_text_candidates(value)
            return
        if isinstance(candidate, list):
            for item in candidate:
                yield from self._iter_text_candidates(item)

    def _iter_base64_candidates(self, candidate: Any) -> Iterable[str]:
        if isinstance(candidate, str):
            stripped = candidate.strip()
            if stripped and self._looks_like_base64(stripped):
                yield stripped
            return
        if isinstance(candidate, dict):
            mime_type = str(candidate.get("mimeType") or candidate.get("mime_type") or "").lower()
            for key in ("base64_content", "data", "image_data", "content", "result", "output", "value"):
                value = candidate.get(key)
                if isinstance(value, str):
                    if key == "data" and mime_type and not mime_type.startswith("image/"):
                        continue
                    yield from self._iter_base64_candidates(value)
            for value in candidate.values():
                yield from self._iter_base64_candidates(value)
            return
        if isinstance(candidate, list):
            for item in candidate:
                yield from self._iter_base64_candidates(item)

    def _looks_like_path(self, value: str) -> bool:
        lower_value = value.lower()
        return lower_value.endswith((".png", ".svg", ".pdf", ".mmd", ".txt")) or ":\\" in value or value.startswith("\\")

    def _looks_like_base64(self, value: str) -> bool:
        cleaned = value.strip()
        if cleaned.startswith("data:image/"):
            return True
        if len(cleaned) < 32 or " " in cleaned or "\n" in cleaned:
            return False
        return bool(re.fullmatch(r"[A-Za-z0-9+/=]+", cleaned))

    def _decode_base64(self, value: str) -> bytes:
        try:
            return base64.b64decode(value, validate=True)
        except binascii.Error:
            cleaned = value.split(",", 1)[-1].strip()
            return base64.b64decode(cleaned)

    def _render_from_mermaid_source(self, mermaid_source: str, diagram_name: str, target_path: Path) -> None:
        with tempfile.TemporaryDirectory(prefix="daan_mermaid_writer_") as tmp_dir:
            temp_input = Path(tmp_dir) / f"{diagram_name}.mmd"
            temp_input.write_text(str(mermaid_source), encoding="utf-8")
            target_path.parent.mkdir(parents=True, exist_ok=True)
            _render_with_mermaid_cli(temp_input, target_path)

    def _safe_stem(self, value: str) -> str:
        candidate = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "diagram").strip())
        candidate = candidate.strip("._") or f"diagram_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        return candidate[:120]

    def _normalize_extension(self, value: str) -> str:
        ext = str(value or "svg").strip().lower().lstrip(".")
        if ext not in _VALID_EXTENSIONS:
            return "svg"
        return ext

    def _as_bool(self, value: Any) -> bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.strip().lower() in {"1", "true", "yes", "y", "on"}
        return bool(value)
