"""Lossless process-design source extractor for the Use Case Builder pipeline.

Reads an uploaded process-design source from the session ``inputs/`` folder and
returns a single, information-complete structured graph. It handles two broad
source kinds:

  * Images (diagrams / screenshots / photos of a flow) — sent to a vision-capable
    model in high-detail mode with an explicit extraction checklist and one
    verification pass, so nothing on the diagram is silently dropped.
  * Text-bearing documents (pdf / docx / txt / md) — text is first extracted and
    then converted into the same structured graph schema.

The model used for the extraction call is passed in by the caller (``model``);
this tool never hardcodes a specific model. When no model is supplied it falls
back to the gateway default so the tool still runs standalone.

local_tools reference:
    SourceExtractTool.extract
"""

from __future__ import annotations

import base64
import json
import logging
import mimetypes
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}
_TEXT_EXT = {".txt", ".md", ".markdown", ".json", ".yaml", ".yml"}
_PDF_EXT = {".pdf"}
_DOCX_EXT = {".docx"}
_SUPPORTED_EXT = _IMAGE_EXT | _TEXT_EXT | _PDF_EXT | _DOCX_EXT

_GRAPH_SCHEMA = """{
  "legend": {},
  "phases": [],
  "roles": [],
  "unused_roles": [],
  "nodes": [
    {
      "id": "",
      "label": "",
      "type": "start | end | task | decision | datastore | tool | data_element | role | annotation | uncertain",
      "phase": "",
      "role": "",
      "cadence": "one_time | repeat | uncertain",
      "schedule": ""
    }
  ],
  "edges": [
    {
      "from": "",
      "to": "",
      "style": "solid | dashed | dotted | uncertain",
      "kind": "SEQUENTIAL | BRANCH | MERGE | LOOP_BACK | PARALLEL | CONDITIONAL | uncertain",
      "cadence": "one_time | repeat | uncertain",
      "condition": "",
      "return_to": ""
    }
  ],
  "gates": [
    {
      "name": "",
      "description": ""
    }
  ],
  "decisions": [
    {
      "name": "",
      "outcomes": [
        {
          "label": "",
          "to": ""
        }
      ]
    }
  ],
  "business_context": ""
}"""

_EXTRACTION_CHECKLIST = f"""You are a process-design extraction specialist. Extract EVERYTHING from the
source — never summarise or skip. If something is unclear, mark it "uncertain"
rather than omit it. Work ONLY from what the source encodes; do not assume
conventions the source does not show.

First read the LEGEND/key if the source has one (shapes, icons, line styles,
colours) and use IT to interpret every element. If there is no legend, infer from
context and mark any guess "uncertain".

The legend may encode meaning by COLOUR, not only by line style. If the legend
defines colours (e.g. one colour = one_time, another = repeat), read each node's
and edge's cadence from its actual line/fill COLOUR per that legend, not from
solid-vs-dashed. Only use solid/dashed when the legend itself defines style.

For EACH node, classify its "type" from its shape/icon per the legend, using this
generic enum: start | end | task | decision | datastore | tool | data_element |
role | annotation | uncertain. Typical (not mandatory) conventions: rectangle ->
task, diamond -> decision, cylinder/database -> datastore, gear -> tool,
star -> data_element, rounded/circle -> start or end. If ambiguous or unlabelled,
use "uncertain".

For EACH node and edge, capture "cadence" from the legend's style/colour meaning:
one_time | repeat | uncertain (e.g. one line style/colour = one_time, another =
repeat/loop). If a schedule marker is present (clock / "daily/weekly/monthly" /
cron), record it in "schedule", else "".

Capture EVERY labelled box, callout, annotation, list, and note as a node — not
just process steps. This includes outputs, files, reports, dashboards,
repositories, recommendations, data-check lists, and numbered side descriptions;
use type "annotation", "data_element", "datastore", or "tool" as appropriate. Do
not drop a box just because it is not a step.

Capture: every node (exact label, phase, owning role/swimlane); every standalone
named artifact/output/input/datastore/tool exactly as written, even if it is only
a data object, file, dashboard, repository, recommendation, or note rather than a
step; every arrow as from->to with style and kind (SEQUENTIAL | BRANCH | MERGE |
LOOP_BACK | PARALLEL | CONDITIONAL); for any LOOP_BACK or looping node, ALSO
record where the loop rejoins in "return_to" (use "uncertain" if not visible —
never omit it); every gate/approval; every decision (with each labelled outcome
and its target); and any business context (client, scale, regulation, timeline,
platform, systems). List any role that owns no node in "unused_roles".

Produce a CONNECTED flow: trace arrows ACROSS phase/swimlane boxes, not only
within them. Every node except a start node should have at least one incoming
edge, and every node except an end node at least one outgoing edge. If a
connection is implied but its exact endpoint is unclear, add the edge and set its
"return_to"/"condition" or the edge "kind" to "uncertain" rather than leaving a
node disconnected. Never fabricate an edge the source does not show.

NEVER invent steps not in the source. Preserve literal labels verbatim; do not
rename, generalize, or merge them. Return JSON ONLY. No markdown fences. No prose.
Use exactly this top-level schema:
{_GRAPH_SCHEMA}
"""

_VERIFY_INSTRUCTION = """Compare your JSON extraction below against the SAME source once more.
List mentally anything you missed (nodes, edges, literal labels, named artifacts,
datastores, tools, callouts/annotations, decisions, loops with their return_to,
gates, legend items), and check that cadence was read from the legend's COLOUR
meaning where the legend defines colours, and that the graph is connected across
phases (no orphan nodes). Then output the COMPLETE corrected JSON graph only.
If nothing is missing, output the same JSON unchanged.

Previous extraction:
"""


class SourceExtractTool:
    """Native tool that turns an uploaded process design into a structured graph."""

    def __init__(self, data_dir: str | None = None, **_kwargs: Any) -> None:
        self.tool_name = "SourceExtractTool"
        self._data_dir = data_dir
        logger.info("%s: initialized (data_dir=%s)", self.tool_name, data_dir)

    def extract(
        self,
        model: str | None = None,
        file_name: str | None = None,
        verify: bool = True,
        **_kwargs: Any,
    ) -> dict[str, Any]:
        """Extract a complete structured process graph from an already-uploaded source.

        The source file is ALREADY present in the session inputs folder — call
        this tool directly with no arguments; never ask the user to upload again.

        Args:
            model: Model id for the extraction call. Passed to the LiteLLM
                gateway. When omitted, the gateway default is used.
            file_name: Optional exact filename inside the session inputs folder.
                When omitted, the first supported source file is used.
            verify: When True (default) and the source is an image, run one extra
                verification pass to catch anything missed on the first read.

        Returns:
            A dict with keys:
              ``status`` ("ok" | "error"),
              ``source_type`` ("image" | "pdf" | "docx" | "text"),
              ``file`` (source filename),
              ``model`` (model id used, or None for pure text extraction),
              ``process_model`` (the structured Markdown process model),
              ``error`` (present only on failure).
        """
        try:
            source = self._resolve_source_file(file_name)
            if source is None:
                return self._error("No supported source file found in session inputs.")

            suffix = source.suffix.lower()
            if suffix in _IMAGE_EXT:
                return self._extract_image(source, model, verify)
            if suffix in _PDF_EXT:
                return self._extract_pdf(source, model)
            if suffix in _DOCX_EXT:
                return self._extract_docx(source, model)
            return self._extract_text(source, model)
        except Exception as exc:  # noqa: BLE001
            logger.exception("%s: extract failed", self.tool_name)
            return self._error(f"Failed to extract source: {exc}")

    def _extract_image(self, source: Path, model: str | None, verify: bool) -> dict[str, Any]:
        data_url = self._to_data_url(source)
        used_model = self._resolve_model(model)

        first = self._vision_completion(used_model, _EXTRACTION_CHECKLIST, data_url)
        extracted = first

        if verify:
            verify_prompt = _VERIFY_INSTRUCTION + first
            second = self._vision_completion(used_model, verify_prompt, data_url)
            if second and second.strip():
                extracted = second

        graph = self._parse_graph(extracted)
        return self._success_payload(
            source_type="image",
            file_name=source.name,
            model=used_model,
            graph=graph,
        )

    def _extract_pdf(self, source: Path, model: str | None) -> dict[str, Any]:
        try:
            from pypdf import PdfReader
        except Exception:  # noqa: BLE001
            try:
                from PyPDF2 import PdfReader  # type: ignore
            except Exception:  # noqa: BLE001
                return self._error(
                    "PDF support requires the 'pypdf' package to be installed."
                )
        reader = PdfReader(str(source))
        pages = [(page.extract_text() or "").strip() for page in reader.pages]
        text = "\n\n".join(p for p in pages if p)
        if not text.strip():
            return self._error(
                "The PDF contains no extractable text (it may be a scanned image; "
                "upload it as an image file instead)."
            )
        return self._extract_from_text_payload(
            text,
            source_type="pdf",
            file_name=source.name,
            model=model,
        )

    def _extract_docx(self, source: Path, model: str | None) -> dict[str, Any]:
        try:
            import docx  # python-docx
        except Exception:  # noqa: BLE001
            return self._error(
                "DOCX support requires the 'python-docx' package to be installed."
            )
        document = docx.Document(str(source))
        parts = [p.text for p in document.paragraphs if p.text and p.text.strip()]
        for table in document.tables:
            for row in table.rows:
                cells = [c.text.strip() for c in row.cells if c.text and c.text.strip()]
                if cells:
                    parts.append(" | ".join(cells))
        text = "\n".join(parts)
        if not text.strip():
            return self._error("The DOCX file contains no readable text.")
        return self._extract_from_text_payload(
            text,
            source_type="docx",
            file_name=source.name,
            model=model,
        )

    def _extract_text(self, source: Path, model: str | None) -> dict[str, Any]:
        text = source.read_text(encoding="utf-8", errors="replace")
        if not text.strip():
            return self._error("The uploaded text file is empty.")
        return self._extract_from_text_payload(
            text,
            source_type="text",
            file_name=source.name,
            model=model,
        )

    def _extract_from_text_payload(
        self,
        text: str,
        *,
        source_type: str,
        file_name: str,
        model: str | None,
    ) -> dict[str, Any]:
        used_model = self._resolve_model(model)
        first = self._text_completion(used_model, _EXTRACTION_CHECKLIST, text)
        extracted = first

        verify_prompt = _VERIFY_INSTRUCTION + first
        second = self._text_completion(used_model, verify_prompt, text)
        if second and second.strip():
            extracted = second

        graph = self._parse_graph(extracted)
        return self._success_payload(
            source_type=source_type,
            file_name=file_name,
            model=used_model,
            graph=graph,
        )

    def _vision_completion(self, model: str, instruction: str, data_url: str) -> str:
        import litellm

        from daan.llm.llm_provider import get_litellm_settings

        settings = get_litellm_settings()
        content = [
            {"type": "text", "text": instruction},
            {"type": "image_url", "image_url": {"url": data_url, "detail": "high"}},
        ]
        response = litellm.completion(
            model=self._gateway_model(model),
            messages=[{"role": "user", "content": content}],
            api_base=settings["url"],
            api_key=settings.get("api_key") or "no-key",
            temperature=0,
            max_tokens=16384,
        )
        return self._response_text(response)

    def _text_completion(self, model: str, instruction: str, source_text: str) -> str:
        import litellm

        from daan.llm.llm_provider import get_litellm_settings

        settings = get_litellm_settings()
        prompt = f"{instruction}\n\nSOURCE TEXT:\n{source_text}"
        response = litellm.completion(
            model=self._gateway_model(model),
            messages=[{"role": "user", "content": prompt}],
            api_base=settings["url"],
            api_key=settings.get("api_key") or "no-key",
            temperature=0,
            max_tokens=16384,
        )
        return self._response_text(response)

    def _resolve_source_file(self, file_name: str | None) -> Path | None:
        if not self._data_dir:
            return None
        inputs_dir = Path(self._data_dir)
        if not inputs_dir.is_dir():
            return None

        if file_name:
            candidate = inputs_dir / file_name
            return candidate if candidate.is_file() else None

        for item in sorted(inputs_dir.iterdir()):
            if item.is_file() and item.suffix.lower() in _SUPPORTED_EXT:
                return item
        return None

    @staticmethod
    def _to_data_url(source: Path) -> str:
        mime = mimetypes.guess_type(source.name)[0] or "image/png"
        encoded = base64.b64encode(source.read_bytes()).decode("ascii")
        return f"data:{mime};base64,{encoded}"

    @staticmethod
    def _resolve_model(model: str | None) -> str:
        name = str(model or "").strip()
        if name:
            return name
        from daan.llm.llm_provider import get_litellm_settings

        return str(get_litellm_settings().get("default_model") or "gpt-4o")

    @staticmethod
    def _gateway_model(model: str) -> str:
        name = str(model or "").strip()
        if name.startswith("litellm_proxy/"):
            return name
        return f"litellm_proxy/{name}"

    @staticmethod
    def _response_text(response: Any) -> str:
        from daan.llm.litellm_response import extract_response_content

        content = extract_response_content(response)
        if content:
            return content
        raise ValueError("Extractor model returned no assistant content.")

    @staticmethod
    def _parse_graph(payload: str) -> dict[str, Any]:
        text = str(payload or "").strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*", "", text)
            text = re.sub(r"\s*```$", "", text)

        data = None
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            # Salvage the outermost {...} block when the model adds prose/fences.
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if match:
                try:
                    data = json.loads(match.group(0))
                except json.JSONDecodeError:
                    data = None
        if not isinstance(data, dict):
            raise ValueError("Extractor returned no parseable JSON graph.")

        return {
            "legend": data.get("legend") if isinstance(data.get("legend"), dict) else {},
            "phases": data.get("phases") if isinstance(data.get("phases"), list) else [],
            "roles": data.get("roles") if isinstance(data.get("roles"), list) else [],
            "unused_roles": data.get("unused_roles") if isinstance(data.get("unused_roles"), list) else [],
            "nodes": data.get("nodes") if isinstance(data.get("nodes"), list) else [],
            "edges": data.get("edges") if isinstance(data.get("edges"), list) else [],
            "gates": data.get("gates") if isinstance(data.get("gates"), list) else [],
            "decisions": data.get("decisions") if isinstance(data.get("decisions"), list) else [],
            "business_context": str(data.get("business_context") or ""),
        }

    @staticmethod
    def _success_payload(
        *,
        source_type: str,
        file_name: str,
        model: str | None,
        graph: dict[str, Any],
    ) -> dict[str, Any]:
        return {
            "status": "ok",
            "source_type": source_type,
            "file": file_name,
            "model": model,
            **graph,
            "process_model": json.dumps(graph, ensure_ascii=False, indent=2),
        }

    @staticmethod
    def _error(message: str) -> dict[str, Any]:
        return {
            "status": "error",
            "source_type": "",
            "file": "",
            "model": None,
            "legend": {},
            "phases": [],
            "roles": [],
            "unused_roles": [],
            "nodes": [],
            "edges": [],
            "gates": [],
            "decisions": [],
            "business_context": "",
            "process_model": "",
            "error": message,
        }
