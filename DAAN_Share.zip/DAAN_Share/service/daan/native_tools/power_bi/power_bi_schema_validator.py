"""
Power BI Schema Validator

Validates and auto-fixes the LLM-generated JSON schema before it is consumed
by PowerBIReportTool.  All validation, fuzzy-matching, column reconciliation,
DAX patching, and measure/calculated-column injection logic lives here so that
the tool itself stays focused on file generation.

Usage (inside the tool):
    from daan.native_tools.powerbi_schema_validator import PowerBISchemaValidator

    validator = PowerBISchemaValidator(data_dir=self.data_dir)
    result = validator.validate_and_fix(schema)
    if not result.ok:
        return result.to_tool_error()   # LLM-readable error string
    schema = result.schema              # cleaned schema, safe to generate
"""

import csv
import difflib
import logging
import os
import re
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import pandas as pd

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------
class ValidationResult:
    """Bundles validation outcome so the tool can decide what to return."""

    def __init__(self, schema: Dict[str, Any]):
        self.schema = schema
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.auto_fixes: List[str] = []

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0

    def to_tool_error(self) -> str:
        """Format a concise, LLM-targeted error string."""
        parts = ["Schema validation failed. Fix these issues and call the tool again:"]
        for e in self.errors[:10]:
            parts.append(f"  - {e}")
        if len(self.errors) > 10:
            parts.append(f"  ... and {len(self.errors) - 10} more errors.")
        return "\n".join(parts)

    def to_tool_success_notes(self) -> str:
        """Short summary of auto-fixes applied (appended to success message)."""
        if not self.auto_fixes and not self.warnings:
            return ""
        parts = []
        if self.auto_fixes:
            parts.append(f"Auto-corrections applied ({len(self.auto_fixes)}):")
            for note in self.auto_fixes[:5]:
                parts.append(f"  - {note}")
            if len(self.auto_fixes) > 5:
                parts.append(f"  ... and {len(self.auto_fixes) - 5} more.")
        if self.warnings:
            parts.append(f"Warnings ({len(self.warnings)}):")
            for w in self.warnings[:3]:
                parts.append(f"  - {w}")
        return "\n".join(parts)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _extract_field_refs(data_mapping: Dict[str, Any]) -> List[Tuple[str, str]]:
    """Extract (table_name, field_name) pairs from a visual's data mapping.

    Handles the three formats the LLM may produce:
      - string   "Table[Field]" or "Field"
      - dict     {"table": "T", "field": "F"} or {"table": "T", "column": "C", "measure": "M"}
      - list     [item, ...]
    """
    refs: List[Tuple[str, str]] = []

    def _parse_item(item: Any, fallback_table: str = ""):
        if isinstance(item, str):
            if "[" in item and "]" in item:
                tbl = item.split("[")[0].strip()
                fld = item.split("[")[1].rstrip("]").strip()
                refs.append((tbl, fld))
            elif item.strip():
                refs.append((fallback_table, item.strip()))
        elif isinstance(item, dict):
            tbl = item.get("table", fallback_table)
            for key in ("field", "column", "measure"):
                fld = item.get(key, "")
                if fld:
                    refs.append((tbl, fld))

    for _role, field_def in data_mapping.items():
        if not field_def:
            continue
        if isinstance(field_def, list):
            for sub in field_def:
                _parse_item(sub)
        else:
            _parse_item(field_def)

    return refs


def _find_similar(name: str, candidates: set, n: int = 3, cutoff: float = 0.6) -> str:
    if not candidates:
        return "(none available)"
    matches = difflib.get_close_matches(name, candidates, n=n, cutoff=cutoff)
    if matches:
        return ", ".join(f"'{m}'" for m in matches)
    return ", ".join(f"'{c}'" for c in sorted(list(candidates)[:10]))


def _norm(s: str) -> str:
    """Lowercase, strip spaces/underscores/hyphens for fuzzy comparison."""
    return s.lower().replace(" ", "").replace("_", "").replace("-", "")


# ---------------------------------------------------------------------------
# Main validator class
# ---------------------------------------------------------------------------
class PowerBISchemaValidator:
    """Stateless validator that operates purely on the schema dict + data_dir."""

    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = Path(data_dir) if data_dir else None

    # ── public entry point ────────────────────────────────────────────────
    def validate_and_fix(self, schema: Dict[str, Any]) -> ValidationResult:
        """Run all validation and auto-fix passes on *schema* (mutated in-place).

        Order matters:
        0. Pre-check: detect duplicate/nonsensical table names and fix them
        1. Normalize tables (fill defaults, auto-detect columns from files)
        2. Reconcile column names with actual file headers
        3. Fuzzy-fix visual field references
        4. Auto-inject missing calculated columns
        5. Validate & fix measures (name conflicts, DAX syntax, missing measures)
        6. Final strict validation (anything left is a hard error for the LLM)
        """
        result = ValidationResult(schema)
        semantic_model = schema.get("semantic_model", {})
        tables = semantic_model.get("tables", [])

        # 0. Pre-check: detect and fix duplicate/nonsensical table names
        self._fix_bad_table_names(schema, result)
        # Re-read tables in case they were modified
        tables = semantic_model.get("tables", [])

        # 1. Normalize
        for table in tables:
            self._normalize_table_schema(table)

        # 2. Reconcile with actual file headers
        for table in tables:
            self._reconcile_with_file_headers(schema, table, result)

        # 2.5 Fix DAX column/table references that use underscore instead of space
        #     (handles the case where columns[] are correct but DAX exprs use underscore variants)
        self._fix_dax_column_refs(schema, result)

        # 2.7 Detect inline aggregation expressions used as measure field names in visuals
        #     e.g. "measure": "COUNT(Table[Col])" or "Sum of Column" — these are invalid.
        #     Report them as errors so the LLM defines proper named measures in the semantic model.
        self._detect_inline_agg_measures(schema, result)

        # 3. Fuzzy-match visual field references
        corrections = self._fuzzy_match_visual_fields(schema)
        if corrections:
            self._apply_field_corrections(schema, corrections)
            total = sum(len(v) for v in corrections.values())
            result.auto_fixes.append(f"Fuzzy-corrected {total} visual field reference(s)")

        # 4. Detect visual field references that don't exist in the semantic model
        self._detect_missing_visual_fields(schema, result)

        # 5. Validate & fix measures
        self._validate_and_fix_measures(schema, result)

        # 5.3 Detect calculated columns referenced by measures but not defined
        self._detect_missing_measure_column_refs(schema, result)

        # 5.4 Detect cross-table column references missing RELATED() in calculated columns
        self._detect_calc_column_cross_table_refs(schema, result)

        # 5.41 Detect measures with iterator functions (SUMX, AVERAGEX, etc.)
        #      referencing columns from other tables without RELATED()
        self._detect_measure_cross_table_refs(schema, result)

        # 5.42 Detect measures placed in the wrong table (lookup table instead of fact table)
        self._detect_misplaced_measures(schema, result)

        # 5.45 Remap visual "measure" bindings whose name matches a calculated column (not a measure).
        #      E.g. {"measure": "Delivery Lead Time (Days)"} when that field is a calc column
        #      must become {"column": "Delivery Lead Time (Days)"}.
        self._remap_measure_bindings_to_calc_cols(schema, result)

        # 5.46 Detect broken visual axis bindings and report as errors:
        #   (a) Non-numeric column used as Values/Y in a chart
        #   (b) Same column on both Category and Y axes
        self._detect_chart_axis_issues(schema, result)

        # 5.5 Validate relationships (check for missing tables/columns)
        semantic_model = schema.get("semantic_model", {})
        relationships = semantic_model.get("relationships", [])
        table_names_set = {t.get("name", "") for t in semantic_model.get("tables", [])}
        col_index_for_rels: Dict[str, Set[str]] = {}
        for t in semantic_model.get("tables", []):
            tname = t.get("name", "")
            cols = {c.get("name", "") for c in t.get("columns", [])}
            cols |= {cc.get("name", "") for cc in t.get("calculated_columns", [])}
            col_index_for_rels[tname] = cols

        valid_relationships = []
        for rel in relationships:
            from_table = rel.get("fromTable")
            from_column = rel.get("fromColumn")
            to_table = rel.get("toTable")
            to_column = rel.get("toColumn")

            if not from_table or not from_column or not to_table or not to_column:
                result.warnings.append(
                    f"Relationship missing required fields (fromTable/fromColumn/toTable/toColumn): {rel}"
                )
                continue

            missing = []
            if from_table not in table_names_set:
                missing.append(f"fromTable '{from_table}' does not exist")
            elif from_column not in col_index_for_rels.get(from_table, set()):
                missing.append(f"fromColumn '{from_column}' not found in table '{from_table}'")
            if to_table not in table_names_set:
                missing.append(f"toTable '{to_table}' does not exist")
            elif to_column not in col_index_for_rels.get(to_table, set()):
                missing.append(f"toColumn '{to_column}' not found in table '{to_table}'")

            if missing:
                result.errors.append(
                    f"Invalid relationship {from_table}[{from_column}] → {to_table}[{to_column}]: "
                    + "; ".join(missing) + ". "
                    f"Available tables: {sorted(table_names_set)}."
                )
            else:
                valid_relationships.append(rel)

        semantic_model["relationships"] = valid_relationships

        # 5.6. Structural integrity checks (source files, empty tables, report)
        self._validate_structural_integrity(schema, result)

        # 5.7. DAX sanity checks (circular refs, EARLIER in measures, duplicate names)
        self._validate_dax_sanity(schema, result)

        # 5.8. Visual completeness checks (missing Category axis, invalid types, table refs)
        self._validate_visual_completeness(schema, result)

        # 6. Final strict field validation
        hard_errors = self._validate_all_field_refs(schema)
        result.errors.extend(hard_errors)

        return result

    # ── 0. Fix bad table names (duplicate or nonsensical) ─────────────────
    def _fix_bad_table_names(self, schema: Dict[str, Any], result: ValidationResult):
        """Detect and fix duplicate or nonsensical table names.

        Common LLM mistake: using a metadata label like "data_profile" for all
        tables instead of deriving proper names from source files.

        Handles all file configurations:
        - CSV files: one file = one table, name derived from filename stem
        - Excel with one sheet: name derived from filename stem
        - Excel with multiple sheets: name derived from sheet_name to differentiate

        Strategy:
        - If multiple tables share the same name, rename each based on its source.
        - If a single table has a name that is a known metadata/partition label,
          rename it based on its source.
        - Update all DAX expressions and visual bindings that reference the old name.
        """
        sem = schema.get("semantic_model", {})
        tables = sem.get("tables", [])
        if not tables:
            return

        # Known metadata/partition labels that LLMs confuse for table names
        METADATA_LABELS = {
            "data_profile", "metadata_context", "fallback_context", "partition",
            "sheet_schema", "table_schema", "table_profile", "data_context",
            "schema", "profile", "context", "content",
        }

        # Detect duplicates
        name_counts: Dict[str, int] = {}
        for t in tables:
            n = t.get("name", "")
            name_counts[n] = name_counts.get(n, 0) + 1

        has_duplicates = any(c > 1 for c in name_counts.values())

        # Detect metadata labels used as table names (also match partition-like patterns)
        def _is_metadata_name(name: str) -> bool:
            n = name.lower().strip()
            if n in METADATA_LABELS:
                return True
            # Partition-style patterns like "sheet_Sheet1_table_0_schema"
            if n.startswith("sheet_") and ("_table_" in n or "_schema" in n or "_profile" in n):
                return True
            return False

        has_metadata_names = any(_is_metadata_name(t.get("name", "")) for t in tables)

        if not has_duplicates and not has_metadata_names:
            return

        # Build rename map: (old_name, new_name) per table index
        renames: List[Tuple[str, str]] = []

        # Count how many tables share each source file path (for multi-sheet detection)
        source_path_counts: Dict[str, int] = {}
        for t in tables:
            src = t.get("source", {})
            sp = src.get("path", "") if isinstance(src, dict) else ""
            if sp:
                source_path_counts[sp] = source_path_counts.get(sp, 0) + 1

        for t in tables:
            old_name = t.get("name", "")
            source_obj = t.get("source", {})
            source_path = source_obj.get("path", "") if isinstance(source_obj, dict) else ""
            sheet_name = source_obj.get("sheet_name", "") if isinstance(source_obj, dict) else ""

            needs_rename = (
                name_counts.get(old_name, 0) > 1
                or _is_metadata_name(old_name)
            )

            if needs_rename and source_path:
                file_stem = Path(source_path).stem
                # If multiple tables share the same source file (multi-sheet Excel),
                # use sheet_name to differentiate
                if source_path_counts.get(source_path, 1) > 1 and sheet_name:
                    new_name = sheet_name.replace(" ", "_")
                else:
                    new_name = file_stem.replace(" ", "_")
                renames.append((old_name, new_name))
            else:
                renames.append((old_name, old_name))  # no change

        # Ensure uniqueness of new names
        seen_new: Dict[str, int] = {}
        for i, (old, new) in enumerate(renames):
            if new in seen_new:
                seen_new[new] += 1
                renames[i] = (old, f"{new}_{seen_new[new]}")
            else:
                seen_new[new] = 1

        # Apply renames
        any_renamed = False
        for i, (old_name, new_name) in enumerate(renames):
            if old_name == new_name:
                continue
            any_renamed = True
            table = tables[i]
            table["name"] = new_name

            # Update DAX expressions in ALL tables' measures and calculated columns
            for t in tables:
                for obj in t.get("measures", []) + t.get("calculated_columns", []):
                    expr = obj.get("expression", "")
                    if not expr:
                        continue
                    # Replace 'old_name'[col] and old_name[col] patterns
                    updated = re.sub(
                        rf"'{re.escape(old_name)}'\[",
                        f"'{new_name}'[",
                        expr, flags=re.IGNORECASE,
                    )
                    updated = re.sub(
                        rf"(?<!')\b{re.escape(old_name)}\[",
                        f"'{new_name}'[" if " " in new_name else f"{new_name}[",
                        updated, flags=re.IGNORECASE,
                    )
                    # Also replace COUNTROWS(old_name) and COUNTROWS('old_name')
                    updated = re.sub(
                        rf"COUNTROWS\s*\(\s*'{re.escape(old_name)}'\s*\)",
                        f"COUNTROWS('{new_name}')" if " " in new_name else f"COUNTROWS({new_name})",
                        updated, flags=re.IGNORECASE,
                    )
                    updated = re.sub(
                        rf"COUNTROWS\s*\(\s*{re.escape(old_name)}\s*\)",
                        f"COUNTROWS('{new_name}')" if " " in new_name else f"COUNTROWS({new_name})",
                        updated, flags=re.IGNORECASE,
                    )
                    if updated != expr:
                        obj["expression"] = updated

            # Update visual bindings
            for page in schema.get("report", {}).get("pages", []):
                for visual in page.get("visuals", []):
                    for _role, fd_or_list in visual.get("data", {}).items():
                        items = fd_or_list if isinstance(fd_or_list, list) else [fd_or_list]
                        for fd in items:
                            if isinstance(fd, dict) and fd.get("table", "").lower() == old_name.lower():
                                fd["table"] = new_name

            result.auto_fixes.append(
                f"Renamed table '{old_name}' → '{new_name}' (derived from source file)"
            )

        if any_renamed:
            # Build a summary for the LLM so it knows the correct table names
            actual_tables = [t.get("name") for t in tables]
            actual_sources = []
            for t in tables:
                src = t.get("source", {})
                p = src.get("path", "") if isinstance(src, dict) else ""
                actual_sources.append(f"{t.get('name')} ← {p}")
            result.errors.append(
                f"Table names were invalid (duplicate or metadata labels). "
                f"They have been auto-renamed but the schema likely has other issues. "
                f"Please rebuild your payload using these table names derived from source files: "
                f"{', '.join(actual_sources)}. "
                f"Each CSV file becomes its own table. The 'data_profile' or 'Partition' labels "
                f"in the context are NOT table names — they are metadata partition identifiers."
            )

    # ── 1. Normalize table schema ─────────────────────────────────────────
    def _normalize_table_schema(self, table: Dict[str, Any]):
        source_obj = table.get("source", {})
        source_path = source_obj.get("path", "") if isinstance(source_obj, dict) else table.get("source_file", "")

        # ── Resolve actual filename on disk (handles underscore↔space mismatches) ──
        # AGENT-9 may write "My_File_1.csv" but the uploaded file is "My File 1.csv".
        # _resolve_file does a normalized fuzzy match; if it finds a different actual
        # file, update the schema path so the M code references the correct filename.
        if source_path:
            actual = self._resolve_file(source_path)
            if actual and actual.name != Path(source_path).name:
                logger.info(
                    f"Source path corrected: '{Path(source_path).name}' → '{actual.name}'"
                )
                if isinstance(source_obj, dict):
                    source_obj["path"] = actual.name
                else:
                    table["source_file"] = actual.name
                source_path = actual.name

        if not table.get("name") and source_path:
            table["name"] = Path(source_path).stem

        if isinstance(source_obj, dict) and not source_obj.get("type") and source_path:
            ext_map = {".csv": "csv", ".xlsx": "excel", ".xls": "excel", ".json": "json"}
            ext = Path(source_path).suffix.lower()
            if ext in ext_map:
                source_obj["type"] = ext_map[ext]

        if not table.get("columns") and source_path:
            detected = self._auto_detect_columns(source_path, table.get("name", "?"))
            if detected:
                table["columns"] = detected

        table.setdefault("calculated_columns", [])
        table.setdefault("measures", [])

    def _auto_detect_columns(self, source_path: str, table_name: str) -> List[Dict[str, str]]:
        p = self._resolve_file(source_path)
        if not p:
            return []
        try:
            ext = p.suffix.lower()
            if ext == ".csv":
                df = pd.read_csv(p, nrows=50, encoding="utf-8-sig")
            elif ext in (".xlsx", ".xls"):
                df = pd.read_excel(p, nrows=50)
            else:
                return []

            dtype_map = {"bool": "boolean", "int": "int64", "float": "double", "datetime": "date"}
            columns = []
            for col in df.columns:
                pd_dtype = str(df[col].dtype)
                pbi_type = "string"
                for key, val in dtype_map.items():
                    if key in pd_dtype:
                        pbi_type = val
                        break
                columns.append({"name": str(col).strip(), "dataType": pbi_type})
            logger.info(f"Auto-detected {len(columns)} columns from {p.name} for '{table_name}'")
            return columns
        except Exception as e:
            logger.warning(f"Column auto-detect failed for {source_path}: {e}")
            return []

    # ── 2. Reconcile with CSV/Excel headers ───────────────────────────────
    def _reconcile_with_file_headers(self, schema: Dict[str, Any], table: Dict[str, Any], result: ValidationResult):
        source_obj = table.get("source", {})
        source_path = source_obj.get("path") if isinstance(source_obj, dict) else table.get("source_file")
        if not source_path:
            return

        ext = str(source_path).rsplit(".", 1)[-1].lower()
        if ext not in ("csv", "xlsx", "xls"):
            return

        headers = self._read_file_headers(source_path)
        if not headers:
            return

        reconciled, rename_map = self._reconcile_columns(
            table.get("columns", []), headers, table.get("name", "")
        )
        table["columns"] = reconciled

        if rename_map:
            self._apply_column_renames(schema, table.get("name", ""), rename_map)
            result.auto_fixes.append(
                f"Reconciled {len(rename_map)} column name(s) for table '{table.get('name', '')}'"
            )

    def _read_file_headers(self, file_path: str) -> List[str]:
        p = self._resolve_file(file_path)
        if not p:
            return []
        try:
            ext = p.suffix.lower()
            if ext == ".csv":
                with open(p, "r", encoding="utf-8-sig", errors="replace") as f:
                    reader = csv.reader(f)
                    row = next(reader, None)
                return [str(h) for h in row if h is not None] if row else []
            elif ext in (".xlsx", ".xls"):
                df = pd.read_excel(p, nrows=0)
                return [str(c) for c in df.columns.tolist()]
        except Exception as e:
            logger.warning(f"Failed to read headers from {file_path}: {e}")
        return []

    def _reconcile_columns(
        self, schema_columns: List[Dict], actual_headers: List[str], table_name: str
    ) -> Tuple[List[Dict], Dict[str, str]]:
        if not actual_headers:
            return schema_columns, {}

        headers_lower = {h.lower().replace(" ", "").replace("_", ""): h for h in actual_headers}
        headers_exact_lower = {h.lower(): h for h in actual_headers}

        rename_map: Dict[str, str] = {}
        reconciled = []
        used = set()

        for col in schema_columns:
            name = col["name"]
            # exact
            if name in actual_headers:
                reconciled.append(col)
                used.add(name)
                continue
            # case-insensitive
            if name.lower() in headers_exact_lower:
                actual = headers_exact_lower[name.lower()]
                rename_map[name] = actual
                new_col = dict(col)
                new_col["name"] = actual
                reconciled.append(new_col)
                used.add(actual)
                continue
            # normalized
            norm = name.lower().replace(" ", "").replace("_", "")
            if norm in headers_lower:
                actual = headers_lower[norm]
                if actual not in used:
                    rename_map[name] = actual
                    new_col = dict(col)
                    new_col["name"] = actual
                    reconciled.append(new_col)
                    used.add(actual)
                    continue
            # no match — keep (may be a formula column)
            reconciled.append(col)

        # add headers that schema missed entirely
        for h in actual_headers:
            if h not in used and not any(c["name"] == h for c in reconciled):
                reconciled.append({"name": h, "dataType": "string"})

        if rename_map:
            logger.info(
                f"Reconciled {len(rename_map)} column(s) for '{table_name}': "
                + ", ".join(f"'{k}'->'{v}'" for k, v in rename_map.items())
            )
        return reconciled, rename_map

    def _apply_column_renames(self, schema: Dict[str, Any], table_name: str, rename_map: Dict[str, str]):
        if not rename_map:
            return
        # DAX in measures
        for table in schema.get("semantic_model", {}).get("tables", []):
            for measure in table.get("measures", []):
                expr = measure.get("expression", "")
                updated = expr
                for old, new in rename_map.items():
                    updated = re.sub(
                        rf"({re.escape(table_name)})\[{re.escape(old)}\]",
                        rf"\1[{new}]", updated, flags=re.IGNORECASE,
                    )
                    updated = re.sub(
                        rf"\[{re.escape(old)}\]",
                        f"[{new}]", updated, flags=re.IGNORECASE,
                    )
                if updated != expr:
                    measure["expression"] = updated

        # visual bindings
        for page in schema.get("report", {}).get("pages", []):
            for visual in page.get("visuals", []):
                for _role, field_def_or_list in visual.get("data", {}).items():
                    items = field_def_or_list if isinstance(field_def_or_list, list) else [field_def_or_list]
                    for fd in items:
                        if isinstance(fd, dict) and fd.get("table") == table_name:
                            col = fd.get("column", "")
                            if col in rename_map:
                                fd["column"] = rename_map[col]

        # relationship columns
        for rel in schema.get("semantic_model", {}).get("relationships", []):
            for side in ("fromColumn", "toColumn"):
                col = rel.get(side, "")
                if col in rename_map:
                    tbl_key = "fromTable" if side == "fromColumn" else "toTable"
                    if rel.get(tbl_key) == table_name:
                        rel[side] = rename_map[col]

    # ── 2.7. Detect inline aggregation expressions in visual bindings ────
    def _detect_inline_agg_measures(self, schema: Dict[str, Any], result: ValidationResult):
        """Detect visual field bindings where "measure" is an aggregation expression
        like ``"COUNT(Table[Col])"`` or a plain-English name like ``"Sum of Sales"``
        rather than a proper named measure defined in the semantic model.

        These are invalid in Power BI — the measure must be defined in the
        semantic model first.  This method reports them as errors so the LLM
        can fix its schema by defining proper named measures.
        """
        # Regex: matches AGG(Table[Col]) or AGG('Table'[Col]) or AGG(Table)
        inline_agg_re = re.compile(
            r"^(COUNTROWS|COUNT|COUNTA|COUNTBLANK|DISTINCTCOUNT|SUM|SUMX|AVG|AVERAGE|MIN|MAX)"
            r"\s*\(\s*(?:'([^']+)'|([A-Za-z0-9 _]+))\s*(?:\[([^\]]+)\])?\s*\)$",
            re.IGNORECASE,
        )

        # Regex: matches plain-English implicit aggregation names
        # e.g. "Count of Article Id", "Average of Net Price", "Sum of Units".
        plain_agg_re = re.compile(
            r"^(Count|Distinct Count|DistinctCount|Sum|Average|Avg|Min|Max)\s+of\s+(.+)$",
            re.IGNORECASE,
        )

        invalid_bindings = []

        for page in schema.get("report", {}).get("pages", []):
            for visual in page.get("visuals", []):
                data = visual.get("data", {})
                vtitle = visual.get("title", visual.get("type", "unnamed"))
                for role, fd_or_list in list(data.items()):
                    items = fd_or_list if isinstance(fd_or_list, list) else [fd_or_list]
                    for fd in items:
                        if not isinstance(fd, dict):
                            continue
                        raw_measure = fd.get("measure", "")
                        if not raw_measure:
                            continue
                        if inline_agg_re.match(raw_measure.strip()):
                            invalid_bindings.append(
                                f"Visual '{vtitle}' role '{role}': "
                                f"measure binding '{raw_measure}' is an inline DAX expression, "
                                f"not a named measure"
                            )
                        elif plain_agg_re.match(raw_measure.strip()):
                            invalid_bindings.append(
                                f"Visual '{vtitle}' role '{role}': "
                                f"measure binding '{raw_measure}' is a plain-English aggregation name, "
                                f"not a named measure"
                            )

        if invalid_bindings:
            result.errors.append(
                "Visual bindings contain inline aggregation expressions or plain-English "
                "aggregation names instead of properly defined measures. "
                "Define each as a named measure in the semantic model's table measures[] array, "
                "then reference the measure name in the visual binding. "
                "Invalid bindings: " + "; ".join(invalid_bindings[:5])
                + (f" ... and {len(invalid_bindings) - 5} more" if len(invalid_bindings) > 5 else "")
            )

    # ── 2.5. Fix DAX column/table name references ────────────────────────
    def _fix_dax_column_refs(self, schema: Dict[str, Any], result: ValidationResult):
        """Fix DAX expressions where column/table names use underscore variants
        of names that have spaces (e.g. LLM writes Sales_Data[Order_Qty]
        but the actual column in the model is 'Order Qty').

        This runs AFTER _reconcile_with_file_headers so columns[] already
        reflect real CSV headers.  The fix covers:
        - Qualified references:  TableName[Col_With_Underscore]
        - Quoted references:     'Table Name'[Col_With_Underscore]
        - Cross-table references inside any measure/calculated column
        """
        def _norm(s: str) -> str:
            return s.lower().replace(" ", "").replace("_", "").replace("-", "")

        sem = schema.get("semantic_model", {})
        tables = sem.get("tables", [])

        # Build lookups from reconciled columns
        table_name_lookup: Dict[str, str] = {}   # norm(table) -> actual_table
        table_col_lookup: Dict[str, Dict[str, str]] = {}  # actual_table -> {norm(col) -> actual_col}

        for table in tables:
            t_name = table.get("name", "")
            if not t_name:
                continue
            table_name_lookup[_norm(t_name)] = t_name
            col_map: Dict[str, str] = {}
            for col in table.get("columns", []):
                cn = col.get("name", "")
                if cn:
                    col_map[_norm(cn)] = cn
            table_col_lookup[t_name] = col_map

        fixes_applied = 0

        def _resolve_ref(raw_table: str, raw_col: str) -> str:
            """Return a corrected DAX Table[Col] reference string, or empty string if nothing changed."""
            nonlocal fixes_applied

            # Resolve table name
            actual_table = raw_table
            norm_t = _norm(raw_table)
            if norm_t in table_name_lookup:
                actual_table = table_name_lookup[norm_t]

            # Resolve column name within actual table
            actual_col = raw_col
            col_map = table_col_lookup.get(actual_table, {})
            norm_c = _norm(raw_col)
            if norm_c in col_map:
                candidate = col_map[norm_c]
                if candidate != raw_col:
                    actual_col = candidate

            if actual_table == raw_table and actual_col == raw_col:
                return ""  # nothing changed

            fixes_applied += 1
            if " " in actual_table:
                return f"'{actual_table}'[{actual_col}]"
            return f"{actual_table}[{actual_col}]"

        def _fix_expr(expr: str) -> str:
            if not expr:
                return expr

            def _sub(m: "re.Match") -> str:
                if m.group(1) is not None:    # 'Quoted Table'[Col]
                    raw_table, raw_col = m.group(1), m.group(2)
                else:                          # BareTable[Col]
                    raw_table, raw_col = m.group(3), m.group(4)
                fixed = _resolve_ref(raw_table, raw_col)
                return fixed if fixed else m.group(0)

            # Pattern: 'Table Name'[Col] | BareWord[Col]
            return re.sub(
                r"'([^']+)'\[([^\]]+)\]|(\w+)\[([^\]]+)\]",
                _sub,
                expr,
            )

        # Apply to every measure and calculated column across all tables
        for table in tables:
            for obj in table.get("measures", []) + table.get("calculated_columns", []):
                original = obj.get("expression", "")
                fixed = _fix_expr(original)
                if fixed != original:
                    obj["expression"] = fixed

        if fixes_applied > 0:
            result.auto_fixes.append(
                f"Fixed {fixes_applied} DAX column reference(s) "
                "with underscore/space normalization"
            )

    # ── 3. Fuzzy-match visual field references ────────────────────────────
    def _fuzzy_match_visual_fields(self, schema: Dict[str, Any]) -> Dict[str, Dict[str, str]]:
        corrections: Dict[str, Dict[str, str]] = {}

        available = self._build_field_index(schema)
        report = schema.get("report", {})

        # Only collect COLUMN-type bindings for fuzzy matching.
        # MEASURE-type bindings must never be remapped to column names — they are
        # handled by the 5c placeholder-injector.  Fuzzy-correcting a measure ref
        # like "On-Time Delivery %" to a column like "Requested Delivery Date" is
        # always wrong.
        referenced_columns: Dict[str, Set[str]] = {}  # table -> {column_name, ...}

        for page in report.get("pages", []):
            for visual in page.get("visuals", []):
                data = visual.get("data", {})
                for role, fd_or_list in data.items():
                    items = fd_or_list if isinstance(fd_or_list, list) else [fd_or_list]
                    for fd in items:
                        if not isinstance(fd, dict):
                            continue
                        col = fd.get("column", "")
                        tbl = fd.get("table", "")
                        if col and tbl and tbl in available:
                            referenced_columns.setdefault(tbl, set()).add(col)

        # Fields whose names start with an aggregation keyword are intentional measure names
        # (e.g. "COUNT of PO_NUMBER", "Total Revenue", "SUM of Amount").  Fuzzy-matching them
        # to raw column names corrupts the binding — let the step-5c auto-injector handle them.
        _agg_prefix_re = re.compile(
            r"^(count|sum|avg|average|min|max|total|distinct)\b", re.IGNORECASE
        )

        for tbl, refs in referenced_columns.items():
            if tbl not in available:
                continue
            actual = available[tbl]
            actual_lower = {f.lower(): f for f in actual}

            for ref in refs:
                if ref in actual:
                    continue
                if ref.lower() in actual_lower:
                    corrections.setdefault(tbl, {})[ref] = actual_lower[ref.lower()]
                    continue
                # Skip fuzzy matching for aggregation-style measure names to prevent
                # weak matches like "COUNT of PO_NUMBER" → "PO_NUMBER".
                if _agg_prefix_re.match(ref):
                    continue
                # Use a high cutoff (0.75) to avoid spurious matches between
                # unrelated column names.
                matches = difflib.get_close_matches(ref.lower(), list(actual_lower.keys()), n=1, cutoff=0.75)
                if matches:
                    corrections.setdefault(tbl, {})[ref] = actual_lower[matches[0]]

        return corrections

    def _apply_field_corrections(self, schema: Dict[str, Any], corrections: Dict[str, Dict[str, str]]):
        if not corrections:
            return
        report = schema.get("report", {})
        sem = schema.get("semantic_model", {})

        # visual data bindings
        for page in report.get("pages", []):
            for visual in page.get("visuals", []):
                data = visual.get("data", {})
                for role, fd in list(data.items()):
                    if not fd:
                        continue
                    if isinstance(fd, str):
                        if "[" in fd and "]" in fd:
                            tbl = fd.split("[")[0].strip()
                            fld = fd.split("[")[1].rstrip("]").strip()
                            if tbl in corrections and fld in corrections[tbl]:
                                data[role] = f"{tbl}[{corrections[tbl][fld]}]"
                        else:
                            for tbl, fm in corrections.items():
                                if fd.strip() in fm:
                                    data[role] = f"{tbl}[{fm[fd.strip()]}]"
                                    break
                    elif isinstance(fd, dict):
                        tbl = fd.get("table", "")
                        for key in ("field", "column", "measure"):
                            fld = fd.get(key, "")
                            if tbl in corrections and fld in corrections[tbl]:
                                fd[key] = corrections[tbl][fld]
                    elif isinstance(fd, list):
                        for item in fd:
                            if isinstance(item, dict):
                                tbl = item.get("table", "")
                                for key in ("field", "column", "measure"):
                                    fld = item.get(key, "")
                                    if tbl in corrections and fld in corrections[tbl]:
                                        item[key] = corrections[tbl][fld]

        # DAX expressions
        for table in sem.get("tables", []):
            tbl_name = table.get("name", "")
            if tbl_name not in corrections:
                continue
            fm = corrections[tbl_name]
            for obj in table.get("measures", []) + table.get("calculated_columns", []):
                expr = obj.get("expression", "")
                if not expr:
                    continue
                for old, new in fm.items():
                    expr = expr.replace(f"[{old}]", f"[{new}]")
                obj["expression"] = expr

    # ── 4. Auto-inject missing calculated columns ─────────────────────────
    def _detect_missing_visual_fields(self, schema: Dict[str, Any], result: ValidationResult):
        """Detect visual field references (columns/measures) that don't exist in the
        semantic model and report them as errors so the LLM can add them explicitly."""
        defined = self._build_field_index(schema)
        report = schema.get("report", {})

        for page in report.get("pages", []):
            page_name = page.get("name", "?")
            for visual in page.get("visuals", []):
                title = visual.get("title", visual.get("type", "?"))
                for tbl, fld in _extract_field_refs(visual.get("data", {})):
                    if not tbl:
                        continue
                    if fld not in defined.get(tbl, set()):
                        result.errors.append(
                            f"Visual '{title}' on page '{page_name}' references "
                            f"'{tbl}[{fld}]' which does not exist in the semantic model. "
                            f"Available fields in '{tbl}': {sorted(defined.get(tbl, set())) or '(none)'}. "
                            f"Define this field as a column, calculated column, or measure in table '{tbl}'."
                        )

    def _generate_dax_for_field(
        self, field_name: str, table_obj: Dict[str, Any], bin_map: Optional[Dict[str, int]] = None
    ) -> Optional[str]:
        fl = field_name.lower()
        tbl = table_obj.get("name", "")
        cols = {c["name"]: c for c in table_obj.get("columns", [])}
        # ✅ ADD: Lead time / duration calculations must use DATEDIFF
        # Any duration / days-between pattern: lead time, transit time, days to X, etc.
        duration_kws = ("lead time", "delivery time", "transit time", "days to", "time to",
                        "days in", "shipping time", "fulfillment time", "cycle time")
        if any(kw in fl for kw in duration_kws):
            date_cols = [c for c in cols if "date" in c.lower() or "time" in c.lower()]
            if len(date_cols) >= 2:
                # DATEDIFF(start, end, DAY) — use first two date cols found
                return f"DATEDIFF([{date_cols[0]}], [{date_cols[1]}], DAY)"
        

        if "(bin)" in fl:
            base = field_name.replace("(bin)", "").replace("(Bin)", "").strip()
            if base in cols:
                bs = (bin_map or {}).get(field_name) or 5
                if "salary" in base.lower():
                    bs = 10000
                return f"INT([{base}]/{bs})*{bs}"

        if "first letter" in fl:
            name_cols = [c for c in cols if any(k in c.lower() for k in ("name", "title", "employee"))]
            if name_cols:
                return f"LEFT([{name_cols[0]}], 1)"

        if "last letter" in fl:
            name_cols = [c for c in cols if any(k in c.lower() for k in ("name", "title", "employee"))]
            if name_cols:
                return f"RIGHT([{name_cols[0]}], 1)"

        if "count of" in fl or fl.startswith("count "):
            return f"COUNTROWS({tbl})"

        if "total" in fl or "sum of" in fl:
            for cn in cols:
                if cn.lower() in fl:
                    return f"SUM([{cn}])"

        if "average" in fl or "avg" in fl:
            for cn in cols:
                if cn.lower() in fl:
                    return f"AVERAGE([{cn}])"

        if "more than" in fl or "greater than" in fl:
            nums = re.findall(r"\d+", field_name)
            num_cols = [c for c in cols if any(k in c.lower() for k in ("balance", "days", "amount", "count"))]
            if nums and num_cols:
                return f"IF([{num_cols[0]}] > {nums[0]}, 1, 0)"

        date_kws = {"year": "YEAR", "month": "MONTH", "day": "DAY", "quarter": "QUARTER"}
        for kw, fn in date_kws.items():
            if kw in fl:
                date_cols = [c for c in cols if any(k in c.lower() for k in ("date", "time"))]
                if date_cols:
                    return f"{fn}([{date_cols[0]}])"

        return None

    # ── 4.5. Auto-inject calculated columns referenced by measures ────────
    def _detect_missing_measure_column_refs(self, schema: Dict[str, Any], result: ValidationResult):
        """Detect measures that reference columns which don't exist in the semantic model.
        Reports errors so the LLM can define the missing columns explicitly."""
        sem = schema.get("semantic_model", {})
        tables = sem.get("tables", [])

        # Build column+calc-col index per table
        col_index: Dict[str, Set[str]] = {}
        for tbl in tables:
            tname = tbl.get("name", "")
            names: Set[str] = set()
            for c in tbl.get("columns", []):
                names.add(c.get("name", ""))
            for cc in tbl.get("calculated_columns", []):
                names.add(cc.get("name", ""))
            col_index[tname] = names

        tables_dict = {t.get("name", ""): t for t in tables}
        ref_re = re.compile(r"(?:'([^']+)'|(\w+))?\[([^\]]+)\]")

        for tbl in tables:
            tname = tbl.get("name", "")
            for measure in tbl.get("measures", []):
                expr = measure.get("expression", "")
                if not expr:
                    continue

                for m in ref_re.finditer(expr):
                    ref_table = m.group(1) or m.group(2) or tname
                    ref_col = m.group(3)

                    # Resolve table name
                    actual_table = ref_table
                    for t in tables_dict:
                        if t.lower() == ref_table.lower():
                            actual_table = t
                            break

                    if actual_table not in col_index:
                        continue
                    if ref_col in col_index[actual_table]:
                        continue

                    # Also skip if it matches a measure name (measure-to-measure refs are valid)
                    measure_names = {
                        m2.get("name", "") for m2 in tables_dict.get(actual_table, {}).get("measures", [])
                    }
                    if ref_col in measure_names:
                        continue

                    result.errors.append(
                        f"Measure '{measure['name']}' in table '{tname}' references "
                        f"'{actual_table}[{ref_col}]' which does not exist. "
                        f"Available columns in '{actual_table}': {sorted(col_index.get(actual_table, set()))}. "
                        f"Define '{ref_col}' as a column or calculated column in table '{actual_table}'."
                    )

    # ── 5.4 Fix calculated column cross-table column references ──────────
    def _detect_calc_column_cross_table_refs(self, schema: Dict[str, Any], result: ValidationResult):
        """Detect calculated columns whose DAX references columns from another table
        without RELATED(). Reports errors so the LLM wraps them explicitly."""
        sem = schema.get("semantic_model", {})
        tables_list = sem.get("tables", [])

        def _norm(s: str) -> str:
            return s.lower().replace(" ", "").replace("_", "")

        col_lookup: Dict[str, Set[str]] = {}
        for t in tables_list:
            tname = t.get("name", "")
            cols = {c.get("name", "") for c in t.get("columns", [])}
            cols |= {cc.get("name", "") for cc in t.get("calculated_columns", [])}
            col_lookup[tname] = cols

        col_ref_re = re.compile(
            r"(?:'([^']+)'|([A-Za-z][A-Za-z0-9 _]*))\[([^\]]+)\]"
        )

        for table in tables_list:
            tname = table.get("name", "")
            for cc in table.get("calculated_columns", []):
                expr = cc.get("expression", "")
                if not expr:
                    continue

                for m in col_ref_re.finditer(expr):
                    ref_table = (m.group(1) or m.group(2) or "").strip()
                    ref_col = m.group(3).strip()

                    # Already wrapped in RELATED? Skip.
                    before = expr[max(0, m.start() - 8):m.start()]
                    if "RELATED" in before.upper():
                        continue

                    if ref_table and ref_table != tname:
                        # Explicit different-table ref without RELATED
                        actual_rt = next(
                            (t.get("name") for t in tables_list if _norm(t.get("name", "")) == _norm(ref_table)),
                            None
                        )
                        if not actual_rt:
                            continue
                        result.errors.append(
                            f"Calculated column '{cc['name']}' in table '{tname}' references "
                            f"'{ref_table}[{ref_col}]' from a different table without RELATED(). "
                            f"Wrap it as RELATED({ref_table}[{ref_col}])."
                        )

                    elif ref_table == tname or not ref_table:
                        # Same-table ref but column doesn't exist here
                        if ref_col in col_lookup.get(tname, set()):
                            continue
                        if _norm(ref_col) in {_norm(c) for c in col_lookup.get(tname, set())}:
                            continue

                        # Column missing from this table — check if it exists elsewhere
                        other_tables = [
                            t.get("name", "") for t in tables_list
                            if t.get("name", "") != tname
                            and any(_norm(c.get("name", "")) == _norm(ref_col) for c in t.get("columns", []) + t.get("calculated_columns", []))
                        ]
                        if other_tables:
                            result.errors.append(
                                f"Calculated column '{cc['name']}' in table '{tname}' references "
                                f"[{ref_col}] which does not exist in '{tname}' but exists in "
                                f"table(s) {other_tables}. Use RELATED({other_tables[0]}[{ref_col}])."
                            )
                        else:
                            result.errors.append(
                                f"Calculated column '{cc['name']}' in table '{tname}' references "
                                f"[{ref_col}] which does not exist in any table. "
                                f"Available columns in '{tname}': {sorted(col_lookup.get(tname, set()))}."
                            )

    # ── 5.41 Detect cross-table refs in measure iterator bodies ─────────
    def _detect_measure_cross_table_refs(self, schema: Dict[str, Any], result: ValidationResult):
        """Detect measures that use iterator functions (SUMX, AVERAGEX, etc.) and
        reference columns from a different table without RELATED().
        Reports errors so the LLM can fix the DAX explicitly."""
        sem = schema.get("semantic_model", {})
        tables_list = sem.get("tables", [])

        table_names = {t.get("name", "") for t in tables_list}
        table_names.discard("")

        col_index: Dict[str, Set[str]] = {}
        for t in tables_list:
            tname = t.get("name", "")
            cols = {c.get("name", "") for c in t.get("columns", [])}
            cols |= {cc.get("name", "") for cc in t.get("calculated_columns", [])}
            cols.discard("")
            col_index[tname] = cols

        iterator_re = re.compile(
            r"\b(SUMX|AVERAGEX|COUNTX|MAXX|MINX|RANKX|FILTER|ADDCOLUMNS)\s*\(\s*"
            r"(?:'([^']+)'|([A-Za-z][A-Za-z0-9_ ]*))\s*,",
            re.IGNORECASE,
        )

        col_ref_re = re.compile(
            r"(?:'([^']+)'|([A-Za-z][A-Za-z0-9 _]*))\[([^\]]+)\]"
        )

        for table in tables_list:
            tname = table.get("name", "")
            for measure in table.get("measures", []):
                expr = measure.get("expression", "")
                if not expr:
                    continue

                iterated_tables: Set[str] = set()
                for im in iterator_re.finditer(expr):
                    iter_tbl = (im.group(2) or im.group(3) or "").strip()
                    actual = next((t for t in table_names if t.lower() == iter_tbl.lower()), None)
                    if actual:
                        iterated_tables.add(actual)

                if not iterated_tables:
                    continue

                for m in col_ref_re.finditer(expr):
                    ref_table = (m.group(1) or m.group(2) or "").strip()
                    ref_col = m.group(3).strip()

                    before = expr[max(0, m.start() - 8):m.start()]
                    if "RELATED" in before.upper():
                        continue

                    actual_ref = next((t for t in table_names if t.lower() == ref_table.lower()), None)
                    if not actual_ref:
                        continue

                    if actual_ref in iterated_tables:
                        continue

                    result.errors.append(
                        f"Measure '{measure.get('name', '?')}' in table '{tname}' uses "
                        f"iterator over {sorted(iterated_tables)} but references "
                        f"'{ref_table}[{ref_col}]' without RELATED(). "
                        f"Wrap it as RELATED({ref_table}[{ref_col}])."
                    )

    # ── 5.42 Detect measures placed in the wrong table ─────────────────
    def _detect_misplaced_measures(self, schema: Dict[str, Any], result: ValidationResult):
        """Detect measures that iterate over a different table than the one they are
        defined in. Reports errors so the LLM can move them to the correct table.

        E.g. measure 'Sales Amount' in Product table with DAX
          SUMX(Sales, Sales[Qty] * RELATED(Product[Price]))
        should be in the Sales table, not Product.
        """
        sem = schema.get("semantic_model", {})
        tables_list = sem.get("tables", [])

        table_names = {t.get("name", "") for t in tables_list}
        table_names.discard("")

        iterator_re = re.compile(
            r"\b(?:SUMX|AVERAGEX|COUNTX|MAXX|MINX|RANKX)\s*\(\s*"
            r"(?:'([^']+)'|([A-Za-z][A-Za-z0-9_ ]*))\s*,",
            re.IGNORECASE,
        )

        for table in tables_list:
            tname = table.get("name", "")
            for measure in table.get("measures", []):
                expr = measure.get("expression", "")
                if not expr:
                    continue

                iter_match = iterator_re.search(expr)
                if not iter_match:
                    continue

                iter_tbl = (iter_match.group(1) or iter_match.group(2) or "").strip()
                actual_iter = next((t for t in table_names if t.lower() == iter_tbl.lower()), None)

                if not actual_iter or actual_iter == tname:
                    continue

                result.errors.append(
                    f"Measure '{measure.get('name', '?')}' is defined in table '{tname}' "
                    f"but iterates over table '{actual_iter}'. Move this measure to the "
                    f"'{actual_iter}' table. Measures using SUMX/AVERAGEX/COUNTX etc. must "
                    f"be placed in the table they iterate over."
                )

    # ── 5.45 Remap visual measure bindings that are actually calc columns ─
    def _remap_measure_bindings_to_calc_cols(self, schema: Dict[str, Any], result: ValidationResult):
        """Visual bindings that use {"measure": "FieldName"} where FieldName is a
        calculated column (not a measure) must become {"column": "FieldName"}.
        Power BI rejects measure references that point to calc columns.
        """
        sem = schema.get("semantic_model", {})
        tables_list = sem.get("tables", [])

        # Build: table_name -> set of calculated column names (case-insensitive lookup)
        calc_col_names: Dict[str, Dict[str, str]] = {}  # table -> {lower_name -> actual_name}
        for t in tables_list:
            tname = t.get("name", "")
            calc_col_names[tname] = {
                cc.get("name", "").lower(): cc.get("name", "")
                for cc in t.get("calculated_columns", [])
            }

        fixes = 0
        for page in schema.get("report", {}).get("pages", []):
            for visual in page.get("visuals", []):
                data = visual.get("data", {})
                for role, fd_or_list in list(data.items()):
                    items = fd_or_list if isinstance(fd_or_list, list) else [fd_or_list]
                    for fd in items:
                        if not isinstance(fd, dict):
                            continue
                        meas_name = fd.get("measure", "")
                        tbl = fd.get("table", "")
                        if not meas_name or not tbl:
                            continue
                        # Check if this "measure" name is actually a calc column
                        cc_map = calc_col_names.get(tbl, {})
                        actual_cc = cc_map.get(meas_name.lower())
                        if actual_cc:
                            del fd["measure"]
                            fd["column"] = actual_cc
                            fixes += 1
                            result.auto_fixes.append(
                                f"Remapped visual binding '{meas_name}' from 'measure' to 'column' "
                                f"in table '{tbl}' (it is a calculated column, not a measure)"
                            )

    # ── 5.46 Detect broken chart axis bindings ──────────────────────────
    def _detect_chart_axis_issues(self, schema: Dict[str, Any], result: ValidationResult):
        """Detect two classes of broken visual bindings and report as errors:

        (a) Non-numeric column used as Values/Y in a chart (e.g. text ID column).
        (b) Same column bound to both Category (X) and Y axes.

        The LLM must fix these by defining proper measures in the semantic model.
        """
        sem = schema.get("semantic_model", {})
        tables_list = sem.get("tables", [])

        # Build: table_name -> {col_name -> dataType}
        col_dtype: Dict[str, Dict[str, str]] = {}
        for t in tables_list:
            tname = t.get("name", "")
            col_dtype[tname] = {}
            for c in t.get("columns", []):
                col_dtype[tname][c.get("name", "")] = c.get("dataType", "string")
            for cc in t.get("calculated_columns", []):
                col_dtype[tname][cc.get("name", "")] = cc.get("dataType", "double")

        NUMERIC_TYPES = {"int64", "double", "decimal"}
        CHART_TYPES = {"barChart", "columnChart", "lineChart", "areaChart", "scatterChart",
                       "pieChart", "donutChart", "treemap", "waterfallChart", "funnelChart"}

        issues = []

        for page in schema.get("report", {}).get("pages", []):
            for visual in page.get("visuals", []):
                vtype = visual.get("type", "")
                if vtype not in CHART_TYPES:
                    continue
                data = visual.get("data", {})
                vtitle = visual.get("title", vtype)

                cat_roles = {k: v for k, v in data.items()
                             if k.lower() in ("category", "axis", "x", "group")}
                val_roles = {k: v for k, v in data.items()
                             if k.lower() in ("values", "y", "value")}

                # (b) Same column on both Category and Y
                for cat_role, cat_fd in cat_roles.items():
                    cat_tbl = cat_fd.get("table", "") if isinstance(cat_fd, dict) else ""
                    cat_col = cat_fd.get("column", "") if isinstance(cat_fd, dict) else ""
                    if not cat_col:
                        continue
                    for val_role, val_fd in val_roles.items():
                        if not isinstance(val_fd, dict):
                            continue
                        y_col = val_fd.get("column", "")
                        y_tbl = val_fd.get("table", cat_tbl)
                        if y_col and y_col == cat_col and y_tbl == cat_tbl:
                            issues.append(
                                f"Visual '{vtitle}': column '{y_col}' is used on both "
                                f"Category and Values axes. Use a measure (e.g. SUM or COUNT) "
                                f"for the Values axis instead."
                            )

                # (a) Non-numeric column used as Values/Y
                for val_role, val_fd in val_roles.items():
                    if not isinstance(val_fd, dict):
                        continue
                    y_col = val_fd.get("column", "")
                    y_tbl = val_fd.get("table", "")
                    if val_fd.get("measure") or not y_col:
                        continue
                    dtype = col_dtype.get(y_tbl, {}).get(y_col, "string")
                    if dtype not in NUMERIC_TYPES:
                        issues.append(
                            f"Visual '{vtitle}': non-numeric column '{y_col}' (type={dtype}) "
                            f"is used as a chart value (Y axis). Use a measure "
                            f"(e.g. COUNTROWS or COUNT) instead of a raw column binding."
                        )

        if issues:
            result.errors.append(
                "Chart axis binding issues detected. Fix these in the schema: "
                + "; ".join(issues[:5])
                + (f" ... and {len(issues) - 5} more" if len(issues) > 5 else "")
            )

    # ── 5. Validate & fix measures ────────────────────────────────────────
    def _validate_and_fix_measures(self, schema: Dict[str, Any], result: ValidationResult):
        sem = schema.get("semantic_model", {})
        tables = sem.get("tables", [])

        # Pre-pass: detect comma-separated DAX expressions in a single measure
        # e.g. "SUM('T'[A]), SUM('T'[B])" - the LLM crammed two expressions into one.
        # Split them into separate measures.
        for table in tables:
            new_measures = []
            measures_to_remove = []
            for i, measure in enumerate(table.get("measures", [])):
                expr = measure.get("expression", "")
                if not expr:
                    continue
                # Detect pattern: complete DAX expression followed by comma and another expression
                # e.g. "SUM(X[A]), COUNT(Y[B])" or "CALCULATE(...), SUMX(...)"
                # A comma at the top level (not inside parens) separating two expressions
                parts = self._split_top_level_comma(expr)
                if len(parts) > 1:
                    # First part keeps the original measure name
                    measure["expression"] = parts[0].strip()
                    result.auto_fixes.append(
                        f"Split comma-separated DAX in measure '{measure.get('name', '')}' "
                        f"into {len(parts)} separate measures"
                    )
                    # Create new measures for the rest
                    for j, part in enumerate(parts[1:], 2):
                        new_name = f"{measure.get('name', 'Measure')}_{j}"
                        new_measures.append({"name": new_name, "expression": part.strip()})
            if new_measures:
                table.setdefault("measures", []).extend(new_measures)

        cols_idx: Dict[str, Set[str]] = defaultdict(set)
        meas_idx: Dict[str, Set[str]] = defaultdict(set)
        cols_lower: Dict[str, Set[str]] = defaultdict(set)
        meas_lower: Dict[str, Set[str]] = defaultdict(set)
        meas_canonical: Dict[str, Dict[str, str]] = defaultdict(dict)
        tables_dict: Dict[str, Dict] = {}

        for table in tables:
            tn = table.get("name")
            tables_dict[tn] = table
            for c in table.get("columns", []) + table.get("calculated_columns", []):
                cn = c.get("name", "")
                cols_idx[tn].add(cn)
                cols_lower[tn].add(cn.lower())
            for m in table.get("measures", []):
                mn = m.get("name", "")
                meas_idx[tn].add(mn)
                meas_lower[tn].add(mn.lower())
                meas_canonical[tn][mn.lower()] = mn

        # 5a. Fix measure/column name conflicts
        for tn, table in tables_dict.items():
            for measure in table.get("measures", []):
                mn = measure["name"]
                if mn.lower() in cols_lower[tn]:
                    new_name = f"Total {mn}"
                    counter = 2
                    while new_name.lower() in meas_lower[tn] or new_name.lower() in cols_lower[tn]:
                        new_name = f"Total {mn} {counter}"
                        counter += 1
                    meas_idx[tn].discard(mn)
                    meas_idx[tn].add(new_name)
                    meas_lower[tn].discard(mn.lower())
                    meas_lower[tn].add(new_name.lower())
                    meas_canonical[tn].pop(mn.lower(), None)
                    meas_canonical[tn][new_name.lower()] = new_name
                    result.auto_fixes.append(f"Renamed measure '{mn}' -> '{new_name}' (name conflict with column)")
                    measure["name"] = new_name

        # 5b. Fix Table[Measure] -> [Measure] in DAX
        all_measure_names = set()
        for s in meas_idx.values():
            all_measure_names.update(s)

        for tn, table in tables_dict.items():
            for measure in table.get("measures", []):
                expr = measure.get("expression", "")
                if not expr:
                    continue
                updated = expr
                for ref_tn in tables_dict:
                    for mn in meas_idx.get(ref_tn, set()):
                        bad = f"{ref_tn}[{mn}]"
                        if bad in updated:
                            updated = updated.replace(bad, f"[{mn}]")
                if updated != expr:
                    measure["expression"] = updated
                    result.auto_fixes.append(f"Fixed Table[Measure] syntax in '{measure['name']}'")
        # ✅ SAFETY GUARD 3: Force AVERAGEX for non-column AVERAGE expressions
        # Only rewrite when AVERAGE() argument is NOT a direct column ref like Table[Col] or 'Table'[Col]
        for tn, table in tables_dict.items():
            for measure in table.get("measures", []):
                expr = measure.get("expression", "")
                if not expr:
                    continue

                # Skip if AVERAGE already has a valid column argument:
                # AVERAGE(Table[Col]) or AVERAGE('Table'[Col]) or AVERAGE([Col])
                # Table name may contain spaces (e.g. "Product Details", "Sales Orders")
                # so match multi-word identifiers too.
                if re.search(
                    r"AVERAGE\s*\(\s*(?:'[^']+'|[A-Za-z][A-Za-z0-9_ ]*[A-Za-z0-9_]|[A-Za-z0-9_]+)?\s*\[",
                    expr, re.IGNORECASE
                ):
                    continue

                # AVERAGE(...) where argument is not a direct column reference
                if re.search(r'AVERAGE\s*\(\s*[^[]', expr, re.IGNORECASE):
                    # Quote the table name in AVERAGEX if it contains spaces
                    quoted_tn = f"'{tn}'" if " " in tn else tn
                    fixed = re.sub(
                        r'AVERAGE\s*\(\s*([^)]+?)\s*\)',
                        rf'AVERAGEX({quoted_tn}, \1)',
                        expr,
                        flags=re.IGNORECASE
                    )

                    if fixed != expr:
                        measure["expression"] = fixed
                        result.auto_fixes.append(
                            f"Rewrote AVERAGE to AVERAGEX in measure {tn}[{measure['name']}]"
                        )

        # ✅ SAFETY GUARD: Force SUMX for SUM() with non-column expressions
        # SUM() only accepts a single column reference. If the LLM writes
        # SUM([Col1] * [Col2]) or SUM(col * RELATED(...)), Power BI rejects it.
        # Rewrite to SUMX(table, expr) automatically.
        for tn, table in tables_dict.items():
            for measure in table.get("measures", []):
                expr = measure.get("expression", "")
                if not expr:
                    continue

                # Skip if SUM already has a valid single column argument:
                # SUM(Table[Col]) or SUM('Table'[Col]) or SUM([Col])
                if re.search(
                    r"SUM\s*\(\s*(?:'[^']+'|[A-Za-z][A-Za-z0-9_ ]*[A-Za-z0-9_]|[A-Za-z0-9_]+)?\s*\[[^\]]+\]\s*\)",
                    expr, re.IGNORECASE
                ):
                    continue

                # SUM(...) where argument contains operators → needs SUMX
                if re.search(r'SUM\s*\(\s*[^)]*[\+\-\*\/][^)]*\)', expr, re.IGNORECASE):
                    quoted_tn = f"'{tn}'" if " " in tn else tn

                    def _replace_sum_with_sumx(m, _qtn=quoted_tn):
                        inner = m.group(1).strip()
                        return f"SUMX({_qtn}, {inner})"

                    fixed = re.sub(
                        r'SUM\s*\(\s*([^)]+?)\s*\)',
                        _replace_sum_with_sumx,
                        expr,
                        flags=re.IGNORECASE
                    )

                    if fixed != expr:
                        measure["expression"] = fixed
                        result.auto_fixes.append(
                            f"Rewrote SUM to SUMX in measure {tn}[{measure['name']}]"
                        )

        # 5b_remap. Fix visual column bindings that point to the wrong table.
        # The LLM sometimes writes {"table": "Sales Orders", "column": "Product Type"}
        # when Product Type actually lives in Product Details. Detect and remap.
        def _norm_field(s: str) -> str:
            return s.lower().replace(" ", "").replace("_", "")

        # Build a lookup: normalised_col_name -> list of tables that have it
        col_to_tables: Dict[str, List[str]] = {}
        for _tn, _cols in cols_idx.items():
            for _c in _cols:
                col_to_tables.setdefault(_norm_field(_c), []).append(_tn)

        for page in schema.get("report", {}).get("pages", []):
            for visual in page.get("visuals", []):
                data = visual.get("data", {})
                for role, fd_or_list in list(data.items()):
                    items = fd_or_list if isinstance(fd_or_list, list) else [fd_or_list]
                    for fd in items:
                        if not isinstance(fd, dict):
                            continue
                        col_name = fd.get("column", "")
                        if not col_name:
                            continue
                        binding_table = fd.get("table", "")
                        # Is this column present in the stated table?
                        if col_name in cols_idx.get(binding_table, set()):
                            continue
                        # Normalised search
                        cn = _norm_field(col_name)
                        candidate_tables = col_to_tables.get(cn, [])
                        if not candidate_tables:
                            # Try fuzzy: find the table that has a column with the same normalised name
                            for _tn, _cols in cols_idx.items():
                                for _c in _cols:
                                    if _norm_field(_c) == cn:
                                        candidate_tables.append(_tn)
                                        break
                        if len(candidate_tables) == 1:
                            # Unambiguously found in another table — remap
                            new_table = candidate_tables[0]
                            # Also normalise the column name to the actual stored name
                            actual_col = next(
                                (c for c in cols_idx.get(new_table, set()) if _norm_field(c) == cn),
                                col_name
                            )
                            fd["table"] = new_table
                            fd["column"] = actual_col
                            result.auto_fixes.append(
                                f"Remapped column binding '{col_name}' from '{binding_table}' "
                                f"to correct table '{new_table}'"
                            )
                        elif len(candidate_tables) > 1:
                            result.warnings.append(
                                f"Column '{col_name}' not in '{binding_table}'; "
                                f"found in multiple tables {candidate_tables} — cannot auto-remap"
                            )

        # 5c. Auto-add missing measures referenced by visuals.
        # NOTE: Only process MEASURE-type bindings here. Column-type bindings are
        # handled above by the remapper and should never generate placeholder measures.
        report = schema.get("report", {})
        for page in report.get("pages", []):
            for visual in page.get("visuals", []):
                # Collect only measure-type field refs (skip plain column bindings)
                measure_refs: List[Tuple[str, str]] = []
                data = visual.get("data", {})
                for role, fd_or_list in data.items():
                    items = fd_or_list if isinstance(fd_or_list, list) else [fd_or_list]
                    for fd in items:
                        if isinstance(fd, dict) and fd.get("measure"):
                            measure_refs.append((fd.get("table", ""), fd["measure"]))
                        elif isinstance(fd, str):
                            # plain string binding — treat as potential measure ref
                            tbl_fld = fd
                            if "[" in tbl_fld:
                                parts = tbl_fld.split("[")
                                measure_refs.append((parts[0].strip(), parts[1].rstrip("]").strip()))

                for tbl, fld in measure_refs:
                    if not tbl or tbl not in tables_dict:
                        continue
                    # is it already a column or measure?
                    if fld in cols_idx.get(tbl, set()) or fld in meas_idx.get(tbl, set()):
                        continue
                    # case-insensitive check
                    canon = meas_canonical.get(tbl, {}).get(fld.lower())
                    if canon:
                        continue
                    # missing measure — add placeholder (only if truly absent)
                    existing_measure_names_lower = {
                        m["name"].lower()
                        for m in tables_dict[tbl].get("measures", [])
                        if m.get("name")
                    }

                    if fld.lower() in existing_measure_names_lower:
                        # Measure already exists; do NOT add duplicate
                        continue

                    placeholder = self._placeholder_dax(fld, tbl, cols_idx.get(tbl, set()))
                    if not placeholder:
                        continue

                    # SAFETY GUARD 1: block measures that reference non‑existent columns
                    col_refs = re.findall(r'\[(.*?)\]', placeholder)
                    invalid_refs = [
                        c for c in col_refs
                        if c not in cols_idx.get(tbl, set())
                    ]
                    if invalid_refs:
                        result.warnings.append(
                            f"Skipped measure {tbl}[{fld}] due to missing column(s): {invalid_refs}"
                        )
                        continue

                    # SAFETY GUARD 2 (CRITICAL): block circular placeholder measures
                    # Example: Average Lead Time = AVERAGE([Average Lead Time])
                    if fld.lower() in placeholder.lower():
                        result.warnings.append(
                            f"Skipped circular placeholder measure {tbl}[{fld}]"
                        )
                        continue
                    
                    # 🚫 SAFETY GUARD 4: Block cross-table column usage without relationship
                    col_refs = re.findall(r'(\w+)\[(.*?)\]', placeholder)
                    invalid_cross_refs = []

                    for ref_tbl, ref_col in col_refs:
                        if ref_tbl != tbl and ref_tbl in tables_dict:
                            invalid_cross_refs.append(f"{ref_tbl}[{ref_col}]")

                    if invalid_cross_refs:
                        result.warnings.append(
                            f"Skipped measure {tbl}[{fld}] due to cross-table column reference(s) "
                            f"without relationship: {invalid_cross_refs}"
                        )
                        continue


                    # ✅ Safe to add measure exactly ONCE
                    tables_dict[tbl].setdefault("measures", []).append(
                        {"name": fld, "expression": placeholder}
                    )
                    meas_idx[tbl].add(fld)
                    meas_lower[tbl].add(fld.lower())
                    meas_canonical[tbl][fld.lower()] = fld
                    result.auto_fixes.append(f"Added placeholder measure {tbl}[{fld}]")


    def _placeholder_dax(self, name: str, table: str, columns: Set[str]) -> str:
        nl = name.lower()
        # Always quote table names that contain spaces to produce valid DAX
        quoted_table = f"'{table}'" if " " in table else table
        if "%" in name or "percent" in nl or "ratio" in nl:
            return "DIVIDE(1, 1, 0)"
        if "count" in nl:
            return f"COUNTROWS({quoted_table})"
        num_hints = ("amount", "quantity", "price", "cost", "value", "revenue", "salary")
        if "sum" in nl or "total" in nl:
            for c in columns:
                if any(h in c.lower() for h in num_hints):
                    return f"SUM({quoted_table}[{c}])"
        if "avg" in nl or "average" in nl:
            for c in columns:
                if any(h in c.lower() for h in num_hints):
                    return f"AVERAGE({quoted_table}[{c}])"
        return f"COUNTROWS({quoted_table})"

    # ── 5.6. Structural integrity checks ─────────────────────────────────
    def _validate_structural_integrity(self, schema: Dict[str, Any], result: ValidationResult):
        """Check fundamental schema structure: source files exist, tables have columns,
        report has pages with visuals."""
        sem = schema.get("semantic_model", {})
        tables = sem.get("tables", [])
        report = schema.get("report", {})

        # Check each table has a resolvable source file
        for table in tables:
            tname = table.get("name", "?")
            source_obj = table.get("source", {})
            source_path = source_obj.get("path", "") if isinstance(source_obj, dict) else ""
            if source_path:
                resolved = self._resolve_file(source_path)
                if not resolved:
                    result.errors.append(
                        f"Table '{tname}': source file '{source_path}' not found in data directory. "
                        f"Available files: {self._list_data_files()}"
                    )
            elif not table.get("columns"):
                # No source and no columns = empty table
                result.errors.append(
                    f"Table '{tname}' has no source.path and no columns defined — "
                    f"it cannot produce a valid semantic model."
                )

            # Check table has at least one column after normalization
            if not table.get("columns"):
                result.warnings.append(
                    f"Table '{tname}' has zero columns. The tool will attempt auto-detection from the source file."
                )

        # Check report has pages
        pages = report.get("pages", [])
        if not pages:
            result.errors.append(
                "Report has no pages defined. At least one page with visuals is required."
            )
        else:
            for page in pages:
                pname = page.get("name", "Unnamed")
                visuals = page.get("visuals", [])
                if not visuals:
                    result.warnings.append(f"Page '{pname}' has zero visuals.")

    def _list_data_files(self) -> str:
        """List available files in data_dir for error messages."""
        if not self.data_dir or not self.data_dir.exists():
            return "(no data directory)"
        try:
            files = [f for f in os.listdir(self.data_dir)
                     if f.lower().endswith(('.csv', '.xlsx', '.xls', '.json'))]
            return ", ".join(sorted(files)) if files else "(empty)"
        except OSError:
            return "(unreadable)"

    # ── 5.7. DAX sanity checks ───────────────────────────────────────────
    def _validate_dax_sanity(self, schema: Dict[str, Any], result: ValidationResult):
        """Check for common DAX errors that would crash Power BI:
        - Circular measure references (measure uses itself)
        - EARLIER() used in measures (only valid in calculated columns)
        - Duplicate measure names within the same table
        - Empty measure expressions
        """
        sem = schema.get("semantic_model", {})
        tables = sem.get("tables", [])

        for table in tables:
            tname = table.get("name", "?")
            measures = table.get("measures", [])

            # Duplicate measure names
            seen_names: Dict[str, int] = {}
            deduped_measures = []
            for m in measures:
                mname = m.get("name", "")
                if not mname:
                    continue
                key = mname.lower()
                if key in seen_names:
                    seen_names[key] += 1
                    # Rename the duplicate
                    new_name = f"{mname}_{seen_names[key]}"
                    m["name"] = new_name
                    result.auto_fixes.append(
                        f"Renamed duplicate measure '{mname}' → '{new_name}' in table '{tname}'"
                    )
                    deduped_measures.append(m)
                else:
                    seen_names[key] = 1
                    deduped_measures.append(m)
            table["measures"] = deduped_measures

            # Per-measure checks
            measures_to_remove = []
            for m in table.get("measures", []):
                mname = m.get("name", "")
                expr = m.get("expression", "")

                # Empty expression
                if not expr or not expr.strip():
                    measures_to_remove.append(mname)
                    result.warnings.append(
                        f"Removed measure '{mname}' in table '{tname}': empty expression."
                    )
                    continue

                # Circular reference: measure name appears as [MeasureName] in its own expression
                # Must check that it's not just a substring match (e.g. "Total" in "Total Revenue")
                if re.search(rf'\[{re.escape(mname)}\]', expr, re.IGNORECASE):
                    measures_to_remove.append(mname)
                    result.warnings.append(
                        f"Removed circular measure '{mname}' in table '{tname}': "
                        f"references itself in expression."
                    )
                    continue

                # EARLIER() in a measure (invalid — only works in calculated columns)
                if re.search(r'\bEARLIER\s*\(', expr, re.IGNORECASE):
                    # Try to simplify: replace EARLIER usage with a basic aggregation
                    simplified = re.sub(
                        r'COUNTROWS\s*\(\s*FILTER\s*\([^)]+,\s*[^)]*EARLIER\s*\([^)]*\)[^)]*\)\s*\)',
                        f"COUNTROWS({tname})" if " " not in tname else f"COUNTROWS('{tname}')",
                        expr,
                        flags=re.IGNORECASE,
                    )
                    if simplified != expr:
                        m["expression"] = simplified
                        result.auto_fixes.append(
                            f"Rewrote EARLIER() usage in measure '{mname}' → simplified to COUNTROWS"
                        )
                    else:
                        measures_to_remove.append(mname)
                        result.warnings.append(
                            f"Removed measure '{mname}' in table '{tname}': "
                            f"uses EARLIER() which is invalid in measures."
                        )
                    continue

                # Catch naked DAX columns in measures (e.g. IF(Sales[Date]... or ISBLANK(Sales[Date]))
                # where the user attempts row context operations inside a measure without an aggregator.
                if re.search(r'(?i)\b(?:IF|ISBLANK|SWITCH|ISERROR)\s*\(\s*(?:\'[^\']+\'|[a-zA-Z0-9_]+)?\s*\[[^\]]+\]', expr):
                    result.errors.append(
                        f"Measure '{mname}' in table '{tname}' contains a naked column reference inside IF/ISBLANK/SWITCH. "
                        f"A single value for a column cannot be determined in a measure without an aggregation function "
                        f"(like MAX, MIN, SUM, or SELECTEDVALUE). Expression: {expr}"
                    )
                    continue
                
                # Catch measures that are purely arithmetic on column references without aggregation
                has_column_ref = bool(re.search(r'\[.+?\]', expr))
                has_aggregator = bool(re.search(r'(?i)\b(?:SUM|MAX|MIN|AVERAGE|COUNT|DISTINCTCOUNT|CALCULATE|SUMX|AVERAGEX|MAXX|MINX|COUNTX|COUNTROWS|SELECTEDVALUE|VALUES|CONCATENATEX)\s*\(', expr))
                
                if has_column_ref and not has_aggregator and "VAR " not in expr.upper():
                    result.errors.append(
                        f"Measure '{mname}' in table '{tname}' appears to use column references without any aggregation functions. "
                        f"Remember that measures operate on filter context, not row context. Wrap columns in MAX/SUM/SELECTEDVALUE! Expression: {expr}"
                    )
                    continue

            if measures_to_remove:
                table["measures"] = [
                    m for m in table.get("measures", [])
                    if m.get("name") not in measures_to_remove
                ]

    # ── 5.8. Visual completeness checks ──────────────────────────────────
    def _validate_visual_completeness(self, schema: Dict[str, Any], result: ValidationResult):
        """Check visuals for common issues:
        - Invalid visual type names
        - Missing Category/X axis on chart types (produces blank single-dot visuals)
        - Visual references a table not in the semantic model (auto-fix to closest match)
        """
        sem = schema.get("semantic_model", {})
        tables = sem.get("tables", [])
        table_names = {t.get("name", "") for t in tables}
        table_names.discard("")
        table_names_lower = {t.lower(): t for t in table_names}

        VALID_VISUAL_TYPES = {
            "barChart", "columnChart", "clusteredBarChart", "clusteredColumnChart",
            "hundredPercentStackedBarChart", "hundredPercentStackedColumnChart",
            "lineChart", "areaChart", "pieChart", "donutChart", "waterfallChart",
            "comboChart", "scatterChart", "card", "gauge", "map", "treemap",
            "table", "tableEx", "boxAndWhiskerChart", "funnelChart",
        }
        VALID_LOWER = {v.lower(): v for v in VALID_VISUAL_TYPES}

        # Chart types that MUST have a Category/X axis to render properly
        NEEDS_CATEGORY = {
            "barchart", "columnchart", "clusteredbarchart", "clusteredcolumnchart",
            "hundredpercentstackedbarchart", "hundredpercentstackedcolumnchart",
            "linechart", "areachart", "piechart", "donutchart", "waterfallchart",
            "combochart",
        }

        report = schema.get("report", {})
        for page in report.get("pages", []):
            for visual in page.get("visuals", []):
                vtype = visual.get("type", "")
                title = visual.get("title", vtype)

                # Validate visual type
                if vtype and vtype.lower() not in VALID_LOWER:
                    # Try fuzzy match
                    matches = difflib.get_close_matches(vtype.lower(), list(VALID_LOWER.keys()), n=1, cutoff=0.7)
                    if matches:
                        corrected = VALID_LOWER[matches[0]]
                        result.auto_fixes.append(
                            f"Corrected visual type '{vtype}' → '{corrected}' in '{title}'"
                        )
                        visual["type"] = corrected
                    else:
                        result.warnings.append(
                            f"Visual '{title}' has unknown type '{vtype}'. "
                            f"Valid types: {', '.join(sorted(VALID_VISUAL_TYPES))}"
                        )

                # Check for missing Category axis on charts
                if vtype.lower() in NEEDS_CATEGORY:
                    data = visual.get("data", {})
                    has_category = any(
                        k.lower() in ("category", "axis", "x", "group")
                        for k in data.keys()
                    )
                    if not has_category:
                        result.errors.append(
                            f"Chart '{title}' (type={vtype}) has no Category/X axis binding. "
                            f"You MUST provide a 'category' or 'axis' field to avoid a blank/single-point visual."
                        )

                # Fix table references that don't match any semantic model table
                data = visual.get("data", {})
                for role, fd_or_list in list(data.items()):
                    items = fd_or_list if isinstance(fd_or_list, list) else [fd_or_list]
                    for fd in items:
                        if not isinstance(fd, dict):
                            continue
                        tbl = fd.get("table", "")
                        if tbl and tbl not in table_names:
                            # Try case-insensitive match
                            actual = table_names_lower.get(tbl.lower())
                            if actual:
                                fd["table"] = actual
                                result.auto_fixes.append(
                                    f"Fixed table name case: '{tbl}' → '{actual}' in visual '{title}'"
                                )
                            else:
                                # Try normalized match
                                tbl_norm = _norm(tbl)
                                match = next(
                                    (t for t in table_names if _norm(t) == tbl_norm), None
                                )
                                if match:
                                    fd["table"] = match
                                    result.auto_fixes.append(
                                        f"Fixed table name: '{tbl}' → '{match}' in visual '{title}'"
                                    )

    # ── 6. Final strict field validation ──────────────────────────────────
    def _validate_all_field_refs(self, schema: Dict[str, Any]) -> List[str]:
        errors = []
        defined = self._build_field_index(schema)
        all_fields = set()
        for s in defined.values():
            all_fields.update(s)

        report = schema.get("report", {})
        for page in report.get("pages", []):
            page_name = page.get("name", "Page")
            for idx, visual in enumerate(page.get("visuals", []), 1):
                title = visual.get("title", f"Visual {idx}")
                for tbl, fld in _extract_field_refs(visual.get("data", {})):
                    if not fld:
                        continue
                    if tbl:
                        if tbl not in defined:
                            errors.append(
                                f"'{title}' on {page_name}: table '{tbl}' not in semantic model. "
                                f"Available tables: {', '.join(sorted(defined.keys()))}"
                            )
                        elif fld not in defined[tbl]:
                            errors.append(
                                f"'{title}' on {page_name}: field '{fld}' not in table '{tbl}'. "
                                f"Available: {_find_similar(fld, defined[tbl])}"
                            )
                    else:
                        if fld not in all_fields:
                            errors.append(
                                f"'{title}' on {page_name}: field '{fld}' not in any table. "
                                f"Similar: {_find_similar(fld, all_fields)}"
                            )
        return errors

    # ── shared helpers ────────────────────────────────────────────────────

    def _split_top_level_comma(self, expr: str) -> List[str]:
        """Split a DAX expression on commas that are at the top level (depth 0).

        Returns a list of parts. If there's only one top-level expression,
        returns a single-element list (no split needed).
        Only splits if each resulting part looks like a complete DAX expression
        (starts with a function call or aggregation).
        """
        parts = []
        depth = 0
        current = []
        for ch in expr:
            if ch == '(':
                depth += 1
                current.append(ch)
            elif ch == ')':
                depth -= 1
                current.append(ch)
            elif ch == ',' and depth == 0:
                parts.append(''.join(current))
                current = []
            else:
                current.append(ch)
        parts.append(''.join(current))

        # Only consider it a "multi-expression" if we have 2+ parts AND
        # each part looks like a standalone DAX expression (starts with a function name)
        dax_func_pattern = re.compile(
            r'^\s*(SUM|COUNT|COUNTROWS|AVERAGE|MIN|MAX|CALCULATE|SUMX|AVERAGEX|'
            r'COUNTAX|DIVIDE|IF|RELATED|DISTINCTCOUNT|COUNTA|VALUES|FILTER|ALL)\s*\(',
            re.IGNORECASE
        )
        if len(parts) >= 2 and all(dax_func_pattern.match(p.strip()) for p in parts):
            return parts
        return [expr]  # no split

    def _build_field_index(self, schema: Dict[str, Any]) -> Dict[str, Set[str]]:
        idx: Dict[str, Set[str]] = {}
        for table in schema.get("semantic_model", {}).get("tables", []):
            tn = table.get("name", "")
            if not tn:
                continue
            fields = set()
            for c in table.get("columns", []):
                fields.add(c.get("name", ""))
            for m in table.get("measures", []):
                fields.add(m.get("name", ""))
            for cc in table.get("calculated_columns", []):
                fields.add(cc.get("name", ""))
            fields.discard("")
            idx[tn] = fields
        return idx

    def _resolve_file(self, file_path: str) -> Optional[Path]:
        """Resolve a filename to an actual path using data_dir."""
        p = Path(file_path)
        if p.exists():
            return p
        if self.data_dir:
            candidate = self.data_dir / p.name
            if candidate.exists():
                return candidate
            # fuzzy filename match (underscores <-> spaces)  and fallback for lonely file
            target_norm = _norm(p.name)
            try:
                tabular_files = []
                for existing in os.listdir(self.data_dir):
                    if existing.lower().endswith(('.csv', '.xlsx', '.xls', '.json')):
                        tabular_files.append(existing)
                    if _norm(existing) == target_norm:
                        cand = self.data_dir / existing
                        if cand.exists():
                            return cand
                
                # Fallback: if there is exactly one tabular file in data_dir, use it.
                if len(tabular_files) == 1:
                    logger.info(f"Fallback: using single file '{tabular_files[0]}' for requested '{file_path}'")
                    cand = self.data_dir / tabular_files[0]
                    if cand.exists():
                        return cand
            except OSError:
                pass
        return None

