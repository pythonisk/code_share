"""
SQL Validation Tool — Denodo to Fabric Migration Testing Automation

Action tool executed by AGENT_TA_03 (SQL Validation Agent).
Runs test-case SQL queries against both Denodo (source) and Microsoft Fabric
(target) and returns structured pass/fail results.

Strategy per test type (POC Section 8):
  - row_count           : compare COUNT(*) results; pass if counts match
  - schema_validation   : compare column name + type sets
  - null_check          : compare NULL count for specified column
  - transformation_val. : compare aggregated / derived value sets
  - data_comparison     : delegate to DataComparisonTool for field-level checks

Connection config is resolved entirely from environment variables (no hardcoding):
  Fabric : FABRIC_SQL_ENDPOINT, FABRIC_DATABASE, FABRIC_BEARER_TOKEN  -or-
           FABRIC_TENANT_ID + FABRIC_CLIENT_ID + FABRIC_CLIENT_SECRET
  Denodo : DENODO_HOST, DENODO_PORT, DENODO_DATABASE,
           DENODO_USER + DENODO_PASSWORD  -or-  DENODO_BEARER_TOKEN
"""

from __future__ import annotations

import ast
import json
import logging
import os
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
_FABRIC_SQLDW_SCOPE = "https://database.windows.net/.default"
_ROW_COUNT_TOLERANCE = float(os.getenv("VALIDATION_ROW_COUNT_TOLERANCE", "0.0"))

# ---------------------------------------------------------------------------
# Helpers — auth & HTTP
# ---------------------------------------------------------------------------

def _get_fabric_token() -> Optional[str]:
    token = os.getenv("FABRIC_BEARER_TOKEN", "").strip()
    if token:
        return token

    tenant = os.getenv("FABRIC_TENANT_ID", "").strip()
    client = os.getenv("FABRIC_CLIENT_ID", "").strip()
    secret = os.getenv("FABRIC_CLIENT_SECRET", "").strip()
    if not (tenant and client and secret):
        return None

    resp = requests.post(
        f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
        data={
            "grant_type": "client_credentials",
            "client_id": client,
            "client_secret": secret,
            "scope": _FABRIC_SQLDW_SCOPE,
        },
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json().get("access_token")


def _exec_fabric_sql(sql: str, timeout: int = 120) -> Dict[str, Any]:
    endpoint = os.getenv("FABRIC_SQL_ENDPOINT", "").strip()
    database = os.getenv("FABRIC_DATABASE", "").strip()
    if not endpoint or not database:
        raise RuntimeError(
            "Fabric SQL endpoint not configured. "
            "Set FABRIC_SQL_ENDPOINT and FABRIC_DATABASE environment variables."
        )
    token = _get_fabric_token()
    if not token:
        raise RuntimeError(
            "No Fabric auth credentials found. "
            "Set FABRIC_BEARER_TOKEN or FABRIC_TENANT_ID + FABRIC_CLIENT_ID + FABRIC_CLIENT_SECRET."
        )
    url = f"https://{endpoint}/v1/workspaces/query"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    resp = requests.post(
        url, headers=headers, json={"query": sql, "database": database}, timeout=timeout
    )
    resp.raise_for_status()
    data = resp.json()
    return {
        "rows": data.get("rows", data.get("results", [])),
        "columns": data.get("columns", []),
    }


def _exec_denodo_sql(sql: str, timeout: int = 120) -> Dict[str, Any]:
    host = os.getenv("DENODO_HOST", "localhost").strip()
    port = os.getenv("DENODO_PORT", "9090").strip()
    database = os.getenv("DENODO_DATABASE", "").strip()
    db_path = f"/{database}" if database else ""
    url = f"http://{host}:{port}/denodo-data-catalog/api{db_path}/views/query"

    session = requests.Session()
    token = os.getenv("DENODO_BEARER_TOKEN", "").strip()
    user = os.getenv("DENODO_USER", "").strip()
    pwd = os.getenv("DENODO_PASSWORD", "").strip()
    if token:
        session.headers["Authorization"] = f"Bearer {token}"
    elif user and pwd:
        session.auth = (user, pwd)
    else:
        raise RuntimeError(
            "No Denodo auth credentials found. "
            "Set DENODO_USER + DENODO_PASSWORD or DENODO_BEARER_TOKEN."
        )

    resp = session.post(url, json={"query": sql}, timeout=timeout)
    resp.raise_for_status()
    data = resp.json()
    return {
        "rows": data.get("elements", data.get("rows", [])),
        "columns": data.get("name", data.get("columns", [])),
    }


# ---------------------------------------------------------------------------
# Per-test validation logic
# ---------------------------------------------------------------------------

def _validate_row_count(test: Dict) -> Dict[str, Any]:
    """Compare COUNT(*) between source (Denodo) and target (Fabric)."""
    src_res = _exec_fabric_sql(test["source_query"]) if _is_fabric_source(test) else _exec_denodo_sql(test["source_query"])
    tgt_res = _exec_fabric_sql(test["target_query"])

    src_count = _extract_scalar(src_res)
    tgt_count = _extract_scalar(tgt_res)

    if src_count is None or tgt_count is None:
        return _result(test, "error", src_count, tgt_count, "Could not extract count values from query results")

    diff = abs(int(src_count) - int(tgt_count))
    tolerance_rows = int(int(src_count) * _ROW_COUNT_TOLERANCE) if src_count else 0
    passed = diff <= tolerance_rows
    detail = None if passed else f"Row count mismatch: source={src_count}, target={tgt_count}, diff={diff}"
    return _result(test, "pass" if passed else "fail", src_count, tgt_count, detail)


def _validate_null_check(test: Dict) -> Dict[str, Any]:
    """Verify null counts match between source and target for a specific column."""
    src_res = _exec_denodo_sql(test["source_query"])
    tgt_res = _exec_fabric_sql(test["target_query"])
    src_null = _extract_scalar(src_res)
    tgt_null = _extract_scalar(tgt_res)
    passed = src_null is not None and tgt_null is not None and int(src_null) == int(tgt_null)
    detail = None if passed else f"Null count mismatch: source={src_null}, target={tgt_null}"
    return _result(test, "pass" if passed else "fail", src_null, tgt_null, detail)


def _validate_schema(test: Dict) -> Dict[str, Any]:
    """Verify column sets (names and types) match between source and target."""
    src_res = _exec_denodo_sql(test["source_query"])
    tgt_res = _exec_fabric_sql(test["target_query"])
    src_cols = set(str(c).lower() for c in (src_res.get("columns") or []))
    tgt_cols = set(str(c).lower() for c in (tgt_res.get("columns") or []))
    missing = src_cols - tgt_cols
    extra = tgt_cols - src_cols
    passed = not missing and not extra
    detail = None
    if not passed:
        detail = f"Schema mismatch — missing in target: {missing}, extra in target: {extra}"
    return _result(test, "pass" if passed else "fail", list(src_cols), list(tgt_cols), detail)


def _validate_transformation(test: Dict) -> Dict[str, Any]:
    """Compare transformation/derived column values between source and target."""
    src_res = _exec_denodo_sql(test["source_query"])
    tgt_res = _exec_fabric_sql(test["target_query"])
    src_val = _extract_scalar(src_res)
    tgt_val = _extract_scalar(tgt_res)
    passed = src_val is not None and tgt_val is not None and str(src_val) == str(tgt_val)
    detail = None if passed else f"Transformation value mismatch: source={src_val}, target={tgt_val}"
    return _result(test, "pass" if passed else "fail", src_val, tgt_val, detail)


# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------

def _is_fabric_source(test: Dict) -> bool:
    """Check if source_query should run on Fabric (both sides Fabric)."""
    return test.get("source_system", "denodo").lower() == "fabric"


def _extract_scalar(result: Dict) -> Optional[Any]:
    """Extract first cell from first row of a query result."""
    rows = result.get("rows", [])
    if not rows:
        return None
    row = rows[0]
    if isinstance(row, dict):
        vals = list(row.values())
        return vals[0] if vals else None
    if isinstance(row, (list, tuple)):
        return row[0] if row else None
    return row


def _result(
    test: Dict,
    status: str,
    source_result: Any,
    target_result: Any,
    mismatch_detail: Optional[str],
) -> Dict[str, Any]:
    return {
        "test_id": test.get("test_id", ""),
        "test_name": test.get("test_name", ""),
        "test_type": test.get("test_type", ""),
        "priority": test.get("priority", "medium"),
        "status": status,
        "source_result": source_result,
        "target_result": target_result,
        "mismatch_detail": mismatch_detail,
    }


# ---------------------------------------------------------------------------
# Input parser
# ---------------------------------------------------------------------------

def _parse_input(input_context) -> Optional[Dict]:
    if isinstance(input_context, dict):
        return input_context
    if not isinstance(input_context, str) or not input_context.strip():
        return None
    raw = input_context.strip()
    for loader in (json.loads, ast.literal_eval):
        try:
            obj = loader(raw)
            if isinstance(obj, (dict, list)):
                return obj if isinstance(obj, dict) else {"test_cases": obj}
        except (ValueError, SyntaxError):
            pass
    logger.warning("SqlValidationTool: cannot parse input_context (len=%d)", len(raw))
    return None


# ---------------------------------------------------------------------------
# Dispatch table
# ---------------------------------------------------------------------------
_VALIDATORS = {
    "row_count": _validate_row_count,
    "null_check": _validate_null_check,
    "schema_validation": _validate_schema,
    "transformation_validation": _validate_transformation,
}


# ---------------------------------------------------------------------------
# Public tool class
# ---------------------------------------------------------------------------

class SqlValidationTool:
    """
    DAAN5 native action tool — SQL Validation Agent (AGENT_TA_03).

    Instantiated by tools_loader.py with no required constructor args.
    Called by the ADK agent runtime with the stringified input_context.
    """

    def __init__(self, data_dir: str = "", **_kwargs):
        self._data_dir = data_dir

    def run_sql_validation(self, input_context) -> str:
        """
        Execute all SQL test cases against Denodo and Fabric and return
        a JSON string containing the per-test validation results.

        Args:
            input_context: dict or JSON string containing:
                           - test_cases: list of test-case dicts (from AGENT_TA_02)
                           - optional overrides: fabric_endpoint, denodo_host, etc.

        Returns:
            JSON string: {"results": [...], "summary": {...}}
        """
        payload = _parse_input(input_context)
        if payload is None:
            return json.dumps({"error": "Invalid or empty input_context", "results": []})

        test_cases: List[Dict] = payload.get("test_cases", [])
        if not test_cases and isinstance(payload, list):
            test_cases = payload

        if not test_cases:
            return json.dumps({"error": "No test_cases found in input_context", "results": []})

        # Apply optional per-call env overrides (injected by agent runtime from session context)
        for env_key in (
            "FABRIC_SQL_ENDPOINT", "FABRIC_DATABASE", "FABRIC_BEARER_TOKEN",
            "FABRIC_TENANT_ID", "FABRIC_CLIENT_ID", "FABRIC_CLIENT_SECRET",
            "DENODO_HOST", "DENODO_PORT", "DENODO_DATABASE",
            "DENODO_USER", "DENODO_PASSWORD", "DENODO_BEARER_TOKEN",
        ):
            override = payload.get(env_key.lower()) or payload.get(env_key)
            if override:
                os.environ[env_key] = str(override)

        results: List[Dict] = []
        for test in test_cases:
            test_type = test.get("test_type", "").lower()

            # data_comparison tests are handled by AGENT_TA_04 — skip here
            if test_type == "data_comparison":
                results.append(
                    _result(test, "skipped", None, None, "Delegated to Data Comparison Agent")
                )
                continue

            validator = _VALIDATORS.get(test_type)
            if validator is None:
                results.append(
                    _result(test, "skipped", None, None, f"Unknown test_type: {test_type!r}")
                )
                continue

            try:
                res = validator(test)
                results.append(res)
                logger.info(
                    "SQL Validation [%s] %s — %s",
                    test.get("test_id", "?"),
                    test.get("test_name", ""),
                    res["status"],
                )
            except Exception as exc:
                logger.error(
                    "SQL Validation error for test %s: %s",
                    test.get("test_id", "?"),
                    exc,
                    exc_info=True,
                )
                results.append(
                    _result(test, "error", None, None, str(exc))
                )

        total = len(results)
        passed = sum(1 for r in results if r["status"] == "pass")
        failed = sum(1 for r in results if r["status"] == "fail")
        errors = sum(1 for r in results if r["status"] == "error")
        skipped = sum(1 for r in results if r["status"] == "skipped")

        summary = {
            "total": total,
            "passed": passed,
            "failed": failed,
            "errors": errors,
            "skipped": skipped,
            "pass_rate": round(passed / total * 100, 2) if total > 0 else 0.0,
        }
        logger.info(
            "SQL Validation complete — total=%d passed=%d failed=%d errors=%d",
            total, passed, failed, errors,
        )
        return json.dumps({"results": results, "summary": summary}, default=str)
