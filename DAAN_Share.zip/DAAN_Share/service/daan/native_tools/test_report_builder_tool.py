"""
Test Report Builder Tool — Denodo to Fabric Migration Testing Automation

Action tool executed by AGENT_TA_06 (Report Generation Agent).
Consolidates the outputs from all previous validation agents into a
structured, human-readable Markdown migration validation report (POC Section 6.6).

Report sections (POC requirement):
  1. Executive Summary         — overall PASS / FAIL / PARTIAL status
  2. Test Execution Summary    — counts (total, passed, failed, skipped)
  3. SQL Validation Details    — per-test-case results table
  4. Data Comparison Summary   — strategy, accuracy %, mismatches
  5. API Validation Summary    — status, field mismatches, masking compliance
  6. Detailed Findings         — top mismatch items with context
  7. Recommendations           — actionable guidance based on failures
"""

from __future__ import annotations

import ast
import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Status thresholds (configurable at the class level; no env-var hardcoding)
# ---------------------------------------------------------------------------
_PASS_THRESHOLD = 100.0   # pass_rate % needed for PASS
_PARTIAL_THRESHOLD = 70.0 # pass_rate % needed for PARTIAL (else FAIL)


# ---------------------------------------------------------------------------
# Markdown generation helpers
# ---------------------------------------------------------------------------

def _h1(text: str) -> str:
    return f"\n# {text}\n"


def _h2(text: str) -> str:
    return f"\n## {text}\n"


def _h3(text: str) -> str:
    return f"\n### {text}\n"


def _badge(status: str) -> str:
    icons = {"PASS": "✅", "FAIL": "❌", "PARTIAL": "⚠️", "SKIPPED": "⏭️", "ERROR": "🔴"}
    return f"{icons.get(status.upper(), '❓')} **{status.upper()}**"


def _table(headers: List[str], rows: List[List[str]]) -> str:
    sep = " | ".join("---" for _ in headers)
    header_row = " | ".join(headers)
    lines = [f"| {header_row} |", f"| {sep} |"]
    for row in rows:
        lines.append("| " + " | ".join(str(c) for c in row) + " |")
    return "\n".join(lines) + "\n"


def _status_icon(status: str) -> str:
    return {"pass": "✅", "fail": "❌", "error": "🔴", "skipped": "⏭️"}.get(
        status.lower(), "❓"
    )


# ---------------------------------------------------------------------------
# Input parser
# ---------------------------------------------------------------------------

def _parse(raw) -> Optional[Dict]:
    if isinstance(raw, dict):
        return raw
    if not isinstance(raw, str) or not raw.strip():
        return None
    for loader in (json.loads, ast.literal_eval):
        try:
            obj = loader(raw.strip())
            return obj if isinstance(obj, dict) else None
        except (ValueError, SyntaxError):
            pass
    logger.warning("TestReportBuilderTool: cannot parse input_context")
    return None


def _get_nested(data: Dict, *keys: str, default=None) -> Any:
    """Safely traverse nested dicts."""
    cur = data
    for k in keys:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(k, default)
    return cur


# ---------------------------------------------------------------------------
# Section builders
# ---------------------------------------------------------------------------

def _section_executive_summary(overall_status: str, view_name: str, ts: str) -> str:
    lines = [
        _h1("Migration Validation Report"),
        f"> **Business View:** `{view_name}`  \n"
        f"> **Generated:** {ts}  \n"
        f"> **Overall Status:** {_badge(overall_status)}\n",
    ]
    return "\n".join(lines)


def _section_test_summary(
    total: int, passed: int, failed: int, errors: int, skipped: int
) -> str:
    pass_rate = round(passed / total * 100, 2) if total else 0.0
    lines = [
        _h2("Test Execution Summary"),
        _table(
            ["Metric", "Count"],
            [
                ["Total Test Cases", str(total)],
                ["Passed ✅", str(passed)],
                ["Failed ❌", str(failed)],
                ["Errors 🔴", str(errors)],
                ["Skipped ⏭️", str(skipped)],
                ["Pass Rate", f"{pass_rate}%"],
            ],
        ),
    ]
    return "\n".join(lines)


def _section_sql_validation(sql_results: Dict) -> str:
    results: List[Dict] = sql_results.get("results", [])
    summary: Dict = sql_results.get("summary", {})
    if not results:
        return _h2("SQL Validation Details") + "\n_No SQL validation results available._\n"

    rows = []
    for r in results:
        rows.append([
            r.get("test_id", ""),
            r.get("test_name", "")[:60],
            r.get("test_type", ""),
            r.get("priority", ""),
            f"{_status_icon(r.get('status',''))} {r.get('status','').upper()}",
            (r.get("mismatch_detail") or "—")[:120],
        ])

    return (
        _h2("SQL Validation Details")
        + _table(["Test ID", "Name", "Type", "Priority", "Status", "Detail"], rows)
        + f"\n**Summary:** {summary.get('passed',0)} passed / "
        f"{summary.get('failed',0)} failed / {summary.get('errors',0)} errors "
        f"({summary.get('pass_rate',0)}% pass rate)\n"
    )


def _section_data_comparison(dc_results: Dict) -> str:
    if dc_results.get("error"):
        return _h2("Data Comparison Summary") + f"\n⚠️ Error: {dc_results['error']}\n"

    strategy = dc_results.get("comparison_strategy", "unknown")
    src_cnt = dc_results.get("source_row_count", "—")
    tgt_cnt = dc_results.get("target_row_count", "—")
    delta = dc_results.get("row_count_delta", "—")
    accuracy = dc_results.get("accuracy_percentage", "—")
    mismatch_cnt = dc_results.get("mismatch_count", 0)
    hash_match = dc_results.get("hash_match", None)

    lines = [
        _h2("Data Comparison Summary"),
        _table(
            ["Metric", "Value"],
            [
                ["Comparison Strategy", strategy.capitalize()],
                ["Source (Denodo) Row Count", str(src_cnt)],
                ["Target (Fabric) Row Count", str(tgt_cnt)],
                ["Row Count Delta", str(delta)],
                ["Mismatch Count", str(mismatch_cnt)],
                ["Accuracy %", f"{accuracy}%"],
                ["Hash Match", str(hash_match) if hash_match is not None else "N/A (full comparison)"],
            ],
        ),
    ]

    mismatches: List[Dict] = dc_results.get("mismatch_details", [])
    if mismatches:
        lines.append(_h3("Top Mismatches (first 20)"))
        rows = []
        for m in mismatches[:20]:
            key = m.get("row_key", "—")
            for fm in m.get("field_mismatches", [m])[:3]:
                rows.append([
                    str(key)[:40],
                    fm.get("column", fm.get("col", "—")),
                    str(fm.get("source_value", "—"))[:60],
                    str(fm.get("target_value", "—"))[:60],
                ])
        lines.append(_table(["Row Key", "Column", "Source Value", "Target Value"], rows))

    return "\n".join(lines)


def _section_api_validation(api_results: Dict) -> str:
    status = api_results.get("api_validation_status", "skipped")
    if status == "skipped":
        reason = api_results.get("reason", "No API endpoints provided")
        return _h2("API Validation Summary") + f"\n⏭️ **Skipped** — {reason}\n"

    fabric_status = api_results.get("fabric_http_status", "—")
    denodo_status = api_results.get("denodo_http_status", "—")
    mismatch_cnt = api_results.get("field_level_mismatch_count", 0)
    masking_ok = api_results.get("masking_compliance", False)

    lines = [
        _h2("API Validation Summary"),
        f"**Overall Status:** {_badge(status)}\n",
        _table(
            ["Metric", "Value"],
            [
                ["Fabric HTTP Status", str(fabric_status)],
                ["Denodo HTTP Status", str(denodo_status)],
                ["Field Mismatches", str(mismatch_cnt)],
                ["Masking Compliance", "✅ Pass" if masking_ok else "❌ Fail"],
            ],
        ),
    ]

    mismatches: List[Dict] = api_results.get("field_level_mismatches", [])
    if mismatches:
        lines.append(_h3("Field Mismatches"))
        rows = [
            [
                m.get("field_path", "—"),
                str(m.get("source_value", "—"))[:60],
                str(m.get("target_value", "—"))[:60],
            ]
            for m in mismatches[:20]
        ]
        lines.append(_table(["Field Path", "Source Value", "Target Value"], rows))

    return "\n".join(lines)


def _section_recommendations(
    overall_status: str,
    sql_results: Dict,
    dc_results: Dict,
    api_results: Dict,
) -> str:
    recs: List[str] = []

    sql_failed = [r for r in sql_results.get("results", []) if r.get("status") == "fail"]
    if sql_failed:
        types = {r.get("test_type") for r in sql_failed}
        for t in types:
            if t == "row_count":
                recs.append("Investigate row count discrepancies — check for filtered rows, duplicate keys, or incomplete loads in the Fabric pipeline.")
            elif t == "null_check":
                recs.append("Null value mismatches detected — review ETL null-handling rules and default value assignments.")
            elif t == "schema_validation":
                recs.append("Schema mismatches found — align column names and data types between Denodo views and Fabric lakehouse schemas.")
            elif t == "transformation_validation":
                recs.append("Transformation value mismatches — audit business logic in Fabric dataflows against Denodo transformation expressions.")

    if dc_results.get("mismatch_count", 0) > 0:
        strategy = dc_results.get("comparison_strategy", "unknown")
        recs.append(
            f"Data comparison ({strategy}) found {dc_results['mismatch_count']} mismatch(es). "
            "Perform a root-cause analysis on mismatched rows using the detailed findings section."
        )

    api_status = api_results.get("api_validation_status", "skipped")
    if api_status == "fail":
        if not api_results.get("masking_compliance"):
            recs.append("Masking compliance failure — verify that PII fields are correctly masked in Fabric API responses per data security policy.")
        if api_results.get("field_level_mismatch_count", 0) > 0:
            recs.append("API field-level mismatches — compare API transformation logic and response schema between Denodo and Fabric endpoints.")

    if overall_status == "PASS":
        recs.append("All validations passed. The migration is ready for the next promotion stage.")
    elif not recs:
        recs.append("Review all error and failure items above and re-run validation after fixes are applied.")

    lines = [_h2("Recommendations")]
    for i, r in enumerate(recs, 1):
        lines.append(f"{i}. {r}")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Overall status determination
# ---------------------------------------------------------------------------

def _determine_overall_status(
    sql_pass_rate: float,
    dc_accuracy: float,
    api_status: str,
) -> str:
    api_ok = api_status in ("pass", "skipped")
    combined = (sql_pass_rate + dc_accuracy) / 2.0

    if combined >= _PASS_THRESHOLD and api_ok:
        return "PASS"
    if combined >= _PARTIAL_THRESHOLD:
        return "PARTIAL"
    return "FAIL"


# ---------------------------------------------------------------------------
# Public tool class
# ---------------------------------------------------------------------------

class TestReportBuilderTool:
    """
    DAAN5 native action tool — Report Generation Agent (AGENT_TA_06).

    Consolidates outputs from all five previous agents into a comprehensive
    Markdown migration validation report.
    """

    def __init__(self, data_dir: str = "", **_kwargs):
        self._data_dir = data_dir

    def build_report(self, input_context) -> str:
        """
        Generate the consolidated migration validation report.

        Args:
            input_context: dict or JSON string containing:
              - extracted_logic:       output from AGENT_TA_01
              - test_cases:            output from AGENT_TA_02
              - sql_validation_results: output from AGENT_TA_03
              - data_comparison_results: output from AGENT_TA_04
              - api_validation_results: output from AGENT_TA_05

        Returns:
            Full Markdown report as a string.
        """
        payload = _parse(input_context)
        if payload is None:
            return "# Report Generation Failed\n\nInvalid or empty input_context."

        # ---- Extract sub-results ----
        extracted_logic: Dict = _parse(payload.get("extracted_logic") or {}) or {}
        sql_raw = payload.get("sql_validation_results") or {}
        sql_results: Dict = _parse(sql_raw) if isinstance(sql_raw, str) else (sql_raw or {})
        dc_raw = payload.get("data_comparison_results") or {}
        dc_results: Dict = _parse(dc_raw) if isinstance(dc_raw, str) else (dc_raw or {})
        api_raw = payload.get("api_validation_results") or {}
        api_results: Dict = _parse(api_raw) if isinstance(api_raw, str) else (api_raw or {})

        # ---- Aggregate counts from SQL results ----
        sql_items: List[Dict] = sql_results.get("results", [])
        sql_summary: Dict = sql_results.get("summary", {})
        total = sql_summary.get("total", len(sql_items))
        passed = sql_summary.get("passed", sum(1 for r in sql_items if r.get("status") == "pass"))
        failed = sql_summary.get("failed", sum(1 for r in sql_items if r.get("status") == "fail"))
        errors = sql_summary.get("errors", sum(1 for r in sql_items if r.get("status") == "error"))
        skipped = sql_summary.get("skipped", sum(1 for r in sql_items if r.get("status") == "skipped"))
        sql_pass_rate: float = float(sql_summary.get("pass_rate", (passed / total * 100) if total else 100.0))

        dc_accuracy: float = float(dc_results.get("accuracy_percentage", 100.0))
        api_status: str = api_results.get("api_validation_status", "skipped")

        overall_status = _determine_overall_status(sql_pass_rate, dc_accuracy, api_status)
        view_name: str = _get_nested(extracted_logic, "metadata", "view_name") or "Unknown View"
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

        # ---- Build report sections ----
        sections = [
            _section_executive_summary(overall_status, view_name, ts),
            _section_test_summary(total, passed, failed, errors, skipped),
            _section_sql_validation(sql_results),
            _section_data_comparison(dc_results),
            _section_api_validation(api_results),
            _section_recommendations(overall_status, sql_results, dc_results, api_results),
        ]

        report = "\n---\n".join(sections)
        logger.info(
            "TestReportBuilderTool: report generated for view '%s' — status=%s",
            view_name, overall_status,
        )
        return report
