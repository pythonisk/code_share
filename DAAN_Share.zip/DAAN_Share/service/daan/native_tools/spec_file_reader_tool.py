"""Generic paginated spreadsheet reader for use-case builder agents.

Reads an uploaded ``.xlsx`` / ``.xls`` / ``.csv`` file from the current session
``inputs/`` folder and returns its rows in offset/limit slices as plain JSON
objects keyed by the file's own column headers.

It is intentionally domain-agnostic: it makes no assumption about what the
columns mean. The calling agent decides how to map each column to its target
schema. This lets one use case ingest any spec file, not a single fixed layout.

local_tools reference:
    SpecFileReaderTool.read_rows
"""

from __future__ import annotations

import csv
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_SUPPORTED_EXT = {".xlsx", ".xls", ".csv"}
# How many leading rows to inspect when auto-detecting the header row.
_HEADER_SCAN_DEPTH = 15


class SpecFileReaderTool:
    """Native tool that paginates over the rows of an uploaded spreadsheet."""

    def __init__(self, data_dir: str | None = None, **_kwargs: Any) -> None:
        self.tool_name = "SpecFileReaderTool"
        self._data_dir = data_dir
        logger.info("%s: initialized (data_dir=%s)", self.tool_name, data_dir)

    # ── Public tool method (exposed to the agent) ────────────────────────────
    def read_rows(
        self,
        offset: int = 0,
        limit: int = 10,
        file_name: str | None = None,
        sheet_name: str | None = None,
        header_row: int = 0,
    ) -> dict[str, Any]:
        """Return a slice of rows from an uploaded spec spreadsheet.

        Read the file once per call and return only the requested window of data
        rows so a looping agent can process a large file in small batches without
        exceeding its output limit.

        Args:
            offset: Zero-based index of the first data row to return.
            limit: Maximum number of data rows to return (batch size).
            file_name: Optional exact filename inside the session inputs folder.
                When omitted, the first supported spreadsheet found is used.
            sheet_name: Optional worksheet name (Excel only). When omitted, the
                first worksheet is used. ``available_sheets`` in the response
                lists every sheet so a later call can target a specific one.
            header_row: Optional 1-based row number that holds the column
                headers. When 0 (default) the header row is auto-detected as the
                row with the most non-empty cells among the first rows, which
                skips banner/title rows automatically.

        Returns:
            A dict with keys:
              ``status`` ("ok" | "error"),
              ``rows`` (list of objects keyed by column header — EMPTY when the
                offset is past the end; that is the signal to stop looping),
              ``columns`` (the detected header names),
              ``offset``, ``limit``, ``returned``,
              ``total_rows`` (total data rows in the sheet),
              ``has_more`` (True when more rows remain after this slice),
              ``file``, ``sheet``, ``available_sheets``.
        """
        try:
            safe_offset = max(0, int(offset))
            safe_limit = max(1, int(limit))

            source = self._resolve_source_file(file_name)
            if source is None:
                return self._error("No supported spreadsheet (.xlsx/.xls/.csv) found in session inputs.")

            if source.suffix.lower() == ".csv":
                header, data_rows, sheets, used_sheet = self._read_csv(source, header_row)
            else:
                header, data_rows, sheets, used_sheet = self._read_excel(source, sheet_name, header_row)

            total = len(data_rows)
            window = data_rows[safe_offset : safe_offset + safe_limit]
            rows = [self._row_to_object(header, values) for values in window]

            return {
                "status": "ok",
                "rows": rows,
                "columns": header,
                "offset": safe_offset,
                "limit": safe_limit,
                "returned": len(rows),
                "total_rows": total,
                "has_more": (safe_offset + safe_limit) < total,
                "file": source.name,
                "sheet": used_sheet,
                "available_sheets": sheets,
            }
        except Exception as exc:  # noqa: BLE001 — surface a clean tool error to the agent
            logger.exception("%s: read_rows failed", self.tool_name)
            return self._error(f"Failed to read spec file: {exc}")

    # ── Internals ────────────────────────────────────────────────────────────
    def _resolve_source_file(self, file_name: str | None) -> Path | None:
        if not self._data_dir:
            return None
        inputs_dir = Path(self._data_dir)
        if not inputs_dir.is_dir():
            return None

        if file_name:
            candidate = inputs_dir / file_name
            return candidate if candidate.is_file() else None

        for item in sorted(inputs_dir.iterdir()):
            if item.is_file() and item.suffix.lower() in _SUPPORTED_EXT:
                return item
        return None

    def _read_excel(
        self, source: Path, sheet_name: str | None, header_row: int
    ) -> tuple[list[str], list[list[Any]], list[str], str]:
        import openpyxl  # local import keeps tool load cheap when unused

        workbook = openpyxl.load_workbook(source, data_only=True, read_only=True)
        try:
            sheets = list(workbook.sheetnames)
            worksheet = workbook[sheet_name] if sheet_name in sheets else workbook.worksheets[0]
            used_sheet = worksheet.title
            grid = [list(row) for row in worksheet.iter_rows(values_only=True)]
        finally:
            workbook.close()

        header, data_rows = self._split_header_and_data(grid, header_row)
        return header, data_rows, sheets, used_sheet

    def _read_csv(
        self, source: Path, header_row: int
    ) -> tuple[list[str], list[list[Any]], list[str], str]:
        with source.open("r", encoding="utf-8-sig", newline="") as handle:
            grid = [list(row) for row in csv.reader(handle)]
        header, data_rows = self._split_header_and_data(grid, header_row)
        return header, data_rows, [], ""

    def _split_header_and_data(
        self, grid: list[list[Any]], header_row: int
    ) -> tuple[list[str], list[list[Any]]]:
        rows = [r for r in grid if any(self._non_empty(c) for c in r)]
        if not rows:
            return [], []

        header_index = (header_row - 1) if header_row and header_row > 0 else self._detect_header_index(rows)
        header_index = max(0, min(header_index, len(rows) - 1))

        raw_header = rows[header_index]
        header = [self._clean_header(cell, i) for i, cell in enumerate(raw_header)]
        data_rows = rows[header_index + 1 :]
        return header, data_rows

    def _detect_header_index(self, rows: list[list[Any]]) -> int:
        best_index = 0
        best_count = -1
        for i, row in enumerate(rows[:_HEADER_SCAN_DEPTH]):
            count = sum(1 for c in row if self._non_empty(c))
            if count > best_count:
                best_count, best_index = count, i
        return best_index

    def _row_to_object(self, header: list[str], values: list[Any]) -> dict[str, Any]:
        obj: dict[str, Any] = {}
        for i, key in enumerate(header):
            value = values[i] if i < len(values) else None
            obj[key] = "" if value is None else str(value).strip()
        return obj

    @staticmethod
    def _non_empty(cell: Any) -> bool:
        return cell is not None and str(cell).strip() != ""

    @staticmethod
    def _clean_header(cell: Any, index: int) -> str:
        text = "" if cell is None else str(cell).strip()
        return text or f"column_{index + 1}"

    @staticmethod
    def _error(message: str) -> dict[str, Any]:
        return {
            "status": "error",
            "rows": [],
            "columns": [],
            "returned": 0,
            "total_rows": 0,
            "has_more": False,
            "message": message,
        }
