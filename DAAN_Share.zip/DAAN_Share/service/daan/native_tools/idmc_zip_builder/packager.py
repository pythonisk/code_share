"""
packager.py — Assembles the final IDMC import ZIP from compiled artifacts.

Pipeline:
  @3.bin ─┐
  @2.bin ─┤─→ DTEMPLATE.zip ─┐
  meta   ─┘                  ├─→ exportPackage.zip ─┐
  Project.json ──────────────┘                      │
  exportMetadata.v2.json ───────────────────────────┤─→ Final IDMC.zip
  exportPackage.chksum ─────────────────────────────┘
"""

from __future__ import annotations

import hashlib
import json
import time
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"

# Tenant constants (from original tool)
_SOURCE_ORG_ID = "8PMFrSGHpQTdbvNa89CAQW"
_SOURCE_ORG_NAME = "LTI Mindtree"
_PROJECT_GUID = "b1IJ4kw9tk4iNQgp7grr8w"
_REPO_HANDLE = "0135Q317000000000008"


def package(mapping_name: str, bin3_json: str, output_dir: Path,
            timestamp: str = "") -> Path:
    """
    Build the complete IDMC import ZIP.

    Args:
        mapping_name: Mapping name (used in filenames and metadata).
        bin3_json:    The compiled @3.bin JSON string.
        output_dir:   Directory for intermediate and final files.
        timestamp:    Optional suffix appended to the final ZIP filename
                      (e.g. ``_2026_0515_0840``).

    Returns:
        Path to the final ZIP.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    mapping_guid = uuid.uuid4().hex[:24].upper()

    # 1. Write @3.bin
    bin3_path = output_dir / "@3.bin"
    bin3_path.write_text(bin3_json, encoding="utf-8")

    # 2. Static @2.bin (thumbnail)
    bin2_path = _TEMPLATES_DIR / "bin2_static" / "@2.bin"

    # 3. fileRecord.json
    file_record_json = _generate_file_record(bin2_path, bin3_path, mapping_name)

    # 4. mappingTemplate.json
    mapping_template_json = _generate_mapping_template(mapping_name, mapping_guid)

    # 5. metadata.meta
    metadata_meta_path = _TEMPLATES_DIR / "metadata.meta"

    # 6. Build DTEMPLATE.zip
    dt_path = output_dir / f"{mapping_name}.DTEMPLATE.zip"
    _build_dtemplate_zip(dt_path, bin2_path, bin3_path,
                         file_record_json, mapping_template_json,
                         metadata_meta_path)

    # 7. Build exportPackage.zip
    export_pkg_path = output_dir / "exportPackage.zip"
    _build_export_package(export_pkg_path, "Default", dt_path)

    # 8. exportMetadata.v2.json
    metadata_json = _generate_export_metadata(mapping_name, mapping_guid)
    metadata_path = output_dir / "exportMetadata.v2.json"
    metadata_path.write_text(metadata_json, encoding="utf-8")

    # 9. exportObject.json
    obj_json = _generate_export_object(mapping_name)
    obj_path = output_dir / "exportObject.json"
    obj_path.write_text(obj_json, encoding="utf-8")

    # 10. exportPackage.chksum
    project_json_path = _TEMPLATES_DIR / "Default.Project.json"
    chksum_path = output_dir / "exportPackage.chksum"
    _generate_chksum(chksum_path, {
        "exportMetadata.v2.json": metadata_path,
        f"Explore/Default.Project.json": project_json_path,
        f"Explore/Default/{mapping_name}.DTEMPLATE.zip": dt_path,
    })

    # 11. Final IDMC import ZIP
    final_zip_path = output_dir / f"{mapping_name}{timestamp}.zip"
    if final_zip_path.exists():
        final_zip_path.unlink()
    with zipfile.ZipFile(final_zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(metadata_path, "exportMetadata.v2.json")
        zf.write(chksum_path, "exportPackage.chksum")
        zf.write(project_json_path, "Explore/Default.Project.json")
        zf.write(dt_path, f"Explore/Default/{mapping_name}.DTEMPLATE.zip")

    # 12. Cleanup intermediates
    for p in [metadata_path, obj_path, chksum_path, export_pkg_path, dt_path, bin3_path]:
        if p.exists():
            p.unlink()

    return final_zip_path


# ── Internal helpers ─────────────────────────────────────────────────

def _generate_file_record(bin2_path: Path, bin3_path: Path,
                          mapping_name: str) -> str:
    now_ms = int(time.time() * 1000)
    data = [
        {
            "@type": "fileRecord", "attachTime": now_ms,
            "id": "@2", "name": "MAPPING_PREVIEW.jpeg",
            "size": bin2_path.stat().st_size, "type": "IMAGE",
        },
        {
            "@type": "fileRecord",
            "additionalInfo": "com.informatica.metadata.template.common.Template",
            "attachTime": now_ms, "id": "@3", "name": mapping_name,
            "size": bin3_path.stat().st_size, "type": "IMFOBJECT",
        },
    ]
    return json.dumps(data, indent=2)


def _generate_mapping_template(mapping_name: str, mapping_guid: str) -> str:
    now_ms = int(time.time() * 1000)
    tmpl = {
        "@type": "mappingTemplate", "id": "@1", "name": mapping_name,
        "description": "", "autoExpireObject": False,
        "bundleVersion": "0", "assetFrsGuid": mapping_guid,
        "templateId": "@3", "deployTime": now_ms,
        "hasParameters": False, "valid": True,
        "fixedConnection": False, "hasParametersDeployed": False,
        "fixedConnectionDeployed": False,
        "isSchemaValidationEnabled": False, "tasks": 0,
        "mappingPreviewFileRecordId": "@2",
        "documentType": "MAPPING", "allowMaxFieldLength": False,
        "specialCharacterSupport": False, "references": [],
    }
    return json.dumps([tmpl], indent=2)


def _build_dtemplate_zip(out: Path, bin2: Path, bin3: Path,
                         file_record: str, mapping_template: str,
                         metadata_meta: Path):
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("fileRecord.json", file_record)
        z.writestr("mappingTemplate.json", mapping_template)
        z.write(metadata_meta, "metadata.meta")
        z.write(bin3, "bin/@3.bin")
        z.write(bin2, "bin/@2.bin")


def _build_export_package(out: Path, project: str, dt_path: Path):
    proj_json = _TEMPLATES_DIR / "Default.Project.json"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(proj_json, f"Explore/{project}.Project.json")
        z.write(dt_path, f"Explore/{project}/{dt_path.name}")


def _generate_export_metadata(mapping_name: str, mapping_guid: str) -> str:
    meta = {
        "name": mapping_name,
        "sourceOrgId": _SOURCE_ORG_ID,
        "sourceOrgName": _SOURCE_ORG_NAME,
        "exportedObjects": [
            {
                "objectGuid": mapping_guid, "objectName": mapping_name,
                "objectType": "DTEMPLATE", "path": "/Explore/Default",
                "providerName": None,
                "metadata": {
                    "modelVersion": {"major": 0, "minor": 0},
                    "repoInfo": {"repoHandle": _REPO_HANDLE},
                    "objectRefs": [],
                    "contextAttributes": [{"name": "id", "value": "@1"}],
                    "additionalInfo": {
                        "description": "", "contentType": "JSON",
                        "documentState": "VALID",
                    },
                },
            },
            {
                "objectGuid": _PROJECT_GUID, "objectName": "Default",
                "objectType": "Project", "path": "/Explore",
                "providerName": None,
                "metadata": {
                    "modelVersion": {"major": 0, "minor": 0},
                    "repoInfo": None, "objectRefs": [],
                    "contextAttributes": [{"name": "IS_DEF_LOC", "value": "true"}],
                    "additionalInfo": {
                        "description": "Auto-generated Default Project",
                        "contentType": None, "documentState": "COMPLETE",
                    },
                },
            },
        ],
    }
    return json.dumps(meta, indent=2, ensure_ascii=False)


def _generate_export_object(mapping_name: str) -> str:
    return json.dumps({
        "objects": [{
            "objectName": mapping_name,
            "objectPath": f"Default/{mapping_name}.DTEMPLATE.zip",
            "objectType": "DTEMPLATE",
            "project": "Default",
        }]
    }, indent=2)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def _generate_chksum(out: Path, file_map: dict[str, Path]):
    ts = datetime.now(timezone.utc).isoformat()
    lines = [f"#\n#{ts}\n"]
    for rel, local in sorted(file_map.items()):
        esc = rel.replace(" ", "\\ ")
        lines.append(f"{esc}={_sha256(local)}\n")
    out.write_text("".join(lines), encoding="utf-8")
