# IDMC ZIP Builder Tool — Key Facts

## Location
`tools/idmc_zip_builder/`

## Architecture
- `schema.py` — JSON schema for LLM tool contract
- `validator.py` — Pre-compilation validation (DAG, types, connectivity)
- `id_registry.py` — Sequential ID allocation (starts at 10000)
- `field_utils.py` — TxField (17), ExpressionField (22), AdapterField (18), build_fields_and_adapter
- `compiler.py` — Deterministic @3.bin JSON compiler (~700 lines)
- `packager.py` — ZIP assembly (DTEMPLATE → exportPackage → final ZIP)
- `tool.py` — Single entry point: validate → compile → package
- `agent.py` — LLM orchestrator with retry loop (MAX_RETRIES=5)
- `test_import.py` — IDMC API import test

## Critical IDMC Format Rules

### Structure
1. Top-level: `{content: {$$IID, $$class:1, ...}, metadata: {$$classInfo: {...}}}`
2. $$classInfo: 63 Java class names mapping numeric class IDs
3. Link refs: `{##ID: id, $$class: N}` — must include $$class

### Template Instantiation
4. Deep re-ID: Recursively replace ALL $$ID values in template with fresh IDs + update ##ID refs. Prevents collisions across multiple instances.
5. Template parameters: 7 params (p_src_conn, p_src_object, p_tgt_conn, p_tgt_object, p_lkp_conn, p_lkp_object, p_lkp_condition). Source/Target/Lookup wire connectionId$ to these.

### Fields
6. Expression fields: $$class 22, needs expFieldType:"OUTPUT", variable, macroOutput*
7. Aggregator fields: $$class 43 (not 17). groupByFields use `fieldName` key (not `name`)

### Groups & Rules
8. Input groups: Need TmplAllRule ($$class 32, include:"true")
9. Source groups: input:"false", output:"true"
10. Joiner Detail: TmplNameRule (36) + TmplNameRuleEntry (39) for same-name field rename (e.g., KUNNR→DETAIL_KUNNR)
11. Lookup DefaultGroup: TmplNameRule renaming ALL incoming + source fields to in_<field>

### Conditions
12. Filter: Simple → filterConditions ($$class 24: fieldName/operator/filterValue). Complex → advancedFilterCondition string.
13. Joiner joinConditions: {leftOperand, operator, rightOperand} as strings
14. Lookup lookupConditions: Same as Joiner. Split on AND for multi-key.
15. Router: groupFilterConditions with `name`. Simple → simpleFilterConditions ($$class 48). Complex → advancedFilterCondition.

### Sorter
16. SortEntry: `ascending: "true"/"false"` (NOT direction). Set sorterMode:"SIMPLE", advancedSort:""

### Target
17. manualMappings: {$$ID, $$class:20, mappingList:[...]}. FieldMapping (35): fromFieldName + toField(##ID→field) + fromExpression(##ID→upstream tx)
18. fieldMappingMode: "MANUAL"

### Source/Target Adapter
19. advancedProperties + sessionProperties required on Source/Target
20. connectionId: Empty string — parameterized via connectionId$

## IDMC API
- Import: `utils/informatica_idmc_importer.py` (V3 API: upload → start → poll)
- No mapping validation API exists (only boolean `valid` field on GET /api/v2/mapping)

## Old vs New Builder
- Old: 13k lines, LLM-driven DAG + deterministic compilation, 30+ DAG repair functions
- New: ~700 lines, purely deterministic compiler. LLM provides complete spec via agent.py
- Design: Old guesses/fixes in Python. New returns validation errors to LLM to fix.

## Testing
- `.venv\Scripts\python.exe tools\idmc_zip_builder\test_import.py [path_to_zip]`
- Test scripts: `_test_fixes.py`, `_test_fixes_v2.py`, `_compare_all.py`
