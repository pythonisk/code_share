"""
tool.py — The single entry-point tool for LLM agents.

Usage by an LLM agent:
    result = build_idmc_zip(spec_dict)

If validation fails, result contains {"status": "error", "errors": [...]}.
If build succeeds, result contains {"status": "ok", "zip_path": "...", "message": "..."}.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

from .validator import validate
from .compiler import compile_3bin
from .packager import package

logger = logging.getLogger(__name__)

_OUTPUT_DIR = Path(__file__).resolve().parent / "output"


def _build_timestamp() -> str:
    """Return a timestamp suffix for ZIP filenames: _YYYY_MMDD_HHMM in IST."""
    ist = timezone(timedelta(hours=5, minutes=30))
    return datetime.now(ist).strftime("_%Y_%m%d_%H%M")


def _check_integrity(bin3_json) -> list[str]:
    """Post-compilation integrity checks on the compiled @3.bin.
    
    Validates:
    1. No duplicate $$ID values
    2. All ##ID references point to existing $$ID values
    3. Every Target has at least one field mapping
    4. Every transformation has fields
    """
    import re

    raw = json.loads(bin3_json) if isinstance(bin3_json, str) else bin3_json
    content = raw.get("content", raw)
    text = json.dumps(content)

    errors: list[str] = []

    # 1. Collect all $$IDs and check for duplicates
    all_ids = [int(m) for m in re.findall(r'"\$\$ID"\s*:\s*(\d+)', text)]
    seen = set()
    dupes = set()
    for i in all_ids:
        if i in seen:
            dupes.add(i)
        seen.add(i)
    if dupes:
        errors.append(f"Duplicate $$ID values: {sorted(dupes)}")

    # 2. All ##ID refs must point to valid $$IDs
    all_refs = [int(m) for m in re.findall(r'"##ID"\s*:\s*(\d+)', text)]
    dangling = set(all_refs) - seen
    if dangling:
        errors.append(f"Dangling ##ID references (no matching $$ID): {sorted(dangling)}")

    # 3. Every Target must have at least one field mapping
    for tx in content.get("transformations", []):
        if tx.get("$$class") == 12:  # Target
            mm = tx.get("manualMappings", {})
            ml = mm.get("mappingList", []) if mm else []
            if not ml:
                errors.append(
                    f"Target '{tx.get('name', '?')}' has no field mappings. "
                    f"IDMC will reject this with 'Field mapping must contain at least one mapped field'."
                )

    return errors


def build_idmc_zip(spec: dict[str, Any]) -> dict[str, Any]:
    """
    Deterministic IDMC ZIP builder tool.

    Accepts a mapping spec dict, validates it, compiles @3.bin,
    packages everything into a final IDMC import ZIP.

    Args:
        spec: Mapping specification dict matching MAPPING_SPEC_SCHEMA.

    Returns:
        dict with either:
          {"status": "ok",    "zip_path": "<absolute path>", "message": "..."}
          {"status": "error", "errors":   ["...", ...]}
    """
    # ── Step 1: Validate ──────────────────────────────────────────
    errors = validate(spec)
    if errors:
        logger.warning("Validation failed with %d error(s).", len(errors))
        return {
            "status": "error",
            "errors": errors,
            "hint": "Fix the errors listed above and resubmit the spec.",
        }

    mapping_name = spec["mapping_name"]

    # ── Step 2: Compile @3.bin ────────────────────────────────────
    try:
        bin3_json = compile_3bin(spec)
    except Exception as exc:
        logger.exception("Compilation failed.")
        return {
            "status": "error",
            "errors": [f"Compilation error: {exc}"],
        }

    # ── Step 2b: Post-compilation integrity check ─────────────────
    integrity_errors = _check_integrity(bin3_json)
    if integrity_errors:
        logger.warning("Post-compilation integrity check failed with %d error(s).", len(integrity_errors))
        return {
            "status": "error",
            "errors": integrity_errors,
            "hint": "The compiled @3.bin has structural issues. This is likely a compiler bug.",
        }

    # ── Step 3: Package ZIP ───────────────────────────────────────
    try:
        _OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        zip_path = package(mapping_name, bin3_json, _OUTPUT_DIR,
                           timestamp=_build_timestamp())
    except Exception as exc:
        logger.exception("Packaging failed.")
        return {
            "status": "error",
            "errors": [f"Packaging error: {exc}"],
        }

    msg = f"IDMC import ZIP created: {zip_path}"
    logger.info(msg)

    # Build a brief summary for the LLM
    content = json.loads(bin3_json) if isinstance(bin3_json, str) else bin3_json
    content = content.get("content", content)
    txs = content.get("transformations", [])
    summary = {
        "transformations": [
            {"name": t.get("name"), "class": t.get("$$class"), "fields": len(t.get("fields", []))}
            for t in txs
        ],
        "links": len(content.get("links", [])),
        "parameters": len(content.get("templateParameters", [])),
    }

    return {
        "status": "ok",
        "zip_path": str(zip_path),
        "message": msg,
        "summary": summary,
    }
