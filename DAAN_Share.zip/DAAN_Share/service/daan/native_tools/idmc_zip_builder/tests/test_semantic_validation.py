"""
Test the semantic / cross-referencing validations in validator.py.
Run:  .venv\\Scripts\\python.exe -m pytest tools/idmc_zip_builder/test_semantic_validation.py -v
"""
import sys
from pathlib import Path

_SERVICE_ROOT = Path(__file__).resolve().parents[4]  # service/
if str(_SERVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(_SERVICE_ROOT))

from daan.native_tools.idmc_zip_builder.validator import validate


def _base_spec(**overrides):
    """Minimal valid spec with 1 source → 1 target."""
    spec = {
        "mapping_name": "test",
        "transformations": [
            {"id": "Src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "A"}, {"name": "B"}]},
            {"id": "Tgt", "type": "Target", "object_name": "T2",
             "fields": [{"name": "X"}, {"name": "Y"}]},
        ],
        "links": [{"from": "Src", "to": "Tgt"}],
    }
    spec.update(overrides)
    return spec


# ── Joiner: condition field doesn't exist in upstream ──

def test_joiner_bad_master_field():
    spec = {
        "mapping_name": "join_test",
        "transformations": [
            {"id": "S1", "type": "Source", "object_name": "T1",
             "fields": [{"name": "CUST_ID"}, {"name": "NAME"}]},
            {"id": "S2", "type": "Source", "object_name": "T2",
             "fields": [{"name": "ORDER_ID"}, {"name": "CUST_REF"}]},
            {"id": "J", "type": "Joiner", "join_type": "NORMAL",
             "conditions": [{"master": "KUNNR", "detail": "CUST_REF"}],
             "fields": [{"name": "CUST_ID"}, {"name": "NAME"}, {"name": "ORDER_ID"}, {"name": "CUST_REF"}]},
            {"id": "Tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "CUST_ID"}, {"name": "ORDER_ID"}]},
        ],
        "links": [
            {"from": "S1", "to": "J"},
            {"from": "S2", "to": "J"},
            {"from": "J", "to": "Tgt"},
        ],
    }
    errors = validate(spec)
    assert any("KUNNR" in e and "does not exist" in e for e in errors), \
        f"Expected error about KUNNR not existing, got: {errors}"


def test_joiner_both_fields_from_same_source():
    spec = {
        "mapping_name": "join_same_src",
        "transformations": [
            {"id": "S1", "type": "Source", "object_name": "T1",
             "fields": [{"name": "KEY_A"}, {"name": "KEY_B"}]},
            {"id": "S2", "type": "Source", "object_name": "T2",
             "fields": [{"name": "OTHER"}]},
            {"id": "J", "type": "Joiner", "join_type": "NORMAL",
             "conditions": [{"master": "KEY_A", "detail": "KEY_B"}],
             "fields": [{"name": "KEY_A"}, {"name": "KEY_B"}, {"name": "OTHER"}]},
            {"id": "Tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "KEY_A"}]},
        ],
        "links": [
            {"from": "S1", "to": "J"},
            {"from": "S2", "to": "J"},
            {"from": "J", "to": "Tgt"},
        ],
    }
    errors = validate(spec)
    assert any("same upstream" in e for e in errors), \
        f"Expected error about same source, got: {errors}"


# ── Expression: field reference not in upstream ──

def test_expression_bad_field_ref():
    spec = {
        "mapping_name": "expr_test",
        "transformations": [
            {"id": "Src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "VKORG"}, {"name": "VTWEG"}]},
            {"id": "Expr", "type": "Expression",
             "fields": [
                 {"name": "OUT_VKORG", "expression": "IIF(XYZZY = '1', '2', VKORG)"},
             ]},
            {"id": "Tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "OUT_VKORG"}]},
        ],
        "links": [
            {"from": "Src", "to": "Expr"},
            {"from": "Expr", "to": "Tgt"},
        ],
    }
    errors = validate(spec)
    assert any("XYZZY" in e for e in errors), \
        f"Expected error about XYZZY, got: {errors}"


def test_expression_valid_field_ref():
    spec = {
        "mapping_name": "expr_ok",
        "transformations": [
            {"id": "Src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "VKORG"}, {"name": "VTWEG"}]},
            {"id": "Expr", "type": "Expression",
             "fields": [
                 {"name": "OUT_VKORG", "expression": "IIF(VKORG = '1000', '1100', VKORG)"},
             ]},
            {"id": "Tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "OUT_VKORG"}]},
        ],
        "links": [
            {"from": "Src", "to": "Expr"},
            {"from": "Expr", "to": "Tgt"},
        ],
    }
    errors = validate(spec)
    assert not errors, f"Expected no errors, got: {errors}"


# ── Filter: condition references non-existent field ──

def test_filter_bad_field_ref():
    spec = {
        "mapping_name": "filter_test",
        "transformations": [
            {"id": "Src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "STATUS"}, {"name": "AMT"}]},
            {"id": "Flt", "type": "Filter", "condition": "GHOST_FIELD > 0",
             "fields": [{"name": "STATUS"}, {"name": "AMT"}]},
            {"id": "Tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "STATUS"}]},
        ],
        "links": [
            {"from": "Src", "to": "Flt"},
            {"from": "Flt", "to": "Tgt"},
        ],
    }
    errors = validate(spec)
    assert any("GHOST_FIELD" in e for e in errors), \
        f"Expected error about GHOST_FIELD, got: {errors}"


# ── Aggregator: group_by field not in upstream ──

def test_aggregator_bad_group_by():
    spec = {
        "mapping_name": "agg_test",
        "transformations": [
            {"id": "Src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "REGION"}, {"name": "AMOUNT"}]},
            {"id": "Agg", "type": "Aggregator",
             "group_by": ["NONEXISTENT"],
             "fields": [
                 {"name": "REGION"},
                 {"name": "TOTAL", "expression": "SUM(AMOUNT)"},
             ]},
            {"id": "Tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "REGION"}, {"name": "TOTAL"}]},
        ],
        "links": [
            {"from": "Src", "to": "Agg"},
            {"from": "Agg", "to": "Tgt"},
        ],
    }
    errors = validate(spec)
    assert any("NONEXISTENT" in e for e in errors), \
        f"Expected error about NONEXISTENT, got: {errors}"


# ── Sorter: sort key not in upstream ──

def test_sorter_bad_sort_key():
    spec = {
        "mapping_name": "sort_test",
        "transformations": [
            {"id": "Src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "A"}, {"name": "B"}]},
            {"id": "Srt", "type": "Sorter",
             "sort_keys": [{"field": "MISSING", "direction": "ASC"}],
             "fields": [{"name": "A"}, {"name": "B"}]},
            {"id": "Tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "A"}]},
        ],
        "links": [
            {"from": "Src", "to": "Srt"},
            {"from": "Srt", "to": "Tgt"},
        ],
    }
    errors = validate(spec)
    assert any("MISSING" in e for e in errors), \
        f"Expected error about MISSING, got: {errors}"


# ── The original SAP STTM spec should still pass ──

def test_original_sap_spec_passes():
    spec = {
        "mapping_name": "SAP_ECC_to_S4HANA",
        "transformations": [
            {"id": "Source_KNA1", "type": "Source", "object_name": "KNA1", "connection_id": "SAP_ECC",
             "fields": [{"name": "KUNNR"}, {"name": "NAME1"}, {"name": "NAME2"},
                        {"name": "SORTL"}, {"name": "LAND1"}, {"name": "SPRAS"},
                        {"name": "STRAS"}, {"name": "ORT01"}, {"name": "PSTLZ"}, {"name": "REGIO"}]},
            {"id": "Source_KNVV", "type": "Source", "object_name": "KNVV", "connection_id": "SAP_ECC",
             "fields": [{"name": "VKORG"}, {"name": "VTWEG"}, {"name": "SPART"},
                        {"name": "PLTYP"}, {"name": "KALKS"}, {"name": "ZTERM"}]},
            {"id": "Expression_Transform", "type": "Expression",
             "fields": [
                 {"name": "VKORG", "expression": "IIF(VKORG IN ('1000','4000','4444','JP01'), '1100', IIF(VKORG LIKE 'TG%', '1710', VKORG))"},
                 {"name": "VTWEG", "expression": "IIF(VTWEG IN ('10','3A','N1'), '10', IIF(VTWEG LIKE 'T%', '20', VTWEG))"},
                 {"name": "SPART", "expression": "'00'"},
                 {"name": "ZTERM", "expression": "IIF(ZTERM IN ('0012','T20D','Z090'), 'Z001', ZTERM)"},
             ]},
            {"id": "Target_BUT000", "type": "Target", "object_name": "BUT000", "connection_id": "S4HANA",
             "fields": [{"name": "PARTNER"}, {"name": "NAME_ORG1"}, {"name": "NAME_ORG2"},
                        {"name": "SEARCHTERM1"}, {"name": "COUNTRY"}, {"name": "LANGUAGE"}]},
            {"id": "Target_ADRC", "type": "Target", "object_name": "ADRC", "connection_id": "S4HANA",
             "fields": [{"name": "STREET"}, {"name": "CITY1"}, {"name": "POST_CODE1"}, {"name": "REGION"}]},
            {"id": "Target_KNVV", "type": "Target", "object_name": "KNVV", "connection_id": "S4HANA",
             "fields": [{"name": "VKORG"}, {"name": "VTWEG"}, {"name": "SPART"},
                        {"name": "PRICE_LIST"}, {"name": "PRICING_PROC"}, {"name": "ZTERM"}]},
        ],
        "links": [
            {"from": "Source_KNA1", "to": "Target_BUT000"},
            {"from": "Source_KNA1", "to": "Target_ADRC"},
            {"from": "Source_KNVV", "to": "Expression_Transform"},
            {"from": "Expression_Transform", "to": "Target_KNVV"},
        ],
    }
    errors = validate(spec)
    assert not errors, f"Original SAP spec should pass, got: {errors}"


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
