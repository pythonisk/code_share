import sys
import json
from pathlib import Path

# Ensure `service/` is on sys.path
_SERVICE_ROOT = Path(__file__).resolve().parents[4]  # service/
if str(_SERVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(_SERVICE_ROOT))

from daan.native_tools.idmc_zip_builder.tool import build_idmc_zip

def main():
    if len(sys.argv) < 2:
        print("Usage: python build_from_json.py <path_to_json>")
        sys.exit(1)
        
    json_path = Path(sys.argv[1])
    if not json_path.exists():
        print(f"Error: File {json_path} does not exist.")
        sys.exit(1)
        
    with open(json_path, 'r') as f:
        spec = json.load(f)
        
    result = build_idmc_zip(spec)
    
    if result.get("status") == "ok":
        print(f"Success! ZIP created at: {result['zip_path']}")
        summary = result.get("summary", {})
        if summary:
            print("\nSummary:")
            for tx in summary.get("transformations", []):
                print(f"  - {tx['name']} ($$class {tx['class']}): {tx['fields']} fields")
    else:
        print("Failed to build ZIP!")
        for i, err in enumerate(result.get("errors", []), 1):
            print(f" {i}. {err}")
        if "hint" in result:
            print(f"Hint: {result['hint']}")
        sys.exit(1)

if __name__ == "__main__":
    main()
