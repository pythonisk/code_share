"""
batch_test_new_sttms.py — Batch test all new STTMs through the agent.

Runs each STTM through the LLM agent, captures the tool input spec,
builds the ZIP, and inspects it for correctness issues.

Saves:
  - tool_input JSON for each STTM in inputs/new_sttms/tool_inputs/
  - inspection report in tests/batch_results/
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

# Ensure `service/` is on sys.path
_SERVICE_ROOT = Path(__file__).resolve().parents[4]  # service/
_PROJECT_ROOT = _SERVICE_ROOT.parent                 # DAAN_5/
if str(_SERVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(_SERVICE_ROOT))

from dotenv import load_dotenv
load_dotenv(dotenv_path=_PROJECT_ROOT / "config" / ".env")

from daan.native_tools.idmc_zip_builder.tests.agent import run_agent, read_sttm
from daan.native_tools.idmc_zip_builder.tool import build_idmc_zip

_INPUTS_DIR = Path(__file__).resolve().parent.parent / "inputs" / "new_sttms"
_TOOL_INPUTS_DIR = _INPUTS_DIR / "tool_inputs"
_RESULTS_DIR = Path(__file__).resolve().parent / "batch_results"


def collect_sttms() -> list[Path]:
    """Collect all STTM files from new_sttms (root + Phase_1/2/3)."""
    sttms = []
    # Root-level STTMs
    for f in sorted(_INPUTS_DIR.glob("*.xlsx")):
        sttms.append(f)
    for f in sorted(_INPUTS_DIR.glob("*.csv")):
        sttms.append(f)
    # Phase subdirectories
    for phase in ["Phase_1", "Phase_2", "Phase_3"]:
        phase_dir = _INPUTS_DIR / phase
        if phase_dir.exists():
            for f in sorted(phase_dir.glob("*.xlsx")):
                sttms.append(f)
            for f in sorted(phase_dir.glob("*.csv")):
                sttms.append(f)
    return sttms


def extract_tool_input_from_log(log_dir: Path, sttm_stem: str) -> dict | None:
    """Extract the last successful tool input spec from the agent run log."""
    logs = sorted(log_dir.glob(f"run_*{sttm_stem}*.json"))
    if not logs:
        return None
    log = json.loads(logs[-1].read_text(encoding="utf-8"))
    
    # Find last tool call with a successful build
    last_spec = None
    for entry in log:
        if "tool_calls" in entry:
            tc = entry["tool_calls"][0]
            try:
                last_spec = json.loads(tc["function"]["arguments"])
            except (json.JSONDecodeError, KeyError):
                pass
    return last_spec


def run_single_test(sttm_path: Path, report: dict) -> dict:
    """Run a single STTM through the agent and collect results."""
    stem = sttm_path.stem
    print(f"\n{'='*70}")
    print(f"  TESTING: {sttm_path.name}")
    print(f"{'='*70}")
    
    result_entry = {
        "sttm": sttm_path.name,
        "phase": _get_phase(sttm_path),
        "status": "unknown",
        "attempts": 0,
        "issues": [],
        "tool_input_saved": False,
    }
    
    try:
        result = run_agent(sttm_path)
        result_entry["status"] = result.get("status", "error")
        
        if result.get("status") == "ok":
            result_entry["zip_path"] = result.get("zip_path", "")
            result_entry["summary"] = result.get("summary", {})
        else:
            result_entry["errors"] = result.get("errors", [])
        
        # Extract tool input from log
        log_dir = Path(__file__).resolve().parent / "agent_runs"
        spec = extract_tool_input_from_log(log_dir, stem)
        if spec:
            # Save tool input
            _TOOL_INPUTS_DIR.mkdir(parents=True, exist_ok=True)
            safe_name = stem.replace(" ", "_")
            tool_input_path = _TOOL_INPUTS_DIR / f"{safe_name}.json"
            tool_input_path.write_text(
                json.dumps(spec, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            result_entry["tool_input_saved"] = True
            result_entry["tool_input_path"] = str(tool_input_path)
            
            # Analyze the spec for common issues
            issues = analyze_spec(spec, sttm_path)
            result_entry["issues"] = issues
            
    except Exception as e:
        result_entry["status"] = "exception"
        result_entry["errors"] = [str(e)]
    
    return result_entry


def analyze_spec(spec: dict, sttm_path: Path) -> list[str]:
    """Analyze the LLM-generated spec for common issues."""
    issues = []
    
    txs = spec.get("transformations", [])
    links = spec.get("links", [])
    tx_map = {tx["id"]: tx for tx in txs}
    
    # Build link graph
    incoming = {}
    outgoing = {}
    for link in links:
        outgoing.setdefault(link["from"], []).append(link["to"])
        incoming.setdefault(link["to"], []).append(link["from"])
    
    # Issue 1: Source directly to Target without Expression when field names differ
    for link in links:
        from_tx = tx_map.get(link["from"])
        to_tx = tx_map.get(link["to"])
        if not from_tx or not to_tx:
            continue
        if from_tx.get("type") == "Source" and to_tx.get("type") == "Target":
            src_fields = {f["name"].upper() for f in from_tx.get("fields", [])}
            tgt_fields = {f["name"].upper() for f in to_tx.get("fields", [])}
            if src_fields != tgt_fields:
                diff = tgt_fields - src_fields
                if diff:
                    issues.append(
                        f"MISSING_RENAME_EXPR: Source '{from_tx['id']}' -> Target '{to_tx['id']}' "
                        f"has field name differences {sorted(diff)} but no Expression node for renaming"
                    )
    
    # Issue 2: LIKE operator used (not valid IDMC syntax)
    for tx in txs:
        for f in tx.get("fields", []):
            expr = f.get("expression", "")
            if " LIKE " in expr.upper():
                issues.append(
                    f"INVALID_LIKE: Node '{tx['id']}' field '{f['name']}' uses LIKE operator. "
                    f"IDMC does not support LIKE — use SUBSTR() or REG_MATCH() instead."
                )
        cond = tx.get("condition", "")
        if cond and " LIKE " in cond.upper():
            issues.append(
                f"INVALID_LIKE: Node '{tx['id']}' condition uses LIKE operator."
            )
    
    # Issue 3: Expression fields on Source or Target nodes
    for tx in txs:
        if tx.get("type") in ("Source", "Target"):
            for f in tx.get("fields", []):
                if f.get("expression"):
                    issues.append(
                        f"EXPR_ON_SOURCE_TARGET: {tx['type']} '{tx['id']}' field '{f['name']}' "
                        f"has an expression. Expressions belong in Expression nodes only."
                    )
    
    # Issue 4: IN() syntax check — LLM sometimes uses SQL syntax
    import re
    for tx in txs:
        for f in tx.get("fields", []):
            expr = f.get("expression", "")
            if re.search(r'\b\w+\s+IN\s*\(', expr, re.IGNORECASE):
                issues.append(
                    f"SQL_IN_SYNTAX: Node '{tx['id']}' field '{f['name']}' uses SQL-style "
                    f"'FIELD IN (...)' — IDMC syntax is IN(FIELD, ...)"
                )
        cond = tx.get("condition", "")
        if cond and re.search(r'\b\w+\s+IN\s*\(', cond, re.IGNORECASE):
            issues.append(
                f"SQL_IN_SYNTAX: Node '{tx['id']}' condition uses SQL-style IN syntax."
            )
    
    # Issue 5: Empty fields on pass-through nodes
    for tx in txs:
        if tx.get("type") in ("Filter", "Sorter") and len(tx.get("fields", [])) == 0:
            issues.append(
                f"EMPTY_PASSTHROUGH: {tx['type']} '{tx['id']}' has no fields. "
                f"Must list all pass-through fields."
            )
    
    # Issue 6: Target with multiple incoming links
    for tx in txs:
        if tx.get("type") == "Target":
            inbound = [l for l in links if l.get("to") == tx["id"]]
            if len(inbound) > 1:
                issues.append(
                    f"MULTI_INPUT_TARGET: Target '{tx['id']}' has {len(inbound)} incoming links. "
                    f"Targets should have exactly one."
                )
    
    # Issue 7: Router links missing from_group
    for link in links:
        from_tx = tx_map.get(link["from"])
        if from_tx and from_tx.get("type") == "Router" and "from_group" not in link:
            issues.append(
                f"MISSING_FROM_GROUP: Link from Router '{from_tx['id']}' to '{link['to']}' "
                f"missing 'from_group'."
            )
    
    # Issue 8: Joiner links missing to_group
    for link in links:
        to_tx = tx_map.get(link["to"])
        if to_tx and to_tx.get("type") == "Joiner" and "to_group" not in link:
            issues.append(
                f"MISSING_TO_GROUP: Link from '{link['from']}' to Joiner '{to_tx['id']}' "
                f"missing 'to_group' (Master/Detail)."
            )
    
    return issues


def _get_phase(sttm_path: Path) -> str:
    parts = sttm_path.parts
    for p in parts:
        if p.startswith("Phase_"):
            return p
    return "root"


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", help="Only test a specific phase (1, 2, 3, root)")
    parser.add_argument("--file", help="Test a single STTM file")
    parser.add_argument("--dry-run", action="store_true", help="List STTMs without testing")
    args = parser.parse_args()
    
    if args.file:
        sttms = [Path(args.file)]
    else:
        sttms = collect_sttms()
        if args.phase:
            phase_filter = f"Phase_{args.phase}" if args.phase != "root" else "root"
            sttms = [s for s in sttms if _get_phase(s) == phase_filter]
    
    print(f"Found {len(sttms)} STTM files to test:")
    for s in sttms:
        print(f"  [{_get_phase(s)}] {s.name}")
    
    if args.dry_run:
        return
    
    _RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    
    report = {"tests": [], "summary": {"total": 0, "ok": 0, "error": 0, "issues": 0}}
    
    for sttm in sttms:
        result = run_single_test(sttm, report)
        report["tests"].append(result)
        report["summary"]["total"] += 1
        if result["status"] == "ok":
            report["summary"]["ok"] += 1
        else:
            report["summary"]["error"] += 1
        if result.get("issues"):
            report["summary"]["issues"] += len(result["issues"])
        
        # Small delay between tests
        time.sleep(2)
    
    # Save report
    report_path = _RESULTS_DIR / "batch_report.json"
    report_path.write_text(
        json.dumps(report, indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )
    
    # Print summary
    print(f"\n{'='*70}")
    print(f"  BATCH TEST SUMMARY")
    print(f"{'='*70}")
    print(f"  Total: {report['summary']['total']}")
    print(f"  OK:    {report['summary']['ok']}")
    print(f"  Error: {report['summary']['error']}")
    print(f"  Issues found: {report['summary']['issues']}")
    
    for test in report["tests"]:
        status_icon = "✓" if test["status"] == "ok" else "✗"
        issues_str = f" ({len(test.get('issues', []))} issues)" if test.get("issues") else ""
        print(f"  {status_icon} [{test['phase']}] {test['sttm']} — {test['status']}{issues_str}")
        for issue in test.get("issues", []):
            print(f"      ! {issue}")
        for err in test.get("errors", []):
            print(f"      ERROR: {err[:120]}")
    
    print(f"\nReport saved to: {report_path}")


if __name__ == "__main__":
    main()
