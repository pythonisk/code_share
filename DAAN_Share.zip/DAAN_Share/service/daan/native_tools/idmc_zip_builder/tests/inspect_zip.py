"""
inspect_zip.py — Inspect a generated IDMC ZIP to verify mapping correctness.

Usage:
    python inspect_zip.py [path_to_zip]

If no path is given, inspects the latest ZIP in the output directory.
"""

import json
import io
import sys
import zipfile
from pathlib import Path


def inspect_zip(zip_path: Path):
    print(f"Inspecting: {zip_path.name}")
    print(f"Size: {zip_path.stat().st_size} bytes")

    with zipfile.ZipFile(zip_path) as outer:
        print("\nOuter ZIP Contents:")
        for info in outer.infolist():
            print(f"  {info.filename} ({info.file_size} bytes)")

        for name in outer.namelist():
            if name.endswith(".DTEMPLATE.zip"):
                dt_data = outer.read(name)
                with zipfile.ZipFile(io.BytesIO(dt_data)) as dt_zip:
                    print(f"\nDTEMPLATE Contents ({name}):")
                    for info in dt_zip.infolist():
                        print(f"  {info.filename} ({info.file_size} bytes)")

                    # Find @3.bin — may be at root or in bin/ subfolder
                    bin3_name = None
                    for zn in dt_zip.namelist():
                        if zn.endswith("@3.bin"):
                            bin3_name = zn
                            break
                    if not bin3_name:
                        print("ERROR: @3.bin not found in DTEMPLATE")
                        return

                    bin3_data = json.loads(dt_zip.read(bin3_name))
                    content = bin3_data.get("content", bin3_data)

                    txs = content.get("transformations", [])
                    print(f"\n{'='*70}")
                    print(f"  {len(txs)} TRANSFORMATIONS")
                    print(f"{'='*70}")

                    for tx in txs:
                        cls = tx.get("$$class")
                        name_tx = tx.get("name", "?")
                        fields = tx.get("fields", [])
                        tx_type = _class_to_type(cls)
                        print(f"\n  [{tx_type} class={cls}] {name_tx} ({len(fields)} fields)")

                        # Show adapter info for Source/Target/Lookup
                        adapter = tx.get("adapter")
                        if adapter:
                            data_obj = adapter.get("dataObject", {})
                            obj_name = data_obj.get("name", "?")
                            print(f"    object_name: {obj_name}")

                        # Show fields
                        for f in fields:
                            fname = f.get("name", "?")
                            expr = ""
                            # Expression fields (class 22)
                            if f.get("$$class") == 22:
                                expr = f" = {f.get('expression', '')}"
                            print(f"      {fname}{expr}")

                        # Show expression fields for Expression nodes
                        expr_fields = tx.get("expressionFields", [])
                        if expr_fields:
                            print(f"    Expression Fields:")
                            for ef in expr_fields:
                                ename = ef.get("name", "?")
                                eexpr = ef.get("expression", "?")
                                print(f"      {ename} = {eexpr}")

                        # Show filter condition
                        filter_cond = tx.get("filterCondition")
                        if filter_cond:
                            cond_text = filter_cond.get("condition", "?")
                            print(f"    Filter Condition: {cond_text}")

                        # Show join conditions
                        join_conds = tx.get("joinConditions", [])
                        if join_conds:
                            print(f"    Join Conditions:")
                            for jc in join_conds:
                                print(f"      {jc.get('masterField', '?')} = {jc.get('detailField', '?')}")

                        # Show aggregator group-by
                        group_by = tx.get("groupByFields")
                        if group_by:
                            gb_fields = group_by.get("fields", [])
                            print(f"    Group By: {[f.get('name') for f in gb_fields]}")

                    links = content.get("links", [])
                    print(f"\n{'='*70}")
                    print(f"  {len(links)} LINKS")
                    print(f"{'='*70}")
                    for link in links:
                        ln = link.get("name", "?")
                        print(f"  {ln}")

                    # Target manual mappings — the critical part
                    print(f"\n{'='*70}")
                    print(f"  TARGET MANUAL MAPPINGS (field-level wiring)")
                    print(f"{'='*70}")
                    for tx in txs:
                        if tx.get("$$class") == 12:  # Target
                            name_tx = tx.get("name", "?")
                            mm = tx.get("manualMappings", {})
                            ml = mm.get("mappingList", []) if mm else []
                            print(f"\n  Target: {name_tx} ({len(ml)} mappings)")
                            for m in ml:
                                sf = m.get("fromFieldName", "?")
                                tf_ref = m.get("toField", {})
                                # Resolve toField by finding the target field by $$ID
                                tf_id = tf_ref.get("##ID") if isinstance(tf_ref, dict) else None
                                tf_name = "?"
                                if tf_id:
                                    for f in tx.get("fields", []):
                                        if f.get("$$ID") == tf_id:
                                            tf_name = f.get("name", "?")
                                            break
                                print(f"    {sf} --> {tf_name}")

                    # Template parameters
                    params = content.get("templateParameters", [])
                    print(f"\n{'='*70}")
                    print(f"  {len(params)} TEMPLATE PARAMETERS")
                    print(f"{'='*70}")
                    for p in params:
                        pname = p.get("name", "?")
                        ptype_obj = p.get("paramType", {})
                        print(f"  {pname}")


def _class_to_type(cls):
    mapping = {
        7: "Source",
        8: "Joiner",
        9: "Filter",
        10: "Expression",
        11: "Lookup",
        12: "Target",
        42: "Aggregator",
        46: "Router",
        49: "Sorter",
        50: "Union",
    }
    return mapping.get(cls, f"Unknown({cls})")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        zip_path = Path(sys.argv[1])
    else:
        output_dir = Path(__file__).resolve().parent.parent / "output"
        zips = sorted(output_dir.glob("*-IDMC*.zip"))
        if not zips:
            print("No IDMC ZIPs found in output/")
            sys.exit(1)
        zip_path = zips[-1]

    if not zip_path.exists():
        print(f"Error: {zip_path} does not exist")
        sys.exit(1)

    inspect_zip(zip_path)
