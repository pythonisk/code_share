"""
agent.py — Orchestrating agent that reads an STTM file, calls an LLM
to produce a mapping spec, invokes the build_idmc_zip tool, and
handles validation errors by letting the LLM self-correct.

All messages (system, user, assistant, tool calls, tool responses) are
logged as JSON in the agent_runs/ folder for observability.
"""

from __future__ import annotations

import json
import os
import sys
import time
from datetime import datetime, timezone
from io import StringIO
from pathlib import Path
from typing import Any

import pandas as pd
from dotenv import load_dotenv
from openai import AzureOpenAI, OpenAI

# Ensure `service/` is on sys.path so that `daan.native_tools.idmc_zip_builder` is importable
_SERVICE_ROOT = Path(__file__).resolve().parents[4]  # service/
_PROJECT_ROOT = _SERVICE_ROOT.parent                 # DAAN_5/
if str(_SERVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(_SERVICE_ROOT))

# Load .env from project config
load_dotenv(dotenv_path=_PROJECT_ROOT / "config" / ".env")

from daan.native_tools.idmc_zip_builder.tool import build_idmc_zip
from daan.native_tools.idmc_zip_builder.schema import MAPPING_SPEC_SCHEMA

_PACKAGE_DIR = Path(__file__).resolve().parent.parent  # idmc_zip_builder/
_AGENT_RUNS_DIR = Path(__file__).resolve().parent / "agent_runs"
_AGENT_RUNS_DIR.mkdir(exist_ok=True)

# Maximum correction loops before giving up
MAX_RETRIES = 5


# ── LLM Client ──────────────────────────────────────────────────────

def _create_client():
    azure_key = os.getenv("AZURE_OPENAI_API_KEY")
    if azure_key:
        return AzureOpenAI(
            max_retries=0,
            timeout=float(os.getenv("LLM_TIMEOUT_SECONDS", "600")),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
            azure_endpoint=os.getenv("AZURE_OPENAI_API_BASE"),
        ), os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")

    openai_key = os.getenv("OPENAI_API_KEY")
    if openai_key:
        return OpenAI(api_key=openai_key), os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    raise RuntimeError(
        "No LLM API key. Set AZURE_OPENAI_API_KEY or OPENAI_API_KEY."
    )


# ── STTM reader ─────────────────────────────────────────────────────

_COLUMN_CANDIDATES = {
    "source_table": [
        "Source Table", "Source Object", "Source_Table", "SRC_TABLE", "Source",
    ],
    "source_field": [
        "Source Field", "Source Column", "Source Attribute", "SRC_COLUMN",
    ],
    "target_table": [
        "Target Table/Structure", "Target Table", "Target Object",
        "Target_Table", "TGT_TABLE", "Target",
    ],
    "target_field": [
        "Target Field", "Target Column", "Target Attribute", "TGT_COLUMN",
    ],
    "transformation_logic": [
        "Transformation/Rule", "Transformation Logic", "Logic",
        "Expression", "Business Rule", "Rule", "Comments",
    ],
}


def _pick(df: pd.DataFrame, candidates: list[str]) -> str | None:
    lower_map = {c.lower(): c for c in df.columns}
    for c in candidates:
        if c.lower() in lower_map:
            return lower_map[c.lower()]
    return None


def read_sttm(path: str | Path) -> str:
    """Read an STTM Excel/CSV into a compact CSV string for the LLM."""
    path = Path(path)
    if path.suffix.lower() in (".xlsx", ".xls"):
        df = pd.read_excel(path, sheet_name=0)
    else:
        df = pd.read_csv(path)

    # Rename to canonical columns
    rename_map: dict[str, str] = {}
    for canon, cands in _COLUMN_CANDIDATES.items():
        actual = _pick(df, cands)
        if actual and actual != canon:
            rename_map[actual] = canon

    df = df.rename(columns=rename_map)

    # Keep only columns that are useful
    keep = [c for c in df.columns if c in _COLUMN_CANDIDATES
            or c.lower() in {v.lower() for vs in _COLUMN_CANDIDATES.values() for v in vs}]
    if keep:
        df = df[keep]

    return df.to_csv(index=False)


# ── System prompt & tool definition ─────────────────────────────────

_RESOLVED_PROMPT_PATH = _PACKAGE_DIR / "resolved_prompts" / "idmc_zip_agent_prompt.md"

# Sentinel heading used to split prose instructions from JSON schema
_SCHEMA_HEADING = "## JSON Schema (mapping spec)"


def _load_system_prompt() -> str:
    """Build the system prompt dynamically from the canonical MD file.

    Everything *above* the ``## JSON Schema (mapping spec)`` heading is
    taken verbatim from the MD file (rules, common mistakes, etc.).
    The JSON schema section is then regenerated from
    ``MAPPING_SPEC_SCHEMA`` so that the two can never drift apart.
    """
    if not _RESOLVED_PROMPT_PATH.exists():
        raise FileNotFoundError(
            f"Resolved prompt file not found: {_RESOLVED_PROMPT_PATH}"
        )

    md_text = _RESOLVED_PROMPT_PATH.read_text(encoding="utf-8")

    # Split at the schema heading
    idx = md_text.find(_SCHEMA_HEADING)
    if idx == -1:
        raise ValueError(
            f"Could not find '{_SCHEMA_HEADING}' heading in {_RESOLVED_PROMPT_PATH}"
        )

    prose_part = md_text[:idx].rstrip()
    schema_json = json.dumps(MAPPING_SPEC_SCHEMA, indent=2)

    return f"{prose_part}\n\n{_SCHEMA_HEADING}\n```json\n{schema_json}\n```\n"

TOOL_DEF = {
    "type": "function",
    "function": {
        "name": "build_idmc_zip",
        "description": (
            "Builds an Informatica IDMC import ZIP from a mapping specification. "
            "Returns {status, zip_path} on success or {status, errors} on validation failure."
        ),
        "parameters": MAPPING_SPEC_SCHEMA,
    },
}


# ── Agent loop ──────────────────────────────────────────────────────

def run_agent(sttm_path: str | Path) -> dict[str, Any]:
    """
    Run the full agent loop:
      1. Read STTM
      2. Ask LLM to produce a mapping spec
      3. Execute build_idmc_zip tool
      4. If validation errors, feed them back to LLM (up to MAX_RETRIES)
      5. Log everything to agent_runs/

    Returns the final tool result dict.
    """
    sttm_path = Path(sttm_path)
    sttm_csv = read_sttm(sttm_path)
    client, model = _create_client()

    # Always load the prompt dynamically from the canonical MD file
    sys_prompt = _load_system_prompt()
    print(f"[AGENT] Loaded system prompt from: {_RESOLVED_PROMPT_PATH}")
    
    # Dump the fully constructed prompt to a file so the user can copy it
    dump_path = _RESOLVED_PROMPT_PATH.parent / "full_prompt_dump.md"
    dump_path.write_text(sys_prompt, encoding="utf-8")
    print(f"[AGENT] Wrote fully combined prompt to: {dump_path}")

    messages: list[dict[str, Any]] = [
        {"role": "system", "content": sys_prompt},
        {
            "role": "user",
            "content": (
                f"Here is the STTM for file '{sttm_path.name}'.\n\n"
                f"```csv\n{sttm_csv}\n```\n\n"
                "Analyse it and call the `build_idmc_zip` tool with the mapping spec."
            ),
        },
    ]

    # Conversation log for persistence
    log: list[dict] = []
    _log(log, messages[-2])  # system
    _log(log, messages[-1])  # user

    final_result: dict[str, Any] = {"status": "error", "errors": ["Agent did not complete."]}

    for attempt in range(1, MAX_RETRIES + 1):
        print(f"\n{'='*60}")
        print(f"[AGENT] Attempt {attempt}/{MAX_RETRIES}  —  calling LLM …")
        print(f"{'='*60}")

        try:
            response = client.chat.completions.create(
                model=model,
                messages=messages,
                tools=[TOOL_DEF],
                tool_choice={"type": "function", "function": {"name": "build_idmc_zip"}},
                temperature=0.0,
            )
        except Exception as api_err:
            err_msg = f"LLM API error: {api_err}"
            print(f"[AGENT] {err_msg}")
            if attempt < MAX_RETRIES:
                print("[AGENT] Retrying...")
                time.sleep(5)
                continue
            else:
                final_result = {"status": "error", "errors": [err_msg]}
                break

        assistant_msg = response.choices[0].message
        # Serialise for logging
        assistant_dict = _assistant_to_dict(assistant_msg)
        messages.append(assistant_dict)
        _log(log, assistant_dict)

        # Extract tool call
        if not assistant_msg.tool_calls:
            print("[AGENT] LLM did not produce a tool call. Retrying.")
            messages.append({
                "role": "user",
                "content": "You must call the build_idmc_zip tool. Try again.",
            })
            _log(log, messages[-1])
            continue

        tc = assistant_msg.tool_calls[0]
        try:
            spec = json.loads(tc.function.arguments)
        except json.JSONDecodeError as e:
            err_msg = f"Invalid JSON in tool arguments: {e}"
            print(f"[AGENT] {err_msg}")
            messages.append({
                "role": "tool",
                "tool_call_id": tc.id,
                "content": json.dumps({"status": "error", "errors": [err_msg]}),
            })
            _log(log, messages[-1])
            continue

        print(f"[AGENT] Received mapping spec with {len(spec.get('transformations', []))} transformations.")

        # Execute the tool
        result = build_idmc_zip(spec)
        result_json = json.dumps(result, indent=2)
        print(f"[TOOL]  Result: {result['status']}")

        messages.append({
            "role": "tool",
            "tool_call_id": tc.id,
            "content": result_json,
        })
        _log(log, messages[-1])

        if result["status"] == "ok":
            print(f"\n[AGENT] SUCCESS — {result.get('zip_path')}")
            final_result = result
            break
        else:
            err_summary = "\n".join(f"  - {e}" for e in result.get("errors", []))
            print(f"[AGENT] Validation errors:\n{err_summary}")

            if attempt < MAX_RETRIES:
                fix_prompt = (
                    "The tool returned validation errors:\n"
                    + "\n".join(result["errors"])
                    + "\n\nFix these errors and call build_idmc_zip again."
                )
                messages.append({"role": "user", "content": fix_prompt})
                _log(log, messages[-1])
            else:
                final_result = result

    # Persist conversation log
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    log_path = _AGENT_RUNS_DIR / f"run_{ts}_{sttm_path.stem}.json"
    log_path.write_text(json.dumps(log, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"\n[AGENT] Conversation log saved to: {log_path}")

    return final_result


# ── Logging helpers ──────────────────────────────────────────────────

def _log(log: list[dict], msg: dict):
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        **msg,
    }
    log.append(entry)


def _assistant_to_dict(msg) -> dict:
    """Convert an OpenAI ChatCompletionMessage to a plain dict."""
    d: dict[str, Any] = {"role": "assistant", "content": msg.content}
    if msg.tool_calls:
        d["tool_calls"] = [
            {
                "id": tc.id,
                "type": "function",
                "function": {
                    "name": tc.function.name,
                    "arguments": tc.function.arguments,
                },
            }
            for tc in msg.tool_calls
        ]
    return d


# ── CLI entry point ─────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="IDMC ZIP Builder Agent")
    parser.add_argument("--sttm", required=True, help="Path to STTM file (xlsx/csv)")
    args = parser.parse_args()

    result = run_agent(args.sttm)
    if result["status"] != "ok":
        print("\n[AGENT] FAILED.")
        for e in result.get("errors", []):
            print(f"  - {e}")
        sys.exit(1)
