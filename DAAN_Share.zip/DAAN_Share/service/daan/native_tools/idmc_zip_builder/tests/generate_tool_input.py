import argparse
import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

# Ensure `service/` is on sys.path so that `daan.native_tools.idmc_zip_builder` is importable
_SERVICE_ROOT = Path(__file__).resolve().parents[4]  # service/
_PROJECT_ROOT = _SERVICE_ROOT.parent                 # DAAN_5/
if str(_SERVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(_SERVICE_ROOT))

# Load .env from project config
load_dotenv(dotenv_path=_PROJECT_ROOT / "config" / ".env")

from daan.native_tools.idmc_zip_builder.tests.agent import (
    read_sttm,
    _create_client,
    SYSTEM_PROMPT,
    TOOL_DEF
)
from daan.native_tools.idmc_zip_builder.schema import MAPPING_SPEC_SCHEMA

def main():
    parser = argparse.ArgumentParser(description="Generate Tool Input JSON from STTM via LLM")
    parser.add_argument("--sttm", required=True, help="Path to STTM file (xlsx/csv)")
    parser.add_argument("--out", required=True, help="Path to save the generated JSON")
    args = parser.parse_args()

    sttm_path = Path(args.sttm)
    if not sttm_path.exists():
        print(f"Error: STTM file not found: {sttm_path}")
        sys.exit(1)

    sttm_csv = read_sttm(sttm_path)
    
    try:
        client, model = _create_client()
    except Exception as e:
         print(f"Error creating LLM client: {e}")
         sys.exit(1)

    # Load the resolved prompt from the canonical file
    _package_dir = Path(__file__).resolve().parent.parent  # idmc_zip_builder/
    _resolved_prompt_path = _package_dir / "resolved_prompts" / "idmc_zip_agent_prompt.md"
    if _resolved_prompt_path.exists():
        sys_prompt = _resolved_prompt_path.read_text(encoding="utf-8")
        print(f"Loaded resolved system prompt from: {_resolved_prompt_path}")
    else:
        schema_text = json.dumps(MAPPING_SPEC_SCHEMA, indent=2)
        sys_prompt = SYSTEM_PROMPT.replace("{schema}", schema_text)
        print("WARNING: Resolved prompt file not found, using inline SYSTEM_PROMPT")

    messages = [
        {"role": "system", "content": sys_prompt},
        {
            "role": "user",
            "content": (
                f"Here is the STTM for file '{sttm_path.name}'.\n\n"
                f"```csv\n{sttm_csv}\n```\n\n"
                "Analyse it and call the `build_idmc_zip` tool with the mapping spec."
            ),
        },
    ]

    print(f"Calling LLM ({model}) to generate tool input JSON...")
    try:
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            tools=[TOOL_DEF],
            tool_choice={"type": "function", "function": {"name": "build_idmc_zip"}},
            temperature=0.0,
        )
    except Exception as e:
        print(f"LLM API request failed: {e}")
        sys.exit(1)

    assistant_msg = response.choices[0].message

    if not assistant_msg.tool_calls:
        print("Failed: LLM did not produce a tool call with the mapping spec.")
        sys.exit(1)

    tc = assistant_msg.tool_calls[0]
    try:
        spec = json.loads(tc.function.arguments)
    except json.JSONDecodeError as e:
        print(f"Failed: Invalid JSON returned by the tool.\n{e}")
        sys.exit(1)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(spec, f, indent=2)

    print(f"Success! Generated tool input JSON saved at:\n{out_path.resolve()}")

if __name__ == "__main__":
    main()
