"""Quick smoke test for newly added validator checks."""
import sys
from pathlib import Path

_SERVICE_ROOT = Path(__file__).resolve().parents[4]
if str(_SERVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(_SERVICE_ROOT))

from daan.native_tools.idmc_zip_builder.validator import validate


def test_empty_filter_fields():
    spec = {
        "mapping_name": "test_empty_filter",
        "transformations": [
            {"id": "src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "A", "type": "string"}]},
            {"id": "flt", "type": "Filter", "condition": "A != 1", "fields": []},
            {"id": "tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "A", "type": "string"}]},
        ],
        "links": [{"from": "src", "to": "flt"}, {"from": "flt", "to": "tgt"}],
    }
    errs = validate(spec)
    assert any("Filter" in e and "no fields" in e for e in errs), f"Expected empty-filter error, got: {errs}"
    print("  PASS: empty Filter fields detected")


def test_empty_joiner_fields():
    spec = {
        "mapping_name": "test_empty_joiner",
        "transformations": [
            {"id": "s1", "type": "Source", "object_name": "T1",
             "fields": [{"name": "K", "type": "string"}]},
            {"id": "s2", "type": "Source", "object_name": "T2",
             "fields": [{"name": "K", "type": "string"}]},
            {"id": "j", "type": "Joiner", "join_type": "NORMAL",
             "conditions": [{"master": "K", "detail": "K"}], "fields": []},
            {"id": "tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "K", "type": "string"}]},
        ],
        "links": [
            {"from": "s1", "to": "j", "to_group": "Master"},
            {"from": "s2", "to": "j", "to_group": "Detail"},
            {"from": "j", "to": "tgt"},
        ],
    }
    errs = validate(spec)
    assert any("Joiner" in e and "no fields" in e for e in errs), f"Expected empty-joiner error, got: {errs}"
    print("  PASS: empty Joiner fields detected")


def test_empty_router_fields():
    spec = {
        "mapping_name": "test_empty_router",
        "transformations": [
            {"id": "src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "A", "type": "string"}]},
            {"id": "rtr", "type": "Router",
             "groups": [{"name": "G1", "condition": "A = 1"}], "fields": []},
            {"id": "tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "A", "type": "string"}]},
        ],
        "links": [
            {"from": "src", "to": "rtr"},
            {"from": "rtr", "to": "tgt", "from_group": "G1"},
        ],
    }
    errs = validate(spec)
    assert any("Router" in e and "no fields" in e for e in errs), f"Expected empty-router error, got: {errs}"
    print("  PASS: empty Router fields detected")


def test_concat_3_args():
    spec = {
        "mapping_name": "test_concat3",
        "transformations": [
            {"id": "src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "A", "type": "string"}, {"name": "B", "type": "string"}]},
            {"id": "expr", "type": "Expression", "fields": [
                {"name": "C", "type": "string", "expression": "CONCAT(A, ' ', B)"},
            ]},
            {"id": "tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "C", "type": "string"}]},
        ],
        "links": [{"from": "src", "to": "expr"}, {"from": "expr", "to": "tgt"}],
    }
    errs = validate(spec)
    assert any("CONCAT" in e and "exactly 2" in e for e in errs), f"Expected CONCAT error, got: {errs}"
    print("  PASS: CONCAT with 3 args detected")


def test_like_operator():
    spec = {
        "mapping_name": "test_like",
        "transformations": [
            {"id": "src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "CODE", "type": "string"}]},
            {"id": "flt", "type": "Filter", "condition": "CODE LIKE 'TG%'",
             "fields": [{"name": "CODE", "type": "string"}]},
            {"id": "tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "CODE", "type": "string"}]},
        ],
        "links": [{"from": "src", "to": "flt"}, {"from": "flt", "to": "tgt"}],
    }
    errs = validate(spec)
    assert any("LIKE" in e for e in errs), f"Expected LIKE error, got: {errs}"
    print("  PASS: LIKE operator detected")


def test_invalid_function_initcap():
    spec = {
        "mapping_name": "test_initcap",
        "transformations": [
            {"id": "src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "NAME", "type": "string"}]},
            {"id": "expr", "type": "Expression", "fields": [
                {"name": "NAME", "type": "string", "expression": "INITCAP(NAME)"},
            ]},
            {"id": "tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "NAME", "type": "string"}]},
        ],
        "links": [{"from": "src", "to": "expr"}, {"from": "expr", "to": "tgt"}],
    }
    errs = validate(spec)
    assert any("INITCAP" in e for e in errs), f"Expected INITCAP error, got: {errs}"
    print("  PASS: INITCAP invalid function detected")


def test_router_missing_from_group():
    spec = {
        "mapping_name": "test_router_grp",
        "transformations": [
            {"id": "src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "A", "type": "string"}]},
            {"id": "rtr", "type": "Router",
             "groups": [{"name": "G1", "condition": "A = 1"}],
             "fields": [{"name": "A", "type": "string"}]},
            {"id": "tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "A", "type": "string"}]},
        ],
        "links": [
            {"from": "src", "to": "rtr"},
            {"from": "rtr", "to": "tgt"},  # Missing from_group!
        ],
    }
    errs = validate(spec)
    assert any("from_group" in e for e in errs), f"Expected from_group error, got: {errs}"
    print("  PASS: Router missing from_group detected")


def test_direct_source_target_rename():
    spec = {
        "mapping_name": "test_rename",
        "transformations": [
            {"id": "src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "OLD_NAME", "type": "string"}]},
            {"id": "tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "NEW_NAME", "type": "string"}]},
        ],
        "links": [{"from": "src", "to": "tgt"}],
    }
    errs = validate(spec)
    assert any("not in source" in e.lower() or "Expression node" in e for e in errs), \
        f"Expected rename-without-expression error, got: {errs}"
    print("  PASS: direct Source->Target rename detected")


def test_sql_concat_operator():
    spec = {
        "mapping_name": "test_pipe_concat",
        "transformations": [
            {"id": "src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "A", "type": "string"}, {"name": "B", "type": "string"}]},
            {"id": "expr", "type": "Expression", "fields": [
                {"name": "C", "type": "string", "expression": "TRIM(A || ' ' || B)"},
            ]},
            {"id": "tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "C", "type": "string"}]},
        ],
        "links": [{"from": "src", "to": "expr"}, {"from": "expr", "to": "tgt"}],
    }
    errs = validate(spec)
    assert any("||" in e for e in errs), f"Expected || error, got: {errs}"
    print("  PASS: SQL || concat operator detected")


def test_passthrough_field_rename():
    spec = {
        "mapping_name": "test_passthrough_rename",
        "transformations": [
            {"id": "src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "CODE", "type": "string"}, {"name": "NAME", "type": "string"}]},
            {"id": "flt", "type": "Filter", "condition": "CODE != 'X'",
             "fields": [{"name": "CODE", "type": "string"}, {"name": "RENAMED", "type": "string"}]},
            {"id": "tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "CODE", "type": "string"}, {"name": "RENAMED", "type": "string"}]},
        ],
        "links": [{"from": "src", "to": "flt"}, {"from": "flt", "to": "tgt"}],
    }
    errs = validate(spec)
    assert any("RENAMED" in e and "do not exist" in e for e in errs), f"Expected passthrough rename error, got: {errs}"
    print("  PASS: passthrough field rename detected")


def test_invalid_function_trim():
    """TRIM() is not a valid IDMC function — use LTRIM(RTRIM(field))."""
    spec = {
        "mapping_name": "test_trim",
        "transformations": [
            {"id": "src", "type": "Source", "object_name": "T1",
             "fields": [{"name": "NAME", "type": "string"}]},
            {"id": "expr", "type": "Expression", "fields": [
                {"name": "NAME", "type": "string", "expression": "TRIM(NAME)"},
            ]},
            {"id": "tgt", "type": "Target", "object_name": "OUT",
             "fields": [{"name": "NAME", "type": "string"}]},
        ],
        "links": [{"from": "src", "to": "expr"}, {"from": "expr", "to": "tgt"}],
    }
    errs = validate(spec)
    assert any("TRIM" in e for e in errs), f"Expected TRIM error, got: {errs}"
    print("  PASS: TRIM invalid function detected")


if __name__ == "__main__":
    tests = [
        test_empty_filter_fields,
        test_empty_joiner_fields,
        test_empty_router_fields,
        test_concat_3_args,
        test_like_operator,
        test_invalid_function_initcap,
        test_router_missing_from_group,
        test_direct_source_target_rename,
        test_sql_concat_operator,
        test_passthrough_field_rename,
        test_invalid_function_trim,
    ]
    passed = 0
    failed = 0
    for t in tests:
        name = t.__name__
        try:
            t()
            passed += 1
        except AssertionError as e:
            print(f"  FAIL: {name}: {e}")
            failed += 1
        except Exception as e:
            print(f"  ERROR: {name}: {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)} tests")
