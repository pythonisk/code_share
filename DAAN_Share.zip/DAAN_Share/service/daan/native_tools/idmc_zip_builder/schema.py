"""
schema.py — Canonical JSON schema for the IDMC ZIP builder tool.

This is the single contract between the LLM and the tool.
The LLM produces a dict matching MAPPING_SPEC_SCHEMA; the tool
validates it, compiles it into IDMC artifacts, and packages a ZIP.

Supported transformation types:
  Source, Target, Expression, Filter, Joiner,
  Aggregator, Lookup, Router, Sorter, Union
"""

# Valid IDMC data types the tool understands.
VALID_DATA_TYPES = frozenset({
    "string", "integer", "float", "date", "timestamp", "decimal",
})

# Transformation types and their IDMC $$class codes.
TX_TYPE_CLASS = {
    "Source": 7,
    "Target": 12,
    "Expression": 10,
    "Filter": 9,
    "Joiner": 8,
    "Aggregator": 42,
    "Lookup": 11,
    "Router": 46,
    "Sorter": 49,
    "Union": 50,
}

VALID_TX_TYPES = frozenset(TX_TYPE_CLASS.keys())

VALID_JOIN_TYPES = frozenset({"NORMAL", "MASTER_OUTER", "DETAIL_OUTER", "FULL_OUTER"})

VALID_SORT_DIRECTIONS = frozenset({"ASC", "DESC"})


# ---------- JSON Schema (used both for documentation and validation) ----------

FIELD_SCHEMA = {
    "type": "object",
    "required": ["name"],
    "properties": {
        "name":       {"type": "string", "description": "Field name (must match physical column name for Source/Target)."},
        "type":       {"type": "string", "enum": sorted(VALID_DATA_TYPES), "default": "string",
                       "description": "Data type. Use 'string' for VARCHAR/CHAR, 'integer' for INT, 'decimal' for NUMBER with scale, 'date'/'timestamp' for date types."},
        "precision":  {"type": "integer", "default": 255, "description": "Max length or total digits."},
        "scale":      {"type": "integer", "default": 0, "description": "Decimal places (only for decimal type)."},
        "expression": {"type": "string",
                       "description": "IDMC expression using real functions (IIF, DECODE, CONCAT, etc.). "
                                      "Required for Expression/Aggregator fields. Must NOT be prose. "
                                      "For direct pass-through, omit this key entirely."},
        "from_field": {"type": "string",
                       "description": "Only for Target fields. Maps this target column to a differently-named "
                                      "upstream field (e.g. when an Expression renames FIELD to o_FIELD, set "
                                      "from_field to 'o_FIELD' on the corresponding Target field)."},
    },
}

JOINER_CONDITION_SCHEMA = {
    "type": "object",
    "required": ["master", "detail"],
    "properties": {
        "master": {"type": "string"},
        "detail": {"type": "string"},
    },
}

ROUTER_GROUP_SCHEMA = {
    "type": "object",
    "required": ["name"],
    "properties": {
        "name":      {"type": "string"},
        "condition": {"type": "string", "description": "Filter condition. Omit for DEFAULT group."},
    },
}

SORT_KEY_SCHEMA = {
    "type": "object",
    "required": ["field"],
    "properties": {
        "field":     {"type": "string"},
        "direction": {"type": "string", "enum": sorted(VALID_SORT_DIRECTIONS), "default": "ASC"},
    },
}

TRANSFORMATION_SCHEMA = {
    "type": "object",
    "required": ["id", "type", "fields"],
    "properties": {
        "id":            {"type": "string", "description": "Unique node identifier (e.g. 'Source_KNA1', 'Expression_Transform')."},
        "type":          {"type": "string", "enum": sorted(VALID_TX_TYPES),
                          "description": "Node type. Source=read from table, Target=write to table, "
                                         "Expression=row-level transform, Filter=drop rows, Joiner=merge 2 streams, "
                                         "Aggregator=group+agg, Lookup=side-table fetch, Router=conditional split, "
                                         "Sorter=order rows, Union=merge identical streams."},
        "object_name":   {"type": "string", "description": "Physical table/file name. Required for Source, Target, Lookup."},
        "fields":        {"type": "array", "items": FIELD_SCHEMA,
                          "description": "All fields this node produces. Source/Target: must match physical columns. "
                                         "Expression: include both transformed AND pass-through fields. Do NOT put 'expression' properties inside Source or Target nodes; use an Expression node for that."},
        # Joiner-specific
        "join_type":     {"type": "string", "enum": sorted(VALID_JOIN_TYPES),
                          "description": "NORMAL=inner, MASTER_OUTER=left, DETAIL_OUTER=right, FULL_OUTER=full outer."},
        "conditions":    {"type": "array", "items": JOINER_CONDITION_SCHEMA,
                          "description": "Join conditions. 'master' = field from first inbound link, 'detail' = field from second inbound link."},
        # Filter-specific
        "condition":     {"type": "string", "description": "Boolean IDMC expression (e.g. 'STATUS != ''DELETED''')."},
        # Aggregator-specific
        "group_by":      {"type": "array", "items": {"type": "string"},
                          "description": "Fields to group by. Must exist in upstream node."},
        # Lookup-specific
        "lookup_condition": {"type": "string", "description": "Lookup match condition. Use exact source names on both sides (e.g. 'CODE = CODE'), the builder will handle IN_ prefixes automatically. ANY field used on the left side of the condition (even for static filters like `STATIC_COL = 'VALUE'`) MUST be declared in the Lookup's 'fields' array, as IDMC reads it from the reference table."},
        "return_fields":    {"type": "array", "items": {"type": "string"},
                             "description": "Fields to return from the lookup table."},
        # Router-specific
        "groups":        {"type": "array", "items": ROUTER_GROUP_SCHEMA,
                          "description": "Named output groups. Each with optional filter condition."},
        # Sorter-specific
        "sort_keys":     {"type": "array", "items": SORT_KEY_SCHEMA,
                          "description": "Ordered list of sort keys with ASC/DESC direction."},
    },
}

LINK_SCHEMA = {
    "type": "object",
    "required": ["from", "to"],
    "properties": {
        "from":       {"type": "string", "description": "ID of the upstream node (data producer)."},
        "to":         {"type": "string", "description": "ID of the downstream node (data consumer)."},
        "from_group": {"type": "string",
                       "description": "Name of the output group on the upstream node. "
                                      "Required when upstream is a Router (specifies which output group this link uses)."},
        "to_group":   {"type": "string",
                       "description": "Name of the input group on the downstream node. "
                                      "Required when downstream is a Joiner — use 'Master' or 'Detail' to indicate which side."},
    },
}

MAPPING_SPEC_SCHEMA = {
    "type": "object",
    "required": ["mapping_name", "transformations", "links"],
    "properties": {
        "mapping_name":    {"type": "string",
                            "description": "Short alphanumeric mapping name (underscores OK, no spaces). Becomes the IDMC asset name."},
        "transformations": {"type": "array", "items": TRANSFORMATION_SCHEMA,
                            "description": "All nodes in the data-flow DAG. Must include at least one Source and one Target."},
        "links":           {"type": "array", "items": LINK_SCHEMA,
                            "description": "Edges connecting the nodes. Every node must appear in at least one link. "
                                           "Sources only in 'from', Targets only in 'to'. No cycles."},
    },
}
