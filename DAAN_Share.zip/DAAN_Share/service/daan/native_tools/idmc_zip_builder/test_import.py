"""
test_import.py — Automated IDMC import test for generated ZIPs.

Uses the existing informatica_idmc_importer utility to upload,
import, and check results. Reports success or errors.
"""

import json
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

# Ensure project root is on path and .env is loaded
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(_PROJECT_ROOT))
load_dotenv(_PROJECT_ROOT / ".env")

from utils.informatica_idmc_importer import import_idmc_package, IICSImportError


def main():
    # Determine which ZIP to test
    if len(sys.argv) > 1:
        zip_path = Path(sys.argv[1])
    else:
        output_dir = Path(__file__).resolve().parent / "output"
        zips = sorted(output_dir.glob("*-IDMC*.zip"))
        if not zips:
            print("No IDMC ZIPs found in output/")
            sys.exit(1)
        zip_path = zips[-1]

    print(f"[TEST] Importing: {zip_path}")
    print(f"[TEST] Size: {zip_path.stat().st_size} bytes")

    # Read IDMC credentials from env
    idmc_url = os.getenv("INFORMATICA_IDMC_URL", "")
    idmc_user = os.getenv("INFORMATICA_IDMC_USERNAME", "")
    idmc_pass = os.getenv("INFORMATICA_IDMC_PASSWORD", "")

    # Derive pod host from the identity-service URL
    from urllib.parse import urlparse
    parsed = urlparse(idmc_url)
    pod_host = f"https://{parsed.hostname}" if parsed.hostname else ""

    def on_progress(step: str, message: str):
        print(f"  [{step.upper()}] {message}")

    try:
        result = import_idmc_package(
            zip_path,
            pod_host=pod_host,
            username=idmc_user,
            password=idmc_pass,
            conflict_resolution="OVERWRITE",
            poll_interval_seconds=5,
            max_wait_seconds=120,
            on_progress=on_progress,
        )

        print(f"\n{'='*60}")
        print(f"RESULT: {result.final_state}")
        print(f"Job ID: {result.job_id}")
        print(f"Log URL: {result.log_url}")
        print(f"{'='*60}")

        # Save full result for debugging
        debug_path = Path(__file__).resolve().parent / "output" / "last_import_result.json"
        debug_path.write_text(
            json.dumps(result.final_payload, indent=2, default=str),
            encoding="utf-8",
        )
        print(f"\n[DEBUG] Full response saved to: {debug_path}")

        # Check for errors in the payload
        status = result.final_payload.get("status", {})
        if isinstance(status, dict):
            msgs = status.get("messages", [])
            for msg in msgs if isinstance(msgs, list) else []:
                print(f"  MSG: {msg}")

        if result.final_state in ("SUCCESS", "SUCCESSFUL", "SUCCEEDED", "COMPLETED"):
            # Now fetch the log to see individual object results
            try:
                import requests
                log_resp = requests.get(
                    result.log_url,
                    headers={"INFA-SESSION-ID": ""},  # session might be expired
                    timeout=30,
                )
                if log_resp.ok:
                    print(f"\n--- Import Log ---\n{log_resp.text[:2000]}")
            except Exception:
                pass
            print("\nIMPORT SUCCESSFUL!")
            sys.exit(0)
        else:
            print("\nIMPORT FAILED — check last_import_result.json for details")
            # Print the full payload for debugging
            print(json.dumps(result.final_payload, indent=2, default=str)[:3000])
            sys.exit(1)

    except IICSImportError as e:
        print(f"\n[ERROR] {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

