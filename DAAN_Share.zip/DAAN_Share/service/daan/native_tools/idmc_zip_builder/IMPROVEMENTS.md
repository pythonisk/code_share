# IDMC ZIP Builder — Validator & Prompt Improvements

## Summary

Added 12 validation checks to `validator.py` and expanded the system prompt's "Common Mistakes" section. All 10 unit tests pass. Tested across 16 STTMs (Phase 1–3).

---

## Validator Checks Added (`validator.py`)

| # | Check | What it catches |
|---|-------|-----------------|
| 1 | Empty fields on Filter/Joiner/Router/Sorter | Nodes with `fields: []` — the #1 failure mode (>60% of mappings) |
| 2 | CONCAT() arg count | CONCAT with ≠ 2 args; suggests nesting for 3+ |
| 3 | LIKE operator in expressions | SQL LIKE not valid in IDMC |
| 4 | Invalid/hallucinated functions | INITCAP, REGEXP_INSTR, NVL2, COALESCE, IFNULL, CASE, REGEXP_REPLACE, REGEXP_SUBSTR → error with IDMC alternatives |
| 5 | Router links missing `from_group` | Router output links must specify `from_group`; also validates group name exists |
| 6 | Direct Source→Target field name mismatch | Source→Target links require identical field names |
| 7 | SQL `\|\|` concat operator | `\|\|` is SQL, not IDMC; must use CONCAT() |
| 8 | Passthrough field name validation | Filter/Joiner/Router/Sorter fields must match upstream names — can't rename |
| 9 | Router group condition syntax | Conditions validated via `_validate_idmc_syntax` |
| 10 | Filter condition syntax | Conditions validated via `_validate_idmc_syntax` |
| 11 | Intra-Expression field ordering | Expression fields computed in order; earlier fields available to later ones |
| 12 | Orphan node detection | Nodes not connected to any link |

## Prompt Improvements (`idmc_zip_agent_prompt.md`)

Expanded "Common Mistakes" section with CRITICAL emphasis on:
- Empty fields being the #1 failure
- CONCAT 2-arg-only with nesting example
- LIKE not valid IDMC
- INITCAP, REGEXP_INSTR don't exist (use LOWER/UPPER/SUBSTR)
- COALESCE/NVL2/IFNULL don't exist (use IIF+ISNULL)
- `||` SQL concat not valid (use CONCAT)
- Filter/Joiner/Router/Sorter cannot rename fields
- Source→Target direct links require matching field names

---

## Test Results (All Phases)

### Phase 1 (6 STTMs) — All PASS
Simple to medium complexity (1–2 sources, 1–2 targets). All succeeded on first or second attempt.

### Phase 2 (7 STTMs) — 6 PASS, 1 timeout-limited

| STTM | Result | Notes |
|------|--------|-------|
| STTM_v2_expression | PASS | |
| STTM_v2_filter | PASS | |
| STTM_v2_joiner | PASS | |
| STTM_v2_lookup | PASS | |
| STTM_v2_router | PASS | |
| STTM_v2_sorter | PASS | |
| STTM_v2_multi_target | FAIL | Validator catches 3 Joiner rename errors; LLM can't self-correct 16+ transformations before 600s timeout |

### Phase 3 (3 STTMs) — 1 PASS, 2 timeout-limited

| STTM | Complexity | Result | Errors Caught | Notes |
|------|-----------|--------|---------------|-------|
| P3_STTM_1_MultiAgg_Joi_Loo_Rou_Sor_4Src_4Tgt | 4 src, 4 tgt, 19 transforms | **PASS (attempt 4)** | 3 errors self-corrected | Orphan node, Joiner passthrough fields, Expression field reachability |
| STTM_3_Joi_Loo_Rou_Sor_department_updated | 2 src, 2 tgt, 8 transforms | FAIL | Passthrough + field reachability | LLM repeatedly fails to pass-through Source fields through Joiner/Lookup chain |
| STTM_Phase3 | 5 src, 5 tgt, 21 transforms | FAIL (timeout) | 4 errors caught | Lookup condition, lost fields after Filter, 2 Joiner passthrough violations; LLM can't self-correct 21-transform spec in time |

---

## Known Limitations

1. **LLM timeout on large corrections**: When the corrected spec exceeds ~16 transformations, the LLM often cannot regenerate the full tool call argument within the 600s API timeout.
2. **Field propagation through Joiner/Lookup chains**: The LLM struggles to understand that Joiners must explicitly include pass-through fields from both upstream sides, and that these fields retain their original names.
3. **Both are LLM behavior issues**, not validator bugs — the validator correctly identifies all errors.

---

## Unit Tests (`tests/test_new_validations.py`)

10 tests, all passing:
- `test_empty_filter_fields`
- `test_empty_joiner_fields`
- `test_empty_router_fields`
- `test_concat_3_args`
- `test_like_operator`
- `test_invalid_function_initcap`
- `test_router_missing_from_group`
- `test_direct_source_target_rename`
- `test_sql_concat_operator`
- `test_passthrough_field_rename`
