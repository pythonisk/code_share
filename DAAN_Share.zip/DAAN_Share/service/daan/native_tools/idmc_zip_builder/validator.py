"""
validator.py — Validates a mapping spec dict against the IDMC schema.

Returns a list of human-readable error strings.  Empty list == valid.
Each error is phrased as an actionable instruction so the LLM can fix
the JSON and resubmit.
"""

from __future__ import annotations

import re
from collections import Counter
from typing import Any

from .schema import (
    VALID_DATA_TYPES,
    VALID_JOIN_TYPES,
    VALID_SORT_DIRECTIONS,
    VALID_TX_TYPES,
)

# Expressions that look like natural-language prose rather than IDMC syntax.
_PROSE_INDICATORS = [
    " the ", " from ", " into ", " using ", " based on ",
    " look up ", " concatenate ", " combine ", " check ",
    " retrieve ", " calculate ", " apply ",
]

# Known valid IDMC functions — anything else is flagged as suspect.
_KNOWN_IDMC_FUNCTIONS = {
    "IIF", "DECODE", "NVL", "CONCAT", "SUBSTR", "UPPER", "LOWER",
    "LPAD", "RPAD", "TO_CHAR", "TO_DATE", "TO_INTEGER", "TO_FLOAT",
    "TO_DECIMAL", "LTRIM", "RTRIM", "SUM", "AVG", "MIN", "MAX", "COUNT",
    "LENGTH", "ROUND", "TRUNC", "ABS", "MOD", "POWER", "SYSDATE",
    "SYSTIMESTAMP", "REG_EXTRACT", "REG_MATCH", "REPLACECHR", "REPLACESTR",
    "INSTR", "ERROR", "IN", "ISNULL", "IS_DATE", "IS_NUMBER", "IS_SPACES",
    "GET_DATE_PART", "ADD_TO_DATE", "DATE_DIFF", "SET_DATE_PART",
    "LAST_DAY", "REVERSE", "GREATEST", "LEAST",
}

# Functions that are NOT valid in IDMC but LLMs commonly hallucinate.
_INVALID_FUNCTIONS = {
    "INITCAP": "IDMC has no INITCAP. Use CONCAT(UPPER(SUBSTR(field,1,1)),LOWER(SUBSTR(field,2))) for Title Case.",
    "REGEXP_INSTR": "Use REG_MATCH(field, pattern) instead of REGEXP_INSTR.",
    "REGEXP_REPLACE": "Use REPLACECHR or REPLACESTR instead of REGEXP_REPLACE.",
    "REGEXP_SUBSTR": "Use REG_EXTRACT(field, pattern) instead of REGEXP_SUBSTR.",
    "NVL2": "IDMC has no NVL2. Use IIF(ISNULL(field), else_val, then_val).",
    "COALESCE": "Use nested NVL() calls instead of COALESCE.",
    "IFNULL": "Use NVL(field, default) instead of IFNULL.",
    "CASE": "Use IIF() or DECODE() instead of CASE/WHEN.",
    "TRIM": "IDMC has no TRIM. Use LTRIM(RTRIM(field)) instead.",
}


def validate(spec: dict[str, Any]) -> list[str]:
    """Run all validation rules and return a list of error strings."""
    errors: list[str] = []
    errors.extend(_validate_top_level(spec))
    if errors:
        return errors  # can't proceed if top-level is broken

    transformations = spec["transformations"]
    links = spec["links"]
    node_ids = {tx["id"] for tx in transformations}

    errors.extend(_validate_unique_ids(transformations))
    errors.extend(_validate_links(links, node_ids))
    errors.extend(_validate_dag_acyclic(links, node_ids))
    errors.extend(_validate_connectivity(links, node_ids))

    for tx in transformations:
        errors.extend(_validate_transformation(tx, links, node_ids))

    # Semantic / cross-referencing validations
    if not errors:
        tx_map = {tx["id"]: tx for tx in transformations}
        errors.extend(_validate_field_reachability(tx_map, links))
        errors.extend(_validate_router_link_groups(tx_map, links))
        errors.extend(_validate_direct_rename_links(tx_map, links))
        errors.extend(_validate_passthrough_field_names(tx_map, links))
        errors.extend(_validate_expression_collisions(tx_map, links))
        errors.extend(_validate_target_from_field(tx_map, links))
        errors.extend(_validate_numeric_type_safety(tx_map, links))
        errors.extend(_validate_topology_rules(tx_map, links))

    return errors


# ── Top-level structure ──────────────────────────────────────────────

def _validate_top_level(spec: dict) -> list[str]:
    errors: list[str] = []
    if not isinstance(spec, dict):
        return ["Spec must be a JSON object (dict)."]

    for key in ("mapping_name", "transformations", "links"):
        if key not in spec:
            errors.append(f"Missing required top-level key '{key}'.")

    if "mapping_name" in spec and not isinstance(spec["mapping_name"], str):
        errors.append("'mapping_name' must be a string.")
    if "mapping_name" in spec and not spec["mapping_name"].strip():
        errors.append("'mapping_name' must not be empty.")

    if "transformations" in spec and not isinstance(spec["transformations"], list):
        errors.append("'transformations' must be an array.")
    if "links" in spec and not isinstance(spec["links"], list):
        errors.append("'links' must be an array.")

    return errors


# ── Node ID uniqueness ───────────────────────────────────────────────

def _validate_unique_ids(transformations: list[dict]) -> list[str]:
    ids = [tx.get("id") for tx in transformations]
    counts = Counter(ids)
    return [
        f"Duplicate transformation id '{nid}' found {cnt} times. Each id must be unique."
        for nid, cnt in counts.items() if cnt > 1
    ]


# ── Links ────────────────────────────────────────────────────────────

def _validate_links(links: list[dict], node_ids: set[str]) -> list[str]:
    errors: list[str] = []
    for i, link in enumerate(links):
        if not isinstance(link, dict):
            errors.append(f"links[{i}] must be an object with 'from' and 'to' keys.")
            continue
        for key in ("from", "to"):
            if key not in link:
                errors.append(f"links[{i}] is missing required key '{key}'.")
            elif link[key] not in node_ids:
                errors.append(
                    f"links[{i}] references unknown node '{link[key]}'. "
                    f"Available nodes: {sorted(node_ids)}."
                )
    return errors


# ── DAG acyclicity ───────────────────────────────────────────────────

def _validate_dag_acyclic(links: list[dict], node_ids: set[str]) -> list[str]:
    adj: dict[str, list[str]] = {nid: [] for nid in node_ids}
    for link in links:
        src, dst = link.get("from"), link.get("to")
        if src in adj and dst in adj:
            adj[src].append(dst)

    WHITE, GRAY, BLACK = 0, 1, 2
    color = {n: WHITE for n in node_ids}
    path: list[str] = []

    def dfs(node: str) -> list[str] | None:
        color[node] = GRAY
        path.append(node)
        for nb in adj[node]:
            if color[nb] == GRAY:
                cycle_start = path.index(nb)
                cycle = path[cycle_start:] + [nb]
                return cycle
            if color[nb] == WHITE:
                result = dfs(nb)
                if result:
                    return result
        path.pop()
        color[node] = BLACK
        return None

    for n in node_ids:
        if color[n] == WHITE:
            cycle = dfs(n)
            if cycle:
                return [f"Cycle detected: {' -> '.join(cycle)}. The graph must be a DAG."]
    return []


# ── Connectivity ─────────────────────────────────────────────────────

def _validate_connectivity(links: list[dict], node_ids: set[str]) -> list[str]:
    linked_nodes: set[str] = set()
    for link in links:
        linked_nodes.add(link.get("from", ""))
        linked_nodes.add(link.get("to", ""))
    orphans = node_ids - linked_nodes
    return [
        f"Node '{nid}' is not connected to any other node. Add a link or remove it."
        for nid in sorted(orphans)
    ]


# ── Per-transformation validation ────────────────────────────────────

def _validate_transformation(
    tx: dict, links: list[dict], node_ids: set[str]
) -> list[str]:
    errors: list[str] = []
    nid = tx.get("id", "<unknown>")
    tx_type = tx.get("type")

    if "id" not in tx or not isinstance(tx["id"], str) or not tx["id"].strip():
        errors.append(f"Transformation missing or empty 'id'.")
        return errors
    if "type" not in tx:
        errors.append(f"Node '{nid}' missing 'type'.")
        return errors
    if tx_type not in VALID_TX_TYPES:
        errors.append(
            f"Node '{nid}' has unknown type '{tx_type}'. "
            f"Valid types: {sorted(VALID_TX_TYPES)}."
        )
        return errors

    # Fields
    fields = tx.get("fields")
    if not isinstance(fields, list):
        errors.append(f"Node '{nid}' 'fields' must be an array.")
    else:
        errors.extend(_validate_fields(nid, tx_type, fields))

    # Type-specific rules
    if tx_type == "Source":
        errors.extend(_validate_source(nid, tx, links))
    elif tx_type == "Target":
        errors.extend(_validate_target(nid, tx, links))
    elif tx_type == "Expression":
        errors.extend(_validate_expression(nid, tx))
    elif tx_type == "Filter":
        errors.extend(_validate_filter(nid, tx))
    elif tx_type == "Joiner":
        errors.extend(_validate_joiner(nid, tx, links))
    elif tx_type == "Aggregator":
        errors.extend(_validate_aggregator(nid, tx))
    elif tx_type == "Lookup":
        errors.extend(_validate_lookup(nid, tx))
    elif tx_type == "Router":
        errors.extend(_validate_router(nid, tx))
    elif tx_type == "Sorter":
        errors.extend(_validate_sorter(nid, tx))

    return errors


# ── Field-level validation ───────────────────────────────────────────

def _validate_fields(nid: str, tx_type: str, fields: list[dict]) -> list[str]:
    errors: list[str] = []
    if tx_type in ("Source", "Target") and len(fields) == 0:
        errors.append(f"{tx_type} '{nid}' must have at least 1 field.")

    # Pass-through nodes MUST list their fields so IDMC knows what to propagate
    if tx_type in ("Filter", "Sorter") and len(fields) == 0:
        errors.append(
            f"{tx_type} '{nid}' has no fields. You must list ALL pass-through fields "
            f"from the upstream node so they can flow to downstream nodes."
        )
    if tx_type == "Joiner" and len(fields) == 0:
        errors.append(
            f"Joiner '{nid}' has no fields. List all fields from both Master and Detail "
            f"sides that should be available to downstream nodes."
        )
    if tx_type == "Router" and len(fields) == 0:
        errors.append(
            f"Router '{nid}' has no fields. List all upstream fields that should be "
            f"available in the output groups."
        )

    names_seen: set[str] = set()
    for i, f in enumerate(fields):
        fname = f.get("name")
        if not fname or not isinstance(fname, str):
            errors.append(f"Node '{nid}' fields[{i}] missing or empty 'name'.")
            continue

        if fname.upper() in names_seen:
            errors.append(f"Node '{nid}' has duplicate field '{fname}'.")
        names_seen.add(fname.upper())

        dtype = f.get("type", "string")
        if dtype not in VALID_DATA_TYPES:
            errors.append(
                f"Node '{nid}' field '{fname}' has unknown type '{dtype}'. "
                f"Valid: {sorted(VALID_DATA_TYPES)}."
            )

    return errors


# ── Source ────────────────────────────────────────────────────────────

def _validate_source(nid: str, tx: dict, links: list[dict]) -> list[str]:
    errors: list[str] = []
    if not tx.get("object_name"):
        errors.append(f"Source '{nid}' missing 'object_name' (physical table/file name).")
    inbound = [l for l in links if l.get("to") == nid]
    if inbound:
        errors.append(f"Source '{nid}' must not have inbound links (it is a data origin).")
    return errors


# ── Target ───────────────────────────────────────────────────────────

def _validate_target(nid: str, tx: dict, links: list[dict]) -> list[str]:
    errors: list[str] = []
    if not tx.get("object_name"):
        errors.append(f"Target '{nid}' missing 'object_name' (physical table/file name).")
    outbound = [l for l in links if l.get("from") == nid]
    if outbound:
        errors.append(f"Target '{nid}' must not have outbound links (it is a data sink).")
    # Target must have at least one incoming link
    inbound = [l for l in links if l.get("to") == nid]
    if not inbound:
        errors.append(f"Target '{nid}' has no incoming links — it will receive no data.")
    return errors


# ── Expression ───────────────────────────────────────────────────────

def _validate_expression(nid: str, tx: dict) -> list[str]:
    errors: list[str] = []
    for f in tx.get("fields", []):
        expr = f.get("expression")
        if expr and _looks_like_prose(expr):
            errors.append(
                f"Expression '{nid}' field '{f['name']}' expression looks like natural language: "
                f"'{expr[:80]}...'. Provide a valid IDMC expression (e.g. CONCAT(A, B))."
            )
        if expr:
            errors.extend(_validate_idmc_syntax(nid, f["name"], expr))
    return errors


# ── Filter ───────────────────────────────────────────────────────────

def _validate_filter(nid: str, tx: dict) -> list[str]:
    errors: list[str] = []
    if not tx.get("condition"):
        errors.append(f"Filter '{nid}' missing 'condition' string.")
    elif _looks_like_prose(tx["condition"]):
        errors.append(
            f"Filter '{nid}' condition looks like natural language: '{tx['condition'][:80]}'. "
            f"Provide a valid IDMC filter expression."
        )
    else:
        errors.extend(_validate_idmc_syntax(nid, "condition", tx["condition"]))
    return errors


# ── Joiner ───────────────────────────────────────────────────────────

def _validate_joiner(nid: str, tx: dict, links: list[dict]) -> list[str]:
    errors: list[str] = []
    inbound = [l for l in links if l.get("to") == nid]
    if len(inbound) < 2:
        errors.append(
            f"Joiner '{nid}' has {len(inbound)} inbound link(s), needs at least 2 "
            f"(one master, one detail)."
        )
    jt = tx.get("join_type")
    if not jt:
        errors.append(f"Joiner '{nid}' missing 'join_type'. Use one of: {sorted(VALID_JOIN_TYPES)}.")
    elif jt not in VALID_JOIN_TYPES:
        errors.append(
            f"Joiner '{nid}' has invalid join_type '{jt}'. "
            f"Valid: {sorted(VALID_JOIN_TYPES)}."
        )
    conditions = tx.get("conditions")
    if not conditions or not isinstance(conditions, list) or len(conditions) == 0:
        errors.append(
            f"Joiner '{nid}' must have at least one condition (e.g. "
            f'{{"master": "KUNNR", "detail": "CUST_ID"}}).'
        )
    else:
        for i, c in enumerate(conditions):
            if not c.get("master"):
                errors.append(f"Joiner '{nid}' conditions[{i}] missing 'master' field name.")
            if not c.get("detail"):
                errors.append(f"Joiner '{nid}' conditions[{i}] missing 'detail' field name.")
    return errors


# ── Aggregator ───────────────────────────────────────────────────────

def _validate_aggregator(nid: str, tx: dict) -> list[str]:
    errors: list[str] = []
    gb = tx.get("group_by")
    if not gb or not isinstance(gb, list) or len(gb) == 0:
        errors.append(f"Aggregator '{nid}' missing 'group_by' array (at least one field).")
    agg_fields = [f for f in tx.get("fields", []) if f.get("expression")]
    if not agg_fields:
        errors.append(
            f"Aggregator '{nid}' must have at least one field with an 'expression' "
            f"(e.g. SUM(AMOUNT))."
        )
    return errors


# ── Lookup ───────────────────────────────────────────────────────────

def _validate_lookup(nid: str, tx: dict) -> list[str]:
    errors: list[str] = []
    if not tx.get("object_name"):
        errors.append(f"Lookup '{nid}' missing 'object_name' (lookup table/object).")
    if not tx.get("lookup_condition"):
        errors.append(f"Lookup '{nid}' missing 'lookup_condition' (e.g. 'CODE = IN_CODE').")
    rf = tx.get("return_fields")
    if not rf or not isinstance(rf, list) or len(rf) == 0:
        errors.append(f"Lookup '{nid}' missing 'return_fields' array (fields to return).")
    return errors


# ── Router ───────────────────────────────────────────────────────────

def _validate_router(nid: str, tx: dict) -> list[str]:
    errors: list[str] = []
    groups = tx.get("groups")
    if not groups or not isinstance(groups, list) or len(groups) < 1:
        errors.append(f"Router '{nid}' must have at least one group.")
    else:
        for i, g in enumerate(groups):
            if not g.get("name"):
                errors.append(f"Router '{nid}' groups[{i}] missing 'name'.")
            cond = g.get("condition", "")
            if cond:
                errors.extend(_validate_idmc_syntax(nid, f"group '{g.get('name', i)}'", cond))
    return errors


# ── Sorter ───────────────────────────────────────────────────────────

def _validate_sorter(nid: str, tx: dict) -> list[str]:
    errors: list[str] = []
    keys = tx.get("sort_keys")
    if not keys or not isinstance(keys, list) or len(keys) == 0:
        errors.append(f"Sorter '{nid}' missing 'sort_keys' array.")
    else:
        for i, k in enumerate(keys):
            if not k.get("field"):
                errors.append(f"Sorter '{nid}' sort_keys[{i}] missing 'field'.")
            direction = k.get("direction", "ASC")
            if direction not in VALID_SORT_DIRECTIONS:
                errors.append(
                    f"Sorter '{nid}' sort_keys[{i}] invalid direction '{direction}'. "
                    f"Use ASC or DESC."
                )
    return errors


# ══════════════════════════════════════════════════════════════════════
#  SEMANTIC / CROSS-REFERENCING VALIDATIONS
# ══════════════════════════════════════════════════════════════════════

def _get_field_names(tx: dict) -> set[str]:
    """Return the upper-cased field names declared on a transformation."""
    return {f["name"].upper() for f in tx.get("fields", []) if f.get("name")}


def _upstream_nodes(nid: str, links: list[dict]) -> list[str]:
    """Return the IDs of all nodes that feed *into* nid."""
    return [l["from"] for l in links if l.get("to") == nid]


def _downstream_nodes(nid: str, links: list[dict]) -> list[str]:
    """Return the IDs of all nodes that nid feeds *into*."""
    return [l["to"] for l in links if l.get("from") == nid]


def _available_upstream_fields(
    nid: str, tx_map: dict[str, dict], links: list[dict],
    _visited: set[str] | None = None,
) -> set[str]:
    """Collect the union of all field names reachable from upstream.

    For passthrough nodes (Expression, Filter, Sorter, Router), the effective
    output is their own explicit fields PLUS whatever flows through from their
    own upstream (TmplAllRule propagation).  We recurse through those.

    Also includes synthetic fields created by:
    - Joiner rename logic (``DETAIL_<field>`` when master==detail)
    - Aggregator group-by fields (they pass through automatically)
    """
    if _visited is None:
        _visited = set()

    fields: set[str] = set()
    passthrough_types = {"Expression", "Filter", "Sorter", "Router", "Lookup", "Joiner"}

    for up_id in _upstream_nodes(nid, links):
        if up_id in _visited:
            continue
        _visited.add(up_id)

        up_tx = tx_map.get(up_id)
        if not up_tx:
            continue

        fields |= _get_field_names(up_tx)

        # Passthrough types: their upstream fields also flow through
        if up_tx.get("type") in passthrough_types:
            fields |= _available_upstream_fields(up_id, tx_map, links, _visited)

        # Joiner rename: when master == detail, compiler renames to DETAIL_<field>
        if up_tx.get("type") == "Joiner":
            for cond in up_tx.get("conditions", []):
                m = cond.get("master", "")
                d = cond.get("detail", "")
                if m and d and m.upper() == d.upper():
                    fields.add(f"DETAIL_{d}".upper())

        # Aggregator: group-by fields pass through even though they're not
        # in the fields array (IDMC makes them available automatically)
        if up_tx.get("type") == "Aggregator":
            for gb in up_tx.get("group_by", []):
                fields.add(gb.upper())

    return fields


def _extract_identifiers(expr: str) -> set[str]:
    """Extract plausible field identifiers from an IDMC expression string.

    This is a best-effort tokeniser — it skips string literals, function
    names (followed by a paren), numbers, and known IDMC keywords.
    """
    import re

    _KEYWORDS = {
        "AND", "OR", "NOT", "IN", "LIKE", "IS", "NULL", "TRUE", "FALSE",
        "THEN", "ELSE", "END", "WHEN", "CASE", "IIF", "DECODE", "NVL",
        "CONCAT", "SUBSTR", "TRIM", "UPPER", "LOWER", "LPAD", "RPAD",
        "TO_CHAR", "TO_DATE", "TO_INTEGER", "TO_FLOAT", "TO_DECIMAL",
        "LTRIM", "RTRIM", "SUM", "AVG", "MIN", "MAX", "COUNT",
        "LENGTH", "ROUND", "TRUNC", "ABS", "MOD", "POWER",
        "SYSDATE", "SYSTIMESTAMP", "REG_EXTRACT", "REG_MATCH",
        "REPLACECHR", "REPLACESTR", "INSTR", "ERROR",
    }

    # Remove string literals to avoid false matches
    cleaned = re.sub(r"'[^']*'", "", expr)
    # Tokenise: word chars only
    tokens = re.findall(r"[A-Za-z_]\w*", cleaned)
    ids: set[str] = set()
    for i, tok in enumerate(tokens):
        upper = tok.upper()
        if upper in _KEYWORDS:
            continue
        # Skip function names (next non-space char is '(')
        rest = cleaned[cleaned.find(tok) + len(tok):].lstrip()
        if rest.startswith("("):
            continue
        # Skip pure numbers or very short (1-char) noise
        if tok.isdigit():
            continue
        ids.add(upper)
    return ids


def _validate_field_reachability(
    tx_map: dict[str, dict], links: list[dict],
) -> list[str]:
    """Cross-referencing semantic validations across the whole DAG."""
    errors: list[str] = []

    for nid, tx in tx_map.items():
        tx_type = tx.get("type", "")
        upstream_fields = _available_upstream_fields(nid, tx_map, links)

        # ── Joiner: condition fields must exist in upstream sources ──
        if tx_type == "Joiner":
            errors.extend(
                _validate_joiner_field_refs(nid, tx, tx_map, links)
            )

        # ── Expression: field refs in expressions should come from upstream ──
        # In IDMC, Expression fields are computed in order, so earlier fields
        # in the same node are available to later fields.
        if tx_type == "Expression" and upstream_fields:
            available = set(upstream_fields)  # copy
            for f in tx.get("fields", []):
                expr = f.get("expression", "")
                if not expr:
                    # pass-through field — still available downstream
                    available.add(f.get("name", "").upper())
                    continue
                refs = _extract_identifiers(expr)
                missing = refs - available
                if missing:
                    errors.append(
                        f"Expression '{nid}' field '{f['name']}' references "
                        f"{sorted(missing)} which are not in upstream fields "
                        f"{sorted(available)}."
                    )
                # This field is now available for subsequent fields
                available.add(f.get("name", "").upper())

        # ── Filter: condition field refs should come from upstream ──
        if tx_type == "Filter" and upstream_fields:
            cond = tx.get("condition", "")
            if cond:
                refs = _extract_identifiers(cond)
                missing = refs - upstream_fields
                if missing:
                    errors.append(
                        f"Filter '{nid}' condition references {sorted(missing)} "
                        f"which are not in upstream fields {sorted(upstream_fields)}."
                    )

        # ── Lookup: lookup_condition field refs ──
        if tx_type == "Lookup" and upstream_fields:
            cond = tx.get("lookup_condition", "")
            if cond:
                # Need to enforce left side belongs completely to the lookup fields, 
                # and right side to the upstream fields. But for now, catching missing fields
                # globally is what we do.
                refs = _extract_identifiers(cond)
                own_fields = _get_field_names(tx)
                known = upstream_fields | own_fields
                missing = refs - known
                if missing:
                    errors.append(
                        f"Lookup '{nid}' condition references {sorted(missing)} "
                        f"which are not in upstream or lookup fields."
                    )
                
                # Check 2: All referenced lookup-side fields (usually left side of `=`)
                # or any constant filters MUST be defined in "fields" because IDMC loads them
                # from the reference table metadata. 
                import re
                parts = re.split(r'\bAND\b|\bOR\b', cond, flags=re.IGNORECASE)
                for part in parts:
                    part = part.strip()
                    # e.g., LAND1 = IN_LAND1 or SPRSL = 'E'
                    m = re.match(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*(=|<>|!=|>=|<=|>|<)\s*(.*)$', part)
                    if m:
                        left_field = m.group(1).strip()
                        if left_field.upper() not in own_fields:
                            errors.append(
                                f"Lookup '{nid}' uses '{left_field}' as a lookup column in condition "
                                f"but it is not declared in the Lookup's 'fields' array."
                            )

        # ── Aggregator: group_by fields must be in upstream ──
        if tx_type == "Aggregator" and upstream_fields:
            for gb_field in tx.get("group_by", []):
                if gb_field.upper() not in upstream_fields:
                    errors.append(
                        f"Aggregator '{nid}' group_by field '{gb_field}' is not "
                        f"in upstream fields {sorted(upstream_fields)}."
                    )

        # ── Sorter: sort_keys must be in upstream ──
        if tx_type == "Sorter" and upstream_fields:
            for sk in tx.get("sort_keys", []):
                sk_field = sk.get("field", "")
                if sk_field.upper() not in upstream_fields:
                    errors.append(
                        f"Sorter '{nid}' sort key '{sk_field}' is not "
                        f"in upstream fields {sorted(upstream_fields)}."
                    )

    return errors


def _validate_joiner_field_refs(
    nid: str, tx: dict, tx_map: dict[str, dict], links: list[dict],
) -> list[str]:
    """Verify that Joiner condition fields actually exist in the upstream sources."""
    errors: list[str] = []
    conditions = tx.get("conditions", [])
    if not conditions:
        return errors

    inbound_ids = _upstream_nodes(nid, links)
    if len(inbound_ids) < 2:
        return errors  # structural validator already flags this

    # In IDMC, the *first* inbound is "master", subsequent are "detail".
    # Collect field sets per upstream node.
    upstream_field_sets = []
    for up_id in inbound_ids:
        if up_id in tx_map:
            upstream_field_sets.append(
                (up_id, _get_field_names(tx_map[up_id]))
            )

    # The union of all upstream fields
    all_upstream = set()
    for _, fs in upstream_field_sets:
        all_upstream |= fs

    for i, cond in enumerate(conditions):
        master_f = cond.get("master", "").upper()
        detail_f = cond.get("detail", "").upper()

        if master_f and master_f not in all_upstream:
            errors.append(
                f"Joiner '{nid}' conditions[{i}] master field '{cond['master']}' "
                f"does not exist in any upstream node. "
                f"Available: {sorted(all_upstream)}."
            )
        if detail_f and detail_f not in all_upstream:
            errors.append(
                f"Joiner '{nid}' conditions[{i}] detail field '{cond['detail']}' "
                f"does not exist in any upstream node. "
                f"Available: {sorted(all_upstream)}."
            )

    return errors


# ── Helpers ──────────────────────────────────────────────────────────

def _looks_like_prose(text: str) -> bool:
    """Heuristic: returns True if the text looks like natural language."""
    lower = text.lower()
    matches = sum(1 for p in _PROSE_INDICATORS if p in lower)
    return matches >= 2


# ── IDMC expression syntax checks ───────────────────────────────────

def _count_top_level_args(expr: str, func_name: str) -> int | None:
    """Count top-level comma-separated arguments inside func_name(...).

    Returns None if func_name is not found in expr.
    """
    pattern = re.compile(rf'\b{func_name}\s*\(', re.IGNORECASE)
    m = pattern.search(expr)
    if not m:
        return None
    start = m.end()  # position right after '('
    depth = 1
    args = 1
    i = start
    in_string = False
    while i < len(expr) and depth > 0:
        ch = expr[i]
        if ch == "'" and not in_string:
            in_string = True
        elif ch == "'" and in_string:
            in_string = False
        elif not in_string:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            elif ch == ',' and depth == 1:
                args += 1
        i += 1
    return args if depth == 0 else None


def _validate_idmc_syntax(nid: str, field_or_label: str, expr: str) -> list[str]:
    """Check an expression string for common IDMC syntax errors."""
    errors: list[str] = []

    # 1. CONCAT must take exactly 2 arguments
    arg_count = _count_top_level_args(expr, "CONCAT")
    if arg_count is not None and arg_count != 2:
        errors.append(
            f"Node '{nid}' {field_or_label}: CONCAT() takes exactly 2 arguments "
            f"but got {arg_count}. Nest calls instead, e.g. CONCAT(CONCAT(A, B), C)."
        )

    # 2. LIKE operator is not valid IDMC syntax
    if re.search(r'\bLIKE\b', expr, re.IGNORECASE):
        errors.append(
            f"Node '{nid}' {field_or_label}: 'LIKE' is not valid IDMC syntax. "
            f"Use SUBSTR(), INSTR(), or REG_MATCH() instead."
        )

    # 3. Check for invalid/hallucinated functions
    func_calls = re.findall(r'\b([A-Za-z_]\w*)\s*\(', expr)
    for func in func_calls:
        upper = func.upper()
        if upper in _INVALID_FUNCTIONS:
            errors.append(
                f"Node '{nid}' {field_or_label}: '{func}()' is not a valid IDMC function. "
                f"{_INVALID_FUNCTIONS[upper]}"
            )

    # 4. SQL concatenation operator || is not valid IDMC
    if '||' in expr:
        errors.append(
            f"Node '{nid}' {field_or_label}: '||' (SQL concat) is not valid IDMC syntax. "
            f"Use CONCAT(a, b) instead. For 3+ values nest: CONCAT(CONCAT(a, b), c)."
        )

    return errors


# ── Router link from_group check ─────────────────────────────────────

def _validate_router_link_groups(
    tx_map: dict[str, dict], links: list[dict],
) -> list[str]:
    """Every link FROM a Router must have a 'from_group' matching a declared group."""
    errors: list[str] = []
    router_ids = {nid for nid, tx in tx_map.items() if tx.get("type") == "Router"}

    for i, link in enumerate(links):
        from_id = link.get("from", "")
        if from_id not in router_ids:
            continue
        from_group = link.get("from_group")
        if not from_group:
            errors.append(
                f"links[{i}]: Link from Router '{from_id}' to '{link.get('to', '?')}' "
                f"is missing 'from_group'. Each outbound Router link must specify "
                f"which group it belongs to."
            )
        else:
            # Validate that the group name actually exists on the Router
            router_tx = tx_map[from_id]
            group_names = {
                g.get("name", "").upper()
                for g in router_tx.get("groups", [])
            }
            if from_group.upper() not in group_names:
                errors.append(
                    f"links[{i}]: from_group '{from_group}' on link from Router "
                    f"'{from_id}' does not match any declared group. "
                    f"Available groups: {sorted(group_names)}."
                )
    return errors


# ── Direct Source→Target rename detection ────────────────────────────

def _validate_direct_rename_links(
    tx_map: dict[str, dict], links: list[dict],
) -> list[str]:
    """Warn when Source links directly to Target but field names differ.

    If field names differ, the user likely forgot an Expression node for renaming.
    """
    errors: list[str] = []
    for link in links:
        from_id = link.get("from", "")
        to_id = link.get("to", "")
        from_tx = tx_map.get(from_id, {})
        to_tx = tx_map.get(to_id, {})
        if from_tx.get("type") != "Source" or to_tx.get("type") != "Target":
            continue
        src_fields = {f.get("name", "").upper() for f in from_tx.get("fields", []) if f.get("name")}
        tgt_fields = {f.get("name", "").upper() for f in to_tx.get("fields", []) if f.get("name")}
        only_in_target = tgt_fields - src_fields
        if only_in_target and len(only_in_target) > 0:
            errors.append(
                f"Source '{from_id}' is linked directly to Target '{to_id}' but "
                f"target has fields not in source: {sorted(only_in_target)}. "
                f"Add an Expression node between them for field renaming."
            )
    return errors


# ── Pass-through field name validation ───────────────────────────────

_PASSTHROUGH_TYPES = {"Filter", "Joiner", "Router", "Sorter"}


def _validate_passthrough_field_names(
    tx_map: dict[str, dict], links: list[dict],
) -> list[str]:
    """Fields on pass-through nodes must match upstream field names.

    Filter, Joiner, Router, and Sorter cannot rename fields — they only
    pass them through.  If a field name on one of these nodes doesn't
    exist upstream, the LLM likely tried to rename at the wrong node.
    """
    errors: list[str] = []
    for nid, tx in tx_map.items():
        tx_type = tx.get("type", "")
        if tx_type not in _PASSTHROUGH_TYPES:
            continue
        upstream = _available_upstream_fields(nid, tx_map, links)
        if not upstream:
            continue  # structural checks already flag disconnected nodes
        node_fields = {
            f.get("name", "").upper()
            for f in tx.get("fields", [])
            if f.get("name")
        }
        bad = node_fields - upstream
        if bad:
            errors.append(
                f"{tx_type} '{nid}' has fields {sorted(bad)} that do not exist "
                f"in any upstream node. {tx_type} nodes cannot rename fields — "
                f"use their original upstream names and add an Expression node "
                f"downstream for renaming. Available upstream fields: "
                f"{sorted(upstream)}."
            )
    return errors


# ── Expression output collision detection ────────────────────────────

def _validate_expression_collisions(
    tx_map: dict[str, dict], links: list[dict],
) -> list[str]:
    """Detect Expression output fields that collide with upstream field names.

    In IDMC, an Expression node uses TmplAllRule to pass ALL upstream
    fields through automatically.  If an Expression declares an output
    field with the SAME name as an upstream field, IDMC will reject
    the mapping with a "duplicate field name" error.

    The fix is to give the Expression output a unique name (e.g.
    ``o_FIELD``) and use ``from_field`` on the downstream Target to
    map it back to the desired target column name.
    """
    errors: list[str] = []

    for nid, tx in tx_map.items():
        if tx.get("type") != "Expression":
            continue

        upstream = _available_upstream_fields(nid, tx_map, links)
        if not upstream:
            continue

        for f in tx.get("fields", []):
            fname = f.get("name", "")
            expr = f.get("expression", "")
            if not expr:
                continue  # pass-through, not an output field

            # Identity expressions (field = field) are skipped by
            # the compiler — they don't create an output field.
            if expr.upper() == fname.upper():
                continue

            if fname.upper() in upstream:
                errors.append(
                    f"Expression '{nid}' output field '{fname}' collides with "
                    f"an upstream field of the same name. IDMC will reject this "
                    f"as a duplicate. Rename the Expression output to a unique "
                    f"name (e.g. 'o_{fname}') and add '\"from_field\": \"o_{fname}\"' "
                    f"on the corresponding Target field."
                )

    return errors


# ── Target from_field validation ─────────────────────────────────────

def _validate_target_from_field(
    tx_map: dict[str, dict], links: list[dict],
) -> list[str]:
    """Validate that Target fields with ``from_field`` reference a real upstream name.

    Also flag Target fields that have NO matching upstream name and no
    ``from_field`` override — these would silently map to nothing.
    """
    errors: list[str] = []

    for nid, tx in tx_map.items():
        if tx.get("type") != "Target":
            continue

        upstream = _available_upstream_fields(nid, tx_map, links)
        if not upstream:
            continue

        for f in tx.get("fields", []):
            fname = f.get("name", "")
            from_field = f.get("from_field", "")

            if from_field:
                if from_field.upper() not in upstream:
                    errors.append(
                        f"Target '{nid}' field '{fname}' has from_field='{from_field}' "
                        f"but '{from_field}' does not exist in upstream fields "
                        f"{sorted(upstream)}."
                    )
            else:
                if fname.upper() not in upstream:
                    errors.append(
                        f"Target '{nid}' field '{fname}' does not exist in "
                        f"upstream fields and has no 'from_field' override. "
                        f"Add 'from_field' pointing to the correct upstream "
                        f"field name, or ensure an upstream Expression creates "
                        f"a field with this exact name. "
                        f"Available upstream: {sorted(upstream)}."
                    )

    return errors


# ══════════════════════════════════════════════════════════════════════
#  NUMERIC TYPE SAFETY VALIDATIONS
# ══════════════════════════════════════════════════════════════════════

_NUMERIC_TYPES = {"integer", "decimal", "float"}

# IDMC active transformations (can change row count)
_ACTIVE_TX_TYPES = {"Aggregator", "Filter", "Joiner", "Router", "Sorter"}


def _collect_field_types(tx: dict) -> dict[str, str]:
    """Return {FIELD_NAME_UPPER: type_str} from a node's fields array."""
    return {
        f["name"].upper(): f.get("type", "string")
        for f in tx.get("fields", [])
        if f.get("name")
    }


def _available_upstream_field_types(
    nid: str, tx_map: dict[str, dict], links: list[dict],
    _visited: set[str] | None = None,
) -> dict[str, str]:
    """Collect {FIELD_NAME_UPPER: type} from all upstream nodes.

    Mirrors ``_available_upstream_fields`` but tracks declared types.
    """
    if _visited is None:
        _visited = set()

    types: dict[str, str] = {}
    passthrough_types = {"Expression", "Filter", "Sorter", "Router", "Lookup", "Joiner"}

    for up_id in _upstream_nodes(nid, links):
        if up_id in _visited:
            continue
        _visited.add(up_id)
        up_tx = tx_map.get(up_id)
        if not up_tx:
            continue

        # For passthrough types, first collect their upstream (flows through)
        if up_tx.get("type") in passthrough_types:
            upstream_of_up = _available_upstream_field_types(up_id, tx_map, links, _visited)
            for k, v in upstream_of_up.items():
                types.setdefault(k, v)

        # Then add/override with this node's own declared field types.
        # For passthrough nodes, only override if the field has an explicit
        # "type" key — otherwise inherit the upstream type (don't default
        # to "string" and clobber a numeric declaration from the Source).
        up_type = up_tx.get("type", "")
        for f in up_tx.get("fields", []):
            fname = f.get("name", "").upper()
            if not fname:
                continue
            if "type" in f:
                # Explicit type declaration — always honour it
                types[fname] = f["type"]
            elif up_type not in passthrough_types:
                # Non-passthrough (Source, Target) — default to string
                types.setdefault(fname, "string")
            # else: passthrough node, no explicit type → keep upstream type

        # Joiner detail-side rename
        if up_tx.get("type") == "Joiner":
            for cond in up_tx.get("conditions", []):
                m = cond.get("master", "")
                d = cond.get("detail", "")
                if m and d and m.upper() == d.upper():
                    det_type = types.get(d.upper(), "string")
                    types[f"DETAIL_{d}".upper()] = det_type

        # Aggregator: group-by fields
        if up_tx.get("type") == "Aggregator":
            for gb in up_tx.get("group_by", []):
                types.setdefault(gb.upper(), "string")

    return types


def _expression_has_arithmetic(expr: str) -> bool:
    """Return True if the expression uses arithmetic operators (*, /, +, -)."""
    cleaned = re.sub(r"'[^']*'", "", expr)  # strip string literals
    # * and / are unambiguously arithmetic
    if re.search(r'[*/]', cleaned):
        return True
    # + or - between two identifiers
    if re.search(r'\b[A-Za-z_]\w*\s*[-+]\s*[A-Za-z_]\w*\b', cleaned):
        return True
    return False


def _extract_arithmetic_field_refs(expr: str) -> set[str]:
    """Extract field names used as direct operands of arithmetic operators."""
    cleaned = re.sub(r"'[^']*'", "", expr)
    fields: set[str] = set()
    # FIELD * FIELD, FIELD / FIELD
    for m in re.finditer(r'\b([A-Za-z_]\w*)\s*[*/]\s*([A-Za-z_]\w*)', cleaned):
        fields.add(m.group(1).upper())
        fields.add(m.group(2).upper())
    # FIELD + FIELD, FIELD - FIELD
    for m in re.finditer(r'\b([A-Za-z_]\w*)\s*[-+]\s*([A-Za-z_]\w*)', cleaned):
        fields.add(m.group(1).upper())
        fields.add(m.group(2).upper())
    # Filter out function names and keywords
    fields -= _KNOWN_IDMC_FUNCTIONS
    fields -= {"AND", "OR", "NOT", "NULL", "TRUE", "FALSE", "IS", "ISNULL"}
    return fields


def _extract_aggregate_field_refs(expr: str) -> list[tuple[str, str]]:
    """Extract (function_name, field_name) for SUM/AVG aggregate functions."""
    results = []
    for m in re.finditer(r'\b(SUM|AVG)\s*\(\s*([A-Za-z_]\w*)\s*\)', expr, re.IGNORECASE):
        results.append((m.group(1).upper(), m.group(2).upper()))
    return results


def _extract_numeric_comparison_fields(expr: str) -> set[str]:
    """Extract field names compared to numeric literals in conditions."""
    cleaned = re.sub(r"'[^']*'", "", expr)
    fields: set[str] = set()
    # FIELD >= 100, FIELD > 100.5, etc.
    for m in re.finditer(
        r'\b([A-Za-z_]\w*)\s*(?:>=|<=|!=|<>|>|<|=)\s*(\d+(?:\.\d+)?)\b', cleaned
    ):
        fields.add(m.group(1).upper())
    # 100 >= FIELD (reversed)
    for m in re.finditer(
        r'\b(\d+(?:\.\d+)?)\s*(?:>=|<=|!=|<>|>|<|=)\s*([A-Za-z_]\w*)\b', cleaned
    ):
        fields.add(m.group(2).upper())
    fields -= {"AND", "OR", "NOT", "NULL"}
    return fields


def _validate_numeric_type_safety(
    tx_map: dict[str, dict], links: list[dict],
) -> list[str]:
    """Validate that fields used in numeric contexts are declared with numeric types.

    IDMC arithmetic operators (*, /, +, -) and aggregate functions (SUM, AVG)
    only work on numeric types (integer, decimal, float).  If a field is
    declared as 'string' (the default when type is omitted), IDMC throws
    "cannot convert the data to a number".
    """
    errors: list[str] = []

    for nid, tx in tx_map.items():
        tx_type = tx.get("type", "")
        upstream_types = _available_upstream_field_types(nid, tx_map, links)

        # ── Expression: arithmetic expressions ──────────────────────
        if tx_type == "Expression":
            local_types = dict(upstream_types)
            for f in tx.get("fields", []):
                fname = f.get("name", "").upper()
                ftype = f.get("type", "string")
                expr = f.get("expression", "")

                if expr and _expression_has_arithmetic(expr):
                    # Check output type
                    if ftype not in _NUMERIC_TYPES:
                        errors.append(
                            f"Expression '{nid}' field '{f['name']}' computes arithmetic "
                            f"but is declared as '{ftype}'. IDMC arithmetic requires numeric "
                            f"types. Add '\"type\": \"decimal\"' (or 'integer'/'float') to "
                            f"this field."
                        )
                    # Check referenced fields are numeric
                    arith_refs = _extract_arithmetic_field_refs(expr)
                    for ref in arith_refs:
                        ref_type = local_types.get(ref)
                        if ref_type is not None and ref_type not in _NUMERIC_TYPES:
                            errors.append(
                                f"Expression '{nid}' field '{f['name']}': arithmetic on "
                                f"'{ref}' which is type '{ref_type}'. IDMC cannot perform "
                                f"arithmetic on strings. Declare '{ref}' with a numeric type "
                                f"(decimal, integer, float) in its Source or upstream node."
                            )
                # Track this field's type for subsequent fields in same node
                local_types[fname] = ftype

        # ── Aggregator: SUM/AVG must operate on numeric fields ──────
        elif tx_type == "Aggregator":
            for f in tx.get("fields", []):
                expr = f.get("expression", "")
                if not expr:
                    continue
                agg_refs = _extract_aggregate_field_refs(expr)
                for func_name, field_name in agg_refs:
                    ref_type = upstream_types.get(field_name, "string")
                    if ref_type not in _NUMERIC_TYPES:
                        errors.append(
                            f"Aggregator '{nid}' field '{f['name']}': {func_name}({field_name}) "
                            f"but '{field_name}' is type '{ref_type}'. {func_name}() requires "
                            f"a numeric type. Declare '{field_name}' as 'decimal', 'integer', "
                            f"or 'float' in its Source or upstream Expression."
                        )

        # ── Filter / Router: numeric comparisons ────────────────────
        elif tx_type in ("Filter", "Router"):
            conditions_to_check: list[tuple[str, str]] = []
            if tx_type == "Filter":
                cond = tx.get("condition", "")
                if cond:
                    conditions_to_check.append(("condition", cond))
            else:
                for g in tx.get("groups", []):
                    cond = g.get("condition", "")
                    if cond:
                        conditions_to_check.append((f"group '{g.get('name', '?')}'", cond))

            for label, cond in conditions_to_check:
                num_fields = _extract_numeric_comparison_fields(cond)
                for field_name in num_fields:
                    ref_type = upstream_types.get(field_name, "string")
                    if ref_type not in _NUMERIC_TYPES:
                        errors.append(
                            f"{tx_type} '{nid}' {label}: compares '{field_name}' to a "
                            f"numeric literal but '{field_name}' is type '{ref_type}'. "
                            f"IDMC cannot compare string to number. Declare '{field_name}' "
                            f"as 'decimal', 'integer', or 'float' in its Source or "
                            f"upstream node."
                        )

    return errors


# ══════════════════════════════════════════════════════════════════════
#  TOPOLOGY RULES (Lookup, Target multi-input, active/passive)
# ══════════════════════════════════════════════════════════════════════

def _validate_topology_rules(
    tx_map: dict[str, dict], links: list[dict],
) -> list[str]:
    """Validate IDMC topology constraints.

    1. Lookup must have exactly 1 inbound link (the pipeline data).
       The reference table is read via ``object_name``, not a linked Source.
    2. Target must have exactly 1 inbound link.
    3. Passive transformations must not receive multiple inputs if any
       upstream is an active transformation.
    """
    errors: list[str] = []

    passive_types = {"Expression", "Lookup", "Target"}

    for nid, tx in tx_map.items():
        tx_type = tx.get("type", "")
        inbound = [l for l in links if l.get("to") == nid]

        # ── Lookup: exactly 1 inbound link ──────────────────────────
        if tx_type == "Lookup" and len(inbound) != 1:
            source_links = [
                l["from"] for l in inbound
                if tx_map.get(l.get("from"), {}).get("type") == "Source"
            ]
            hint = ""
            if source_links:
                hint = (
                    f" Remove the link(s) from {source_links} — a Lookup reads its "
                    f"reference table from 'object_name' ('{tx.get('object_name', '?')}'), "
                    f"not from a linked Source."
                )
            errors.append(
                f"Lookup '{nid}' has {len(inbound)} inbound link(s) but must have "
                f"exactly 1 (the pipeline data stream).{hint}"
            )

        # ── Target: exactly 1 inbound link ──────────────────────────
        if tx_type == "Target" and len(inbound) > 1:
            errors.append(
                f"Target '{nid}' has {len(inbound)} inbound links but must have "
                f"exactly 1. Merge multiple streams using a Joiner or Union "
                f"before the Target."
            )

        # ── Passive node with multiple active inputs ────────────────
        if tx_type in passive_types and len(inbound) > 1:
            active_upstreams = [
                l["from"] for l in inbound
                if tx_map.get(l.get("from"), {}).get("type") in _ACTIVE_TX_TYPES
            ]
            if active_upstreams:
                errors.append(
                    f"{tx_type} '{nid}' has {len(inbound)} inbound links with active "
                    f"upstream(s): {active_upstreams}. In IDMC, you cannot connect "
                    f"multiple upstream transformations to the same input group of "
                    f"a passive transformation if any is active. Merge streams with "
                    f"a Joiner or Union first."
                )

    return errors
