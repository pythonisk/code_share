"""
compiler.py — Deterministic @3.bin compiler.

Takes a validated mapping spec dict and produces the @3.bin JSON
string (the core IDMC mapping artifact).

No LLM calls.  Pure data transformation.
"""

from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from .id_registry import IDRegistry
from .schema import TX_TYPE_CLASS
from .field_utils import (
    build_fields_and_adapter,
    make_advanced_properties,
    make_expression_field,
    platform_type_ref,
    make_session_properties,
    make_tx_field,
)

_TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"

# IDMC $$classInfo — maps numeric class IDs to Java class names.
# Without this, IDMC cannot deserialize the JSON objects.
# Extracted from a known-good IDMC export.
_CLASS_INFO = {
    "1": "com.informatica.metadata.template.common.Template",
    "2": "com.informatica.metadata.common.description.Description",
    "3": "com.informatica.metadata.template.common.layout.LayoutAnnotation",
    "4": "com.informatica.metadata.common.genericannotation.GenericAnnotation",
    "5": "com.informatica.metadata.template.common.TmplLink",
    "6": "com.informatica.metadata.template.common.TmplGroup",
    "7": "com.informatica.metadata.template.tx.tmplsource.TmplSource",
    "8": "com.informatica.metadata.template.tx.tmpljoiner.TmplJoiner",
    "9": "com.informatica.metadata.template.tx.tmplfilter.TmplFilter",
    "10": "com.informatica.metadata.template.tx.tmplexpression.TmplExpression",
    "11": "com.informatica.metadata.template.tx.tmpllookup.TmplLookup",
    "12": "com.informatica.metadata.template.tx.tmpltarget.TmplTarget",
    "13": "com.informatica.metadata.common.genericannotation.NameValuePair",
    "14": "com.informatica.metadata.template.common.TxAdvancedProperty",
    "15": "com.informatica.metadata.template.common.TxSessionProperty",
    "16": "com.informatica.metadata.template.ext.da.cloud.common.BaseAdapter",
    "17": "com.informatica.metadata.template.common.field.TxField",
    "18": "com.informatica.metadata.template.ext.da.cloud.common.BaseAdapterField",
    "19": "com.informatica.metadata.common.typesystem.DataType",
    "20": "com.informatica.metadata.template.tx.tmpltarget.FieldMappings",
    "21": "com.informatica.metadata.template.tx.tmpljoiner.JoinCondition",
    "22": "com.informatica.metadata.template.tx.tmplexpression.TmplExpressionField",
    "23": "com.informatica.metadata.template.tx.tmplexpression.TmplExpressionWindowSpec",
    "24": "com.informatica.metadata.template.tx.tmplfilter.FilterCondition",
    "25": "com.informatica.metadata.template.tx.tmpllookup.LookupCondition",
    "26": "com.informatica.metadata.common.types.StringValue",
    "27": "com.informatica.metadata.common.types.BooleanValue",
    "28": "com.informatica.metadata.template.ext.da.cloud.common.LocalObjectDesignConfig",
    "29": "com.informatica.metadata.template.ext.da.cloud.common.DataObject",
    "30": "com.informatica.metadata.template.ext.da.cloud.common.RuntimeAttributes",
    "31": "com.informatica.metadata.template.ext.da.cloud.common.ReadOptions",
    "32": "com.informatica.metadata.template.common.rule.TmplAllRule",
    "33": "com.informatica.metadata.template.ext.da.cloud.common.BulkOptions",
    "34": "com.informatica.metadata.template.ext.da.cloud.common.WriteOptions",
    "35": "com.informatica.metadata.template.tx.tmpltarget.FieldMapping",
    "36": "com.informatica.metadata.template.common.rule.TmplNameRule",
    "37": "com.informatica.metadata.template.common.ConflictResolution",
    "38": "com.informatica.metadata.template.ext.da.cloud.common.FlatFileAttrs",
    "39": "com.informatica.metadata.template.common.rule.TmplNameRuleEntry",
    "40": "com.informatica.metadata.template.ext.da.cloud.common.Option",
    "41": "com.informatica.metadata.template.common.BulkRenameOption",
    "42": "com.informatica.metadata.template.tx.tmplaggregator.TmplAggregator",
    "43": "com.informatica.metadata.template.tx.tmplaggregator.TmplAggregatorField",
    "44": "com.informatica.metadata.template.tx.tmplaggregator.TmplAggregatorGroupByFields",
    "45": "com.informatica.metadata.template.tx.tmplaggregator.TmplAggregatorGroupByField",
    "46": "com.informatica.metadata.template.tx.tmplrouter.TmplRouter",
    "47": "com.informatica.metadata.template.tx.tmplrouter.GroupFilterCondition",
    "48": "com.informatica.metadata.template.tx.tmplrouter.SimpleFilterCondition",
    "49": "com.informatica.metadata.template.tx.tmplsorter.TmplSorter",
    "50": "com.informatica.metadata.template.tx.tmplunion.TmplUnion",
    "51": "com.informatica.metadata.template.tx.tmplunion.TmplUnionGroup",
    "52": "com.informatica.metadata.template.tx.tmplsorter.SortEntry",
    "60": "com.informatica.metadata.template.common.param.TmplParam",
    "61": "com.informatica.metadata.template.common.param.ConnectionParamType",
    "62": "com.informatica.metadata.template.common.param.DataObjectParamType",
    "63": "com.informatica.metadata.template.common.param.ExpressionParamType",
}

_TEMPLATE_FILES = {
    "Source":      "TmplSource_class_7.json",
    "Target":      "TmplTarget_class_12.json",
    "Expression":  "TmplExpression_class_10.json",
    "Filter":      "TmplFilter_class_9.json",
    "Joiner":      "TmplJoiner_class_8.json",
    "Aggregator":  "TmplAggregator_class_42.json",
    "Lookup":      "TmplLookup_class_11.json",
    "Router":      "TmplRouter_class_46.json",
    "Sorter":      "TmplSorter_class_10.json",
    "Union":       "TmplUnion_class_10.json",
}

# Cached templates
_CACHE: dict[str, dict] = {}


def _load_template(tx_type: str) -> dict:
    if tx_type in _CACHE:
        return deepcopy(_CACHE[tx_type])
    fname = _TEMPLATE_FILES.get(tx_type)
    if not fname:
        raise ValueError(f"No template for transformation type '{tx_type}'.")
    path = _TEMPLATES_DIR / fname
    if not path.exists():
        raise FileNotFoundError(f"Template file not found: {path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    _CACHE[tx_type] = data
    return deepcopy(data)


def _deep_reid_template(obj: Any, reg: IDRegistry) -> None:
    """Recursively replace ALL $$ID values in a template with fresh IDs.

    Also updates ##ID references to match. This prevents duplicate $$IDs
    when the same template is instantiated multiple times (e.g. two Targets).
    """
    id_map: dict[int, int] = {}

    def _collect(node: Any) -> None:
        if isinstance(node, dict):
            if "$$ID" in node and isinstance(node["$$ID"], int):
                old = node["$$ID"]
                if old not in id_map:
                    id_map[old] = reg.next_id()
            for v in node.values():
                _collect(v)
        elif isinstance(node, list):
            for item in node:
                _collect(item)

    def _rewrite(node: Any) -> None:
        if isinstance(node, dict):
            if "$$ID" in node:
                old = node["$$ID"]
                if isinstance(old, int) and old in id_map:
                    node["$$ID"] = id_map[old]
            if "##ID" in node:
                ref = node["##ID"]
                if isinstance(ref, int) and ref in id_map:
                    node["##ID"] = id_map[ref]
            for v in node.values():
                _rewrite(v)
        elif isinstance(node, list):
            for item in node:
                _rewrite(item)

    _collect(obj)
    _rewrite(obj)


def _spec_upstream_fields(
    node_id: str,
    spec_by_id: dict[str, dict],
    upstream_map: dict[str, list[str]],
    _cache: dict[str, set[str]] | None = None,
) -> set[str]:
    """Return the set of UPPER-cased field names available upstream of *node_id*.

    Traces through the spec-level DAG.  Passthrough types (Expression,
    Filter, Sorter, Router) propagate their upstream fields plus their own.
    """
    if _cache is None:
        _cache = {}
    if node_id in _cache:
        return _cache[node_id]

    result: set[str] = set()
    for up_id in upstream_map.get(node_id, []):
        up_tx = spec_by_id.get(up_id, {})
        for f in up_tx.get("fields", []):
            result.add(f["name"].upper())
        if up_tx.get("type") in {"Expression", "Filter", "Sorter", "Router", "Lookup"}:
            result.update(_spec_upstream_fields(up_id, spec_by_id, upstream_map, _cache))

    _cache[node_id] = result
    return result


def compile_3bin(spec: dict[str, Any]) -> str:
    """Compile a validated mapping spec into @3.bin JSON string."""
    reg = IDRegistry()
    mapping_name = spec["mapping_name"]
    transformations_spec = spec["transformations"]
    links_spec = spec["links"]

    # Pre-compute spec-level upstream field names for collision detection
    spec_by_id: dict[str, dict] = {t["id"]: t for t in transformations_spec}
    up_map: dict[str, list[str]] = {}
    for link in links_spec:
        up_map.setdefault(link["to"], []).append(link["from"])
    _upstream_cache: dict[str, set[str]] = {}

    idmc_transformations: list[dict] = []
    idmc_links: list[dict] = []

    # Map spec node IDs to their compiled IDMC objects (for link wiring)
    node_id_to_idmc: dict[str, dict] = {}

    # Track field renames: {node_id: {ORIGINAL_UPPER: renamed_name}}
    # Only Lookup nodes produce renames (structural IDMC conflict resolution).
    node_renames: dict[str, dict[str, str]] = {}

    for tx in transformations_spec:
        upstream_fields: set[str] | None = None
        if tx["type"] == "Lookup":
            upstream_fields = _spec_upstream_fields(
                tx["id"], spec_by_id, up_map, _upstream_cache,
            )
        idmc_obj, renames = _compile_transformation(reg, tx, upstream_fields)
        node_id_to_idmc[tx["id"]] = idmc_obj
        idmc_transformations.append(idmc_obj)
        if renames:
            node_renames[tx["id"]] = renames

    # Build IDMC link objects
    for link in links_spec:
        from_id = link["from"]
        to_id = link["to"]
        from_obj = node_id_to_idmc[from_id]
        to_obj = node_id_to_idmc[to_id]

        link_name = f"{from_id} -> {to_id}"
        from_group_name = link.get("from_group")
        to_group_name = link.get("to_group")
        idmc_link = _build_link(reg, from_obj, to_obj, link_name,
                                from_group_name=from_group_name,
                                to_group_name=to_group_name)
        idmc_links.append(idmc_link)

    # Post-process: populate Target manualMappings now that links exist
    _populate_target_manual_mappings(
        reg, links_spec, node_id_to_idmc, transformations_spec,
        node_renames,
    )

    # Build template parameters for connection/object parameterization
    parameters = _build_template_params(reg, idmc_transformations)

    # Assemble top-level @3.bin
    content_iid = reg.next_id()

    bin3 = {
        "content": {
            "$$IID": content_iid,
            "$$class": 1,
            "annotations": [],
            "allowMaxFieldLength": "false",
            "bigIntConvertType": "ONLY_BIGINT",
            "documentType": "MAPPING",
            "ecoSystem": "",
            "name": mapping_name,
            "specialCharacterSupport": "false",
            "templateOrigin": "",
            "links": idmc_links,
            "transformations": idmc_transformations,
            "parameters": parameters,
        },
        "metadata": {
            "$$classInfo": _CLASS_INFO,
        },
    }

    return json.dumps(bin3, indent=2, ensure_ascii=False)


# ── Template parameters ──────────────────────────────────────────────

def _build_template_params(
    reg: IDRegistry, transformations: list[dict],
) -> list[dict]:
    """Create template-level parameters and wire connectionId$ references.

    IDMC uses template parameters ($$class 60) so that connections and
    objects can be supplied at runtime. Source, Target, and Lookup
    transformations reference these via connectionId$ (a ##ID ref).
    """

    def _make_param(name: str, label: str, anon_class: int) -> dict:
        return {
            "$$ID": reg.next_id(),
            "$$class": 60,
            "input": "true",
            "output": "false",
            "precision": 0,
            "scale": 0,
            "allowRuntimeOverride": "false",
            "expressionVariable": "false",
            "label": label,
            "name": name,
            "anonymousType": {
                "$$ID": reg.next_id(),
                "$$class": anon_class,
                "name": "",
                "isVisible": "false",
            },
        }

    params: list[dict] = []
    # Source connection/object
    p_src_conn = _make_param("p_src_conn", "Source", 61)
    p_src_obj = _make_param("p_src_object", "Source", 62)
    # Target connection/object
    p_tgt_conn = _make_param("p_tgt_conn", "Target", 61)
    p_tgt_obj = _make_param("p_tgt_object", "Target", 62)
    # Lookup connection/object/condition
    p_lkp_conn = _make_param("p_lkp_conn", "Lookup", 61)
    p_lkp_obj = _make_param("p_lkp_object", "Lookup", 62)
    p_lkp_cond = _make_param("p_lkp_condition", "Lookup Condition", 63)

    params = [p_src_conn, p_src_obj, p_tgt_conn, p_tgt_obj,
              p_lkp_conn, p_lkp_obj, p_lkp_cond]

    # Wire connectionId$ on each Source/Target/Lookup
    for tx in transformations:
        cls = tx.get("$$class")
        adapter = tx.get("dataAdapter")
        if not isinstance(adapter, dict):
            continue

        if cls == 7:  # Source
            adapter["connectionId"] = ""
            adapter["connectionId$"] = {"##ID": p_src_conn["$$ID"], "$$class": 60}
        elif cls == 12:  # Target
            adapter["connectionId"] = ""
            adapter["connectionId$"] = {"##ID": p_tgt_conn["$$ID"], "$$class": 60}
        elif cls == 11:  # Lookup
            adapter["connectionId"] = ""
            adapter["connectionId$"] = {"##ID": p_lkp_conn["$$ID"], "$$class": 60}
            tx["lookupCondition$"] = {"##ID": p_lkp_cond["$$ID"], "$$class": 60}

    return params


# ── Transformation compilation ───────────────────────────────────────

def _compile_transformation(
    reg: IDRegistry, tx: dict,
    upstream_fields: set[str] | None = None,
) -> tuple[dict, dict[str, str]]:
    """Compile a single transformation spec into an IDMC object.

    Returns (idmc_obj, renames) where *renames* is
    ``{ORIGINAL_UPPER: renamed_name}`` for Lookup field renames,
    or an empty dict for other types.
    """
    tx_type = tx["type"]
    node_id = tx["id"]
    base = _load_template(tx_type)

    # Deep-reassign ALL $$ID values in the template to avoid duplicates
    # when the same template type is instantiated multiple times.
    _deep_reid_template(base, reg)

    base["name"] = node_id
    for g in base.get("groups", []):
        # Groups with input="true" need a TmplAllRule ($$class 32)
        # to propagate upstream fields as inputs.
        if g.get("input") == "true" and "rules" not in g:
            g["rules"] = [{
                "$$ID": reg.next_id(),
                "$$class": 32,
                "bulkRename": "false",
                "include": "true",
            }]

    spec_fields = tx.get("fields", [])
    renames: dict[str, str] = {}

    if tx_type == "Source":
        _compile_source(reg, base, tx, spec_fields)
    elif tx_type == "Target":
        _compile_target(reg, base, tx, spec_fields)
    elif tx_type == "Expression":
        _compile_expression(reg, base, tx, spec_fields)
    elif tx_type == "Filter":
        _compile_filter(reg, base, tx, spec_fields)
    elif tx_type == "Joiner":
        _compile_joiner(reg, base, tx, spec_fields)
    elif tx_type == "Aggregator":
        _compile_aggregator(reg, base, tx, spec_fields)
    elif tx_type == "Lookup":
        renames = _compile_lookup(reg, base, tx, spec_fields, upstream_fields or set())
    elif tx_type == "Router":
        _compile_router(reg, base, tx, spec_fields)
    elif tx_type == "Sorter":
        _compile_sorter(reg, base, tx, spec_fields)
    elif tx_type == "Union":
        _compile_union(reg, base, tx, spec_fields)

    return base, renames


# ── Source ────────────────────────────────────────────────────────────

def _compile_source(reg: IDRegistry, base: dict, tx: dict, fields: list[dict]):
    obj_name = tx.get("object_name", tx["id"])

    tx_fields, adapter, _ = build_fields_and_adapter(reg, fields, obj_name, "source")
    # connectionId must stay empty — IDMC import fails with non-empty values

    base["fields"] = tx_fields
    base["dataAdapter"] = adapter
    base["advancedProperties"] = make_advanced_properties(reg, "Source")
    base["sessionProperties"] = make_session_properties(reg, "Source")


# ── Target ───────────────────────────────────────────────────────────

def _compile_target(reg: IDRegistry, base: dict, tx: dict, fields: list[dict]):
    obj_name = tx.get("object_name", tx["id"])

    tx_fields, adapter, _ = build_fields_and_adapter(reg, fields, obj_name, "target")
    # connectionId must stay empty — IDMC import fails with non-empty values

    base["fields"] = tx_fields
    base["dataAdapter"] = adapter
    base["advancedProperties"] = make_advanced_properties(reg, "Target")
    base["sessionProperties"] = make_session_properties(reg, "Target")


# ── Expression ───────────────────────────────────────────────────────

def _compile_expression(
    reg: IDRegistry, base: dict, tx: dict, fields: list[dict],
) -> None:
    """Compile an Expression transformation.

    Creates expression output fields ($$class 22) for each non-identity
    field in the spec.  Identity fields (where expression == field name)
    are skipped because TmplAllRule already propagates them from upstream.

    The tool_input must ensure expression output names do NOT collide
    with upstream field names.  Use a prefix like ``o_`` for computed
    fields that would otherwise share a name with an upstream field.
    """
    tx_fields: list[dict] = []

    for f in fields:
        expr = f.get("expression") or f["name"]
        if expr.upper() == f["name"].upper():
            # Pure pass-through — TmplAllRule propagates it automatically.
            continue

        out = make_expression_field(
            reg, f["name"], f.get("type", "string"),
            f.get("precision", 255), f.get("scale", 0),
            expression=expr,
            exp_field_type="OUTPUT",
        )
        tx_fields.append(out)

    base["fields"] = tx_fields


# ── Filter ───────────────────────────────────────────────────────────

def _compile_filter(reg: IDRegistry, base: dict, tx: dict, fields: list[dict]):
    import re as _re
    
    condition_text = tx.get("condition", "")
    if condition_text:
        # For simple binary predicates (FIELD op VALUE), use structured
        # filterConditions ($$class 24) which is more robust across tenants.
        # For complex conditions (AND/OR/functions), use advancedFilterCondition.
        cond_upper = condition_text.upper()
        if " AND " not in cond_upper and " OR " not in cond_upper:
            m = _re.match(
                r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*(=|<>|!=|>=|<=|>|<)\s*(.+?)\s*$',
                condition_text,
            )
            if m:
                field_name = m.group(1).strip()
                operator = m.group(2).strip()
                raw_val = m.group(3).strip()
                if raw_val.startswith("'") and raw_val.endswith("'") and len(raw_val) >= 2:
                    raw_val = raw_val[1:-1]
                base["filterConditions"] = [{
                    "$$ID": reg.next_id(), "$$class": 24,
                    "fieldName": field_name,
                    "filterValue": raw_val,
                    "operator": operator,
                }]
                base["advancedFilterCondition"] = ""
                base.pop("conditions", None)
                return

        # Complex condition: use advancedFilterCondition
        base["advancedFilterCondition"] = condition_text
        base.pop("filterConditions", None)
        base.pop("conditions", None)
    else:
        base["advancedFilterCondition"] = ""
        base.pop("conditions", None)


# ── Joiner ───────────────────────────────────────────────────────────

def _compile_joiner(reg: IDRegistry, base: dict, tx: dict, fields: list[dict]):
    jt = tx.get("join_type", "NORMAL")
    jt_map = {
        "NORMAL": "Normal Join", "MASTER_OUTER": "Master Outer Join",
        "DETAIL_OUTER": "Detail Outer Join", "FULL_OUTER": "Full Outer Join",
    }
    base["joinType"] = jt_map.get(jt, "Normal Join")

    # Handle field name conflicts between Master and Detail.
    # When the same field name appears in both join conditions (master == detail),
    # the Detail field must be renamed to avoid "Field name conflicts" in IDMC.
    conditions = tx.get("conditions", [])
    rename_entries: list[dict] = []  # For TmplNameRule on Detail group
    resolved_conditions = []

    for c in conditions:
        master_field = c["master"]
        detail_field = c["detail"]

        if master_field == detail_field:
            # Rename the detail field: KUNNR -> DETAIL_KUNNR
            renamed = f"DETAIL_{detail_field}"
            rename_entries.append({
                "$$ID": reg.next_id(), "$$class": 39,
                "inputName": detail_field, "outputName": renamed,
            })
            resolved_conditions.append({
                "$$ID": reg.next_id(), "$$class": 21,
                "leftOperand": master_field, "operator": "=",
                "rightOperand": renamed,
            })
        else:
            resolved_conditions.append({
                "$$ID": reg.next_id(), "$$class": 21,
                "leftOperand": master_field, "operator": "=",
                "rightOperand": detail_field,
            })

    base["joinConditions"] = resolved_conditions

    # If there are rename entries, add a TmplNameRule to the Detail group
    if rename_entries:
        detail_group = None
        for g in base.get("groups", []):
            if g.get("name") == "Detail":
                detail_group = g
                break
        if detail_group:
            detail_group.setdefault("rules", []).append({
                "$$ID": reg.next_id(), "$$class": 36,
                "bulkRename": "false", "include": "true",
                "fieldNamesStr": "",
                "names": rename_entries,
            })


# ── Aggregator ───────────────────────────────────────────────────────

def _compile_aggregator(reg: IDRegistry, base: dict, tx: dict, fields: list[dict]):
    # IDMC Aggregator output schema = aggregated expression fields ONLY.
    # Group-by fields are NOT output ports — they pass through automatically
    # via groupByFieldsList. Only fields with an explicit aggregate expression
    # should appear in the fields array ($$class 43 = TmplAggregatorField).
    gb = tx.get("group_by", [])
    gb_set = {g.upper() for g in gb}

    tx_fields = []
    for f in fields:
        name = f["name"]
        expr = f.get("expression", "")

        # Skip group-by fields — they are handled via groupByFieldsList,
        # not as output ports.  IDMC raises "field name conflicts" if
        # a group-by field also appears in the Aggregator's fields array.
        if not expr and name.upper() in gb_set:
            continue

        # If no expression provided but it's not a group-by field,
        # treat it as a pass-through (straight pull).  This shouldn't
        # normally happen for a well-formed spec.
        if not expr:
            expr = name

        dtype = f.get("type", "string")
        precision = f.get("precision", 18)
        scale = f.get("scale", 0)

        # Aggregator fields must be $$class 43 with full expression
        # attributes matching the native TmplAggregatorField structure.
        tf: dict = {
            "$$ID": reg.next_id(),
            "$$class": 43,  # TmplAggregatorField
            "annotations": [],
            "defaultValue": "",
            "ignoreComparison": "false",
            "ignoreNullInputs": "false",
            "isDefaultValueUpdated": "false",
            "name": name,
            "platformType": platform_type_ref(dtype),
            "precision": precision,
            "scale": scale,
            "expFieldType": "OUTPUT",
            "expression": expr,
            "macroOutputPrefix": "",
            "macroOutputSuffix": "",
            "selectedMacroInput": "",
        }
        tx_fields.append(tf)

    base["fields"] = tx_fields

    gb_id = reg.next_id()
    base["groupByFieldsList"] = {
        "$$ID": gb_id, "$$class": 44,
        "fields": [
            {"$$ID": reg.next_id(), "$$class": 45, "fieldName": fname}
            for fname in gb
        ],
    }


# ── Lookup ───────────────────────────────────────────────────────────

def _compile_lookup(
    reg: IDRegistry, base: dict, tx: dict, fields: list[dict],
    upstream_fields: set[str],
) -> dict[str, str]:
    """Return ``{ORIGINAL_UPPER: renamed}`` for lookup-table field renames."""
    import re as _re

    obj_name = tx.get("object_name", tx["id"])
    cond = tx.get("lookup_condition", "")
    return_field_names = set(tx.get("return_fields", []))

    # ── Identify lookup-table fields (join keys + return fields) ─────
    # The adapter and $$class 17 fields must only describe the lookup
    # table, NOT the incoming main-stream fields (those arrive via
    # TmplAllRule on the input group).
    join_key_names: set[str] = set()
    if cond:
        for part in _re.split(r"\bAND\b", cond, flags=_re.IGNORECASE):
            m = _re.match(
                r"^\s*([A-Za-z_]\w*)\s*(?:=|<>|!=|>=|<=|>|<)\s*"
                r"([A-Za-z_]\w*)\s*$",
                part.strip(),
            )
            if m:
                # For same-name joins like "REGION_CODE = REGION_CODE",
                # both sides reference the same name.  The right side is
                # conventionally the lookup table's field.
                join_key_names.add(m.group(2).strip())

    lkp_table_names = return_field_names | join_key_names
    lkp_table_fields = [f for f in fields if f["name"] in lkp_table_names]
    # Fallback: if nothing matched, include all (shouldn't happen)
    if not lkp_table_fields:
        lkp_table_fields = fields

    tx_fields, adapter, _ = build_fields_and_adapter(
        reg, lkp_table_fields, obj_name, "source",
    )
    base["fields"] = tx_fields
    base["dataAdapter"] = adapter

    # ── Rename lookup-table fields that CONFLICT with upstream ─────────
    # Only rename lookup table fields whose name already exists in the
    # incoming stream (via TmplAllRule).  Non-conflicting return fields
    # (like EMP_NAME when it doesn't exist upstream) stay as-is.
    uid_prefix = f"in_{reg.next_id()}_"
    field_renames: dict[str, str] = {}          # original -> prefixed
    rename_entries: list[dict] = []
    for fname in sorted(lkp_table_names):
        if fname.upper() in upstream_fields:
            renamed = f"{uid_prefix}{fname}"
            field_renames[fname] = renamed
            rename_entries.append({
                "$$ID": reg.next_id(), "$$class": 39,
                "inputName": fname, "outputName": renamed,
            })

    if rename_entries:
        for g in base.get("groups", []):
            if g.get("name") == "DefaultGroup":
                g.setdefault("rules", []).append({
                    "$$ID": reg.next_id(), "$$class": 36,
                    "bulkRename": "false", "include": "true",
                    "fieldNamesStr": "",
                    "names": rename_entries,
                })
                break

    # ── Lookup conditions ────────────────────────────────────────────
    if cond:
        lkp_conditions: list[dict] = []
        for part in _re.split(r"\bAND\b", cond, flags=_re.IGNORECASE):
            part = part.strip()
            m = _re.match(
                r"^\s*([A-Za-z_]\w*)\s*(=|<>|!=|>=|<=|>|<)\s*"
                r"([A-Za-z_]\w*|'.+?'|\".+?\"|[0-9.]+)\s*$",
                part,
            )
            if m:
                left = m.group(1).strip()
                op = m.group(2).strip()
                right = m.group(3).strip()
                # Rename the lookup-table side of the condition
                if right in field_renames:
                    right = field_renames[right]
                lkp_conditions.append({
                    "$$ID": reg.next_id(), "$$class": 25,
                    "leftOperand": left, "operator": op,
                    "rightOperand": right,
                })
            else:
                lkp_conditions.append({
                    "$$ID": reg.next_id(), "$$class": 25,
                    "expression": part,
                })
        base["lookupConditions"] = lkp_conditions

    # Reassign IDs on template advanced properties
    for ap in base.get("advancedProperties", []):
        ap["$$ID"] = reg.next_id()

    # Return renames keyed by ORIGINAL_UPPER so _get_output_fields can
    # resolve the prefixed names for downstream target mappings.
    # Only return renames for RETURN fields — join key renames are only
    # needed for the lookup condition, not for downstream mapping.
    # (Join keys like REGION_CODE still come through from upstream unchanged.)
    return {k.upper(): v for k, v in field_renames.items()
            if k in return_field_names}


# ── Router ───────────────────────────────────────────────────────────

def _compile_router(reg: IDRegistry, base: dict, tx: dict, fields: list[dict]):
    import re as _re

    groups_spec = tx.get("groups", [])
    # Keep the INPUT group from template, replace output groups
    input_group = None
    for g in base["groups"]:
        if g.get("input") == "true":
            input_group = g
            break
    if not input_group:
        input_group = base["groups"][0]

    output_groups = []
    filter_conditions = []
    for gs in groups_spec:
        # A group named "DEFAULT" (case-insensitive) without a condition
        # is the IDMC catch-all — mapped to the built-in DEFAULT1.
        if gs["name"].upper() == "DEFAULT" and not gs.get("condition"):
            continue

        gid = reg.next_id()
        output_groups.append({
            "$$ID": gid, "$$class": 6,
            "input": "false", "name": gs["name"], "output": "true",
        })
        cond = gs.get("condition", "")
        if cond:
            group_obj = {
                "$$ID": reg.next_id(), "$$class": 47,
                "advancedFilterCondition": "",
                "name": gs["name"],
            }
            # For simple binary predicates, use simpleFilterConditions ($$class 48)
            cond_upper = cond.upper()
            if " AND " not in cond_upper and " OR " not in cond_upper:
                m = _re.match(
                    r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*(=|<>|!=|>=|<=|>|<)\s*(.+?)\s*$',
                    cond,
                )
                if m:
                    field_name = m.group(1).strip()
                    operator = m.group(2).strip()
                    raw_val = m.group(3).strip()
                    if raw_val.startswith("'") and raw_val.endswith("'") and len(raw_val) >= 2:
                        raw_val = raw_val[1:-1]
                    group_obj["simpleFilterConditions"] = [{
                        "$$ID": reg.next_id(), "$$class": 48,
                        "fieldName": field_name,
                        "filterValue": raw_val,
                        "operator": operator,
                    }]
                    filter_conditions.append(group_obj)
                    continue

            # Complex condition: use advancedFilterCondition
            group_obj["advancedFilterCondition"] = cond
            filter_conditions.append(group_obj)

    # IDMC Routers always have a DEFAULT1 output group (catch-all).
    # Preserve it from the template.
    default1 = None
    for g in base.get("groups", []):
        if g.get("name") == "DEFAULT1" and g.get("output") == "true":
            default1 = g
            break
    base["groups"] = [input_group] + ([default1] if default1 else []) + output_groups
    base["groupFilterConditions"] = filter_conditions


# ── Sorter ───────────────────────────────────────────────────────────

def _compile_sorter(reg: IDRegistry, base: dict, tx: dict, fields: list[dict]):
    sort_keys = tx.get("sort_keys", [])
    base["sortEntries"] = [
        {
            "$$ID": reg.next_id(), "$$class": 52,
            "fieldName": sk["field"],
            "ascending": "false" if sk.get("direction", "ASC").upper() == "DESC" else "true",
        }
        for sk in sort_keys
    ]
    base["sorterMode"] = "SIMPLE"
    base["advancedSort"] = ""


# ── Union ────────────────────────────────────────────────────────────

def _compile_union(reg: IDRegistry, base: dict, tx: dict, fields: list[dict]):
    tx_fields = [
        make_tx_field(reg, f["name"], f.get("type", "string"),
                      f.get("precision", 255), f.get("scale", 0))
        for f in fields
    ]
    base["fields"] = tx_fields
    # Re-ID groups
    for g in base.get("groups", []):
        g["$$ID"] = reg.next_id()


# ── Link builder ─────────────────────────────────────────────────────

def _populate_target_manual_mappings(
    reg: IDRegistry,
    links_spec: list[dict],
    node_id_to_idmc: dict[str, dict],
    transformations_spec: list[dict],
    node_renames: dict[str, dict[str, str]] | None = None,
) -> None:
    """Post-process: populate manualMappings on Target transformations.

    Each Target field needs a FieldMapping ($$class 35) that references
    the upstream transformation. This must be done after links are built
    because we need to know which transformation feeds each Target.

    *node_renames* maps ``node_id -> {ORIGINAL_UPPER: renamed}``
    for Lookup return fields that were renamed to avoid field-name
    conflicts with the incoming stream (structural IDMC plumbing).
    """
    node_renames = node_renames or {}

    # Build a map: target_id -> list of upstream_ids that feed into it
    target_upstream: dict[str, list[str]] = {}
    for link in links_spec:
        target_upstream.setdefault(link["to"], []).append(link["from"])

    # Build a map of effective output field names per node from the spec.
    # For nodes that pass-through fields via TmplAllRule (Expression, Filter,
    # Sorter, Router), trace back through the link chain to collect all
    # available field names.
    spec_by_id: dict[str, dict] = {t["id"]: t for t in transformations_spec}
    # link_to -> [link_from, ...]
    upstream_map: dict[str, list[str]] = {}
    for link in links_spec:
        upstream_map.setdefault(link["to"], []).append(link["from"])

    _output_fields_cache: dict[str, dict[str, str]] = {}  # node_id -> {UPPER: original}

    def _get_output_fields(nid: str) -> dict[str, str]:
        """Return {UPPER_NAME: effective_output_name} of all fields a node outputs.

        For Lookup nodes with renamed return fields, the renamed name
        replaces the original so downstream consumers get the correct
        ``fromFieldName``.
        """
        if nid in _output_fields_cache:
            return _output_fields_cache[nid]

        tx_spec = spec_by_id.get(nid, {})
        tx_type = tx_spec.get("type", "")
        result: dict[str, str] = {}  # UPPER -> effective name

        # Passthrough types: inherit upstream fields then overlay own fields
        passthrough_types = {"Expression", "Filter", "Sorter", "Router", "Lookup"}
        if tx_type in passthrough_types:
            for up_id in upstream_map.get(nid, []):
                result.update(_get_output_fields(up_id))

        # Add this node's own explicit fields (overriding any upstream duplicates)
        for f in tx_spec.get("fields", []):
            result[f["name"].upper()] = f["name"]

        # Apply structural renames (Lookup return fields renamed to
        # avoid IDMC field-name conflicts with the incoming stream).
        renames = node_renames.get(nid, {})
        for orig_upper, renamed in renames.items():
            result[orig_upper] = renamed

        _output_fields_cache[nid] = result
        return result

    for node_id, idmc_obj in node_id_to_idmc.items():
        if idmc_obj.get("$$class") != 12:  # Only Targets
            continue

        upstream_ids = target_upstream.get(node_id, [])
        if not upstream_ids:
            continue

        # Use the first upstream (Targets typically have one input)
        upstream_id = upstream_ids[0]
        upstream_obj = node_id_to_idmc.get(upstream_id)
        if not upstream_obj:
            continue

        # Build case-insensitive lookup of upstream output field names
        upstream_fields = _get_output_fields(upstream_id)

        target_fields = idmc_obj.get("fields", [])
        # Build spec-level lookup for from_field overrides
        target_spec = spec_by_id.get(node_id, {})
        target_spec_fields = {
            f["name"].upper(): f for f in target_spec.get("fields", [])
        }
        mapping_list = []
        for tf in target_fields:
            tgt_name = tf["name"]
            # Check for explicit from_field in the spec first,
            # then fall back to case-insensitive upstream name match.
            spec_f = target_spec_fields.get(tgt_name.upper(), {})
            from_field_override = spec_f.get("from_field")
            if from_field_override:
                from_name = from_field_override
            else:
                from_name = upstream_fields.get(tgt_name.upper(), tgt_name)
            mapping_list.append({
                "$$ID": reg.next_id(),
                "$$class": 35,
                "fromFieldName": from_name,
                "toField": {
                    "##ID": tf["$$ID"],
                    "$$class": 17,
                },
                "fromExpression": {
                    "##ID": upstream_obj["$$ID"],
                    "$$class": upstream_obj["$$class"],
                },
            })

        if mapping_list:
            mm = idmc_obj.get("manualMappings", {})
            mm["mappingList"] = mapping_list
            idmc_obj["manualMappings"] = mm


def _build_link(reg: IDRegistry, from_obj: dict, to_obj: dict, link_name: str = "",
                *, from_group_name: str | None = None, to_group_name: str | None = None) -> dict:
    """Build an IDMC link ($$class 5) between two transformation objects."""
    from_group = _find_group(from_obj, output=True, group_name=from_group_name)
    to_group = _find_group(to_obj, output=False, group_name=to_group_name)

    link: dict[str, Any] = {
        "$$ID": reg.next_id(),
        "$$class": 5,
        "name": link_name,
        "fromTransformation": {
            "##ID": from_obj["$$ID"],
            "$$class": from_obj["$$class"],
        },
        "toTransformation": {
            "##ID": to_obj["$$ID"],
            "$$class": to_obj["$$class"],
        },
    }
    if from_group:
        link["fromGroup"] = {"##ID": from_group["$$ID"], "$$class": 6}
    if to_group:
        link["toGroup"] = {"##ID": to_group["$$ID"], "$$class": 6}
    return link


def _find_group(obj: dict, output: bool, *, group_name: str | None = None) -> dict | None:
    """Find a matching group in a transformation object.
    
    If group_name is given, find the group with that name (case-insensitive).
    Otherwise, fall back to the first group matching the input/output flag.
    For Router output groups, skip DEFAULT1 unless explicitly requested.
    """
    groups = obj.get("groups", [])
    
    # If a specific group name was requested, find it
    if group_name:
        for g in groups:
            if g.get("name", "").lower() == group_name.lower():
                return g
        # "DEFAULT" maps to IDMC's built-in "DEFAULT1" catch-all
        if group_name.upper() == "DEFAULT":
            for g in groups:
                if g.get("name") == "DEFAULT1":
                    return g
    
    # Default: find first group matching the direction flag
    key = "output" if output else "input"
    is_router = obj.get("$$class") == 46
    for g in groups:
        if g.get(key) == "true" or g.get(key) is True:
            # Skip DEFAULT1 on Router when no explicit name requested
            if is_router and output and not group_name and g.get("name") == "DEFAULT1":
                continue
            return g
    # Joiner special handling: Detail group for input
    if not output:
        for g in groups:
            name = g.get("name", "").lower()
            if name in ("detail", "defaultgroup", "input", "input1"):
                return g
    return groups[0] if groups else None
