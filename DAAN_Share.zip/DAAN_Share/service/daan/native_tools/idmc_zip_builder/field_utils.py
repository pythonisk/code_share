"""
field_utils.py — Helpers to create IDMC TxField (class 17) and
BaseAdapterField (class 18) objects from the validated spec fields.
"""

from __future__ import annotations
from typing import Any

from .id_registry import IDRegistry

# IDMC platform data-type references ($$class 19)
_PLATFORM_TYPES = {
    "string":    "smd:com.informatica.metadata.seed.platform.Platform.typesystem/string",
    "integer":   "smd:com.informatica.metadata.seed.platform.Platform.typesystem/integer",
    "float":     "smd:com.informatica.metadata.seed.platform.Platform.typesystem/decimal",
    "decimal":   "smd:com.informatica.metadata.seed.platform.Platform.typesystem/decimal",
    "date":      "smd:com.informatica.metadata.seed.platform.Platform.typesystem/date",
    "timestamp": "smd:com.informatica.metadata.seed.platform.Platform.typesystem/timestamp",
}

_NATIVE_TYPE_MAP = {
    "string": "nstring", "integer": "integer", "float": "decimal",
    "decimal": "decimal", "date": "date", "timestamp": "timestamp",
}


def platform_type_ref(dtype: str) -> dict:
    sid = _PLATFORM_TYPES.get(dtype, _PLATFORM_TYPES["string"])
    return {"##SID": sid, "$$class": 19}


def make_tx_field(
    reg: IDRegistry, name: str, dtype: str = "string",
    precision: int = 255, scale: int = 0,
    expression: str | None = None,
) -> dict[str, Any]:
    """Create a TxField ($$class 17) object."""
    obj: dict[str, Any] = {
        "$$ID": reg.next_id(),
        "$$class": 17,
        "name": name,
        "platformType": platform_type_ref(dtype),
        "precision": precision,
        "scale": scale,
        "defaultValue": "",
        "ignoreComparison": "false",
        "ignoreNullInputs": "false",
        "isDefaultValueUpdated": "false",
    }
    if expression is not None:
        obj["expression"] = expression
    return obj


def make_expression_field(
    reg: IDRegistry, name: str, dtype: str = "string",
    precision: int = 255, scale: int = 0,
    expression: str | None = None,
    exp_field_type: str = "OUTPUT",
) -> dict[str, Any]:
    """Create a TmplExpressionField ($$class 22) for Expression transformations."""
    obj: dict[str, Any] = {
        "$$ID": reg.next_id(),
        "$$class": 22,
        "name": name,
        "platformType": platform_type_ref(dtype),
        "precision": precision,
        "scale": scale,
        "defaultValue": "NULL",
        "ignoreComparison": "false",
        "ignoreNullInputs": "false",
        "isDefaultValueUpdated": "true",
        "expFieldType": exp_field_type,
        "expression": expression or "",
        "macroOutputPrefix": "",
        "macroOutputSuffix": "",
        "selectedMacroInput": "",
        "variable": "false",
    }
    return obj


def make_adapter_field(
    reg: IDRegistry, name: str, dtype: str = "string",
    precision: int = 255, scale: int = 0,
) -> dict[str, Any]:
    """Create a BaseAdapterField ($$class 18) for dataAdapter.object.fields."""
    native = _NATIVE_TYPE_MAP.get(dtype, "nstring")
    return {
        "$$ID": reg.next_id(),
        "$$class": 18,
        "name": name,
        "annotations": [],
        "createable": "false",
        "externalId": "false",
        "fieldStatus": "NEW",
        "fieldType": "UNDEFINED",
        "filterable": "true",
        "foreignKey": "false",
        "generated": "false",
        "javaType": "",
        "key": "false",
        "label": name,
        "nativeName": name,
        "nativeType": native,
        "newField": "false",
        "nullable": "true",
        "original": "true",
        "passthroughPort": "false",
        "precision": precision,
        "properties": [],
        "scale": scale,
        "sfIdLookup": "",
        "unique": "false",
        "updateable": "false",
    }


def build_fields_and_adapter(
    reg: IDRegistry, spec_fields: list[dict], object_name: str,
    adapter_kind: str = "source",
) -> tuple[list[dict], dict, dict[str, int]]:
    """
    Build TxField list + full dataAdapter dict for a Source or Target.

    Returns (tx_fields, data_adapter, field_id_map).
    field_id_map maps field_name -> adapter_field $$ID for cross-referencing.
    """
    tx_fields: list[dict] = []
    adapter_fields: list[dict] = []
    field_id_map: dict[str, int] = {}

    for sf in spec_fields:
        name = sf["name"]
        dtype = sf.get("type", "string")
        prec = sf.get("precision", 255)
        sc = sf.get("scale", 0)

        af = make_adapter_field(reg, name, dtype, prec, sc)
        field_id_map[name] = af["$$ID"]
        adapter_fields.append(af)

        tf = make_tx_field(reg, name, dtype, prec, sc)
        tf["adapterField"] = {"##ID": af["$$ID"], "$$class": 18}
        tx_fields.append(tf)

    adapter_id = reg.next_id()
    object_id = reg.next_id()

    data_adapter: dict[str, Any] = {
        "$$ID": adapter_id,
        "$$class": 16,
        "name": "",
        "codePage": "",
        "compatibleEngine": "",
        "connectionId": "",
        "excludeDynamicFileNameField": "false",
        "fwConfigId": "",
        "multipleObject": "false",
        "objectType": "SINGLE",
        "typeSystem": "CSVFile",
        "useDynamicFileName": "false",
        "object": {
            "$$ID": object_id,
            "$$class": 29,
            "name": object_name,
            "customQuery": "",
            "dbSchema": "",
            "label": object_name,
            "objectName": "",
            "objectType": "",
            "parentPath": "",
            "path": object_name,
            "retainMetadata": "false",
            "fileAttrs": {
                "$$ID": reg.next_id(),
                "$$class": 38,
                "consecutiveDelimiter": "false",
                "customRowDelimiter": "",
                "delimiter": ",",
                "escapeChar": "",
                "firstDataRow": 2,
                "firstDataRowAsHeader": "false",
                "headerAndDataDelimiter": 0,
                "headerLineNo": 1,
                "multiDelimitersAsAnd": "true",
                "rowDelimiter": 0,
                "textQualifier": "\"",
            },
            "fields": adapter_fields,
        },
        "oprRuntimeAttributes": {"$$ID": reg.next_id(), "$$class": 30},
        "runtimeAttributes": {"$$ID": reg.next_id(), "$$class": 30},
    }

    if adapter_kind == "source":
        data_adapter["readOptions"] = {
            "$$ID": reg.next_id(), "$$class": 31,
            "commandType": 0, "descending": "false",
            "filterCondition": "", "flatFileCommand": "",
            "queryAll": "false", "rowLimit": 0,
            "selectDistinct": "false", "userDefinedJoin": "",
            "advancedFilterCondition": "", "requestXml": "",
            "sortFieldValues": "",
        }
    else:
        data_adapter["writeOptions"] = {
            "$$ID": reg.next_id(), "$$class": 34,
            "batchSize": 0, "bulkApi": "false",
            "errorFileDirectory": "", "errorFilePrefix": "",
            "handleDecimalRoundOff": "false", "handleSpecialChars": "false",
            "operations": ["Insert"], "setFieldsToNull": "false",
            "successFileDirectory": "", "successFilePrefix": "",
            "truncate": "false", "updateStrategyExpression": "",
            "useErrorFile": "false", "useExactSrcNames": "false",
            "useSuccessFile": "false",
        }

    return tx_fields, data_adapter, field_id_map


def make_advanced_properties(reg: IDRegistry, kind: str) -> list[dict]:
    """Create advancedProperties for Source or Target nodes."""
    if kind == "Source":
        defs = [
            ("Tracing Level", "Normal"), ("Pre SQL", ""), ("Post SQL", ""),
            ("Sql Override", ""), ("Output is deterministic", "false"),
            ("Read operations", "1"), ("Enable Dynamic SQL", "false"),
            ("Trim field values", "false"),
        ]
    else:
        defs = [
            ("Tracing Level", "Normal"), ("Pre SQL", ""), ("Post SQL", ""),
            ("Commit Interval", "10000"), ("Rollback on error", "true"),
            ("Write operations", "1"), ("Data Sync", "false"),
            ("Truncate Target Table", "false"),
        ]
    return [{"$$ID": reg.next_id(), "$$class": 14, "name": n, "value": v} for n, v in defs]


def make_session_properties(reg: IDRegistry, kind: str) -> list[dict]:
    """Create sessionProperties for Source or Target nodes."""
    if kind == "Source":
        defs = [
            ("Source file directory", ""), ("Source filename", ""),
            ("Remote Filename", ""), ("Fetch size", "1000"),
        ]
    else:
        defs = [
            ("Target file directory", ""), ("Target filename", ""),
            ("Remote filename", ""), ("Batch size", "1000"),
        ]
    return [{"$$ID": reg.next_id(), "$$class": 15, "name": n, "value": v} for n, v in defs]
