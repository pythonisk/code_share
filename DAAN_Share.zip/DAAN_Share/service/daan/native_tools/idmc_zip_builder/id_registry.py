"""
id_registry.py — Sequential ID allocator for IDMC $$ID values.

Every object in @3.bin needs a globally unique $$ID.  This registry
hands out monotonically increasing integers.
"""


class IDRegistry:
    def __init__(self, start: int = 10000):
        self._current = start

    def next_id(self) -> int:
        self._current += 1
        return self._current
