"""
ssis_package_generator.py — Native tool that turns a SQL Server stored procedure
into a downloadable SSIS package (a .dtsx wrapped in a .zip).

Usage by an LLM agent:
    local_tools = SsisPackageGenerator.generate_ssis_package

The tool:
  1. Resolves the stored procedure text (inline ``stored_procedure`` or from a
     .sql file in the session ``inputs/`` folder).
  2. Parses the procedure name and parameters.
  3. Emits a well-formed SSIS package (.dtsx) containing an OLE DB connection
     manager and an Execute SQL Task that runs the procedure, exposing each
     parameter as a package variable bound to the call.
  4. Zips the .dtsx (plus a README) into ``session_storage/{session_id}/artifacts/``
     so the UI download button can serve it.

On success returns::

    {"status": "ok", "artifact_file": "<name>.zip", "artifact_path": "...",
     "package_name": "...", "procedure": "...", "parameter_count": N, "message": "..."}
"""

from __future__ import annotations

import html
import logging
import re
import uuid
import zipfile
from pathlib import Path
from typing import Any

from daan.flow.session_service import get_artifacts_dir

logger = logging.getLogger(__name__)

SUPPORTED_INPUT_SUFFIXES = {".sql", ".txt"}

# Minimal SQL-type -> SSIS/OLE DB parameter data-type code mapping used for the
# Execute SQL Task parameter bindings. Unknown types fall back to VARCHAR.
_SQL_TYPE_TO_SSIS: dict[str, str] = {
    "bigint": "LARGE_INTEGER",
    "int": "LONG",
    "smallint": "SHORT",
    "tinyint": "BYTE",
    "bit": "BOOLEAN",
    "decimal": "NUMERIC",
    "numeric": "NUMERIC",
    "money": "CURRENCY",
    "float": "DOUBLE",
    "real": "FLOAT",
    "date": "DATE",
    "datetime": "DATE",
    "datetime2": "DATE",
    "smalldatetime": "DATE",
    "uniqueidentifier": "GUID",
    "varchar": "VARCHAR",
    "nvarchar": "VARCHAR",
    "char": "VARCHAR",
    "nchar": "VARCHAR",
    "text": "VARCHAR",
}


class SsisPackageGenerator:
    def __init__(self, data_dir: str | None = None):
        self.tool_name = "SsisPackageGenerator"
        self._data_dir = data_dir
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    def generate_ssis_package(
        self,
        stored_procedure: str | None = None,
        file_name: str | None = None,
        file_path: str | None = None,
        package_name: str | None = None,
        server: str | None = None,
        database: str | None = None,
        output_file_name: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Generate an SSIS package zip from a stored procedure.

        Args:
            stored_procedure: Inline stored-procedure DDL/text. Preferred.
            file_name / file_path: Alternatively, a .sql file in the session inputs.
            package_name: Optional SSIS package name (defaults to the proc name).
            server: Target SQL Server host for the connection manager (default placeholder).
            database: Target database for the connection manager (default placeholder).
            output_file_name: Optional zip file name.
        """
        try:
            proc_sql = self._resolve_procedure_sql(stored_procedure, file_name, file_path, kwargs)
            if not proc_sql or not proc_sql.strip():
                return {
                    "status": "error",
                    "errors": ["No stored procedure provided. Pass 'stored_procedure' text "
                               "or a .sql file in the session inputs folder."],
                }

            proc_schema, proc_name, parameters = self._parse_procedure(proc_sql)
            if not proc_name:
                return {
                    "status": "error",
                    "errors": ["Could not identify a CREATE PROCEDURE statement in the input."],
                }

            pkg_name = self._sanitize_identifier(package_name or f"Run_{proc_name}")
            server_name = (server or "localhost").strip()
            database_name = (database or "YourDatabase").strip()

            dtsx_xml = self._build_dtsx(
                package_name=pkg_name,
                proc_schema=proc_schema,
                proc_name=proc_name,
                parameters=parameters,
                server=server_name,
                database=database_name,
            )
            readme = self._build_readme(pkg_name, proc_schema, proc_name, parameters, server_name, database_name)

            artifacts_dir = self._resolve_artifacts_dir()
            zip_name = output_file_name or f"{pkg_name}.zip"
            if not zip_name.lower().endswith(".zip"):
                zip_name = f"{zip_name}.zip"
            zip_path = self._next_available_artifact_path(artifacts_dir, zip_name)

            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
                zf.writestr(f"{pkg_name}.dtsx", dtsx_xml)
                zf.writestr("README.txt", readme)

            logger.info(
                "%s: Generated SSIS package '%s' (%d parameter(s)) -> %s",
                self.tool_name, pkg_name, len(parameters), zip_path,
            )
            return {
                "status": "ok",
                "message": f"Generated SSIS package for procedure '{proc_schema}.{proc_name}'.",
                "artifact_file": zip_path.name,
                "artifact_path": str(zip_path),
                "package_name": pkg_name,
                "procedure": f"{proc_schema}.{proc_name}",
                "parameter_count": len(parameters),
            }
        except Exception as exc:
            logger.exception("%s: SSIS package generation failed", self.tool_name)
            return {
                "status": "error",
                "errors": [f"SSIS package generation failed: {exc}"],
            }

    # ── Input resolution ────────────────────────────────────────────────────

    def _resolve_procedure_sql(
        self,
        stored_procedure: str | None,
        file_name: str | None,
        file_path: str | None,
        kwargs: dict[str, Any],
    ) -> str | None:
        inline = stored_procedure or kwargs.get("procedure") or kwargs.get("sql")
        if isinstance(inline, str) and inline.strip():
            return inline

        inputs_dir = Path(self._data_dir) if self._data_dir else None
        candidates: list[Path] = []

        for raw in (file_path, kwargs.get("input_file")):
            if isinstance(raw, str) and raw.strip():
                candidate = Path(raw).expanduser()
                if not candidate.is_absolute() and inputs_dir is not None:
                    candidate = inputs_dir / candidate
                if candidate.is_file():
                    candidates.append(candidate)

        if inputs_dir is not None:
            for raw in (file_name, kwargs.get("file_names")):
                if isinstance(raw, str) and raw.strip():
                    candidate = inputs_dir / raw.strip()
                    if candidate.is_file():
                        candidates.append(candidate)

        # Fall back to the first supported file in the inputs folder.
        if not candidates and inputs_dir is not None and inputs_dir.is_dir():
            for item in sorted(inputs_dir.iterdir()):
                if item.is_file() and item.suffix.lower() in SUPPORTED_INPUT_SUFFIXES:
                    candidates.append(item)
                    break

        for candidate in candidates:
            try:
                text = candidate.read_text(encoding="utf-8", errors="ignore")
                if text.strip():
                    return text
            except Exception as exc:
                logger.warning("%s: Failed to read '%s': %s", self.tool_name, candidate, exc)
        return None

    # ── Parsing ─────────────────────────────────────────────────────────────

    def _parse_procedure(self, sql: str) -> tuple[str, str, list[dict[str, str]]]:
        """Return (schema, proc_name, [{name, sql_type, ssis_type}, ...])."""
        name_match = re.search(
            r"CREATE\s+(?:OR\s+ALTER\s+)?PROC(?:EDURE)?\s+"
            r"(?:(\[[^\]]+\]|\w+)\s*\.\s*)?(\[[^\]]+\]|\w+)",
            sql,
            re.IGNORECASE,
        )
        if not name_match:
            return "dbo", "", []

        schema = self._strip_brackets(name_match.group(1)) if name_match.group(1) else "dbo"
        proc_name = self._strip_brackets(name_match.group(2))

        # Parameter block: between the proc name and the AS that begins the body.
        after_name = sql[name_match.end():]
        body_match = re.search(r"\bAS\b", after_name, re.IGNORECASE)
        param_block = after_name[: body_match.start()] if body_match else ""
        param_block = param_block.strip().lstrip("(").rstrip(")")

        parameters: list[dict[str, str]] = []
        if param_block.strip():
            for raw_param in self._split_top_level(param_block):
                param = self._parse_parameter(raw_param)
                if param:
                    parameters.append(param)
        return schema, proc_name, parameters

    def _parse_parameter(self, raw: str) -> dict[str, str] | None:
        raw = raw.strip()
        if not raw:
            return None
        match = re.match(r"(@\w+)\s+(\[[^\]]+\]|\w+)", raw)
        if not match:
            return None
        name = match.group(1)
        sql_type = self._strip_brackets(match.group(2)).lower()
        ssis_type = _SQL_TYPE_TO_SSIS.get(sql_type, "VARCHAR")
        return {"name": name, "sql_type": sql_type, "ssis_type": ssis_type}

    @staticmethod
    def _split_top_level(text: str) -> list[str]:
        """Split a parameter list on commas that are not nested in parentheses."""
        parts: list[str] = []
        depth = 0
        current: list[str] = []
        for char in text:
            if char == "(":
                depth += 1
            elif char == ")":
                depth = max(0, depth - 1)
            if char == "," and depth == 0:
                parts.append("".join(current))
                current = []
            else:
                current.append(char)
        if current:
            parts.append("".join(current))
        return parts

    @staticmethod
    def _strip_brackets(value: str | None) -> str:
        return (value or "").strip().strip("[]").strip()

    @staticmethod
    def _sanitize_identifier(value: str) -> str:
        cleaned = re.sub(r"[^A-Za-z0-9_]+", "_", (value or "").strip()).strip("_")
        return cleaned or "SsisPackage"

    # ── DTSX generation ─────────────────────────────────────────────────────

    def _build_dtsx(
        self,
        *,
        package_name: str,
        proc_schema: str,
        proc_name: str,
        parameters: list[dict[str, str]],
        server: str,
        database: str,
    ) -> str:
        pkg_guid = f"{{{uuid.uuid4()}}}"
        conn_guid = f"{{{uuid.uuid4()}}}"
        task_guid = f"{{{uuid.uuid4()}}}"

        # Build the EXEC statement with ordered '?' placeholders and the parameter
        # bindings/variables that back them.
        placeholders = ", ".join(f"{p['name']} = ?" for p in parameters)
        exec_stmt = f"EXEC [{proc_schema}].[{proc_name}]"
        if placeholders:
            exec_stmt += " " + placeholders
        exec_stmt += ";"

        variables_xml = "".join(
            self._variable_xml(package_name, p["name"], p["sql_type"]) for p in parameters
        )
        bindings_xml = "".join(
            self._param_binding_xml(package_name, index, p)
            for index, p in enumerate(parameters)
        )

        connection_string = (
            f"Data Source={server};Initial Catalog={database};"
            "Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;"
        )

        return f"""<?xml version="1.0" encoding="utf-8"?>
<DTS:Executable xmlns:DTS="www.microsoft.com/SqlServer/Dts"
  DTS:refId="Package"
  DTS:CreationName="Microsoft.Package"
  DTS:Description="Auto-generated SSIS package that executes stored procedure {html.escape(proc_schema)}.{html.escape(proc_name)}."
  DTS:DTSID="{pkg_guid}"
  DTS:ExecutableType="Microsoft.Package"
  DTS:LocaleID="1033"
  DTS:ObjectName="{html.escape(package_name)}"
  DTS:VersionBuild="1">
  <DTS:Property DTS:Name="PackageFormatVersion">8</DTS:Property>
  <DTS:Variables>{variables_xml}
  </DTS:Variables>
  <DTS:ConnectionManagers>
    <DTS:ConnectionManager
      DTS:refId="Package.ConnectionManagers[TargetDB]"
      DTS:CreationName="OLEDB"
      DTS:DTSID="{conn_guid}"
      DTS:ObjectName="TargetDB">
      <DTS:ObjectData>
        <DTS:ConnectionManager
          DTS:ConnectionString="{html.escape(connection_string)}" />
      </DTS:ObjectData>
    </DTS:ConnectionManager>
  </DTS:ConnectionManagers>
  <DTS:Executables>
    <DTS:Executable
      DTS:refId="Package\\Execute Stored Procedure"
      DTS:CreationName="Microsoft.ExecuteSQLTask"
      DTS:DTSID="{task_guid}"
      DTS:ExecutableType="Microsoft.ExecuteSQLTask"
      DTS:LocaleID="1033"
      DTS:ObjectName="Execute Stored Procedure">
      <DTS:ObjectData>
        <SQLTask:SqlTaskData
          xmlns:SQLTask="www.microsoft.com/sqlserver/dts/tasks/sqltask"
          SQLTask:Connection="{conn_guid}"
          SQLTask:SqlStatementSource="{html.escape(exec_stmt)}">
{bindings_xml}        </SQLTask:SqlTaskData>
      </DTS:ObjectData>
    </DTS:Executable>
  </DTS:Executables>
</DTS:Executable>
"""

    @staticmethod
    def _variable_xml(package_name: str, param_name: str, sql_type: str) -> str:
        var_name = param_name.lstrip("@")
        var_guid = f"{{{uuid.uuid4()}}}"
        return f"""
    <DTS:Variable
      DTS:CreationName="Variable"
      DTS:DTSID="{var_guid}"
      DTS:Namespace="User"
      DTS:ObjectName="{html.escape(var_name)}">
      <DTS:VariableValue DTS:DataType="8"></DTS:VariableValue>
    </DTS:Variable>"""

    @staticmethod
    def _param_binding_xml(package_name: str, ordinal: int, param: dict[str, str]) -> str:
        var_name = param["name"].lstrip("@")
        return (
            f'          <SQLTask:ParameterBinding '
            f'SQLTask:ParameterName="{ordinal}" '
            f'SQLTask:DtsVariableName="User::{html.escape(var_name)}" '
            f'SQLTask:ParameterDirection="Input" '
            f'SQLTask:DataType="{param["ssis_type"]}" '
            f'SQLTask:ParameterSize="-1" />\n'
        )

    @staticmethod
    def _build_readme(
        package_name: str,
        proc_schema: str,
        proc_name: str,
        parameters: list[dict[str, str]],
        server: str,
        database: str,
    ) -> str:
        param_lines = "\n".join(
            f"  - User::{p['name'].lstrip('@')}  (SQL type: {p['sql_type']}, SSIS type: {p['ssis_type']})"
            for p in parameters
        ) or "  (none)"
        return (
            f"SSIS Package: {package_name}.dtsx\n"
            f"=========================================\n\n"
            f"This package executes the stored procedure:\n"
            f"    [{proc_schema}].[{proc_name}]\n\n"
            f"Connection Manager 'TargetDB' (edit before running):\n"
            f"    Server   : {server}\n"
            f"    Database : {database}\n"
            f"    Security : Integrated (SSPI)\n\n"
            f"Package variables mapped to the procedure parameters:\n"
            f"{param_lines}\n\n"
            f"How to use:\n"
            f"  1. Open {package_name}.dtsx in Visual Studio (SSDT) or add it to an\n"
            f"     Integration Services project.\n"
            f"  2. Update the 'TargetDB' connection manager with your server/database\n"
            f"     and authentication.\n"
            f"  3. Set values for the User:: variables (or map them to project params).\n"
            f"  4. Execute the package, or deploy it to the SSIS Catalog / SQL Agent.\n"
        )

    # ── Artifacts ───────────────────────────────────────────────────────────

    def _resolve_artifacts_dir(self) -> Path:
        if not self._data_dir:
            artifacts_dir = Path(__file__).resolve().parent / "artifacts"
            artifacts_dir.mkdir(parents=True, exist_ok=True)
            return artifacts_dir

        data_path = Path(self._data_dir)
        session_dir = data_path.parent if data_path.name == "inputs" else data_path
        artifacts_dir = get_artifacts_dir(session_dir.name, create=True)
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        return artifacts_dir

    def _next_available_artifact_path(self, artifacts_dir: Path, file_name: str) -> Path:
        candidate = artifacts_dir / Path(file_name).name
        if not candidate.exists():
            return candidate
        stem = candidate.stem
        suffix = candidate.suffix
        index = 2
        while True:
            retry = artifacts_dir / f"{stem}_{index}{suffix}"
            if not retry.exists():
                return retry
            index += 1
