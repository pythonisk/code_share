"""
DAAN 5 Native Tool: IICS STTM Generator

Entry point:
    local_tools = IICSSttmGenerator.generate_sttm_excel

This tool:
1) Accepts IICS .DTEMPLATE exports (zip file path or folder path)
2) Parses IICS mapping metadata from JSON structure
3) Extracts sources, targets, transformations, expressions, routers
4) Generates comprehensive Excel STTM documentation with 3 sheets:
   - Details: Mapping overview, source/target info, filters
   - Mappings: Field-level mappings with transformations
   - Transformations: Transformation list with coordinates

Design notes:
- DAAN 5 loads native tools via ClassName.method_name resolved through tools_loader,
  with CamelCase->snake_case module mapping. Keep class name + method stable.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Optional

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from daan.flow.context_vars import daan_session_id

logger = logging.getLogger(__name__)

_TOOL_VERSION = "1.0"


# ========================================================================
# Java class suffix -> canonical short name mappings
# ========================================================================

_CLASS_SUFFIX_MAP = {
    'TmplSource': 'SOURCE',
    'TmplExpression': 'EXPRESSION',
    'TmplRouter': 'ROUTER',
    'TmplTarget': 'TARGET',
    'TmplExpressionField': 'EXPR_FIELD',
    'FieldMapping': 'FIELD_MAPPING',
    'SessionVariable': 'SESSION_VAR',
    'TmplParam': 'PARAM',
}


# ========================================================================
# Helper Functions: Zip Extraction & Folder Processing
# ========================================================================

def _extract_zip(zip_path, extract_to=None):
    """
    Extract a zip file containing .DTEMPLATE folder(s).
    Returns the path where files were extracted.
    If extract_to is None, a temp directory is created.
    """
    zip_path = Path(zip_path)
    if not zip_path.exists():
        raise FileNotFoundError(f"Zip file not found: {zip_path}")
    if not zipfile.is_zipfile(zip_path):
        raise ValueError(f"Not a valid zip file: {zip_path}")

    if extract_to is None:
        extract_to = Path(tempfile.mkdtemp(prefix="iics_"))
    else:
        extract_to = Path(extract_to)
        extract_to.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(zip_path, 'r') as zf:
        zf.extractall(extract_to)

    logger.info(f"Extracted: {zip_path.name} → {extract_to}")
    return extract_to


def _build_class_map(data):
    """
    Read $$classInfo from metadata and return two dicts:
      class_num_to_name: {int -> canonical_short_name}
      class_name_to_num: {canonical_short_name -> int}
    """
    class_info = data.get('metadata', {}).get('$$classInfo', {})
    num_to_name = {}
    name_to_num = {}
    for num_str, java_class in class_info.items():
        short = java_class.rsplit('.', 1)[-1]
        canonical = _CLASS_SUFFIX_MAP.get(short)
        if canonical:
            num = int(num_str)
            num_to_name[num] = canonical
            name_to_num[canonical] = num
    return num_to_name, name_to_num


def _build_id_map(data):
    """Recursively collect all objects with $$ID into a lookup dict."""
    id_map = {}

    def walk(obj):
        if isinstance(obj, dict):
            if '$$ID' in obj:
                id_map[obj['$$ID']] = obj
            for v in obj.values():
                walk(v)
        elif isinstance(obj, list):
            for item in obj:
                walk(item)

    walk(data)
    return id_map


def _resolve_ref(ref, id_map):
    """Resolve a ##ID reference to its actual object."""
    if isinstance(ref, dict) and '##ID' in ref:
        return id_map.get(ref['##ID'], ref)
    return ref


def _type_from_platform(pt, id_map=None):
    """Extract human-readable type name from a platformType object or ##SID."""
    if not pt:
        return ''
    if isinstance(pt, dict):
        if '##ID' in pt and id_map:
            pt = id_map.get(pt['##ID'], pt)
        sid = pt.get('##SID', '')
        if sid and '/typesystem/' in sid:
            return sid.split('/typesystem/', 1)[1]
        return pt.get('name', '')
    return ''


# ========================================================================
# IICS Mapping Parser
# ========================================================================

def _parse_iics_mapping(template_folder):
    """Parse IICS .DTEMPLATE folder and extract mapping metadata."""
    bin_file = Path(template_folder) / "bin" / "@3.bin"

    if not bin_file.exists():
        raise FileNotFoundError(f"Mapping file not found: {bin_file}")

    with open(bin_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    content = data.get('content', {})
    id_map = _build_id_map(data)
    _num_to_name, name_to_num = _build_class_map(data)

    mapping_info = {
        'name': content.get('name', ''),
        'documentType': content.get('documentType', ''),
        'links': content.get('links', []),
        'parameters': content.get('parameters', []),
        'transformations': content.get('transformations', []),
        'variables': content.get('variables', []),
        'annotations': content.get('annotations', []),
        'id_map': id_map,
        'class_map': name_to_num,
    }

    return mapping_info


# ========================================================================
# Transformation Extractors
# ========================================================================

def _extract_sources(transformations, id_map=None, class_map=None):
    """Extract source transformations (TmplSource)."""
    src_cls = (class_map or {}).get('SOURCE', 9)
    sources = []
    for tx in transformations:
        if tx.get('$$class') == src_cls:
            da = tx.get('dataAdapter', {})
            runtime_attrs = da.get('runtimeAttributes', {}).get('attributes', [])
            obj_data = da.get('object', {})

            fields = []
            for f in tx.get('fields', []):
                af_ref = f.get('adapterField', {})
                af = _resolve_ref(af_ref, id_map) if id_map else af_ref
                native = af.get('nativeType', '') if isinstance(af, dict) else ''
                dtype = native or _type_from_platform(f.get('platformType'), id_map)
                fields.append({
                    'name': f.get('name', ''),
                    'precision': f.get('precision', ''),
                    'scale': f.get('scale', 0),
                    'datatype': dtype,
                })

            source = {
                'name': tx.get('name', ''),
                'object_name': obj_data.get('objectName', obj_data.get('name', tx.get('name', ''))),
                'object': obj_data,
                'fields': fields,
                'db_name': next((a['value'] for a in runtime_attrs if a.get('name') == 'Database'), ''),
                'schema_name': next((a['value'] for a in runtime_attrs if a.get('name') == 'Schema'), ''),
            }
            sources.append(source)
    return sources


def _extract_expressions(transformations, class_map=None):
    """Extract expression transformations (TmplExpression)."""
    expr_cls = (class_map or {}).get('EXPRESSION')
    expressions = []
    for tx in transformations:
        is_expr = (tx.get('$$class') == expr_cls) if expr_cls is not None \
            else any(f.get('expFieldType') for f in tx.get('fields', []))
        if is_expr:
            expressions.append({'name': tx.get('name', ''), 'fields': tx.get('fields', [])})
    return expressions


def _extract_routers(transformations, class_map=None):
    """Extract router transformations (TmplRouter)."""
    rtr_cls = (class_map or {}).get('ROUTER')
    routers = []
    for tx in transformations:
        is_router = (tx.get('$$class') == rtr_cls) if rtr_cls is not None \
            else (tx.get('groupFilterConditions') is not None)
        if is_router and tx.get('groupFilterConditions'):
            routers.append({
                'name': tx.get('name', ''),
                'groups': tx.get('groups', []),
                'groupFilterConditions': tx.get('groupFilterConditions', [])
            })
    return routers


def _extract_targets(transformations, id_map=None, class_map=None):
    """Extract target transformations (TmplTarget), resolving ##ID references."""
    tgt_cls = (class_map or {}).get('TARGET', 8)
    targets = []
    for tx in transformations:
        if tx.get('$$class') == tgt_cls:
            da = tx.get('dataAdapter', {})
            obj_data = da.get('object', {})

            resolved_mappings = []
            for m in tx.get('manualMappings', {}).get('mappingList', []):
                to_ref = m.get('toField', {})
                to_field = _resolve_ref(to_ref, id_map) if id_map else to_ref
                resolved_mappings.append({
                    'fromFieldName': m.get('fromFieldName', ''),
                    'toField': to_field,
                })

            rich_fields = []
            for f in tx.get('fields', []):
                af_ref = f.get('adapterField', {})
                af = _resolve_ref(af_ref, id_map) if id_map else af_ref
                native = af.get('nativeType', '') if isinstance(af, dict) else ''
                dtype = native or _type_from_platform(f.get('platformType'), id_map)
                rich_fields.append({
                    'id': f.get('$$ID'),
                    'name': f.get('name', ''),
                    'precision': f.get('precision', ''),
                    'datatype': dtype,
                })

            target = {
                'name': tx.get('name', ''),
                'path': obj_data.get('path', obj_data.get('objectName', '')),
                'objectName': obj_data.get('objectName', ''),
                'object': obj_data,
                'fields': rich_fields,
                'manualMappings': {'mappingList': resolved_mappings},
                'updateColumns': tx.get('updateColumns', []),
                'writeOptions': da.get('writeOptions', {}),
                'runtimeAttributes': da.get('runtimeAttributes', {}),
            }
            targets.append(target)
    return targets


def _get_tx_type_label(tx_class, tx=None, class_map=None):
    """Get human-readable transformation type label."""
    cm = class_map or {}
    reverse = {v: k for k, v in cm.items()}
    canonical = reverse.get(tx_class)
    label_map = {
        'SOURCE': 'Source Qualifier',
        'EXPRESSION': 'Expression',
        'ROUTER': 'Router',
        'TARGET': 'Target Definition',
    }
    if canonical:
        return label_map.get(canonical, canonical)
    if tx is not None and any(f.get('expFieldType') for f in tx.get('fields', [])):
        return 'Expression'
    return 'Unknown'


def _get_layout_coordinates(annotations):
    """Return dict of tx_name -> 'x_norm, seq' from the layout annotation blob."""
    for ann in annotations:
        if ann.get('$$class') == 2:
            try:
                blob = json.loads(ann.get('jsonBlob', '{}'))
                sorted_items = sorted(blob.items(), key=lambda i: (i[1].get('y', 0), i[1].get('x', 0)))
                return {name: f"{pos.get('y', 0) / 100:.2f}, {seq}"
                        for seq, (name, pos) in enumerate(sorted_items, 1)}
            except Exception:
                pass
    return {}


# ========================================================================
# Excel Generation
# ========================================================================

def _create_excel_mapping_sheet(mapping_info, output_file):
    """Generate Excel with 3 sheets: Details, Mappings, Transformations."""

    wb = Workbook()

    HEADER_FILL = PatternFill(start_color="B9BCBC", end_color="B9BCBC", fill_type="solid")
    HEADER_FONT = Font(bold=True)

    def lbl(ws, row, col, text):
        c = ws.cell(row=row, column=col, value=text)
        c.fill = HEADER_FILL
        c.font = HEADER_FONT

    def val(ws, row, col, text):
        ws.cell(row=row, column=col, value=text)

    id_map = mapping_info.get('id_map', {})
    class_map = mapping_info.get('class_map', {})
    txs = mapping_info['transformations']
    sources = _extract_sources(txs, id_map, class_map)
    exprs = _extract_expressions(txs, class_map)
    routers = _extract_routers(txs, class_map)
    targets = _extract_targets(txs, id_map, class_map)
    coords = _get_layout_coordinates(mapping_info['annotations'])

    # Build expression-output lookup
    expr_lookup = {}
    for ex in exprs:
        for f in ex['fields']:
            if f.get('expFieldType') == 'OUTPUT':
                expr_lookup[f['name']] = {
                    'expression': f.get('expression', ''),
                    'datatype': _type_from_platform(f.get('platformType'), id_map),
                    'precision': f.get('precision', ''),
                }

    # Build source-field lookup
    src_field_lookup = {}
    for src in sources:
        for f in src['fields']:
            src_field_lookup[f['name']] = {
                'object_name': src.get('object_name', src.get('name', '')),
                'datatype': f.get('datatype', ''),
                'precision': f.get('precision', ''),
            }

    # ══════════════════════════════════════════════════════════════════════
    # SHEET 1 – Details
    # ══════════════════════════════════════════════════════════════════════
    ws_det = wb.active
    ws_det.title = "Details"

    # Row 1 – Mapping header
    lbl(ws_det, 1, 1, 'Mapping Name')
    val(ws_det, 1, 2, mapping_info['name'])
    lbl(ws_det, 1, 3, 'Mapping Complexity')
    val(ws_det, 1, 4, 'Medium')

    # Row 2 – Source info
    src0 = sources[0] if sources else {}
    src_obj = src0.get('object', {})
    lbl(ws_det, 2, 1, 'Source Name')
    val(ws_det, 2, 2, src0.get('object_name', src0.get('name', '')))
    lbl(ws_det, 2, 3, 'Source Type')
    val(ws_det, 2, 4, src_obj.get('objectType', ''))
    lbl(ws_det, 2, 5, 'Source DB Name')
    val(ws_det, 2, 6, src0.get('db_name', ''))
    lbl(ws_det, 2, 7, 'Source Qualifier Query')
    val(ws_det, 2, 8, 'Yes' if src_obj.get('customQuery') else 'No')

    # Row 3 – First target + SQL
    tgt0 = targets[0] if targets else {}
    tgt0_obj = tgt0.get('object', {})
    lbl(ws_det, 3, 1, 'Target Name')
    val(ws_det, 3, 2, tgt0_obj.get('objectName', tgt0.get('name', '')))
    lbl(ws_det, 3, 3, 'Target Type')
    val(ws_det, 3, 4, tgt0_obj.get('objectType', ''))
    lbl(ws_det, 3, 7, 'Source Qualifier Query')
    sql_cell = ws_det.cell(row=3, column=8, value=src_obj.get('customQuery', ''))
    sql_cell.alignment = Alignment(wrap_text=True, vertical='top')
    ws_det.merge_cells('H3:H8')
    ws_det.row_dimensions[3].height = 300

    # Rows 4-5 – Additional targets
    for extra_row, tgt in zip([4, 5], targets[1:3]):
        tobj = tgt.get('object', {})
        lbl(ws_det, extra_row, 1, 'Target Name')
        val(ws_det, extra_row, 2, tobj.get('objectName', tgt.get('name', '')))
        lbl(ws_det, extra_row, 3, 'Target Type')
        val(ws_det, extra_row, 4, tobj.get('objectType', ''))

    # Rows 6-8 – Router / Filter conditions
    filter_entries = []
    for rtr in routers:
        for cond in rtr['groupFilterConditions']:
            filter_entries.append((rtr['name'], cond.get('advancedFilterCondition', '')))

    for idx, (rname, rcond) in enumerate(filter_entries[:3], 1):
        r = 5 + idx
        lbl(ws_det, r, 1, f'Filter{idx} Name')
        val(ws_det, r, 2, rname)
        lbl(ws_det, r, 3, f'Filter{idx} Condition')
        val(ws_det, r, 4, rcond)

    # Rows 9-10 – Stored procedures (labels only)
    lbl(ws_det, 9, 1, 'Stored Procedure1 Name')
    lbl(ws_det, 9, 3, 'Procedure1 Type')
    lbl(ws_det, 9, 5, 'Procedure1 Call')
    lbl(ws_det, 10, 1, 'Stored Procedure2 Name')
    lbl(ws_det, 10, 3, 'Procedure2 Type')
    lbl(ws_det, 10, 5, 'Procedure2 Call')

    # Column widths for Details sheet
    for col_letter, width in {'A': 26, 'B': 32, 'C': 26, 'D': 32, 'E': 26, 'F': 24, 'G': 22, 'H': 48}.items():
        ws_det.column_dimensions[col_letter].width = width

    # ══════════════════════════════════════════════════════════════════════
    # SHEET 2 – Mappings
    # ══════════════════════════════════════════════════════════════════════
    ws_map = wb.create_sheet("Mappings")

    # Row 1 – Header
    for col, heading in [(1, 'Source Object'), (2, 'Source Field'), (3, 'Source Datatype'),
                         (4, 'Source Precision'), (5, 'Transformation Logic'),
                         (6, 'Target Object'), (7, 'Target Field'),
                         (8, 'Target Datatype'), (9, 'Target Precision'), (10, 'Key')]:
        lbl(ws_map, 1, col, heading)

    # Rows 2+ – Field-level mappings
    data_row = 2
    seen = set()
    for tgt in targets:
        tgt_path = tgt.get('path', tgt.get('objectName', tgt.get('name', '')))
        update_cols = tgt.get('updateColumns', [])
        mappings = tgt.get('manualMappings', {}).get('mappingList', [])

        to_id_to_from = {m['toField'].get('$$ID'): m['fromFieldName'] for m in mappings if
                         m['toField'].get('$$ID')}
        to_name_to_from = {m['toField'].get('name'): m['fromFieldName'] for m in mappings if
                           m['toField'].get('name')}

        for tf in tgt.get('fields', []):
            tgt_field = tf.get('name', '')
            tgt_prec = tf.get('precision', '')
            tgt_dtype = tf.get('datatype', '')

            key = f"{tgt_path}|{tgt_field}"
            if key in seen:
                continue
            seen.add(key)

            from_field = to_id_to_from.get(tf.get('id')) or to_name_to_from.get(tgt_field, '')

            if from_field and from_field in expr_lookup:
                ei = expr_lookup[from_field]
                src_obj_name = ''
                src_fld = ''
                src_dt = ''
                src_prec = ''
                logic = ei.get('expression', '')
            elif from_field and from_field in src_field_lookup:
                fi = src_field_lookup[from_field]
                src_obj_name = fi.get('object_name', '')
                src_fld = from_field
                src_dt = fi.get('datatype', '')
                src_prec = fi.get('precision', '')
                logic = ''
            else:
                src_obj_name = ''
                src_fld = from_field
                src_dt = ''
                src_prec = ''
                logic = ''

            val(ws_map, data_row, 1, src_obj_name)
            val(ws_map, data_row, 2, src_fld)
            val(ws_map, data_row, 3, src_dt)
            val(ws_map, data_row, 4, src_prec)
            val(ws_map, data_row, 5, logic)
            val(ws_map, data_row, 6, tgt_path)
            val(ws_map, data_row, 7, tgt_field)
            val(ws_map, data_row, 8, tgt_dtype)
            val(ws_map, data_row, 9, tgt_prec)
            val(ws_map, data_row, 10, 'YES' if tgt_field in update_cols else '')
            data_row += 1

    # Column widths for Mappings sheet
    for col_letter, width in {'A': 30, 'B': 32, 'C': 18, 'D': 14, 'E': 45,
                              'F': 38, 'G': 32, 'H': 18, 'I': 14, 'J': 8}.items():
        ws_map.column_dimensions[col_letter].width = width

    # ══════════════════════════════════════════════════════════════════════
    # SHEET 3 – Transformations
    # ══════════════════════════════════════════════════════════════════════
    ws_tx = wb.create_sheet("Transformations")

    lbl(ws_tx, 1, 1, 'Transformation Name')
    lbl(ws_tx, 1, 2, 'Coordinates')
    lbl(ws_tx, 1, 3, 'Transformation Type')

    for tx_row, tx in enumerate(txs, 2):
        tx_name = tx.get('name', '')
        val(ws_tx, tx_row, 1, tx_name)
        val(ws_tx, tx_row, 2, coords.get(tx_name, ''))
        val(ws_tx, tx_row, 3, _get_tx_type_label(tx.get('$$class'), tx, class_map))

    for col_letter, width in {'A': 36, 'B': 18, 'C': 24}.items():
        ws_tx.column_dimensions[col_letter].width = width

    wb.save(output_file)
    logger.info(f"Generated Excel: {output_file}")


# ========================================================================
# Main DAAN 5 Native Tool Class
# ========================================================================

class IICSSttmGenerator:
    """
    DAAN 5 Native Tool class for IICS STTM Excel generation.
    Keep class+method stable for tools_loader mapping.
    """

    def __init__(self, data_dir: Optional[str] = None, **_: Any) -> None:
        self.tool_name = "IICSSttmGenerator"
        self.data_dir = data_dir
        logger.info("IICSSttmGenerator v%s loaded (data_dir=%s)", _TOOL_VERSION, data_dir)

    def generate_sttm_excel(
            self,
            input_path: str | None = None,
            output_dir: str | None = None,
            **kwargs: Any,
    ) -> str:
        """
        Generate STTM Excel documentation from IICS .DTEMPLATE exports.

        This tool converts Informatica Intelligent Cloud Services (IICS) mapping exports
        into comprehensive Source-to-Target Mapping (STTM) Excel documentation with detailed
        mapping specifications.

        Args:
            input_path: Path to IICS export in one of these formats:
                       - Path to .zip file containing .DTEMPLATE folder(s)
                       - Path to .DTEMPLATE folder directly
                       - None: Tool will auto-detect from session data directory

                       Example paths:
                       - "C:/mappings/export.zip"
                       - "C:/mappings/m_Load_Customer.DTEMPLATE"

            output_dir: Directory where generated Excel files will be saved.
                       If not provided, files are saved to:
                       - Same directory as input zip file
                       - Same directory as .DTEMPLATE folder
                       - Session data directory (if auto-detected)

        Returns:
            Success message with path(s) to generated STTM Excel file(s).
            Each .DTEMPLATE mapping generates one .xlsx file with 3 sheets:
            - Details: Mapping overview, source/target info, filters, procedures
            - Mappings: Field-level source-to-target mappings with transformations
            - Transformations: Complete list of transformations with coordinates

        Excel Sheet Structure:
            Details Sheet:
            - Mapping Name, Complexity
            - Source Name, Type, DB Name, SQL Query
            - Target Name(s), Type(s)
            - Filter/Router conditions
            - Stored procedure placeholders

            Mappings Sheet (STTM):
            - Source Object, Field, Datatype, Precision
            - Transformation Logic (expressions)
            - Target Object, Field, Datatype, Precision
            - Key column indicator

            Transformations Sheet:
            - Transformation Name
            - Layout Coordinates
            - Transformation Type (Source Qualifier, Expression, Router, Target, etc.)

        Examples:
            # Process a zip file
            result = generate_sttm_excel(input_path="C:/exports/mappings.zip")

            # Process a single .DTEMPLATE folder
            result = generate_sttm_excel(
                input_path="C:/exports/m_Load_Customer.DTEMPLATE",
                output_dir="C:/documentation"
            )

            # Auto-detect from session (file uploaded via DAAN UI)
            result = generate_sttm_excel()

        Raises:
            FileNotFoundError: If input_path does not exist or no .DTEMPLATE found
            ValueError: If input_path is not a valid zip or .DTEMPLATE folder
            Exception: If mapping parsing or Excel generation fails
        """

        # Normalize input path
        resolved_path = self._resolve_input_path(input_path)
        resolved_path = Path(resolved_path)

        # Determine output directory
        if output_dir:
            output_dir = Path(output_dir)
        else:
            output_dir = resolved_path.parent if resolved_path.is_file() else resolved_path

        output_dir.mkdir(parents=True, exist_ok=True)

        # Process based on input type
        if resolved_path.is_file() and resolved_path.suffix == '.zip':
            return self._process_zip(resolved_path, output_dir)
        elif resolved_path.is_dir() and resolved_path.suffix == '.DTEMPLATE':
            return self._process_single_mapping(resolved_path, output_dir)
        elif resolved_path.is_dir():
            return self._process_all_mappings(resolved_path, output_dir)
        else:
            raise ValueError(f"Invalid input: {resolved_path}. Must be .zip file or .DTEMPLATE folder")

    def _resolve_input_path(self, input_path: str | None) -> str:
        """Resolve input path from explicit path or auto-detect from session."""
        if input_path:
            return input_path

        # Auto-detect from session data directory
        if self.data_dir:
            data_path = Path(self.data_dir)
            if data_path.exists():
                # Look for zip files first
                zip_files = list(data_path.glob("*.zip"))
                if zip_files:
                    logger.info(f"Auto-detected zip file: {zip_files[0]}")
                    return str(zip_files[0])

                # Look for .DTEMPLATE folders
                template_folders = list(data_path.rglob("*.DTEMPLATE"))
                if template_folders:
                    logger.info(f"Auto-detected .DTEMPLATE folder: {template_folders[0]}")
                    return str(template_folders[0])

        raise ValueError(
            "No input_path provided and could not auto-detect IICS files. "
            "Please provide input_path parameter or upload IICS export file."
        )

    def _process_zip(self, zip_path: Path, output_dir: Path) -> str:
        """Process a zip file containing one or more .DTEMPLATE folders."""
        temp_dir = None
        try:
            temp_dir = _extract_zip(zip_path)

            # Check if .DTEMPLATE subfolders exist
            template_folders = list(temp_dir.rglob("*.DTEMPLATE"))
            template_folders = [f for f in template_folders if f.is_dir()]

            if template_folders:
                # Zip contains .DTEMPLATE subfolders
                result = self._process_all_mappings(temp_dir, output_dir)
                return f"Processed zip: {zip_path.name}\n{result}"
            else:
                # Zip IS the mapping (flat structure)
                mapping_name = zip_path.stem
                for suffix in ('.zip', '.DTEMPLATE'):
                    if mapping_name.endswith(suffix):
                        mapping_name = mapping_name[:-len(suffix)]
                output_file = output_dir / f"{mapping_name}.xlsx"

                logger.info(f"Processing flat zip: {zip_path.name}")
                mapping_info = _parse_iics_mapping(temp_dir)
                _create_excel_mapping_sheet(mapping_info, output_file)

                return f"✓ Generated: {output_file}"

        finally:
            if temp_dir and temp_dir.exists():
                shutil.rmtree(temp_dir, ignore_errors=True)

    def _process_single_mapping(self, template_folder: Path, output_dir: Path) -> str:
        """Process a single .DTEMPLATE folder."""
        mapping_name = template_folder.name.replace('.DTEMPLATE', '')
        output_file = output_dir / f"{mapping_name}.xlsx"

        logger.info(f"Processing mapping: {template_folder.name}")
        mapping_info = _parse_iics_mapping(template_folder)
        _create_excel_mapping_sheet(mapping_info, output_file)

        return f"✓ Generated: {output_file}"

    def _process_all_mappings(self, base_path: Path, output_dir: Path) -> str:
        """Process all .DTEMPLATE folders found in base_path."""
        template_folders = list(base_path.rglob("*.DTEMPLATE"))
        template_folders = [f for f in template_folders if f.is_dir()]

        if not template_folders:
            return f"No .DTEMPLATE folders found in: {base_path}"

        results = []
        results.append(f"Found {len(template_folders)} mapping(s) to process")

        for folder in template_folders:
            try:
                mapping_name = folder.name.replace('.DTEMPLATE', '')
                output_file = output_dir / f"{mapping_name}.xlsx"

                logger.info(f"Processing: {folder.name}")
                mapping_info = _parse_iics_mapping(folder)
                _create_excel_mapping_sheet(mapping_info, output_file)

                results.append(f"✓ {mapping_name}.xlsx")

            except Exception as e:
                logger.error(f"Error processing {folder.name}: {str(e)}")
                results.append(f"✗ {folder.name}: {str(e)}")

        results.append(f"\nCompleted processing {len(template_folders)} mapping(s)")
        results.append(f"Output directory: {output_dir}")

        return "\n".join(results)
