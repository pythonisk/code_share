"""CosmosDB Gremlin graph client for CRM offering keyword lookups.

Graph schema (ontology_full_load.py):
  Vertices: BusinessUnit, Category, Offering, Capability, Keyword, Platform, Accelerator
  Edges:    HAS_CATEGORY, HAS_OFFERING, HAS_CAPABILITY, TAGGED_WITH, USES_PLATFORM, HAS_ACCELERATOR

Matching strategy:
  Every Offering is linked to Keyword nodes via TAGGED_WITH edges.
  Keyword.value is a comma-separated string of many related terms.
  We normalise both sides and count how many row keywords appear in any offering keyword value.
  Score = unique_matched_row_keywords / total_row_keywords  (0.0-1.0)
"""

from __future__ import annotations

import json
import logging
import os
import re
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# A single-word input term that overlaps with this fraction (or more) of ALL
# offerings in the graph carries no discriminating signal (it is effectively a
# generic/ubiquitous term) and is suppressed. This is a DATA-DRIVEN replacement
# for hand-maintained generic-word lists: the graph itself decides what is too
# common to be meaningful. Multi-word phrases are never suppressed.
GENERIC_DF_RATIO = 0.5


def _resolve_env(primary_env_var: str, fallback_env_var: str) -> str:
    primary_value = os.getenv(primary_env_var, "").strip()
    if primary_value:
        return primary_value
    return os.getenv(fallback_env_var, "").strip()


class CosmosGraphClient:
    """Thin Gremlin client for the D&A offering ontology graph.

    Preferred usage (context manager):
        with CosmosGraphClient() as client:
            results = client.query_offerings_by_keywords(["data marketplace", ...])

    Manual usage:
        client = CosmosGraphClient(key="<key>")
        client.connect()
        results = client.query_offerings_by_keywords([...])
        client.close()
    """

    def __init__(
        self,
        endpoint: Optional[str] = None,
        database: Optional[str] = None,
        graph: Optional[str] = None,
        key: Optional[str] = None,
    ):
        self._endpoint = (endpoint or _resolve_env("GREMLIN_ENDPOINT", "GREMLIN_ENDPOINT_FALLBACK")).strip()
        self._database = (database or _resolve_env("GREMLIN_DATABASE", "GREMLIN_DATABASE_FALLBACK")).strip()
        self._graph = (graph or _resolve_env("GREMLIN_GRAPH", "GREMLIN_GRAPH_FALLBACK")).strip()
        self._key = (key or _resolve_env("GREMLIN_KEY", "GREMLIN_KEY_FALLBACK")).strip()
        self._client = None

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Open the Gremlin websocket connection."""
        try:
            from gremlin_python.driver import client as gmod, serializer
            from gremlin_python.driver.aiohttp.transport import AiohttpTransport
        except ImportError:
            raise ImportError(
                "gremlinpython is not installed. "
                "Run: pip install \"gremlinpython>=3.7.0\""
            )

        missing = []
        if not self._key:
            missing.append("GREMLIN_KEY or GREMLIN_KEY_FALLBACK")
        if not self._endpoint:
            missing.append("GREMLIN_ENDPOINT or GREMLIN_ENDPOINT_FALLBACK")
        if not self._database:
            missing.append("GREMLIN_DATABASE or GREMLIN_DATABASE_FALLBACK")
        if not self._graph:
            missing.append("GREMLIN_GRAPH or GREMLIN_GRAPH_FALLBACK")
        if missing:
            raise ValueError(
                "Missing required Gremlin connection settings: "
                + ", ".join(missing)
                + ". Set them as environment variables or pass explicit constructor arguments."
            )

        self._client = gmod.Client(
            self._endpoint,
            "g",
            transport_factory=lambda: AiohttpTransport(call_from_event_loop=True),
            username=f"/dbs/{self._database}/colls/{self._graph}",
            password=self._key,
            message_serializer=serializer.GraphSONSerializersV2d0(),
        )

    def close(self) -> None:
        if self._client:
            try:
                self._client.close()
            except Exception:
                pass
            self._client = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *_):
        self.close()

    # ------------------------------------------------------------------
    # Primary public method
    # ------------------------------------------------------------------

    def query_offerings_by_keywords(
        self,
        row_keywords: List[str],
        top_n: int = 3,
        min_score: float = 0.10,
    ) -> List[Dict[str, Any]]:
        """Find offerings whose TAGGED_WITH keyword nodes overlap with row_keywords.

        Args:
            row_keywords: combined list of extracted_keywords + extracted_phrases
                          for one CRM opportunity row.
            top_n:        max offerings to return, ranked by score desc.
            min_score:    minimum fraction of row_keywords that must match (0.0-1.0).
                          Rows below this -> caller routes to no_recommendation.

        Returns:
            List of dicts ordered by score descending:
            [
              {
                "offering_id":   "offering:dna-001",
                "name":          "Next Gen Data Modernization",
                "category":      "Enterprise Data Platforms",
                "score":         0.75,
                "matched_terms": ["cloud data platform", "data modernization"],
              },
              ...
            ]
            Empty list if nothing meets min_score.
        """
        if not self._client:
            self.connect()

        if not row_keywords:
            return []

        norm_row = [_norm(k) for k in row_keywords if k]
        if not norm_row:
            return []

        raw = self._fetch_offering_keyword_map()
        if not raw:
            logger.warning("CosmosGraphClient: no offering-keyword data returned from graph")
            return []

        per_offering: List[Dict[str, Any]] = []
        term_doc_freq: Dict[str, int] = {}
        for entry in raw:
            oid = entry["offering_id"]
            kw_terms = [
                _norm(t)
                for t in re.split(r"[,\n]+", entry["keyword_value"])
                if t.strip()
            ]

            matched_row_terms = set()
            matched_graph_terms = set()
            for rk in norm_row:
                matching_terms = [kt for kt in kw_terms if _term_matches(rk, kt)]
                if matching_terms:
                    matched_row_terms.add(rk)
                    matched_graph_terms.update(matching_terms)

            if not matched_row_terms:
                continue

            per_offering.append({
                "offering_id": oid,
                "name": entry["offering_name"],
                "category": entry.get("category", ""),
                "matched_row_terms": matched_row_terms,
                "matched_graph_terms": matched_graph_terms,
            })
            for term in matched_row_terms:
                term_doc_freq[term] = term_doc_freq.get(term, 0) + 1

        if not per_offering:
            return []

        total_offerings = max(len(raw), 1)
        generic_terms = {
            term
            for term, freq in term_doc_freq.items()
            if " " not in term and (freq / total_offerings) >= GENERIC_DF_RATIO
        }

        scores: Dict[str, Dict[str, Any]] = {}
        for off in per_offering:
            discriminating = off["matched_row_terms"] - generic_terms
            if not discriminating:
                continue
            scores[off["offering_id"]] = {
                "offering_id": off["offering_id"],
                "name": off["name"],
                "category": off["category"],
                "matched_terms": off["matched_graph_terms"],
                "matched_input_terms": discriminating,
            }

        if not scores:
            return []

        meaningful_row_terms = [t for t in norm_row if t not in generic_terms]
        total = max(len(meaningful_row_terms), 1)
        results = []
        for data in scores.values():
            unique = list(data["matched_terms"])
            matched_inputs = list(data["matched_input_terms"])
            score = len(matched_inputs) / total
            if score >= min_score:
                term_powers = [
                    1.0 - (term_doc_freq.get(t, 0) / max(total_offerings, 1))
                    for t in matched_inputs
                ]
                min_power = min(term_powers) if term_powers else 0.0
                term_specificity = {
                    t: round(1.0 - (term_doc_freq.get(t, 0) / max(total_offerings, 1)), 3)
                    for t in matched_inputs
                }
                results.append({
                    "offering_id": data["offering_id"],
                    "name": data["name"],
                    "category": data["category"],
                    "score": round(score, 4),
                    "matched_terms": unique,
                    "matched_input_terms": matched_inputs,
                    "term_discriminating_power": round(min_power, 3),
                    "term_specificity_breakdown": term_specificity,
                })

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_n]

    def get_offering_details(self, offering_id: str) -> Optional[Dict[str, Any]]:
        """Fetch full vertex properties for a single offering node."""
        if not self._client:
            self.connect()
        result = self._exec(
            f"g.V().has('id', {json.dumps(offering_id)}).valueMap(true)"
        )
        return _parse_valuemap(result[0]) if result else None

    def fetch_offering_subgraph(self, offering_id: str) -> Dict[str, Any]:
        """Fetch enriched subgraph for one offering: capabilities, platforms, keywords."""
        if not self._client:
            self.connect()

        oid_q = json.dumps(offering_id)
        subgraph: Dict[str, Any] = {
            "offering_id": offering_id,
            "name": "",
            "category": "",
            "capabilities": [],
            "platforms": [],
            "keywords": [],
        }

        details = self.get_offering_details(offering_id)
        if details:
            subgraph["name"] = details.get("name", "")

        try:
            cap_rows = self._exec(
                f"g.V().has('id', {oid_q})"
                f".out('HAS_CAPABILITY').hasLabel('Capability').values('name')"
            ) or []
            subgraph["capabilities"] = [str(v) for v in cap_rows if v]
        except Exception as exc:
            logger.debug("fetch_offering_subgraph capabilities failed for %s: %s", offering_id, exc)

        try:
            plat_rows = self._exec(
                f"g.V().has('id', {oid_q})"
                f".out('HAS_CAPABILITY').out('IMPLEMENTS_ON').hasLabel('Platform').values('name')"
            ) or []
            subgraph["platforms"] = list({str(v) for v in plat_rows if v})
        except Exception as exc:
            logger.debug("fetch_offering_subgraph platforms failed for %s: %s", offering_id, exc)

        try:
            kw_rows = self._exec(
                f"g.V().has('id', {oid_q})"
                f".out('TAGGED_WITH').hasLabel('Keyword').values('value')"
            ) or []
            kw_terms: List[str] = []
            for kw_val in kw_rows:
                kw_terms.extend(
                    t.strip() for t in re.split(r"[,\n]+", str(kw_val)) if t.strip()
                )
            subgraph["keywords"] = kw_terms[:30]
        except Exception as exc:
            logger.debug("fetch_offering_subgraph keywords failed for %s: %s", offering_id, exc)

        return subgraph

    def _fetch_offering_keyword_map(self) -> List[Dict[str, Any]]:
        """Two-query fetch: Offering --TAGGED_WITH--> Keyword."""
        pairs_raw = self._exec(
            "g.V().hasLabel('Offering').as('off')"
            ".out('TAGGED_WITH').hasLabel('Keyword').as('kw')"
            ".select('off','kw')"
            ".by(id())"
            ".by(values('value'))"
        ) or []

        if not pairs_raw:
            logger.warning("CosmosGraphClient: no offering-keyword pairs returned from graph")
            return []

        names_raw = self._exec(
            "g.V().hasLabel('Offering')"
            ".project('oid','name')"
            ".by(id())"
            ".by(values('name'))"
        ) or []
        name_map: Dict[str, str] = {
            str(r.get("oid", "")): str(r.get("name", ""))
            for r in names_raw
        }

        rows = []
        for pair in pairs_raw:
            oid = str(pair.get("off", ""))
            val = str(pair.get("kw", ""))
            if oid and val:
                rows.append({
                    "offering_id": oid,
                    "offering_name": name_map.get(oid, oid),
                    "keyword_value": val,
                    "category": "",
                })

        try:
            cat_rows = self._exec(
                "g.V().hasLabel('Category').as('cat')"
                ".out('HAS_OFFERING').hasLabel('Offering').as('off')"
                ".select('cat','off')"
                ".by(values('name'))"
                ".by(id())"
            ) or []
            cat_map = {
                str(r.get("off", "")): str(r.get("cat", ""))
                for r in cat_rows
            }
            for r in rows:
                r["category"] = cat_map.get(r["offering_id"], "")
        except Exception as exc:
            logger.debug("Category enrichment skipped: %s", exc)

        return rows

    def _exec(self, query: str) -> Optional[List[Any]]:
        try:
            return self._client.submit(query).all().result()
        except Exception as exc:
            logger.error("Gremlin query failed [%.200s]: %s", query, exc)
            return None


def _norm(text: str) -> str:
    """Lowercase, strip, collapse whitespace."""
    return re.sub(r"\s+", " ", str(text).lower().strip())


def _term_matches(input_term: str, graph_term: str) -> bool:
    """Match phrases loosely, but keep single-word terms strict."""
    input_term = _norm(input_term)
    graph_term = _norm(graph_term)

    if not input_term or not graph_term:
        return False

    if " " in input_term:
        return input_term in graph_term

    return input_term in set(graph_term.split())


def _first(val: Any) -> Any:
    """GraphSON valueMap wraps scalars in lists — unwrap the first element."""
    if isinstance(val, list):
        return val[0] if val else None
    return val


def _parse_valuemap(vm: Dict) -> Dict[str, Any]:
    """Flatten GraphSON valueMap (all values are lists) to a plain dict."""
    return {k: _first(v) for k, v in vm.items()}