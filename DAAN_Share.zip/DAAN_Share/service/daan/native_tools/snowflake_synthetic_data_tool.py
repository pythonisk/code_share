import logging
from typing import Any, Dict, List, Optional

from daan.native_tools.synthetic_data_tool import SyntheticDataTool

logger = logging.getLogger(__name__)


class SnowflakeSyntheticDataTool:
    """Snowflake-specific SDG wrapper for UC_CP_026.

    Registered in agent config as: ``SnowflakeSyntheticDataTool.execute_generation``.

    This tool intentionally handles only the synthetic data generation phase.
    Snowflake validate/extract/upload remain MCP tool responsibilities for the
    action agent. By the time this tool runs, MCP extraction should already have
    written session inputs/ files for the selected source tables.
    """

    def __init__(self, data_dir: Optional[str] = None):
        self.tool_name = "SnowflakeSyntheticDataTool"
        self._delegate = SyntheticDataTool(data_dir=data_dir, tool_name=self.tool_name)
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    def execute_generation(
        self,
        reviewed_output: Optional[Dict[str, Any] | str] = None,
        agent_id: str = "unknown",
        agent_name: str = "Unknown Agent",
        session_id: Optional[str] = None,
        tables: Optional[List[str]] = None,
        row_counts: Optional[Dict[str, int]] = None,
        sample_size: int = 10000,
        database: str = "",
        schema: str = "",
        upload_to_snowflake: bool = True,
        target_schema: str = "",
        target_database: str = "",
    ) -> Dict[str, Any]:
        """Run only the local generation phase using session inputs already fetched via MCP.

        Extra Snowflake-related parameters are accepted to keep the ADK tool
        signature aligned with the execution plan, but generation itself uses
        the session inputs/ folder prepared by MCP extraction.
        """
        result = self._delegate.execute_generation(
            reviewed_output=reviewed_output if isinstance(reviewed_output, dict) else None,
            agent_id=agent_id,
            agent_name=agent_name,
            session_id=session_id,
        )

        if result.get("status") == "error":
            message = str(result.get("message", ""))
            if "requirements.csv not found" in message or "Missing table CSV(s):" in message:
                result = dict(result)
                result["message"] = (
                    "Snowflake sample data has not been prepared for this session. "
                    "Call sdg_extract_schema_and_samples first so MCP fetches the selected tables into the session inputs folder, "
                    "then call SnowflakeSyntheticDataTool.execute_generation. "
                    f"Original error: {message}"
                )
            return result

        output_files = result.get("output_files") or []
        generated_tables = []
        for path in output_files:
            path_text = str(path)
            if path_text.lower().endswith(".csv"):
                generated_tables.append(path_text.rsplit("/", 1)[-1].rsplit("\\", 1)[-1].rsplit(".", 1)[0].upper())

        generated_table_count = len(generated_tables)
        generated_file_count = int(result.get("tables_generated", 0) or 0)

        return {
            "status": result.get("status", "success"),
            "message": result.get("message", "Synthetic data generation completed."),
            "agent_id": result.get("agent_id", agent_id),
            "agent_name": result.get("agent_name", agent_name),
            "tables_generated": generated_table_count,
            "generated_file_count": generated_file_count,
            "generated_tables": generated_tables,
            "output_files": output_files,
            "output_dir": result.get("output_dir"),
            "execution_log": result.get("execution_log", {}),
            "quality_scores": result.get("quality_scores", {}),
            "timestamp": result.get("timestamp"),
        }


__all__ = ["SnowflakeSyntheticDataTool"]
