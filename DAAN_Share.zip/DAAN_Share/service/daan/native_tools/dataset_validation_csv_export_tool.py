from __future__ import annotations

import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

from daan.flow.session_service import get_artifacts_dir

logger = logging.getLogger(__name__)


class DatasetValidationCSVExportTool:
    """
    Exports Dataset Validation reports (markdown format) into a 
    consolidated Excel workbook with multiple sheets.
    """

    def __init__(self, data_dir: str | None = None):
        self.tool_name = "DatasetValidationCSVExportTool"
        self._data_dir = data_dir
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    def export_validation_to_csv(
        self,
        report_markdown: str,
        output_file_name: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Parse a Dataset Validation report and export every table as a sheet in one Excel file.
        """
        try:
            if not report_markdown or not report_markdown.strip():
                return {"status": "error", "errors": ["No report markdown provided"]}

            prefix = output_file_name or "dataset_validation"
            artifacts_dir = self._resolve_artifacts_dir()
            tables = self._extract_all_markdown_tables(report_markdown)

            if not tables:
                return {"status": "error", "errors": ["No tables found in report"]}

            # Collect data for the Excel workbook
            sheet_data: list[tuple[str, pd.DataFrame]] = []
            used_keys: dict[str, int] = {}

            for section_name, df in tables:
                base_key = self._section_to_filename(section_name)
                
                # Ensure unique sheet names
                count = used_keys.get(base_key, 0) + 1
                used_keys[base_key] = count
                key = base_key if count == 1 else f"{base_key}_{count}"
                
                sheet_data.append((self._sanitize_sheet_name(key), df))

            # Save the consolidated Excel workbook
            consolidated_filename = f"{prefix}_report.xlsx"
            consolidated_path = self._save_consolidated_excel(
                artifacts_dir, sheet_data, consolidated_filename
            )

            return {
                "status": "ok",
                "message": f"Successfully exported report to {consolidated_path.name} with {len(sheet_data)} sheets.",
                "artifact_files": {"report": consolidated_path.name},
                "artifact_paths": {"report": str(consolidated_path)},
                "extraction_summary": {
                    "sheets_in_workbook": len(sheet_data),
                    "timestamp": datetime.now().isoformat(),
                },
            }

        except Exception as exc:
            logger.exception("%s: Export failed", self.tool_name)
            return {"status": "error", "errors": [str(exc)]}

    def _extract_all_markdown_tables(self, markdown_text: str) -> list[tuple[str, pd.DataFrame]]:
        results = []
        lines = markdown_text.split("\n")
        current_headings = {}
        i = 0
        while i < len(lines):
            line = lines[i]
            heading_match = re.match(r"^(#{1,4})\s+(.*)", line)
            if heading_match:
                level = len(heading_match.group(1))
                clean_text = re.sub(r"\*+", "", heading_match.group(2)).strip().rstrip(":")
                for lvl in list(current_headings):
                    if lvl >= level: del current_headings[lvl]
                current_headings[level] = clean_text
                i += 1; continue

            if line.strip().startswith("|") and i + 1 < len(lines) and re.match(r"^\s*\|[\s\-:|]+\|", lines[i + 1]):
                table_lines = []
                while i < len(lines) and lines[i].strip().startswith("|"):
                    table_lines.append(lines[i]); i += 1
                rows = [[c.strip() for c in t.split("|")[1:-1]] for t in table_lines if not re.match(r"^\s*\|[\s\-:|]+\|", t)]
                if len(rows) >= 2:
                    df = pd.DataFrame(rows[1:], columns=rows[0])
                    section_name = current_headings.get(max(current_headings.keys()), "Table") if current_headings else "Table"
                    results.append((section_name, df))
                continue
            i += 1
        return results

    def _section_to_filename(self, section_name: str) -> str:
        cleaned = re.sub(r"^[\d\w]+[.)]\s*", "", section_name).strip()
        cleaned = re.sub(r"\(.*?\)", "", cleaned).strip()
        return re.sub(r"[^\w]+", "_", cleaned.lower()).strip("_")[:30]

    def _sanitize_sheet_name(self, name: str) -> str:
        cleaned = re.sub(r"[\\/*?\[\]:]", "", name).strip()
        return (cleaned or "Table")[:31]

    def _save_consolidated_excel(self, output_dir: Path, sheet_data: list[tuple[str, pd.DataFrame]], filename: str) -> Path:
        # Overwrite existing file instead of creating new versions (_1, _2, etc.)
        path = output_dir / filename
        with pd.ExcelWriter(path, engine="openpyxl") as writer:
            for sheet_name, df in sheet_data:
                df.to_excel(writer, index=False, sheet_name=sheet_name)
                self._autofit_columns(writer, df, sheet_name)
        return path

    def _autofit_columns(self, writer: pd.ExcelWriter, df: pd.DataFrame, sheet_name: str) -> None:
        worksheet = writer.sheets[sheet_name]
        for idx, col in enumerate(df.columns):
            series = df.iloc[:, idx]
            data_max_len = series.astype(str).map(len).max() if not series.empty else 0
            max_len = max(int(data_max_len), len(str(col)))
            worksheet.column_dimensions[worksheet.cell(row=1, column=idx + 1).column_letter].width = min(max_len + 2, 50)

    def _resolve_artifacts_dir(self) -> Path:
        if not self._data_dir:
            artifacts_dir = Path(__file__).resolve().parent / "artifacts"
        else:
            data_dir = Path(self._data_dir)
            session_id = self._extract_session_id(data_dir)
            if session_id:
                artifacts_dir = get_artifacts_dir(session_id, create=True)
            else:
                artifacts_dir = data_dir / "artifacts"
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        return artifacts_dir

    def _extract_session_id(self, data_dir: Path) -> str | None:
        data_dir = data_dir.resolve()
        if data_dir.name == "inputs" and data_dir.parent.name:
            return data_dir.parent.name
        if data_dir.parent.name == "session_storage" and data_dir.name:
            return data_dir.name
        return None