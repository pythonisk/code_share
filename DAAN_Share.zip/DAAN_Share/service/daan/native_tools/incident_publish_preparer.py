from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any

from daan.flow.context_vars import daan_session_id
from daan.flow.session_service import get_session_dir
from daan.flow.session_store import get_session

logger = logging.getLogger(__name__)

# Matches ```json ... ``` (or ``` ... ```) fenced blocks emitted by LLMs.
_CODE_FENCE_RE = re.compile(
    r"^\s*```[^\S\r\n]*[A-Za-z0-9_-]*[^\S\r\n]*\r?\n(.*?)\r?\n\s*```\s*$",
    re.DOTALL,
)


def _strip_code_fence(text: str) -> str:
    """Strip a surrounding ```lang ... ``` fence if present."""
    m = _CODE_FENCE_RE.match(text)
    return m.group(1).strip() if m else text.strip()


def _parse_json_value(value: Any) -> Any:
    if isinstance(value, (dict, list)):
        return value
    if not isinstance(value, str):
        return None

    text = _strip_code_fence(value)
    if not text:
        return None

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def _parse_merged_json_chunks(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]

    parsed = _parse_json_value(value)
    if isinstance(parsed, list):
        return [item for item in parsed if isinstance(item, dict)]
    if isinstance(parsed, dict):
        return [parsed]

    if not isinstance(value, str):
        return []

    text = value.strip()
    if not text:
        return []

    rows: list[dict[str, Any]] = []
    for separator in ("\n\n---\n\n", "\r\n\r\n---\r\n\r\n", "\n---\n", "\r\n---\r\n"):
        if separator in text:
            chunks = [chunk.strip() for chunk in text.split(separator) if chunk.strip()]
            for chunk in chunks:
                parsed_chunk = _parse_json_value(chunk)
                if isinstance(parsed_chunk, list):
                    rows.extend(item for item in parsed_chunk if isinstance(item, dict))
                elif isinstance(parsed_chunk, dict):
                    rows.append(parsed_chunk)
            return rows
    return rows


def _coerce_agent_rows(payload: Any, agent_id: str) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        return []

    candidate = payload.get(agent_id)
    rows = _parse_merged_json_chunks(candidate)
    if rows:
        return rows

    for key, value in payload.items():
        if str(key).strip().upper() == agent_id.upper():
            rows = _parse_merged_json_chunks(value)
            if rows:
                return rows
    return []


def _rows_match_keys(rows: list[dict[str, Any]], required_keys: tuple[str, ...]) -> bool:
    if not rows:
        return False
    for row in rows:
        if not isinstance(row, dict):
            continue
        if all(str(row.get(key) or "").strip() for key in required_keys):
            return True
    return False


def _find_rows_by_schema(
    payload: Any,
    *,
    preferred_agent_id: str = "",
    required_keys: tuple[str, ...],
) -> list[dict[str, Any]]:
    preferred = str(preferred_agent_id or "").strip()
    if preferred:
        preferred_rows = _coerce_agent_rows(payload, preferred)
        if _rows_match_keys(preferred_rows, required_keys):
            return preferred_rows

    if not isinstance(payload, dict):
        return []

    for value in payload.values():
        rows = _parse_merged_json_chunks(value)
        if _rows_match_keys(rows, required_keys):
            return rows
    return []


def _coerce_resolution_steps(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    if isinstance(value, str):
        lines = [line.strip(" -\t") for line in value.replace("\r", "").split("\n")]
        return [line for line in lines if line]
    return []


def _serialize_rows(rows: list[dict[str, Any]]) -> str:
    return json.dumps(rows, ensure_ascii=False)


def _read_agent_output_from_disk(session_id: str, agent_id: str) -> str:
    session_dir = get_session_dir(session_id)
    if session_dir is None:
        return ""
    output_path = Path(session_dir) / "agents" / str(agent_id).strip() / "output.md"
    if not output_path.is_file():
        return ""
    try:
        return output_path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _load_runtime_dynamic_outputs(session_id: str | None) -> dict[str, Any]:
    sid = str(session_id or "").strip()
    if not sid:
        return {}

    session = get_session(sid)
    if session is not None and isinstance(session.dynamic_agent_outputs, dict) and session.dynamic_agent_outputs:
        return dict(session.dynamic_agent_outputs)

    outputs: dict[str, Any] = {}
    session_dir = get_session_dir(sid)
    if session_dir is None:
        return outputs

    agents_dir = Path(session_dir) / "agents"
    if not agents_dir.is_dir():
        return outputs

    for agent_dir in agents_dir.iterdir():
        if not agent_dir.is_dir():
            continue
        text = _read_agent_output_from_disk(sid, agent_dir.name)
        if text.strip():
            outputs[agent_dir.name] = text
    return outputs


class IncidentPublishPreparer:
    def __init__(self, data_dir: str | None = None, **_kwargs: Any) -> None:
        self._data_dir = data_dir

    def prepare_publish_batches(
        self,
        reviewed_output: str | None = None,
        priority_agent_id: str = "",
        root_cause_agent_id: str = "",
        session_id: str | None = None,
        **kwargs: Any,
    ) -> str:
        structured_input = kwargs.get("dynamic_agent_outputs_structured")
        raw_input = kwargs.get("dynamic_agent_outputs")

        runtime_session_id = str(session_id or daan_session_id.get() or "").strip() or None
        runtime_outputs = _load_runtime_dynamic_outputs(runtime_session_id)

        structured_payload = _parse_json_value(structured_input)
        if not isinstance(structured_payload, dict):
            structured_payload = structured_input if isinstance(structured_input, dict) else {}
        if not structured_payload and runtime_outputs:
            structured_payload = {
                agent_id: _parse_merged_json_chunks(value)
                for agent_id, value in runtime_outputs.items()
            }

        raw_payload = _parse_json_value(raw_input)
        if not isinstance(raw_payload, dict):
            raw_payload = raw_input if isinstance(raw_input, dict) else {}
        if not raw_payload and runtime_outputs:
            raw_payload = runtime_outputs

        priority_rows = _find_rows_by_schema(
            structured_payload,
            preferred_agent_id=priority_agent_id,
            required_keys=("incident_id", "recommended_priority"),
        )
        if not priority_rows:
            priority_rows = _find_rows_by_schema(
                raw_payload,
                preferred_agent_id=priority_agent_id,
                required_keys=("incident_id", "recommended_priority"),
            )

        root_cause_rows = _find_rows_by_schema(
            structured_payload,
            preferred_agent_id=root_cause_agent_id,
            required_keys=("incident_id", "probable_cause"),
        )
        if not root_cause_rows:
            root_cause_rows = _find_rows_by_schema(
                raw_payload,
                preferred_agent_id=root_cause_agent_id,
                required_keys=("incident_id", "probable_cause"),
            )

        root_cause_by_incident = {
            str(row.get("incident_id") or "").strip(): row
            for row in root_cause_rows
            if str(row.get("incident_id") or "").strip()
        }

        prepared_rows: list[dict[str, Any]] = []
        skipped_rows: list[dict[str, str]] = []
        seen_incidents: set[str] = set()
        missing_root_cause_count = 0

        for row in priority_rows:
            incident_id = str(row.get("incident_id") or "").strip()
            if not incident_id:
                skipped_rows.append({"incident_id": "", "reason": "Missing incident_id in priority analysis row"})
                continue
            if incident_id in seen_incidents:
                continue

            seen_incidents.add(incident_id)
            root_row = root_cause_by_incident.get(incident_id, {})
            if not root_row:
                missing_root_cause_count += 1

            resolution_steps = _coerce_resolution_steps(root_row.get("resolution_steps"))
            comment_lines = [
                "Triage Decision:",
                f"- Recommended Priority: {str(row.get('recommended_priority') or '').strip() or 'Not provided'}",
                f"- Recommended Impact: {str(row.get('recommended_impact') or '').strip() or 'Not provided'}",
                f"- Recommended Urgency: {str(row.get('recommended_urgency') or '').strip() or 'Not provided'}",
            ]

            root_cause_category = str(root_row.get("root_cause_category") or "").strip()
            probable_cause = str(root_row.get("probable_cause") or "").strip()
            justification = str(row.get("justification") or "").strip()

            if root_cause_category:
                comment_lines.append(f"- Root Cause: {root_cause_category}")
            if probable_cause:
                comment_lines.append(f"- Probable Cause: {probable_cause}")
            if justification:
                comment_lines.append(f"- Priority Justification: {justification}")

            if resolution_steps:
                comment_lines.append("Resolution Steps:")
                comment_lines.extend(f"- {step}" for step in resolution_steps)

            prepared_rows.append(
                {
                    "incident_id": incident_id,
                    "recommended_priority": str(row.get("recommended_priority") or "").strip(),
                    "recommended_impact": str(row.get("recommended_impact") or "").strip(),
                    "recommended_urgency": str(row.get("recommended_urgency") or "").strip(),
                    "comment": "\n".join(comment_lines).strip(),
                }
            )

        if not prepared_rows and reviewed_output:
            logger.warning("IncidentPublishPreparer: no rows prepared from structured inputs")

        publish_payload = _serialize_rows(prepared_rows)

        result = {
            "status": "success" if prepared_rows else "error",
            "summary": {
                "session_id": runtime_session_id or "",
                "priority_rows_total": len(priority_rows),
                "root_cause_rows_total": len(root_cause_rows),
                "incidents_prepared": len(prepared_rows),
                "incidents_skipped": len(skipped_rows),
                "incidents_missing_root_cause": missing_root_cause_count,
            },
            "publish_items": prepared_rows,
            "publish_payload": publish_payload,
            "publish_payload_item_count": len(prepared_rows),
            "skipped": skipped_rows,
        }
        return json.dumps(result, ensure_ascii=False)