"""
BTEQ Script Generator Tool — DAAN 5 native tool wrapper.

Registered in agent config as:
    local_tools: BteqScriptGenerator.generate_bteq_scripts_v2

tools_loader resolves the class name to this module automatically:
    BteqScriptGenerator -> bteq_script_generator -> daan.native_tools.bteq_script_generator

Input (from session inputs dir):
    session_storage/{session_id}/inputs/*.xlsx   — mapping Excel file

Output (to session artifacts dir):
    session_storage/{session_id}/artifacts/bteq_scripts/*.btq
    session_storage/{session_id}/artifacts/bteq_scripts_<ts>.zip
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from daan.flow.session_service import get_artifacts_dir, read_context_map_output
from daan.flow.session_store import get_session
from daan.llm.llm_provider import get_llm_response_with_fallback
from daan.utils.bteq_generator import (
    build_preprocessed_bteq_context,
    generate_scripts_from_preprocessed_context,
    generate_scripts_with_llm,
    postprocess_generated_bteq_scripts,
    save_scripts_to_zip,
)

logger = logging.getLogger(__name__)


def _normalize_tool_refs(tool_value: Any) -> list[str]:
    if isinstance(tool_value, list):
        return [str(item or '').strip() for item in tool_value if str(item or '').strip()]
    text = str(tool_value or '').strip()
    if not text:
        return []
    return [part.strip() for part in text.strip('[]').split(',') if part.strip()]


def _is_bteq_agent_config(agent_cfg: dict[str, Any]) -> bool:
    local_tools = _normalize_tool_refs(agent_cfg.get('local_tools'))
    if any(tool_ref == 'BteqScriptGenerator.generate_bteq_scripts_v2' for tool_ref in local_tools):
        return True

    combined = ' '.join(
        str(agent_cfg.get(key) or '')
        for key in ('agent_name', 'prompt', 'agent_actions', 'output')
    )
    combined_upper = combined.upper()
    return 'BTEQSCRIPTGENERATOR.GENERATE_BTEQ_SCRIPTS_V2' in combined_upper or 'BTEQ TYPE-1 SCRIPT GENERATOR' in combined_upper


def _candidate_bteq_agents_from_session(session_id: str | None) -> list[dict[str, Any]]:
    """Find BTEQ agent configs from session, including their prompts."""
    sid = str(session_id or '').strip()
    if not sid:
        return []

    agent_configs: list[dict[str, Any]] = []
    try:
        session = get_session(sid)
        if session is not None:
            agent_configs.extend(list(session.context_map_result.get('agents', []) or []))
    except Exception:
        pass

    try:
        disk_context = read_context_map_output(sid)
        agent_configs.extend(list(disk_context.get('agents', []) or []))
    except Exception:
        pass

    matches: list[dict[str, Any]] = []
    seen: set[str] = set()
    for agent_cfg in agent_configs:
        if not isinstance(agent_cfg, dict) or not _is_bteq_agent_config(agent_cfg):
            continue
        candidate_id = str(agent_cfg.get('agent_id') or '').strip()
        candidate_name = str(agent_cfg.get('agent_name') or candidate_id or 'Unknown Agent').strip()
        candidate_prompt = str(agent_cfg.get('prompt') or '').strip()
        if not candidate_id or candidate_id in seen:
            continue
        seen.add(candidate_id)
        matches.append({
            'agent_id': candidate_id,
            'agent_name': candidate_name,
            'prompt': candidate_prompt,
        })
    return matches


def _resolve_bteq_agent_identity_and_prompt(
    session_id: str | None,
    agent_id: str,
    agent_name: str,
    catalog_prompt: str,
) -> tuple[str, str, str]:
    """Resolve BTEQ agent identity and prompt from session context if needed.

    Returns (agent_id, agent_name, catalog_prompt).
    """
    current_id = str(agent_id or '').strip() or 'unknown'
    current_name = str(agent_name or '').strip() or 'Unknown Agent'
    current_prompt = str(catalog_prompt or '').strip()

    # If we already have everything, return early
    if current_id != 'unknown' and current_prompt:
        return current_id, current_name, current_prompt

    # Try to recover from session context
    candidates = _candidate_bteq_agents_from_session(session_id)
    if not candidates:
        # Fall back to DB fetch if we have a valid agent_id
        if current_id != 'unknown' and not current_prompt:
            current_prompt = _fetch_agent_prompt(current_id)
            if current_prompt:
                logger.info(
                    "Loaded prompt from DB for %s (%d chars)",
                    current_id,
                    len(current_prompt),
                )
        return current_id, current_name, current_prompt

    resolved = candidates[0]
    resolved_id = resolved['agent_id']
    resolved_name = resolved['agent_name']
    resolved_prompt = resolved.get('prompt') or ''

    # Update identity if unknown
    if current_id == 'unknown':
        current_id = resolved_id
        current_name = resolved_name
        logger.info(
            "Resolved BTEQ agent identity from session context: %s (%s)",
            resolved_id,
            resolved_name,
            extra={'session_id': str(session_id or '').strip() or None},
        )

    # Update prompt if missing
    if not current_prompt:
        if resolved_prompt:
            current_prompt = resolved_prompt
            logger.info(
                "Resolved BTEQ prompt from session context for %s (%d chars)",
                current_id,
                len(current_prompt),
                extra={'session_id': str(session_id or '').strip() or None},
            )
        else:
            # Last resort: try DB fetch with the resolved agent_id
            current_prompt = _fetch_agent_prompt(current_id)
            if current_prompt:
                logger.info(
                    "Loaded prompt from DB for %s (%d chars)",
                    current_id,
                    len(current_prompt),
                )

    return current_id, current_name, current_prompt


def _resolve_bteq_agent_identity(
    session_id: str | None,
    agent_id: str,
    agent_name: str,
) -> tuple[str, str]:
    """Resolve BTEQ agent identity only (backward compat for postprocess)."""
    resolved_id, resolved_name, _ = _resolve_bteq_agent_identity_and_prompt(
        session_id, agent_id, agent_name, ""
    )
    return resolved_id, resolved_name


def _fetch_agent_prompt(agent_id: str) -> str:
    """Fetch the prompt_text from DB for the given agent_id."""
    try:
        from daan.core.database import SessionLocal
        from daan.models.archetype import Agent
        with SessionLocal() as db:
            agent = db.query(Agent).filter(Agent.agent_id == agent_id).first()
            if agent and agent.prompt_ref and agent.prompt_ref.prompt_text:
                return agent.prompt_ref.prompt_text
    except Exception as e:
        logger.warning("Failed to fetch prompt for agent %s: %s", agent_id, e)
    return ""


def _sanitize_catalog_prompt_for_native_generation(catalog_prompt: str) -> str:
    """Remove agent-only tool orchestration instructions from DB prompts.

    DB prompts like daan_5_pt include an agent-facing header (tool invocation
    instructions, 'do not manually generate BTEQ', 'return the tool result', etc.)
    separated from the actual BTEQ generation rules by a '---' marker.
    When the same prompt is passed to the raw LLM inside the native tool we must
    strip that header so the LLM only sees the BTEQ rules, not the conflicting
    instructions that would cause it to refuse to generate BTEQ.
    """
    if not catalog_prompt:
        return ""

    text = str(catalog_prompt)

    # Primary strategy: strip the agent-orchestration header that precedes the
    # '---' separator present in prompts like daan_5_pt.
    separator_idx = text.find('\n---\n')
    if separator_idx != -1:
        return text[separator_idx + len('\n---\n'):].strip()

    # Fallback: line-by-line filter for prompts without a '---' separator.
    filtered_lines = []
    for line in text.splitlines():
        line_text = line.strip()
        if "BteqScriptGenerator.preprocess_bteq_context" in line_text:
            continue
        if "BteqScriptGenerator.postprocess_bteq_scripts" in line_text:
            continue
        if "filename-to-script mapping" in line_text.lower():
            continue
        if "do not manually generate" in line_text.lower():
            continue
        if "do not summarize, explain" in line_text.lower():
            continue
        if "return the tool result directly" in line_text.lower():
            continue
        if "call the bteqscriptgenerator" in line_text.lower():
            continue
        filtered_lines.append(line)
    return "\n".join(filtered_lines).strip()


class BteqScriptGenerator:
    """DAAN native tool that generates Teradata BTEQ load scripts from a mapping Excel.

    Follows the same structural contract as other native tools (e.g. AidaSttmTool):
     - Instantiated by tools_loader with data_dir injected from agent_runner.tool_kwargs
     - Single public method receives agent executor kwargs
     - Returns a flat result dict with ``status``
    """

    def __init__(self, data_dir: str | None = None):
        self.tool_name = "BteqScriptGenerator"
        self._data_dir = data_dir
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def preprocess_bteq_context(
        self,
        source_system: str | None = None,
        target_entity: str | None = None,
        catalog_prompt: str = "",
        session_id: str | None = None,
        agent_id: str = "unknown",
        agent_name: str = "Unknown Agent",
        persist_artifact: bool = True,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Preprocess the uploaded mapping Excel into normalized script units."""
        logger.info("%s: Starting BTEQ preprocess", self.tool_name)

        try:
            # Resolve identity AND prompt together from session context
            agent_id, agent_name, catalog_prompt = _resolve_bteq_agent_identity_and_prompt(
                session_id, agent_id, agent_name, catalog_prompt
            )

            inputs_dir = Path(self._data_dir) if self._data_dir else None
            if not inputs_dir or not inputs_dir.exists():
                return self._error(agent_id, agent_name, f"Inputs directory not found: {self._data_dir}")

            excel_files = sorted(inputs_dir.glob("*.xlsx"))
            if not excel_files:
                return self._error(agent_id, agent_name, "No .xlsx mapping file found in session inputs directory.")

            excel_path = str(excel_files[0])
            payload = build_preprocessed_bteq_context(
                excel_path=excel_path,
                target_entity=target_entity or None,
                source_system=source_system or 'efeap',
                catalog_prompt=catalog_prompt,
            )

            preprocess_artifact_path = None
            if persist_artifact:
                if session_id:
                    artifacts_dir = get_artifacts_dir(session_id, create=True)
                else:
                    artifacts_dir = inputs_dir.parent / "artifacts"
                    artifacts_dir.mkdir(parents=True, exist_ok=True)

                preprocess_artifact_path = artifacts_dir / "bteq_preprocess_context.json"
                preprocess_artifact_path.write_text(
                    json.dumps(payload, indent=2, default=str),
                    encoding="utf-8",
                )

            result = {
                "status": "ok",
                "message": f"Prepared {payload['script_unit_count']} BTEQ script unit(s).",
                "agent_id": agent_id,
                "agent_name": agent_name,
                "excel_path": excel_path,
                **payload,
            }
            if preprocess_artifact_path is not None:
                result["preprocess_artifact_path"] = str(preprocess_artifact_path)
            return result
        except Exception as exc:
            logger.exception("%s: BTEQ preprocess failed", self.tool_name)
            return self._error(agent_id, agent_name, f"BTEQ preprocess failed: {exc}")


    def postprocess_bteq_scripts(
        self,
        generated_scripts: Any,
        session_id: str | None = None,
        preprocess_artifact_path: str | None = None,
        metadata_bundle: dict[str, Any] | None = None,
        agent_id: str = "unknown",
        agent_name: str = "Unknown Agent",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Validate, package, and persist generated BTEQ scripts."""
        logger.info("%s: Starting BTEQ postprocess", self.tool_name)
        try:
            agent_id, agent_name = _resolve_bteq_agent_identity(session_id, agent_id, agent_name)
            inputs_dir = Path(self._data_dir) if self._data_dir else None
            if session_id:
                artifacts_dir = get_artifacts_dir(session_id, create=True)
            elif inputs_dir is not None:
                artifacts_dir = inputs_dir.parent / "artifacts"
                artifacts_dir.mkdir(parents=True, exist_ok=True)
            else:
                artifacts_dir = Path("output")
                artifacts_dir.mkdir(parents=True, exist_ok=True)

            result = postprocess_generated_bteq_scripts(
                generated_scripts=generated_scripts,
                output_dir=str(artifacts_dir),
            )
            result.update({
                "agent_id": agent_id,
                "agent_name": agent_name,
            })
            if preprocess_artifact_path:
                result["preprocess_artifact_path"] = preprocess_artifact_path
            if metadata_bundle:
                result["metadata_bundle"] = metadata_bundle
            return result
        except Exception as exc:
            logger.exception("%s: BTEQ postprocess failed", self.tool_name)
            return self._error(agent_id, agent_name, f"BTEQ postprocess failed: {exc}")

    def generate_bteq_scripts_v2(
        self,
        source_system: str | None = None,
        target_entity: str | None = None,
        catalog_prompt: str = "",
        session_id: str | None = None,
        agent_id: str = "unknown",
        agent_name: str = "Unknown Agent",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run preprocess -> LLM generation -> postprocess in one native-tool call."""
        logger.info("%s: Starting BTEQ wrapper generation v2", self.tool_name)

        try:
            # Resolve identity AND prompt together from session context
            agent_id, agent_name, catalog_prompt = _resolve_bteq_agent_identity_and_prompt(
                session_id, agent_id, agent_name, catalog_prompt
            )

            if not catalog_prompt:
                logger.warning(
                    "%s: No prompt available for %s - generation may produce lower quality results",
                    self.tool_name, agent_id
                )

            native_catalog_prompt = _sanitize_catalog_prompt_for_native_generation(catalog_prompt)

            preprocess_result = self.preprocess_bteq_context(
                source_system=source_system,
                target_entity=target_entity,
                catalog_prompt=native_catalog_prompt,
                session_id=session_id,
                agent_id=agent_id,
                agent_name=agent_name,
                persist_artifact=False,  # Don't persist intermediate JSON to artifacts
                **kwargs,
            )
            if preprocess_result.get("status") != "ok":
                return preprocess_result

            inputs_dir = Path(self._data_dir) if self._data_dir else None
            if session_id:
                artifacts_dir = get_artifacts_dir(session_id, create=True)
            elif inputs_dir is not None:
                artifacts_dir = inputs_dir.parent / "artifacts"
                artifacts_dir.mkdir(parents=True, exist_ok=True)
            else:
                artifacts_dir = Path("output")
                artifacts_dir.mkdir(parents=True, exist_ok=True)

            progress_messages: list[str] = []

            def _progress(msg: str) -> None:
                logger.info("%s: %s", self.tool_name, msg)
                progress_messages.append(msg)

            def _llm_client(prompt: str, max_tokens: int = 16384, temperature: float = 0.0) -> str:
                return get_llm_response_with_fallback(
                    prompt,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )

            generated_scripts = generate_scripts_from_preprocessed_context(
                preprocessed_context=preprocess_result,
                llm_client=_llm_client,
                progress_callback=_progress,
                catalog_prompt=native_catalog_prompt,
            )

            postprocess_result = postprocess_generated_bteq_scripts(
                generated_scripts=generated_scripts,
                output_dir=str(artifacts_dir),
            )

            postprocess_result.update({
                "message": f"Generated {postprocess_result.get('scripts_generated', 0)} BTEQ script(s) successfully.",
                "agent_id": agent_id,
                "agent_name": agent_name,
                "preprocess_artifact_path": preprocess_result.get("preprocess_artifact_path"),
                "script_unit_count": preprocess_result.get("script_unit_count", 0),
                "output_filenames": preprocess_result.get("output_filenames", []),
                "progress_log": progress_messages,
            })
            return postprocess_result

        except Exception as exc:
            logger.exception("%s: BTEQ generation v2 failed", self.tool_name)
            return self._error(agent_id, agent_name, f"BTEQ generation v2 failed: {exc}")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _error(self, agent_id: str, agent_name: str, message: str) -> dict[str, Any]:
        logger.error("%s: %s", self.tool_name, message)
        return {
            "status": "error",
            "message": message,
            "agent_id": agent_id,
            "agent_name": agent_name,
            "scripts_generated": 0,
        }
