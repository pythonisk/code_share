"""Native RAG tool for indexing and retrieval."""

from __future__ import annotations

import hashlib
import json
import logging
import re
import shutil
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

from daan.agents.context_extrapolation_agent import ContextExtrapolationAgent, ContextExtrapolationPolicy
from daan.chat.chat_context_service import build_contextual_retrieval_query
from daan.core.config import get_settings
from daan.graph_stores.graph_store_factory import GraphStoreFactory
from daan.llm.embedding_provider import EmbeddingProviderFactory
from daan.llm.llm_provider import create_completion_provider, get_default_provider_name
from daan.models.context_extrapolation_models import ContextExtrapolationResult, QueryNormalizationResult, QueryType, RetrievalBranchPlan
from daan.models.evidence_models import EvidenceEnvelope
from daan.rag.chunking.chunker_factory import ChunkerFactory
from daan.rag.indexing.rag_indexing_service import RagIndexingService
from daan.rag.rag_context_builder import resolve_embedding_config
from daan.rag.reranking.reranker_factory import RerankerFactory
from daan.rag.retrieval.retriever_factory import RetrieverFactory
from daan.vector_stores.document import RagDocument
from daan.vector_stores.vector_store_factory import VectorStoreFactory

logger = logging.getLogger(__name__)


def _apply_vector_store_connection_defaults(store_name: str, vector_store_config: dict[str, Any]) -> dict[str, Any]:
    normalized_store = str(store_name or "").strip().lower()
    if normalized_store not in {"postgres", "pgvector", "postgresql"}:
        return vector_store_config

    if any(vector_store_config.get(key) for key in ("database_url", "url", "connection_string")):
        return vector_store_config

    database_url = get_settings().get_vector_database_url()
    if database_url:
        vector_store_config["database_url"] = database_url
    return vector_store_config


class RagTool:
    """Native tool methods following ClassName.method convention."""

    _completion_provider_cache: dict[str, Any] = {}

    def __init__(self, rag_config: dict[str, Any]) -> None:
        self.rag_config = rag_config
        self._indexing_service = RagIndexingService()
        self._kb_registry_path = Path(self.rag_config.get("kb_registry_path", ".rag_kbs.json"))
        self._last_context_extrapolation = ContextExtrapolationResult.fallback("not_run")
        self._last_context_trace: dict[str, Any] = {}
        self._last_retrieval_query: str = ""
        self._last_branch_traces: list[dict[str, Any]] = []
        self._last_timing_breakdown: dict[str, int] = {}
        self._last_query_normalization: dict[str, Any] = {}
        self._last_graph_summary: dict[str, Any] = {}

    def search(
        self,
        query: str,
        k: int = 5,
        retriever_type: str = "graph_rag",
        kb_id: str = "default",
        query_link: str | None = None,
    ) -> str:
        resolved_query_link = query_link or self._query_link(query)
        resolved_retriever_type = self._resolve_retriever_type(retriever_type)
        base_config = self._build_runtime_components(
            kb_id,
            query_link=resolved_query_link,
            include_graph_store=self._retriever_requires_graph_store(resolved_retriever_type),
            include_llm_provider=self._runtime_requires_llm_provider(
                retriever_type=resolved_retriever_type,
            ),
        )
        retriever = RetrieverFactory.create_retriever(retriever_type=resolved_retriever_type, config=base_config)
        pool = self._candidate_pool(k)
        docs = retriever.retrieve(query=query, k=pool)
        docs = self._apply_reranker(query, docs, base_config)[:k]

        if not docs:
            return "No context found."

        lines = [f"[{index + 1}] {doc.content}" for index, doc in enumerate(docs)]
        return "\n\n".join(lines)

    async def index_file(
        self,
        file_path: str,
        kb_id: str = "default",
        session_id: str | None = None,
        query: str | None = None,
        query_link: str | None = None,
    ) -> str:
        components = self._build_runtime_components(kb_id, query_link=query_link)
        document_loader_config = self._document_loader_config()
        link_ontology, ontology_link_config = self._ontology_link_settings(kb_id)
        result = await self._indexing_service.index_documents(
            session_id=session_id or kb_id,
            files=[file_path],
            vector_store=components["vector_store"],
            graph_store=components["graph_store"],
            embedding_provider=components["embedding_provider"],
            chunker=components["chunker"],
            query=query,
            query_link=query_link,
            use_document_loaders=bool(document_loader_config.get("enabled", False)),
            document_loader_config=document_loader_config,
            link_ontology=link_ontology,
            ontology_link_config=ontology_link_config,
        )
        self._register_kb(
            kb_id,
            chunks_indexed=int(result.get("chunks_indexed", 0) or 0),
            document_name=Path(file_path).name,
        )
        return f"Indexed {result['chunks_indexed']} chunks from {file_path} with query_link={result['query_link']}"

    def search_documents(
        self,
        query: str,
        k: int = 5,
        retriever_type: str = "graph_rag",
        kb_id: str = "default",
        query_link: str | None = None,
        metadata_filter: dict[str, Any] | None = None,
        include_explainability: bool = False,
        chat_context: str | None = None,
    ) -> list[dict] | dict[str, Any]:
        """Return structured search results for API use."""
        t_normalize_start = time.perf_counter()
        resolved_query_link = query_link or self._query_link(query)
        resolved_retriever_type = self._resolve_retriever_type(retriever_type)
        effective_chat_context = str(chat_context or "").strip()
        contextual_query = build_contextual_retrieval_query(query, effective_chat_context)
        query_normalization = self._normalize_query(query)
        self._last_query_normalization = query_normalization.model_dump(exclude_none=True)
        query_normalization_ms = int((time.perf_counter() - t_normalize_start) * 1000)
        context_policy = self._context_extrapolation_policy()
        base_config = self._build_runtime_components(
            kb_id,
            query_link=resolved_query_link,
            include_graph_store=self._retriever_requires_graph_store(resolved_retriever_type),
            include_llm_provider=context_policy.enabled
            or self._runtime_requires_llm_provider(retriever_type=resolved_retriever_type),
        )
        if metadata_filter:
            base_config["metadata_filter"] = metadata_filter
        plan = ContextExtrapolationResult.fallback("not_run")
        ce_ms = 0
        if context_policy.enabled:
            t_ce_start = time.perf_counter()
            plan = self._build_context_extrapolation_plan(
                query=query,
                kb_id=kb_id,
                retriever_type=resolved_retriever_type,
                base_config=base_config,
                chat_context=effective_chat_context or None,
            )
            ce_ms = int((time.perf_counter() - t_ce_start) * 1000)
        plan.query_normalization = plan.query_normalization or query_normalization
        branch_retriever_type = "vector" if query_normalization.simple_query else resolved_retriever_type
        branch_plans = self._build_branch_plans(
            query=query,
            contextual_query=contextual_query or query,
            plan=plan,
            query_normalization=query_normalization,
            k=k,
        )
        plan.branch_plans = branch_plans
        self._last_context_extrapolation = plan
        self._last_retrieval_query = branch_plans[0].retrieval_query if branch_plans else str(contextual_query or query or "")
        pool = self._candidate_pool(k)
        t_branch_start = time.perf_counter()
        branch_traces = self._execute_branch_plans(
            branch_plans=branch_plans,
            retriever_type=branch_retriever_type,
            base_config=base_config,
            query_link=resolved_query_link,
            pool=pool,
        )
        branch_retrieval_ms = int((time.perf_counter() - t_branch_start) * 1000)
        self._last_branch_traces = branch_traces
        t_merge_start = time.perf_counter()
        merged_docs = self._merge_branch_candidates(branch_traces)
        candidate_merge_ms = int((time.perf_counter() - t_merge_start) * 1000)
        t_rerank_start = time.perf_counter()
        reranked_docs = self._apply_reranker(contextual_query or query, merged_docs, base_config)
        rerank_apply_ms = int((time.perf_counter() - t_rerank_start) * 1000)
        t_select_start = time.perf_counter()
        docs = self._select_final_docs(reranked_docs, k)
        select_final_ms = int((time.perf_counter() - t_select_start) * 1000)
        reranking_ms = candidate_merge_ms + rerank_apply_ms + select_final_ms
        results = [self._serialize_doc(doc, resolved_query_link) for doc in docs]
        self._update_branch_selection(branch_traces, results)
        self._last_graph_summary = self._build_graph_contribution_summary(branch_traces, results)
        self._last_timing_breakdown = {
            "query_normalization_ms": query_normalization_ms,
            "ce_ms": ce_ms,
            "branch_retrieval_ms": branch_retrieval_ms,
            "concept_extraction_ms": sum(int(trace.get("concept_extraction_ms", 0) or 0) for trace in branch_traces),
            "graph_traversal_ms": sum(int(trace.get("graph_traversal_ms", 0) or 0) for trace in branch_traces),
            "reranking_ms": reranking_ms,
            "answer_generation_ms": 0,
            "explainability_ms": 0,
        }
        if not include_explainability:
            return results

        explainability = self._build_explainability(
            query_link=resolved_query_link,
            retriever_type=branch_retriever_type,
            results=results,
            retriever_trace={
                "branch_traces": branch_traces,
                "query_normalization": self._last_query_normalization,
                "timing_breakdown": self._last_timing_breakdown,
                "graph_summary": self._last_graph_summary,
            },
        )
        return {
            "results": results,
            "explainability": explainability,
            "graph": {
                "nodes": explainability.get("graph_nodes", []),
                "edges": explainability.get("graph_edges", []),
            },
        }

    def get_last_context_extrapolation(self) -> ContextExtrapolationResult:
        return self._last_context_extrapolation.model_copy(deep=True)

    def get_last_context_trace(self) -> dict[str, Any]:
        return dict(self._last_context_trace)

    def get_last_retrieval_query(self) -> str:
        return str(self._last_retrieval_query)

    def get_last_evidence_envelope(self, original_query: str) -> EvidenceEnvelope:
        return self._last_context_extrapolation.to_evidence_envelope(
            original_query=original_query,
            final_retrieval_query=self._last_retrieval_query,
            runtime_trace={
                **self._last_context_trace,
                "query_normalization": self._last_query_normalization,
                "timing_breakdown": self._last_timing_breakdown,
                "graph_summary": self._last_graph_summary,
            },
        )

    async def index_file_structured(
        self,
        file_path: str,
        kb_id: str = "default",
        session_id: str | None = None,
        query: str | None = None,
        query_link: str | None = None,
        source_type: str = "upload",
        include_graph_store: bool = True,
        display_name: str | None = None,
    ) -> dict:
        """Index a file and return structured result for API use."""
        components = self._build_runtime_components(kb_id, query_link=query_link, include_graph_store=include_graph_store)
        document_loader_config = self._document_loader_config()
        link_ontology, ontology_link_config = self._ontology_link_settings(kb_id)
        result = await self._indexing_service.index_documents(
            session_id=session_id or kb_id,
            files=[file_path],
            vector_store=components["vector_store"],
            graph_store=components["graph_store"],
            embedding_provider=components["embedding_provider"],
            chunker=components["chunker"],
            query=query,
            query_link=query_link,
            source_type=source_type,
            use_document_loaders=bool(document_loader_config.get("enabled", False)),
            document_loader_config=document_loader_config,
            link_ontology=link_ontology,
            ontology_link_config=ontology_link_config,
            extra_metadata={"source": str(display_name).strip()} if display_name and str(display_name).strip() else None,
        )
        self._register_kb(
            kb_id,
            chunks_indexed=int(result.get("chunks_indexed", 0) or 0),
            document_name=str(display_name).strip() if display_name and str(display_name).strip() else Path(file_path).name,
        )
        return result

    def index_ontology_concepts(self, kb_id: str = "default", batch_size: int = 128) -> dict:
        """Embed curated ontology concepts for GraphRAG entity search (step 2).

        Reads the curated concept vertices from the KB's graph, embeds each
        concept's name/aliases/description, and upserts them into the KB's
        dedicated concept vector table (``<collection>_concepts``). Idempotent:
        re-running refreshes the embeddings in place. Run after publishing or
        updating the ontology.
        """
        components = self._build_runtime_components(kb_id, include_graph_store=True)
        graph_store = components["graph_store"]
        concept_store = components["concept_vector_store"]
        embedding_provider = components["embedding_provider"]
        if graph_store is None or concept_store is None:
            return {"kb_id": kb_id, "concepts_indexed": 0, "reason": "graph or concept store unavailable"}

        list_concepts = getattr(graph_store, "list_concept_nodes", None)
        concepts = list_concepts() if callable(list_concepts) else []
        if not concepts:
            return {"kb_id": kb_id, "concepts_indexed": 0, "reason": "no curated concepts found"}

        indexed = 0
        for start in range(0, len(concepts), batch_size):
            batch = concepts[start : start + batch_size]
            texts = [self._concept_embedding_text(concept) for concept in batch]
            embeddings = embedding_provider.embed_batch(texts)
            docs = [
                RagDocument(
                    id=f"concept:{concept['id']}",
                    content=text,
                    metadata={
                        "node_type": "concept",
                        "concept_id": str(concept["id"]),
                        "name": str(concept.get("name") or ""),
                        "label": str(concept.get("label") or ""),
                        "session_id": kb_id,
                    },
                    source=None,
                    chunk_index=0,
                    embedding=embedding,
                )
                for concept, text, embedding in zip(batch, texts, embeddings)
            ]
            concept_store.add_documents(docs)
            indexed += len(docs)

        logger.info("Indexed %d ontology concept embeddings for kb_id=%s.", indexed, kb_id)
        return {"kb_id": kb_id, "concepts_indexed": indexed}

    @staticmethod
    def _concept_embedding_text(concept: dict) -> str:
        """Build the text embedded for a curated concept (name + aliases + desc)."""
        parts: list[str] = [str(concept.get("name") or "").strip()]
        aliases = concept.get("aliases")
        if isinstance(aliases, (list, tuple, set)):
            parts.extend(str(alias).strip() for alias in aliases if str(alias).strip())
        elif isinstance(aliases, str) and aliases.strip():
            parts.append(aliases.strip())
        description = str(concept.get("description") or "").strip()
        if description:
            parts.append(description)
        return " ".join(part for part in parts if part) or str(concept.get("id") or "")

    def list_knowledge_bases(self) -> list[dict]:
        configured = self.rag_config.get("knowledge_bases", [])
        kb_stats = self._get_kb_stats()
        registry_stats = self._load_registered_kb_stats()

        configured_enabled = {
            str(kb.get("id")): bool(kb.get("enabled", True))
            for kb in configured
            if kb.get("id")
        }
        # Optional friendly display name per KB (knowledge_bases[].name). The UI shows
        # this verbatim; when absent it falls back to a title-cased kb_id.
        configured_names = {
            str(kb.get("id")): str(kb.get("name") or "").strip()
            for kb in configured
            if kb.get("id")
        }
        configured_descriptions = {
            str(kb.get("id")): str(kb.get("description") or "").strip()
            for kb in configured
            if kb.get("id")
        }
        configured_customers = {
            str(kb.get("id")): str(kb.get("customer") or "").strip()
            for kb in configured
            if kb.get("id")
        }
        configured_types = {
            str(kb.get("id")): str(kb.get("type") or "").strip()
            for kb in configured
            if kb.get("id")
        }
        # Each KB may define a collection name used as the storage key in the vector
        # store. Stats are resolved by collection first, then by id.
        configured_collections = {
            str(kb.get("id")): str(kb.get("collection") or "").strip()
            for kb in configured
            if kb.get("id")
        }

        def _lookup_stats(stats: dict, kb_id: str, collection: str) -> dict:
            """Resolve stats by collection name when available, otherwise by kb_id."""
            if collection and stats.get(collection):
                return stats[collection]
            if stats.get(kb_id):
                return stats[kb_id]
            return {}

        # Only KBs created via the UI (living in the sidecar file) may be deleted;
        # hand-curated entries in rag_config.yml are protected in the UI and API alike.
        user_created_ids = {str(kb.get("id")) for kb in get_settings().load_user_knowledge_bases() if kb.get("id")}

        return [
            {
                "id": kb_id,
                "name": configured_names.get(kb_id) or kb_id.replace("_", " ").title(),
                "description": configured_descriptions.get(kb_id) or "",
                "customer": configured_customers.get(kb_id) or "",
                "type": configured_types.get(kb_id) or "",
                "enabled": configured_enabled.get(kb_id, True),
                "has_graph": self.kb_uses_graph_store(kb_id),
                "user_created": kb_id in user_created_ids,
                "chunks_indexed": (
                    _lookup_stats(kb_stats, kb_id, configured_collections.get(kb_id, "")).get("chunks", 0)
                    or _lookup_stats(registry_stats, kb_id, configured_collections.get(kb_id, "")).get("chunks", 0)
                ),
                "documents": sorted(
                    dict.fromkeys(
                        _lookup_stats(kb_stats, kb_id, configured_collections.get(kb_id, "")).get("documents", [])
                        + _lookup_stats(registry_stats, kb_id, configured_collections.get(kb_id, "")).get("documents", [])
                    )
                ),
            }
            for kb_id in [str(kb.get("id")) for kb in configured if kb.get("id")]
        ]

    def create_knowledge_base(
        self,
        kb_id: str,
        name: str,
        description: str = "",
        customer: str = "",
        kb_type: str = "",
        collection: str | None = None,
        system_prompt: str = "",
    ) -> dict[str, Any]:
        """Register a new vector-only knowledge base.

        The PostgreSQL table backing ``collection`` is created lazily by the vector
        store on the first index call, so nothing is provisioned here.

        Raises:
            ValueError: If the id is blank or already in use.
        """
        normalized_id = str(kb_id).strip()
        if not normalized_id:
            raise ValueError("Knowledge base id is required.")

        for entry in self.rag_config.get("knowledge_bases") or []:
            if str(entry.get("id") or "").strip().casefold() == normalized_id.casefold():
                raise ValueError(f"Knowledge base '{normalized_id}' already exists.")

        resolved_name = str(name).strip() or normalized_id
        resolved_description = str(description).strip()
        kb_entry: dict[str, Any] = {
            "id": normalized_id,
            "enabled": True,
            "name": resolved_name,
            "description": resolved_description,
            "customer": str(customer).strip(),
            "type": str(kb_type).strip(),
            "system_prompt": str(system_prompt).strip()
            or self.default_system_prompt(resolved_name, resolved_description),
            "collection": str(collection or normalized_id).strip(),
            "link_ontology": False,
            "public": True,
        }
        kb_entry.update(self._provision_graph_settings(normalized_id))

        try:
            get_settings().append_user_knowledge_base(kb_entry)
        except ValueError:
            # A concurrent create won the race; drop the graph we just provisioned.
            self._rollback_graph_provisioning(kb_entry)
            raise

        # Keep this instance's config in sync so an immediate index call resolves the KB.
        configured = list(self.rag_config.get("knowledge_bases") or [])
        configured.append(kb_entry)
        self.rag_config["knowledge_bases"] = configured

        self._register_kb(normalized_id)
        return kb_entry

    def kb_uses_graph_store(self, kb_id: str) -> bool:
        """True when the KB is backed by a real graph rather than the in-memory placeholder.

        Ingestion uses this so a vector-only KB never builds a graph store or its
        companion ``<collection>_concepts`` table.
        """
        kb_config = self._resolve_kb_config(str(kb_id).strip())
        store_type = str(
            kb_config.get("graph_store_type") or self.rag_config.get("graph_store_type", "kuzu")
        ).strip().lower()
        return store_type != "in_memory"

    @staticmethod
    def default_system_prompt(name: str, description: str = "") -> str:
        """Build a starter persona so a new KB answers better than the generic fallback."""
        resolved_name = str(name).strip() or "this knowledge base"
        resolved_description = str(description).strip()
        context_line = f" It covers: {resolved_description}" if resolved_description else ""
        return (
            f"You are a knowledge assistant for {resolved_name}.{context_line}\n\n"
            "Answer using ONLY the provided context.\n"
            "- Start with a direct 1-2 sentence answer in bold.\n"
            "- Add supporting detail as bullets, and use a markdown table when comparing items.\n"
            "- If the answer is not in the context, say so plainly instead of guessing."
        )

    @staticmethod
    def _provision_graph_settings(kb_id: str) -> dict[str, Any]:
        """Create a Cosmos graph for the KB, falling back to vector-only when unavailable.

        The container is proved writable through Gremlin before the KB adopts it,
        because a container created via the SQL data plane is not guaranteed to be
        a usable graph. A container that fails that check is deleted again.
        """
        settings = get_settings()
        ready, _ = settings.cosmos_provisioning_ready()
        if not ready:
            return {"graph_store_type": "in_memory"}

        from daan.graph_stores.providers.cosmos_graph_store import CosmosGraphStore, graph_name_for_kb

        graph_name = graph_name_for_kb(kb_id)
        database = settings.COSMOS_DEFAULT_DATABASE
        store = CosmosGraphStore({"database": database, "graph": graph_name})
        try:
            store.ensure_graph(throughput=settings.COSMOS_GRAPH_THROUGHPUT or None)
            store.verify_writable()
            return {"graph": graph_name, "database": database}
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Cosmos graph provisioning failed for kb_id=%s; creating a vector-only KB. Error: %s",
                kb_id,
                exc,
            )
            store.delete_graph()
            return {"graph_store_type": "in_memory"}
        finally:
            store.close()

    @staticmethod
    def _rollback_graph_provisioning(kb_entry: dict[str, Any]) -> None:
        graph_name = str(kb_entry.get("graph") or "").strip()
        database = str(kb_entry.get("database") or "").strip()
        if not graph_name or not database:
            return

        from daan.graph_stores.providers.cosmos_graph_store import CosmosGraphStore

        store = CosmosGraphStore({"database": database, "graph": graph_name})
        try:
            if store.delete_graph():
                logger.info("Rolled back provisioned Cosmos graph '%s'.", graph_name)
        finally:
            store.close()

    def delete_knowledge_base(self, kb_id: str, session_storage_dir: str | None = None) -> dict[str, Any]:
        normalized = str(kb_id).strip()
        if not normalized:
            return {"deleted": False, "kb_id": kb_id, "reason": "invalid_kb_id"}

        registry_stats = self._load_registered_kb_stats()
        store_stats = self._get_kb_stats()
        collection = str(self._resolve_kb_config(normalized).get("collection") or "").strip()
        # Without this guard, deleting an unknown id would build a vector store and
        # create the very table it is about to drop.
        if not self._resolve_kb_config(normalized) and normalized not in registry_stats and normalized not in store_stats:
            return {"deleted": False, "kb_id": normalized, "reason": "not_found"}

        existing_stats = (
            store_stats.get(collection)
            or store_stats.get(normalized)
            or registry_stats.get(normalized, {})
        )
        documents = list(existing_stats.get("documents", []))
        chunks_indexed = int(existing_stats.get("chunks", 0) or 0)

        deleted_vector_docs = self._delete_vector_store_entries(normalized)
        registry_removed = self._delete_registry_entry(normalized)
        uploads_removed = self._delete_uploaded_files(normalized, session_storage_dir)
        graph_removed = self._delete_graph_entries(normalized)
        config_removed = get_settings().remove_user_knowledge_base(normalized)

        return {
            "deleted": bool(
                registry_removed
                or uploads_removed
                or deleted_vector_docs
                or graph_removed
                or config_removed
                or normalized in registry_stats
            ),
            "kb_id": normalized,
            "documents": documents,
            "chunks_indexed": chunks_indexed,
            "deleted_vector_docs": deleted_vector_docs,
            "registry_removed": registry_removed,
            "uploads_removed": uploads_removed,
            "graph_removed": graph_removed,
            "config_removed": config_removed,
        }

    def _delete_graph_entries(self, kb_id: str) -> bool:
        """Delete the KB's Cosmos graph container, if it was provisioned for it.

        Skips KBs on ``in_memory`` or a shared/pre-existing graph (no ``graph`` key
        of their own), so this never touches a container another KB might use.
        """
        kb_config = self._resolve_kb_config(kb_id)
        graph_name = str(kb_config.get("graph") or "").strip()
        database = str(kb_config.get("database") or "").strip()
        if not graph_name or not database:
            return False

        from daan.graph_stores.providers.cosmos_graph_store import CosmosGraphStore

        store = CosmosGraphStore({"database": database, "graph": graph_name})
        try:
            removed = store.delete_graph()
        except Exception:
            logger.exception("Failed to delete Cosmos graph '%s' for kb_id=%s", graph_name, kb_id)
            return False
        finally:
            store.close()
        if removed:
            logger.info("Deleted Cosmos graph '%s' for kb_id=%s", graph_name, kb_id)
        return removed

    def _load_registered_kbs(self) -> list[str]:
        registry = self._load_registered_kb_stats()
        if registry:
            return list(registry.keys())

        if not self._kb_registry_path.exists():
            return []
        try:
            payload = json.loads(self._kb_registry_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return []
        if not isinstance(payload, list):
            return []
        return [str(item) for item in payload if str(item).strip()]

    def _document_loader_config(self) -> dict[str, Any]:
        config = self.rag_config.get("document_loaders")
        if not isinstance(config, dict):
            return {"enabled": False, "fallback_to_converter": True}

        normalized = dict(config)
        normalized["enabled"] = bool(normalized.get("enabled", False))
        normalized["fallback_to_converter"] = bool(normalized.get("fallback_to_converter", True))
        return normalized

    def _load_registered_kb_stats(self) -> dict[str, dict]:
        if not self._kb_registry_path.exists():
            return {}

        try:
            payload = json.loads(self._kb_registry_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}

        # Backward compatibility: old format was a simple list of KB IDs.
        if isinstance(payload, list):
            return {
                str(item): {"chunks": 0, "documents": []}
                for item in payload
                if str(item).strip()
            }

        if not isinstance(payload, dict):
            return {}

        normalized: dict[str, dict] = {}
        for kb_id, item in payload.items():
            if not str(kb_id).strip():
                continue
            chunk_count = 0
            documents: list[str] = []

            if isinstance(item, dict):
                chunk_count = int(item.get("chunks", item.get("chunks_indexed", 0)) or 0)
                documents = [str(doc) for doc in item.get("documents", []) if str(doc).strip()]

            normalized[str(kb_id)] = {
                "chunks": chunk_count,
                "documents": sorted(dict.fromkeys(documents)),
            }

        return normalized

    def _register_kb(self, kb_id: str, chunks_indexed: int = 0, document_name: str | None = None) -> None:
        normalized = str(kb_id).strip()
        if not normalized:
            return

        existing = self._load_registered_kb_stats()
        current = existing.get(normalized, {"chunks": 0, "documents": []})
        updated_documents = current.get("documents", [])

        if document_name and document_name not in updated_documents:
            updated_documents.append(document_name)

        existing[normalized] = {
            "chunks": int(current.get("chunks", 0) or 0) + int(chunks_indexed or 0),
            "documents": sorted(dict.fromkeys(updated_documents)),
        }

        try:
            self._kb_registry_path.write_text(json.dumps(existing, indent=2), encoding="utf-8")
        except OSError:
            return

    def _get_kb_stats(self) -> dict[str, dict]:
        """Return chunk counts and unique document names per KB from the active vector store."""
        store_name = str(self.rag_config.get("vector_store_type", "chroma") or "chroma").strip().lower()
        if store_name in ("postgres", "pgvector"):
            return self._get_postgres_kb_stats()
        if store_name == "faiss":
            return self._get_faiss_kb_stats()
        if store_name == "chroma":
            return self._get_chroma_kb_stats()
        return self._load_registered_kb_stats()

    def _get_postgres_kb_stats(self) -> dict[str, dict]:
        """Return chunk counts and document names per KB from the PostgreSQL vector table."""
        stats: dict[str, dict] = {}
        try:
            vector_store = self._build_vector_store("default")
        except Exception:
            logger.exception("Failed to initialize PostgreSQL vector store for KB stats; returning empty stats")
            return stats
        list_stats = getattr(vector_store, "list_knowledge_base_stats", None)
        if callable(list_stats):
            try:
                payload = list_stats()
                if isinstance(payload, dict):
                    return payload
            except Exception:
                return stats
        return stats

    def _get_faiss_kb_stats(self) -> dict[str, dict]:
        """Return chunk counts and unique document names per KB from FAISS persisted docs.json."""
        stats: dict[str, dict] = {}
        docs_path = Path(".faiss_store") / "docs.json"
        
        if not docs_path.exists():
            return stats
        
        try:
            payload = json.loads(docs_path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                return stats
            
            for doc_data in payload.values():
                metadata = doc_data.get("metadata", {})
                source = doc_data.get("source") or metadata.get("source", "")
                self._accumulate_kb_stat(stats, metadata, source)
        except (json.JSONDecodeError, OSError):
            pass
        
        return stats

    def _get_chroma_kb_stats(self) -> dict[str, dict]:
        """Return chunk counts and document names per KB from each KB's own Chroma collection."""
        stats: dict[str, dict] = {}
        vector_store_config = self.rag_config.get("vector_store_config", {})
        persist_dir = Path(vector_store_config.get("persist_directory", ".chroma"))
        # Resolve relative path against the repo root (matches ChromaVectorStore).
        if not persist_dir.is_absolute():
            persist_dir = Path(__file__).resolve().parents[3] / persist_dir
        if not persist_dir.exists():
            return stats

        try:
            import chromadb  # pylint: disable=import-outside-toplevel

            client = chromadb.PersistentClient(path=str(persist_dir))
            # chromadb >= 0.6.0 returns collection-name strings from list_collections();
            # older versions return Collection objects. Support both so stats don't
            # silently come back empty on a newer chromadb (e.g. in the deployed build).
            existing = {
                str(col if isinstance(col, str) else getattr(col, "name", col))
                for col in client.list_collections()
            }
        except Exception:
            logger.exception("Failed to open Chroma store at %s; returning empty KB stats", persist_dir)
            return stats

        for kb in self.rag_config.get("knowledge_bases", []) or []:
            kb_id = str(kb.get("id") or "").strip()
            if not kb_id:
                continue
            # Mirror the collection resolution used when indexing in
            # _build_runtime_components so reads and writes target the same collection.
            collection_name = str(
                kb.get("collection")
                or vector_store_config.get("collection_name")
                or kb_id
            )
            if collection_name not in existing:
                stats[kb_id] = {"chunks": 0, "documents": []}
                continue
            payload: Any = {}
            try:
                collection = client.get_collection(collection_name)
                payload = collection.get(include=["metadatas"])
            except Exception:
                logger.exception(
                    "Failed to read Chroma collection %r for KB %r; reporting empty stats",
                    collection_name,
                    kb_id,
                )
                stats[kb_id] = {"chunks": 0, "documents": []}
                continue

            ids = payload.get("ids", []) or []
            documents: list[str] = []
            for metadata in payload.get("metadatas") or []:
                md = metadata or {}
                source = str(md.get("source") or "")
                source_type = md.get("source_type")
                if source.startswith("db:") or source_type in ("usecase", "agent", "prompt"):
                    name = "Use cases (database)"
                else:
                    name = self._basename(source) if source else str(md.get("title") or "")
                if name and name not in documents:
                    documents.append(name)
            stats[kb_id] = {"chunks": len(ids), "documents": sorted(documents)}

        return stats

    def _accumulate_kb_stat(self, stats: dict[str, dict], metadata: dict[str, Any], source: str) -> None:
        kb_id = str(metadata.get("session_id", "default") or "default")
        doc_name = self._basename(source) if source else ""

        if kb_id not in stats:
            stats[kb_id] = {"chunks": 0, "documents": []}

        stats[kb_id]["chunks"] += 1
        if doc_name and doc_name not in stats[kb_id]["documents"]:
            stats[kb_id]["documents"].append(doc_name)

    def _delete_registry_entry(self, kb_id: str) -> bool:
        existing = self._load_registered_kb_stats()
        if kb_id not in existing:
            return False

        existing.pop(kb_id, None)
        try:
            self._kb_registry_path.write_text(json.dumps(existing, indent=2), encoding="utf-8")
            return True
        except OSError:
            return False

    def _delete_uploaded_files(self, kb_id: str, session_storage_dir: str | None) -> bool:
        if not session_storage_dir:
            return False

        uploads_dir = Path(session_storage_dir) / "rag_uploads" / kb_id
        if not uploads_dir.exists():
            return False

        try:
            shutil.rmtree(uploads_dir)
            return True
        except OSError:
            return False

    def _delete_vector_store_entries(self, kb_id: str) -> int:
        store_name = str(self.rag_config.get("vector_store_type", "chroma") or "chroma").strip().lower()
        if store_name in ("postgres", "pgvector"):
            return self._delete_postgres_kb_entries(kb_id)
        if store_name == "faiss":
            return self._delete_faiss_kb_entries(kb_id)
        if store_name == "chroma":
            return self._delete_chroma_kb_entries(kb_id)
        return 0

    def _delete_postgres_kb_entries(self, kb_id: str) -> int:
        vector_store = self._build_vector_store(kb_id)
        purge_knowledge_base = getattr(vector_store, "purge_knowledge_base", None)
        if callable(purge_knowledge_base):
            try:
                result = purge_knowledge_base(kb_id, drop_tables=not self._collection_is_shared(kb_id))
            except Exception:
                logger.exception("Failed to purge PostgreSQL entries for kb_id=%s", kb_id)
                return 0
            dropped = result.get("dropped_tables") or []
            if dropped:
                logger.info("Dropped PostgreSQL tables for kb_id=%s: %s", kb_id, ", ".join(dropped))
            return int(result.get("deleted_rows", 0) or 0)

        delete_by_session_id = getattr(vector_store, "delete_by_session_id", None)
        if callable(delete_by_session_id):
            try:
                return int(delete_by_session_id(kb_id) or 0)
            except Exception:
                return 0
        return 0

    def _collection_is_shared(self, kb_id: str) -> bool:
        """True when another KB maps to the same vector collection, making a drop unsafe."""
        normalized_id = str(kb_id).strip()
        target = str(self._resolve_kb_config(normalized_id).get("collection") or normalized_id).strip().casefold()
        for entry in self.rag_config.get("knowledge_bases") or []:
            other_id = str(entry.get("id") or "").strip()
            if not other_id or other_id.casefold() == normalized_id.casefold():
                continue
            other_collection = str(entry.get("collection") or other_id).strip().casefold()
            if other_collection == target:
                return True
        return False

    def _build_vector_store(self, kb_id: str | None = None):
        kb_config = self._resolve_kb_config(kb_id or "") if kb_id else {}
        vector_store_config = dict(self.rag_config.get("vector_store_config", {}))
        store_name = str(self.rag_config.get("vector_store_type", "chroma") or "chroma").strip().lower()
        vector_store_config = _apply_vector_store_connection_defaults(store_name, vector_store_config)

        if store_name == "chroma":
            vector_store_config["collection_name"] = (
                kb_config.get("collection")
                or vector_store_config.get("collection_name")
                or kb_id
                or "default"
            )
        else:
            configured_kbs = self.rag_config.get("knowledge_bases", []) or []
            fallback_table = ""
            if configured_kbs:
                first_kb = configured_kbs[0] or {}
                fallback_table = str(first_kb.get("collection") or first_kb.get("id") or "").strip()
            vector_store_config["table_name"] = str(
                kb_config.get("collection")
                or kb_id
                or vector_store_config.get("table_name")
                or fallback_table
                or "rag_documents"
            )

        return VectorStoreFactory.create_store(
            store_name=store_name,
            config=vector_store_config,
        )

    def _delete_faiss_kb_entries(self, kb_id: str) -> int:
        vector_store = self._build_runtime_components(kb_id).get("vector_store")
        docs = getattr(vector_store, "_docs", None)
        if not isinstance(docs, dict):
            return 0

        matching_ids = [
            doc_id
            for doc_id, doc in docs.items()
            if str((getattr(doc, "metadata", {}) or {}).get("session_id", "default") or "default") == kb_id
        ]

        for doc_id in matching_ids:
            vector_store.delete(doc_id)

        return len(matching_ids)

    def _delete_chroma_kb_entries(self, kb_id: str) -> int:
        vector_store_config = self.rag_config.get("vector_store_config", {})
        persist_dir = vector_store_config.get("persist_directory", ".chroma")
        collection_name = vector_store_config.get("collection_name", "default")

        try:
            import chromadb  # pylint: disable=import-outside-toplevel

            client = chromadb.PersistentClient(path=str(persist_dir))
            collection = client.get_or_create_collection(name=collection_name)
            matches = collection.get(where={"session_id": kb_id})
            ids = list(matches.get("ids") or [])
            if ids:
                collection.delete(ids=ids)
            return len(ids)
        except Exception:
            return 0

    def _build_runtime_components(
        self,
        kb_id: str,
        query_link: str | None = None,
        include_graph_store: bool = True,
        include_llm_provider: bool = False,
    ) -> dict[str, Any]:
        kb_config = self._resolve_kb_config(kb_id)
        embedding_provider_name = self.rag_config.get("embedding_provider", "azure_openai")
        embedding_config = resolve_embedding_config(self.rag_config)

        embedding_provider = EmbeddingProviderFactory.create_provider(
            provider_name=embedding_provider_name,
            config=embedding_config,
        )

        vector_store_config = dict(self.rag_config.get("vector_store_config", {}))
        store_name = str(self.rag_config.get("vector_store_type", "chroma") or "chroma").strip().lower()
        vector_store_config = _apply_vector_store_connection_defaults(store_name, vector_store_config)
        collection_name = str(
            kb_config.get("collection")
            or kb_id
            or vector_store_config.get("table_name")
            or vector_store_config.get("collection_name")
            or "rag_documents"
        )
        if store_name == "chroma":
            vector_store_config["collection_name"] = collection_name
        else:
            vector_store_config["table_name"] = collection_name
        vector_store = VectorStoreFactory.create_store(
            store_name=store_name,
            config=vector_store_config,
        )

        # Entity-embedding store for GraphRAG entity search (step 2): curated
        # ontology concepts embedded into their own table/collection so entity
        # vector search never pollutes chunk retrieval. Only built when a graph is
        # in play; retrieval degrades gracefully if it is empty/absent.
        concept_vector_store = None
        if include_graph_store:
            concept_store_config = dict(self.rag_config.get("vector_store_config", {}))
            concept_store_config = _apply_vector_store_connection_defaults(store_name, concept_store_config)
            concept_collection = f"{collection_name}_concepts"
            if store_name == "chroma":
                concept_store_config["collection_name"] = concept_collection
            else:
                concept_store_config["table_name"] = concept_collection
            concept_vector_store = VectorStoreFactory.create_store(
                store_name=store_name,
                config=concept_store_config,
            )

        # kb_id selects the graph container; pass per-KB graph/database overrides through
        # to the store (CosmosGraphStore falls back to env when these are absent).
        # A per-KB graph_store_type lets a vector-only KB opt out of a real graph
        # (e.g. graph_store_type: in_memory).
        graph_store = None
        if include_graph_store:
            graph_store_config = dict(self.rag_config.get("graph_store_config", {}))
            if kb_config.get("graph"):
                graph_store_config["graph"] = kb_config["graph"]
            if kb_config.get("database"):
                graph_store_config["database"] = kb_config["database"]
            graph_store_type = kb_config.get("graph_store_type") or self.rag_config.get("graph_store_type", "kuzu")
            graph_store = GraphStoreFactory.create_store(
                store_name=graph_store_type,
                config=graph_store_config,
            )
        chunker = ChunkerFactory.create_chunker(
            chunker_type=self.rag_config.get("chunker_type", "recursive_text"),
            config={
                "chunk_size": self.rag_config.get("chunk_size", 512),
                "chunk_overlap": self.rag_config.get("chunk_overlap", 64),
                "embedding_provider": embedding_provider,
            },
        )

        llm_provider = None
        if include_llm_provider:
            try:
                provider_name = get_default_provider_name()
                llm_provider = self._get_cached_completion_provider(provider_name)
                logger.info("Created LLM provider '%s' for retrieval runtime.", provider_name)
            except Exception as exc:
                logger.warning("Could not create LLM provider for retrieval runtime: %s", exc)

        return {
            "embedding_provider": embedding_provider,
            "vector_store": vector_store,
            "concept_vector_store": concept_vector_store,
            "graph_store": graph_store,
            "chunker": chunker,
            "llm_provider": llm_provider,
            "query_link_key": query_link,
            "use_hybrid": bool(self.rag_config.get("use_hybrid", False)),
            "graph_depth": self.rag_config.get("graph_depth", 2),
            "graph_seed_limit": self.rag_config.get("graph_seed_limit", 6),
            "use_ontology_seeds": bool(self.rag_config.get("use_ontology_seeds", True)),
            "ontology_seed_limit": self.rag_config.get("ontology_seed_limit", 5),
            "ontology_seed_mode": self.rag_config.get("ontology_seed_mode", "semantic"),
            "ontology_seed_min_score": self.rag_config.get("ontology_seed_min_score", 0.30),
            "use_lexical_chunk_resolution": bool(self.rag_config.get("use_lexical_chunk_resolution", True)),
        }

    @classmethod
    def _get_cached_completion_provider(cls, provider_name: str) -> Any:
        normalized_name = str(provider_name or "").strip()
        cached = cls._completion_provider_cache.get(normalized_name)
        if cached is not None:
            return cached
        provider, _ = create_completion_provider(normalized_name)
        cls._completion_provider_cache[normalized_name] = provider
        return provider

    def warm_runtime_components(self) -> None:
        default_kb = str(self.rag_config.get("default_kb_id") or "default").strip() or "default"
        retriever_type = self._resolve_retriever_type(None)
        context_policy = self._context_extrapolation_policy()
        include_graph_store = self._retriever_requires_graph_store(retriever_type)
        warmup_kb = self._select_warmup_kb(default_kb, require_graph=include_graph_store)
        try:
            self._build_runtime_components(
                warmup_kb,
                include_graph_store=include_graph_store,
                include_llm_provider=context_policy.enabled
                or self._runtime_requires_llm_provider(retriever_type=retriever_type),
            )
            reranker_type = str(self.rag_config.get("reranker_type") or "").strip().lower()
            reranker_config = dict(self.rag_config.get("reranker_config", {}))
            if reranker_type == "cross_encoder" and bool(reranker_config.get("preload_on_startup", True)):
                RerankerFactory.create_reranker(reranker_type, reranker_config)
        except Exception as exc:
            logger.warning("Runtime warmup skipped: %s", exc)

    def _select_warmup_kb(self, preferred_kb: str, *, require_graph: bool) -> str:
        if not require_graph:
            return preferred_kb
        try:
            kb_config = self._resolve_kb_config(preferred_kb)
        except Exception:
            kb_config = {}
        if kb_config.get("graph") and kb_config.get("database"):
            return preferred_kb

        for entry in self.rag_config.get("knowledge_bases", []) or []:
            if not isinstance(entry, dict):
                continue
            if entry.get("graph") and entry.get("database"):
                candidate = str(entry.get("id") or entry.get("kb_id") or "").strip()
                if candidate:
                    return candidate
        return preferred_kb

    @staticmethod
    def _retriever_requires_graph_store(retriever_type: str) -> bool:
        return retriever_type in {"graph", "graph_rag"}

    def _context_extrapolation_policy(self) -> ContextExtrapolationPolicy:
        return ContextExtrapolationPolicy.model_validate(self.rag_config.get("context_extrapolation", {}))

    def _runtime_requires_llm_provider(self, *, retriever_type: str) -> bool:
        if retriever_type in {"hyde", "multi_query", "contextual_compression"}:
            return True
        return str(self.rag_config.get("reranker_type") or "").strip().lower() == "llm_reranker"

    def _resolve_retriever_type(self, retriever_type: str | None) -> str:
        return str(retriever_type or self.rag_config.get("default_retriever_type") or "graph_rag")

    def _candidate_pool(self, k: int) -> int:
        """Candidate count to retrieve before reranking. A wide pool lets the reranker
        see tabular/code chunks that pure dense ranking would bury; it then trims to k."""
        configured = int(self.rag_config.get("candidate_pool", 30) or 30)
        return max(configured, k * 4, k)

    def _resolve_kb_config(self, kb_id: str) -> dict[str, Any]:
        """Return the knowledge_bases[] entry for kb_id (vector collection, graph, persona)."""
        for entry in self.rag_config.get("knowledge_bases", []) or []:
            if str(entry.get("id")) == str(kb_id):
                return dict(entry)
        return {}

    def _ontology_link_settings(self, kb_id: str) -> tuple[bool, dict[str, Any]]:
        """Resolve whether to ground chunks into the curated ontology at index time.

        Per-KB ``link_ontology`` overrides the global default; ``ontology_link_config``
        (per-KB, else global) tunes the linker (edge_type, stopword_names, etc.).
        """
        kb_config = self._resolve_kb_config(kb_id)
        global_default = bool(self.rag_config.get("link_ontology", False))
        link_ontology = bool(kb_config.get("link_ontology", global_default))
        link_config = dict(
            self.rag_config.get("ontology_link_config", {})
            or {}
        )
        link_config.update(kb_config.get("ontology_link_config", {}) or {})
        return link_ontology, link_config

    def _apply_reranker(self, query: str, docs: list, base_config: dict[str, Any]) -> list:
        reranker_type = self.rag_config.get("reranker_type")
        if not reranker_type or not docs:
            return docs

        reranker_config = dict(self.rag_config.get("reranker_config", {}))
        reranker_config.setdefault("llm_provider", base_config.get("llm_provider"))
        try:
            reranker = RerankerFactory.create_reranker(reranker_type, reranker_config)
            return reranker.rerank(query, docs)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Reranker %s failed; returning retrieval order instead: %s",
                reranker_type,
                exc,
            )
            return docs

    def _build_explainability(
        self,
        query_link: str,
        retriever_type: str,
        results: list[dict[str, Any]],
        retriever_trace: dict[str, Any] | None,
    ) -> dict[str, Any]:
        trace = dict(retriever_trace or {})
        branch_traces = list(trace.get("branch_traces", []))
        merged_trace = self._merge_branch_trace_details(branch_traces)
        candidate_scores = {
            str(item.get("id")): float(item.get("score", 0.0))
            for item in merged_trace.get("candidate_scores", [])
            if item.get("id")
        }
        candidate_chunk_ids = [chunk_id for chunk_id in candidate_scores if chunk_id]
        reranked_chunks = []
        for rank, result in enumerate(results, start=1):
            reranked_chunks.append(
                {
                    **self._to_explainability_chunk(result),
                    "score": candidate_scores.get(result["id"], 1.0 / rank),
                }
            )

        graph_nodes = trace.get("graph_nodes") or self._build_fallback_graph_nodes(query_link, results)
        graph_edges = trace.get("graph_edges") or self._build_fallback_graph_edges(query_link, results)
        if graph_edges and results:
            query_node_id = f"query:{query_link}"
            graph_edges = [
                *graph_edges,
                *[
                    {
                        "source_id": query_node_id,
                        "target_id": result["id"],
                        "type": "rerank-selected",
                        "properties": {"rank": rank + 1},
                    }
                    for rank, result in enumerate(results)
                ],
            ]

        return {
            "query_link": query_link,
            "retriever_type": retriever_type,
            "candidate_chunk_ids": candidate_chunk_ids,
            "ontology_seed_ids": list(merged_trace.get("ontology_seed_ids", [])),
            "reranking_applied": bool(results),
            "query_normalization": dict(trace.get("query_normalization", {})),
            "timing_breakdown": dict(trace.get("timing_breakdown", {})),
            "graph_contribution": dict(trace.get("graph_summary", {})),
            "branch_contributions": self._build_branch_contribution_summary(branch_traces, results),
            "branches": branch_traces,
            "knowledge_area_probes": [probe.model_dump(exclude_none=True) for probe in self._last_context_extrapolation.probes],
            "ce_status": {
                "status": "accepted" if self._last_context_extrapolation.use_plan else "fallback",
                "fallback_reason": self._last_context_extrapolation.fallback_reason,
            },
            "seed_chunk_ids": list(merged_trace.get("seed_chunk_ids", [])),
            "seed_chunks": [
                self._to_explainability_chunk(result)
                for result in results
                if result["id"] in set(merged_trace.get("seed_chunk_ids", []))
            ],
            "reranked_chunks": reranked_chunks,
            "selected_references": [self._to_explainability_chunk(result) for result in results],
            "answer_to_reference_mapping": [],
            "final_context_snapshot": "\n\n".join(result["content"] for result in results[:3]),
            "visited_node_ids": list(merged_trace.get("visited_node_ids", [])),
            "traversal_hops": list(merged_trace.get("traversal_hops", [])),
            "edge_list": list(graph_edges),
            "final_selected_chunk_ids": [result["id"] for result in results],
            "graph_nodes": graph_nodes,
            "graph_edges": graph_edges,
        }

    def _reset_context_extrapolation_state(self) -> None:
        self._last_context_extrapolation = ContextExtrapolationResult.fallback("not_run")
        self._last_context_trace = {}
        self._last_retrieval_query = ""
        self._last_branch_traces = []
        self._last_timing_breakdown = {}
        self._last_query_normalization = {}
        self._last_graph_summary = {}

    def _build_context_extrapolation_plan(
        self,
        *,
        query: str,
        kb_id: str,
        retriever_type: str,
        base_config: dict[str, Any],
        chat_context: str | None = None,
    ) -> ContextExtrapolationResult:
        policy = self._context_extrapolation_policy()
        agent = ContextExtrapolationAgent(
            llm_provider=base_config.get("llm_provider"),
            config={
                **policy.model_dump(),
                "provider_name": get_default_provider_name(),
            },
        )
        plan = agent.build_plan(query=query, kb_id=kb_id, retriever_type=retriever_type, chat_context=chat_context)
        self._last_context_extrapolation = plan
        self._last_context_trace = agent.get_last_runtime_trace()
        if plan.use_plan:
            logger.info(
                "ContextExtrapolationAgent accepted plan for kb_id=%s retriever=%s confidence=%.2f",
                kb_id,
                retriever_type,
                plan.overall_confidence,
            )
        else:
            logger.info(
                "ContextExtrapolationAgent fallback for kb_id=%s retriever=%s reason=%s",
                kb_id,
                retriever_type,
                plan.fallback_reason or "unknown",
            )
        return plan

    @staticmethod
    def _normalize_query(query: str) -> QueryNormalizationResult:
        normalized_query = str(query or "").strip()
        lowered = normalized_query.casefold()
        query_type = QueryType.GENERAL
        if any(token in lowered for token in ("integrate", "integration", "connector", "connect", "jira", "api")):
            query_type = QueryType.INTEGRATION
        elif any(token in lowered for token in ("workflow", "process", "steps", "lifecycle")):
            query_type = QueryType.WORKFLOW
        elif any(token in lowered for token in ("requirement", "required", "files", "document", "upload", "artifact", "brd")):
            query_type = QueryType.REQUIREMENTS
        elif any(token in lowered for token in ("governance", "policy", "compliance", "audit")):
            query_type = QueryType.GOVERNANCE
        elif lowered.startswith("what is ") or lowered.startswith("who is "):
            query_type = QueryType.DEFINITION
        elif normalized_query.endswith("?") and len(normalized_query.split()) <= 6:
            query_type = QueryType.FACTOID
        simple_query = query_type in {QueryType.FACTOID, QueryType.DEFINITION} and len(normalized_query.split()) <= 8
        detected_entities = [
            token.strip(" ,.:;")
            for token in re.findall(r"\b[A-Z][A-Za-z0-9&._-]*\b", normalized_query)
            if token.strip(" ,.:;")
        ]
        return QueryNormalizationResult(
            original_query=normalized_query,
            normalized_query=normalized_query,
            query_type=query_type,
            simple_query=simple_query,
            detected_entities=list(dict.fromkeys(detected_entities)),
        )

    def _build_branch_plans(
        self,
        *,
        query: str,
        contextual_query: str,
        plan: ContextExtrapolationResult,
        query_normalization: QueryNormalizationResult,
        k: int,
    ) -> list[RetrievalBranchPlan]:
        plans = [
            RetrievalBranchPlan(
                branch_id="base",
                branch_type="base_query",
                label="Base query",
                retrieval_query=contextual_query or query,
                confidence=1.0,
            )
        ]
        # A rejected or failed context-extrapolation plan should not multiply
        # expensive retrieval work with synthetic fallback probes.
        if query_normalization.simple_query or not plan.use_plan:
            return plans
        configured_probe_branches = self.rag_config.get("max_probe_branches", 3)
        try:
            max_probe_branches = int(3 if configured_probe_branches is None else configured_probe_branches)
        except (TypeError, ValueError):
            max_probe_branches = 3
        max_probe_branches = max(0, max_probe_branches)
        for index, probe in enumerate(plan.probes[:max_probe_branches], start=1):
            plans.append(
                RetrievalBranchPlan(
                    branch_id=f"probe-{index}",
                    branch_type=probe.probe_type.value,
                    label=probe.label,
                    retrieval_query=f"User query: {query.strip()}\nKnowledge area: {probe.label}",
                    probe_id=probe.probe_id,
                    probe_type=probe.probe_type.value,
                    confidence=probe.confidence,
                )
            )
        return plans

    def _execute_branch_plans(
        self,
        *,
        branch_plans: list[RetrievalBranchPlan],
        retriever_type: str,
        base_config: dict[str, Any],
        query_link: str,
        pool: int,
    ) -> list[dict[str, Any]]:
        max_workers = max(1, min(len(branch_plans), int(self.rag_config.get("branch_execution_concurrency", 2) or 2)))
        if len(branch_plans) <= 1 or max_workers == 1:
            return [self._execute_branch_plan(branch, retriever_type, base_config, query_link, pool) for branch in branch_plans]
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(self._execute_branch_plan, branch, retriever_type, base_config, query_link, pool) for branch in branch_plans]
        return [future.result() for future in futures]

    def _execute_branch_plan(
        self,
        branch_plan: RetrievalBranchPlan,
        retriever_type: str,
        base_config: dict[str, Any],
        query_link: str,
        pool: int,
    ) -> dict[str, Any]:
        branch_started_at = time.perf_counter()
        branch_config = dict(base_config)
        branch_config["query_link_key"] = f"{query_link}:{branch_plan.branch_id}"
        t_retrieval = time.perf_counter()
        vector_retriever = RetrieverFactory.create_retriever(retriever_type="vector", config=branch_config)
        seed_docs = vector_retriever.retrieve(query=branch_plan.retrieval_query, k=min(pool, max(4, pool)))
        branch_retrieval_ms = int((time.perf_counter() - t_retrieval) * 1000)
        vector_trace = vector_retriever.get_last_trace() if hasattr(vector_retriever, "get_last_trace") else {}
        t_concepts = time.perf_counter()
        concept_ids = self._extract_branch_concepts(branch_plan, seed_docs)
        concept_extraction_ms = int((time.perf_counter() - t_concepts) * 1000)
        ontology_seed_ids = self._resolve_branch_ontology_seeds(branch_plan, concept_ids, branch_config)
        graph_docs: list[Any] = []
        graph_trace: dict[str, Any] = {}
        t_graph = time.perf_counter()
        if retriever_type in {"graph", "graph_rag"} and branch_config.get("graph_store") is not None:
            graph_retriever = RetrieverFactory.create_retriever(retriever_type="graph", config=branch_config)
            try:
                graph_docs = graph_retriever.retrieve(
                    query=branch_plan.retrieval_query,
                    k=min(pool, max(4, pool)),
                    branch_plan=branch_plan,
                    concept_ids=concept_ids,
                    ontology_seed_ids=ontology_seed_ids,
                    seed_docs=seed_docs,
                )
            except TypeError:
                graph_docs = graph_retriever.retrieve(query=branch_plan.retrieval_query, k=min(pool, max(4, pool)))
            graph_trace = graph_retriever.get_last_trace() if hasattr(graph_retriever, "get_last_trace") else {}
        graph_traversal_ms = int((time.perf_counter() - t_graph) * 1000) if retriever_type in {"graph", "graph_rag"} else 0
        docs = self._merge_docs_preserve_order(seed_docs, graph_docs)
        seed_chunk_ids = [str(item) for item in vector_trace.get("seed_chunk_ids", []) if str(item)]
        graph_seed_chunk_ids = [str(item) for item in graph_trace.get("seed_chunk_ids", []) if str(item)]
        candidate_chunk_ids = [doc.id for doc in docs]
        seed_chunk_id_set = set(seed_chunk_ids)
        graph_trace_chunk_ids = [
            str(item)
            for item in [
                *graph_trace.get("resolved_chunk_ids", []),
                *graph_trace.get("visited_chunk_node_ids", []),
            ]
            if str(item)
        ]
        expanded_chunk_ids = list(
            dict.fromkeys(
                [
                    *[doc.id for doc in graph_docs if doc.id not in seed_chunk_id_set],
                    *[chunk_id for chunk_id in graph_trace_chunk_ids if chunk_id not in seed_chunk_id_set],
                ]
            )
        )
        graph_only_chunk_ids = list(expanded_chunk_ids)
        candidate_scores: dict[str, float] = {}
        for item in vector_trace.get("candidate_scores", []):
            if item.get("id"):
                candidate_scores[str(item.get("id"))] = float(item.get("score", 0.0))
        for item in graph_trace.get("candidate_scores", []):
            if item.get("id"):
                candidate_scores[str(item.get("id"))] = max(candidate_scores.get(str(item.get("id")), 0.0), float(item.get("score", 0.0)) + 0.1)
        branch_trace = {
            "branch_id": branch_plan.branch_id,
            "branch_type": branch_plan.branch_type,
            "probe_id": branch_plan.probe_id,
            "probe_type": branch_plan.probe_type,
            "label": branch_plan.label,
            "retrieval_query": branch_plan.retrieval_query,
            "docs": docs,
            "concept_ids": concept_ids,
            "ontology_seed_ids": list(dict.fromkeys([*ontology_seed_ids, *graph_trace.get("ontology_seed_ids", [])])),
            "seed_chunk_ids": list(dict.fromkeys([*seed_chunk_ids, *graph_seed_chunk_ids])),
            "expanded_chunk_ids": expanded_chunk_ids,
            "graph_only_chunk_ids": graph_only_chunk_ids,
            "candidate_chunk_ids": candidate_chunk_ids,
            "selected_chunk_ids": [],
            "candidate_scores": candidate_scores,
            "visited_node_ids": list(graph_trace.get("visited_node_ids", vector_trace.get("visited_node_ids", []))),
            "visited_chunk_node_ids": list(graph_trace.get("visited_chunk_node_ids", [])),
            "resolved_chunk_ids": list(graph_trace.get("resolved_chunk_ids", [])),
            "traversal_hops": list(graph_trace.get("traversal_hops", [])),
            "graph_nodes": list(graph_trace.get("graph_nodes", vector_trace.get("graph_nodes", []))),
            "graph_edges": list(graph_trace.get("graph_edges", vector_trace.get("graph_edges", []))),
            "branch_retrieval_ms": branch_retrieval_ms,
            "concept_extraction_ms": concept_extraction_ms,
            "graph_traversal_ms": graph_traversal_ms,
        }
        return branch_trace

    @staticmethod
    def _merge_docs_preserve_order(seed_docs: list[Any], graph_docs: list[Any]) -> list[Any]:
        merged: list[Any] = []
        seen_ids: set[str] = set()
        for doc in [*seed_docs, *graph_docs]:
            if not getattr(doc, "id", None) or doc.id in seen_ids:
                continue
            merged.append(doc)
            seen_ids.add(doc.id)
        return merged

    @staticmethod
    def _resolve_branch_ontology_seeds(
        branch_plan: RetrievalBranchPlan,
        concept_ids: list[str],
        branch_config: dict[str, Any],
    ) -> list[str]:
        graph_store = branch_config.get("graph_store")
        if graph_store is None:
            return []
        lister = getattr(graph_store, "list_node_ids", None)
        if not callable(lister):
            return []
        try:
            node_ids = [str(node_id) for node_id in lister() if node_id and not str(node_id).startswith("chunk:")]
        except Exception:
            return []
        branch_terms = [branch_plan.label, *concept_ids]
        matched: list[str] = []
        for node_id in node_ids:
            folded = re.sub(r"[^a-z0-9]+", "", node_id.casefold())
            if not folded:
                continue
            if any(re.sub(r"[^a-z0-9]+", "", term.casefold()) in folded or folded in re.sub(r"[^a-z0-9]+", "", term.casefold()) for term in branch_terms if term):
                matched.append(node_id)
            if len(matched) >= 5:
                break
        return matched

    @staticmethod
    def _extract_branch_concepts(branch_plan: RetrievalBranchPlan, docs: list[Any]) -> list[str]:
        concepts: list[str] = []
        for token in re.findall(r"[A-Za-z0-9_&.-]+", branch_plan.label):
            if len(token) > 3 and token not in concepts:
                concepts.append(token)
        for doc in docs[:2]:
            for token in re.findall(r"\b[A-Z][A-Za-z0-9_&.-]*\b", str(doc.content or "")):
                if token not in concepts:
                    concepts.append(token)
                if len(concepts) >= 8:
                    return concepts
        return concepts

    def _merge_branch_candidates(self, branch_traces: list[dict[str, Any]]) -> list[Any]:
        merged_docs: dict[str, Any] = {}
        provenance: dict[str, dict[str, Any]] = {}
        for trace in branch_traces:
            seed_ids = set(trace.get("seed_chunk_ids", []))
            graph_only_ids = set(trace.get("graph_only_chunk_ids", []))
            for rank, doc in enumerate(trace.get("docs", []), start=1):
                if doc.id not in merged_docs:
                    merged_docs[doc.id] = doc
                    provenance[doc.id] = {
                        "branch_ids": set(),
                        "graph_only": False,
                        "seed_hit": False,
                        "concept_ids": set(),
                        "ontology_seed_ids": set(),
                        "score": 0.0,
                    }
                item = provenance[doc.id]
                item["branch_ids"].add(trace.get("branch_id"))
                item["graph_only"] = item["graph_only"] or doc.id in graph_only_ids
                item["seed_hit"] = item["seed_hit"] or doc.id in seed_ids
                item["concept_ids"].update(trace.get("concept_ids", []))
                item["ontology_seed_ids"].update(trace.get("ontology_seed_ids", []))
                item["score"] = max(item["score"], float(trace.get("candidate_scores", {}).get(doc.id, 1.0 / rank)))
        for doc_id, doc in merged_docs.items():
            metadata = dict(getattr(doc, "metadata", {}) or {})
            item = provenance[doc_id]
            metadata["branch_ids"] = sorted(item["branch_ids"])
            metadata["graph_only"] = bool(item["graph_only"])
            metadata["seed_hit"] = bool(item["seed_hit"])
            metadata["concept_ids"] = sorted(item["concept_ids"])
            metadata["ontology_seed_ids"] = sorted(item["ontology_seed_ids"])
            metadata["provenance_score"] = float(item["score"])
            doc.metadata = metadata
        return list(merged_docs.values())

    def _select_final_docs(self, reranked_docs: list[Any], k: int) -> list[Any]:
        return list(reranked_docs[:k])

    @staticmethod
    def _update_branch_selection(branch_traces: list[dict[str, Any]], results: list[dict[str, Any]]) -> None:
        selected_ids = {result["id"] for result in results}
        for trace in branch_traces:
            trace["selected_chunk_ids"] = [chunk_id for chunk_id in trace.get("candidate_chunk_ids", []) if chunk_id in selected_ids]

    def _merge_branch_trace_details(self, branch_traces: list[dict[str, Any]]) -> dict[str, Any]:
        merged: dict[str, Any] = {
            "candidate_scores": [],
            "seed_chunk_ids": [],
            "ontology_seed_ids": [],
            "visited_node_ids": [],
            "traversal_hops": [],
            "graph_nodes": [],
            "graph_edges": [],
        }
        score_map: dict[str, float] = {}
        seen_nodes: set[str] = set()
        seen_edges: set[tuple[str, str, str]] = set()
        for trace in branch_traces:
            merged["seed_chunk_ids"].extend(trace.get("seed_chunk_ids", []))
            merged["ontology_seed_ids"].extend(trace.get("ontology_seed_ids", []))
            merged["visited_node_ids"].extend(trace.get("visited_node_ids", []))
            merged["traversal_hops"].extend(trace.get("traversal_hops", []))
            for chunk_id in trace.get("candidate_chunk_ids", []):
                score_map[chunk_id] = max(score_map.get(chunk_id, 0.0), float(trace.get("candidate_scores", {}).get(chunk_id, 0.0)))
            for node in trace.get("graph_nodes", []):
                node_id = str(node.get("id") or "")
                if node_id and node_id not in seen_nodes:
                    seen_nodes.add(node_id)
                    merged["graph_nodes"].append(node)
            for edge in trace.get("graph_edges", []):
                edge_key = (str(edge.get("source_id") or ""), str(edge.get("target_id") or ""), str(edge.get("type") or ""))
                if edge_key not in seen_edges:
                    seen_edges.add(edge_key)
                    merged["graph_edges"].append(edge)
        merged["candidate_scores"] = [{"id": chunk_id, "score": score} for chunk_id, score in score_map.items()]
        merged["seed_chunk_ids"] = list(dict.fromkeys(merged["seed_chunk_ids"]))
        merged["ontology_seed_ids"] = list(dict.fromkeys(merged["ontology_seed_ids"]))
        merged["visited_node_ids"] = list(dict.fromkeys(merged["visited_node_ids"]))
        return merged

    def _build_branch_contribution_summary(self, branch_traces: list[dict[str, Any]], results: list[dict[str, Any]]) -> list[dict[str, Any]]:
        selected_ids = {result["id"] for result in results}
        summaries: list[dict[str, Any]] = []
        for trace in branch_traces:
            selected_chunk_ids = [chunk_id for chunk_id in trace.get("candidate_chunk_ids", []) if chunk_id in selected_ids]
            candidate_count = len(trace.get("candidate_chunk_ids", []))
            selected_count = len(selected_chunk_ids)
            summaries.append(
                {
                    "branch_id": trace.get("branch_id"),
                    "branch_type": trace.get("branch_type"),
                    "label": trace.get("label"),
                    "probe_id": trace.get("probe_id"),
                    "probe_type": trace.get("probe_type"),
                    "candidate_count": candidate_count,
                    "selected_count": selected_count,
                    "contribution_score": round(selected_count / max(1, candidate_count), 4),
                }
            )
        return summaries

    def _build_graph_contribution_summary(self, branch_traces: list[dict[str, Any]], results: list[dict[str, Any]]) -> dict[str, Any]:
        visited_nodes = set()
        expanded_chunks = set()
        graph_only_chunks = set()
        seed_chunk_ids = set()
        for trace in branch_traces:
            visited_nodes.update(trace.get("visited_node_ids", []))
            expanded_chunks.update(trace.get("expanded_chunk_ids", []))
            graph_only_chunks.update(trace.get("graph_only_chunk_ids", []))
            seed_chunk_ids.update(trace.get("seed_chunk_ids", []))
        selected_ids = {result["id"] for result in results}
        graph_selected_chunks = graph_only_chunks & selected_ids
        non_seed_selected = {chunk_id for chunk_id in selected_ids if chunk_id not in seed_chunk_ids}
        return {
            "visited_nodes": len(visited_nodes),
            "expanded_chunks": len(expanded_chunks),
            "graph_only_candidates": len(graph_only_chunks),
            "graph_selected_chunks": len(graph_selected_chunks),
            "graph_contribution_rate": round(len(graph_selected_chunks) / max(1, len(selected_ids)), 4),
            "non_seed_survival_rate": round(len(non_seed_selected) / max(1, len(selected_ids)), 4),
        }

    @staticmethod
    def _build_retrieval_query(
        query: str,
        plan: ContextExtrapolationResult,
        *,
        chat_context: str | None = None,
    ) -> str:
        base_query = build_contextual_retrieval_query(query, chat_context)
        if not plan.use_plan:
            return base_query

        sections = [f"User query: {query.strip()}"]
        if chat_context:
            sections.append(f"Recent conversation context:\n{chat_context.strip()}")
        if plan.intent:
            sections.append(f"Intent: {plan.intent}")
        if plan.persona:
            sections.append(f"Persona: {plan.persona}")
        if plan.retrieval_probes:
            sections.append("Knowledge areas: " + " | ".join(plan.retrieval_probes))
        return "\n".join(sections)

    @staticmethod
    def _serialize_doc(doc: Any, query_link: str) -> dict[str, Any]:
        return {
            "id": doc.id,
            "content": doc.content,
            "source": doc.metadata.get("source") if doc.metadata else doc.source,
            "chunk_index": RagTool._resolve_chunk_index(doc),
            "query_link": query_link,
        }

    @staticmethod
    def _to_explainability_chunk(result: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": result.get("id"),
            "source": result.get("source"),
            "chunk_index": int(result.get("chunk_index", 0) or 0),
            "snippet": str(result.get("content", "") or "")[:280],
        }

    @staticmethod
    def _prune_graph_to_final(
        graph_nodes: list[dict[str, Any]],
        graph_edges: list[dict[str, Any]],
        final_ids: set[str],
        recall_limit: int = 5,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Keep only the chunks that survived reranking.

        The graph retriever emits a wide candidate pool (every doc it scored) as
        ``final_chunk`` / ``seed_chunk`` nodes, but only the reranked ``final_ids``
        are shown to the user. Trim the final-chunk lane to that set and cap the
        recall lane so the visualization mirrors the answer.
        """
        def role_of(node: dict[str, Any]) -> str:
            props = node.get("properties") or {}
            role = str(props.get("role") or "")
            if role:
                return role
            label = str(node.get("label") or "")
            nid = str(node.get("id") or "")
            if label == "Query" or nid.startswith("query:"):
                return "query"
            if label == "Chunk":
                return "final_chunk"
            return "concept"

        kept_nodes: list[dict[str, Any]] = []
        recall_seen = 0
        for node in graph_nodes:
            role = role_of(node)
            nid = str(node.get("id") or "")
            if role == "final_chunk":
                if nid in final_ids:
                    kept_nodes.append(node)
            elif role == "seed_chunk":
                if recall_seen < recall_limit:
                    kept_nodes.append(node)
                    recall_seen += 1
            else:
                kept_nodes.append(node)

        kept_ids = {str(node.get("id")) for node in kept_nodes}
        kept_edges = [
            edge for edge in graph_edges
            if str(edge.get("source_id")) in kept_ids and str(edge.get("target_id")) in kept_ids
        ]
        return kept_nodes, kept_edges

    @staticmethod
    def _build_fallback_graph_nodes(query_link: str, results: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return [
            {
                "id": f"query:{query_link}",
                "label": "Query",
                "properties": {"name": "Query"},
            },
            *[
                {
                    "id": result["id"],
                    "label": "Chunk",
                    "properties": {
                        "source": result.get("source"),
                        "chunk_index": result.get("chunk_index", 0),
                        "text": result.get("content", ""),
                    },
                }
                for result in results
            ],
        ]

    @staticmethod
    def _build_fallback_graph_edges(query_link: str, results: list[dict[str, Any]]) -> list[dict[str, Any]]:
        query_node_id = f"query:{query_link}"
        return [
            {
                "source_id": query_node_id,
                "target_id": result["id"],
                "type": "seed",
                "properties": {"rank": rank + 1},
            }
            for rank, result in enumerate(results)
        ]

    @staticmethod
    def _query_link(query: str) -> str:
        return hashlib.sha1(query.strip().lower().encode("utf-8")).hexdigest()[:16]

    @staticmethod
    def _basename(source: str) -> str:
        """Return the file name from a source path, handling both POSIX ('/') and
        Windows ('\\') separators regardless of the host OS. Documents indexed on
        Windows store paths like 'C:\\Users\\...\\file.txt'; on a Linux container
        Path(...).name (PurePosixPath) keeps the backslashes, so normalize the
        separators before taking the last segment."""
        normalized = str(source or "").replace("\\", "/").rstrip("/")
        return normalized.rsplit("/", 1)[-1]

    @staticmethod
    def _resolve_chunk_index(doc: Any) -> int:
        """Resolve chunk index from metadata/model, then fall back to id suffix."""
        metadata = getattr(doc, "metadata", {}) or {}
        raw_chunk_index = metadata.get("chunk_index", getattr(doc, "chunk_index", 0))
        try:
            parsed_chunk_index = int(raw_chunk_index)
        except (TypeError, ValueError):
            parsed_chunk_index = 0

        # Older indexed records may not persist chunk_index metadata; ids follow "...:<part>:<chunk>".
        if parsed_chunk_index == 0:
            doc_id = str(getattr(doc, "id", "") or "")
            tail = doc_id.rsplit(":", 1)[-1]
            try:
                parsed_chunk_index = int(tail)
            except (TypeError, ValueError):
                pass

        return parsed_chunk_index
