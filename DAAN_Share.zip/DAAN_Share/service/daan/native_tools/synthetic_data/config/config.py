"""
Configuration management for Synthetic Test Data Generator.

When running inside DAAN's FastAPI service, the environment is already
set up by the server.  No dotenv calls are made here.
"""
import os
import re
import pandas as pd
from typing import Dict, Any, List, Optional


class GenerationConfig:
    """Data generation configuration.

    All paths must be supplied by the caller (SyntheticDataTool) so that
    each workflow session gets its own isolated output and scripts dirs.
    """

    def __init__(
        self,
        selected_tables: Optional[List[str]] = None,
        row_counts: Optional[Dict[str, int]] = None,
        output_format: str = "csv",
        scripts_dir: Optional[str] = None,
        output_dir: Optional[str] = None,
    ):
        self.selected_tables = selected_tables or []
        self.row_counts = row_counts or {}
        self.output_format = output_format
        self.scripts_dir = scripts_dir
        self.output_dir = output_dir
        self.fk_full_load_threshold = 10000
        self.fk_sample_size = 10000

    @classmethod
    def from_csv_inputs(cls, csv_dir: str) -> "GenerationConfig":
        """
        Build a GenerationConfig by reading requirements.csv from the session
        inputs directory.

        requirements.csv must have two columns: ``table_name`` and ``row_count``.
        Every other .csv file in the directory is considered a data table.

        Args:
            csv_dir: Path to session_storage/{session_id}/inputs/

        Returns:
            GenerationConfig instance populated from the CSV mapping file.
        """
        mapping_path = os.path.join(csv_dir, "requirements.csv")
        if not os.path.exists(mapping_path):
            raise FileNotFoundError(
                f"requirements.csv not found in {csv_dir}. "
                "Create a CSV with columns: table_name, row_count"
            )

        mapping_df = pd.read_csv(mapping_path)

        # Normalise headers: strip whitespace, lowercase, replace spaces/hyphens
        # with underscores — so "Table Name" and "table_name" both match.
        mapping_df.columns = [
            re.sub(r"[\s\-\.]+", "_", c.strip().lower())
            for c in mapping_df.columns
        ]

        required_cols = {"table_name", "row_count"}
        if not required_cols.issubset(set(mapping_df.columns)):
            raise ValueError(
                f"requirements.csv must have columns: table_name, row_count "
                f"(spaces in headers are normalised automatically). "
                f"After normalisation got: {list(mapping_df.columns)}"
            )

        # Drop empty / blank rows (pandas reads trailing commas as NaN rows)
        mapping_df = mapping_df.dropna(subset=["table_name", "row_count"])
        mapping_df = mapping_df[mapping_df["table_name"].astype(str).str.strip() != ""]

        row_counts: Dict[str, int] = {
            str(row["table_name"]).strip().upper(): int(float(row["row_count"]))
            for _, row in mapping_df.iterrows()
        }
        selected_tables = list(row_counts.keys())

        return cls(
            selected_tables=selected_tables,
            row_counts=row_counts,
            output_format="csv",
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "selected_tables": self.selected_tables,
            "row_counts": self.row_counts,
            "output_format": self.output_format,
            "scripts_dir": self.scripts_dir,
            "output_dir": self.output_dir,
        }
