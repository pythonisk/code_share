"""
Referential Integrity Agent - Manages FK relationships in generated data
"""
import logging
import os
import pandas as pd
from typing import Dict, List, Any
from datetime import datetime

logger = logging.getLogger(__name__)


class ReferentialIntegrityEnforcer:
    """
    Ensure foreign key relationships are maintained in generated data
    """
    

    def __init__(self, generation_plan: Dict[str, Any], metadata: Dict[str, Any], output_dir: str, output_format: str = 'csv'):
        """
        Initialize Referential Integrity Enforcer
        
        Args:
            generation_plan: Generation plan from GenerationPlanner
            metadata: Schema metadata from SchemaMetadataExtractor
            output_dir: Directory containing generated CSV/Excel files
            output_format: Output format ('csv' or 'excel')
        """
        self.generation_plan = generation_plan
        self.metadata = metadata
        self.output_dir = output_dir
        self.output_format = output_format.lower()
        self.generated_data = {}
    
    def enforce_referential_integrity(self) -> bool:
        """
        Load generated data and enforce FK relationships
        
        Returns:
            bool: True if successful
        """
        try:
            print("\n" + "="*80)
            print("🔗 ENFORCING REFERENTIAL INTEGRITY")
            print("="*80)
            
            execution_order = self.generation_plan.get('execution_order', [])
            table_plans = self.generation_plan.get('table_plans', {})
            
            # Debug: print what we're looking for
            logger.info(f"Output directory: {self.output_dir}")
            logger.info(f"Output format: {self.output_format}")
            logger.info(f"Execution order: {execution_order}")
            logger.info(f"Table plans keys: {list(table_plans.keys())}")
            
            # List files in output directory for debugging
            if os.path.exists(self.output_dir):
                files_in_dir = os.listdir(self.output_dir)
                logger.debug(f"Files in output directory: {files_in_dir}")
            else:
                logger.warning(f"Output directory does not exist: {self.output_dir}")
                print(f"   ⚠ Output directory not found: {self.output_dir}")
            
            # Load all generated data
            print("\n📂 LOADING DATA FILES...")
            for table in execution_order:
                if table in table_plans:
                    self._load_table_data(table)
            
            # Enforce FK relationships
            print("\n🔐 ENFORCING FOREIGN KEY RELATIONSHIPS...")
            for table in execution_order:
                if table in table_plans:
                    plan = table_plans[table]
                    if plan.get('has_fk'):
                        self._enforce_fk_for_table(table, plan)
            
            print("\n" + "="*80)
            print("[OK] REFERENTIAL INTEGRITY ENFORCEMENT COMPLETED")
            print("="*80 + "\n")
            
            logger.info("Referential integrity enforcement completed")
            return True
        
        except Exception as e:
            logger.error(f"Referential integrity enforcement failed: {str(e)}")
            print(f"❌ Error: {str(e)}")
            return False
    
    def _load_table_data(self, table_name: str) -> bool:
        """
        Load generated data from CSV or Excel based on output format
        
        Args:
            table_name: Name of the table
        
        Returns:
            bool: True if loaded successfully
        """
        try:
            # Try to find the file regardless of format - look for what actually exists
            # Files might be saved with different cases
            paths_to_try = [
                # Exact match with configured format
                os.path.join(self.output_dir, f"{table_name}.xlsx") if self.output_format == 'excel' else os.path.join(self.output_dir, f"{table_name}.csv"),
                # Uppercase with configured format
                os.path.join(self.output_dir, f"{table_name.upper()}.xlsx") if self.output_format == 'excel' else os.path.join(self.output_dir, f"{table_name.upper()}.csv"),
                # Lowercase with configured format
                os.path.join(self.output_dir, f"{table_name.lower()}.xlsx") if self.output_format == 'excel' else os.path.join(self.output_dir, f"{table_name.lower()}.csv"),
                # Also check the opposite format (in case user changed settings)
                os.path.join(self.output_dir, f"{table_name}.xlsx") if self.output_format != 'excel' else os.path.join(self.output_dir, f"{table_name}.csv"),
                os.path.join(self.output_dir, f"{table_name.upper()}.xlsx") if self.output_format != 'excel' else os.path.join(self.output_dir, f"{table_name.upper()}.csv"),
                os.path.join(self.output_dir, f"{table_name.lower()}.xlsx") if self.output_format != 'excel' else os.path.join(self.output_dir, f"{table_name.lower()}.csv"),
            ]
            
            for file_path in paths_to_try:
                logger.debug(f"Checking path: {file_path}")
                if os.path.exists(file_path):
                    logger.info(f"Found file at: {file_path}")
                    try:
                        if file_path.endswith('.xlsx'):
                            df = pd.read_excel(file_path)
                        else:
                            df = pd.read_csv(file_path)
                        
                        self.generated_data[table_name] = df
                        logger.info(f"Loaded {len(df)} rows from {table_name}")
                        print(f"   ✓ {table_name}: {len(df)} rows, {len(df.columns)} columns")
                        return True
                    except Exception as e:
                        logger.error(f"Failed to read {file_path}: {str(e)}")
                        continue
            
            logger.warning(f"Data file not found for {table_name}")
            print(f"   ✗ {table_name}: FILE NOT FOUND")
            return False
        
        except Exception as e:
            logger.error(f"Failed to load data for {table_name}: {str(e)}")
            print(f"   ✗ {table_name}: ERROR - {str(e)}")
            return False
    
    def _enforce_fk_for_table(self, table_name: str, table_plan: Dict[str, Any]) -> bool:
        """
        Enforce FK constraints for a table
        
        Args:
            table_name: Name of the table
            table_plan: Generation plan for the table
        
        Returns:
            bool: True if successful
        """
        try:
            if table_name not in self.generated_data:
                logger.warning(f"Data not loaded for {table_name}")
                return False
            
            df = self.generated_data[table_name]
            
            # Print table header (simplified)
            print(f"\n   * {table_name.upper()}: {len(df)} rows")
            
            # Use the improved column information from generation plan
            columns = table_plan.get('columns', [])
            fk_count = 0
            
            for col_plan in columns:
                if col_plan.get('is_foreign_key'):
                    fk_col = col_plan.get('column_name')
                    fk_references = col_plan.get('foreign_key_references', [])
                    
                    if not fk_references:
                        # Fallback to old FK relationships format
                        continue
                    
                    for fk_ref in fk_references:
                        parent_table = fk_ref.get('referenced_table') or fk_ref.get('REFERENCED_TABLE')
                        parent_col = fk_ref.get('referenced_column') or fk_ref.get('REFERENCED_COLUMN')
                        is_ai_detected = fk_ref.get('ai_detected', False)
                        is_implicit = fk_ref.get('is_implicit', False)
                        confidence = fk_ref.get('confidence', 'unknown')
                        
                        if not parent_table or not parent_col:
                            continue
                        
                        if parent_table not in self.generated_data:
                            logger.warning(f"Parent table {parent_table} data not available for {table_name}.{fk_col}")
                            print(f"      [WARNING] Parent table '{parent_table}' not available")
                            continue
                        
                        parent_df = self.generated_data[parent_table]
                        
                        # Check if the columns exist in dataframes
                        if fk_col not in df.columns:
                            logger.warning(f"FK column {fk_col} not found in {table_name}")
                            print(f"      [ERROR] FK column '{fk_col}' not found")
                            continue
                        
                        if parent_col not in parent_df.columns:
                            logger.warning(f"Parent column {parent_col} not found in {parent_table}")
                            print(f"      [ERROR] Parent column '{parent_col}' not found")
                            continue
                        
                        # Get valid values from parent table
                        valid_values = parent_df[parent_col].dropna().unique().tolist()
                        
                        # Check for mismatches - identify rows that have invalid FK values
                        # Only consider non-null FK values for mismatch detection
                        non_null_mask = df[fk_col].notna()
                        if non_null_mask.any():
                            mismatches = df[non_null_mask & ~df[fk_col].isin(valid_values)]
                            mismatch_count = len(mismatches)
                        else:
                            mismatch_count = 0
                        
                        # Fix only the mismatched rows, preserve valid rows and NULLs
                        if len(valid_values) > 0:
                            # Create mask for rows that need fixing
                            fix_mask = non_null_mask & ~df[fk_col].isin(valid_values)
                            
                            if fix_mask.any():
                                # Replace only the invalid values with valid ones (cycling)
                                invalid_indices = df[fix_mask].index
                                replacement_values = [valid_values[i % len(valid_values)] for i in range(len(invalid_indices))]
                                df.loc[invalid_indices, fk_col] = replacement_values
                                logger.info(f"Fixed {mismatch_count} mismatched FK values for {table_name}.{fk_col}")
                            
                            fk_count += 1
                            
                            # Status with AI detection indicator
                            ai_marker = " [AI-DETECTED]" if is_ai_detected else ""
                            implicit_marker = " [IMPLICIT]" if is_implicit else ""
                            confidence_marker = f" ({confidence})" if is_ai_detected else ""
                            
                            if mismatch_count == 0:
                                status = "✓ OK"
                                detail = f"All {len(df)} values valid"
                            else:
                                status = "⚠ FIXED"
                                detail = f"{mismatch_count} rows corrected, {len(df) - mismatch_count} already valid"
                            
                            print(f"      [{status}] {fk_col} -> {parent_table}.{parent_col} ({detail}){ai_marker}{implicit_marker}{confidence_marker}")
                            
                            logger.info(f"Updated FK {table_name}.{fk_col} -> {parent_table}.{parent_col}: "
                                      f"Fixed {mismatch_count}/{len(df)} rows (AI-detected: {is_ai_detected})")
                        else:
                            print(f"      [ERROR] No valid values found in parent table {parent_table}")
            
            # Fallback to old FK relationships format if no column-based FKs found
            if fk_count == 0:
                fk_relationships = table_plan.get('foreign_keys', [])
                
                for fk in fk_relationships:
                    # Extract FK details with multiple possible field names
                    fk_col = (fk.get('FK_COLUMN_NAME') or fk.get('COLUMN_NAME') or '').upper()
                    parent_table = (fk.get('REFERENCED_TABLE_NAME') or fk.get('REFERENCED_TABLE') or '').upper()
                    parent_col = (fk.get('REFERENCED_COLUMN_NAME') or fk.get('REFERENCED_COLUMN') or '').upper()
                    constraint_name = fk.get('CONSTRAINT_NAME', 'UNKNOWN')
                    
                    if not fk_col or not parent_table:
                        logger.warning(f"Incomplete FK definition for {table_name}: {constraint_name}")
                        continue
                    
                    if parent_table not in self.generated_data:
                        logger.warning(f"Parent table {parent_table} data not available for {table_name}.{fk_col}")
                        print(f"      [ERROR] Parent table '{parent_table}' not available")
                        continue
                    
                    parent_df = self.generated_data[parent_table]
                    
                    # Check if the columns exist in dataframes
                    if fk_col not in df.columns:
                        logger.warning(f"FK column {fk_col} not found in {table_name}")
                        print(f"      [ERROR] FK column '{fk_col}' not found")
                        continue
                    
                    if parent_col not in parent_df.columns:
                        logger.warning(f"Parent column {parent_col} not found in {parent_table}")
                        print(f"      [ERROR] Parent column '{parent_col}' not found")
                        continue
                    
                    # Get valid values from parent table
                    valid_values = parent_df[parent_col].dropna().unique().tolist()
                    
                    # Check for mismatches - only non-null FK values
                    non_null_mask = df[fk_col].notna()
                    if non_null_mask.any():
                        mismatches = df[non_null_mask & ~df[fk_col].isin(valid_values)]
                        mismatch_count = len(mismatches)
                    else:
                        mismatch_count = 0
                    
                    # Fix only mismatched rows, preserve valid rows and NULLs
                    if len(valid_values) > 0:
                        # Create mask for rows that need fixing
                        fix_mask = non_null_mask & ~df[fk_col].isin(valid_values)
                        
                        if fix_mask.any():
                            # Replace only invalid values with valid ones (cycling)
                            invalid_indices = df[fix_mask].index
                            replacement_values = [valid_values[i % len(valid_values)] for i in range(len(invalid_indices))]
                            df.loc[invalid_indices, fk_col] = replacement_values
                            logger.info(f"Fixed {mismatch_count} mismatched FK values for {table_name}.{fk_col}")
                        
                        # Status output
                        if mismatch_count == 0:
                            status = "✓ OK"
                            detail = f"All {len(df)} values valid"
                        else:
                            status = "⚠ FIXED"
                            detail = f"{mismatch_count} rows corrected, {len(df) - mismatch_count} already valid"
                        
                        print(f"      [{status}] {fk_col} -> {parent_table}.{parent_col} ({detail})")
                        
                        logger.info(f"Updated FK {table_name}.{fk_col} -> {parent_table}.{parent_col}: "
                                  f"Fixed {mismatch_count}/{len(df)} rows")
                    else:
                        print(f"      ❌ No valid values found in parent table {parent_table}")
            
            # Save updated data in the chosen format
            if self.output_format == 'excel':
                excel_path = os.path.join(self.output_dir, f"{table_name.upper()}.xlsx")
                df.to_excel(excel_path, index=False, engine='openpyxl')
                logger.info(f"Saved updated {table_name} to Excel")
            else:
                csv_path = os.path.join(self.output_dir, f"{table_name.upper()}.csv")
                df.to_csv(csv_path, index=False)
                logger.info(f"Saved updated {table_name} to CSV")
            
            return True
        
        except Exception as e:
            logger.error(f"Failed to enforce FK for {table_name}: {str(e)}")
            print(f"      [ERROR] {str(e)}")
            return False
    
    def generate_integrity_script(self, output_path: str) -> bool:
        """
        Generate Python script that applies referential integrity
        
        Args:
            output_path: Path to save the script
        
        Returns:
            bool: True if successful
        """
        try:
            script = self._build_integrity_script()
            
            with open(output_path, 'w') as f:
                f.write(script)
            
            logger.info(f"Integrity script saved to {output_path}")
            print(f"* Integrity script saved: apply_referential_integrity.py")
            return True
        
        except Exception as e:
            logger.error(f"Failed to generate integrity script: {str(e)}")
            return False
    
    def _build_integrity_script(self) -> str:
        """Build integrity enforcement script"""
        script = '''"""
Referential Integrity Enforcement Script
Auto-generated script to enforce FK relationships
"""

import pandas as pd
import os
from datetime import datetime

def enforce_integrity():
    """Enforce referential integrity for all generated data"""
    
    output_dir = os.path.dirname(__file__)
    
'''
        
        execution_order = self.generation_plan.get('execution_order', [])
        table_plans = self.generation_plan.get('table_plans', {})
        
        for table in execution_order:
            if table in table_plans:
                plan = table_plans[table]
                if plan.get('has_fk'):
                    fk_code = self._build_fk_enforcement_code(table, plan)
                    script += fk_code
        
        script += '''
    print("Referential integrity enforcement completed!")

if __name__ == "__main__":
    enforce_integrity()
'''
        
        return script
    
    def _build_fk_enforcement_code(self, table_name: str, table_plan: Dict[str, Any]) -> str:
        """Build code for a single table's FK enforcement with proper indentation"""
        fk_relationships = table_plan.get('foreign_keys', [])
        
        # If no FKs, just add a comment
        if not fk_relationships:
            return f'''        # {table_name}: No FK to enforce
        print("[OK] {table_name}: No FK to enforce")
        df_{table_name} = pd.read_csv(os.path.join(output_dir, '{table_name}.csv'))

'''
        
        # Has FKs - build enforcement code
        code = f'''        # Enforce FK for {table_name}
        print("\\n[ENFORCE] {table_name}...")
        df_{table_name} = pd.read_csv(os.path.join(output_dir, '{table_name}.csv'))
'''
        
        # Track which parent tables we've already loaded
        loaded_parents = set()
        
        for fk in fk_relationships:
            # Handle multiple field name variations
            fk_col = (fk.get('FK_COLUMN_NAME') or fk.get('COLUMN_NAME') or '').upper()
            parent_table = (fk.get('REFERENCED_TABLE_NAME') or fk.get('REFERENCED_TABLE') or '').upper()
            parent_col = (fk.get('REFERENCED_COLUMN_NAME') or fk.get('REFERENCED_COLUMN') or '').upper()
            
            if not fk_col or not parent_table or not parent_col:
                continue
            
            # Check if self-referential FK
            is_self_ref = (parent_table == table_name.upper())
            
            # Load parent table only once (unless self-referential)
            if not is_self_ref and parent_table not in loaded_parents:
                code += f'''        df_{parent_table} = pd.read_csv(os.path.join(output_dir, '{parent_table}.csv'))
'''
                loaded_parents.add(parent_table)
            
            # Get valid IDs
            if is_self_ref:
                # Self-referential: use current table's PKs
                code += f'''        
        # Fix {fk_col} FK (self-referential)
        valid_{parent_table.lower()}_ids = df_{table_name}['{parent_col}'].unique().tolist()
        df_{table_name}['{fk_col}'] = df_{table_name}['{fk_col}'].apply(
            lambda x: x if pd.isna(x) or x in valid_{parent_table.lower()}_ids else valid_{parent_table.lower()}_ids[int(x) % len(valid_{parent_table.lower()}_ids)]
        )
        print(f"  [FIXED] {table_name}.{fk_col} (self-referential)")
'''
            else:
                # Regular FK
                code += f'''        
        # Fix {fk_col} FK
        valid_{parent_table.lower()}_ids = df_{parent_table}['{parent_col}'].unique().tolist()
        print(f"  Valid {parent_table} IDs: {{valid_{parent_table.lower()}_ids[:10]}}... (total: {{len(valid_{parent_table.lower()}_ids)}})")
        df_{table_name}['{fk_col}'] = [valid_{parent_table.lower()}_ids[i % len(valid_{parent_table.lower()}_ids)] for i in range(len(df_{table_name}))]
        print(f"  [FIXED] {{len(df_{table_name})}} FK values: {table_name}.{fk_col} -> {parent_table}.{parent_col}")
'''
        
        # Save the table
        code += f'''        
        df_{table_name}.to_csv(os.path.join(output_dir, '{table_name}.csv'), index=False)
        print(f"  [SAVED] {table_name}.csv")

'''
        
        return code
    
    def generate_ri_code(self, code_path: str, output_dir: str) -> bool:
        """
        Generate Python code for referential integrity enforcement
        
        Args:
            code_path: Path to save the generated code
            output_dir: Directory containing the CSV files
            
        Returns:
            bool: True if successful
        """
        try:
            timestamp = datetime.now().isoformat()
            # Use forward slashes to avoid Windows path unicode escape issues
            output_dir_safe = output_dir.replace('\\', '/')
            code = f'''"""
Referential Integrity Enforcement Script
Generated: {timestamp}
Output Directory: {output_dir_safe}
"""
import os
import pandas as pd
import logging

logger = logging.getLogger(__name__)

def enforce_referential_integrity(output_dir):
    """Enforce FK relationships in generated data"""
    
    print("\\n[RI] STEP 7: Enforcing Referential Integrity")
    print("-" * 60)
    print(f"Output Directory: {{output_dir}}")
    
    try:
'''
            
            # Get execution order and table plans
            execution_order = self.generation_plan.get('execution_order', [])
            table_plans = self.generation_plan.get('table_plans', {})
            
            # Add code for each table
            for table in execution_order:
                if table in table_plans:
                    table_plan = table_plans[table]
                    code += self._build_fk_enforcement_code(table, table_plan)
            
            code += f'''        print("\\n[RI] Referential integrity enforcement completed")
        return True
        
    except Exception as e:
        logger.error(f"Error enforcing referential integrity: {{str(e)}}")
        print(f"[ERROR] Error: {{str(e)}}")
        return False

if __name__ == "__main__":
    output_directory = r"{output_dir}"
    enforce_referential_integrity(output_directory)
'''
            
            # Write code to file with UTF-8 encoding
            os.makedirs(os.path.dirname(code_path), exist_ok=True)
            with open(code_path, 'w', encoding='utf-8') as f:
                f.write(code)
            
            logger.info(f"Generated referential integrity code: {code_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to generate RI code: {str(e)}")
            return False