"""
Simple Model Cache Manager - Stores trained ML models per database
Loads .pkl files on demand instead of retraining

Structure:
  output/model_cache/
    SNOWFLAKE_SAMPLE_DATA/
      CUSTOMER.pkl
      LINEITEM.pkl
      ORDERS.pkl
      ...
    ANOTHER_DB/
      TABLE1.pkl
      TABLE2.pkl
"""
import os
import pickle
import logging
from pathlib import Path
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


class ModelCacheManager:
    """
    Simple cache manager - stores one .pkl file per table per database
    No complex metadata, no fingerprinting - just filesystem-based lookup
    """
    
    def __init__(self, cache_dir: str = 'output/model_cache'):
        """
        Initialize cache manager
        
        Args:
            cache_dir: Root directory for all cached models
        """
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"Model cache manager initialized at {self.cache_dir}")
    
    def get_table_cache_path(self, database: str, table_name: str) -> Path:
        """
        Get the .pkl file path for a specific table in a database
        
        Args:
            database: Database name
            table_name: Table name
        
        Returns:
            Path to {cache_dir}/{database}/{table_name}.pkl
        """
        db_dir = self.cache_dir / database.upper()
        db_dir.mkdir(parents=True, exist_ok=True)
        return db_dir / f"{table_name}.pkl"
    
    def is_table_cached(self, database: str, table_name: str) -> bool:
        """
        Check if a trained model exists for this table
        
        Args:
            database: Database name
            table_name: Table name
        
        Returns:
            bool: True if .pkl file exists
        """
        cache_path = self.get_table_cache_path(database, table_name)
        exists = cache_path.exists()
        
        if exists:
            logger.info(f"Found cached model: {cache_path}")
        
        return exists
    
    def load_table_model(self, database: str, table_name: str) -> Optional[Dict[str, Any]]:
        """
        Load cached trained model for a table
        
        Args:
            database: Database name
            table_name: Table name
        
        Returns:
            Trained model dict or None if not cached
        """
        cache_path = self.get_table_cache_path(database, table_name)
        
        if not cache_path.exists():
            return None
        
        try:
            with open(cache_path, 'rb') as f:
                model = pickle.load(f)
            logger.info(f"Loaded cached model from {cache_path}")
            return model
        except Exception as e:
            logger.error(f"Failed to load cached model from {cache_path}: {e}")
            return None
    
    def save_table_model(self, database: str, table_name: str, trained_model: Dict[str, Any]) -> bool:
        """
        Save trained model for a table to cache
        
        Args:
            database: Database name
            table_name: Table name
            trained_model: Trained model dict
        
        Returns:
            bool: True if saved successfully
        """
        cache_path = self.get_table_cache_path(database, table_name)
        
        try:
            with open(cache_path, 'wb') as f:
                pickle.dump(trained_model, f)
            logger.info(f"Cached model saved to {cache_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to save cache to {cache_path}: {e}")
            return False
    
    def get_cached_tables(self, database: str) -> list:
        """
        Get list of all tables that have cached models for this database
        
        Args:
            database: Database name
        
        Returns:
            List of table names that are cached
        """
        db_dir = self.cache_dir / database.upper()
        
        if not db_dir.exists():
            return []
        
        cached_tables = [
            f.stem  # Remove .pkl extension
            for f in db_dir.glob('*.pkl')
        ]
        
        logger.info(f"Found {len(cached_tables)} cached models for {database}")
        return cached_tables
    
    def clear_database_cache(self, database: str) -> bool:
        """
        Delete all cached models for a database
        
        Args:
            database: Database name
        
        Returns:
            bool: True if cleared successfully
        """
        db_dir = self.cache_dir / database.upper()
        
        if not db_dir.exists():
            return True
        
        try:
            import shutil
            shutil.rmtree(db_dir)
            logger.info(f"Cleared cache for database: {database}")
            return True
        except Exception as e:
            logger.error(f"Failed to clear cache for {database}: {e}")
            return False
