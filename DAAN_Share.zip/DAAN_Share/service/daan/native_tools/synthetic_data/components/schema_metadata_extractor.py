"""Metadata extraction and processing module.

This module reads schema information from CSV files and builds the JSON
catalog used by the rest of the components. For each table it captures:

- table name
- column names
- data types (inferred from pandas dtypes)
- nullability
- primary key detection (heuristic: unique *_ID column or first fully-unique column)
- limited sample values per column (from first 10 rows of the CSV)

It also performs lightweight PII detection based on column names.
"""
import json
import logging
import os
import re
import pandas as pd
from typing import Dict, List, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

# Map pandas dtype kinds to simplified SQL-style type names used downstream
_DTYPE_MAP = {
    "i": "NUMBER",
    "u": "NUMBER",
    "f": "FLOAT",
    "b": "BOOLEAN",
    "M": "TIMESTAMP",
    "m": "TEXT",
    "O": "TEXT",
    "S": "TEXT",
    "U": "TEXT",
}


def _pandas_dtype_to_sql(dtype) -> str:
    return _DTYPE_MAP.get(dtype.kind, "TEXT")


class SchemaMetadataExtractor:
    """Extract and process database schema metadata from CSV files."""

    def __init__(self, csv_dir: str):
        """
        Initialize metadata extractor.

        Args:
            csv_dir: Path to directory containing input CSV files.
                     Every .csv file except ``requirements.csv`` is treated
                     as a data table.  The table name is derived from the
                     filename (without extension, uppercased).
        """
        self.csv_dir = csv_dir
        self.tables_metadata: Dict[str, Any] = {}
        self.relationships: Dict[str, List[Dict[str, Any]]] = {}
        # Populated during extract_all_metadata so MLPatternLearner can reuse
        # the DataFrames without re-reading the CSVs.
        self.dataframes: Dict[str, pd.DataFrame] = {}

        # PII detection patterns based on column names (lightweight, name-based only)
        self.pii_patterns = {
            "email": re.compile(r"email", re.IGNORECASE),
            "phone": re.compile(r"phone|mobile|contact", re.IGNORECASE),
            "name": re.compile(r"name", re.IGNORECASE),
            "address": re.compile(r"address|addr", re.IGNORECASE),
            "ssn": re.compile(r"ssn|social_security", re.IGNORECASE),
            "dob": re.compile(r"dob|birthdate|date_of_birth", re.IGNORECASE),
        }

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def extract_all_metadata(self, selected_tables: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Load all input CSVs from csv_dir and build the metadata catalog.

        Args:
            selected_tables: Optional list of table names (without .csv) to
                             process.  If None, all CSVs except requirements.csv
                             are processed.

        Returns:
            Dictionary containing all schema metadata (same structure as the
            original Snowflake-based extractor so downstream components are
            unchanged).
        """
        try:
            print("\n📊 Extracting schema metadata from CSV files...")

            # Discover CSV files — exclude the row-count mapping file
            all_csv_files = [
                f for f in os.listdir(self.csv_dir)
                if f.lower().endswith(".csv") and f.lower() != "requirements.csv"
            ]

            if not all_csv_files:
                print("❌ No data CSV files found in input directory")
                return {}

            # Derive table names from filenames (uppercase, no extension)
            available_tables = {
                os.path.splitext(f)[0].upper(): f for f in all_csv_files
            }

            # Filter to selected subset
            if selected_tables:
                selected_set = set(t.upper() for t in selected_tables)
                available_tables = {k: v for k, v in available_tables.items() if k in selected_set}

            if not available_tables:
                found = list({os.path.splitext(f)[0].upper() for f in all_csv_files})
                wanted = [t.upper() for t in (selected_tables or [])]
                print(f"❌ No matching tables found. Wanted: {wanted}. Found CSVs: {found}")
                return {}

            print(f"✓ Found {len(available_tables)} table(s): {list(available_tables.keys())}")

            # Load each CSV and extract metadata
            for table_name, filename in available_tables.items():
                csv_path = os.path.join(self.csv_dir, filename)
                print(f"  * Processing {table_name}...")
                try:
                    df = pd.read_csv(csv_path)
                    self.dataframes[table_name] = df
                    self.tables_metadata[table_name] = self._extract_table_metadata_from_df(table_name, df)
                except Exception as e:
                    logger.error(f"Failed to load {csv_path}: {e}")
                    print(f"  ⚠ Skipping {table_name}: {e}")
            
            # Extract relationships
            print("\n🔗 Extracting relationships...")
            self.relationships = self._extract_relationships()
            
            logger.info(f"Successfully extracted metadata for {len(self.tables_metadata)} tables")
            return self._build_metadata_json()
            
        except Exception as e:
            logger.error(f"Metadata extraction failed: {str(e)}")
            print(f"❌ Error: {str(e)}")
            return {}
    
    def _extract_table_metadata_from_df(self, table_name: str, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Build metadata dict for a single table from a pandas DataFrame.

        Args:
            table_name: Uppercase table name (derived from CSV filename)
            df: DataFrame loaded from the input CSV

        Returns:
            Metadata dict compatible with the original Snowflake-based structure.
        """
        try:
            row_count = len(df)

            # --- Primary key heuristic ---
            # 1. Any column whose name ends with _ID and has all unique non-null values
            # 2. Fallback: first column that is entirely unique
            pk_columns: List[str] = []
            col_names = df.columns.tolist()

            for col in col_names:
                col_up = col.upper()
                if (col_up.endswith("_ID") or col_up == "ID") and df[col].nunique() == row_count:
                    pk_columns = [col]
                    break

            if not pk_columns and col_names:
                if df[col_names[0]].nunique() == row_count:
                    pk_columns = [col_names[0]]

            # --- Max PK values ---
            max_pk_values: Dict[str, Any] = {}
            for pk_col in pk_columns:
                try:
                    val = df[pk_col].max()
                    if val is not None and str(val) != "nan":
                        max_pk_values[pk_col] = val
                except Exception:
                    pass

            # --- Build columns metadata ---
            columns_metadata: List[Dict[str, Any]] = []
            for ordinal, col in enumerate(col_names, 1):
                dtype = df[col].dtype
                sql_type = _pandas_dtype_to_sql(dtype)
                nullable = bool(df[col].isna().any())
                is_pk = col in pk_columns

                # Sample values — first 10 non-null unique items
                try:
                    sample_vals = df[col].dropna().unique()[:10].tolist()
                    sample_vals = [str(v) if not isinstance(v, (int, float, bool)) else v for v in sample_vals]
                except Exception:
                    sample_vals = []

                col_info: Dict[str, Any] = {
                    "name": col,
                    "data_type": sql_type,
                    "max_length": None,
                    "nullable": nullable,
                    "ordinal_position": ordinal,
                    "is_primary_key": is_pk,
                    "is_foreign_key": False,  # filled in by _infer_implicit_foreign_keys
                    "column_comment": None,
                    "sample_values": sample_vals,
                }

                pii = self._detect_pii(col, sql_type)
                if pii:
                    col_info["pii_category"] = pii

                columns_metadata.append(col_info)

            return {
                "table_name": table_name,
                "table_comment": None,
                "row_count": row_count,
                "row_count_millions": round(row_count / 1_000_000, 2) if row_count >= 1_000_000 else None,
                "columns": columns_metadata,
                "column_count": len(col_names),
                "primary_keys": pk_columns,
                "max_pk_values": max_pk_values,
                "foreign_keys": [],  # no DB constraints; heuristic FKs added later
                "extracted_at": datetime.now().isoformat(),
            }

        except Exception as e:
            logger.error(f"Error extracting metadata for {table_name}: {e}")
            print(f"⚠  Warning: Could not extract metadata for {table_name}: {e}")
            return {}

    def _detect_pii(self, column_name: str, data_type: str) -> Optional[str]:
        """Detect potential PII based on column name and data type.

        This is intentionally conservative and name-based only so that it
        remains fast and does not inspect actual data values.
        """
        col_lower = column_name.lower()

        for pii_type, pattern in self.pii_patterns.items():
            if pattern.search(col_lower):
                return pii_type

        return None

    def _infer_implicit_foreign_keys(self):
        """Detect implicit FK relationships by matching *_ID columns against
        primary keys of other tables.

        Many databases (especially Snowflake) do not enforce FK constraints,
        so the schema introspection returns no FK metadata even though logical
        relationships exist.  This method fills that gap by:

        1. Building a PK lookup: table_name -> PK column name(s)
        2. For every non-PK column whose name ends with ``_ID``, checking
           whether it matches a PK in another table (direct match or
           pluralized table name match, e.g. CUSTOMER_ID -> CUSTOMERS.CUSTOMER_ID).
        3. Marking the column as ``is_foreign_key = True`` and attaching the
           inferred reference with ``ai_detected = True`` so downstream code
           can distinguish schema-declared vs. heuristic FKs.
        """

        # Step 1: Build PK lookup  {"CUSTOMERS": ["CUSTOMER_ID"], ...}
        pk_lookup: Dict[str, List[str]] = {}
        for table, meta in self.tables_metadata.items():
            pk_cols = meta.get('primary_keys', [])
            if pk_cols:
                pk_lookup[table.upper()] = [c.upper() for c in pk_cols]

        if not pk_lookup:
            return  # Nothing to match against

        inferred_count = 0

        for table, meta in self.tables_metadata.items():
            table_upper = table.upper()
            for col_info in meta.get('columns', []):
                col_name = col_info['name'].upper()

                # Skip columns already flagged as PK or FK
                if col_info.get('is_primary_key') or col_info.get('is_foreign_key'):
                    continue

                # Only consider columns that look like IDs
                if not col_name.endswith('_ID'):
                    continue

                # Derive candidate parent table names from the column name.
                # CUSTOMER_ID -> try CUSTOMER, CUSTOMERS
                base_name = col_name[:-3]  # strip "_ID"
                if not base_name:
                    continue

                candidates = [
                    base_name,                     # CUSTOMER
                    base_name + 'S',               # CUSTOMERS
                    base_name + 'ES',              # e.g. ADDRESSES
                    base_name.rstrip('S'),         # if already plural
                ]
                # De-duplicate while preserving order
                seen = set()
                unique_candidates = []
                for c in candidates:
                    if c not in seen and c != table_upper:
                        seen.add(c)
                        unique_candidates.append(c)

                for candidate_table in unique_candidates:
                    if candidate_table in pk_lookup:
                        parent_pks = pk_lookup[candidate_table]
                        # Try to match the FK column name to one of the parent PKs
                        matched_pk = None
                        if col_name in parent_pks:
                            matched_pk = col_name
                        elif len(parent_pks) == 1:
                            # If the parent table has a single PK, map to it
                            matched_pk = parent_pks[0]

                        if matched_pk:
                            col_info['is_foreign_key'] = True
                            col_info['foreign_key_references'] = [{
                                'referenced_table': candidate_table,
                                'referenced_column': matched_pk,
                                'constraint_name': f'INFERRED_{table_upper}_{col_name}',
                                'ai_detected': True,
                            }]
                            inferred_count += 1
                            logger.info(
                                f"Inferred FK: {table}.{col_name} -> "
                                f"{candidate_table}.{matched_pk}"
                            )
                            print(f"  🔗 Inferred FK: {table}.{col_name} -> {candidate_table}.{matched_pk}")
                            break  # First match wins

        if inferred_count:
            print(f"  ✓ Inferred {inferred_count} implicit foreign key(s)")
        else:
            logger.debug("No implicit foreign keys inferred")

    def _extract_relationships(self) -> Dict[str, List[Dict[str, Any]]]:
        """
        Extract all FK relationships between tables.
        Also infers implicit FKs by column-name matching when no explicit
        constraints exist in the database.
        
        Returns:
            Dictionary of relationships
        """
        # --- Infer implicit FKs BEFORE building the relationship map ---
        self._infer_implicit_foreign_keys()

        relationships = {}
        
        for table, metadata in self.tables_metadata.items():
            fk_list = metadata.get('foreign_keys', [])

            # Also collect inferred FKs from column metadata
            for col_info in metadata.get('columns', []):
                if col_info.get('is_foreign_key') and col_info.get('foreign_key_references'):
                    for ref in col_info['foreign_key_references']:
                        # Avoid duplicating explicit FK entries
                        already_present = any(
                            (fk.get('FK_COLUMN_NAME', '').upper() == col_info['name'].upper() or
                             fk.get('COLUMN_NAME', '').upper() == col_info['name'].upper())
                            for fk in fk_list
                        )
                        if not already_present:
                            fk_list.append({
                                'FK_COLUMN_NAME': col_info['name'],
                                'REFERENCED_TABLE_NAME': ref['referenced_table'],
                                'REFERENCED_COLUMN_NAME': ref['referenced_column'],
                                'CONSTRAINT_NAME': ref.get('constraint_name', 'INFERRED'),
                            })

            if fk_list:
                relationships[table] = fk_list
                # Extract FK constraint names
                constraint_names = []
                for fk in fk_list:
                    # Try different possible constraint name keys
                    constraint_name = (
                        fk.get('constraint_name') or 
                        fk.get('CONSTRAINT_NAME') or 
                        fk.get('name') or 
                        'UNKNOWN'
                    )
                    if constraint_name not in constraint_names:
                        constraint_names.append(constraint_name)
                
                fk_names_str = ", ".join(constraint_names)
                logger.info(f"Table {table} has {len(fk_list)} foreign key(s): {fk_names_str}")
        
        return relationships
    
    def _build_metadata_json(self) -> Dict[str, Any]:
        """
        Build complete metadata JSON template
        
        Returns:
            Complete metadata structure
        """
        return {
            'extraction_timestamp': datetime.now().isoformat(),
            'database': 'csv_input',
            'schema': 'default',
            'total_tables': len(self.tables_metadata),
            'tables': self.tables_metadata,
            'referential_integrity': {
                'relationships': self.relationships,
                'dependency_graph': self._build_dependency_graph()
            }
        }
    
    def _build_dependency_graph(self) -> Dict[str, List[str]]:
        """
        Build dependency graph showing parent-child table relationships
        
        Returns:
            Dictionary mapping tables to their dependencies
        """
        dependency_graph = {}
        
        for table, relationships in self.relationships.items():
            dependencies = []
            for rel in relationships:
                parent_table = (
                    rel.get('REFERENCED_TABLE') or
                    rel.get('REFERENCED_TABLE_NAME') or
                    rel.get('referenced_table')
                )
                # Skip self-referential dependencies (e.g., EMPLOYEES -> EMPLOYEES)
                if parent_table and parent_table.upper() != table.upper() and parent_table not in dependencies:
                    dependencies.append(parent_table)
            
            if dependencies:
                dependency_graph[table] = dependencies
        
        return dependency_graph
    
    def save_metadata_to_json(self, metadata: Dict[str, Any], output_path: str) -> bool:
        """
        Save metadata to JSON file
        
        Args:
            metadata: Metadata dictionary
            output_path: Path to save JSON file
        
        Returns:
            bool: True if successful
        """
        try:
            with open(output_path, 'w') as f:
                json.dump(metadata, f, indent=2, default=str)
            logger.info(f"Metadata saved to {output_path}")
            print(f"✓ Metadata saved to {output_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to save metadata: {str(e)}")
            print(f"❌ Error saving metadata: {str(e)}")
            return False
    
    def load_metadata_from_json(self, json_path: str) -> Dict[str, Any]:
        """
        Load metadata from JSON file
        
        Args:
            json_path: Path to JSON file
        
        Returns:
            Metadata dictionary
        """
        try:
            with open(json_path, 'r') as f:
                metadata = json.load(f)
            logger.info(f"Metadata loaded from {json_path}")
            return metadata
        except Exception as e:
            logger.error(f"Failed to load metadata: {str(e)}")
            print(f"❌ Error loading metadata: {str(e)}")
            return {}
