"""
Planner Agent - Plans data generation strategy based on schema
"""
import logging
import json
import os
from pathlib import Path
from typing import Dict, List, Any, Tuple, Optional

from daan.native_tools.synthetic_data.utils.llm_client import AzureOpenAIClient

logger = logging.getLogger(__name__)


class GenerationPlanner:
    """
    Analyze schema and create data generation plan
    """
    
    def __init__(self, metadata: Dict[str, Any]):
        """
        Initialize Planner Agent
        
        Args:
            metadata: Schema metadata from MetadataExtractor
        """
        self.metadata = metadata
        self.generation_plan = {}
        self.execution_order = []
        self.dependency_graph = metadata.get('referential_integrity', {}).get('dependency_graph', {})
        
        # Initialize LLM for intelligent FK detection
        try:
            import os
            # Check environment variables before attempting initialization
            api_key = os.getenv('AZURE_OPENAI_API_KEY')
            api_base = os.getenv('AZURE_OPENAI_API_BASE') or os.getenv('AZURE_ENDPOINT')
            api_version = os.getenv('AZURE_OPENAI_API_VERSION')
            deployment = os.getenv('AZURE_OPENAI_DEPLOYMENT')
            
            if not api_key or not api_base or not api_version:
                missing = []
                if not api_key:
                    missing.append('AZURE_OPENAI_API_KEY')
                if not api_base:
                    missing.append('AZURE_OPENAI_API_BASE/AZURE_ENDPOINT')
                if not api_version:
                    missing.append('AZURE_OPENAI_API_VERSION')
                logger.warning(f"Missing environment variables: {', '.join(missing)}")
                self.llm_client = None
            else:
                self.llm_client: Optional[AzureOpenAIClient] = AzureOpenAIClient()
                logger.info("[OK] LLM client initialized for intelligent FK detection")
                print("[AI] LLM-powered intelligent FK detection enabled")
        except Exception as e:
            logger.warning(f"LLM client not available: {e}. FK detection will use metadata only.")
            print("[!] LLM not available - FK detection will use metadata only")
            self.llm_client = None
    
    def create_generation_plan(self, selected_tables: List[str], row_counts: Dict[str, int]) -> Dict[str, Any]:
        """
        Create comprehensive data generation plan
        
        Args:
            selected_tables: List of tables to generate
            row_counts: Dictionary mapping table names to row counts
        
        Returns:
            Generation plan dictionary
        """
        try:
            print("\n[PLAN] Creating generation plan...")
            
            # Determine execution order (handle dependencies)
            self.execution_order = self._determine_execution_order(selected_tables)
            print(f"[OK] Execution order determined: {len(self.execution_order)} tables")
            
            # Create plan for each table
            for table in self.execution_order:
                if table in selected_tables:
                    self.generation_plan[table] = self._create_table_plan(
                        table, 
                        row_counts.get(table, 1000)
                    )
            
            logger.info(f"Generation plan created for {len(self.generation_plan)} tables")
            
            # Re-determine execution order AFTER FK detection
            # (dependency_graph from metadata may be empty for implicit FKs)
            # Scan column-level FK references since implicit FKs are stored there
            detected_dep_graph = {}
            for table_name, plan in self.generation_plan.items():
                parents = []
                for col_plan in plan.get('columns', []):
                    if col_plan.get('is_foreign_key'):
                        for fk_ref in col_plan.get('foreign_key_references', []):
                            ref_table = fk_ref.get('referenced_table', '')
                            if ref_table and ref_table in self.generation_plan and ref_table != table_name:
                                parents.append(ref_table)
                if parents:
                    detected_dep_graph[table_name] = list(set(parents))
            
            if detected_dep_graph:
                # Update dependency graph with detected FKs
                self.dependency_graph = detected_dep_graph
                old_order = list(self.execution_order)
                self.execution_order = self._determine_execution_order(selected_tables)
                if old_order != self.execution_order:
                    print(f"[OK] Execution order re-sorted based on detected FKs")
                    logger.info(f"Execution order updated: {self.execution_order}")
            
            # Print FK detection summary
            self._print_fk_detection_summary(self.generation_plan)
            
            return {
                'execution_order': self.execution_order,
                'table_plans': self.generation_plan,
                'total_tables': len(self.generation_plan),
                'total_rows': sum([plan['row_count'] for plan in self.generation_plan.values()])
            }
        
        except Exception as e:
            logger.error(f"Failed to create generation plan: {str(e)}")
            print(f"[ERROR] Error: {str(e)}")
            return {}
    
    def _determine_execution_order(self, selected_tables: List[str]) -> List[str]:
        """
        Determine execution order based on FK dependencies
        (Parent tables before child tables)
        
        Args:
            selected_tables: List of selected tables
        
        Returns:
            Sorted list of tables
        """
        execution_order = []
        processed = set()
        visiting = set()
        
        def process_table(table):
            # Prevent infinite recursion on cycles
            if table in processed or table in visiting:
                return
            
            visiting.add(table)
            
            # Process dependencies first (parent tables)
            dependencies = self.dependency_graph.get(table, [])
            for parent in dependencies:
                if parent in selected_tables:
                    process_table(parent)
            
            if table in selected_tables and table not in processed:
                execution_order.append(table)
                processed.add(table)
            
            visiting.remove(table)
        
        for table in selected_tables:
            process_table(table)
        
        return execution_order
    
    def _create_table_plan(self, table_name: str, row_count: int) -> Dict[str, Any]:
        """
        Create detailed generation plan for a single table
        
        Args:
            table_name: Name of the table
            row_count: Number of rows to generate
        
        Returns:
            Table generation plan
        """
        tables = self.metadata.get('tables', {})
        table_meta = tables.get(table_name, {})
        columns = table_meta.get('columns', [])
        fk_relationships = table_meta.get('foreign_keys', [])
        
        # Get the ORIGINAL row count from the source table metadata
        # This is critical for detecting dimension tables correctly
        original_row_count = table_meta.get('row_count', row_count)
        
        # Get max PK values from real data (so synthetic continues where real data stopped)
        max_pk_values = table_meta.get('max_pk_values', {})
        
        column_plans: List[Dict[str, Any]] = []
        for col in columns:
            col_plan = self._create_column_plan(col, fk_relationships, table_name)
            # Attach max PK value to PK columns
            if col_plan.get('is_primary_key') and col_plan['column_name'] in max_pk_values:
                col_plan['max_real_pk_value'] = max_pk_values[col_plan['column_name']]
            column_plans.append(col_plan)
        
        return {
            'table_name': table_name,
            'table_comment': table_meta.get('table_comment'),
            'row_count': row_count,
            'original_row_count': original_row_count,  # Add source table row count for dimension detection
            'columns': column_plans,
            'has_fk': len(fk_relationships) > 0,
            'foreign_keys': fk_relationships
        }
    
    def _create_column_plan(self, column: Dict[str, Any], fk_relationships: List[Dict], table_name: str = '') -> Dict[str, Any]:
        """
        Create generation strategy for a column
        
        Args:
            column: Column metadata
            fk_relationships: Foreign key relationships
            table_name: Name of the table (for PK detection heuristic)
        
        Returns:
            Column generation plan
        """
        col_name = column['name']
        data_type = column['data_type'].upper()
        nullable = column['nullable']
        max_length = column['max_length']
        is_pk = column['is_primary_key']
        
        # VALIDATION: If schema says this is a PK but the column name doesn't match
        # standard PK naming patterns (e.g., FEE_PAID falsely marked as PK), un-mark it.
        # Snowflake heuristic PK detection can produce false positives for high-cardinality numeric columns.
        if is_pk:
            col_name_lower = col_name.lower()
            has_pk_name = (col_name_lower.endswith('_key') or col_name_lower.endswith('key') or
                          col_name_lower.endswith('_id') or col_name_lower.endswith('id') or
                          col_name_lower.endswith('_pk') or col_name_lower.endswith('_no') or
                          col_name_lower.endswith('_code') or col_name_lower == 'id')
            if not has_pk_name:
                logger.info(f"[OVERRIDE] {col_name} was marked as PK by schema but name doesn't match PK patterns - removing PK flag")
                print(f"  [OVERRIDE] {col_name} un-marked as PK (name doesn't match PK patterns)")
                is_pk = False
        
        # Extract column metadata early (needed for multiple checks)
        pii_category = column.get('pii_category')
        column_comment = column.get('column_comment')
        sample_values = column.get('sample_values', [])
        fk_references = column.get('foreign_key_references', [])
        
        # PK DETECTION: Use heuristic naming patterns only (no LLM)
        # LLM is only used for FK detection and script generation
        # CRITICAL: Only mark as PK if column name matches STANDARD PK naming patterns
        # but NOT if it looks like a FK (e.g., O_CUSTKEY is FK, not PK)
        # Support both numeric types AND text types (TEXT IDs like ACC123456)
        pk_eligible_types = ['NUMBER', 'INT', 'INTEGER', 'BIGINT', 'TEXT', 'VARCHAR', 'STRING']
        if not is_pk and data_type in pk_eligible_types:
            col_name_lower = col_name.lower()
            
            # Standard PK naming patterns (generic, works for any schema):
            # 1. Ends with _KEY, _ID, _PK suffix
            # 2. OR contains table name + KEY/ID (e.g., CUSTOMER_KEY, USER_ID)
            # 3. NOT a FK candidate (avoid marking columns like ORDER_ID in CUSTOMER table as PK)
            
            is_standard_pk_pattern = (col_name_lower.endswith('_key') or 
                                     col_name_lower.endswith('key') or
                                     col_name_lower.endswith('_id') or 
                                     col_name_lower.endswith('_pk'))
            
            # BUT: Don't mark as PK if it's clearly a FK
            # FK indicators: column references OTHER table (e.g., CUST in ORDERS, SUPP in PART)
            # Check if column name contains a reference to another table
            # Use more precise matching: the column name prefix (before _ID/_KEY) should match the OTHER table name
            is_likely_fk = False
            # Extract the entity name from the column (e.g., STUDENT_ID -> STUDENT, DEPT_ID -> DEPT)
            col_entity = col_name_lower.replace('_id', '').replace('_key', '').replace('_pk', '').replace('_no', '').strip('_')
            
            for other_table in self.metadata.get('tables', {}).keys():
                if other_table.lower() != table_name.lower():  # Different table
                    other_lower = other_table.lower()
                    # Precise match: the extracted entity must meaningfully match the other table
                    # e.g., 'dept' matches 'department', 'student' matches 'student'
                    if (col_entity == other_lower or 
                        other_lower.startswith(col_entity) or 
                        col_entity.startswith(other_lower)):
                        is_likely_fk = True
                        break
            
            # For TEXT columns: additional PK check - must be ordinal position 1 (first column)
            # This prevents marking DEPT_ID in STUDENT table as PK
            is_first_column = column.get('ordinal_position', 0) == 1
            
            looks_like_pk = is_standard_pk_pattern and not is_likely_fk
            
            # For TEXT type: require first column position for stronger PK signal
            if data_type in ['TEXT', 'VARCHAR', 'STRING']:
                looks_like_pk = looks_like_pk and is_first_column
            
            if looks_like_pk:
                is_pk = True
                logger.info(f"[HEURISTIC] {col_name} identified as primary key (standard naming pattern)")
                print(f"  [HEURISTIC] {col_name} identified as PRIMARY KEY")

        # Prefer extractor-provided FK flag, fall back to relationship scan
        is_fk = column.get('is_foreign_key')
        if is_fk is None:
            is_fk = any(fk['COLUMN_NAME'] == col_name for fk in fk_relationships)
        
        # INTELLIGENT FK DETECTION: Use LLM to detect FK relationships
        # Run intelligent detection in all cases to find implicit FKs
        # (especially important for different naming conventions like c_custkey vs O_custkey)
        if is_fk and fk_references:
            for fk_ref in fk_references:
                if not fk_ref.get('referenced_table') or not fk_ref.get('referenced_column'):
                    # FK metadata incomplete - use LLM intelligence
                    logger.info(f"[AI] Using LLM to intelligently detect FK relationship for {col_name}")
                    print(f"  [AI] Detecting FK relationship for {col_name}...")
                    detected_fk = self._detect_fk_with_llm(col_name, data_type, sample_values)
                    if detected_fk:
                        fk_ref['referenced_table'] = detected_fk['referenced_table']
                        fk_ref['referenced_column'] = detected_fk['referenced_column']
                        fk_ref['ai_detected'] = True
                        logger.info(f"[OK] LLM detected: {col_name} -> {detected_fk['referenced_table']}.{detected_fk['referenced_column']}")
                        print(f"  [OK] {col_name} -> {detected_fk['referenced_table']}.{detected_fk['referenced_column']}")
        
        # IMPLICIT FK DETECTION: Columns that look like foreign keys but aren't marked as such
        # Use LLM to intelligently detect if this could be a FK (important for non-standard naming)
        # BUT: Skip for primary keys - they should never be treated as FKs
        col_name_lower = col_name.lower()
        # Use underscore-separated suffixes to avoid false positives (e.g., "FEE_PAID" matching "id")
        looks_like_fk = (col_name_lower.endswith('_key') or col_name_lower.endswith('_id') or 
                        col_name_lower.endswith('_no') or col_name_lower.endswith('_pk') or
                        col_name_lower.endswith('_code') or col_name_lower == 'id')
        
        if not is_fk and not is_pk and looks_like_fk:
            logger.info(f"[AI] Checking if {col_name} is an implicit foreign key...")
            print(f"  [AI] Checking implicit FK: {col_name}...")
            implicit_fk = self._detect_implicit_fk_with_llm(col_name, data_type, sample_values, table_name)
            if implicit_fk:
                is_fk = True
                # Mark this as AI-detected and implicit
                implicit_fk['ai_detected'] = True
                implicit_fk['is_implicit'] = True
                fk_references = [implicit_fk]
                logger.info(f"[OK] LLM detected implicit FK: {col_name} -> {implicit_fk['referenced_table']}.{implicit_fk['referenced_column']}")
                print(f"  [OK-AI] Detected FK: {col_name} -> {implicit_fk['referenced_table']}.{implicit_fk['referenced_column']}")
            else:
                logger.info(f"[INFO] {col_name} is not an implicit FK (LLM analysis)")
                print(f"  [SKIP] {col_name} is not a FK")

        plan = {
            'column_name': col_name,
            'data_type': data_type,
            'nullable': nullable,
            'max_length': max_length,
            'is_primary_key': is_pk,
            'is_foreign_key': is_fk,
            'pii_category': pii_category,
            'column_comment': column_comment,
            'sample_values': sample_values,
            'foreign_key_references': fk_references,  # Include FK references in plan
            'generation_strategy': self._determine_generation_strategy(
                column_name=col_name,
                data_type=data_type,
                max_length=max_length,
                is_pk=is_pk,
                is_fk=is_fk,
                pii_category=pii_category,
                sample_values=sample_values,
            ),
        }
        
        # For primary keys, detect increment pattern from sample values
        if is_pk and sample_values:
            pattern = self._detect_increment_pattern(col_name, sample_values)
            if pattern:
                plan['increment_pattern'] = pattern
                logger.info(f"[PATTERN] {col_name}: {pattern}")
                print(f"  [PATTERN] {col_name}: Detected increment pattern - start={pattern['start']}, step={pattern['step']}")
        
        return plan

    def _detect_fk_with_llm(self, column_name: str, data_type: str, sample_values: List[Any]) -> Optional[Dict[str, str]]:
        """
        🧠 Use LLM to intelligently detect foreign key relationships
        from column naming patterns and available tables in schema.
        Handles different naming conventions (e.g., c_custkey vs O_custkey).
        
        Args:
            column_name: Name of the FK column
            data_type: Data type of the column
            sample_values: Sample values from the column
        
        Returns:
            Dictionary with 'referenced_table' and 'referenced_column' or None
        """
        if not self.llm_client:
            logger.warning("LLM not available for FK detection")
            return None
        
        try:
            # Get available tables and their primary keys from metadata
            available_tables = self._build_available_tables_info()
            
            system_msg = {
                "role": "system",
                "content": (
                    "You are an expert database schema analyst. Your task is to identify foreign key relationships.\n"
                    "CRITICAL RULES:\n"
                    "1. Analyze column names semantically - extract the entity type from names\n"
                    "2. Handle naming variations:\n"
                    "   - Remove prefixes: c_custkey, C_CUSTKEY, CUST_KEY all mean CUSTOMER\n"
                    "   - Remove suffixes: custkey, cust_id, customer_no all reference CUSTOMER\n"
                    "   - Match core meaning: 'CUST' or 'CUSTOMER' both map to CUSTOMER table\n"
                    "3. Match numeric data types - FK columns are usually INT, BIGINT, NUMERIC\n"
                    "4. Verify with sample values when available\n"
                    "5. Return ONLY valid JSON with no markdown formatting\n\n"
                    "Return format: {\"referenced_table\": \"TABLE_NAME\", \"referenced_column\": \"COLUMN_NAME\", \"confidence\": \"high|medium|low\"}\n"
                    "Or: {\"error\": \"reason\"} if no match found.\n"
                    "DO NOT return markdown, code blocks, or explanations - just JSON."
                )
            }
            
            user_msg = {
                "role": "user",
                "content": (
                    f"Find the foreign key reference for this column:\n\n"
                    f"Column: {column_name}\n"
                    f"Type: {data_type}\n"
                    f"Sample values: {sample_values[:10] if sample_values else 'N/A'}\n\n"
                    f"Available tables and their primary keys:\n"
                    f"{json.dumps(available_tables, indent=2)}\n\n"
                    f"Which table does this column reference? Return ONLY the JSON response."
                )
            }
            
            response = self.llm_client.chat_completion([system_msg, user_msg], temperature=0.1, max_tokens=300)
            
            logger.debug(f"LLM raw response for {column_name}: {response[:200]}")
            
            if not response or not response.strip():
                logger.warning(f"LLM returned empty response for {column_name}")
                return None
            
            response_clean = response.strip()
            if response_clean.startswith('```'):
                lines = response_clean.split('\n')
                response_clean = '\n'.join(line for line in lines if not line.startswith('```'))
                response_clean = response_clean.strip()
            
            try:
                result = json.loads(response_clean)
            except json.JSONDecodeError as je:
                logger.error(f"LLM response is not valid JSON for {column_name}: {response[:100]}")
                return None
            
            if 'error' in result or 'referenced_table' not in result:
                logger.warning(f"LLM could not determine FK for {column_name}")
                return None
            
            ref_table = result['referenced_table'].upper()
            if ref_table not in [t.upper() for t in self.metadata.get('tables', {}).keys()]:
                logger.warning(f"LLM suggested non-existent table {ref_table} for {column_name}")
                return None
            
            actual_ref_table = next(
                (t for t in self.metadata.get('tables', {}).keys() if t.upper() == ref_table),
                ref_table
            )
            
            # VALIDATE: Referenced column must be the PK of the referenced table
            # e.g., STUDENT_ID -> ENROLLMENT.STUDENT_ID is WRONG because ENROLL_ID is ENROLLMENT's PK
            ref_col_upper = result['referenced_column'].upper()
            ref_table_meta = self.metadata.get('tables', {}).get(actual_ref_table, {})
            ref_table_pk_cols = [c['name'].upper() for c in ref_table_meta.get('columns', []) if c.get('is_primary_key')]
            if ref_table_pk_cols and ref_col_upper not in ref_table_pk_cols:
                logger.warning(f"[REJECT-FK] {column_name} -> {actual_ref_table}.{ref_col_upper} rejected: {ref_col_upper} is not a PK of {actual_ref_table} (PKs: {ref_table_pk_cols})")
                return None
            
            return {
                'referenced_table': actual_ref_table,
                'referenced_column': ref_col_upper,
                'confidence': result.get('confidence', 'medium')
            }
            
        except Exception as e:
            logger.error(f"LLM FK detection failed for {column_name}: {e}")
            return None
    
    def _detect_implicit_fk_with_llm(self, column_name: str, data_type: str, sample_values: List[Any], current_table: str = '') -> Optional[Dict[str, Any]]:
        """
        🧠 Use LLM to detect IMPLICIT foreign key relationships
        for columns that aren't explicitly marked as FKs but could be.
        Handles semantic matching across different naming conventions.
        
        Args:
            column_name: Name of the potential FK column
            data_type: Data type of the column
            sample_values: Sample values from the column
            current_table: Name of the current table (for self-ref validation)
        
        Returns:
            Dictionary with FK reference info or None
        """
        if not self.llm_client:
            return None
        
        try:
            available_tables = self._build_available_tables_enriched()
            
            system_msg = {
                "role": "system",
                "content": (
                    "You are a database expert specializing in schema analysis and FK detection.\n"
                    "Your task: Identify foreign key relationships by analyzing column names and data patterns.\n\n"
                    "CRITICAL DETECTION RULES:\n"
                    "1. COLUMN NAME ANALYSIS:\n"
                    "   - Extract entity abbreviations: C_*=CUSTOMER, O_*=ORDERS, P_*=PART, S_*=SUPPLIER, N_*=NATION\n"
                    "   - Suffix patterns: *KEY, *ID, *NO, *NUM all indicate possible FK\n"
                    "   - Example: O_CUSTKEY -> Extract 'CUST' -> Match to CUSTOMER table\n\n"
                    "2. SEMANTIC MATCHING (Most Important):\n"
                    "   - CUST/CUSTOMER -> CUSTOMER table\n"
                    "   - ORDER -> ORDERS table\n"
                    "   - PART -> PART table\n"
                    "   - SUPP -> SUPPLIER table\n"
                    "   - NATION -> NATION table\n"
                    "   - REGION -> REGION table\n\n"
                    "3. CROSS-TABLE COLUMN MATCHING:\n"
                    "   - Match by semantic meaning, NOT exact name\n"
                    "   - O_CUSTKEY (ORDERS) matches C_CUSTKEY (CUSTOMER) - both about customers!\n"
                    "   - P_PARTKEY matches PARTKEY\n"
                    "   - Look at available columns in each table and find the semantic match\n\n"
                    "4. DATA VALIDATION:\n"
                    "   - Numeric types (INT, BIGINT, NUMBER) are strong FK indicators\n"
                    "   - Sample values should be small integers (like 1-1000)\n"
                    "   - If sample values appear in target table's PK values, it's likely a FK\n\n"
                    "RETURN FORMAT: {\"is_fk\": true, \"referenced_table\": \"TABLE_NAME\", \"referenced_column\": \"COLUMN_NAME\"}\n"
                    "Or if not a FK: {\"is_fk\": false}\n"
                    "CRITICAL: Return ONLY valid JSON, no markdown, explanations, or code blocks!"
                )
            }
            
            user_msg = {
                "role": "user",
                "content": (
                    f"ANALYZE THIS COLUMN FOR FOREIGN KEY RELATIONSHIP:\n\n"
                    f"COLUMN TO CHECK:\n"
                    f"  Name: {column_name}\n"
                    f"  Type: {data_type}\n"
                    f"  Sample values: {sample_values[:20] if sample_values else 'N/A'}\n\n"
                    f"ALL TABLES IN THE SCHEMA:\n"
                    f"{json.dumps(available_tables, indent=2)}\n\n"
                    f"TASK:\n"
                    f"1. Does '{column_name}' look like a foreign key column?\n"
                    f"2. Extract semantic meaning from '{column_name}'\n"
                    f"3. Find the MATCHING table and column from the available tables above\n"
                    f"4. Return JSON with is_fk, referenced_table, and referenced_column\n\n"
                    f"EXAMPLE DETECTION:\n"
                    f"If column='O_CUSTKEY' with values [1,2,3,4]\n"
                    f"And CUSTOMER table has C_CUSTKEY with sample_pk_values [1,2,3,4]\n"
                    f"Then: O_CUSTKEY is FK to CUSTOMER.C_CUSTKEY\n\n"
                    f"Return ONLY the JSON response:"
                )
            }
            
            response = self.llm_client.chat_completion([system_msg, user_msg], temperature=0.1, max_tokens=300)
            
            response_clean = response.strip()
            if response_clean.startswith('```'):
                lines = response_clean.split('\n')
                response_clean = '\n'.join(line for line in lines if not line.startswith('```'))
                response_clean = response_clean.strip()
            
            logger.info(f"[LLM-RESPONSE] {column_name}: {response_clean[:200]}")
            
            result = json.loads(response_clean)
            
            if not result.get('is_fk'):
                logger.info(f"[LLM-NO-FK] {column_name} determined to NOT be a foreign key: {result}")
                return None
            
            ref_table = result.get('referenced_table', '').upper()
            ref_col = result.get('referenced_column', '')
            
            if not ref_table or not ref_col:
                return None
            
            # Validate table exists
            if ref_table not in [t.upper() for t in self.metadata.get('tables', {}).keys()]:
                return None
            
            # Find actual table name with correct casing
            actual_ref_table = next(
                (t for t in self.metadata.get('tables', {}).keys() if t.upper() == ref_table),
                ref_table
            )
            
            # VALIDATE SELF-REFERENTIAL FK: If LLM maps column to the SAME table,
            # verify the column entity semantically matches the table name.
            # e.g., STUDENT_ID in ENROLLMENT -> LLM says ref=ENROLLMENT (wrong! student != enrollment)
            # e.g., MANAGER_ID in EMPLOYEES -> LLM says ref=EMPLOYEES (correct! manager is an employee)
            if current_table and actual_ref_table.upper() == current_table.upper():
                col_entity = column_name.lower().replace('_id', '').replace('_key', '').replace('_pk', '').replace('_no', '').strip('_')
                table_lower = current_table.lower()
                # Self-ref is valid ONLY if column entity matches table name
                # e.g., employee/manager in EMPLOYEES, enrollment in ENROLLMENT
                is_valid_self_ref = (
                    col_entity == table_lower or
                    table_lower.startswith(col_entity) or
                    col_entity.startswith(table_lower) or
                    col_entity in ('manager', 'parent', 'supervisor', 'reports_to')  # Known self-ref patterns
                )
                if not is_valid_self_ref:
                    logger.info(f"[REJECT-SELF-REF] {column_name} -> {actual_ref_table} rejected: '{col_entity}' doesn't match '{table_lower}'")
                    print(f"  [REJECT] {column_name} is NOT a self-referential FK to {actual_ref_table} (entity mismatch)")
                    return None
            
            # VALIDATE: Referenced column must be the PK of the referenced table
            # e.g., STUDENT_ID -> ENROLLMENT.STUDENT_ID is WRONG because ENROLL_ID is ENROLLMENT's PK
            # The parent table for STUDENT_ID should be STUDENT, not ENROLLMENT
            ref_col_upper = ref_col.upper()
            ref_table_meta = self.metadata.get('tables', {}).get(actual_ref_table, {})
            ref_table_pk_cols = [c['name'].upper() for c in ref_table_meta.get('columns', []) if c.get('is_primary_key')]
            if ref_table_pk_cols and ref_col_upper not in ref_table_pk_cols:
                logger.info(f"[REJECT-FK] {column_name} -> {actual_ref_table}.{ref_col_upper} rejected: {ref_col_upper} is not PK of {actual_ref_table} (PKs: {ref_table_pk_cols})")
                print(f"  [REJECT] {column_name} -> {actual_ref_table}.{ref_col_upper}: referenced column is not a PK (parent table not in selected tables?)")
                return None
            
            return {
                'referenced_table': actual_ref_table,
                'referenced_column': ref_col_upper,
                'ai_detected': True,
                'is_implicit': True,
                'confidence': result.get('confidence', 'medium')  # Add confidence from LLM response
            }
            
        except Exception as e:
            logger.error(f"[ERROR] Implicit FK detection failed for {column_name}: {str(e)[:200]}", exc_info=True)
            return None
    
    def _detect_increment_pattern(self, column_name: str, sample_values: List[Any]) -> Optional[Dict[str, Any]]:
        """
        🧠 Use LLM to analyze sample values and detect increment patterns.
        For primary keys, identify the starting value and increment step size.
        
        This allows generating synthetic data that matches the PATTERN of the original,
        and handles DIMENSION TABLES vs FACT TABLES differently:
        
        **FACT TABLES** (large, scales):
        - Samples: [15001, 15002, 15003, ..., 15025] -> start=15001, step=1
        - For 1000 rows: Generate 15001, 15002, 15003, ..., 16000 (NOT repeating 15001-15025)
        
        **DIMENSION TABLES** (small, fixed cardinality, cycles):
        - Samples: [0, 1, 2, 3, 4] (5 unique values) -> start=0, step=1
        - For 1000 rows: Generate 0,1,2,3,4, 0,1,2,3,4, 0,1,2,3,4, ... (repeats to maintain cardinality)
        - Example: NATION table has 25 nations, should cycle through 1-25 even for 1000 rows
        
        Detection logic:
        - If unique values ≤ 100 AND sample count ≤ 100 -> DIMENSION TABLE (cycle)
        - Otherwise -> FACT TABLE (scale)
        
        Args:
            column_name: Name of the column
            sample_values: Sample values from the column
        
        Returns:
            Dictionary with 'start', 'step', 'pattern_type' or None if no pattern detected
        """
        if not self.llm_client or not sample_values or len(sample_values) < 2:
            return None
        
        try:
            # Convert sample values to numbers
            numeric_samples = []
            for val in sample_values[:20]:  # Use first 20 samples
                try:
                    numeric_samples.append(float(val) if val is not None else None)
                except (ValueError, TypeError):
                    pass
            
            # Need at least 2 valid numeric samples to detect pattern
            if len(numeric_samples) < 2:
                return None
            
            # FAST HEURISTIC: Try to detect pattern without LLM first
            # This is much faster and works for most common cases
            valid_nums = [v for v in numeric_samples if v is not None]
            
            if len(valid_nums) >= 2:
                start_val = valid_nums[0]
                
                # Calculate differences between consecutive values
                diffs = []
                for i in range(1, len(valid_nums)):
                    diff = valid_nums[i] - valid_nums[i-1]
                    if diff != 0:
                        diffs.append(diff)
                
                if diffs:
                    # Check if all differences are the same (sequential pattern)
                    if len(set(diffs)) == 1:
                        step_val = diffs[0]
                        logger.debug(f"[PATTERN-HEURISTIC] {column_name}: start={start_val}, step={step_val} (consistent)")
                        return {
                            'start': start_val,
                            'step': step_val,
                            'pattern_type': 'sequential',
                            'confidence': 'high',
                            'method': 'heuristic'
                        }
                    else:
                        # Differences are not consistent, use average
                        avg_step = sum(diffs) / len(diffs)
                        logger.debug(f"[PATTERN-HEURISTIC] {column_name}: start={start_val}, step~{avg_step} (sparse)")
                        return {
                            'start': start_val,
                            'step': avg_step,
                            'pattern_type': 'sparse',
                            'confidence': 'medium',
                            'method': 'heuristic'
                        }
                elif len(valid_nums) >= 2 and valid_nums[0] == valid_nums[1]:
                    # All values are the same
                    logger.debug(f"[PATTERN-HEURISTIC] {column_name}: constant value {start_val}")
                    return {
                        'start': start_val,
                        'step': 0,
                        'pattern_type': 'constant',
                        'confidence': 'high',
                        'method': 'heuristic'
                    }
            
            # Heuristic didn't work well - don't use LLM for pattern detection
            # LLM is only used for FK detection and script generation
            logger.debug(f"[PATTERN] Heuristic analysis inconclusive for {column_name} - skipping pattern detection")
            return None
            
        except Exception as e:
            logger.warning(f"[WARNING] Pattern detection failed for {column_name}: {str(e)[:200]}")
            return None
    
    def _build_available_tables_enriched(self) -> Dict[str, Any]:
        """
        Build COMPREHENSIVE schema info for LLM FK detection.
        Includes table names, PK columns, ALL columns, sample values, and data types.
        
        Returns:
            Dictionary with enriched table information (JSON-serializable)
        """
        from decimal import Decimal
        from datetime import date, datetime, time
        
        def make_json_serializable(val):
            """Convert non-JSON-serializable types to JSON-serializable equivalents"""
            if val is None:
                return None
            elif isinstance(val, bool):  # Must check bool before int (bool is subclass of int)
                return val
            elif isinstance(val, (int, float, str)):
                return val
            elif isinstance(val, Decimal):
                return float(val)
            elif isinstance(val, (datetime, date)):
                return val.isoformat()
            elif isinstance(val, time):
                return val.isoformat()
            elif isinstance(val, (list, tuple)):
                return [make_json_serializable(v) for v in val]
            elif isinstance(val, dict):
                return {k: make_json_serializable(v) for k, v in val.items()}
            else:
                # For other types, convert to string
                return str(val)
        
        available_tables = {}
        tables = self.metadata.get('tables', {})
        
        for table_name, table_info in tables.items():
            pk_cols = table_info.get('primary_keys', [])
            
            available_tables[table_name] = {
                'primary_keys': pk_cols,
                'columns_info': []
            }
            
            # For each column, collect name, type, and sample values
            for col in table_info.get('columns', []):
                col_name = col.get('name')
                col_type = col.get('data_type', 'UNKNOWN')
                col_samples = col.get('sample_values', [])[:10]  # First 10 samples
                is_pk = col_name in pk_cols
                
                # Make all sample values JSON-serializable
                col_samples_clean = [make_json_serializable(val) for val in col_samples]
                
                available_tables[table_name]['columns_info'].append({
                    'name': col_name,
                    'type': col_type,
                    'is_primary_key': is_pk,
                    'sample_values': col_samples_clean
                })
        
        return available_tables
    
    def _build_available_tables_info(self) -> Dict[str, Any]:
        """Legacy method for backward compatibility - calls new enriched version"""
        return self._build_available_tables_enriched()
    
    def _determine_generation_strategy(
        self,
        column_name: str,
        data_type: str,
        max_length: Any,
        is_pk: bool,
        is_fk: bool,
        pii_category: Any,
        sample_values: List[Any],
    ) -> str:
        """
        Determine Faker provider for data type
        
        Args:
            column_name: Column name (used for semantic hints like *_ID, EMAIL, NAME)
            data_type: SQL data type
            max_length: Maximum length for strings
            is_pk: Is primary key
        
        Returns:
            Faker strategy name
        """
        name_lower = column_name.lower()

        # Primary keys – treat as auto-incrementing numeric IDs
        if is_pk:
            return 'sequence'

        # Foreign keys – values will be corrected by RI agent later,
        # but we still generate numeric placeholders.
        if is_fk:
            return 'foreign_key'

        # PII-based strategies (overrides plain name-based detection)
        if pii_category:
            pii_lower = str(pii_category).lower()
            if 'email' in pii_lower:
                return 'email'
            if 'phone' in pii_lower or 'mobile' in pii_lower:
                return 'phone'
            if 'name' in pii_lower:
                return 'name'
        
        # Normalize data type
        dtype = data_type.upper()

        # Note: sample_values are used for PATTERN ANALYSIS by the LLM,
        # not as a reference list to choose from directly.
        # The LLM will analyze patterns in sample data to generate realistic synthetic values.

        # Text types
        if 'VARCHAR' in dtype or 'STRING' in dtype or 'TEXT' in dtype:
            if max_length and max_length <= 50:
                return 'word'
            return 'sentence'

        # Integer-like numeric types
        if dtype in ['INT', 'INTEGER', 'BIGINT', 'NUMBER'] or 'NUMBER' in dtype:
            return 'random_int'

        # Floating point / decimal numeric types
        if dtype in ['FLOAT', 'DOUBLE', 'DECIMAL', 'NUMERIC']:
            return 'random_float'

        if dtype == 'BOOLEAN':
            return 'boolean'

        if 'DATE' in dtype or 'TIMESTAMP' in dtype:
            return 'date_time'

        # Fallback string
        return 'word'
    
    def get_plan_summary(self) -> str:
        """
        Get human-readable plan summary
        
        Returns:
            Formatted plan summary
        """
        summary = "\n" + "="*60 + "\n"
        summary += "GENERATION PLAN SUMMARY\n"
        summary += "="*60 + "\n"
        
        summary += f"Total Tables: {len(self.generation_plan)}\n"
        summary += f"Execution Order:\n"
        
        for idx, table in enumerate(self.execution_order, 1):
            if table in self.generation_plan:
                plan = self.generation_plan[table]
                summary += f"  {idx}. {table} -> {plan['row_count']} rows\n"
        
        total_rows = sum([plan['row_count'] for plan in self.generation_plan.values()])
        summary += f"\nTotal Rows to Generate: {total_rows}\n"
        summary += "="*60 + "\n"
        
        return summary
    
    def _print_fk_detection_summary(self, generation_plan: Dict[str, Any]) -> None:
        """
        Print foreign key detection summary to terminal
        
        Args:
            generation_plan: The generation plan with all table plans
        """
        # Count FK types
        total_fks = 0
        ai_detected_fks = 0
        implicit_fks = 0
        explicit_fks = 0
        high_confidence_fks = 0
        medium_confidence_fks = 0
        
        for table_plan in generation_plan.values():
            for col in table_plan.get('columns', []):
                if col.get('is_foreign_key'):
                    fk_refs = col.get('foreign_key_references', [])
                    for fk_ref in fk_refs:
                        total_fks += 1
                        
                        if fk_ref.get('ai_detected'):
                            ai_detected_fks += 1
                        
                        if fk_ref.get('is_implicit'):
                            implicit_fks += 1
                        else:
                            explicit_fks += 1
                        
                        confidence = fk_ref.get('confidence', 'medium')
                        if confidence == 'high':
                            high_confidence_fks += 1
                        elif confidence == 'medium':
                            medium_confidence_fks += 1
        
        # Print summary
        if total_fks > 0:
            print("\n" + "="*60)
            print("FOREIGN KEY DETECTION SUMMARY")
            print("="*60)
            print(f"✓ Total Foreign Keys Found: {total_fks}")
            print(f"  • Explicit FKs (from schema): {explicit_fks}")
            
            if ai_detected_fks > 0:
                print(f"  • AI-Detected FKs: {ai_detected_fks}")
                if implicit_fks > 0:
                    print(f"    - Implicit FKs: {implicit_fks}")
                if high_confidence_fks > 0:
                    print(f"    - High Confidence: {high_confidence_fks}")
                if medium_confidence_fks > 0:
                    print(f"    - Medium Confidence: {medium_confidence_fks}")
            
            print("="*60)
