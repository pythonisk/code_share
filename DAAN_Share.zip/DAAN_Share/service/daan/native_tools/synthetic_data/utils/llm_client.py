"""Lightweight Azure OpenAI chat client used for code generation.

Reads configuration from environment variables defined in .env:

- AZURE_OPENAI_API_KEY
- AZURE_OPENAI_API_BASE or AZURE_ENDPOINT
- AZURE_OPENAI_API_VERSION
- AZURE_OPENAI_DEPLOYMENT (deployment/model name, e.g. "gpt-4o-mini")

This module intentionally avoids taking a hard dependency on the official
Azure OpenAI SDK and uses `requests` instead.
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional

import requests


class AzureOpenAIClient:
    """Minimal Azure OpenAI chat completion client."""

    def __init__(self) -> None:
        api_key = os.getenv("AZURE_OPENAI_API_KEY")
        api_base = os.getenv("AZURE_OPENAI_API_BASE") or os.getenv("AZURE_ENDPOINT")
        api_version = os.getenv("AZURE_OPENAI_API_VERSION")
        deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o-mini")

        if not api_key or not api_base or not api_version:
            raise RuntimeError(
                "Azure OpenAI environment not fully configured. "
                "Expected AZURE_OPENAI_API_KEY, AZURE_OPENAI_API_BASE (or AZURE_ENDPOINT) "
                "and AZURE_OPENAI_API_VERSION in the environment."
            )

        self.api_key = api_key
        self.api_base = api_base.rstrip("/")
        self.api_version = api_version
        self.deployment = deployment

    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.2, max_tokens: int = 2048) -> str:
        """Call the Azure OpenAI chat completions endpoint and return text content.

        The deployment name comes from AZURE_OPENAI_DEPLOYMENT. The caller is
        responsible for interpreting the returned text.
        """
        url = (
            f"{self.api_base}/openai/deployments/{self.deployment}/chat/completions"
            f"?api-version={self.api_version}"
        )

        headers = {
            "Content-Type": "application/json",
            "api-key": self.api_key,
        }

        payload: Dict[str, Any] = {
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        response = requests.post(url, headers=headers, data=json.dumps(payload), timeout=60)
        response.raise_for_status()
        data = response.json()

        choices = data.get("choices") or []
        if not choices:
            # Log the full response for debugging
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Azure OpenAI response contained no choices. Full response: {data}")
            raise RuntimeError("Azure OpenAI response contained no choices")

        message = choices[0].get("message") or {}
        content = message.get("content")
        if not isinstance(content, str):
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Azure OpenAI response message content was not a string. Message: {message}")
            raise RuntimeError("Azure OpenAI response message content was not a string")

        return content.strip()