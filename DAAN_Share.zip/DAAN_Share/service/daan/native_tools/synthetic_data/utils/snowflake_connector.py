"""
Snowflake connection and query execution module.

Reads all credentials from environment variables already present in the
FastAPI process (loaded from config/.env at server startup).

Expected env vars:
    SNOWFLAKE_ACCOUNT, SNOWFLAKE_USER, SNOWFLAKE_PASSWORD,
    SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA, SNOWFLAKE_WAREHOUSE,
    SNOWFLAKE_ROLE  (optional, defaults to SYSADMIN)
"""
import os
import logging
from typing import List, Dict, Any, Optional

import snowflake.connector

logger = logging.getLogger(__name__)


class SnowflakeConnector:
    """Handle Snowflake database connections and queries.

    Credentials are read from environment variables — no config dict,
    no dotenv calls, no interactive prompts.
    """

    def __init__(self):
        self.config = {
            "account": os.getenv("SNOWFLAKE_ACCOUNT", ""),
            "user": os.getenv("SNOWFLAKE_USER", ""),
            "password": os.getenv("SNOWFLAKE_PASSWORD", ""),
            "warehouse": os.getenv("SNOWFLAKE_WAREHOUSE", ""),
            "database": os.getenv("SNOWFLAKE_DATABASE", ""),
            "schema": os.getenv("SNOWFLAKE_SCHEMA", "PUBLIC"),
            "role": os.getenv("SNOWFLAKE_ROLE", "SYSADMIN"),
        }
        self.connection = None
        self._tables_cache = None
        self._row_count_cache: Dict[str, int] = {}

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    def connect(self) -> bool:
        """Establish connection to Snowflake.

        Returns:
            bool: True if connection successful, False otherwise.
        """
        missing = [k for k, v in self.config.items() if k != "role" and not v]
        if missing:
            logger.error("Missing Snowflake env vars: %s", ", ".join(f"SNOWFLAKE_{k.upper()}" for k in missing))
            return False
        try:
            self.connection = snowflake.connector.connect(
                account=self.config["account"],
                user=self.config["user"],
                password=self.config["password"],
                warehouse=self.config["warehouse"],
                database=self.config["database"],
                schema=self.config["schema"],
                role=self.config["role"],
            )
            logger.info("Connected to Snowflake: %s / %s", self.config["account"], self.config["database"])
            return True
        except Exception as exc:
            logger.error("Failed to connect to Snowflake: %s", str(exc))
            return False

    def disconnect(self) -> None:
        """Close Snowflake connection."""
        if self.connection:
            try:
                self.connection.close()
            except Exception:
                pass
            self.connection = None
            logger.info("Disconnected from Snowflake")

    # ------------------------------------------------------------------
    # Query execution
    # ------------------------------------------------------------------

    def execute_query(self, query: str) -> List[Dict[str, Any]]:
        """Execute a SQL query and return results as a list of dicts."""
        try:
            cursor = self.connection.cursor()
            cursor.execute(query)
            columns = [desc[0] for desc in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            cursor.close()
            return results
        except Exception as exc:
            logger.error("Query execution error: %s", str(exc))
            return []

    # ------------------------------------------------------------------
    # Schema introspection — identical logic to original connector
    # ------------------------------------------------------------------

    def get_tables(self) -> List[str]:
        """Return table names in the configured schema (cached per session)."""
        if self._tables_cache is not None:
            return self._tables_cache
        query = (
            f"SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES "
            f"WHERE TABLE_SCHEMA = '{self.config['schema']}' "
            f"AND TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME"
        )
        results = self.execute_query(query)
        self._tables_cache = [row["TABLE_NAME"] for row in results]
        return self._tables_cache

    def get_table_schema(self, table_name: str) -> List[Dict[str, Any]]:
        """Get column details for a specific table."""
        query = (
            f"SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, "
            f"IS_NULLABLE, ORDINAL_POSITION, COLUMN_DEFAULT, COMMENT "
            f"FROM INFORMATION_SCHEMA.COLUMNS "
            f"WHERE TABLE_SCHEMA = '{self.config['schema']}' "
            f"AND TABLE_NAME = '{table_name}' ORDER BY ORDINAL_POSITION"
        )
        return self.execute_query(query)

    def get_primary_keys(self, table_name: str) -> List[str]:
        """Get primary key columns for a table using multi-strategy detection."""
        try:
            schema = self.config["schema"]
            database = self.config.get("database", "")

            # Strategy 1: SHOW PRIMARY KEYS
            try:
                results = self.execute_query(
                    f'SHOW PRIMARY KEYS IN TABLE "{database}"."{schema}"."{table_name}"'
                )
                if results:
                    pks = [r.get("column_name", r.get("COLUMN_NAME", "")) for r in results]
                    pks = [c for c in pks if c]
                    if pks:
                        return pks
            except Exception:
                pass

            # Strategy 2: Naming convention + cardinality heuristic
            describe_results = self.execute_query(f'DESCRIBE TABLE "{schema}"."{table_name}"')
            id_candidates = []
            for row in describe_results:
                row_dict = {k.upper(): v for k, v in row.items()}
                col_name = row_dict.get("NAME", "")
                data_type = row_dict.get("TYPE", "").upper()
                if (col_name.upper().endswith("_ID") or col_name.upper().endswith("ID")) and any(
                    t in data_type for t in ("NUMBER", "INT", "TEXT", "VARCHAR", "STRING")
                ):
                    id_candidates.append(col_name)

            if id_candidates:
                first_id = id_candidates[0]
                card = self.execute_query(
                    f'SELECT COUNT(DISTINCT "{first_id}") AS unique_count, COUNT(*) AS total_count '
                    f'FROM "{schema}"."{table_name}"'
                )
                if card:
                    u = card[0].get("UNIQUE_COUNT", 0)
                    t = card[0].get("TOTAL_COUNT", 1)
                    if u and t and u >= t * 0.95:
                        return [first_id]
                return [id_candidates[0]]

            logger.warning("No primary key detected for %s", table_name)
            return []
        except Exception as exc:
            logger.warning("Could not retrieve PKs for %s: %s", table_name, str(exc))
            return []

    def get_foreign_keys(self, table_name: str) -> List[Dict[str, Any]]:
        """Get foreign key relationships for a table."""
        try:
            schema = self.config["schema"]
            query = (
                f"SELECT CONSTRAINT_NAME, TABLE_NAME, TABLE_SCHEMA "
                f"FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS "
                f"WHERE CONSTRAINT_TYPE = 'FOREIGN KEY' "
                f"AND TABLE_SCHEMA = '{schema}' AND TABLE_NAME = '{table_name}'"
            )
            constraints = self.execute_query(query)
            if not constraints:
                return []
            enriched = []
            for c in constraints:
                fk_col, ref_table, ref_col = self._infer_fk_columns(
                    table_name, c.get("CONSTRAINT_NAME", "")
                )
                row = dict(c)
                if fk_col:
                    row["FK_COLUMN_NAME"] = fk_col
                if ref_table:
                    row["REFERENCED_TABLE_NAME"] = ref_table
                if ref_col:
                    row["REFERENCED_COLUMN_NAME"] = ref_col
                enriched.append(row)
            return enriched
        except Exception as exc:
            logger.debug("Could not retrieve FKs for %s: %s", table_name, str(exc))
            return []

    def _infer_fk_columns(self, table_name: str, constraint_name: str):
        """Infer FK column, referenced table, and referenced column from constraint name."""
        try:
            all_tables = [t.upper() for t in self.get_tables()]
            parts = constraint_name.upper().split("_")
            if len(parts) < 2:
                return None, None, None
            ref_table = None
            for table in all_tables:
                if table in constraint_name.upper() and table != table_name:
                    ref_table = table
                    break
            if not ref_table:
                last_part = parts[-1]
                for table in all_tables:
                    if table.startswith(last_part) and table != table_name:
                        ref_table = table
                        break
            fk_col = None
            if "MANAGER" in constraint_name.upper():
                fk_col = "MANAGER_ID"
            elif "DEPT" in constraint_name.upper():
                fk_col = "DEPARTMENT_ID"
            elif ref_table:
                fk_col = ref_table.rstrip("S") + "_ID"
            ref_col = (ref_table.rstrip("S") + "_ID") if ref_table else None
            return fk_col, ref_table, ref_col
        except Exception:
            return None, None, None

    def get_table_comment(self, table_name: str) -> Optional[str]:
        """Get table-level comment from INFORMATION_SCHEMA."""
        try:
            schema = self.config.get("schema")
            if not schema:
                return None
            results = self.execute_query(
                f"SELECT COMMENT FROM INFORMATION_SCHEMA.TABLES "
                f"WHERE TABLE_SCHEMA = '{schema}' AND TABLE_NAME = '{table_name}'"
            )
            if not results:
                return None
            return results[0].get("COMMENT") or results[0].get("comment")
        except Exception as exc:
            logger.warning("Could not retrieve comment for %s: %s", table_name, str(exc))
            return None

    def get_max_pk_value(self, table_name: str, pk_column: str) -> Any:
        """Get the maximum value of a primary key column."""
        try:
            schema = self.config["schema"]
            results = self.execute_query(
                f'SELECT MAX("{pk_column}") AS MAX_VAL FROM "{schema}"."{table_name}"'
            )
            if results and results[0].get("MAX_VAL") is not None:
                return results[0]["MAX_VAL"]
            return None
        except Exception as exc:
            logger.warning("Could not get max PK for %s.%s: %s", table_name, pk_column, str(exc))
            return None

    def get_row_count(self, table_name: str) -> int:
        """Get row count for a table (cached per session)."""
        if table_name in self._row_count_cache:
            return self._row_count_cache[table_name]
        try:
            schema = self.config.get("schema")
            if not schema:
                return 0
            results = self.execute_query(
                f"SELECT ROW_COUNT FROM INFORMATION_SCHEMA.TABLES "
                f"WHERE TABLE_SCHEMA = '{schema}' AND TABLE_NAME = '{table_name}'"
            )
            if results and results[0].get("ROW_COUNT"):
                count = int(results[0]["ROW_COUNT"])
                self._row_count_cache[table_name] = count
                return count
            fallback = self.execute_query(
                f"SELECT COUNT(*) AS row_count FROM {schema}.{table_name}"
            )
            count = int(fallback[0].get("ROW_COUNT") or fallback[0].get("row_count") or 0) if fallback else 0
            self._row_count_cache[table_name] = count
            return count
        except Exception as exc:
            logger.warning("Could not retrieve row count for %s: %s", table_name, str(exc))
            return 0

    def get_sample_values(self, table_name: str, column_names: List[str]) -> Dict[str, List[Any]]:
        """Get sample values from a table for pattern understanding."""
        samples: Dict[str, List[Any]] = {name: [] for name in column_names}
        try:
            schema = self.config.get("schema")
            if not schema or not column_names:
                return samples
            quoted_cols = ", ".join(f'"{name}"' for name in column_names)
            results = self.execute_query(
                f'SELECT {quoted_cols} FROM "{schema}"."{table_name}" LIMIT 10'
            )
            for row in results:
                for col in column_names:
                    val = row.get(col)
                    if val is not None and val not in samples[col]:
                        samples[col].append(val)
        except Exception as exc:
            logger.warning("Could not get sample values for %s: %s", table_name, str(exc))
        return samples

    def get_sample_dataframe(self, table_name: str, sample_size: int = 10000):
        """Return a pandas DataFrame with a sample of the table data."""
        import pandas as pd
        try:
            schema = self.config["schema"]
            results = self.execute_query(
                f'SELECT * FROM "{schema}"."{table_name}" LIMIT {sample_size}'
            )
            return pd.DataFrame(results) if results else pd.DataFrame()
        except Exception as exc:
            logger.error("Could not sample %s: %s", table_name, str(exc))
            return None

    def get_synthetic_database_name(self) -> str:
        """Return the target database name for synthetic data: <REAL_DB>_SYNTHETIC."""
        return f"{self.config.get('database', 'SYNTHETIC_DATA')}_SYNTHETIC"
