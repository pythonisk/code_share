"""Catalog of REAL, available tools for the Use Case Builder pipeline.

The AgentEnricher agent uses this to map each generated agent to tools that
actually exist in this DAAN deployment, so it never invents a tool name. It
returns three grounded groups:

  * mcp_servers — from ``config/mcp_servers_registry.yml`` and the
    ``mcp_server_registry`` DB table (dynamically discovered servers).
  * local_tools — native tool classes in ``daan/native_tools/`` with their
    callable methods, discovered by static parsing (no code is executed).

local_tools reference:
    ToolCatalogTool.list_available_tools
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

# Native-tool modules that are infrastructure/clients, not agent-callable tools.
_LOCAL_TOOL_SKIP = {
    "__init__",
    "tools_loader",
}


class ToolCatalogTool:
    """Native tool that lists the real MCP servers and local tools available."""

    def __init__(self, data_dir: str | None = None, **_kwargs: Any) -> None:
        self.tool_name = "ToolCatalogTool"
        self._data_dir = data_dir
        logger.info("%s: initialized (data_dir=%s)", self.tool_name, data_dir)

    # ── Public tool method (exposed to the agent) ────────────────────────────
    def list_available_tools(self, **_kwargs: Any) -> dict[str, Any]:
        """Return the real MCP servers and local tools available in this deployment.

        Returns:
            A dict with keys:
              ``status`` ("ok" | "error"),
              ``mcp_servers`` (list of {server_name, display_name, description,
                tools}) — reference an MCP server by its ``server_name``,
              ``local_tools`` (list of {reference, class_name, method,
                description}) — reference a local tool by its ``reference``
                (``ClassName.method``),
              ``usage`` (short note on how to reference each group).
        """
        try:
            mcp_servers = self._collect_mcp_servers()
            local_tools = self._collect_local_tools()
            return {
                "status": "ok",
                "mcp_servers": mcp_servers,
                "local_tools": local_tools,
                "usage": (
                    "Set an agent's mcp_servers to a server_name from mcp_servers. "
                    "Set an agent's local_tools to a reference (ClassName.method) "
                    "from local_tools. Only use names that appear in these lists."
                ),
            }
        except Exception as exc:  # noqa: BLE001 — surface a clean tool error
            logger.exception("%s: list_available_tools failed", self.tool_name)
            return {
                "status": "error",
                "mcp_servers": [],
                "local_tools": [],
                "error": f"Failed to list tools: {exc}",
            }

    # ── MCP servers ──────────────────────────────────────────────────────────
    def _collect_mcp_servers(self) -> list[dict[str, Any]]:
        by_name: dict[str, dict[str, Any]] = {}

        for entry in self._mcp_from_registry_yaml():
            by_name[entry["server_name"]] = entry
        for entry in self._mcp_from_db():
            existing = by_name.get(entry["server_name"])
            if existing:
                # Prefer DB-discovered tool list when the yaml had none.
                if entry.get("tools") and not existing.get("tools"):
                    existing["tools"] = entry["tools"]
                if not existing.get("description"):
                    existing["description"] = entry.get("description", "")
            else:
                by_name[entry["server_name"]] = entry

        return sorted(by_name.values(), key=lambda e: e["server_name"])

    def _mcp_from_registry_yaml(self) -> list[dict[str, Any]]:
        registry_path = (
            Path(__file__).resolve().parents[3]
            / "config"
            / "mcp_servers_registry.yml"
        )
        if not registry_path.is_file():
            return []
        try:
            data = yaml.safe_load(registry_path.read_text(encoding="utf-8")) or {}
        except Exception:  # noqa: BLE001
            logger.warning("%s: failed to parse mcp_servers_registry.yml", self.tool_name)
            return []

        servers = data.get("servers") or {}
        result: list[dict[str, Any]] = []
        for name, cfg in servers.items():
            if not isinstance(cfg, dict):
                continue
            if cfg.get("enabled") is False:
                continue
            result.append(
                {
                    "server_name": name,
                    "display_name": cfg.get("display_name") or name,
                    "description": cfg.get("description") or "",
                    "tools": [],
                }
            )
        return result

    def _mcp_from_db(self) -> list[dict[str, Any]]:
        try:
            from daan.core.database import SessionLocal
            from daan.models.mcp_registry import McpServerRegistry
        except Exception:  # noqa: BLE001
            return []

        result: list[dict[str, Any]] = []
        db = None
        try:
            db = SessionLocal()
            for row in db.query(McpServerRegistry).all():
                result.append(
                    {
                        "server_name": row.server_name,
                        "display_name": row.display_name or row.server_name,
                        "description": row.description or "",
                        "tools": self._tool_names(row.available_tools),
                    }
                )
        except Exception:  # noqa: BLE001
            logger.warning("%s: MCP registry DB read skipped", self.tool_name)
            return result
        finally:
            if db is not None:
                db.close()
        return result

    @staticmethod
    def _tool_names(available_tools: Any) -> list[str]:
        if not available_tools:
            return []
        items = available_tools
        if isinstance(available_tools, dict):
            items = available_tools.get("tools", available_tools)
        names: list[str] = []
        if isinstance(items, dict):
            names = [str(k) for k in items.keys()]
        elif isinstance(items, list):
            for item in items:
                if isinstance(item, dict):
                    name = item.get("name") or item.get("tool") or item.get("function")
                    if name:
                        names.append(str(name))
                elif item:
                    names.append(str(item))
        return names

    # ── Local (native) tools ─────────────────────────────────────────────────
    def _collect_local_tools(self) -> list[dict[str, Any]]:
        native_dir = Path(__file__).resolve().parent
        result: list[dict[str, Any]] = []
        for path in sorted(native_dir.glob("*.py")):
            if path.stem in _LOCAL_TOOL_SKIP:
                continue
            try:
                for entry in self._parse_module_tools(path):
                    result.append(entry)
            except Exception:  # noqa: BLE001 — one bad file must not break the catalog
                logger.debug("%s: skipped unparsable %s", self.tool_name, path.name)
        return result

    def _parse_module_tools(self, path: Path) -> list[dict[str, Any]]:
        tree = ast.parse(path.read_text(encoding="utf-8"))
        module_doc = ast.get_docstring(tree) or ""
        module_summary = self._first_sentence(module_doc)

        entries: list[dict[str, Any]] = []
        for node in tree.body:
            if not isinstance(node, ast.ClassDef):
                continue
            class_doc = self._first_sentence(ast.get_docstring(node) or "") or module_summary
            for method in self._public_methods(node):
                entries.append(
                    {
                        "reference": f"{node.name}.{method}",
                        "class_name": node.name,
                        "method": method,
                        "description": class_doc,
                    }
                )
        return entries

    @staticmethod
    def _public_methods(node: ast.ClassDef) -> list[str]:
        methods: list[str] = []
        for item in node.body:
            if not isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            name = item.name
            if name.startswith("_"):
                continue
            methods.append(name)
        return methods

    @staticmethod
    def _first_sentence(text: str) -> str:
        cleaned = " ".join((text or "").split())
        if not cleaned:
            return ""
        for stop in (". ", ".\n"):
            idx = cleaned.find(stop)
            if idx != -1:
                return cleaned[: idx + 1].strip()
        return cleaned[:200].strip()
