"""Assemble the generated agent spec into one Excel sheet + a definition.json.

This is the fourth agent (X4) in the Use Case Builder from Process Design
pipeline. It does NOT rely on the LLM copying a large payload into its tool
arguments; instead it reads the upstream agents' saved outputs directly from
session storage (``agents/*/output.md``), which DAAN persists for every agent.

It produces two things:
  * a single human-downloadable Excel workbook in the session ``artifacts/``
    folder, and
  * a ``definition.json`` (``{usecase, agents}``) at the session root, which the
    final creator agent consumes deterministically (no truncation risk).

local_tools reference:
    SpecExcelWriterTool.write
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

# Agent-table columns for the Excel sheet, in DB column order (+ Prompt).
_AGENT_COLUMNS = [
    ("agent_id", "Agent ID"),
    ("role", "Role"),
    ("input_context", "Input Context"),
    ("agent_name", "Agent Name"),
    ("agent_actions", "Agent Actions"),
    ("output_format", "Output Format"),
    ("output_validators", "Output Validators"),
    ("guardrails", "Guardrails"),
    ("mcp_server", "MCP Server"),
    ("local_tools", "Local Tools"),
    ("agent_type", "Agent Type"),
    ("depend_on", "Depends On"),
    ("prompt", "Prompt"),
]

# Usecase-level fields for the metadata header block (DB columns).
_USECASE_FIELDS = [
    ("name", "Use Case Name"),
    ("task", "Task"),
    ("role", "Role"),
    ("category", "Category"),
    ("agents_involved", "Agents Involved"),
    ("loop_config", "Loop Config"),
]

# Alias sets so we accept whatever key names the architect/enricher emitted.
_ALIASES: dict[str, tuple[str, ...]] = {
    "agent_id": ("agent_id", "logical_id", "id"),
    "role": ("role",),
    "input_context": ("input_context", "inputs", "input"),
    "agent_name": ("agent_name", "name"),
    "agent_actions": ("agent_actions", "actions", "action", "task"),
    "output_format": ("output_format", "output", "expected_output", "output_schema"),
    "output_validators": ("output_validators", "validators"),
    "guardrails": ("guardrails", "guard_rails", "constraints"),
    "mcp_server": ("mcp_server", "mcp_servers", "mcp_tools", "mcp"),
    "local_tools": ("local_tools", "native_tools", "tools"),
    "agent_type": ("agent_type", "type"),
    "depend_on": ("depend_on", "depends_on", "dependencies", "parents"),
    "prompt": ("prompt", "user_prompt", "system_prompt", "instruction"),
}


class SpecExcelWriterTool:
    """Native tool that writes the agent spec Excel and definition.json."""

    def __init__(self, data_dir: str | None = None, **_kwargs: Any) -> None:
        self.tool_name = "SpecExcelWriterTool"
        self._data_dir = data_dir
        logger.info("%s: initialized (data_dir=%s)", self.tool_name, data_dir)

    # ── Public tool method (exposed to the agent) ────────────────────────────
    def write(
        self,
        session_id: str | None = None,
        file_name: str = "use_case_spec.xlsx",
        **_kwargs: Any,
    ) -> dict[str, Any]:
        """Assemble the agent spec from upstream outputs into Excel + definition.json.

        Args:
            session_id: Session id whose ``agents/*/output.md`` files hold the
                upstream specs. When omitted, it is derived from the injected
                data directory.
            file_name: Name of the Excel workbook to create in ``artifacts/``.

        Returns:
            A dict with keys:
              ``status`` ("ok" | "error"),
              ``xlsx_path`` (absolute path to the workbook),
              ``definition_path`` (absolute path to definition.json),
              ``agents`` (count of agents written),
              ``error`` (present only on failure).
        """
        try:
            session_dir = self._resolve_session_dir(session_id)
            if session_dir is None:
                return self._error("Could not resolve the session directory.")

            outputs = self._read_agent_outputs(session_dir)
            if not outputs:
                return self._error("No upstream agent outputs found to assemble.")

            usecase, agents = self._parse_definition(outputs)
            if not agents:
                return self._error(
                    "No agent specifications could be parsed from upstream outputs."
                )

            definition = {"usecase": usecase, "agents": agents}
            definition_path = session_dir / "definition.json"
            definition_path.write_text(
                json.dumps(definition, indent=2, ensure_ascii=False), encoding="utf-8"
            )

            # Excel-only agents_involved: agent names (DB stores id:name|type at creation).
            usecase_for_excel = dict(usecase)
            _names = [str(a.get("agent_name") or a.get("name") or "").strip() for a in agents]
            usecase_for_excel["agents_involved"] = "; ".join(n for n in _names if n)
            xlsx_path = self._write_excel(session_dir, file_name, usecase_for_excel, agents)

            return {
                "status": "ok",
                "xlsx_path": str(xlsx_path),
                "definition_path": str(definition_path),
                "agents": len(agents),
            }
        except Exception as exc:  # noqa: BLE001 — surface a clean tool error
            logger.exception("%s: write failed", self.tool_name)
            return self._error(f"Failed to write spec: {exc}")

    # ── Reading upstream outputs ─────────────────────────────────────────────
    def _resolve_session_dir(self, session_id: str | None) -> Path | None:
        if session_id:
            root = Path(__file__).resolve().parents[3] / "session_storage" / session_id
            if root.is_dir():
                return root
            # LLM-supplied session_id is invalid; fall back to the injected data_dir.
        if not self._data_dir:
            return None
        data_path = Path(self._data_dir)
        session_dir = data_path.parent if data_path.name == "inputs" else data_path
        return session_dir if session_dir.is_dir() else None

    def _read_agent_outputs(self, session_dir: Path) -> list[str]:
        agents_dir = session_dir / "agents"
        if not agents_dir.is_dir():
            return []

        # Order by output.md mtime so enriched specs (produced later by the
        # enricher loop) come AFTER the architect's raw specs and win the merge.
        def _mtime(agent_dir: Path) -> float:
            f = agent_dir / "output.md"
            try:
                return f.stat().st_mtime if f.is_file() else float("inf")
            except Exception:  # noqa: BLE001
                return float("inf")

        outputs: list[str] = []
        for agent_dir in sorted(
            (p for p in agents_dir.iterdir() if p.is_dir()), key=_mtime
        ):
            output_file = agent_dir / "output.md"
            if output_file.is_file():
                try:
                    text = output_file.read_text(encoding="utf-8")
                except Exception:  # noqa: BLE001
                    continue
                if text.strip():
                    outputs.append(text)
        return outputs

    # ── Parsing specs out of the outputs ─────────────────────────────────────
    def _parse_definition(
        self, outputs: list[str]
    ) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        from daan.native_tools.create_use_case_from_definition_tool import (
            _collect_bare_agents,
        )

        usecase: dict[str, Any] = {}
        by_name: dict[str, dict[str, Any]] = {}
        order: list[str] = []

        for text in outputs:
            for parsed in self._parse_blocks(text):
                if isinstance(parsed, dict) and isinstance(parsed.get("usecase"), dict):
                    if not usecase:
                        usecase = parsed["usecase"]
                for agent in _collect_bare_agents(parsed):
                    key = str(agent.get("agent_name") or "").strip().casefold()
                    if not key:
                        continue
                    if key not in by_name:
                        by_name[key] = {}
                        order.append(key)
                    # Later, non-empty fields overwrite: the enricher's prompt/
                    # tools win over the architect's bare atom of the same name.
                    for field, value in agent.items():
                        if value not in (None, "", [], {}):
                            by_name[key][field] = value

        return usecase, [by_name[key] for key in order]

    @staticmethod
    def _parse_blocks(text: str) -> list[Any]:
        """Parse objects from loop-joined, fenced, or raw JSON/YAML output."""
        results: list[Any] = []

        # Strip a single fence wrapping the WHOLE output so it does not corrupt
        # the first/last block after splitting on the separator.
        text = text.strip()
        if text.startswith("```"):
            text = re.sub(r"^```[a-zA-Z0-9]*\s*", "", text)
            text = re.sub(r"\s*```$", "", text)

        # The loop runner joins each iteration's output with this exact separator.
        segments = re.split(r"\n\n---\n\n", text) if "\n\n---\n\n" in text else [text]

        candidates: list[str] = []
        for segment in segments:
            seg = segment.strip()
            if not seg:
                continue
            fenced = re.findall(
                r"```(?:ya?ml|json)?\s*(.*?)```", seg, re.DOTALL | re.IGNORECASE
            )
            if fenced:
                candidates.extend(f.strip() for f in fenced)
            else:
                candidates.append(seg)

        for candidate in candidates:
            for loader in (json.loads, yaml.safe_load):
                try:
                    parsed = loader(candidate)
                except Exception:  # noqa: BLE001
                    continue
                if parsed is not None:
                    results.append(parsed)
                    break
        return results

    # ── Excel output ─────────────────────────────────────────────────────────
    def _write_excel(
        self,
        session_dir: Path,
        file_name: str,
        usecase: dict[str, Any],
        agents: list[dict[str, Any]],
    ) -> Path:
        import openpyxl
        from openpyxl.styles import Alignment, Font, PatternFill

        artifacts_dir = session_dir / "artifacts"
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        xlsx_path = artifacts_dir / file_name

        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.title = "UseCase"

        bold = Font(bold=True)
        header_fill = PatternFill("solid", fgColor="D9E1F2")
        wrap = Alignment(wrap_text=True, vertical="top")

        row = 1
        # Metadata header block (key/value rows).
        for key, label in _USECASE_FIELDS:
            sheet.cell(row=row, column=1, value=label).font = bold
            sheet.cell(row=row, column=2, value=self._as_cell(usecase.get(key)))
            row += 1

        row += 1  # blank separator row
        # Agent table header.
        header_row = row
        for col_index, (_key, label) in enumerate(_AGENT_COLUMNS, start=1):
            cell = sheet.cell(row=header_row, column=col_index, value=label)
            cell.font = bold
            cell.fill = header_fill
            cell.alignment = wrap
        row += 1

        for agent in agents:
            for col_index, (key, _label) in enumerate(_AGENT_COLUMNS, start=1):
                value = self._as_cell(self._get(agent, key))
                cell = sheet.cell(row=row, column=col_index, value=value)
                cell.alignment = wrap
            row += 1

        self._autosize(sheet, len(_AGENT_COLUMNS))
        workbook.save(xlsx_path)
        return xlsx_path

    @staticmethod
    def _autosize(sheet: Any, num_cols: int) -> None:
        from openpyxl.utils import get_column_letter

        for col in range(1, max(num_cols, 2) + 1):
            letter = get_column_letter(col)
            longest = 0
            for cell in sheet[letter]:
                value = cell.value
                if value is not None:
                    longest = max(longest, min(len(str(value)), 60))
            sheet.column_dimensions[letter].width = max(12, min(longest + 2, 60))

    # ── Field helpers ────────────────────────────────────────────────────────
    def _get(self, agent: dict[str, Any], key: str) -> Any:
        for alias in _ALIASES.get(key, (key,)):
            if alias in agent and agent[alias] not in (None, ""):
                return agent[alias]
        return ""

    @staticmethod
    def _as_cell(value: Any) -> str:
        if value in (None, ""):
            return ""
        if isinstance(value, bool):
            return "Yes" if value else "No"
        if isinstance(value, (list, tuple)):
            return ", ".join(str(v) for v in value if str(v).strip())
        if isinstance(value, dict):
            return json.dumps(value, ensure_ascii=False)
        return str(value)

    @staticmethod
    def _error(message: str) -> dict[str, Any]:
        return {
            "status": "error",
            "xlsx_path": "",
            "definition_path": "",
            "agents": 0,
            "error": message,
        }
