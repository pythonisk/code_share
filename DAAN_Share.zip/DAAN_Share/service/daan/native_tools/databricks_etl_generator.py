"""DAAN native tool: persist Databricks PySpark / DDL notebooks as session artifacts."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

from daan.flow.session_service import get_artifacts_dir

logger = logging.getLogger(__name__)

_MAX_NOTEBOOK_BYTES = 5 * 1024 * 1024  # cap protects session disk from runaway agents
_DATABRICKS_HEADER = "# Databricks notebook source"
_SAFE_NAME_RE = re.compile(r"[^A-Za-z0-9._-]+")


class DatabricksEtlGenerator:
    """Persist Databricks notebooks emitted by AGENT_810 (ETL) and AGENT_811 (DDL)."""

    tool_name = "DatabricksEtlGenerator"

    def __init__(self, data_dir: str | None = None) -> None:
        self._data_dir = data_dir
        logger.info("%s: initialized (data_dir=%s)", self.tool_name, data_dir)

    def generate_etl_notebook(
        self,
        notebook_code: str | None = None,
        target_table_name: str | None = None,
        file_name: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        return self._write(notebook_code, target_table_name, file_name, kind="etl")

    def generate_ddl_notebook(
        self,
        notebook_code: str | None = None,
        target_table_name: str | None = None,
        file_name: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        return self._write(notebook_code, target_table_name, file_name, kind="ddl")

    def _write(
        self,
        notebook_code: str | None,
        target_table_name: str | None,
        file_name: str | None,
        kind: str,
    ) -> dict[str, Any]:
        try:
            code = self._validate(notebook_code)
            artifacts_dir = self._artifacts_dir()
            name = self._artifact_name(file_name, target_table_name, kind)
            path = self._next_path(artifacts_dir, name)
            path.write_text(code, encoding="utf-8")
            size = path.stat().st_size
            logger.info("%s: wrote %s -> %s (%d bytes)", self.tool_name, kind, path, size)
            return {
                "status": "ok",
                "artifact_file": path.name,
                "artifact_path": str(path),
                "byte_size": size,
                "target_table_name": target_table_name,
            }
        except ValueError as exc:
            logger.warning("%s: %s", self.tool_name, exc)
            return {"status": "error", "errors": [str(exc)]}
        except Exception as exc:
            logger.exception("%s: write failed", self.tool_name)
            return {"status": "error", "errors": [f"{type(exc).__name__}: {exc}"]}

    @staticmethod
    def _validate(notebook_code: str | None) -> str:
        if not isinstance(notebook_code, str) or not notebook_code.strip():
            raise ValueError("notebook_code is required and must be a non-empty string.")
        code = notebook_code.strip()
        if len(code.encode("utf-8")) > _MAX_NOTEBOOK_BYTES:
            raise ValueError(f"notebook_code exceeds {_MAX_NOTEBOOK_BYTES} bytes.")
        if not code.startswith(_DATABRICKS_HEADER):
            raise ValueError(f"notebook_code must start with '{_DATABRICKS_HEADER}'.")
        return code

    @staticmethod
    def _artifact_name(
        file_name: str | None,
        target_table_name: str | None,
        kind: str,
    ) -> str:
        raw = Path((file_name or target_table_name or f"{kind}_notebook").strip()).name
        if raw.lower().endswith(".py"):
            raw = raw[:-3]
        stem = _SAFE_NAME_RE.sub("_", raw.replace(".", "_")).strip("._-")
        return f"{stem or kind + '_notebook'}.py"

    def _artifacts_dir(self) -> Path:
        if not self._data_dir:
            raise ValueError("data_dir was not injected; cannot resolve artifacts directory.")
        data_path = Path(self._data_dir)
        session_dir = data_path.parent if data_path.name == "inputs" else data_path
        return get_artifacts_dir(session_dir.name, create=True)

    @staticmethod
    def _next_path(artifacts_dir: Path, file_name: str) -> Path:
        candidate = artifacts_dir / Path(file_name).name
        if not candidate.exists():
            return candidate
        stem, suffix = candidate.stem, candidate.suffix
        index = 2
        while (candidate := artifacts_dir / f"{stem}_{index}{suffix}").exists():
            index += 1
        return candidate
