"""
Test Cases Generator Agent
Generates ETL/data-migration test cases from STTM mapping data.
Uses simple RAG (ChromaDB) for BRD context retrieval per STTM pair.
Produces a styled Excel workbook.

Entry point: ``TestCaseGenerator(input_context, prompt, brd_content).run()``
"""

import ast
import os, re, io, json, logging, sys as _sys
from pathlib import Path
from typing import Any, Optional
import pandas as pd
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI

# Lazy import: RAG_TCG is loaded only when generate_test_cases() is called,
# so tool registration by tools_loader succeeds even if rag package is absent.
RAG_TCG = None  # populated by _get_rag_class()

load_dotenv()
logger = logging.getLogger(__name__)


def _load_azure_creds() -> dict:
    """Load Azure OpenAI credentials from DAAN llm_config.yml, env-var fallback."""
    try:
        from daan.llm.llm_provider import load_llm_config
        cfg = load_llm_config() or {}
        az = (cfg.get("providers", {}) or {}).get("azure_openai", {}) or {}
        return {
            "api_key": az.get("api_key") or os.getenv("AZURE_OPENAI_API_KEY", ""),
            "endpoint": (
                az.get("endpoint")
                or os.getenv("AZURE_OPENAI_API_BASE", "")
                or os.getenv("AZURE_OPENAI_API_ENDPOINT", "")
                or os.getenv("AZURE_ENDPOINT", "")
            ),
            "api_version": az.get("api_version") or os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
            "deployment": az.get("deployment_name") or os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
        }
    except Exception as exc:
        logger.warning("Could not load llm_config.yml (%s), falling back to env vars", exc)
        return {
            "api_key": os.getenv("AZURE_OPENAI_API_KEY", ""),
            "endpoint": (
                os.getenv("AZURE_OPENAI_API_BASE", "")
                or os.getenv("AZURE_OPENAI_API_ENDPOINT", "")
                or os.getenv("AZURE_ENDPOINT", "")
            ),
            "api_version": os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
            "deployment": os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
        }


def _create_llm(**overrides):
    """Create an AzureChatOpenAI instance using DAAN config credentials."""
    creds = _load_azure_creds()
    return AzureChatOpenAI(
        azure_endpoint=overrides.get("azure_endpoint", creds["endpoint"]),
        azure_deployment=overrides.get("azure_deployment", creds["deployment"]),
        openai_api_version=overrides.get("openai_api_version", creds["api_version"]),
        api_key=overrides.get("api_key", creds["api_key"]),
        temperature=overrides.get("temperature", 0),
        max_tokens=overrides.get("max_tokens", 16384),
    )

_COL_ORDER = [
    "Requirement", "Test Case Name", "Description", "Pre-condition",
    "Step Number", "Step Description", "Expected Result",
    "Source Validation", "Target Validation",
]


def _get_rag_class():
    """Lazily import RAG_TCG so the module can load even when rag is absent."""
    global RAG_TCG
    if RAG_TCG is None:
        from daan.rag.rag_tcg import RAG_TCG as _cls  # noqa: E402
        RAG_TCG = _cls
    return RAG_TCG


# ====================================================================
#  Main class
# ====================================================================

class TestCasesGenerator:
    """DAAN native tool: generates ETL/data-migration test cases.

    Registered in agent config as: ``TestCasesGenerator.generate_test_cases``

    The action agent calls ``generate_test_cases(mapping_data={...})``
    where *mapping_data* is a dict containing STTM pairs, BRD text, etc.
    The tool runs RAG-augmented LLM generation internally and writes a
    styled Excel workbook to ``session_storage/{session_id}/tcg_output/``.
    """

    def __init__(self, data_dir: Optional[str] = None):
        self.tool_name = "TestCasesGenerator"
        self._data_dir = data_dir
        self.input_context = None
        self.prompt = ""
        self.brd_content = ""
        self.metadata_content = ""
        self.rag = None
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    # ------------------------------------------------------------------
    # Public DAAN tool API
    # ------------------------------------------------------------------

    def generate_test_cases(
        self, mapping_data: dict[str, Any], **kwargs
    ) -> dict[str, Any]:
        """Generate comprehensive ETL test cases from structured mapping data.

        Args:
            mapping_data: dict with keys:
                mappings (list[dict]): Each dict has *source*, *target*,
                    *columns* (dict), *rules* (dict), *transformations* (dict),
                    *filters* (str), *joins* (str), *schema* (dict).
                brd_content (str, optional): Full BRD text.
                metadata_content (str, optional): Schema / metadata text.
                prompt_template (str, optional): Custom LLM prompt template.

        Returns:
            ``{"status": "ok", "excel_path": "...", "test_case_count": N, "message": "..."}``
            or ``{"status": "error", "errors": ["...", ...]}``
        """
        # ── Validate ──────────────────────────────────────────────────
        if not isinstance(mapping_data, dict):
            return {"status": "error", "errors": ["mapping_data must be a dict"]}

        mappings = mapping_data.get("mappings", [])
        if not mappings:
            return {
                "status": "error",
                "errors": ["No mappings found in mapping_data. Provide a 'mappings' array."],
            }

        # ── Populate internal state from mapping_data ─────────────────
        self.input_context = {"mappings": mappings}
        self.brd_content = mapping_data.get("brd_content", "") or ""
        self.metadata_content = mapping_data.get("metadata_content", "") or ""
        self.prompt = mapping_data.get("prompt_template", "") or ""

        # Also pull BRD / metadata from session input files if not provided
        if self._data_dir:
            self._load_session_files()

        # ── Run the generation pipeline ──────────────────────────────
        result = self.run()

        # ── Persist output ───────────────────────────────────────────
        if result.get("status_code") == 200 and result.get("excel_bytes"):
            output_dir = self._resolve_output_dir()
            excel_path = output_dir / "test_cases_output.xlsx"
            excel_path.write_bytes(result["excel_bytes"])
            logger.info("%s: Excel written to %s", self.tool_name, excel_path)

            df = result.get("dataframe")
            count = len(df) if df is not None and not df.empty else 0

            return {
                "status": "ok",
                "excel_path": result.get("artifact_path") or str(excel_path),
                "test_case_count": count,
                "message": result.get("message", "Test cases generated successfully"),
            }

        return {
            "status": "error",
            "errors": [result.get("message", "Generation failed with no output")],
        }

    # ------------------------------------------------------------------
    # Session-file helpers
    # ------------------------------------------------------------------

    def _load_session_files(self):
        """Read BRD / metadata files from the session inputs directory."""
        if not self._data_dir:
            return
        inputs_dir = Path(self._data_dir)
        if not inputs_dir.exists():
            return
        for f in inputs_dir.iterdir():
            if not f.is_file():
                continue
            name_lower = f.name.lower()
            try:
                content = f.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            if "brd" in name_lower and not self.brd_content:
                self.brd_content = content
                logger.info("%s: Loaded BRD from %s", self.tool_name, f.name)
            elif "metadata" in name_lower and not self.metadata_content:
                self.metadata_content = content
                logger.info("%s: Loaded metadata from %s", self.tool_name, f.name)

    def _resolve_output_dir(self) -> Path:
        if self._data_dir:
            data_path = Path(self._data_dir)
            session_dir = data_path.parent if data_path.name == "inputs" else data_path
            output_dir = session_dir / "tcg_output"
        else:
            output_dir = Path(__file__).resolve().parent / "tcg_output"
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir

    def _resolve_rag_db_path(self) -> str:
        """Return a session-local path for the ChromaDB index."""
        if self._data_dir:
            data_path = Path(self._data_dir)
            session_dir = data_path.parent if data_path.name == "inputs" else data_path
            rag_dir = session_dir / "rag" / "chroma_db_tcg"
        else:
            rag_dir = Path(__file__).resolve().parent / ".chroma_db_tcg"
        rag_dir.mkdir(parents=True, exist_ok=True)
        return str(rag_dir)

    # ------------------------------------------------------------------
    # Internal pipeline
    # ------------------------------------------------------------------

    def run(self) -> dict:
        try:
            if self.rag is None:
                rag_db_path = self._resolve_rag_db_path()
                self.rag = _get_rag_class()(db_path=rag_db_path)
            pairs = _extract_sttm_pairs(self.input_context)
            if not pairs:
                return _result(400, "No STTM pairs found in the mapping data")
            logger.info("STTM pairs found: %d", len(pairs))

            # Build RAG index from BRD + mapping text
            self._build_rag_index(pairs)

            frames = []
            for i, pair in enumerate(pairs, 1):
                logger.info("Generating %d/%d: %s -> %s",
                            i, len(pairs), pair["source"], pair["target"])
                df = self._generate_for_pair(pair)
                if df is not None and not df.empty:
                    frames.append(df)

            if not frames:
                return _result(400, "LLM returned no test cases")

            combined = pd.concat(frames, ignore_index=True)
            for c in _COL_ORDER:
                if c not in combined.columns:
                    combined[c] = ""
            combined = combined[_COL_ORDER]
            excel = _create_excel(combined)
            
            # Save to artifacts if in a session context
            excel_path = None
            if self._data_dir:
                try:
                    data_pth = Path(self._data_dir)
                    session_dir = data_pth.parent if data_pth.name == "inputs" else data_pth
                    artifacts_dir = session_dir / "artifacts"
                    artifacts_dir.mkdir(parents=True, exist_ok=True)
                    
                    # Generate a unique filename
                    ts = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
                    excel_path = artifacts_dir / f"Generated_Test_Cases_{ts}.xlsx"
                    with open(excel_path, "wb") as f:
                        f.write(excel)
                    logger.info("Saved TCG output to artifacts: %s", excel_path)
                except Exception as e:
                    logger.error("Failed to save to artifacts: %s", e)

            return _result(200, f"Generated test cases for {len(pairs)} pair(s)",
                           combined, excel, str(excel_path) if excel_path else None)
        except Exception as exc:
            logger.error("TCG error: %s", exc, exc_info=True)
            return _result(500, str(exc))

    # -- RAG --

    def _build_rag_index(self, pairs: list):
        chunks: list = []
        if self.brd_content and self.brd_content.strip():
            brd = self.brd_content.strip()
            step, overlap = 800, 150
            for start in range(0, len(brd), step - overlap):
                chunks.append(brd[start:start + step])

        # Index ALL input file text into RAG for comprehensive context retrieval
        data = _safe_parse(self.input_context)
        if data:
            all_text = _collect_all_text(data)
            if all_text.strip():
                step, overlap = 800, 150
                for start in range(0, len(all_text), step - overlap):
                    chunks.append(all_text[start:start + step])

        for p in pairs:
            cols = p.get("columns", {})
            cols_str = ", ".join(f"{s}->{t}" for s, t in cols.items()) if cols else "N/A"
            rules_str = ""
            if p.get("rules"):
                rules_str = " Rules: " + "; ".join(f"{k}: {v}" for k, v in p["rules"].items())
            transforms = p.get("transformations", {})
            tx_str = ""
            if transforms:
                tx_str = " Transforms: " + "; ".join(f"{k}: {v}" for k, v in transforms.items())
            chunks.append(f"Mapping: {p['source']} -> {p['target']}. Columns: {cols_str}{rules_str}{tx_str}")

            # Parse transformation steps and index each as a separate semantic chunk
            raw_rows = p.get("raw_rows") or []
            step_descriptions = _parse_transformation_steps(raw_rows)

            # If no raw_rows, try extracting steps from collected context text
            if not step_descriptions:
                data_tmp = _safe_parse(self.input_context)
                if data_tmp:
                    ctx_text = _collect_all_text(data_tmp)
                    ctx_rows = _extract_rows_from_context(ctx_text)
                    if ctx_rows:
                        step_descriptions = _parse_transformation_steps(ctx_rows)

            if step_descriptions:
                for step_name, step_logic in step_descriptions:
                    chunks.append(f"Transformation Step: {step_name}\n{step_logic}")
            else:
                # Fallback: index raw row text
                for row in raw_rows:
                    chunks.append(json.dumps(row, default=str, ensure_ascii=False)[:800])

            # Index LLM-extracted transformations as individual chunks
            for tx_name, tx_logic in p.get("transformations", {}).items():
                if tx_logic and str(tx_logic).strip():
                    chunks.append(f"Transformation: {tx_name} — {tx_logic}")

            # Index each rule as its own chunk for precise retrieval
            for rule_name, rule_desc in p.get("rules", {}).items():
                chunks.append(f"Business Rule: {rule_name} — {rule_desc}")

        if chunks:
            try:
                self.rag.build_index(chunks)
            except Exception as exc:
                logger.warning("RAG build failed (%s) - continuing without", exc)

    def _retrieve_context(self, pair: dict) -> str:
        # Collect ALL input file text — this is the primary context source
        all_input_text = ""
        data = _safe_parse(self.input_context)
        if data:
            all_input_text = _collect_all_text(data)

        # If schema data not in parsed context, read from Inputs/ directory
        inputs_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Inputs")
        if "|--" not in all_input_text and os.path.isdir(inputs_dir):
            for fname in os.listdir(inputs_dir):
                if fname.lower().endswith(".txt"):
                    fpath = os.path.join(inputs_dir, fname)
                    try:
                        with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                            all_input_text += "\n\n=== File: " + fname + " ===\n" + f.read()
                    except OSError:
                        pass

        parts = []
        if self.brd_content and self.brd_content.strip():
            # Cap BRD to avoid overwhelming the prompt
            brd = self.brd_content.strip()
            if len(brd) > 4000:
                brd = brd[:4000] + "\n... (BRD truncated for token budget)"
            parts.append(brd)

        # Multi-query RAG retrieval: use targeted queries per category
        # for best context on rules, joins, calculations, schema
        if self.rag.is_ready:
            rag_seen = set()
            queries = [
                f"business rules RULE1 RULE2 RULE3 RULE4 violation threshold UCL LCL {pair['target']}",
                f"join conditions join keys inner join {pair['source']} {pair['target']}",
                f"PPK PPL PPU PP calculation mean sigma derived column formula",
                f"schema columns source target {pair['source']} {pair['target']} data type",
                f"deduplication windowing top-14 row_number filter type casting transformation",
            ]
            for q in queries:
                results = self.rag.retrieve(q, k=5)
                for r in results:
                    if r not in rag_seen:
                        rag_seen.add(r)
                        parts.append(r)

        # Include full input text but cap to leave room for LLM output
        # (~10K chars of context + ~8K template leaves ~12K tokens for response)
        if all_input_text.strip():
            if len(all_input_text) > 25000:
                all_input_text = all_input_text[:25000] + "\n... (input truncated for token budget)"
            parts.append(all_input_text)

        return "\n\n".join(parts) if parts else ""

    # -- LLM generation --

    def _generate_for_pair(self, pair: dict) -> pd.DataFrame:
        try:
            brd_ctx = self._retrieve_context(pair)
            prompt_text = _build_prompt(pair, brd_ctx, self.prompt, self.metadata_content)

            # Parse schemas so _fill_empty_cells can also use actual column names
            src_schema_cols, tgt_schema_cols = _parse_spark_schemas(brd_ctx)
            pair["_src_schema_cols"] = src_schema_cols
            pair["_tgt_schema_cols"] = tgt_schema_cols

            llm = _create_llm()
            resp = llm.invoke(prompt_text)
            raw = getattr(resp, "content", None) or ""
            if not raw.strip():
                logger.warning("LLM returned empty response for %s->%s", pair["source"], pair["target"])
                return pd.DataFrame()

            cases = _parse_json(raw)
            if not cases:
                logger.warning("Could not parse LLM JSON for %s->%s; response preview: %.500s",
                               pair["source"], pair["target"], raw[:500])
                return pd.DataFrame()

            # If the model returns a small default set, request additional coverage.
            cases = _expand_cases_if_needed(cases, pair, llm)

            # Post-process: fill ALL empty cells (SQL, descriptions, etc.)
            cases = _fill_empty_cells(cases, pair, llm)

            # Quality check: if >40% of important cells are empty, retry once
            empty_ratio = _empty_cell_ratio(cases)
            if empty_ratio > 0.4:
                logger.warning("%.0f%% cells empty — retrying generation", empty_ratio * 100)
                resp2 = llm.invoke(prompt_text + "\n\nCRITICAL: Every field in every row MUST be filled. No empty cells.")
                raw2 = getattr(resp2, "content", None) or ""
                cases2 = _parse_json(raw2)
                if cases2:
                    ratio2 = _empty_cell_ratio(cases2)
                    if ratio2 < empty_ratio:
                        cases = _fill_empty_cells(cases2, pair, llm)

            df = pd.DataFrame(cases)
            col_map = {
                "requirement": "Requirement", "test_case_name": "Test Case Name",
                "description": "Description", "pre_condition": "Pre-condition",
                "step_number": "Step Number", "step_description": "Step Description",
                "expected_result": "Expected Result",
                "source_validation": "Source Validation",
                "target_validation": "Target Validation",
            }
            df.rename(columns=col_map, inplace=True)
            for c in _COL_ORDER:
                if c not in df.columns:
                    df[c] = ""
            return df[_COL_ORDER]
        except Exception as exc:
            logger.error("LLM generation failed for %s->%s: %s",
                         pair["source"], pair["target"], exc, exc_info=True)
            return pd.DataFrame()


# ====================================================================
#  Safe parser: JSON string, Python repr string, or raw dict
# ====================================================================

def _safe_parse(input_context) -> dict | None:
    """Parse input_context into a dict regardless of format."""
    if isinstance(input_context, dict):
        return input_context
    if not isinstance(input_context, str) or not input_context.strip():
        return None
    s = input_context.strip()
    # Try JSON first
    try:
        obj = json.loads(s)
        if isinstance(obj, dict):
            return obj
    except (json.JSONDecodeError, ValueError):
        pass
    # Try Python literal (handles single-quote dicts from repr())
    try:
        obj = ast.literal_eval(s)
        if isinstance(obj, dict):
            return obj
    except (ValueError, SyntaxError):
        pass
    logger.warning("Cannot parse input_context; type=%s preview: %s",
                   type(input_context).__name__, s[:300])
    return None


# ====================================================================
#  STTM extraction (Legacy Heuristics Removed for DAAN 5.1 Migration)
# ====================================================================

def _extract_sttm_pairs(input_context) -> list:
    """Parse input_context and return list of STTM pair dicts.

    In DAAN 5.1, this is handled by the Planning (Dynamic) Agent.
    This Action Agent expects a structured JSON payload.
    """
    data = _safe_parse(input_context)
    if not data:
        return []

    # Support for the structured Planning Agent output
    if isinstance(data, dict) and "mappings" in data:
        return data["mappings"]
    if isinstance(data, list):
        return data

    logger.warning("No structured mapping data found in input_context")
    return []


# ====================================================================
#  Input text extraction — feed all files to RAG / LLM
# ====================================================================

def _collect_all_text(data: dict) -> str:
    """Recursively extract all textual content from the SCM context dict.

    Handles both partition-based and full_context_mode formats.
    """
    parts: list[str] = []
    for key, value in data.items():
        if str(key).startswith("_"):
            continue

        if isinstance(value, str):
            parts.append(f"=== File: {key} ===\n{value}")

        elif isinstance(value, dict):
            # Full-context format: {Type, Purpose, Content}
            content = value.get("Content", value)
            if isinstance(content, str):
                parts.append(f"=== File: {key} ===\n{content}")
            elif isinstance(content, list):
                for item in content:
                    if not isinstance(item, dict):
                        continue
                    inner = item.get("content", item.get("Content", {}))
                    if isinstance(inner, dict):
                        rows = inner.get("rows", [])
                        cols = inner.get("columns", [])
                        sheet = inner.get("sheet_name", "")
                        if rows:
                            parts.append(f"=== File: {key} / Sheet: {sheet} ===")
                            if cols:
                                parts.append(f"Columns: {cols}")
                            for r in rows[:200]:
                                parts.append(json.dumps(r, default=str, ensure_ascii=False))
                    elif isinstance(inner, str):
                        parts.append(f"=== File: {key} ===\n{inner[:8000]}")
            elif isinstance(content, dict):
                parts.append(f"=== File: {key} ===\n{json.dumps(content, default=str, ensure_ascii=False)[:8000]}")

        elif isinstance(value, list):
            # Partition-based format
            for item in value:
                if not isinstance(item, dict):
                    continue
                content = item.get("Content", item)
                partition = item.get("Partition", "data")
                if isinstance(content, dict):
                    rows = content.get("rows", [])
                    cols = content.get("columns", [])
                    sheet = content.get("sheet_name", "")
                    if rows:
                        parts.append(f"=== File: {key} / {partition} ===")
                        if cols:
                            parts.append(f"Columns: {cols}")
                        for r in rows[:200]:
                            parts.append(json.dumps(r, default=str, ensure_ascii=False))
                    else:
                        parts.append(f"=== File: {key} / {partition} ===\n{json.dumps(content, default=str, ensure_ascii=False)[:8000]}")
                elif isinstance(content, str):
                    parts.append(f"=== File: {key} ===\n{content[:8000]}")

    return "\n\n".join(parts)


# Legacy LLM extraction removed for Planning Agent migration

# Legacy heuristics removed

# ====================================================================
#  Schema parsing — extract actual column/table names from input text
# ====================================================================

_SPARK_SCHEMA_RE = re.compile(r"\|--\s+(\w+):\s+(\S+)")
_TABLE_NAME_RE = re.compile(
    r"\[(\w+)\]\.\[(\w+)\]",  # [schema].[table] with brackets
)
_TABLE_NAME_RE2 = re.compile(
    r"(?<!\[)(\w+)\.(\w+)(?!\])",  # schema.table without brackets
)


def _parse_spark_schemas(text: str) -> tuple:
    """Parse Spark-style schema blocks from text.

    Returns (src_cols, tgt_cols) where each is a list of (col_name, data_type).
    Detects "src schema" / "source schema" and "target schema" / "tgt schema" labels.
    """
    if not text:
        return [], []

    src_cols, tgt_cols = [], []
    lines = text.splitlines()
    current = None  # 'src' or 'tgt'

    for line in lines:
        ll = line.strip().lower()
        if any(k in ll for k in ("src schema", "source schema", "source root")):
            current = "src"
            continue
        if any(k in ll for k in ("target schema", "tgt schema", "target root")):
            current = "tgt"
            continue
        if ll == "root":
            continue

        m = _SPARK_SCHEMA_RE.search(line)
        if m:
            col_name, dtype = m.group(1), m.group(2)
            if current == "src":
                src_cols.append((col_name, dtype))
            elif current == "tgt":
                tgt_cols.append((col_name, dtype))

    return src_cols, tgt_cols


def _extract_table_names(text: str) -> tuple:
    """Try to find actual source/target table names from transformation logic.

    Returns (src_table, tgt_table). Either may be empty string if not found.
    """
    src_table = tgt_table = ""
    if not text:
        return src_table, tgt_table

    # Look for [schema].[table] patterns first (e.g. [edw].[VW_NELSON_...])
    all_matches = []
    for m in _TABLE_NAME_RE.finditer(text):
        all_matches.append((m.group(1), m.group(2)))
    for m in _TABLE_NAME_RE2.finditer(text):
        all_matches.append((m.group(1), m.group(2)))

    for schema, table in all_matches:
        tbl = f"{schema}.{table}"
        tl = table.lower()
        if any(k in tl for k in ("vw_", "view", "batch", "src", "source")):
            if not src_table:
                src_table = tbl
        elif any(k in tl for k in ("dim_", "fact_", "established", "target", "tgt", "spec")):
            if not tgt_table:
                tgt_table = tbl

    return src_table, tgt_table


def _parse_transformation_steps(raw_rows: list) -> list:
    """Parse Nelson_Logic-style rows into (step_name, step_description) pairs.

    Detects format where:
    - Row 0 has 'Cell' = 'Logic Description' and numbered cols = step names
    - Row 1 has 'Cell' = 'Logic' and numbered cols = step descriptions
    Falls back to extracting any string values from rows.
    """
    if not raw_rows or len(raw_rows) < 2:
        return []

    # Detect header row (step names) and logic row (step descriptions)
    header_row = logic_row = None
    for row in raw_rows:
        cell_val = str(row.get("Cell", "")).strip().lower()
        if "description" in cell_val or "desciption" in cell_val:
            header_row = row
        elif cell_val == "logic":
            logic_row = row

    if not header_row or not logic_row:
        # Try: first row = headers, second row = logic
        r0 = raw_rows[0]
        r1 = raw_rows[1] if len(raw_rows) > 1 else None
        r0_cell = str(r0.get("Cell", "")).strip().lower()
        if r0_cell in ("logic description", "logic desciption", "step", "name"):
            header_row = r0
            logic_row = r1

    if not header_row or not logic_row:
        return []

    steps = []
    for key in header_row:
        if key == "Cell":
            continue
        step_name = str(header_row.get(key, "")).strip()
        step_logic = str(logic_row.get(key, "")).strip()
        if step_name and step_name.lower() != "nan" and step_logic and step_logic.lower() != "nan":
            steps.append((step_name, step_logic))

    return steps


def _extract_rows_from_context(text: str) -> list:
    """Extract JSON row dicts from collected context text.

    _collect_all_text outputs rows as JSON lines; this parses them back into
    dicts so _parse_transformation_steps can find header/logic rows.
    """
    if not text:
        return []
    rows = []
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            obj = json.loads(line)
            if isinstance(obj, dict) and ("Cell" in obj or "cell" in obj):
                rows.append(obj)
        except (json.JSONDecodeError, ValueError):
            pass
    return rows


# ====================================================================
#  Post-process: fill empty cells (SQL + all descriptive fields)
# ====================================================================

_REQUIRED_KEYS = [
    "requirement", "test_case_name", "description", "pre_condition",
    "step_number", "step_description", "expected_result",
    "source_validation", "target_validation",
]

# Keys that are allowed to be empty for multi-step rows (step 2+)
_MULTI_STEP_ALLOW_EMPTY = {"test_case_name", "description", "pre_condition", "requirement"}


def _target_case_count(pair: dict) -> int:
    """Compute a practical minimum number of test cases for one STTM pair."""
    col_count = len(pair.get("columns", {}) or {})
    rule_count = len(pair.get("rules", {}) or {})
    tx_count = len(pair.get("transformations", {}) or {})
    step_count = len(_parse_transformation_steps(pair.get("raw_rows") or []))

    # Coverage-driven estimate with a floor to avoid tiny default outputs.
    target = max(12, col_count + rule_count + tx_count + step_count + 6)
    return min(80, target)


def _expand_cases_if_needed(cases: list, pair: dict, llm) -> list:
    """Request additional unique test cases when initial generation is too small."""
    if not cases:
        return cases

    target = _target_case_count(pair)
    if len(cases) >= target:
        return cases

    need = target - len(cases)
    src, tgt = pair["source"], pair["target"]

    existing_names = []
    for c in cases:
        nm = str(c.get("test_case_name", "") or "").strip()
        if nm:
            existing_names.append(nm)

    cols_info = ", ".join(f"{s}->{t}" for s, t in (pair.get("columns", {}) or {}).items()) or "N/A"
    rules_info = "; ".join(f"{k}: {v}" for k, v in (pair.get("rules", {}) or {}).items()) or "N/A"
    tx_info = "; ".join(f"{k}: {v}" for k, v in (pair.get("transformations", {}) or {}).items()) or "N/A"

    expand_prompt = f"""You generated too few test cases for this mapping.
Generate EXACTLY {need} ADDITIONAL, UNIQUE test cases (do not repeat existing ones).

Source table: {src}
Target table: {tgt}
Column mappings: {cols_info}
Business rules: {rules_info}
Transformations: {tx_info}

Existing test case names (avoid duplicates):
{json.dumps(existing_names[:200], indent=2, default=str)}

Rules:
- Focus on missing coverage: per-column validation, business rules, transformations, joins/filters, edge cases
- Every row must have all 9 fields non-empty (except multi-step rows where step 2+ may keep test_case_name/description/pre_condition empty)
- source_validation must be valid SQL against {src}
- target_validation must be valid SQL against {tgt}

Return ONLY a JSON array of exactly {need} objects, each with keys:
requirement, test_case_name, description, pre_condition, step_number,
step_description, expected_result, source_validation, target_validation
"""

    try:
        resp = llm.invoke(expand_prompt)
        raw = getattr(resp, "content", None) or ""
        extra = _parse_json(raw)
        if not extra:
            logger.warning("Coverage expansion failed to parse JSON")
            return cases

        existing_name_set = {
            str(c.get("test_case_name", "") or "").strip().lower()
            for c in cases
            if str(c.get("test_case_name", "") or "").strip()
        }
        deduped_extra = []
        for item in extra:
            if not isinstance(item, dict):
                continue
            name = str(item.get("test_case_name", "") or "").strip().lower()
            if name and name in existing_name_set:
                continue
            if name:
                existing_name_set.add(name)
            deduped_extra.append(item)

        if deduped_extra:
            logger.info("Coverage expansion added %d additional test case(s)", len(deduped_extra))
            return cases + deduped_extra
    except Exception as exc:
        logger.warning("Coverage expansion LLM call failed: %s", exc)

    return cases


def _empty_cell_ratio(cases: list) -> float:
    """Return ratio of empty important cells (0.0 = all filled, 1.0 = all empty)."""
    if not cases:
        return 1.0
    total = empty = 0
    for c in cases:
        step = c.get("step_number", 1)
        try:
            step = int(step)
        except (ValueError, TypeError):
            step = 1
        for key in _REQUIRED_KEYS:
            if step > 1 and key in _MULTI_STEP_ALLOW_EMPTY:
                continue
            total += 1
            val = str(c.get(key, "") or "").strip()
            if not val:
                empty += 1
    return empty / total if total else 1.0


def _fill_empty_cells(cases: list, pair: dict, llm) -> list:
    """Ensure every test case row has non-empty fields.

    Repairs both SQL validation columns AND descriptive columns
    (step_description, expected_result, etc.).
    """
    if not cases:
        return cases

    src, tgt = pair["source"], pair["target"]

    # Collect indices of rows with ANY empty required field
    empty_indices = []
    for i, c in enumerate(cases):
        step = c.get("step_number", 1)
        try:
            step = int(step)
        except (ValueError, TypeError):
            step = 1

        for key in _REQUIRED_KEYS:
            # Multi-step rows: test_case_name/description/pre_condition can be empty for steps 2+
            if step > 1 and key in _MULTI_STEP_ALLOW_EMPTY:
                continue
            val = str(c.get(key, "") or "").strip()
            if not val:
                empty_indices.append(i)
                break

    if not empty_indices:
        return cases  # all rows filled

    logger.info("Found %d rows with empty cells — repairing", len(empty_indices))

    # Build compact repair items
    repair_items = []
    for idx in empty_indices:
        c = cases[idx]
        item = {"index": idx}
        for key in _REQUIRED_KEYS:
            item[key] = c.get(key, "")
        repair_items.append(item)

    cols_info = ", ".join(f"{s}->{t}" for s, t in pair.get("columns", {}).items())
    src_cols_str = ", ".join(c for c, _ in pair.get("_src_schema_cols", []))
    tgt_cols_str = ", ".join(c for c, _ in pair.get("_tgt_schema_cols", []))

    repair_prompt = f"""Some test case rows have missing/empty fields. Fill in ALL empty fields.

Source table: {src}
Target table: {tgt}
Column mappings: {cols_info or 'N/A'}
Source columns: {src_cols_str or 'N/A'}
Target columns: {tgt_cols_str or 'N/A'}

RULES:
- source_validation: Must be a valid SQL SELECT query against {src}
- target_validation: Must be a valid SQL SELECT query against {tgt}
- step_description: Describe the validation step (what to test and how)
- expected_result: Describe what the correct outcome should be
- requirement: Name the requirement being tested (e.g. "Schema Validation", "Row Count Match")
- test_case_name: Short name for the test case
- description: Brief description of what this test verifies
- pre_condition: What must be true before running this test
- Use ONLY actual column names ({src_cols_str or 'from mappings'}) and table names ({src}, {tgt})

Rows needing repair:
{json.dumps(repair_items[:20], indent=2, default=str)}

Return a JSON array. Each element must have "index" plus ALL 9 fields filled:
  "index", "requirement", "test_case_name", "description", "pre_condition",
  "step_number", "step_description", "expected_result",
  "source_validation", "target_validation"

Keep existing non-empty values. Only fill in the empty ones.
Return ONLY the JSON array."""

    try:
        resp = llm.invoke(repair_prompt)
        raw = getattr(resp, "content", None) or ""
        repairs = _parse_json(raw)
        if repairs:
            repair_map = {r["index"]: r for r in repairs if isinstance(r, dict) and "index" in r}
            for idx in empty_indices:
                r = repair_map.get(idx, {})
                for key in _REQUIRED_KEYS:
                    current = str(cases[idx].get(key, "") or "").strip()
                    if not current:
                        new_val = str(r.get(key, "") or "").strip()
                        if new_val:
                            cases[idx][key] = new_val
            logger.info("Cell repair: processed %d rows", len(empty_indices))
        else:
            logger.warning("Cell repair: could not parse LLM response")
    except Exception as exc:
        logger.warning("Cell repair LLM call failed: %s", exc)

    # Final safety net: ensure SQL columns are never empty
    for i, c in enumerate(cases):
        if not str(c.get("source_validation", "") or "").strip():
            cases[i]["source_validation"] = f"SELECT * FROM {src}"
        if not str(c.get("target_validation", "") or "").strip():
            cases[i]["target_validation"] = f"SELECT * FROM {tgt}"

    return cases


# ====================================================================
#  Prompt builder - uses catalog prompt from Excel (no hardcoding)
# ====================================================================

def _build_prompt(pair, brd_ctx, catalog_prompt="", metadata_content=""):
    src, tgt = pair["source"], pair["target"]
    col_maps = pair.get("columns", {})
    rules = pair.get("rules", {})
    transforms = pair.get("transformations", {})
    filters_str = pair.get("filters", "") or "(none)"
    joins_str = pair.get("joins", "") or "(none)"
    schema = pair.get("schema", {})

    # ---- Parse actual schemas from input context (Schema_Definition.txt etc.) ----
    all_ctx = brd_ctx or ""
    src_schema_cols, tgt_schema_cols = _parse_spark_schemas(all_ctx)
    found_src_table, found_tgt_table = _extract_table_names(all_ctx)

    # Use discovered table names if the pair has generic/LLM-guessed names
    if found_src_table:
        src = found_src_table
    if found_tgt_table:
        tgt = found_tgt_table

    # Build explicit column lists for new prompt placeholders
    if src_schema_cols:
        src_columns = "\n".join(f"  - {name} ({dtype})" for name, dtype in src_schema_cols)
    else:
        src_columns = "\n".join(f"  - {c}" for c in col_maps.keys()) if col_maps else "(see column mappings)"

    if tgt_schema_cols:
        tgt_columns = "\n".join(f"  - {name} ({dtype})" for name, dtype in tgt_schema_cols)
    else:
        tgt_columns = "\n".join(f"  - {c}" for c in col_maps.values()) if col_maps else "(see column mappings)"

    cols_block = "\n".join(f"  - {s} -> {t}" for s, t in col_maps.items()) if col_maps else "  (not specified in mapping)"

    # Build rules_block from explicit rules
    rules_lines = []
    if rules:
        rules_lines.extend(f"  - {col}: {rule}" for col, rule in rules.items())
    rules_block = "\n".join(rules_lines) if rules_lines else "(none)"

    # Build logic_block from ALL transformation data
    logic_lines = []
    if transforms:
        for col, tx in transforms.items():
            logic_lines.append(f"  - {col}: {tx}")

    # Parse raw_rows: detect Nelson_Logic-style format (header row + logic row)
    # where columns are numbered step IDs and rows contain step descriptions
    raw_rows = pair.get("raw_rows") or []
    step_descriptions = _parse_transformation_steps(raw_rows)

    # If no raw_rows or parsing failed, try extracting steps from the context text
    # (brd_ctx contains the collected text from Nelson_Logic via _collect_all_text)
    if not step_descriptions:
        ctx_rows = _extract_rows_from_context(all_ctx)
        if ctx_rows:
            step_descriptions = _parse_transformation_steps(ctx_rows)

    if step_descriptions:
        for step_name, step_logic in step_descriptions:
            logic_lines.append(f"  Step: {step_name}\n    {step_logic}")
    elif raw_rows:
        # Fallback: dump raw rows but more compactly
        for row in raw_rows:
            row_str = json.dumps(row, default=str, ensure_ascii=False)
            if len(row_str) > 1500:
                row_str = row_str[:1500] + "..."
            logic_lines.append(f"  - RAW: {row_str}")
    logic_block = "\n".join(logic_lines) if logic_lines else "(none)"

    # Build join_keys from pair data or transformation logic
    join_keys = joins_str
    if join_keys == "(none)":
        # Try to extract join keys from logic text
        join_match = re.search(r"[Jj]oins?\s.*?on\s+(\d+\s+keys?:?\s*.*?)(?:\.|$)", all_ctx)
        if join_match:
            join_keys = join_match.group(0)

    # Legacy schema_block (kept for backward compat with old prompt format)
    schema_lines = []
    if src_schema_cols:
        schema_lines.append("SOURCE TABLE COLUMNS:")
        for col_name, dtype in src_schema_cols:
            schema_lines.append(f"  - {col_name} ({dtype})")
    if tgt_schema_cols:
        schema_lines.append("TARGET TABLE COLUMNS:")
        for col_name, dtype in tgt_schema_cols:
            schema_lines.append(f"  - {col_name} ({dtype})")
    if schema_lines:
        schema_block = "\n".join(schema_lines)
    elif schema:
        schema_block = "\n".join(f"  - {col}: {dtype}" for col, dtype in schema.items())
    else:
        schema_block = "(infer from column mappings)"

    brd_block = brd_ctx.strip() if brd_ctx and brd_ctx.strip() else "(No BRD provided)"

    # Build blocks that the catalog template may reference under different names
    rules_str = rules_block  # "{rules}" alias
    transforms_str = logic_block  # "{transformations}" alias
    col_mappings_str = cols_block  # "{column_mappings}" alias
    mapping_record_str = f"Source: {src}, Target: {tgt}, Columns: {cols_block}"

    # Source/target schema strings for catalog placeholders
    if src_schema_cols:
        src_schema_str = "\n".join(f"  - {n} ({d})" for n, d in src_schema_cols)
    else:
        src_schema_str = src_columns

    if tgt_schema_cols:
        tgt_schema_str = "\n".join(f"  - {n} ({d})" for n, d in tgt_schema_cols)
    else:
        tgt_schema_str = tgt_columns

    # Use the catalog prompt from Excel (Archetypes/Data Pipeline/Data Pipeline.xlsx)
    # with variable substitution — no hardcoded prompt
    if catalog_prompt and catalog_prompt.strip():
        template = catalog_prompt.strip()
        # Substitute known placeholders into the Excel template
        # NOTE: longer placeholders are replaced before shorter ones to avoid partial matches
        subs = {
            # Catalog prompt placeholders (from AG072 refine_prompt)
            "{source_table}": src,
            "{target_table}": tgt,
            "{source_schema}": src_schema_str,
            "{target_schema}": tgt_schema_str,
            "{column_mappings}": col_mappings_str,
            "{mapping_record}": mapping_record_str,
            "{brd_content}": brd_block,
            "{metadata_content}": metadata_content or "(none)",
            "{rules}": rules_str,
            "{transformations}": transforms_str,
            "{filter}": filters_str,
            "{join conditions}": join_keys,
            "{sourc col name}": src_columns,
            "{target col name}": tgt_columns,
            # Legacy/internal placeholders
            "{src_table}": src,
            "{tgt_table}": tgt,
            "{src}": src,
            "{tgt}": tgt,
            "{src_columns}": src_columns,
            "{tgt_columns}": tgt_columns,
            "{cols_block}": cols_block,
            "{rules_block}": rules_block,
            "{filters_str}": filters_str,
            '{filters_str if filters_str else "(none)"}': filters_str,
            "{joins_str}": joins_str,
            '{joins_str if joins_str else "(none)"}': joins_str,
            "{join_keys}": join_keys,
            "{schema_block}": schema_block,
            "{logic_block}": logic_block,
            "{brd_block}": brd_block,
        }
        for placeholder, value in subs.items():
            template = template.replace(placeholder, value)

        # The catalog prompt may say "Tabular format" but our parser expects JSON.
        # Append a JSON output override so the LLM returns parseable JSON.
        if "json" not in template.lower()[-500:]:
            template += (
                "\n\n**IMPORTANT: Return the test cases as a JSON array (not a table).**\n"
                "Each element must have exactly these 9 keys:\n"
                "requirement, test_case_name, description, pre_condition, step_number, "
                "step_description, expected_result, source_validation, target_validation\n"
                "Return ONLY the JSON array. No markdown fences, no explanations."
            )
        return template

    # Comprehensive fallback prompt — coverage-driven, uses all input data
    return (
        f"You are an expert Data/ETL QA engineer specializing in comprehensive test case generation.\n"
        f"Your task: Analyze ALL input data thoroughly and generate EVERY valid, logical test case for {src} → {tgt}.\n\n"
        f"## INPUT DATA (analyze ALL of this — every column, every rule, every transformation)\n\n"
        f"### Source → Target Mapping\n"
        f"Mapping: {src} → {tgt}\n\n"
        f"### Column Mappings (STTM)\n{cols_block}\n\n"
        f"### Business Rules (generate one test per rule)\n{rules_block}\n\n"
        f"### Filters Applied\n{filters_str}\n\n"
        f"### Join Conditions\n{joins_str}\n\n"
        f"### Schema Definition\n{schema_block}\n\n"
        f"### Transformation Logic (generate one test per transformation)\n{logic_block}\n\n"
        f"### BRD / Business Requirements\n{brd_block}\n\n"
        f"## ANALYSIS PHASE (do this before generating)\n"
        f"1. EXTRACT all column mappings from the input data\n"
        f"2. EXTRACT all business rules (explicit from rules AND implicit from BRD/logic)\n"
        f"3. IDENTIFY all transformations (type conversions, calculations, string ops, aggregations, lookups, derived columns, CASE/IF logic)\n"
        f"4. IDENTIFY all data quality constraints (NOT NULL, unique keys, referential integrity, valid ranges, enums)\n"
        f"5. IDENTIFY all filter/join/dedup/window operations\n"
        f"6. LIST all target columns that need validation\n\n"
        f"## TEST CASE CATEGORIES (generate ALL applicable)\n\n"
        f"### Category 1: Schema & Metadata Validation\n"
        f"- Column count match between source and target\n"
        f"- Column name validation in target\n"
        f"- Data type validation for each column\n"
        f"- Nullable constraint validation\n"
        f"- Primary key / unique key validation\n\n"
        f"### Category 2: Row Count & Reconciliation\n"
        f"- Total row count match (source vs target)\n"
        f"- Row count after filters applied\n"
        f"- Row count per group/partition (if applicable)\n"
        f"- Duplicate detection in target\n"
        f"- Orphan record detection\n\n"
        f"### Category 3: Data Mapping Validation (one per column mapping)\n"
        f"- For EACH source→target column pair: validate data values match\n"
        f"- For derived/calculated columns: recompute from source and compare\n"
        f"- For lookup columns: validate lookup join correctness\n"
        f"- NULL handling validation per column\n\n"
        f"### Category 4: Transformation Validation (one per transformation step)\n"
        f"- For EACH transformation: validate correct application\n"
        f"- Examples: TRIM/UPPER/LOWER, type casting, date formatting, concatenation, substring,\n"
        f"  mathematical calculations, conditional logic (CASE/IF), aggregations, window functions\n\n"
        f"### Category 5: Business Rule Validation (one per rule)\n"
        f"- For EACH business rule: generate query returning VIOLATING rows\n"
        f"- If rule has multiple outputs: validate EACH output\n"
        f"- Threshold checks (>, <, BETWEEN)\n"
        f"- Referential integrity checks\n"
        f"- Cross-field validation rules\n\n"
        f"### Category 6: Filter & Join Validation\n"
        f"- Filter inclusion: correct rows pass the filter\n"
        f"- Filter exclusion: filtered rows are NOT in target\n"
        f"- Join key match validation\n"
        f"- Unmatched/dropped record detection\n"
        f"- Duplicate explosion prevention from joins\n\n"
        f"### Category 7: Dedup & Window Validation (if applicable)\n"
        f"- Deduplication correctness\n"
        f"- Window function boundaries (ROW_NUMBER, RANK, top-N)\n"
        f"- Ordering and partition-by correctness\n\n"
        f"### Category 8: Edge Cases & Data Quality\n"
        f"- NULL value handling in source vs target\n"
        f"- Empty string vs NULL handling\n"
        f"- Boundary values (min/max for numeric, date ranges)\n"
        f"- Special character handling\n\n"
        f"## SQL REQUIREMENTS\n"
        f"- Use ACTUAL column names from the schema/mapping data above\n"
        f"- source_validation: Valid SQL SELECT against {src}\n"
        f"- target_validation: Valid SQL SELECT against {tgt}\n"
        f"- Business rule queries MUST return violating rows (SELECT cols WHERE violation), NOT just counts\n"
        f"- If validation requires columns not in target, JOIN with source/lookup tables\n\n"
        f"## MULTI-STEP RULE\n"
        f"- Step 1: includes test_case_name, description, pre_condition\n"
        f"- Steps 2+: set test_case_name, description, pre_condition to \"\"\n"
        f"- Most test cases should be single-step unless logically sequential\n\n"
        f"## QUANTITY TARGET\n"
        f"- Generate AT MINIMUM one test case per target column\n"
        f"- Generate AT MINIMUM one test case per business rule\n"
        f"- Generate AT MINIMUM one test case per transformation step\n"
        f"- Aim for 20-50+ test cases for thorough coverage\n"
        f"- DO NOT stop at a minimal set — generate ALL valid test cases the data supports\n\n"
        f"## OUTPUT FORMAT\n"
        f"Return JSON array only. Each element has exactly 9 keys:\n"
        f"requirement, test_case_name, description, pre_condition, step_number,\n"
        f"step_description, expected_result, source_validation, target_validation\n\n"
        f"CRITICAL:\n"
        f"- Every row MUST have non-empty source_validation and target_validation SQL\n"
        f"- Every row MUST have non-empty step_description and expected_result\n"
        f"- Use ACTUAL table names ({src}, {tgt}) — never generic placeholders\n"
        f"- Return ONLY the JSON array. No markdown fences, no explanations.\n"
    )


# ====================================================================
#  Helpers
# ====================================================================

def _result(code, msg, df=None, excel=None, artifact_path=None):
    return {"status_code": code, "message": msg,
            "dataframe": df if df is not None else pd.DataFrame(),
            "excel_bytes": excel,
            "artifact_path": artifact_path}


def _parse_json(text):
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    try:
        r = json.loads(text)
        return r if isinstance(r, list) else None
    except json.JSONDecodeError:
        pass
    m = re.search(r"\[", text)
    if m:
        depth = 0
        for i in range(m.start(), len(text)):
            if text[i] == "[":
                depth += 1
            elif text[i] == "]":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[m.start(): i + 1])
                    except json.JSONDecodeError:
                        break

    # Truncated JSON recovery: try to salvage partial array
    if m:
        partial = text[m.start():]
        # Close any open strings and objects, then close the array
        for suffix in ['}]', '"}]', '"}}]', '"}]', ']']:
            try:
                fixed = partial.rstrip().rstrip(',') + suffix
                result = json.loads(fixed)
                if isinstance(result, list) and result:
                    logger.info("Recovered %d items from truncated JSON", len(result))
                    return result
            except (json.JSONDecodeError, ValueError):
                continue

        # Last resort: extract individual JSON objects from the partial text
        items = []
        obj_pattern = re.compile(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}')
        for obj_match in obj_pattern.finditer(partial):
            try:
                obj = json.loads(obj_match.group())
                if isinstance(obj, dict) and any(k in obj for k in
                        ("requirement", "test_case_name", "source_validation",
                         "step_description", "expected_result")):
                    items.append(obj)
            except (json.JSONDecodeError, ValueError):
                continue
        if items:
            logger.info("Extracted %d items from truncated JSON via regex", len(items))
            return items

    return None


def _create_excel(df):
    try:
        from openpyxl.styles import Alignment, Font, Border, Side, PatternFill
        import openpyxl

        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            df.to_excel(writer, index=False, sheet_name="Test Cases")
            ws = writer.sheets["Test Cases"]
            border = Border(left=Side(style="thin"), right=Side(style="thin"),
                            top=Side(style="thin"), bottom=Side(style="thin"))
            hdr_fill = PatternFill(start_color="4B0082", end_color="4B0082", fill_type="solid")
            for cell in ws[1]:
                cell.font = Font(bold=True, color="FFFFFF", size=11)
                cell.fill = hdr_fill
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
                cell.border = border
            for row_idx in range(2, len(df) + 2):
                for col_idx in range(1, len(_COL_ORDER) + 1):
                    c = ws.cell(row=row_idx, column=col_idx)
                    c.border = border
                    c.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
            for i in range(1, len(_COL_ORDER) + 1):
                ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = 25
            ws.freeze_panes = ws["A2"]
        buf.seek(0)
        return buf.getvalue()
    except Exception as exc:
        logger.error("Excel creation failed: %s", exc)
        return None
