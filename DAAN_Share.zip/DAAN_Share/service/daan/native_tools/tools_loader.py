import importlib
import importlib.util
import re
import os


def _camel_to_snake(name: str) -> str:
    """Convert CamelCase to snake_case (e.g. PowerBIReportGenerator -> power_bi_report_generator)."""
    s1 = re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1_\2', name)
    return re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', s1).lower()


def _resolve_local_tool_reference(tool_config):
    if isinstance(tool_config, str):
        ref = tool_config.strip()
        if not ref or "." not in ref:
            return None, None, None, ref
        class_name, function_name = ref.split(".", 1)
        # Derive snake_case module name from the CamelCase class name.
        # e.g. "PowerBIReportGenerator" -> "daan.native_tools.power_bi_report_generator"
        snake_module = _camel_to_snake(class_name)
        module_name = f"daan.native_tools.{snake_module}"
        return module_name, class_name, function_name, ref

    if not isinstance(tool_config, dict):
        return None, None, None, str(tool_config)

    module_name = tool_config.get("module")
    class_name = tool_config.get("class_name")
    function_name = tool_config.get("function_name") or tool_config.get("method")
    display_name = tool_config.get("name") or f"{class_name}.{function_name}" if class_name else "unknown"
    return module_name, class_name, function_name, display_name


def load_local_tool(module_name, class_name, function_name=None, display_name="unknown", tool_kwargs=None):
    if tool_kwargs is None:
        tool_kwargs = {}
        
    try:
        try:
            module = importlib.import_module(module_name)
        except ImportError:
            # Fallback: try the CamelCase module name for backward compat
            # (e.g. daan.native_tools.JiraStoryPublisher)
            fallback = f"daan.native_tools.{class_name}"
            if fallback != module_name:
                module = importlib.import_module(fallback)
                module_name = fallback
            else:
                raise

        # Handle package/module name collision:
        # If module_name resolved to a package (directory with __init__.py)
        # instead of the .py file, and the class isn't in __init__.py,
        # try loading the .py file directly via its file path.
        if not hasattr(module, class_name) and hasattr(module, "__path__"):
            pkg_dir = module.__path__[0]
            sibling_py = os.path.join(os.path.dirname(pkg_dir), os.path.basename(pkg_dir) + ".py")
            if os.path.isfile(sibling_py):
                unique_name = module_name + "_file"
                spec = importlib.util.spec_from_file_location(unique_name, sibling_py)
                if spec and spec.loader:
                    file_module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(file_module)
                    module = file_module
                    print(f"Resolved {class_name} from file '{sibling_py}' (package name collision)")

        tool_class = getattr(module, class_name)

        if function_name:
            # Instantiate with injected kwargs!
            tool_instance = tool_class(**tool_kwargs)
            tool_function = getattr(tool_instance, function_name)
            print(f"Loaded local function tool: {display_name} from {module_name} with kwargs: {list(tool_kwargs.keys())}")
            return tool_function

        print(f"Loaded local class tool: {class_name} from {module_name}")
        return tool_class

    except ImportError as error:
        print(f"Failed to import module {module_name or 'N/A'}: {error}")
        return None
    except AttributeError as error:
        if function_name:
            print(
                f"Failed to load function {function_name} from class {class_name} "
                f"in module {module_name}: {error}"
            )
        else:
            print(
                f"Failed to find class {class_name or 'N/A'} "
                f"in module {module_name or 'N/A'}: {error}"
            )
        return None
    except Exception as error:
        print(f"Unexpected error loading tool {display_name}: {error}")
        return None


def get_local_tools(tool_config, tool_kwargs=None):
    if tool_kwargs is None:
        tool_kwargs = {}

    if isinstance(tool_config, dict) and not tool_config.get("enabled", True):
        return None

    module_name, class_name, function_name, display_name = _resolve_local_tool_reference(tool_config)
    if not module_name or not class_name:
        print(f"Skipping local tool due to invalid format: {tool_config}")
        return None

    tool = load_local_tool(
        module_name=module_name,
        class_name=class_name,
        function_name=function_name,
        display_name=display_name,
        tool_kwargs=tool_kwargs
    )
    if tool is not None:
        print(f"Added local tool: {display_name}")
    else:
        print(f"Failed to load local tool: {display_name}")
    return tool
