"""PBIP Visual Extractor

Extracts per-visual CSV files from a Power BI PBIP project zip.

Registered in agent config as:  ``PBIPVisualExtractor.extract_visual_csvs``

Workflow
--------
1. Locate the PBIP zip: uses ``zip_path`` param, or scans session inputs/ for
   the first ``.zip`` file, or falls back to a plain PBIP folder.
2. Unzip to a temp directory and find the ``.SemanticModel`` and ``.Report``
   sub-folders.
3. Parse ``*.tmdl`` files → table schema, measures, calculated columns,
   relationships.
4. Detect bundled source CSVs (same zip or adjacent folder).
5. Load CSVs with pandas; compute DAX-equivalent calculated columns.
6. For every data-bearing visual (``visual.json`` with a ``queryState``),
   group/aggregate and write a named CSV.
7. Pack all per-visual CSVs into ``pbip_visuals_<timestamp>.zip`` under
   ``session_storage/{session_id}/artifacts/``.
"""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
import tempfile
import zipfile
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).resolve().parents[3]

# Measure roles that contain aggregated values
_MEASURE_ROLES = {"Y", "X", "Values", "Size", "Tooltips"}
# Dimension roles that hold categorical grouping columns
_DIMENSION_ROLES = {"Category", "Group", "Details", "Rows", "Columns", "Legend"}


# ---------------------------------------------------------------------------
# M-query source-type detection (used by _parse_tmdl_table)
# ---------------------------------------------------------------------------

_SNOWFLAKE_RE = re.compile(
    r"Snowflake\.Databases\s*\(\s*"
    r"(?P<server>\"[^\"]+\"|[A-Za-z_]\w*)"   # quoted string or parameter ref
    r"\s*,\s*"
    r"(?P<warehouse>\"[^\"]+\"|[A-Za-z_]\w*)",  # quoted string or parameter ref
    re.IGNORECASE,
)

_MYSQL_RE = re.compile(
    r"MySQL\.Database\s*\(\s*"
    r"(?P<host>\"[^\"]*\")"          # quoted host (may include :port)
    r"\s*,\s*"
    r"(?P<database>\"[^\"]*\")",
    re.IGNORECASE,
)

# Navigation: Source{[Name="DB_NAME"]}[Data]  or  db{[Name="SCHEMA"]}[Data]
_NAV_NAME_RE = re.compile(
    r'\{?\[Name\s*=\s*"(?P<value>[^"]+)"\]\}?\[Data\]',
    re.IGNORECASE,
)

# Navigation for MySQL tables: Source{[Schema="x", Item="y"]}[Data]
_MYSQL_NAV_RE = re.compile(
    r'\{?\[Schema\s*=\s*"(?P<schema>[^"]+)"\s*,\s*Item\s*=\s*"(?P<item>[^"]+)"\]\}?\[Data\]',
    re.IGNORECASE,
)

# Custom SQL via Value.NativeQuery
_NATIVE_QUERY_RE = re.compile(
    r'Value\.NativeQuery\s*\([^,]+,\s*"(?P<query>[^"]+)"',
    re.IGNORECASE | re.DOTALL,
)

# Parameter table
_PARAM_RE = re.compile(
    r'(?:metaValue\s*=\s*)?"(?P<value>[^"]*)"',
    re.IGNORECASE,
)

# CSV / Excel source
_SOURCE_CSV_RE = re.compile(r'"([^"]+\.csv)"', re.IGNORECASE)
_SOURCE_EXCEL_RE = re.compile(r'"([^"]+\.(xlsx?|xlsb))"', re.IGNORECASE)


def _strip_m_quotes(s: str) -> str:
    """Remove surrounding double-quotes from an M-query string literal."""
    s = s.strip()
    if s.startswith('"') and s.endswith('"'):
        return s[1:-1]
    return s


def _parse_tmdl_source(tmdl_text: str) -> Dict[str, Any]:
    """Parse the M-query partition block from a single TMDL table file.

    Returns::

        {
            "source_type": "snowflake" | "mysql" | "csv" | "excel" | "parameter" | "unknown",
            "connection":  { <db-specific keys> },
        }
    """
    result: Dict[str, Any] = {"source_type": "unknown", "connection": {}}

    # Extract the M expression from the partition block
    m_block = re.search(
        r"partition\s+.+?=\s*m\b.*?source\s*=\s*\n([\s\S]+?)(?=\n\t[a-z]|\Z)",
        tmdl_text,
        re.IGNORECASE,
    )
    m_expr = m_block.group(1).strip() if m_block else tmdl_text

    # --- Snowflake ---
    sf = _SNOWFLAKE_RE.search(m_expr)
    if sf:
        result["source_type"] = "snowflake"
        nav = _NAV_NAME_RE.findall(m_expr)
        nq = _NATIVE_QUERY_RE.search(m_expr)
        result["connection"] = {
            "server":        _strip_m_quotes(sf.group("server")),
            "warehouse":     _strip_m_quotes(sf.group("warehouse")),
            "database":      nav[0] if len(nav) >= 1 else None,
            "schema":        nav[1] if len(nav) >= 2 else None,
            "table":         nav[2] if len(nav) >= 3 else None,
            "native_query":  nq.group("query").strip() if nq else None,
        }
        return result

    # --- MySQL ---
    my = _MYSQL_RE.search(m_expr)
    if my:
        result["source_type"] = "mysql"
        raw_host = _strip_m_quotes(my.group("host"))
        host = raw_host.split(":")[0] if ":" in raw_host else raw_host
        port = raw_host.split(":")[1] if ":" in raw_host else "3306"
        mysql_nav = _MYSQL_NAV_RE.search(m_expr)
        nav = _NAV_NAME_RE.findall(m_expr)
        nq = _NATIVE_QUERY_RE.search(m_expr)
        result["connection"] = {
            "host":         host,
            "port":         port,
            "database":     _strip_m_quotes(my.group("database")),
            "schema":       mysql_nav.group("schema") if mysql_nav else None,
            "table":        mysql_nav.group("item") if mysql_nav else (nav[-1] if nav else None),
            "native_query": nq.group("query").strip() if nq else None,
        }
        return result

    # --- CSV ---
    if _SOURCE_CSV_RE.search(m_expr):
        result["source_type"] = "csv"
        m = _SOURCE_CSV_RE.search(m_expr)
        result["connection"] = {"file": Path(m.group(1)).name}
        return result

    # --- Excel ---
    if _SOURCE_EXCEL_RE.search(m_expr):
        result["source_type"] = "excel"
        m = _SOURCE_EXCEL_RE.search(m_expr)
        result["connection"] = {"file": Path(m.group(1)).name}
        return result

    # --- Power Query parameter table ---
    if re.search(r"IsParameterQuery|IsParameterQueryRequired", tmdl_text, re.IGNORECASE):
        result["source_type"] = "parameter"
        pm = _PARAM_RE.search(m_expr)
        result["connection"] = {"value": pm.group("value") if pm else ""}
        return result

    return result


# ---------------------------------------------------------------------------
# TMDL parser helpers
# ---------------------------------------------------------------------------


def _parse_tmdl_table(tmdl_text: str) -> Dict[str, Any]:
    """Parse a single ``.tmdl`` table file into a schema dict.

    Returns::

        {
            "source_csv": "Sales.csv" | None,
            "source_type": "csv" | "snowflake" | "mysql" | "excel" | "parameter" | "unknown",
            "connection": {<db-specific keys>},
            "columns": [{"name": str, "data_type": str}],
            "calculated_columns": [{"name": str, "dax": str}],
            "measures": [{"name": str, "dax": str}],
        }
    """
    schema: Dict[str, Any] = {
        "source_csv": None,
        "source_type": "unknown",
        "connection": {},
        "columns": [],
        "calculated_columns": [],
        "measures": [],
    }

    # --- Detect source type (CSV / Snowflake / MySQL / Excel / parameter) ---
    src_info = _parse_tmdl_source(tmdl_text)
    schema["source_type"] = src_info.get("source_type", "unknown")
    schema["connection"] = src_info.get("connection", {})

    # --- source CSV from M-query partition (kept for backward compat) ---
    csv_match = re.search(r'"([^"]+\.csv)"', tmdl_text, re.IGNORECASE)
    if csv_match:
        schema["source_csv"] = Path(csv_match.group(1)).name

    lines = tmdl_text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Measure definition:  measure 'Name' = DAX
        m = re.match(r"^\s*measure\s+'?(.+?)'?\s*=\s*(.+)$", line)
        if m:
            measure_name = m.group(1).strip("'\"")
            dax_expr = m.group(2).strip()
            schema["measures"].append({"name": measure_name, "dax": dax_expr})
            i += 1
            continue

        # Column definition
        col_match = re.match(r"^\s*column\s+'?(.+?)'?\s*(?:=\s*(.+))?$", line)
        if col_match:
            col_name = col_match.group(1).strip("'\"")
            dax_expr = (col_match.group(2) or "").strip()
            # Look ahead for dataType
            data_type = "string"
            j = i + 1
            while j < len(lines) and j < i + 10:
                dt_match = re.match(r"^\s*dataType:\s*(\S+)", lines[j])
                if dt_match:
                    data_type = dt_match.group(1)
                    break
                if lines[j].strip() == "" or re.match(r"^\s*(column|measure|partition)", lines[j]):
                    break
                j += 1

            if dax_expr:
                schema["calculated_columns"].append(
                    {"name": col_name, "dax": dax_expr, "data_type": data_type}
                )
            else:
                schema["columns"].append({"name": col_name, "data_type": data_type})
            i += 1
            continue

        i += 1

    return schema


def _parse_relationships(tmdl_text: str) -> List[Dict[str, str]]:
    """Parse relationships.tmdl into a list of relationship dicts.

    Returns list of ``{"from_table", "from_col", "to_table", "to_col"}``.
    Handles both a single combined file and individual per-relationship files,
    and both quoted (``'Table'.'Col'``) and unquoted (``Table.'Col'``) identifiers.
    """
    relationships: List[Dict[str, str]] = []
    # Match: fromColumn: 'Table'.'Col'  or  fromColumn: Table.'Col'  or  fromColumn: Table.Col
    from_re = re.compile(r"fromColumn:\s*'?(\w+)'?\.'?([^'\n\r]+?)'?\s*$", re.MULTILINE)
    to_re = re.compile(r"toColumn:\s*'?(\w+)'?\.'?([^'\n\r]+?)'?\s*$", re.MULTILINE)

    # Split on "relationship <uuid>" at start-of-line or start-of-string
    blocks = re.split(r"(?:^|\n)relationship\s+", tmdl_text)
    for block in blocks:
        from_m = from_re.search(block)
        to_m = to_re.search(block)
        if from_m and to_m:
            relationships.append(
                {
                    "from_table": from_m.group(1).strip("'"),
                    "from_col": from_m.group(2).strip("'"),
                    "to_table": to_m.group(1).strip("'"),
                    "to_col": to_m.group(2).strip("'"),
                }
            )
    return relationships


# ---------------------------------------------------------------------------
# Visual JSON parser
# ---------------------------------------------------------------------------

def _parse_visual(visual_json: dict) -> Dict[str, Any]:
    """Extract visual type, dimension fields, and measure fields from a visual.json.

    Returns::

        {
            "visual_type": str,
            "dimensions": [{"entity": str, "property": str, "role": str}],
            "measures": [{"entity": str, "property": str, "role": str}],
        }
    """
    visual = visual_json.get("visual", {})
    visual_type = visual.get("visualType", "unknown")
    query_state = visual.get("query", {}).get("queryState", {})

    dimensions: List[Dict[str, str]] = []
    measures: List[Dict[str, str]] = []

    for role, role_data in query_state.items():
        for proj in role_data.get("projections", []):
            field = proj.get("field", {})
            if "Column" in field:
                entity = field["Column"]["Expression"]["SourceRef"]["Entity"]
                prop = field["Column"]["Property"]
                dimensions.append({"entity": entity, "property": prop, "role": role})
            elif "Measure" in field:
                entity = field["Measure"]["Expression"]["SourceRef"]["Entity"]
                prop = field["Measure"]["Property"]
                measures.append({"entity": entity, "property": prop, "role": role})

    return {
        "visual_type": visual_type,
        "dimensions": dimensions,
        "measures": measures,
    }


# ---------------------------------------------------------------------------
# DAX-to-pandas resolver
# ---------------------------------------------------------------------------

def _resolve_dax_calculated_column(
    col_def: Dict[str, str],
    table_name: str,
    loaded_dfs: Dict[str, pd.DataFrame],
    relationships: List[Dict[str, str]],
) -> Optional[pd.Series]:
    """Attempt to resolve a DAX calculated column to a pandas Series.

    Handles the patterns found in this PBIP:

    * ``Sales[Order Qty] * RELATED(Product[Net Price])``
    * ``DATEDIFF(col1, col2, DAY)``
    * ``IF(Sales[col] <= 0, "On Time", "Late")``
    * ``DATE(YEAR(col), MONTH(col), 1)``
    """
    dax = col_def["dax"].strip()
    df = loaded_dfs.get(table_name)
    if df is None:
        return None

    # --- Sales Amount = Order Qty * RELATED(Product[Net Price]) ---
    related_mul = re.match(
        r"(\w+)\[([^\]]+)\]\s*\*\s*RELATED\((\w+)\[([^\]]+)\]\)",
        dax, re.IGNORECASE,
    )
    if related_mul:
        t1, c1 = related_mul.group(1), related_mul.group(2)
        t2, c2 = related_mul.group(3), related_mul.group(4)
        if t1 == table_name and t2 in loaded_dfs:
            rel = _find_relationship(table_name, t2, relationships)
            if rel:
                left_key = rel["left_col"]
                right_key = rel["right_col"]
                right_df = loaded_dfs[t2][[right_key, c2]].copy()
                right_df = right_df.rename(columns={c2: f"__related_{c2}"})
                merged = df.merge(right_df, left_on=left_key, right_on=right_key, how="left")
                return (merged[c1].astype(float) * merged[f"__related_{c2}"].astype(float)).values
        return None

    # --- DATEDIFF(col1, col2, DAY) ---
    datediff_m = re.match(
        r"DATEDIFF\((\w+)\[([^\]]+)\]\s*,\s*(\w+)\[([^\]]+)\]\s*,\s*DAY\)",
        dax, re.IGNORECASE,
    )
    if datediff_m:
        c1 = datediff_m.group(2)
        c2 = datediff_m.group(4)
        try:
            d1 = pd.to_datetime(df[c1], errors="coerce", format="mixed")
            d2 = pd.to_datetime(df[c2], errors="coerce", format="mixed")
            return (d2 - d1).dt.days.values
        except Exception:
            return None

    # --- IF(T[col] <= 0, "...", "...") ---
    if_m = re.match(
        r'IF\((\w+)\[([^\]]+)\]\s*<=\s*0\s*,\s*"([^"]+)"\s*,\s*"([^"]+)"\)',
        dax, re.IGNORECASE,
    )
    if if_m:
        col_name = if_m.group(2)
        true_val = if_m.group(3)
        false_val = if_m.group(4)
        if col_name in df.columns:
            return (df[col_name].astype(float) <= 0).map({True: true_val, False: false_val}).values
        return None

    # --- DATE(YEAR(col), MONTH(col), 1) ---
    date_m = re.match(
        r"DATE\(YEAR\((\w+)\[([^\]]+)\]\)\s*,\s*MONTH\((\w+)\[([^\]]+)\]\)\s*,\s*1\)",
        dax, re.IGNORECASE,
    )
    if date_m:
        col_name = date_m.group(2)
        if col_name in df.columns:
            try:
                dt = pd.to_datetime(df[col_name], errors="coerce", format="mixed")
                return dt.dt.to_period("M").dt.to_timestamp().values
            except Exception:
                return None
        return None

    return None


def _find_relationship(
    table_a: str, table_b: str, relationships: List[Dict[str, str]]
) -> Optional[Dict[str, str]]:
    """Return {left_col, right_col} joining table_a to table_b via any relationship."""
    for rel in relationships:
        if rel["from_table"] == table_a and rel["to_table"] == table_b:
            return {"left_col": rel["from_col"], "right_col": rel["to_col"]}
        if rel["from_table"] == table_b and rel["to_table"] == table_a:
            return {"left_col": rel["to_col"], "right_col": rel["from_col"]}
    return None


# ---------------------------------------------------------------------------
# Measure resolver: DAX measure → pandas aggregation
# ---------------------------------------------------------------------------

def _resolve_measure(
    measure_dax: str,
    dim_col: Optional[str],
    table_name: str,
    loaded_dfs: Dict[str, pd.DataFrame],
    relationships: List[Dict[str, str]],
) -> Optional[pd.Series]:
    """Resolve a DAX measure to a grouped pandas Series.

    Supported patterns:
    * ``SUM(T[col])``          → df.groupby(dim)[col].sum()
    * ``SUMX(T, T[col1]*RELATED(T2[col2]))``  → merge + groupby + sum of product
    """
    dax = measure_dax.strip()

    # SUM(T[col])
    sum_m = re.match(r"SUM\((\w+)\[([^\]]+)\]\)", dax, re.IGNORECASE)
    if sum_m:
        t = sum_m.group(1)
        col = sum_m.group(2)
        df = loaded_dfs.get(t)
        if df is None or col not in df.columns:
            return None
        if dim_col is None:
            # Scalar total
            return pd.Series([pd.to_numeric(df[col], errors="coerce").sum()])
        return pd.to_numeric(df[col], errors="coerce")

    # SUMX(T, T[col1] * RELATED(T2[col2]))
    sumx_m = re.match(
        r"SUMX\((\w+)\s*,\s*(\w+)\[([^\]]+)\]\s*\*\s*RELATED\((\w+)\[([^\]]+)\]\)\)",
        dax, re.IGNORECASE,
    )
    if sumx_m:
        base_t = sumx_m.group(1)
        t1, c1 = sumx_m.group(2), sumx_m.group(3)
        t2, c2 = sumx_m.group(4), sumx_m.group(5)
        df = loaded_dfs.get(base_t)
        if df is None:
            return None
        rel = _find_relationship(base_t, t2, relationships)
        if rel is None:
            return None
        right_df = loaded_dfs.get(t2)
        if right_df is None:
            return None
        right_sub = right_df[[rel["right_col"], c2]].copy()
        right_sub = right_sub.rename(columns={c2: "__related_val"})
        merged = df.merge(right_sub, left_on=rel["left_col"], right_on=rel["right_col"], how="left")
        merged["__product"] = (
            pd.to_numeric(merged[c1], errors="coerce")
            * pd.to_numeric(merged["__related_val"], errors="coerce")
        )
        return merged["__product"]

    return None


# ---------------------------------------------------------------------------
# Visual data computation
# ---------------------------------------------------------------------------

def _compute_visual_df(
    visual_info: Dict[str, Any],
    schema: Dict[str, Dict[str, Any]],
    loaded_dfs: Dict[str, pd.DataFrame],
    relationships: List[Dict[str, str]],
) -> Optional[pd.DataFrame]:
    """Compute the aggregated DataFrame for a single visual."""
    dims = visual_info["dimensions"]
    measures = visual_info["measures"]

    if not measures:
        logger.debug("Visual has no measures, skipping.")
        return None

    # --- Build working dataframe ---
    # For visuals with no dimension columns (scatter with only measures), return totals
    if not dims:
        result: Dict[str, Any] = {}
        for m_def in measures:
            meas_info = _lookup_measure(m_def["entity"], m_def["property"], schema)
            if meas_info is None:
                continue
            series = _resolve_measure(
                meas_info["dax"], None, m_def["entity"], loaded_dfs, relationships
            )
            if series is not None:
                col_name = m_def["property"]
                result[col_name] = [pd.to_numeric(series, errors="coerce").sum()]
        return pd.DataFrame(result) if result else None

    # --- Resolve dimension columns ---
    # All dims must come from the same "base" table (or be joined in)
    # Determine the primary table: first dim entity
    primary_entity = dims[0]["entity"]
    primary_df = loaded_dfs.get(primary_entity, pd.DataFrame()).copy()
    if primary_df.empty:
        return None

    # Resolve each dimension column (may be a calculated column)
    dim_col_names: List[str] = []
    for dim in dims:
        entity = dim["entity"]
        prop = dim["property"]
        # Check if it's a calculated column
        calc_col = _lookup_calc_column(entity, prop, schema)
        if calc_col is not None:
            # Compute it on the primary df
            series = _resolve_dax_calculated_column(
                calc_col, entity, loaded_dfs, relationships
            )
            if series is not None:
                if entity == primary_entity:
                    primary_df[prop] = series
                else:
                    # Dimension from a different entity — join it in
                    rel = _find_relationship(primary_entity, entity, relationships)
                    if rel:
                        ext_df = loaded_dfs[entity].copy()
                        ext_df[prop] = series if len(series) == len(ext_df) else ext_df[prop]
                        primary_df = primary_df.merge(
                            ext_df[[rel["right_col"], prop]].drop_duplicates(rel["right_col"]),
                            left_on=rel["left_col"],
                            right_on=rel["right_col"],
                            how="left",
                        )
            elif entity == primary_entity:
                pass  # col may already exist in loaded df
            dim_col_names.append(prop)
        elif entity == primary_entity:
            # Regular source column already in primary_df
            if prop in primary_df.columns:
                dim_col_names.append(prop)
        else:
            # Column from a related entity — join it
            rel = _find_relationship(primary_entity, entity, relationships)
            if rel:
                ext_df = loaded_dfs.get(entity)
                if ext_df is not None and prop in ext_df.columns:
                    join_cols = [rel["right_col"]]
                    if prop not in join_cols:
                        join_cols.append(prop)
                    primary_df = primary_df.merge(
                        ext_df[join_cols].drop_duplicates(rel["right_col"]),
                        left_on=rel["left_col"],
                        right_on=rel["right_col"],
                        how="left",
                    )
                    dim_col_names.append(prop)

    if not dim_col_names:
        return None

    # --- Resolve measures ---
    measure_series: Dict[str, pd.Series] = {}
    for m_def in measures:
        meas_info = _lookup_measure(m_def["entity"], m_def["property"], schema)
        if meas_info is None:
            continue
        series = _resolve_measure(
            meas_info["dax"], dim_col_names[0], m_def["entity"], loaded_dfs, relationships
        )
        if series is not None:
            # series is per-row, needs to be attached to primary_df for groupby
            meas_entity = m_def["entity"]
            meas_df = loaded_dfs.get(meas_entity, pd.DataFrame())
            if len(series) == len(meas_df):
                # series aligns with the measure's base table
                # Need to join back if different from primary
                if meas_entity == primary_entity:
                    primary_df[m_def["property"]] = series
                else:
                    # Attach via relationship
                    rel = _find_relationship(primary_entity, meas_entity, relationships)
                    if rel:
                        temp_df = loaded_dfs[meas_entity][[rel["right_col"]]].copy()
                        temp_df[m_def["property"]] = series
                        primary_df = primary_df.merge(
                            temp_df,
                            left_on=rel["left_col"],
                            right_on=rel["right_col"],
                            how="left",
                        )
                measure_series[m_def["property"]] = primary_df[m_def["property"]]
            elif len(series) == len(primary_df):
                primary_df[m_def["property"]] = series
                measure_series[m_def["property"]] = primary_df[m_def["property"]]

    # --- Check for pre-resolved calculated columns used as measures ---
    # e.g. Total Sales Amount → SUM(Sales[Sales Amount]) where Sales Amount is a calc col
    # The calc col should already be in primary_df after the calculated column resolution
    for m_def in measures:
        prop = m_def["property"]
        if prop in measure_series:
            continue
        meas_info = _lookup_measure(m_def["entity"], m_def["property"], schema)
        if meas_info:
            sum_inner = re.match(r"SUM\((\w+)\[([^\]]+)\]\)", meas_info["dax"], re.IGNORECASE)
            if sum_inner:
                inner_col = sum_inner.group(2)
                if inner_col in primary_df.columns:
                    primary_df[prop] = pd.to_numeric(primary_df[inner_col], errors="coerce")
                    measure_series[prop] = primary_df[prop]

    if not measure_series:
        return None

    # --- Group and aggregate ---
    agg_cols = {col: "sum" for col in measure_series}
    for col in measure_series:
        primary_df[col] = pd.to_numeric(primary_df[col], errors="coerce")

    # Drop rows where all dim columns are null
    primary_df = primary_df.dropna(subset=dim_col_names, how="all")

    try:
        grouped = primary_df.groupby(dim_col_names, as_index=False).agg(agg_cols)
    except Exception as exc:
        logger.warning("GroupBy failed: %s", exc)
        return None

    # Clean up column names (remove hidden merge columns)
    final_cols = dim_col_names + list(agg_cols.keys())
    grouped = grouped[[c for c in final_cols if c in grouped.columns]]
    grouped = grouped.sort_values(list(agg_cols.keys()), ascending=False).reset_index(drop=True)
    return grouped


def _lookup_measure(entity: str, prop: str, schema: Dict[str, Dict[str, Any]]) -> Optional[Dict]:
    for meas in schema.get(entity, {}).get("measures", []):
        if meas["name"] == prop:
            return meas
    return None


def _lookup_calc_column(entity: str, prop: str, schema: Dict[str, Dict[str, Any]]) -> Optional[Dict]:
    for calc in schema.get(entity, {}).get("calculated_columns", []):
        if calc["name"] == prop:
            return calc
    return None


# ---------------------------------------------------------------------------
# DB visual metadata builder
# ---------------------------------------------------------------------------

def _build_db_visual_metadata_df(
    visual_info: Dict[str, Any],
    schema: Dict[str, Dict[str, Any]],
) -> Optional[pd.DataFrame]:
    """Build a metadata DataFrame for a visual whose tables are sourced from
    an external database (Snowflake / MySQL).

    Since live data cannot be fetched at extraction time, this returns a
    schema/lineage DataFrame describing every field bound to the visual
    alongside its DB connection coordinates and DAX definition.
    """
    rows = []
    all_fields = (
        [{"kind": "dimension", **d} for d in visual_info["dimensions"]]
        + [{"kind": "measure", **m} for m in visual_info["measures"]]
    )
    for field_ref in all_fields:
        entity = field_ref["entity"]
        prop = field_ref["property"]
        role = field_ref["role"]

        t_meta = schema.get(entity, {})
        conn = t_meta.get("connection", {})
        source_type = t_meta.get("source_type", "unknown")

        field_kind = "column"
        dax_expression = ""
        data_type = ""

        for meas in t_meta.get("measures", []):
            if meas["name"] == prop:
                field_kind = "measure"
                dax_expression = meas.get("dax", "")
                break

        if field_kind == "column":
            for calc in t_meta.get("calculated_columns", []):
                if calc["name"] == prop:
                    field_kind = "calculated_column"
                    dax_expression = calc.get("dax", "")
                    data_type = calc.get("data_type", "")
                    break

        if field_kind == "column":
            for col in t_meta.get("columns", []):
                if col["name"] == prop:
                    data_type = col.get("data_type", "")
                    break

        rows.append(
            {
                "field_role": role,
                "field_name": prop,
                "field_kind": field_kind,
                "table_name": entity,
                "source_type": source_type,
                "db_server": conn.get("server") or conn.get("host") or "",
                "db_database": conn.get("database") or "",
                "db_schema": conn.get("schema") or "",
                "db_table": conn.get("table") or "",
                "dax_expression": dax_expression,
                "data_type": data_type,
            }
        )

    if not rows:
        return None
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# PBIP folder walker
# ---------------------------------------------------------------------------

def _find_pbip_roots(root: Path) -> Tuple[Optional[Path], Optional[Path]]:
    """Return (semantic_model_dir, report_dir) within an extracted folder."""
    sm_dir: Optional[Path] = None
    rpt_dir: Optional[Path] = None

    for p in root.rglob("*.SemanticModel"):
        if p.is_dir():
            sm_dir = p
            break
    for p in root.rglob("*.Report"):
        if p.is_dir():
            rpt_dir = p
            break

    return sm_dir, rpt_dir


def _find_source_csvs(root: Path, schema: Dict[str, Dict[str, Any]]) -> Dict[str, Path]:
    """Find source CSV files bundled in the extracted directory."""
    needed_csvs = {
        meta["source_csv"]
        for meta in schema.values()
        if meta.get("source_csv")
    }
    found: Dict[str, Path] = {}
    for csv_name in needed_csvs:
        for match in root.rglob(csv_name):
            if match.is_file():
                found[csv_name] = match
                break
    return found


# ---------------------------------------------------------------------------
# Main tool class
# ---------------------------------------------------------------------------

class PBIPVisualExtractor:
    """Native tool that extracts per-visual CSV data from a Power BI PBIP project zip.

    Registered in agent config as: ``PBIPVisualExtractor.extract_visual_csvs``
    """

    def __init__(self, data_dir: Optional[str] = None):
        self.tool_name = "PBIPVisualExtractor"
        self._data_dir = data_dir
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def _derive_session_id(self) -> Optional[str]:
        """Derive session_id from the injected data_dir path.

        data_dir is typically ``session_storage/{session_id}/inputs``, so the
        session_id is the grandparent folder name relative to storage root.
        """
        if not self._data_dir:
            return None
        p = Path(self._data_dir)
        # .../session_storage/{session_id}/inputs  → parent.name = session_id
        if p.name == "inputs":
            return p.parent.name
        # fallback: last path component
        return p.name

    def extract_visual_csvs(
        self,
        zip_path: Optional[str] = None,
        session_id: Optional[str] = None,
        agent_id: str = "unknown",
        agent_name: str = "Unknown Agent",
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Extract per-visual CSVs from a PBIP project zip.

        Args:
            zip_path: Absolute path to the PBIP zip file.  If omitted, the
                tool scans the session inputs folder for a ``.zip`` file.
            session_id: DAAN session UUID used to write output artifacts.
                If omitted, derived automatically from the injected data_dir.
            agent_id: Agent identifier (for logging).
            agent_name: Agent display name (for logging).

        Returns:
            dict with keys:
                ``status``    — "ok" | "error"
                ``zip_path``  — path to output zip (on success)
                ``summary``   — list of extracted visual dicts (on success)
                ``message``   — human-readable description
        """
        # Auto-derive session_id from data_dir when not explicitly provided
        if not session_id:
            session_id = self._derive_session_id()

        try:
            logger.info("%s: Starting PBIP visual extraction", self.tool_name)

            # 1. Resolve input zip / folder
            source_path = self._resolve_source(zip_path)
            if source_path is None:
                return {
                    "status": "error",
                    "message": (
                        "No PBIP zip file found. Provide 'zip_path' or upload a "
                        ".zip file containing a PBIP project to the session inputs folder."
                    ),
                }

            # 2. Extract to temp dir
            with tempfile.TemporaryDirectory(prefix="pbip_") as tmp_str:
                tmp_dir = Path(tmp_str)
                extract_root = self._extract_source(source_path, tmp_dir)
                logger.info("%s: Extracted to %s", self.tool_name, extract_root)

                # 3. Find SemanticModel + Report directories
                sm_dir, rpt_dir = _find_pbip_roots(extract_root)
                if sm_dir is None:
                    return {
                        "status": "error",
                        "message": (
                            "Could not find a .SemanticModel folder in the zip. "
                            "Ensure the zip contains a valid PBIP project folder."
                        ),
                    }
                if rpt_dir is None:
                    return {
                        "status": "error",
                        "message": "Could not find a .Report folder in the zip.",
                    }

                # 4. Parse TMDL schema
                tables_dir = sm_dir / "definition" / "tables"
                schema = self._parse_schema(tables_dir)
                logger.info("%s: Parsed schema for tables: %s", self.tool_name, list(schema.keys()))

                # 5. Parse relationships — handle both a single file and a directory
                #    of per-relationship .tmdl files (both are valid PBIP layouts).
                rels_single = sm_dir / "definition" / "relationships.tmdl"
                rels_dir = sm_dir / "definition" / "relationships"
                if rels_single.exists():
                    rels_text = rels_single.read_text(encoding="utf-8")
                elif rels_dir.is_dir():
                    rels_text = "\n".join(
                        f.read_text(encoding="utf-8")
                        for f in sorted(rels_dir.glob("*.tmdl"))
                    )
                else:
                    rels_text = ""
                relationships = _parse_relationships(rels_text) if rels_text else []
                logger.info("%s: Parsed %d relationships", self.tool_name, len(relationships))

                # 6. Identify external DB tables (Snowflake / MySQL) — they cannot
                #    be loaded as DataFrames; surface them in the output summary.
                db_sourced_tables = {
                    tname: tmeta
                    for tname, tmeta in schema.items()
                    if tmeta.get("source_type") in ("snowflake", "mysql")
                }
                if db_sourced_tables:
                    for tname, tmeta in db_sourced_tables.items():
                        conn = tmeta.get("connection", {})
                        logger.info(
                            "%s: Table '%s' is sourced from %s (%s). "
                            "DB-sourced visual metadata CSVs will be included in the output zip.",
                            self.tool_name,
                            tname,
                            tmeta["source_type"].upper(),
                            conn.get("server") or conn.get("host") or "unknown host",
                        )

                # 7. Find + load source CSVs (skip DB-sourced tables)
                csv_paths = _find_source_csvs(extract_root, schema)
                # Also look in data_dir (session inputs) for any missing CSVs
                if self._data_dir:
                    for csv_name in {m["source_csv"] for m in schema.values() if m.get("source_csv")}:
                        if csv_name not in csv_paths:
                            candidate = Path(self._data_dir) / csv_name
                            if candidate.exists():
                                csv_paths[csv_name] = candidate

                loaded_dfs = self._load_csvs(schema, csv_paths)
                logger.info("%s: Loaded DataFrames: %s", self.tool_name, list(loaded_dfs.keys()))

                # 8. Apply calculated columns
                self._apply_calculated_columns(schema, loaded_dfs, relationships)

                # 9. Parse visuals + generate per-visual CSVs
                pages_dir = rpt_dir / "definition" / "pages"
                output_dir = tmp_dir / "visual_csvs"
                output_dir.mkdir()

                summary, csv_files = self._extract_visuals(
                    pages_dir, schema, loaded_dfs, relationships, output_dir
                )

                if not csv_files:
                    return {
                        "status": "error",
                        "message": "No data-bearing visuals found or no data could be extracted.",
                    }

                # 10. Generate DB summary CSVs (connections, tables, relationships)
                #     and add them to the same zip
                db_summary_csvs = self._generate_db_summary_csvs(
                    schema, relationships, output_dir
                )
                csv_files.extend(db_summary_csvs)

                # 11. Pack all CSVs into output zip
                out_zip_path = self._pack_output(csv_files, session_id, output_dir)
                logger.info("%s: Output zip: %s", self.tool_name, out_zip_path)

        except Exception as exc:
            logger.exception("%s: Extraction failed", self.tool_name)
            return {"status": "error", "message": f"Extraction failed: {exc}"}

        db_visual_count = sum(
            1 for s in summary if s.get("source_type") == "database"
        )
        csv_visual_count = len(summary) - db_visual_count

        return {
            "status": "ok",
            "zip_path": str(out_zip_path),
            "summary": summary,
            "message": (
                f"Successfully extracted {len(summary)} visual CSV(s) from "
                f"{len({s['page'] for s in summary})} page(s) "
                f"({csv_visual_count} from embedded data, "
                f"{db_visual_count} DB-sourced field metadata). "
                f"Output zip: {out_zip_path}"
            ),
        }

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _resolve_source(self, zip_path: Optional[str]) -> Optional[Path]:
        """Resolve the PBIP source — explicit path, session inputs zip, or folder."""
        # 1. Explicit zip_path
        if zip_path:
            p = Path(zip_path)
            if p.exists():
                return p
            logger.warning("%s: zip_path '%s' not found", self.tool_name, zip_path)

        # 2. Scan session inputs folder
        if self._data_dir:
            inputs = Path(self._data_dir)
            for f in sorted(inputs.iterdir()):
                if f.suffix.lower() == ".zip":
                    logger.info("%s: Using zip from inputs: %s", self.tool_name, f)
                    return f
            # Maybe the PBIP folder itself was uploaded (unzipped)
            for f in sorted(inputs.iterdir()):
                if f.is_dir() and (f / ".SemanticModel" or True):
                    sm_candidates = list(f.rglob("*.SemanticModel"))
                    if sm_candidates:
                        return f

        return None

    def _extract_source(self, source_path: Path, tmp_dir: Path) -> Path:
        """Extract zip to tmp_dir (or use the folder directly)."""
        if source_path.is_dir():
            dest = tmp_dir / source_path.name
            shutil.copytree(str(source_path), str(dest))
            return tmp_dir

        with zipfile.ZipFile(source_path, "r") as zf:
            zf.extractall(tmp_dir)
        return tmp_dir

    def _parse_schema(self, tables_dir: Path) -> Dict[str, Dict[str, Any]]:
        """Parse all .tmdl files in the tables directory."""
        schema: Dict[str, Dict[str, Any]] = {}
        if not tables_dir.is_dir():
            return schema
        for tmdl_file in sorted(tables_dir.glob("*.tmdl")):
            text = tmdl_file.read_text(encoding="utf-8")
            table_name = tmdl_file.stem  # e.g. "Sales"
            schema[table_name] = _parse_tmdl_table(text)
        return schema

    def _load_csvs(
        self,
        schema: Dict[str, Dict[str, Any]],
        csv_paths: Dict[str, Path],
    ) -> Dict[str, pd.DataFrame]:
        """Load source CSVs into DataFrames keyed by table name."""
        loaded: Dict[str, pd.DataFrame] = {}
        for table_name, meta in schema.items():
            csv_name = meta.get("source_csv")
            if not csv_name or csv_name not in csv_paths:
                logger.warning(
                    "%s: Source CSV '%s' for table '%s' not found",
                    self.tool_name, csv_name, table_name,
                )
                continue
            try:
                df = pd.read_csv(csv_paths[csv_name], encoding="utf-8-sig", low_memory=False)
                df.columns = [c.strip() for c in df.columns]
                loaded[table_name] = df
                logger.info(
                    "%s: Loaded %s: %d rows, cols=%s",
                    self.tool_name, csv_name, len(df), list(df.columns),
                )
            except Exception as exc:
                logger.warning("%s: Failed to load '%s': %s", self.tool_name, csv_name, exc)
        return loaded

    def _apply_calculated_columns(
        self,
        schema: Dict[str, Dict[str, Any]],
        loaded_dfs: Dict[str, pd.DataFrame],
        relationships: List[Dict[str, str]],
    ) -> None:
        """Compute DAX calculated columns and add them to the loaded DataFrames."""
        for table_name, meta in schema.items():
            df = loaded_dfs.get(table_name)
            if df is None:
                continue
            for calc_col in meta.get("calculated_columns", []):
                col_name = calc_col["name"]
                if col_name in df.columns:
                    continue  # already present (shouldn't happen, but guard)
                series = _resolve_dax_calculated_column(
                    calc_col, table_name, loaded_dfs, relationships
                )
                if series is not None:
                    df[col_name] = series
                    logger.info(
                        "%s: Computed calculated column '%s'.'%s'",
                        self.tool_name, table_name, col_name,
                    )
                else:
                    logger.warning(
                        "%s: Could not resolve calculated column '%s'.'%s' (DAX: %s)",
                        self.tool_name, table_name, col_name, calc_col["dax"],
                    )

    @staticmethod
    def _make_descriptive_filename(
        visual_info: Dict[str, Any],
        visual_type: str,
        seen_names: set,
    ) -> Tuple[str, str]:
        """Generate a human-readable filename and label from visual data bindings.

        Returns ``(csv_filename, label)`` where label has spaces for display,
        e.g. ``("Total_Order_Quantity_by_Total_Net_Price__scatterChart.csv",
                 "Total Order Quantity by Total Net Price")``

        The ``visual_type`` suffix is always appended to guarantee uniqueness
        when multiple chart types share the same dimension/measure pair.
        """
        dims = visual_info["dimensions"]
        measures = visual_info["measures"]

        def slug(s: str) -> str:
            return re.sub(r"[^\w]+", "_", s).strip("_")

        if dims and measures:
            dim_part = " and ".join(d["property"] for d in dims[:2])
            meas_part = " and ".join(m["property"] for m in measures[:2])
        elif measures:
            # Scatter / pure-measure visual: "X by Y"
            dim_part = measures[0]["property"] if len(measures) >= 1 else ""
            meas_part = measures[1]["property"] if len(measures) >= 2 else measures[0]["property"]
        else:
            dim_part = visual_type
            meas_part = "data"

        label = f"{dim_part} by {meas_part}"
        base_slug = f"{slug(dim_part)}_by_{slug(meas_part)}__{visual_type}"
        csv_filename = f"{base_slug}.csv"

        # De-duplicate: if the same base already exists, append a counter
        counter = 2
        while csv_filename in seen_names:
            csv_filename = f"{base_slug}_{counter}.csv"
            counter += 1

        seen_names.add(csv_filename)
        return csv_filename, label

    def _extract_visuals(
        self,
        pages_dir: Path,
        schema: Dict[str, Dict[str, Any]],
        loaded_dfs: Dict[str, pd.DataFrame],
        relationships: List[Dict[str, str]],
        output_dir: Path,
    ) -> Tuple[List[Dict[str, Any]], List[Path]]:
        """Walk all pages/visuals, compute data, and write CSVs."""
        summary: List[Dict[str, Any]] = []
        csv_files: List[Path] = []
        seen_names: set = set()

        if not pages_dir.is_dir():
            return summary, csv_files

        for page_folder in sorted(pages_dir.iterdir()):
            if not page_folder.is_dir():
                continue
            page_json_path = page_folder / "page.json"
            if not page_json_path.exists():
                continue
            page_meta = json.loads(page_json_path.read_text(encoding="utf-8"))
            page_name = page_meta.get("displayName", page_folder.name)

            visuals_dir = page_folder / "visuals"
            if not visuals_dir.is_dir():
                continue

            for visual_folder in sorted(visuals_dir.iterdir()):
                if not visual_folder.is_dir():
                    continue
                visual_json_path = visual_folder / "visual.json"
                if not visual_json_path.exists():
                    continue

                visual_json = json.loads(visual_json_path.read_text(encoding="utf-8"))
                visual_info = _parse_visual(visual_json)
                visual_type = visual_info["visual_type"]
                visual_id = visual_folder.name

                if not visual_info["measures"] and not visual_info["dimensions"]:
                    logger.debug(
                        "Visual %s (%s) has no data bindings, skipping.", visual_id, visual_type
                    )
                    continue

                df_out = _compute_visual_df(
                    visual_info, schema, loaded_dfs, relationships
                )

                if df_out is None or df_out.empty:
                    # Check if any of the visual's tables are DB-sourced
                    visual_tables = (
                        {d["entity"] for d in visual_info["dimensions"]}
                        | {m["entity"] for m in visual_info["measures"]}
                    )
                    has_db_tables = any(
                        schema.get(t, {}).get("source_type") in ("snowflake", "mysql")
                        for t in visual_tables
                    )
                    if has_db_tables:
                        df_out = _build_db_visual_metadata_df(visual_info, schema)
                        if df_out is None or df_out.empty:
                            logger.warning(
                                "%s: DB visual %s (%s) has no field bindings, skipping.",
                                self.tool_name, visual_id[:8], visual_type,
                            )
                            continue
                        logger.info(
                            "%s: DB-sourced visual %s (%s) — generating metadata CSV.",
                            self.tool_name, visual_id[:8], visual_type,
                        )
                    else:
                        logger.warning(
                            "%s: Could not compute data for visual %s (%s) on page '%s'",
                            self.tool_name, visual_id[:8], visual_type, page_name,
                        )
                        continue

                csv_filename, label = self._make_descriptive_filename(
                    visual_info, visual_type, seen_names
                )
                csv_path = output_dir / csv_filename
                df_out.to_csv(csv_path, index=False)
                csv_files.append(csv_path)

                # Determine whether this entry was built from live data or DB metadata
                visual_tables = (
                    {d["entity"] for d in visual_info["dimensions"]}
                    | {m["entity"] for m in visual_info["measures"]}
                )
                is_db_visual = any(
                    schema.get(t, {}).get("source_type") in ("snowflake", "mysql")
                    for t in visual_tables
                )

                summary.append(
                    {
                        "page": page_name,
                        "visual_type": visual_type,
                        "visual_id": visual_id,
                        "label": label,
                        "csv_filename": csv_filename,
                        "rows": len(df_out),
                        "columns": list(df_out.columns),
                        "source_type": "database" if is_db_visual else "embedded",
                    }
                )
                logger.info(
                    "%s: Wrote %s — '%s' (%d rows)", self.tool_name, csv_filename, label, len(df_out)
                )

        return summary, csv_files

    def _generate_db_summary_csvs(
        self,
        schema: Dict[str, Dict[str, Any]],
        relationships: List[Dict[str, str]],
        output_dir: Path,
    ) -> List[Path]:
        """Generate summary CSVs for DB-sourced tables and include them in the zip.

        Produces up to three files:
        * ``db_connections.csv``  — unique Snowflake / MySQL endpoints
        * ``db_tables.csv``       — all DB-sourced tables with connection coords
        * ``db_relationships.csv``— relationships that involve a DB table
        """
        csv_files: List[Path] = []
        db_tables = {
            tname: tmeta
            for tname, tmeta in schema.items()
            if tmeta.get("source_type") in ("snowflake", "mysql")
        }
        if not db_tables:
            return csv_files

        # --- db_connections.csv ---
        seen: set = set()
        conn_rows: List[Dict] = []
        for t in db_tables.values():
            st = t["source_type"]
            conn = t["connection"]
            if st == "snowflake":
                key = ("snowflake", conn.get("server", ""), conn.get("warehouse", ""))
                if key not in seen:
                    seen.add(key)
                    conn_rows.append(
                        {
                            "connection_type": "Snowflake",
                            "server": conn.get("server", ""),
                            "warehouse": conn.get("warehouse", ""),
                            "host": "",
                            "port": "",
                        }
                    )
            else:
                key = ("mysql", conn.get("host", ""), conn.get("port", "3306"))
                if key not in seen:
                    seen.add(key)
                    conn_rows.append(
                        {
                            "connection_type": "MySQL",
                            "server": "",
                            "warehouse": "",
                            "host": conn.get("host", ""),
                            "port": conn.get("port", "3306"),
                        }
                    )
        if conn_rows:
            p = output_dir / "db_connections.csv"
            pd.DataFrame(
                conn_rows,
                columns=["connection_type", "server", "warehouse", "host", "port"],
            ).to_csv(p, index=False)
            csv_files.append(p)

        # --- db_tables.csv ---
        table_rows = []
        for t in db_tables.values():
            conn = t["connection"]
            table_rows.append(
                {
                    "table_name": t["table_name"],
                    "source_type": t["source_type"],
                    "db_server_or_host": conn.get("server") or conn.get("host") or "",
                    "db_warehouse": conn.get("warehouse", ""),
                    "db_database": conn.get("database", ""),
                    "db_schema": conn.get("schema", ""),
                    "db_table": conn.get("table", ""),
                    "has_native_query": bool(conn.get("native_query")),
                    "native_query": (conn.get("native_query") or "").replace("\n", " "),
                    "num_columns": len(t.get("columns", [])),
                    "num_calculated_columns": len(t.get("calculated_columns", [])),
                    "num_measures": len(t.get("measures", [])),
                }
            )
        p = output_dir / "db_tables.csv"
        pd.DataFrame(
            table_rows,
            columns=[
                "table_name", "source_type", "db_server_or_host", "db_warehouse",
                "db_database", "db_schema", "db_table", "has_native_query",
                "native_query", "num_columns", "num_calculated_columns", "num_measures",
            ],
        ).to_csv(p, index=False)
        csv_files.append(p)

        # --- db_relationships.csv ---
        db_table_names = set(db_tables.keys())
        db_rels = [
            r for r in relationships
            if r.get("from_table") in db_table_names or r.get("to_table") in db_table_names
        ]
        if db_rels:
            p = output_dir / "db_relationships.csv"
            pd.DataFrame(
                db_rels,
                columns=["from_table", "from_col", "to_table", "to_col"],
            ).to_csv(p, index=False)
            csv_files.append(p)

        logger.info(
            "%s: Generated %d DB summary CSV(s) for %d DB-sourced table(s).",
            self.tool_name, len(csv_files), len(db_tables),
        )
        return csv_files

    def _pack_output(
        self,
        csv_files: List[Path],
        session_id: Optional[str],
        output_dir: Path,
    ) -> Path:
        """Pack all per-visual CSVs into a zip in the artifacts directory."""
        ist = timezone(timedelta(hours=5, minutes=30))
        timestamp = datetime.now(ist).strftime("%Y%m%d_%H%M%S")
        zip_name = f"pbip_visuals_{timestamp}.zip"

        # Resolve output location
        if session_id:
            try:
                from daan.flow.session_service import get_artifacts_dir
                artifacts_dir = get_artifacts_dir(session_id, create=True)
            except Exception:
                artifacts_dir = output_dir
        else:
            artifacts_dir = output_dir

        out_zip = artifacts_dir / zip_name
        with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for csv_path in csv_files:
                zf.write(csv_path, arcname=csv_path.name)

        return out_zip
