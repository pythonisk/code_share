from __future__ import annotations

import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

from daan.flow.context_vars import daan_session_id as _ctx_session_id
from daan.flow.session_service import get_artifacts_dir

if TYPE_CHECKING:
    from openpyxl import Workbook
    from openpyxl.worksheet.worksheet import Worksheet

logger = logging.getLogger(__name__)


class JsonArtifactTool:
    """Save a final JSON payload as a .json artifact under artifacts/.

    Registered in agent config as: ``JsonArtifactTool.save_json_artifact``
    Compatibility alias: ``JsonArtifactTool.execute_generation``
    Excel conversion: ``JsonArtifactTool.convert_json_to_excel_artifact``
    """

    def __init__(self, data_dir: str | None = None):
        self.tool_name = "JsonArtifactTool"
        self._data_dir = data_dir
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    def save_json_artifact(
        self,
        reviewed_output: object | None = None,
        json_data: object | None = None,
        file_name: str | None = None,
        file_path: str | None = None,
        output_file_name: str | None = None,
        session_id: str | None = None,
        **kwargs: object,
    ) -> dict[str, object]:
        """Read a final JSON payload and persist it as an artifact file."""
        try:
            payload = self._resolve_payload(
                primary=json_data if json_data is not None else reviewed_output,
                file_name=file_name,
                file_path=file_path,
                kwargs=kwargs,
            )
            if payload is None:
                payload = self._build_fallback_payload(
                    primary=json_data if json_data is not None else reviewed_output,
                    file_name=file_name,
                    file_path=file_path,
                    kwargs=kwargs,
                )
            if payload is None:
                return {
                    "status": "error",
                    "errors": [
                        "No payload found. Provide json_data/reviewed_output or place an input file in the session inputs folder."
                    ],
                }

            artifacts_dir = self._resolve_artifacts_dir(session_id=session_id)
            artifact_path = self._next_available_artifact_path(
                artifacts_dir,
                output_file_name or f"json_artifact_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            )
            artifact_path.write_text(
                json.dumps(payload, ensure_ascii=False, indent=2, default=str),
                encoding="utf-8",
            )

            message = f"Saved JSON artifact: {artifact_path.name}"
            logger.info("%s: %s", self.tool_name, message)
            return {
                "status": "ok",
                "message": message,
                "artifact_name": artifact_path.name,
                "artifact_path": str(artifact_path),
                "json_path": str(artifact_path),
                "ui_output": message,
                "reviewed_output": message,
            }
        except Exception as exc:
            logger.exception("%s: JSON artifact creation failed", self.tool_name)
            return {
                "status": "error",
                "errors": [f"JSON artifact creation failed: {exc}"],
            }

    def execute_generation(
        self,
        reviewed_output: object | None = None,
        json_data: object | None = None,
        file_name: str | None = None,
        file_path: str | None = None,
        output_file_name: str | None = None,
        session_id: str | None = None,
        **kwargs: object,
    ) -> dict[str, object]:
        return self.save_json_artifact(
            reviewed_output=reviewed_output,
            json_data=json_data,
            file_name=file_name,
            file_path=file_path,
            output_file_name=output_file_name,
            session_id=session_id,
            **kwargs,
        )

    def convert_json_to_excel_artifact(
        self,
        reviewed_output: object | None = None,
        json_data: object | None = None,
        file_name: str | None = None,
        file_path: str | None = None,
        output_file_name: str | None = None,
        session_id: str | None = None,
        **kwargs: object,
    ) -> dict[str, object]:
        """Read a final JSON payload and convert it into a tabular Excel artifact."""
        try:
            payload = self._resolve_payload(
                primary=json_data if json_data is not None else reviewed_output,
                file_name=file_name,
                file_path=file_path,
                kwargs=kwargs,
            )
            if payload is None:
                return {
                    "status": "error",
                    "errors": [
                        "No JSON payload found. Provide json_data/reviewed_output or place a .json file in the session inputs folder."
                    ],
                }

            artifacts_dir = self._resolve_artifacts_dir(session_id=session_id)
            artifact_path = self._next_available_excel_path(
                artifacts_dir,
                output_file_name or f"json_tabular_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
            )
            self._write_workbook(artifact_path, payload)

            message = f"Generated Excel workbook from JSON: {artifact_path.name}"
            logger.info("%s: %s", self.tool_name, message)
            return {
                "status": "ok",
                "message": message,
                "artifact_name": artifact_path.name,
                "artifact_path": str(artifact_path),
                "excel_path": str(artifact_path),
                "ui_output": message,
                "reviewed_output": message,
            }
        except Exception as exc:
            logger.exception("%s: JSON to Excel conversion failed", self.tool_name)
            return {
                "status": "error",
                "errors": [f"JSON to Excel conversion failed: {exc}"],
            }

    def convert_json_file_to_excel(
        self,
        input_file: str,
        output_file: str | None = None,
    ) -> dict[str, object]:
        """Convert a JSON file into an Excel workbook at an explicit output path."""
        try:
            input_path = Path(input_file).expanduser()
            if not input_path.is_absolute():
                input_path = input_path.resolve()
            if not input_path.is_file():
                return {
                    "status": "error",
                    "errors": [f"Input JSON file not found: {input_file}"],
                }

            payload = self._coerce_json(input_path.read_text(encoding="utf-8"))
            if payload is None:
                return {
                    "status": "error",
                    "errors": [f"Input file is not valid JSON: {input_path}"],
                }

            if output_file:
                output_path = Path(output_file).expanduser()
                if not output_path.is_absolute():
                    output_path = output_path.resolve()
            else:
                output_path = input_path.with_suffix(".xlsx")

            output_path.parent.mkdir(parents=True, exist_ok=True)
            self._write_workbook(output_path, payload)

            message = f"Generated Excel workbook from JSON file: {output_path.name}"
            logger.info("%s: %s", self.tool_name, message)
            return {
                "status": "ok",
                "message": message,
                "input_path": str(input_path),
                "output_path": str(output_path),
                "excel_path": str(output_path),
                "artifact_name": output_path.name,
                "ui_output": message,
                "reviewed_output": message,
            }
        except Exception as exc:
            logger.exception("%s: JSON file to Excel conversion failed", self.tool_name)
            return {
                "status": "error",
                "errors": [f"JSON file to Excel conversion failed: {exc}"],
            }

    def run(
        self,
        reviewed_output: object | None = None,
        json_data: object | None = None,
        file_name: str | None = None,
        file_path: str | None = None,
        output_file_name: str | None = None,
        session_id: str | None = None,
        **kwargs: object,
    ) -> dict[str, object]:
        return self.save_json_artifact(
            reviewed_output=reviewed_output,
            json_data=json_data,
            file_name=file_name,
            file_path=file_path,
            output_file_name=output_file_name,
            session_id=session_id,
            **kwargs,
        )

    def execute(
        self,
        reviewed_output: object | None = None,
        json_data: object | None = None,
        file_name: str | None = None,
        file_path: str | None = None,
        output_file_name: str | None = None,
        session_id: str | None = None,
        **kwargs: object,
    ) -> dict[str, object]:
        return self.save_json_artifact(
            reviewed_output=reviewed_output,
            json_data=json_data,
            file_name=file_name,
            file_path=file_path,
            output_file_name=output_file_name,
            session_id=session_id,
            **kwargs,
        )

    def _resolve_payload(
        self,
        primary: object | None,
        file_name: str | None,
        file_path: str | None,
        kwargs: dict[str, object],
    ) -> object | None:
        payload = self._coerce_json(primary)
        if payload is not None:
            return payload

        for key in ("content", "output", "text", "message", "json_payload"):
            payload = self._coerce_json(kwargs.get(key))
            if payload is not None:
                return payload

        candidate = self._resolve_input_file(file_name=file_name, file_path=file_path, kwargs=kwargs)
        if candidate is None:
            return None
        return self._coerce_json(candidate.read_text(encoding="utf-8"))

    def _build_fallback_payload(
        self,
        primary: object | None,
        file_name: str | None,
        file_path: str | None,
        kwargs: dict[str, object],
    ) -> dict[str, object] | None:
        source = self._resolve_raw_source(primary=primary, file_name=file_name, file_path=file_path, kwargs=kwargs)
        if source is None:
            return None
        source_name, raw_value = source
        raw_text = self._stringify_raw_payload(raw_value)
        if not raw_text.strip():
            return None
        return {
            "raw_output": raw_text,
            "parsed_json": {},
            "is_valid_json": False,
            "source": source_name,
        }

    def _resolve_raw_source(
        self,
        primary: object | None,
        file_name: str | None,
        file_path: str | None,
        kwargs: dict[str, object],
    ) -> tuple[str, object] | None:
        if primary not in (None, ""):
            return ("primary", primary)

        for key in ("content", "output", "text", "message", "json_payload"):
            value = kwargs.get(key)
            if value not in (None, ""):
                return (key, value)

        candidate = self._resolve_input_file(file_name=file_name, file_path=file_path, kwargs=kwargs)
        if candidate is None:
            return None
        return ("input_file", candidate.read_text(encoding="utf-8"))

    def _stringify_raw_payload(self, value: object) -> str:
        if isinstance(value, str):
            return value
        if isinstance(value, Path):
            return value.read_text(encoding="utf-8")
        try:
            return json.dumps(value, ensure_ascii=False, indent=2, default=str)
        except TypeError:
            return str(value)

    def _coerce_json(self, value: object | None) -> object | None:
        if value is None:
            return None
        if isinstance(value, (dict, list)):
            return value
        if isinstance(value, str):
            text = value.strip()
            if not text:
                return None
            if text.startswith("```"):
                match = re.match(r"^```[a-zA-Z0-9_-]*\s*\n(?P<body>[\s\S]*?)\n```\s*$", text)
                if match:
                    text = match.group("body").strip()
            path_candidate = Path(text)
            if path_candidate.suffix.lower() == ".json" and path_candidate.exists():
                return self._coerce_json(path_candidate.read_text(encoding="utf-8"))
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return None
        return None

    def _resolve_input_file(
        self,
        file_name: str | None,
        file_path: str | None,
        kwargs: dict[str, object],
    ) -> Path | None:
        inputs_dir = Path(self._data_dir) if self._data_dir else None

        explicit_path = file_path or kwargs.get("path") or kwargs.get("json_file")
        if explicit_path:
            candidate = Path(str(explicit_path)).expanduser()
            if not candidate.is_absolute() and inputs_dir is not None:
                candidate = inputs_dir / candidate
            if candidate.is_file():
                return candidate.resolve()

        explicit_name = file_name or kwargs.get("file_names") or kwargs.get("input_file")
        if explicit_name and inputs_dir is not None:
            candidate = (inputs_dir / str(explicit_name)).resolve()
            if candidate.is_file():
                return candidate

        if inputs_dir is None or not inputs_dir.is_dir():
            return None

        for item in sorted(inputs_dir.iterdir()):
            if item.is_file() and item.suffix.lower() == ".json":
                return item.resolve()
        return None

    def _resolve_artifacts_dir(self, session_id: str | None) -> Path:
        if self._data_dir:
            data_path = Path(self._data_dir)
            session_dir = data_path.parent if data_path.name.lower() == "inputs" else data_path
            artifacts_dir = get_artifacts_dir(session_dir.name, create=True)
            artifacts_dir.mkdir(parents=True, exist_ok=True)
            return artifacts_dir

        resolved_session_id = session_id or _ctx_session_id.get()
        if resolved_session_id:
            artifacts_dir = get_artifacts_dir(resolved_session_id, create=True)
            artifacts_dir.mkdir(parents=True, exist_ok=True)
            return artifacts_dir

        artifacts_dir = Path(__file__).resolve().parent / "artifacts"
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        return artifacts_dir

    def _next_available_artifact_path(self, artifacts_dir: Path, file_name: str) -> Path:
        safe_name = Path(file_name).name
        if not safe_name.lower().endswith(".json"):
            safe_name = f"{safe_name}.json"
        candidate = artifacts_dir / safe_name
        if not candidate.exists():
            return candidate

        stem = candidate.stem
        suffix = candidate.suffix
        index = 2
        while True:
            retry = artifacts_dir / f"{stem}_{index}{suffix}"
            if not retry.exists():
                return retry
            index += 1

    def _next_available_excel_path(self, artifacts_dir: Path, file_name: str) -> Path:
        safe_name = Path(file_name).name
        if not safe_name.lower().endswith(".xlsx"):
            safe_name = f"{safe_name}.xlsx"
        candidate = artifacts_dir / safe_name
        if not candidate.exists():
            return candidate

        stem = candidate.stem
        suffix = candidate.suffix
        index = 2
        while True:
            retry = artifacts_dir / f"{stem}_{index}{suffix}"
            if not retry.exists():
                return retry
            index += 1

    def _write_workbook(self, path: Path, payload: object) -> None:
        from openpyxl import Workbook

        workbook = Workbook()
        default_sheet = workbook.active
        if default_sheet is not None:
            workbook.remove(default_sheet)

        self._write_payload_sheet(workbook, "Data", payload)

        if not workbook.sheetnames:
            sheet = workbook.create_sheet("Data")
            sheet.append(["Value"])
            sheet.append([self._stringify(payload)])

        workbook.save(path)

    def _write_payload_sheet(
        self,
        workbook: Workbook,
        sheet_name: str,
        payload: object,
        *,
        prefer_table_for_empty_list: bool = False,
    ) -> None:
        safe_sheet_name = self._safe_sheet_name(sheet_name)

        if isinstance(payload, list):
            if self._is_table_rows(payload) or (prefer_table_for_empty_list and not payload):
                self._write_table_sheet(workbook, safe_sheet_name, payload)
                return
            self._write_list_sheet(workbook, safe_sheet_name, payload)
            return

        if isinstance(payload, dict):
            scalar_items: dict[str, object] = {}
            nested_written = False
            for key, value in payload.items():
                if isinstance(value, list):
                    self._write_payload_sheet(
                        workbook,
                        str(key),
                        value,
                        prefer_table_for_empty_list=True,
                    )
                    nested_written = True
                    continue
                if isinstance(value, dict):
                    if self._write_embedded_table_sheet(workbook, str(key), value):
                        nested_written = True
                    else:
                        self._write_key_value_sheet(workbook, str(key), value)
                        nested_written = True
                    continue
                scalar_items[str(key)] = value

            if scalar_items:
                self._write_key_value_sheet(workbook, safe_sheet_name, scalar_items)
            if not scalar_items and not nested_written:
                self._write_key_value_sheet(workbook, safe_sheet_name, payload)
            return

        sheet = workbook.create_sheet(safe_sheet_name)
        sheet.append(["Value"])
        sheet.append([self._stringify(payload)])

    def _write_table_sheet(
        self,
        workbook: Workbook,
        sheet_name: str,
        rows: list[dict[str, object]],
        headers: list[str] | None = None,
    ) -> None:
        sheet = workbook.create_sheet(self._safe_sheet_name(sheet_name))
        resolved_headers = headers or self._collect_headers(rows)
        sheet.append(resolved_headers)
        for row in rows:
            sheet.append([self._stringify(row.get(header)) for header in resolved_headers])
        self._autofit(sheet)

    def _write_key_value_sheet(self, workbook: Workbook, sheet_name: str, data: dict[str, object]) -> None:
        sheet = workbook.create_sheet(self._safe_sheet_name(sheet_name))
        sheet.append(["Key", "Value"])
        for key, value in data.items():
            sheet.append([str(key), self._stringify(value)])
        self._autofit(sheet)

    def _write_list_sheet(self, workbook: Workbook, sheet_name: str, values: list[object]) -> None:
        sheet = workbook.create_sheet(self._safe_sheet_name(sheet_name))
        sheet.append(["Value"])
        for value in values:
            sheet.append([self._stringify(value)])
        self._autofit(sheet)

    def _write_embedded_table_sheet(self, workbook: Workbook, sheet_name: str, data: dict[str, object]) -> bool:
        for rows_key in ("rows", "records", "data", "items"):
            rows_value = data.get(rows_key)
            if not isinstance(rows_value, list):
                continue
            if rows_value and not self._is_table_rows(rows_value):
                continue
            headers = self._extract_headers(data.get("columns"))
            self._write_table_sheet(workbook, sheet_name, rows_value, headers=headers)
            return True
        return False

    def _extract_headers(self, columns: object) -> list[str] | None:
        if not isinstance(columns, list):
            return None

        headers: list[str] = []
        for column in columns:
            if isinstance(column, str):
                headers.append(column)
                continue
            if isinstance(column, dict):
                for key in ("name", "column_name", "key", "field"):
                    value = column.get(key)
                    if value not in (None, ""):
                        headers.append(str(value))
                        break
        return headers or None

    def _collect_headers(self, rows: list[dict[str, object]]) -> list[str]:
        headers: list[str] = []
        seen: set[str] = set()
        for row in rows:
            for key in row.keys():
                text = str(key)
                if text in seen:
                    continue
                seen.add(text)
                headers.append(text)
        return headers or ["Value"]

    def _is_table_rows(self, value: object) -> bool:
        return isinstance(value, list) and all(isinstance(item, dict) for item in value)

    def _stringify(self, value: object) -> str:
        if value is None:
            return ""
        if isinstance(value, (dict, list)):
            return json.dumps(value, ensure_ascii=False)
        return str(value)

    def _safe_sheet_name(self, value: str) -> str:
        text = re.sub(r"[\\/*?:\[\]]", "_", (value or "Data")).strip()
        text = text or "Data"
        return text[:31]

    def _autofit(self, sheet: Worksheet) -> None:
        from openpyxl.utils import get_column_letter

        for column_cells in sheet.columns:
            values = [len(str(cell.value or "")) for cell in column_cells]
            max_width = min(max(values, default=10) + 2, 60)
            first_index = column_cells[0].column
            if isinstance(first_index, int):
                sheet.column_dimensions[get_column_letter(first_index)].width = max_width


__all__ = ["JsonArtifactTool"]