"""
Power BI Report Tool
Handles the physical creation of Power BI Project (.pbip) file structures.
Implements specific logic for TMDL and PBIR generation.
"""

import os
import json
import logging
import uuid
import random
import shutil
import math
from pathlib import Path
from typing import Dict, Any, List, Optional
import tempfile
from dotenv import load_dotenv
import zipfile

from daan.native_tools.power_bi.power_bi_schema_validator import PowerBISchemaValidator

__all__ = ["PowerBIReportGenerator"]

# Load environment variables
load_dotenv()

def _escape_m_identifier(value: str) -> str:
    """
    Create a safe M language identifier for a column or table name.
    In M, identifiers with spaces or special characters use [#"..."] syntax.
    """
    if not value:
        return '[#""]'
    
    # Check if name needs special quoting (has spaces, special chars, or reserved words)
    needs_quoting = not value.replace('_', '').isalnum() or value[0].isdigit()
    
    if needs_quoting:
        # Escape internal quotes for M syntax
        escaped = value.replace('"', '""')
        return f'[#{chr(34)}{escaped}{chr(34)}]'  # Using chr(34) for "
    else:
        return f'[{value}]'

def _escape_m_string(value: str) -> str:
    """
    Escape a string value for safe use in M (Power Query) code.
    In M, double quotes inside strings are escaped by doubling them.
    """
    if value is None:
        return ""
    return str(value).replace('"', '""')

logger = logging.getLogger(__name__)

class PowerBIReportGenerator:
    """
    Tool for generating Power BI Project (.pbip) file structures.
    Uses PBIP format (Project) with .Report (PBIR) and .SemanticModel (TMDL).
    """
    
    def __init__(self, data_dir: Optional[str] = None):
        """Initialize the tool."""
        self.data_dir = Path(data_dir) if data_dir else None
        self.page_visuals = {}  # Track visuals per page: {page_id: [{id, mapped_type}]}
        self.page_layouts = {}  # Track layout stats per page: {page_id: {card_count, visual_count}}
        self.first_page_id = None  # ID of the first (banner) page
        self.global_measure_names = set()  # Track all measure names for uniqueness

    def _choose_build_base_dir(self) -> Path:
        """Choose a build directory for PBIP generation.

        On Windows, PBIP folder structures can exceed MAX_PATH (WinError 206)
        when the workspace path is already long (e.g., OneDrive). To avoid that,
        build under a short temp root unless overridden.
        We default to the OS temp directory.
        """
        override = os.getenv('POWERBI_BUILD_DIR')
        if override:
            try:
                return Path(override)
            except Exception:
                pass

        return Path(tempfile.gettempdir()) / 'daan_pbi'


    
    def create_project(self, schema: Dict[str, Any]) -> str:
        """
        Create a Power BI project structure from a high-level schema.

        Tables support a SLIM FORMAT where 'columns' can be omitted —
        they will be auto-detected from the source file.

        Minimal table definition:
        {
            "name": "Sales",
            "source": { "path": "data/sales.csv" },
            "measures": [ ... ]
        }

        Returns:
            A concise string message for the LLM describing success or failure.
        """
        try:
            # ── SAVE TOOL INPUT IMMEDIATELY FOR DEBUGGING ────────────────────
            if self.data_dir:
                try:
                    input_path = self.data_dir.parent / "power_bi_tool_input.json"
                    with open(input_path, "w", encoding="utf-8") as _f:
                        json.dump(schema, _f, indent=2, ensure_ascii=False)
                    logger.info(f"Power BI tool input saved to: {input_path}")
                except Exception as _e:
                    logger.warning(f"Could not save Power BI tool input: {_e}")

            # ── VALIDATE & AUTO-FIX SCHEMA ────────────────────────────────
            validator = PowerBISchemaValidator(data_dir=self.data_dir)
            result = validator.validate_and_fix(schema)

            if result.auto_fixes:
                logger.info(f"Validator applied {len(result.auto_fixes)} auto-fix(es)")
                for fix in result.auto_fixes:
                    logger.info(f"  - {fix}")

            if not result.ok:
                logger.error("Schema validation failed after auto-fix:")
                for err in result.errors:
                    logger.error(f"  - {err}")
                return result.to_tool_error()

            schema = result.schema

            # ── PROJECT SETUP ─────────────────────────────────────────────
            project_name = schema.get("project_name", "PowerBI_Project")
            
            # Sanitize project name
            safe_name = "".join(c for c in project_name if c.isalnum() or c in ('_', '-')).strip()
            if not safe_name:
                safe_name = "PowerBI_Project"
                
            # Keep the name short to avoid Windows MAX_PATH length issues (limit 260 chars).
            # The full path inside the zip is:
            #   <name>\<name>.SemanticModel\definition\relationships\<rel_file>.tmdl
            # so the project name contributes 2x — keep it very short.
            if len(safe_name) > 28:
                import hashlib
                safe_name = safe_name[:20] + "_" + hashlib.md5(safe_name.encode()).hexdigest()[:4]
            
            base_dir = self._choose_build_base_dir()
            try:
                os.makedirs(base_dir, exist_ok=True)
            except Exception:
                pass
            
            self.project_name = safe_name
            self.base_dir = base_dir
            
            self.project_folder_path = base_dir / safe_name
            self.project_file_path = self.project_folder_path / f"{safe_name}.pbip"
            
            self.report_dir = self.project_folder_path / f"{safe_name}.Report"
            self.model_dir = self.project_folder_path / f"{safe_name}.SemanticModel"
            
            # Track relationship key columns for data quality handling
            self.relationship_keys = set()
            
            # Track table names for DAX validation
            self.table_names = set()
            
            # Initialize page visuals tracker for this project
            self.page_visuals = {}
            self.page_layouts = {}
            
            # Clean up old project if exists
            if self.project_folder_path.exists():
                shutil.rmtree(self.project_folder_path)
            os.makedirs(self.project_folder_path, exist_ok=True)
            
            # 1. Initialize Structure
            self._ensure_root()
            
            # 2. Build Semantic Model
            semantic_model = schema.get("semantic_model", {})

            # 2a. Extract relationship key columns
            relationships = semantic_model.get("relationships", [])
            for rel in relationships:
                to_table = rel.get("toTable")
                to_col = rel.get("toColumn")
                from_table = rel.get("fromTable")
                from_col = rel.get("fromColumn")
                
                if to_table and to_col:
                    self.relationship_keys.add((to_table, to_col))
                if from_table and from_col:
                    self.relationship_keys.add((from_table, from_col))
            
            # 2b. Add tables
            tables = semantic_model.get("tables", [])
            for table in tables:
                table_name = table.get("name")
                self.table_names.add(table_name)
                
                source_obj = table.get("source", {})
                if isinstance(source_obj, dict):
                    source_path = source_obj.get("path")
                else:
                    source_path = table.get("source_file")

                self._add_table(
                    table_name=table_name,
                    columns={c["name"]: c["dataType"] for c in table.get("columns", [])},
                    measures={m["name"]: self._fix_dax_syntax(m["expression"], table_name) for m in table.get("measures", [])},
                    calculated_columns={cc["name"]: cc.get("expression", "") for cc in table.get("calculated_columns", []) if cc.get("name") and cc.get("expression")},
                    source_file=source_path,
                    source_info=source_obj if isinstance(source_obj, dict) else None
                )
            
            # ── FINAL SAFETY: drop relationships that reference missing tables/columns ──
            cleaned_relationships = []
            dropped_rels = []

            for rel in relationships:
                f_tbl = rel.get("fromTable")
                f_col = rel.get("fromColumn")
                t_tbl = rel.get("toTable")
                t_col = rel.get("toColumn")

                # Table must exist
                if f_tbl not in self.table_names or t_tbl not in self.table_names:
                    dropped_rels.append(f"{f_tbl}[{f_col}] → {t_tbl}[{t_col}] (missing table)")
                    continue

                # Column must exist in originating tables
                from_table_obj = next(
                    (t for t in semantic_model.get("tables", []) if t.get("name") == f_tbl),
                    None
                )
                to_table_obj = next(
                    (t for t in semantic_model.get("tables", []) if t.get("name") == t_tbl),
                    None
                )

                if not from_table_obj or not to_table_obj:
                    dropped_rels.append(f"{f_tbl}[{f_col}] → {t_tbl}[{t_col}] (table object not found)")
                    continue

                from_columns = {c.get("name") for c in from_table_obj.get("columns", [])}
                to_columns = {c.get("name") for c in to_table_obj.get("columns", [])}

                if f_col not in from_columns or t_col not in to_columns:
                    dropped_rels.append(f"{f_tbl}[{f_col}] → {t_tbl}[{t_col}] (missing column)")
                    continue

                cleaned_relationships.append(rel)

            if dropped_rels:
                for d in dropped_rels:
                    logger.warning(f"Dropped relationship: {d}")
                    result.warnings.append(f"Dropped relationship: {d}")

            relationships = cleaned_relationships

            # 2c. Add Relationships
            if relationships:
                self._add_relationships(relationships)
                
            # 3. Build Report
            MAX_VISUALS_PER_PAGE = 4
            report = schema.get("report", {})
            pages = report.get("pages", [])
            global_data_signatures = {}
            for page in pages:
                page_name = page.get("name", "Page 1")
                visuals = page.get("visuals", [])

                valid_visuals = []
                seen_titles = set()
                for visual in visuals:
                    vtitle = (visual.get("title") or "").strip()
                    if vtitle and vtitle in seen_titles:
                        logger.warning(f"Skipping duplicate visual '{vtitle}' on page '{page_name}'")
                        continue
                    if vtitle:
                        seen_titles.add(vtitle)

                    data_mapping = visual.get("data", {})
                    vtype = visual.get("type", "")
                    data_sig = self._compute_visual_data_signature(vtype, data_mapping)
                    if data_sig:
                        if data_sig in global_data_signatures:
                            prev_page, prev_title = global_data_signatures[data_sig]
                            if prev_page != page_name:
                                logger.warning(
                                    f"Skipping cross-page duplicate visual '{vtitle}' on page "
                                    f"'{page_name}' — same data binding already on page "
                                    f"'{prev_page}' as '{prev_title}'"
                                )
                                continue
                        global_data_signatures[data_sig] = (page_name, vtitle)

                    valid_visuals.append(visual)

                for chunk_idx in range(0, max(len(valid_visuals), 1), MAX_VISUALS_PER_PAGE):
                    chunk = valid_visuals[chunk_idx:chunk_idx + MAX_VISUALS_PER_PAGE]
                    if not chunk:
                        page_id = self._create_page(page_name)
                        self.page_layouts[page_id] = {"card_count": 0, "visual_count": 0}
                        continue

                    if chunk_idx == 0:
                        current_page_name = page_name
                    else:
                        overflow_num = (chunk_idx // MAX_VISUALS_PER_PAGE) + 1
                        current_page_name = f"{page_name} ({overflow_num})"
                        logger.info(f"Page '{page_name}' has more than {MAX_VISUALS_PER_PAGE} visuals — "
                                    f"overflowing {len(chunk)} visual(s) to '{current_page_name}'")

                    page_id = self._create_page(current_page_name)
                    self.page_layouts[page_id] = {
                        "card_count": sum(
                            1 for visual in chunk
                            if self._map_visual_type(visual.get("type", "")) == "card"
                        ),
                        "visual_count": len(chunk)
                    }
                    for visual in chunk:
                        self._add_visual(
                            page_id=page_id,
                            visual_type=visual.get("type", ""),
                            title=visual.get("title"),
                            data_mapping=visual.get("data", {})
                        )
            
            # 4. Copy Input Files and Generate Instructions
            if self.data_dir and self.data_dir.exists():
                # Universally copy all tabular data files found in the session inputs folder
                # to the PBIP folder, ensuring nothing is missed for the LLM's requests
                for f in self.data_dir.iterdir():
                    if f.is_file() and f.suffix.lower() in ('.csv', '.xlsx', '.xls', '.json'):
                        logger.info(f"Copying tabular file '{f.name}' into PBIP folder.")
                        shutil.copy2(f, self.project_folder_path / f.name)
                            
            self._create_instructions(tables)
            
            # 5. Compress and clean up
            if self.data_dir:
                # We expect data_dir to be .../session_storage/{session_id}/inputs
                # So we go up one level to store the zip in the session folder itself.
                session_dir = self.data_dir.parent if self.data_dir.name == "inputs" else self.data_dir
                
                # Write the zip into the artifacts/ directory for universal download
                artifacts_dir = session_dir / "artifacts"
                artifacts_dir.mkdir(parents=True, exist_ok=True)
                
                zip_base_path = artifacts_dir / safe_name
                # make_archive appends .zip automatically to zip_base_path
                shutil.make_archive(
                    base_name=str(zip_base_path),
                    format='zip',
                    root_dir=self.project_folder_path.parent,
                    base_dir=self.project_folder_path.name
                )
                final_path = f"{zip_base_path}.zip"
                
                # Delete the raw project folder from temp dir to save space
                try:
                    shutil.rmtree(self.project_folder_path)
                except Exception as e:
                    logger.warning(f"Failed to clean up temp project folder {self.project_folder_path}: {e}")
            else:
                # Fallback if no data_dir was provided
                final_path = str(self.project_folder_path)
            
            # Build concise success message for the LLM
            num_tables = len(tables)
            num_pages = len(pages)
            notes = result.to_tool_success_notes()
            msg = (
                f"Power BI project '{safe_name}' created successfully at {final_path}. "
                f"{num_tables} table(s), {num_pages} page(s)."
            )
            if notes:
                msg += f"\n{notes}"
            return msg
            
        except Exception as e:
            logger.error(f"Failed to create Power BI project: {e}", exc_info=True)
            return f"Error creating Power BI project: {e}"

    def _create_instructions(self, tables: List[Dict[str, Any]]):
        """Generates a README file explaining where to put input files."""
        instructions_path = self.project_folder_path / "README.md"
        
        files_needed = []
        for table in tables:
             # Logic to extract filename similar to _add_table
             source_obj = table.get("source", {})
             if isinstance(source_obj, dict):
                src = source_obj.get("path")
             else:
                src = table.get("source_file")
             
             if src:
                 files_needed.append(Path(src).name)
        
        content = f"""# Power BI Project Instructions

This Power BI Project is set up to load data from local files.

## Step 1: Verify Input Files
The following files are required for this report:
"""
        for f in files_needed:
            content += f"- `{f}`\n"

        content += """
**Note:** If these files were available during generation, they have been automatically copied into this folder.
If not, please ensure they are available in a single directory on your machine.

## Step 2: Open Project
Double-click the `.pbip` file to open the project in Power BI Desktop.

## Step 3: Configure Data Source
The project uses a parameter named `DataFolder` to locate the input files. You must set this to the correct path.

1.  In Power BI Desktop, look at the **Home** ribbon.
2.  Click **Transform Data** (the icon, not the dropdown) to open the Power Query Editor.
    *   *Alternatively: Click the dropdown arrow on 'Transform Data' and select 'Edit Permissions' -> 'Edit Parameters' if available.*
3.  In the Power Query Editor, inside the **Queries** pane (left side), select the `DataFolder` parameter.
4.  In the **Current Value** box, enter the full path to the folder containing your files.
    *   **Option A**: If the files are in this project folder (unzipped), copy the path of this folder.
    *   **Option B**: If your files are in a different location (e.g., `Downloads` or `Documents`), copy that path.
5.  Click **Close & Apply** (top left) to load the data.

"""
        with open(instructions_path, 'w') as f:
            f.write(content)

    def _ensure_root(self):
        # 1. Create .pbip file
        pbip_content = {
            "$schema": "https://developer.microsoft.com/json-schemas/fabric/pbip/pbipProperties/1.0.0/schema.json",
            "version": "1.0",
            "artifacts": [
                {
                    "report": {
                        "path": f"{self.project_name}.Report"
                    }
                }
            ],
            "settings": {
                "enableAutoRecovery": True
            }
        }
        with open(self.project_file_path, 'w') as f:
            json.dump(pbip_content, f, indent=4)

        # 2. Create Semantic Model Folder
        if not self.model_dir.exists():
            os.makedirs(self.model_dir)
            self._init_model()

        # 3. Create Report Folder
        if not self.report_dir.exists():
            os.makedirs(self.report_dir / "definition" / "pages")
            self._init_report()

    def _init_model(self):
        # Create .platform file
        with open(self.model_dir / ".platform", 'w') as f:
            json.dump({
                "$schema": "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json",
                "metadata": {
                    "type": "SemanticModel",
                    "displayName": self.project_name
                },
                "config": {
                    "version": "2.0",
                    "logicalId": str(uuid.uuid4())
                }
            }, f, indent=4)

        # Create definition.pbism
        with open(self.model_dir / "definition.pbism", 'w') as f:
            json.dump({
                "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json",
                "version": "4.0",
                "settings": {}
            }, f, indent=4)

        # Create definition folder for TMDL
        tmdl_dir = self.model_dir / "definition"
        if not tmdl_dir.exists():
            os.makedirs(tmdl_dir / "tables")

        # Create base model.tmdl
        tmdl_path = self.model_dir / "definition" / "model.tmdl"
        with open(tmdl_path, 'w') as f:
            # Using raw string for tab characters or explicit escaping
            content = (
                "model Model\n"
                "\tculture: en-US\n"
                "\tdefaultPowerBIDataSourceVersion: powerBI_V3\n\n"
                '\tannotation PBI_ProTooling = ["DevMode"]\n\n'
            )
            f.write(content)            
        # Create DataFolder parameter.
        # Use a generic placeholder path so the PBIP is portable.
        # When the user opens the project in Power BI Desktop, they set this
        # parameter via Transform Data → Edit Parameters to their local data folder.
        default_data_folder = "C:/Path/To/Data/Folder"  # <-- user should change this in Power BI Desktop
        self._add_parameter("DataFolder", default_data_folder, "The folder containing input CSV/Excel files. Set this to the folder where all your data files are located.")

    def _fix_dax_syntax(self, expression: str, current_table: str = None) -> str:
        """Fix common DAX syntax errors from LLM generation.
        
        Args:
            expression: The DAX expression to fix
            current_table: The table this measure belongs to (for context)
        """
        import re
        
        original_expr = expression
        
        # ✅ Fix EARLIER() usage: EARLIER is invalid in measures — replace with simple aggregate.
        # Pattern: COUNTROWS(FILTER(Table, Table[Col] = EARLIER(Table[Col])))
        # Fix:     COUNTROWS(Table)
        earlier_pattern = re.compile(
            r'COUNTROWS\s*\(\s*FILTER\s*\('
            r"[^,]+,"           # table argument
            r"[^=]+=\s*"        # column = 
            r"EARLIER\s*\([^)]+\)"  # EARLIER(Table[Col])
            r"\s*\)\s*\)",
            re.IGNORECASE,
        )
        if earlier_pattern.search(expression):
            # Extract the table name from the FILTER's first argument
            m = re.search(
                r'COUNTROWS\s*\(\s*FILTER\s*\(\s*([^,]+)',
                expression,
                re.IGNORECASE,
            )
            table_ref = m.group(1).strip() if m else (current_table or "Table")
            expression = f"COUNTROWS({table_ref})"
            logger.warning(
                "Auto-fixed EARLIER() in measure: '%s' → '%s' (EARLIER is invalid in measures)",
                original_expr.strip(),
                expression,
            )
            original_expr = expression
        
        # ✅ Quote unquoted table names that contain spaces: TableName[Col] → 'TableName'[Col]
        # Only match a bare word sequence (no parentheses before the bracket) — avoids
        # mangling AVERAGEX(table, expr) or SUMX(table, expr) which look similar.
        def _quote_table_names(match):
            table = match.group(1)
            column = match.group(2)
            # Only quote if the table name actually contains a space and is already not quoted
            if " " in table:
                return f"'{table}'[{column}]"
            return f"{table}[{column}]"

        # Safe pattern: matches only when the bracket is preceded by a plain identifier
        # (letters/digits/underscores/spaces) NOT preceded by a closing paren or quote
        expression = re.sub(
            r"(?<!')\b([A-Za-z][A-Za-z0-9_ ]*[A-Za-z0-9_])\[([^\]]+)\]",
            _quote_table_names,
            expression
        )

        # Step 1: Fix cross-table column references - wrap with RELATED()
        # Find all Table[Column] references
        column_refs = re.findall(r'(\w+)\[(.*?)\]', expression)
        
        if current_table and column_refs:
            for table_name, column_name in column_refs:
                # If this column is from a different table, it needs RELATED()
                if table_name != current_table and table_name in self.table_names:
                    # Check if not already wrapped in RELATED()
                    ref_pattern = rf'{table_name}\[{re.escape(column_name)}\]'
                    # Don't wrap if already in RELATED() or RELATEDTABLE()
                    full_pattern = rf'(?<!RELATED\()(?<!RELATEDTABLE\(){ref_pattern}'
                    
                    def replace_with_related(match):
                        return f'RELATED({match.group(0)})'
                    
                    expression = re.sub(full_pattern, replace_with_related, expression, flags=re.IGNORECASE)
        
        # Step 2: Fix AVERAGE(DATEDIFF(...)) → AVERAGEX(table, DATEDIFF(...))
        # Need to handle nested parentheses properly
        if re.search(r'AVERAGE\s*\(\s*DATEDIFF', expression, re.IGNORECASE):
            # Find AVERAGE( and then extract the full DATEDIFF(...) with balanced parens
            avg_start = re.search(r'AVERAGE\s*\(', expression, re.IGNORECASE)
            if avg_start:
                # Find matching closing paren for AVERAGE
                start_pos = avg_start.end()
                paren_count = 1
                end_pos = start_pos
                
                while end_pos < len(expression) and paren_count > 0:
                    if expression[end_pos] == '(':
                        paren_count += 1
                    elif expression[end_pos] == ')':
                        paren_count -= 1
                    end_pos += 1
                
                if paren_count == 0:
                    # Extract the content between AVERAGE( and matching )
                    datediff_full = expression[start_pos:end_pos-1]
                    
                    # Use current_table if provided
                    if current_table:
                        # Replace AVERAGE(DATEDIFF(...)) with AVERAGEX(table, DATEDIFF(...))
                        fixed = f"AVERAGEX({current_table}, {datediff_full})"
                        expression = expression[:avg_start.start()] + fixed + expression[end_pos:]
                        logger.info(f"Fixed DAX: AVERAGE(DATEDIFF...) → AVERAGEX({current_table}, DATEDIFF...)")
        
        # Step 3: Fix AVERAGE(<complex_expression>) → AVERAGEX(...)
        # More generic pattern for AVERAGE with non-column arguments
        pattern2 = r'AVERAGE\s*\(\s*([A-Z]+)\s*\('
        if re.search(pattern2, expression, re.IGNORECASE) and 'AVERAGEX' not in expression.upper():
            logger.warning(f"DAX may have AVERAGE() with complex expression: {expression}")
            logger.warning("Consider manually reviewing if AVERAGEX() is needed.")
        
        # Step 4: Fix similar patterns for SUM, MIN, MAX with DATEDIFF
        for agg_func in ['SUM', 'MIN', 'MAX', 'COUNT']:
            pattern = f'{agg_func}\\s*\\(\\s*DATEDIFF\\s*\\(([^)]+)\\)\\s*\\)'
            if re.search(pattern, expression, re.IGNORECASE):
                logger.warning(f"Found {agg_func}(DATEDIFF(...)) - may need {agg_func}X correction")
        
        if expression != original_expr:
            logger.info(f"DAX Fixed: {original_expr} → {expression}")
        
        return expression
    
    def _add_parameter(self, name: str, default_value: str, description: str):
        """Creates a Power Query parameter in the semantic model."""
        # Parameters should clearly be expressions in TMDL
        tmdl_dir = self.model_dir / "definition" / "expressions"
        if not tmdl_dir.exists():
             os.makedirs(tmdl_dir)
        
        # Sanitize parameter name for filename
        safe_param_name = name.replace('::', '_').replace(':', '_')
        safe_param_name = ''.join(c for c in safe_param_name if c not in '<>"/\\|?*')
        
        # In TMDL, a parameter is defined as an expression
        content = f"expression {name} = \"{default_value.replace(os.sep, '/')}\" meta [IsParameterQuery=true, Type=\"Text\", IsParameterQueryRequired=true]\n"
        content += f"\tlineageTag: {uuid.uuid4()}\n\n"
        content += f"\tannotation PBI_ResultType = Text\n\n"
        
        with open(tmdl_dir / f"{safe_param_name}.tmdl", 'w', encoding='utf-8') as f:
            f.write(content)

    def _add_relationships(self, relationships: List[Dict[str, str]]):
        """Creates relationship definitions in separate .tmdl files within relationships folder."""
        # Create relationships folder within definition
        relationships_dir = self.model_dir / "definition" / "relationships"
        if not relationships_dir.exists():
            os.makedirs(relationships_dir)
        
        for rel in relationships:
            # Generate UUID for relationship
            rel_id = str(uuid.uuid4())
            
            from_tbl = rel.get("fromTable")
            from_col = rel.get("fromColumn")
            to_tbl = rel.get("toTable")
            to_col = rel.get("toColumn")
            
            if from_tbl and from_col and to_tbl and to_col:
                # Robust Relationship Handling
                # ----------------------------
                # Power BI TMDL expects standard relationships to be defined as:
                #   fromColumn: The Foreign Key (Many Side)
                #   toColumn:   The Primary Key (One Side)
                #
                # The Prompt Instructions now explicitly ask for Many->One (Fact->Dim).
                # However, to be robust against "One->Many" (Dim->Fact) inputs:
                
                cardinality = rel.get("cardinality", "ManyToOne") # Default assumption
                
                # If user provided OneToMany (Dim -> Fact)
                if cardinality.lower() == "onetomany":
                    # Swap to make it Many->One for TMDL
                    final_from_tbl = to_tbl
                    final_from_col = to_col
                    final_to_tbl = from_tbl
                    final_to_col = from_col
                else:
                    # Standard ManyToOne (Fact -> Dim) or unspecified
                    final_from_tbl = from_tbl
                    final_from_col = from_col
                    final_to_tbl = to_tbl
                    final_to_col = to_col
                
                # Create relationship content in TMDL format with proper configuration
                # NOTE: Set relyOnReferentialIntegrity to false to handle mismatched keys gracefully
                # This prevents "The key didn't match any rows in the table" errors
                content = f"relationship {rel_id}\n"
                content += f"\tfromColumn: '{final_from_tbl}'.'{final_from_col}'\n"
                content += f"\ttoColumn: '{final_to_tbl}'.'{final_to_col}'\n"
                content += f"\tcrossFilteringBehavior: bothDirections\n"
                content += f"\trelyOnReferentialIntegrity: false\n\n"
                
                # Write to separate .tmdl file in relationships folder
                # Sanitize table and column names for filename
                safe_from_tbl = final_from_tbl.replace('::', '_').replace(':', '_')
                safe_from_tbl = ''.join(c for c in safe_from_tbl if c not in '<>"/\\|?*')
                safe_from_col = final_from_col.replace('::', '_').replace(':', '_')
                safe_from_col = ''.join(c for c in safe_from_col if c not in '<>"/\\|?*')
                safe_to_tbl = final_to_tbl.replace('::', '_').replace(':', '_')
                safe_to_tbl = ''.join(c for c in safe_to_tbl if c not in '<>"/\\|?*')
                safe_to_col = final_to_col.replace('::', '_').replace(':', '_')
                safe_to_col = ''.join(c for c in safe_to_col if c not in '<>"/\\|?*')
                
                rel_base = f"{safe_from_tbl}_{safe_from_col}_to_{safe_to_tbl}_{safe_to_col}"
                # Keep relationship filenames short: the project name appears twice in the
                # path already, so relationship filenames must stay under ~40 chars to stay
                # within the Windows 260-char MAX_PATH limit when extracted anywhere.
                if len(rel_base) > 40:
                    import hashlib
                    rel_base = hashlib.md5(rel_base.encode()).hexdigest()[:16]
                rel_file_name = f"rel_{rel_base}.tmdl"

                with open(relationships_dir / rel_file_name, 'w', encoding='utf-8') as f:
                    f.write(content)

    def _init_report(self):
        # Create .platform file
        with open(self.report_dir / ".platform", 'w') as f:
            json.dump({
                "$schema": "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json",
                "metadata": {
                    "type": "Report",
                    "displayName": self.project_name
                },
                "config": {
                    "version": "2.0",
                    "logicalId": str(uuid.uuid4())
                }
            }, f, indent=4)

        # Create version.json inside definition folder
        definition_dir = self.report_dir / "definition"
        if not definition_dir.exists():
             os.makedirs(definition_dir)
             
        # PBIR Version Metadata Schema
        with open(definition_dir / "version.json", 'w') as f:
             json.dump({
                 "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/versionMetadata/1.0.0/schema.json",
                 "version": "2.0.0"
             }, f, indent=4)

        # Create report.json
        self.default_page_id = "ReportSection" + uuid.uuid4().hex[:12]
        
        with open(definition_dir / "report.json", 'w') as f:
             json.dump({
                  "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/report/2.1.0/schema.json",
                  "themeCollection": {
                    "baseTheme": {
                      "name": "CY24SU10",
                      "reportVersionAtImport": "5.65",
                      "type": "SharedResources"
                    }
                  }
             }, f, indent=4)
        
        # Initialize Pages Directory and pages.json
        pages_dir = definition_dir / "pages"
        if not pages_dir.exists():
            os.makedirs(pages_dir)
            
        with open(pages_dir / "pages.json", 'w') as f:
            json.dump({
                "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.0.0/schema.json",
                "pageOrder": [ self.default_page_id ],
                "activePageName": self.default_page_id
            }, f, indent=4)

        # Create definition.pbir
        pbir_content = {
            "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/1.0.0/schema.json",
            "version": "4.0",
            "datasetReference": {
                "byPath": { "path": "../" + self.model_dir.name }
            }
        }
        
        with open(self.report_dir / "definition.pbir", 'w') as f:
            json.dump(pbir_content, f, indent=4)

    def _create_page(self, display_name: str) -> str:
        page_id = "ReportSection" + uuid.uuid4().hex[:12]
        
        # Initialize visual tracking for this page
        self.page_visuals[page_id] = []
        
        # Update pages.json
        pages_json_path = self.report_dir / "definition" / "pages" / "pages.json"
        
        with open(pages_json_path, 'r') as f:
            pages_meta = json.load(f)
        
        # Check if this is the first page being created (default page exists)
        if len(pages_meta["pageOrder"]) == 1 and pages_meta["pageOrder"][0] == self.default_page_id:
            # Remove the default page and use a new ID for this first page
            pages_meta["pageOrder"] = [page_id]
            pages_meta["activePageName"] = page_id
            self.first_page_id = page_id  # Record banner page ID
            
            # Remove default page directory if it exists
            default_page_dir = self.report_dir / "definition" / "pages" / self.default_page_id
            if default_page_dir.exists():
                shutil.rmtree(default_page_dir)
        else:
            # Add subsequent pages
            pages_meta["pageOrder"].append(page_id)
        
        # Always write the updated pages.json
        with open(pages_json_path, 'w') as f:
            json.dump(pages_meta, f, indent=4)
        
        # Create the page directory and visuals folder
        page_dir = self.report_dir / "definition" / "pages" / page_id
        if not page_dir.exists():
            os.makedirs(page_dir / "visuals")
        
        # Create the page.json file
        with open(page_dir / "page.json", 'w') as f:
             json.dump({
                  "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.0.0/schema.json",
                  "name": page_id,
                  "displayName": display_name,
                  "displayOption": "FitToPage",
                  "height": 720,
                  "width": 1280
             }, f, indent=4)
             
        return page_id

    def _add_table(self, table_name: str, columns: Dict[str, str], measures: Dict[str, str], calculated_columns: Optional[Dict[str, str]] = None, source_file: Optional[str] = None, source_info: Optional[Dict[str, str]] = None):
        tmdl_dir = self.model_dir / "definition" / "tables"
        if not tmdl_dir.exists():
            os.makedirs(tmdl_dir)
        
        # Sanitize table_name for use as a filename (remove invalid Windows path characters)
        # Replace :: with _ and remove other invalid characters: < > : " / \ | ? *
        safe_filename = table_name.replace('::', '_').replace(':', '_')
        safe_filename = ''.join(c for c in safe_filename if c not in '<>"/\\|?*')
        
        content = f"table '{table_name}'\n\tlineageTag: {uuid.uuid4()}\n\n"
        
        m_types = []
        for name, dtype in columns.items():
            tmdl_type = "string" # default
            m_type_target = "type text"
            
            d_lower = dtype.lower()
            name_lower = name.lower()
            
            # Special handling for known text columns that should never be converted
            if any(kw in name_lower for kw in ["rating", "duration", "type", "status", "code", "label"]):
                # Keep these as string regardless of inferred datatype
                tmdl_type = "string"
                m_type_target = "type any"
            # For ID columns, always use string to avoid conversion errors with mixed data
            elif "_id" in name_lower or "show_id" in name_lower:
                tmdl_type = "string"
                m_type_target = "type any"
            elif "int" in d_lower: 
                tmdl_type = "int64"
                m_type_target = "Int64.Type"
            elif "double" in d_lower or "decimal" in d_lower or "float" in d_lower: 
                tmdl_type = "double"
                m_type_target = "type number"
            elif "date" in d_lower or "time" in d_lower: 
                tmdl_type = "dateTime"
                m_type_target = "type datetime"
            elif "bool" in d_lower: 
                tmdl_type = "boolean"
                m_type_target = "type logical"
            
            # Numeric columns need summarizeBy: sum so charts can auto-aggregate plain
            # column bindings on Y-axis. ID/key columns and relationship keys stay as 'none'.
            is_numeric = tmdl_type in ("int64", "double")
            is_id_or_key = (
                "_id" in name_lower
                or "show_id" in name_lower
                or name_lower.endswith(" id")
                or name_lower == "id"
                or (table_name, name) in self.relationship_keys
            )
            summarize_by = "sum" if (is_numeric and not is_id_or_key) else "none"

            content += f"\tcolumn '{name}'\n\t\tdataType: {tmdl_type}\n\t\tsourceColumn: {name}\n\t\tsummarizeBy: {summarize_by}\n\t\tlineageTag: {uuid.uuid4()}\n\n"
            content += f"\t\tannotation SummarizationSetBy = Automatic\n\n"
            
            # Escape column names for M code
            escaped_name = _escape_m_string(name)
            # For ID columns and text-based columns, use type any for flexibility
            if (any(kw in name_lower for kw in ["rating", "duration", "type", "status", "code", "label"]) or 
                "_id" in name_lower or "show_id" in name_lower):
                m_types.append(f'{{"{escaped_name}", type any}}')
            else:
                m_types.append(f'{{"{escaped_name}", {m_type_target}}}')
        
        # Emit calculated columns (DAX-defined columns)
        if calculated_columns:
            for cc_name, cc_expr in calculated_columns.items():
                content += f"\tcolumn '{cc_name}' = {cc_expr}\n\t\tdataType: int64\n\t\tlineageTag: {uuid.uuid4()}\n\t\tsummarizeBy: none\n\n\t\tannotation SummarizationSetBy = Automatic\n\n"

        for name, expr in measures.items():
            final_name = name

            # ✅ GLOBAL measure name uniqueness (Power BI requirement)
            if final_name.lower() in self.global_measure_names:
                counter = 2
                while f"{name} {counter}".lower() in self.global_measure_names:
                    counter += 1
                final_name = f"{name} {counter}"
                logger.warning(
                    f"Renamed duplicate global measure '{name}' → '{final_name}'"
                )

            self.global_measure_names.add(final_name.lower())

            content += (
                f"\tmeasure '{final_name}' = {expr}\n"
                f"\t\tlineageTag: {uuid.uuid4()}\n\n"
            )
                
        m_type_str = ", ".join(m_types)
        
        # Identify numeric columns that need data cleaning (currency symbols, commas, etc.)
        # Exclude ID columns which might contain mixed text/numeric data
        # Also exclude duration, rating, and other text-based columns that may contain non-numeric characters
        numeric_columns = []
        skip_keywords = ["duration", "rating", "name", "title", "description", "category", "type", "status", "code", "text", "label"]
        for name, dtype in columns.items():
            name_lower = name.lower()
            d_lower = dtype.lower()
            # Skip if column contains these keywords in its name
            if any(kw in name_lower for kw in skip_keywords):
                continue
            # Skip ID columns to avoid conversion errors
            if "_id" in name_lower or "show_id" in name_lower:
                continue
            # Only include if type indicates numeric
            if any(t in d_lower for t in ["int", "double", "decimal", "float", "currency", "money"]):
                numeric_columns.append(name)
        
        if source_file:
            # Generate M code using the DataFolder parameter
            filename = Path(source_file).name
            
            # Escape filename for safe use in M code
            escaped_filename = _escape_m_string(filename)
            
            # Robust Path Logic to handle user input errors (quotes, trailing slashes)
            # Using Character.FromNumber to avoid any escaping issues: 34="quote", 47=/", 92=backslash
            path_logic_lines = [
                "    // Clean up DataFolder parameter input",
                "    RawPath = DataFolder,",
                "    Trimmed = Text.Trim(RawPath),",
                "    // Remove surrounding quotes if user pasted them",
                "    Unquoted = if Text.StartsWith(Trimmed, \"'\") and Text.EndsWith(Trimmed, \"'\") then Text.Range(Trimmed, 1, Text.Length(Trimmed)-2) else if Text.StartsWith(Trimmed, Character.FromNumber(34)) and Text.EndsWith(Trimmed, Character.FromNumber(34)) then Text.Range(Trimmed, 1, Text.Length(Trimmed)-2) else Trimmed,",
                "    // Remove trailing slash to avoid double slashes (47 = /, 92 = backslash)",
                "    CleanPath = if Text.EndsWith(Unquoted, Character.FromNumber(47)) or Text.EndsWith(Unquoted, Character.FromNumber(92)) then Text.Range(Unquoted, 0, Text.Length(Unquoted)-1) else Unquoted,",
                f"    FilePath = CleanPath & Character.FromNumber(47) & \"{escaped_filename}\","
            ]
            path_logic = "\n".join(path_logic_lines)
            
            # Generate data cleaning step for numeric columns (remove $, commas, etc.)
            clean_numeric_step = ""
            if numeric_columns:
                clean_transformations = []
                for col_name in numeric_columns:
                    escaped_col = _escape_m_string(col_name)
                    # M function to clean currency/numeric text: remove $, €, £, ¥, ₹, commas, spaces, handle parentheses for negatives
                    # Use try...otherwise to gracefully handle non-numeric values (keeps them as-is instead of error)
                    clean_transformations.append(
                        f'{{"{escaped_col}", each try (if _ is text then '
                        f'let cleaned = Text.Trim(Text.Replace(Text.Replace(Text.Replace(Text.Replace(Text.Replace(Text.Replace(Text.Replace(Text.Replace(_, "$", ""), "€", ""), "£", ""), "¥", ""), "₹", ""), ",", ""), " ", ""), "%", "")), '
                        f'isNegative = Text.StartsWith(cleaned, "(") and Text.EndsWith(cleaned, ")"), '
                        f'stripped = if isNegative then Text.Range(cleaned, 1, Text.Length(cleaned)-2) else cleaned '
                        f'in if isNegative then -Number.From(stripped) else Number.From(stripped) else _) otherwise _, type number}}'
                    )
                clean_numeric_step = f'\n    #"Cleaned Numeric Data" = Table.TransformColumns(#"Promoted Headers", {{{", ".join(clean_transformations)}}}),\n'

            if source_file.lower().endswith(".csv"):
                 # Check if this table has key columns used in relationships
                 key_columns = [col for col, dtype in columns.items() 
                               if (table_name, col) in self.relationship_keys]
                 
                 if key_columns:
                     # Add filtering step to remove rows with blank key columns
                     # Use proper M identifier syntax for column names with spaces/special chars
                     filter_conditions = [f'{_escape_m_identifier(col)} <> null and {_escape_m_identifier(col)} <> ""' for col in key_columns]
                     filter_expr = ' and '.join(filter_conditions)
                     
                     # Decide which step to apply type conversion to
                     prev_step = '#"Cleaned Numeric Data"' if numeric_columns else '#"Promoted Headers"'
                     
                     source_expression = f"""let
{path_logic}
    Source = Csv.Document(File.Contents(FilePath),[Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.None]),
    #"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),{clean_numeric_step}
    #"Changed Type" = List.Accumulate({{{m_type_str}}}, {prev_step}, (state, current) => try Table.TransformColumnTypes(state, {{current}}) otherwise state),
    #"Filtered Key Columns" = Table.SelectRows(#"Changed Type", each {filter_expr})
in
    #"Filtered Key Columns" """
                 else:
                     prev_step = '#"Cleaned Numeric Data"' if numeric_columns else '#"Promoted Headers"'
                     
                     source_expression = f"""let
{path_logic}
    Source = Csv.Document(File.Contents(FilePath),[Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.None]),
    #"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),{clean_numeric_step}
    #"Changed Type" = List.Accumulate({{{m_type_str}}}, {prev_step}, (state, current) => try Table.TransformColumnTypes(state, {{current}}) otherwise state)
in
    #"Changed Type" """
            else:
                 # Excel source - properly escape table name for M code
                 escaped_table_name = _escape_m_string(table_name)
                 
                 # Determine sheet name: prefer explicit sheet_name from source_info,
                 # fall back to table_name, but always use try/otherwise to handle mismatches.
                 sheet_name_hint = table_name
                 if source_info and isinstance(source_info, dict):
                     sheet_name_hint = source_info.get("sheet_name") or source_info.get("sheet") or table_name
                 escaped_sheet_name = _escape_m_string(sheet_name_hint)
                 
                 prev_step_excel = '#"Cleaned Numeric Data"' if numeric_columns else '#"Promoted Headers"'
                 
                 # Use try/otherwise to fall back to the first sheet when the
                 # named sheet doesn't exist (prevents "The key didn't match
                 # any rows in the table" error).
                 source_expression = f"""let
{path_logic}
    Source = Excel.Workbook(File.Contents(FilePath), null, true),
    Sheet_Data = try Source{{[Item="{escaped_sheet_name}",Kind="Sheet"]}}[Data] otherwise try Source{{[Item="{escaped_table_name}",Kind="Sheet"]}}[Data] otherwise Source{{0}}[Data],
    #"Promoted Headers" = Table.PromoteHeaders(Sheet_Data, [PromoteAllScalars=true]),{clean_numeric_step}
    #"Changed Type" = List.Accumulate({{{m_type_str}}}, {prev_step_excel}, (state, current) => try Table.TransformColumnTypes(state, {{current}}) otherwise state)
in
    #"Changed Type" """
        else:
            # Dummy Data
            m_columns = []
            sample_rows = [[], [], [], [], []] 
            
            for name, dtype in columns.items():
                val_generator = lambda i: f'"{name} {i}"' 
                d_lower = dtype.lower()
                
                if "int" in d_lower: 
                    val_generator = lambda i: str(100 + i*10 + random.randint(0, 5))
                elif "double" in d_lower: 
                    val_generator = lambda i: str(round(10.5 + i*2.5 + random.random(), 2))
                elif "date" in d_lower: 
                    val_generator = lambda i: f'#datetime({2024}, {1}, {1+i}, 12, 0, 0)'
                elif "bool" in d_lower: 
                    val_generator = lambda i: "true" if i%2==0 else "false"
                
                # Escape column name for M code
                escaped_name = _escape_m_string(name)
                m_columns.append(f'"{escaped_name}"')
                for i in range(5):
                    sample_rows[i].append(val_generator(i))
                    
            rows_str = ",\\n\\t\\t".join(["{" + ", ".join(row) + "}" for row in sample_rows])
            m_col_str = ", ".join(m_columns)
            
            source_expression = f"""let
    Source = Table.FromRows(
        {{
            {rows_str}
        }}, 
        {{{m_col_str}}}
    ),
    #"Changed Type" = List.Accumulate({{{m_type_str}}}, Source, (state, current) => try Table.TransformColumnTypes(state, {{current}}) otherwise state)
in
    #"Changed Type" """

        content += f"\tpartition '{table_name}' = m\n"
        content += f"\t\tmode: import\n"
        
        # Format the M code with proper indentation
        # Each line should be indented with tabs for TMDL compliance
        indentation = "\t\t\t"
        formatted_lines = []
        for line in source_expression.split("\n"):
            # Don't add extra indentation to blank lines
            if line.strip():
                formatted_lines.append(indentation + line)
            else:
                formatted_lines.append("")
        formatted_m = "\n".join(formatted_lines)
        
        content += f"\t\tsource = \n{formatted_m}\n\n"
        content += f"\tannotation PBI_ResultType = Table\n"

        # Use sanitized filename for the file path
        with open(tmdl_dir / f"{safe_filename}.tmdl", 'w', encoding='utf-8') as f:
            f.write(content)

    def _compute_visual_data_signature(self, visual_type: str, data_mapping: Dict[str, Any]) -> str:
        """
        Compute a canonical signature for a visual's data bindings.
        Used to detect cross-page duplicate visuals that show identical data.
        
        Returns empty string if signature cannot be computed (skips dedup).
        """
        if not data_mapping or not visual_type:
            return ""
        
        mapped_type = self._map_visual_type(visual_type)
        parts = [mapped_type]
        
        # Sort roles for deterministic comparison
        for role in sorted(data_mapping.keys()):
            field_def = data_mapping[role]
            if isinstance(field_def, dict):
                table = field_def.get("table", "")
                col = field_def.get("column", "") or field_def.get("measure", "")
                parts.append(f"{role}={table}.{col}")
            elif isinstance(field_def, list):
                # Table visual with multiple fields
                field_parts = []
                for fd in field_def:
                    if isinstance(fd, dict):
                        table = fd.get("table", "")
                        col = fd.get("column", "") or fd.get("measure", "")
                        field_parts.append(f"{table}.{col}")
                parts.append(f"{role}=[{','.join(sorted(field_parts))}]")
        
        return "|".join(parts)

    def _resolve_table_name(self, name: str) -> str:
        """Resolve a table name from the LLM JSON to a known semantic-model table.

        The LLM sometimes emits table references that differ in casing or
        underscore/space usage from the actual TMDL table name (e.g.
        ``"HR Data"`` vs ``"HR_Data"``).  This causes Power BI to show
        *"The key didn't match any rows in the table"* because the
        ``SourceRef.Entity`` value must match the TMDL table name exactly.

        Resolution order:
          1. Exact match ⇒ return as-is.
          2. Case-insensitive match.
          3. Normalized match (strip spaces/underscores, lower-case compare).
          4. No match ⇒ return the original name (will work if there is only
             one table and the model can still resolve it).
        """
        if not hasattr(self, "table_names") or not self.table_names:
            return name
        # 1. Exact
        if name in self.table_names:
            return name
        # 2. Case-insensitive
        for t in self.table_names:
            if t.lower() == name.lower():
                logger.info(f"Resolved table name '{name}' → '{t}' (case)")
                return t
        # 3. Normalized (ignore spaces, underscores, hyphens)
        def _norm(s: str) -> str:
            return s.lower().replace(" ", "").replace("_", "").replace("-", "")
        name_norm = _norm(name)
        for t in self.table_names:
            if _norm(t) == name_norm:
                logger.info(f"Resolved table name '{name}' → '{t}' (normalized)")
                return t
        # 4. No match
        logger.warning(f"Table name '{name}' could not be matched to any semantic-model table: {self.table_names}")
        return name

    def _add_visual(self, page_id: str, visual_type: str, title: str, data_mapping: Dict[str, str]):
        page_dir = self.report_dir / "definition" / "pages" / page_id
        visuals_dir = page_dir / "visuals"
        if not visuals_dir.exists():
            os.makedirs(visuals_dir)
            
        visual_name = uuid.uuid4().hex
        
        # Create a folder for the visual
        visual_folder = visuals_dir / visual_name
        if not visual_folder.exists():
            os.makedirs(visual_folder)
        
        # --- Grid-based positioning to avoid overlap ---
        # Page is 1280x720; use a 2-column grid with padding
        existing_visuals = self.page_visuals.get(page_id, [])
        existing_count = len(existing_visuals)
        COLS = 2
        PADDING = 20
        PAGE_WIDTH = 1280
        PAGE_HEIGHT = 720
        VISUAL_WIDTH = 600
        VISUAL_HEIGHT = 350
        col = existing_count % COLS
        row = existing_count // COLS
        
        pos_x = PADDING + col * (VISUAL_WIDTH + PADDING)
        pos_y = PADDING + row * (VISUAL_HEIGHT + PADDING)
        
        mapped_type = self._map_visual_type(visual_type)
        banner_page_id = self.first_page_id or (next(iter(self.page_visuals), None))
        page_layout = self.page_layouts.get(page_id, {})
        existing_card_count = sum(1 for item in existing_visuals if item.get("mapped_type") == "card")
        
        # Cards: auto-size from the actual generated page content rather than hardcoded buckets.
        if mapped_type == "card":
            page_card_count = max(1, int(page_layout.get("card_count", existing_card_count + 1)))
            page_visual_count = max(1, int(page_layout.get("visual_count", existing_count + 1)))
            cards_only_page = page_card_count == page_visual_count

            if cards_only_page:
                card_cols = min(COLS, max(1, math.ceil(math.sqrt(page_card_count))))
                card_rows = max(1, math.ceil(page_card_count / card_cols))
                available_width = PAGE_WIDTH - (PADDING * (card_cols + 1))
                available_height = PAGE_HEIGHT - (PADDING * (card_rows + 1))
                CARD_WIDTH = available_width // card_cols
                CARD_HEIGHT = available_height // card_rows
                if page_id == banner_page_id:
                    CARD_HEIGHT = min(CARD_HEIGHT, 280)
            else:
                card_cols = COLS
                card_rows = max(1, math.ceil(page_card_count / card_cols))
                top_band_height = max(180, min(240, (PAGE_HEIGHT - (PADDING * 3)) // max(2, page_visual_count)))
                available_width = PAGE_WIDTH - (PADDING * (card_cols + 1))
                available_height = top_band_height - (PADDING * max(0, card_rows - 1))
                CARD_WIDTH = available_width // card_cols
                CARD_HEIGHT = max(150, available_height // card_rows)

            card_col = existing_card_count % card_cols
            card_row = existing_card_count // card_cols
            pos_x = PADDING + card_col * (CARD_WIDTH + PADDING)
            pos_y = PADDING + card_row * (CARD_HEIGHT + PADDING)
            VISUAL_WIDTH = CARD_WIDTH
            VISUAL_HEIGHT = CARD_HEIGHT
        
        # --- Normalize role names to what Power BI PBIR actually expects ---
        # PBIR uses specific well-known role names per visual type.
        # Common chart types use "Category" (capital C) and "Y" (not "values").
        ROLE_NORMALIZATION = {
            # Standard charts: Category + Y
            "clusteredColumnChart": {"category": "Category", "values": "Y", "y": "Y", "series": "Series"},
            "clusteredBarChart": {"category": "Category", "values": "Y", "y": "Y", "series": "Series"},
            "barChart": {"category": "Category", "values": "Y", "y": "Y", "series": "Series"},
            "columnChart": {"category": "Category", "values": "Y", "y": "Y", "series": "Series"},
            "hundredPercentStackedBarChart": {"category": "Category", "values": "Y", "y": "Y", "series": "Series"},
            "hundredPercentStackedColumnChart": {"category": "Category", "values": "Y", "y": "Y", "series": "Series"},
            "lineChart": {"category": "Category", "values": "Y", "y": "Y", "series": "Series"},
            "areaChart": {"category": "Category", "values": "Y", "y": "Y", "series": "Series"},
            "pieChart": {"category": "Category", "group": "Category", "values": "Y", "y": "Y"},
            "donutChart": {"category": "Category", "group": "Category", "values": "Y", "y": "Y"},
            "waterfallChart": {"category": "Category", "values": "Y", "y": "Y"},
            "comboChart": {"category": "Category", "values": "Y", "y": "Y", "series": "Series"},
            # Card visual: PBIR expects 'Fields'
            "card": {"data": "Fields", "value": "Fields", "values": "Fields", "fields": "Fields", "y": "Fields"},
            # Scatter chart: needs X, Y, Size
            "scatterChart": {"category": "X", "x": "X", "y": "Y", "values": "Y", "size": "Size"},
            # Treemap: Group and Values
            "treemap": {"category": "Group", "group": "Group", "values": "Values", "y": "Values"},
            # Gauge: Y for value
            "gauge": {"data": "Y", "value": "Y", "y": "Y", "fields": "Y", "values": "Y"},
            # Map visual: Category for location, Size for bubble
            "map": {"category": "Category", "size": "Size", "y": "Size"},
            # Box and Whisker: Category for grouping, Values for value (CUSTOM VISUAL - Box and Whisker with Points (Pro))
            "boxandwhiskerwithpoints6C29D629F202A5FF5B6B023486584FCA": {"category": "Category", "values": "Values", "y": "Values"},
            # Table: Values array
            "tableEx": {"rows": "Values", "values": "Values", "category": "Values", "y": "Values"},
        }
        
        role_map = ROLE_NORMALIZATION.get(mapped_type, {})
        
        # Aggregation function name → PBIR Function number
        AGG_FUNCTION_MAP = {
            "sum": 0, "avg": 1, "average": 1, "count": 5, "countnonull": 5,
            "min": 3, "max": 4, "countd": 5, "distinctcount": 5, "median": 6,
        }

        query_state = {}
        
        for role, field_def_or_list in data_mapping.items():
            # Normalize the role name for specific visual types
            normalized_role = role_map.get(role.lower(), role)
            
            # Normalize to list to handle both single items and lists (for Tables)
            items_to_process = field_def_or_list if isinstance(field_def_or_list, list) else [field_def_or_list]
            projections = []

            for field_def in items_to_process:
                table_name = None
                field_name = None
                target_type = "Column"
                aggregation = None
                
                if isinstance(field_def, dict):
                    table_name = field_def.get("table")
                    field_name = field_def.get("column")
                    aggregation = field_def.get("aggregation")
                    if field_name:
                        target_type = "Column"
                    else:
                        field_name = field_def.get("measure")
                        target_type = "Measure"

                elif isinstance(field_def, str):
                    parts = field_def.strip(']').split('[')
                    if len(parts) == 2:
                        table_name = parts[0]
                        field_name = parts[1]

                # Resolve table name to match semantic-model TMDL exactly
                # (prevents "The key didn't match any rows in the table")
                if table_name:
                    table_name = self._resolve_table_name(table_name)
                
                if table_name and field_name:
                    # Build the field expression
                    if target_type == "Measure":
                        # Measures: direct Measure reference (no aggregation wrapper)
                        field_expr = {
                            "Measure": {
                                "Expression": {
                                    "SourceRef": {"Entity": table_name}
                                },
                                "Property": field_name
                            }
                        }
                        query_ref = f"{table_name}.{field_name}"
                        native_ref = field_name
                    elif aggregation and aggregation.lower() in AGG_FUNCTION_MAP:
                        # Columns with explicit aggregation: wrap in Aggregation expression
                        agg_fn = AGG_FUNCTION_MAP[aggregation.lower()]
                        agg_name = aggregation.capitalize()
                        field_expr = {
                            "Aggregation": {
                                "Expression": {
                                    "Column": {
                                        "Expression": {
                                            "SourceRef": {"Entity": table_name}
                                        },
                                        "Property": field_name
                                    }
                                },
                                "Function": agg_fn
                            }
                        }
                        query_ref = f"{agg_name}({table_name}.{field_name})"
                        native_ref = f"{agg_name} of {field_name}"
                    else:
                        # Plain column reference (no aggregation, used for categories/dimensions)
                        field_expr = {
                            "Column": {
                                "Expression": {
                                    "SourceRef": {"Entity": table_name}
                                },
                                "Property": field_name
                            }
                        }
                        query_ref = f"{table_name}.{field_name}"
                        native_ref = field_name

                    projections.append({
                        "field": field_expr,
                        "queryRef": query_ref,
                        "nativeQueryRef": native_ref
                    })
            
            if projections:
                query_state[normalized_role] = { "projections": projections }

        visual_config = {
            "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.1.0/schema.json",
            "name": visual_name,
            "position": {
                "x": pos_x,
                "y": pos_y,
                "z": 1000 + existing_count,
                "width": VISUAL_WIDTH,
                "height": VISUAL_HEIGHT,
                "tabOrder": 1000 + existing_count
            },
            "visual": {
                "visualType": mapped_type,
                "query": {
                    "queryState": query_state
                },
                "drillFilterOtherVisuals": True
            }
        }

        # Defensive schema guard: PBIR visualContainer schema rejects additional properties like `visual.vcObjects`.
        # If any upstream logic ever injects it, strip it before writing the file.
        if isinstance(visual_config.get("visual"), dict):
            visual_config["visual"].pop("vcObjects", None)

        # Add branded background color to all KPI cards across all pages.
        # Uses visualContainerObjects.background — a schema-valid container-level property
        # that controls only visual appearance, not data rendering.  Wrong format → transparent
        # background (same as today); it cannot blank out the card values.
        if mapped_type == "card":
            # Single consistent blue-grey pastel family, lightest → slightly deeper
            _card_colors = ["#DDE8F5", "#C8D9EF", "#B3CBE9", "#9FBCE3"]
            bg_color = _card_colors[existing_count % len(_card_colors)]
            text_black_expr = {
                "solid": {
                    "color": {
                        "expr": {
                            "Literal": {
                                "Value": "'#000000'"
                            }
                        }
                    }
                }
            }
            visual_config["visual"]["visualContainerObjects"] = {
                "background": [
                    {
                        "properties": {
                            "show": {
                                "expr": {
                                    "Literal": {
                                        "Value": "true"
                                    }
                                }
                            },
                            "color": {
                                "solid": {
                                    "color": {
                                        "expr": {
                                            "Literal": {
                                                "Value": f"'{bg_color}'"
                                            }
                                        }
                                    }
                                }
                            },
                            "transparency": {
                                "expr": {
                                    "Literal": {
                                        "Value": "0D"
                                    }
                                }
                            }
                        }
                    }
                ],
                "border": [
                    {
                        "properties": {
                            "show": {
                                "expr": {
                                    "Literal": {
                                        "Value": "true"
                                    }
                                }
                            },
                            "color": {
                                "solid": {
                                    "color": {
                                        "expr": {
                                            "Literal": {
                                                "Value": "'#7FA8D4'"
                                            }
                                        }
                                    }
                                }
                            },
                            "width": {
                                "expr": {
                                    "Literal": {
                                        "Value": "1D"
                                    }
                                }
                            },
                            "radius": {
                                "expr": {
                                    "Literal": {
                                        "Value": "8D"
                                    }
                                }
                            }
                        }
                    }
                ]
            }
            # Keep KPI value and subtitle readable on light backgrounds.
            visual_config["visual"]["objects"] = {
                "labels": [
                    {
                        "properties": {
                            "color": text_black_expr
                        }
                    }
                ],
                "categoryLabels": [
                    {
                        "properties": {
                            "color": text_black_expr
                        }
                    }
                ],
                "calloutValue": [
                    {
                        "properties": {
                            "color": text_black_expr
                        }
                    }
                ]
            }

        # Write to visual.json inside the visual folder
        with open(visual_folder / "visual.json", 'w') as f:
            json.dump(visual_config, f, indent=4)
        
        # Track this visual for the page (for internal tracking)
        if page_id not in self.page_visuals:
            self.page_visuals[page_id] = []
        self.page_visuals[page_id].append({"id": visual_name, "mapped_type": mapped_type})
        
        # Visuals are auto-discovered by Power BI from the visual.json files in the visuals folder

    def _map_visual_type(self, v_type: str) -> str:
        """Maps Tableau visual names to Power BI visual IDs."""
        if not v_type:
            return "card"
        
        v_lower = v_type.lower().strip()
        
        # Exact matches first (most specific)
        # PBIR visual type IDs:
        #   barChart = Stacked Bar (default bar in Power BI)
        #   clusteredBarChart = Clustered Bar
        #   columnChart = Stacked Column (default column in Power BI)
        #   clusteredColumnChart = Clustered Column
        exact_mappings = {
            "pie": "pieChart",
            "donut": "donutChart",
            "line": "lineChart",
            "linechart": "lineChart",
            "area": "areaChart",
            "bar": "clusteredBarChart",
            "column": "clusteredColumnChart",
            "scatter": "scatterChart",
            "bubble": "scatterChart",
            "table": "tableEx",
            "text_table": "tableEx",
            "text table": "tableEx",
            "crosstab": "tableEx",
            "matrix": "tableEx",
            "card": "card",
            "kpi": "card",
            "gauge": "gauge",
            "map": "map",
            "treemap": "treemap",
            "waterfall": "waterfallChart",
            "combo": "comboChart",
            "histogram": "clusteredColumnChart",
            "distribution": "clusteredColumnChart",
            "shape": "card",
            "polygon": "map",
            "gantt": "tableEx",
            "dual_axis": "comboChart",
            "stacked bar": "barChart",
            "stacked column": "columnChart",
            "stackedbar": "barChart",
            "stackedcolumn": "columnChart",
            "stackedbarchart": "barChart",
            "stackedcolumnchart": "columnChart",
            "barchart": "barChart",
            "columnchart": "columnChart",
            # Box and Whisker (Custom Visual - "Box and Whisker with Points")
            "boxandwhiskerchart": "boxandwhiskerwithpoints6C29D629F202A5FF5B6B023486584FCA",
            "boxplot": "boxandwhiskerwithpoints6C29D629F202A5FF5B6B023486584FCA",
            "box plot": "boxandwhiskerwithpoints6C29D629F202A5FF5B6B023486584FCA",
        }
        
        # Check exact matches
        if v_lower in exact_mappings:
            return exact_mappings[v_lower]
        
        # Tableau-specific visual type mappings (multi-word patterns first for priority)
        tableau_to_pbi = {
            # Multi-word patterns (must come before single-word to take precedence)
            "text_table": "tableEx",
            "text table": "tableEx",
            "donut chart": "donutChart",
            "pie chart": "pieChart",
            "line chart": "lineChart",
            "area chart": "areaChart",
            "bar chart": "clusteredBarChart",
            "column chart": "clusteredColumnChart",
            "scatter plot": "scatterChart",
            "bubble chart": "scatterChart",
            "waterfall chart": "waterfallChart",
            "combo chart": "comboChart",
            "100% stacked bar": "hundredPercentStackedBarChart",
            "100% stacked column": "hundredPercentStackedColumnChart",
            "horizontal bar": "clusteredBarChart",
            "vertical bar": "clusteredColumnChart",
            "stacked bar": "barChart",
            "stacked column": "columnChart",
            "dot plot": "clusteredColumnChart",
            "dual axis": "comboChart",
            
            # Single-word patterns (order matters - more specific first)
            "crosstab": "tableEx",
            "matrix": "tableEx",
            "sheet": "tableEx",
            "text": "card",
            "shape": "card",
            "image": "card",
            "bullet": "gauge",  # Bullet chart maps to gauge
            "gantt": "tableEx",  # Power BI doesn't have Gantt natively
            "treemap": "treemap",
            "histogram": "clusteredColumnChart",
            "distribution": "clusteredColumnChart",
            # Box and Whisker (Custom Visual - requires "Box and Whisker with Points" from AppSource)
            "box and whisker": "boxandwhiskerwithpoints6C29D629F202A5FF5B6B023486584FCA",
            "box plot": "boxandwhiskerwithpoints6C29D629F202A5FF5B6B023486584FCA",
            "boxplot": "boxandwhiskerwithpoints6C29D629F202A5FF5B6B023486584FCA",
        }
        
        # Check substring matches
        for pattern, mapping in tableau_to_pbi.items():
            if pattern in v_lower:
                return mapping
        
        # Fallback to rough keyword matching
        # Check for stacked variants BEFORE generic bar/column to preserve stacked semantics
        if "stacked" in v_lower and any(x in v_lower for x in ["bar", "horizontal"]):
            if "100%" in v_lower or "percent" in v_lower:
                return "hundredPercentStackedBarChart"
            return "barChart"
        if "stacked" in v_lower and any(x in v_lower for x in ["column", "vertical"]):
            if "100%" in v_lower or "percent" in v_lower:
                return "hundredPercentStackedColumnChart"
            return "columnChart"
        if any(x in v_lower for x in ["column", "vertical"]):
            return "clusteredColumnChart"
        if any(x in v_lower for x in ["bar", "horizontal"]):
            return "clusteredBarChart"
        if "line" in v_lower:
            return "lineChart"
        if "area" in v_lower:
            return "areaChart"
        if "pie" in v_lower or "donut" in v_lower:
            return "pieChart"
        if any(x in v_lower for x in ["scatter", "bubble", "xy"]):
            return "scatterChart"
        if any(x in v_lower for x in ["table", "sheet", "crosstab"]):
            return "tableEx"
        if "map" in v_lower:
            return "map"
        if any(x in v_lower for x in ["box", "whisker"]):
            return "boxandwhiskerwithpoints6C29D629F202A5FF5B6B023486584FCA"
        if "gauge" in v_lower or "bullet" in v_lower:
            return "gauge"
        if "tree" in v_lower:
            return "treemap"
        if "waterfall" in v_lower:
            return "waterfallChart"
        if "histogram" in v_lower or "distribution" in v_lower:
            return "clusteredColumnChart"
        
        return "card"  # Safe default

