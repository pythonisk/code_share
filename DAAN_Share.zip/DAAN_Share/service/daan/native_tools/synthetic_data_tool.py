import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from daan.flow.context_vars import daan_session_id as _ctx_session_id

# Resolve the project root (3 levels up from .../service/daan/native_tools/)
# so SESSION_STORAGE_DIR relative paths work regardless of the server CWD.
_PROJECT_ROOT = Path(__file__).resolve().parents[3]

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SyntheticDataTool:
    """DAAN native tool that drives the full synthetic data generation pipeline.

    Registered in agent config as: ``SyntheticDataTool.execute_generation``

    Follows the same structural contract as JiraStoryPublisher:
     - instantiated by tools_loader (class name = module name)
     - single public method receives ``reviewed_output`` dict
     - returns a flat result dict with ``status``

    Input convention (session_storage/{session_id}/inputs/):
        - requirements.csv  — two columns: table_name, row_count
        - <TABLE_NAME>.csv   â€” one file per table (sample data for schema + ML training)

    Output convention (session_storage/{session_id}/sdg/output/):
        - <TABLE_NAME>.csv   â€” generated synthetic data

    Pipeline:
        1. Locate session inputs directory
        2. Read requirements.csv → selected_tables, row_counts
        3. Extract schema metadata from uploaded CSVs (no DB connection needed)
        4. Build generation plan (FK detection + execution order)
        5. Train ML patterns (pgmpy Bayesian Networks, with per-DB model cache)
        6. Generate per-table Python scripts
        7. Execute scripts sequentially (WorkflowOrchestrator)
        8. Return output file paths
    """

    def __init__(self, data_dir: Optional[str] = None, tool_name: str = "SyntheticDataTool"):
        self.tool_name = tool_name or "SyntheticDataTool"
        # data_dir is injected by tools_loader from agent_runner's tool_kwargs:
        # {project_root}/session_storage/{session_id}/inputs
        self._data_dir = data_dir
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def execute_generation(
        self,
        reviewed_output: Optional[Dict[str, Any]] = None,
        agent_id: str = "unknown",
        agent_name: str = "Unknown Agent",
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Run the full SDG pipeline.

        Args:
            reviewed_output: dict passed by DAAN action-agent executor
                (content is not parsed â€” all inputs come from session files).
            agent_id: Agent identifier for logging.
            agent_name: Agent display name for logging.
            session_id: DAAN session UUID used to locate input CSVs and
                place outputs in an isolated session directory.

        Returns:
            dict with keys: status, message, agent_id, agent_name,
            tables_generated, output_files, output_dir, execution_log,
            quality_scores, timestamp.
        """
        try:
            logger.info("%s: Starting synthetic data generation", self.tool_name)

            # -- 1. Resolve paths from injected data_dir -----------------
            # tools_loader injects data_dir={project_root}/session_storage/{session_id}/inputs
            # from agent_runner.tool_kwargs. Fall back to ContextVar, then timestamp.
            if self._data_dir:
                inputs_dir = self._data_dir
                session_base = str(Path(self._data_dir).parent / "sdg")
            else:
                resolved_session_id = _ctx_session_id.get() or session_id
                session_tag = resolved_session_id or datetime.now().strftime("%Y%m%d_%H%M%S")
                if not resolved_session_id:
                    logger.warning(
                        "%s: data_dir and session_id both unavailable — using timestamp fallback '%s'",
                        self.tool_name, session_tag,
                    )
                _storage_raw = os.getenv("SESSION_STORAGE_DIR", "session_storage")
                storage_root = (
                    _storage_raw
                    if os.path.isabs(_storage_raw)
                    else str(_PROJECT_ROOT / _storage_raw)
                )
                inputs_dir = os.path.join(storage_root, session_tag, "inputs")
                session_base = os.path.join(storage_root, session_tag, "sdg")
            output_dir = os.path.join(session_base, "output")
            sdv_dir   = os.path.join(output_dir, "SDV")
            scripts_dir = os.path.join(sdv_dir, "scripts")
            sdv_output_dir = os.path.join(sdv_dir, "output")
            os.makedirs(output_dir, exist_ok=True)
            os.makedirs(scripts_dir, exist_ok=True)
            os.makedirs(sdv_output_dir, exist_ok=True)

            # Shared model cache (persisted across sessions per pipeline run)
            model_cache_dir = os.path.join(
                os.path.dirname(__file__),
                "synthetic_data", "model_cache",
            )
            os.makedirs(model_cache_dir, exist_ok=True)

            # ── 2. Read requirements.csv for selected tables + row counts ──
            from daan.native_tools.synthetic_data.config.config import GenerationConfig

            try:
                gen_config = GenerationConfig.from_csv_inputs(inputs_dir)
            except FileNotFoundError as exc:
                return self._error(agent_id, agent_name, str(exc))
            except ValueError as exc:
                return self._error(agent_id, agent_name, str(exc))

            selected_tables: List[str] = gen_config.selected_tables
            row_counts: Dict[str, int] = gen_config.row_counts

            if not selected_tables:
                return self._error(agent_id, agent_name, "requirements.csv contains no table rows")

            # â”€â”€ 3. Extract schema metadata from uploaded CSVs â”€â”€â”€â”€â”€â”€â”€â”€â”€
            from daan.native_tools.synthetic_data.components.schema_metadata_extractor import (
                SchemaMetadataExtractor,
            )

            extractor = SchemaMetadataExtractor(inputs_dir)
            metadata = extractor.extract_all_metadata(selected_tables=selected_tables)
            if not metadata:
                missing_csvs = [
                    t for t in selected_tables
                    if not os.path.exists(os.path.join(inputs_dir, f"{t}.csv"))
                    and not os.path.exists(os.path.join(inputs_dir, f"{t.lower()}.csv"))
                ]
                detail = (
                    f"Missing table CSV(s): {missing_csvs}. "
                    "Call sdg_extract_schema_and_samples first to pull Snowflake data into the session inputs folder, "
                    "then call execute_generation."
                ) if missing_csvs else "No CSV files matched the selected tables in the inputs directory."
                return self._error(agent_id, agent_name, detail)

            # â”€â”€ 4. ML pattern learning â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
            from daan.native_tools.synthetic_data.components.ml_pattern_learner import (
                MLPatternLearner,
            )
            from daan.native_tools.synthetic_data.components.model_cache_manager import (
                ModelCacheManager,
            )

            ml_learner = MLPatternLearner(
                output_dir=output_dir,
                save_samples=False,
                use_cache=True,
                force_retrain=False,
            )
            ml_learner.cache_manager = ModelCacheManager(model_cache_dir)

            learned_patterns: Dict[str, Any] = {}
            if extractor.dataframes:
                learned_patterns = ml_learner.learn_patterns_from_dataframes(
                    extractor.dataframes,
                    database="sdg",
                )

            # â”€â”€ 5. Build generation plan â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
            from daan.native_tools.synthetic_data.components.generation_planner import (
                GenerationPlanner,
            )

            planner = GenerationPlanner(metadata)
            generation_plan = planner.create_generation_plan(selected_tables, row_counts)

            # â”€â”€ 6. Generate Python scripts â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
            from daan.native_tools.synthetic_data.components.python_script_generator import (
                PythonScriptGenerator,
            )

            script_gen = PythonScriptGenerator(
                generation_plan=generation_plan,
                output_dir=scripts_dir,
                output_format="csv",
                include_nulls=False,
            )
            script_gen.set_learned_patterns(learned_patterns)
            generated_scripts: Dict[str, str] = script_gen.generate_all_scripts()

            # ── 7. Execute workflow (scripts → RI enforcement) ─────────
            from daan.native_tools.synthetic_data.components.workflow_orchestrator import (
                WorkflowOrchestrator,
            )

            orchestrator = WorkflowOrchestrator(
                metadata=metadata,
                generation_plan=generation_plan,
                scripts_dir=scripts_dir,
                output_dir=output_dir,
                output_format="csv",
            )
            success = orchestrator.execute_workflow()

            # ── 8. Collect output files ───────────────────────────────────
            # CSVs land in sdg/output/SDV/output/, scripts in sdg/output/SDV/scripts/
            output_files: List[str] = []
            for search_dir in [output_dir, sdv_output_dir]:
                if os.path.exists(search_dir):
                    output_files.extend(
                        os.path.join(search_dir, f)
                        for f in os.listdir(search_dir)
                        if f.endswith(".csv")
                    )
            # Include generated scripts from scripts/ subfolder
            if os.path.exists(scripts_dir):
                output_files.extend(
                    os.path.join(scripts_dir, f)
                    for f in os.listdir(scripts_dir)
                    if f.endswith(".py")
                )

            tables_generated = len(output_files)
            quality_scores = {
                t: orchestrator.execution_results.get(t, {}).get("status", "UNKNOWN")
                for t in selected_tables
            }

            # ── 9. Copy deliverables into artifacts/ ──────────────────────
            self._publish_artifacts(output_files)

            status = "success" if success else "partial"
            message = (
                f"Generated {tables_generated} CSV file(s) for {len(selected_tables)} "
                f"table(s). Output: {output_dir}"
            )
            logger.info("%s: %s", self.tool_name, message)

            return {
                "status": status,
                "message": message,
                "agent_id": agent_id,
                "agent_name": agent_name,
                "tables_generated": tables_generated,
                "output_files": output_files,
                "output_dir": output_dir,
                "execution_log": orchestrator.execution_results,
                "quality_scores": quality_scores,
                "timestamp": datetime.now().isoformat(),
            }

        except Exception as exc:
            logger.error("%s: Fatal error: %s", self.tool_name, str(exc), exc_info=True)
            return self._error(agent_id, agent_name, f"Error: {exc}")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _publish_artifacts(self, output_files: List[str]) -> None:
        """Copy generated output files into the session's artifacts/ directory."""
        if not self._data_dir:
            return
        data_path = Path(self._data_dir)
        session_dir = data_path.parent if data_path.name == "inputs" else data_path
        artifacts_dir = session_dir / "artifacts"
        artifacts_dir.mkdir(parents=True, exist_ok=True)

        import shutil
        for src in output_files:
            src_path = Path(src)
            if src_path.is_file():
                shutil.copy2(src_path, artifacts_dir / src_path.name)
        logger.info(
            "%s: Published %d file(s) to artifacts/",
            self.tool_name, len(output_files),
        )

    def _error(self, agent_id: str, agent_name: str, message: str) -> Dict[str, Any]:
        logger.error("%s: %s", self.tool_name, message)
        return {
            "status": "error",
            "message": message,
            "agent_id": agent_id,
            "agent_name": agent_name,
            "tables_generated": 0,
            "output_files": [],
            "timestamp": datetime.now().isoformat(),
        }


__all__ = ["SyntheticDataTool"]
