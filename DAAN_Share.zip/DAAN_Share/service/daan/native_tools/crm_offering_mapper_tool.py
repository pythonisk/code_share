"""CRM Offering Mapper Tool - Simplified version."""

from __future__ import annotations

import csv
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from daan.llm.llm_provider import get_llm_response_with_fallback

logger = logging.getLogger(__name__)

DEFAULT_OFFERINGS_FILE = "data/CRM/Data and Analytics offering v1.1.xlsx"


class CrmOfferingMapperTool:
    """Stage-2 offering mapper: reads Excel, maps rows with LLM, exports artifacts."""

    def __init__(self, data_dir: Optional[str] = None):
        self._data_dir = data_dir
        self._workspace_root = Path(__file__).resolve().parents[3]

    def map_offerings_and_export(
        self,
        enriched_rows: Any,
        output_name_prefix: str = "crm_offering_mapping",
        llm_provider: Optional[str] = None,
        offerings_file_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Map enriched rows to offerings and export artifacts."""
        # Normalize inputs
        try:
            rows = self._parse_rows(enriched_rows)
        except Exception as exc:
            return {"status": "error", "errors": [f"Invalid enriched_rows: {exc}"]}

        # Read offerings from Excel
        try:
            offerings = self._read_offerings_excel(offerings_file_path or DEFAULT_OFFERINGS_FILE)
        except Exception as exc:
            return {"status": "error", "errors": [f"Failed to read offerings: {exc}"]}

        # Track original column order from first row
        original_columns = list(rows[0].keys()) if rows else []
        
        # Map each row
        recommended, no_reco = [], []
        for row in rows:
            result = self._map_row(row, offerings, llm_provider)
            recommended.extend(result["recommended_mappings"])
            no_reco.extend(result["no_recommendation"])
        
        # Reorder columns: original first, then new fields
        recommended = [self._reorder_columns(r, original_columns) for r in recommended]
        no_reco = [self._reorder_columns(r, original_columns, is_no_reco=True) for r in no_reco]

        # Build summary
        summary = self._build_summary(len(rows), recommended, no_reco)

        # Export artifacts
        try:
            paths = self._export_artifacts(
                recommended, no_reco, summary, output_name_prefix
            )
        except Exception as exc:
            return {"status": "error", "errors": [f"Export failed: {exc}"]}

        # Build offering breakdown
        offering_counts = {}
        for rec in recommended:
            offering = rec.get("recommended_offering", "Unknown")
            offering_counts[offering] = offering_counts.get(offering, 0) + 1
        
        # Build human-readable response
        return {
            "status": "success",
            "message": f"Successfully mapped {summary['total_rows']} opportunities to offerings",
            "summary": {
                "total_opportunities_analyzed": summary["total_rows"],
                "opportunities_with_recommendations": summary["rows_with_recommendations"],
                "total_recommendations_generated": summary["total_recommendations"],
                "recommendation_rate": f"{summary['recommendation_rate_percent']}%",
                "average_confidence": summary["average_confidence"],
                "opportunities_without_recommendations": summary["no_recommendation_count"]
            },
            "offering_breakdown": [
                {"offering": k, "recommendation_count": v} 
                for k, v in sorted(offering_counts.items(), key=lambda x: x[1], reverse=True)
            ],
            "artifacts_location": {
                "folder": str(self._get_output_dir().relative_to(self._workspace_root)),
                "files_generated": ["JSON", "CSV (recommended)", "CSV (no recommendation)", "Excel", "Markdown"]
            }
        }

    def _parse_rows(self, data: Any) -> List[Dict[str, Any]]:
        """Parse enriched_rows from various input formats."""
        if isinstance(data, str):
            data = json.loads(Path(data).read_text() if Path(data).exists() else data)
        
        if isinstance(data, dict):
            for key in ("enriched_rows", "rows", "data"):
                if key in data and isinstance(data[key], list):
                    return [r if isinstance(r, dict) else {"raw": str(r)} for r in data[key]]
            return [data]
        
        if isinstance(data, list):
            return [r if isinstance(r, dict) else {"raw": str(r)} for r in data]
        
        raise ValueError("Invalid enriched_rows format")

    def _read_offerings_excel(self, file_path: str) -> Dict[str, Any]:
        """Read offerings from Excel file."""
        from openpyxl import load_workbook

        path = Path(file_path)
        if not path.is_absolute():
            path = self._workspace_root / file_path
        
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        
        # Find "Offering Name" column (not "Offering Category")
        header = next(ws.iter_rows(values_only=True))
        name_col = None
        for i, h in enumerate(header):
            if h:
                h_norm = str(h).strip().lower()
                # Match exact "offering name" or variations, but NOT "offering category"
                if h_norm in ("offering name", "offering_name", "offeringname") or \
                   (h_norm == "offering name" or h_norm.endswith(" name") and "offering" in h_norm):
                    name_col = i
                    logger.info(f"Found 'Offering Name' column at index {i}: {h}")
                    break
        
        if name_col is None:
            raise ValueError("No 'Offering Name' column found. Available columns: " + ", ".join(str(h) for h in header if h))
        
        # Extract offerings
        offerings = []
        for row in ws.iter_rows(min_row=2, values_only=True):
            if row[name_col]:
                offerings.append({
                    "name": str(row[name_col]).strip(),
                    "data": {str(header[i]): str(row[i]) for i in range(len(header)) if i < len(row) and row[i]}
                })
        
        wb.close()
        
        if not offerings:
            raise ValueError("No offerings found in Excel")
        
        return {
            "names": [o["name"] for o in offerings],
            "context": "\n\n".join(
                f"{o['name']}:\n" + "\n".join(f"  {k}: {v}" for k, v in o["data"].items())
                for o in offerings
            )
        }

    def _map_row(
        self, row: Dict[str, Any], offerings: Dict[str, Any], provider: Optional[str]
    ) -> Dict[str, List[Dict[str, Any]]]:
        """Map a single row using LLM."""
        prompt = self._build_prompt(row, offerings)
        response = get_llm_response_with_fallback(
            prompt=prompt, provider_name=provider, temperature=0, max_tokens=1800
        )
        
        parsed = self._parse_json(response)
        row_id = self._get_row_id(row)
        
        # Validate recommendations
        valid_recs = []
        rejected_recs = []
        for rec in parsed.get("recommended_mappings", []):
            if not isinstance(rec, dict):
                continue
            name = str(rec.get("recommended_offering", "")).strip()
            if self._is_valid_offering(name, offerings["names"]):
                valid_recs.append({**row, **rec, "row_identifier": row_id})
            else:
                rejected_recs.append(name)
                logger.warning(
                    f"Rejected invalid offering '{name}' for row {row_id}. "
                    f"Allowed: {offerings['names']}"
                )
        
        if valid_recs:
            # Sort by confidence_score descending
            valid_recs.sort(key=lambda x: x.get("confidence_score", 0), reverse=True)
            
            # Limit recommendations: max 2, or only 1 if first confidence > 90%
            if len(valid_recs) > 0:
                first_confidence = valid_recs[0].get("confidence_score", 0)
                if first_confidence > 90:
                    valid_recs = valid_recs[:1]
                    logger.info(f"Row {row_id}: High confidence ({first_confidence}%) - returning only 1 recommendation")
                else:
                    valid_recs = valid_recs[:2]
                    logger.info(f"Row {row_id}: Returning top {len(valid_recs)} recommendation(s)")
            
            return {"recommended_mappings": valid_recs, "no_recommendation": []}
        
        # No valid recommendation
        no_reco = parsed.get("no_recommendation", [{}])[0] if parsed.get("no_recommendation") else {}
        return {
            "recommended_mappings": [],
            "no_recommendation": [{
                **row,
                "row_identifier": row_id,
                "reason": str(no_reco.get("ambiguity_or_gap_reason", "No valid recommendation")),
                "extra_info_needed": str(no_reco.get("what_extra_info_is_needed", ""))
            }]
        }

    def _build_prompt(self, row: Dict[str, Any], offerings: Dict[str, Any]) -> str:
        """Build LLM prompt for row mapping."""
        names_list = "\n".join(f"- {n}" for n in offerings["names"])
        return (
            f"Map this opportunity to offerings. Only use offerings from the ALLOWED list.\n\n"
            f"ALLOWED OFFERINGS:\n{names_list}\n\n"
            f"OFFERINGS CONTEXT:\n{offerings['context']}\n\n"
            f"OPPORTUNITY:\n{json.dumps(row, indent=2)}\n\n"
            f"IMPORTANT: Provide recommendations ranked by confidence (highest first). "
            f"Include up to 3-4 options, but only the top 1-2 will be used. "
            f"If your top recommendation has >90% confidence, indicate this clearly.\n\n"
            f"Return JSON with keys: recommended_mappings (list) or no_recommendation (list).\n"
            f"Recommended mapping fields: rank, recommended_offering, confidence_score, "
            f"confidence_label, mapping_reason.\n"
            f"No recommendation fields: ambiguity_or_gap_reason, what_extra_info_is_needed."
        )

    def _build_summary(
        self, total: int, recommended: List[Dict], no_reco: List[Dict]
    ) -> Dict[str, Any]:
        """Build summary metrics."""
        row_ids = {r.get("row_identifier") for r in recommended if r.get("row_identifier")}
        scores = [r.get("confidence_score", 0) for r in recommended]
        avg_score = sum(scores) / len(scores) if scores else 0
        
        return {
            "total_rows": total,
            "rows_with_recommendations": len(row_ids),
            "total_recommendations": len(recommended),
            "no_recommendation_count": len(no_reco),
            "recommendation_rate_percent": round(len(row_ids) / total * 100, 2) if total else 0,
            "average_confidence": round(avg_score, 2)
        }

    def _export_artifacts(
        self, recommended: List[Dict], no_reco: List[Dict], summary: Dict, prefix: str
    ) -> Dict[str, str]:
        """Export JSON, CSV, Excel, Markdown artifacts."""
        output_dir = self._get_output_dir()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base = f"{prefix}_{timestamp}"
        
        # JSON
        json_path = output_dir / f"{base}.json"
        json_path.write_text(json.dumps({
            "recommended_mappings": recommended,
            "no_recommendation": no_reco,
            "summary": summary
        }, indent=2))
        
        # CSV
        rec_csv = output_dir / f"{base}_recommended.csv"
        no_csv = output_dir / f"{base}_no_recommendation.csv"
        self._write_csv(rec_csv, recommended)
        self._write_csv(no_csv, no_reco)
        
        # Excel
        xlsx = output_dir / f"{base}.xlsx"
        self._write_excel(xlsx, recommended, no_reco, summary)
        
        # Markdown
        md = output_dir / f"{base}.md"
        self._write_markdown(md, recommended, no_reco, summary)
        
        return {
            "json_path": str(json_path),
            "markdown_path": str(md),
            "recommended_csv_path": str(rec_csv),
            "no_recommendation_csv_path": str(no_csv),
            "excel_path": str(xlsx)
        }

    def _write_csv(self, path: Path, rows: List[Dict]) -> None:
        """Write CSV file."""
        if not rows:
            path.write_text("", encoding="utf-8")
            return
        
        # Use ordered keys from first row, then add any additional keys from other rows
        fieldnames = list(rows[0].keys())
        seen = set(fieldnames)
        for row in rows[1:]:
            for key in row.keys():
                if key not in seen:
                    fieldnames.append(key)
                    seen.add(key)
        
        with path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow({k: self._csv_value(v) for k, v in row.items()})
    
    def _csv_value(self, val: Any) -> Any:
        """Convert value for CSV (lists/dicts to JSON strings)."""
        if isinstance(val, (list, dict)):
            return json.dumps(val)
        return val

    def _write_excel(self, path: Path, rec: List[Dict], no_rec: List[Dict], summary: Dict) -> None:
        """Write Excel file."""
        from openpyxl import Workbook
        
        wb = Workbook()
        
        # Recommended sheet
        ws1 = wb.active
        ws1.title = "Recommended"
        if rec:
            ws1.append(list(rec[0].keys()))
            for row in rec:
                ws1.append([self._excel_value(v) for v in row.values()])
        
        # No recommendation sheet
        ws2 = wb.create_sheet("No Recommendation")
        if no_rec:
            ws2.append(list(no_rec[0].keys()))
            for row in no_rec:
                ws2.append([self._excel_value(v) for v in row.values()])
        
        # Summary sheet
        ws3 = wb.create_sheet("Summary")
        ws3.append(["Metric", "Value"])
        for k, v in summary.items():
            ws3.append([k, v])
        
        wb.save(path)
    
    def _excel_value(self, val: Any) -> Any:
        """Convert value for Excel cell (lists/dicts to JSON strings)."""
        if isinstance(val, (list, dict)):
            return json.dumps(val)
        return val

    def _write_markdown(self, path: Path, rec: List[Dict], no_rec: List[Dict], summary: Dict) -> None:
        """Write Markdown file."""
        lines = [
            "# CRM Offering Mapping Results",
            "",
            "## Summary",
            "",
            "| Metric | Value |",
            "|--------|------:|"
        ]
        lines.extend(f"| {k} | {v} |" for k, v in summary.items())
        
        lines.extend([
            "",
            "## Recommended Mappings",
            "",
            f"Total: {len(rec)}",
            ""
        ])
        
        lines.extend([
            "",
            "## No Recommendations",
            "",
            f"Total: {len(no_rec)}",
            ""
        ])
        
        path.write_text("\n".join(lines))

    def _get_output_dir(self) -> Path:
        """Get output directory for artifacts."""
        if self._data_dir:
            base = Path(self._data_dir).parent
            output_dir = base / "artifacts"
        else:
            output_dir = Path(__file__).parent / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir

    def _parse_json(self, text: str) -> Dict:
        """Parse JSON from LLM response."""
        try:
            return json.loads(text)
        except:
            # Try to extract JSON from markdown block
            text = text.strip()
            if text.startswith("```"):
                text = text.split("```", 2)[1].removeprefix("json").strip()
            start = text.find("{")
            end = text.rfind("}")
            if start >= 0 and end > start:
                try:
                    return json.loads(text[start:end+1])
                except:
                    pass
        return {}

    def _get_row_id(self, row: Dict) -> str:
        """Extract row identifier."""
        for key in ["row_identifier", "id", "opportunity_id", "name", "title"]:
            if key in row and row[key]:
                return str(row[key])
        return ""

    def _is_valid_offering(self, name: str, allowed: List[str]) -> bool:
        """Check if offering name is in allowed list."""
        normalized = name.lower().strip()
        return normalized in {a.lower().strip() for a in allowed}
    
    def _reorder_columns(self, row: Dict[str, Any], original_columns: List[str], is_no_reco: bool = False) -> Dict[str, Any]:
        """Reorder columns: original first, then new fields in specific order."""
        ordered = {}
        
        # Add original columns first
        for col in original_columns:
            if col in row:
                ordered[col] = row[col]
        
        # Add new columns in specific order
        if is_no_reco:
            new_fields = ["reason", "extra_info_needed"]
        else:
            new_fields = ["extracted_phrases", "recommended_offering", "confidence_score", "rank", "mapping_reason"]
        
        for field in new_fields:
            if field in row:
                # Rename for clarity
                if field == "confidence_score":
                    ordered["confidence"] = row[field]
                else:
                    ordered[field] = row[field]
        
        # Add any remaining fields not in original or new lists
        for key, value in row.items():
            if key not in ordered and key not in ["confidence_score"]:
                ordered[key] = value
        
        return ordered
