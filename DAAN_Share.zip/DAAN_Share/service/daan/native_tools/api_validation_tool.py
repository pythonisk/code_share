"""
API Validation Tool — Denodo to Fabric Migration Testing Automation

Action tool executed by AGENT_TA_05 (API Validation Agent).
Compares REST / GraphQL API responses between Denodo (source) and
Microsoft Fabric (target), validating:

  - Data consistency  : field-level value matching between responses
  - Response schema   : structural equivalence of JSON responses
  - Masking compliance: PII / sensitive fields are masked in the target
  - HTTP status codes : both APIs return expected status codes

This agent is CONDITIONAL — if no API endpoints are provided in the
session context, it returns a "skipped" status so the pipeline can continue.

Connection credentials come entirely from the input_context payload or
from environment variables (no hardcoding).
"""

from __future__ import annotations

import ast
import json
import logging
import os
from typing import Any, Dict, List, Optional, Set

import requests

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _build_session(
    auth_type: str,
    token: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    api_key: Optional[str] = None,
    api_key_header: str = "X-API-Key",
) -> requests.Session:
    """Create a requests.Session with the appropriate auth configured."""
    session = requests.Session()
    session.headers["Accept"] = "application/json"

    auth_type = (auth_type or "").lower()
    if auth_type in ("bearer", "token") and token:
        session.headers["Authorization"] = f"Bearer {token}"
    elif auth_type == "basic" and username and password:
        session.auth = (username, password)
    elif auth_type == "apikey" and api_key:
        session.headers[api_key_header] = api_key
    # "none" — unauthenticated (e.g. public API)
    return session


def _call_api(
    session: requests.Session,
    url: str,
    method: str,
    params: Optional[Dict],
    body: Optional[Dict],
    timeout: int,
) -> Dict[str, Any]:
    """Call an API endpoint and return a normalised response dict."""
    try:
        resp = session.request(
            method.upper(),
            url,
            params=params or {},
            json=body,
            timeout=timeout,
        )
        try:
            body_data = resp.json()
        except ValueError:
            body_data = resp.text
        return {
            "status_code": resp.status_code,
            "success": resp.ok,
            "body": body_data,
            "headers": dict(resp.headers),
        }
    except requests.RequestException as exc:
        return {"status_code": None, "success": False, "body": None, "error": str(exc)}


def _flatten(obj: Any, prefix: str = "") -> Dict[str, Any]:
    """Recursively flatten a nested dict/list to dot-notation key-value pairs."""
    items: Dict[str, Any] = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            items.update(_flatten(v, f"{prefix}.{k}" if prefix else str(k)))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            items.update(_flatten(v, f"{prefix}[{i}]"))
    else:
        items[prefix] = obj
    return items


def _field_level_compare(
    src_body: Any,
    tgt_body: Any,
    masked_fields: Set[str],
) -> List[Dict]:
    """
    Compare flattened field values between source and target responses.
    Fields listed in masked_fields are expected to differ; mismatches there
    are reported as masking_compliance failures, not data mismatches.
    """
    src_flat = _flatten(src_body)
    tgt_flat = _flatten(tgt_body)
    all_keys = set(src_flat) | set(tgt_flat)

    mismatches: List[Dict] = []
    for key in sorted(all_keys):
        sv = str(src_flat.get(key, "__MISSING__"))
        tv = str(tgt_flat.get(key, "__MISSING__"))
        if sv == tv:
            continue

        # Determine if this is a masking difference or a data mismatch
        field_name = key.split(".")[-1].split("[")[0]
        is_masked_field = any(mf.lower() in key.lower() for mf in masked_fields)
        mismatches.append({
            "field_path": key,
            "source_value": sv[:200],
            "target_value": tv[:200],
            "issue_type": "masking_compliance" if is_masked_field else "data_mismatch",
        })
    return mismatches


# ---------------------------------------------------------------------------
# Input parser
# ---------------------------------------------------------------------------

def _parse_input(input_context) -> Optional[Dict]:
    if isinstance(input_context, dict):
        return input_context
    if not isinstance(input_context, str) or not input_context.strip():
        return None
    for loader in (json.loads, ast.literal_eval):
        try:
            obj = loader(input_context.strip())
            return obj if isinstance(obj, dict) else None
        except (ValueError, SyntaxError):
            pass
    logger.warning("ApiValidationTool: cannot parse input_context")
    return None


# ---------------------------------------------------------------------------
# Public tool class
# ---------------------------------------------------------------------------

class ApiValidationTool:
    """
    DAAN5 native action tool — API Validation Agent (AGENT_TA_05).

    Compares Denodo and Fabric API responses for data consistency,
    masking compliance, and schema equivalence.
    """

    def __init__(self, data_dir: str = "", **_kwargs):
        self._data_dir = data_dir

    def validate_api(self, input_context) -> str:
        """
        Execute API validation between Denodo (source) and Fabric (target).

        Args:
            input_context: dict or JSON string. Expected keys:
              fabric_api_url:       Full Fabric REST endpoint URL
              denodo_api_url:       Full Denodo REST endpoint URL
              method:               HTTP method (default: GET)
              params:               Query parameters dict (optional)
              body:                 Request body dict (optional)
              fabric_auth_type:     'bearer' | 'basic' | 'apikey' | 'none'
              fabric_token:         Bearer token for Fabric
              fabric_client_id:     Service-principal client ID
              fabric_client_secret: Service-principal client secret
              fabric_tenant_id:     Azure tenant ID
              denodo_auth_type:     'bearer' | 'basic' | 'none'
              denodo_token:         Denodo bearer token
              denodo_username:      Denodo username
              denodo_password:      Denodo password
              masked_fields:        list of field names expected to be masked in Fabric
              timeout_seconds:      HTTP timeout (default: 60)

        Returns:
            JSON string with api_validation_status, mismatches, masking_compliance.
        """
        payload = _parse_input(input_context)
        if payload is None:
            return json.dumps({
                "api_validation_status": "skipped",
                "reason": "No input_context provided",
            })

        fabric_url = (payload.get("fabric_api_url") or "").strip()
        denodo_url = (payload.get("denodo_api_url") or "").strip()

        # --- Conditional: skip if no endpoints provided ---
        if not fabric_url or not denodo_url:
            logger.info("ApiValidationTool: no API endpoints provided — skipping")
            return json.dumps({
                "api_validation_status": "skipped",
                "reason": "No API endpoints provided in session context",
            })

        method = payload.get("method", "GET")
        params = payload.get("params") or {}
        body = payload.get("body")
        timeout = int(payload.get("timeout_seconds", 60))
        masked_fields: Set[str] = set(payload.get("masked_fields") or [])

        # ---- Resolve Fabric auth (param → env) ----
        fabric_auth = payload.get("fabric_auth_type", "bearer")
        fabric_token = (
            payload.get("fabric_token")
            or _resolve_fabric_token(
                payload.get("fabric_tenant_id"),
                payload.get("fabric_client_id"),
                payload.get("fabric_client_secret"),
            )
        )

        # ---- Resolve Denodo auth (param → env) ----
        denodo_auth = payload.get("denodo_auth_type", "bearer")
        denodo_token = payload.get("denodo_token") or os.getenv("DENODO_BEARER_TOKEN", "")
        denodo_user = payload.get("denodo_username") or os.getenv("DENODO_USER", "")
        denodo_pwd = payload.get("denodo_password") or os.getenv("DENODO_PASSWORD", "")

        fabric_session = _build_session(
            auth_type=fabric_auth,
            token=fabric_token,
        )
        denodo_session = _build_session(
            auth_type=denodo_auth,
            token=denodo_token,
            username=denodo_user,
            password=denodo_pwd,
        )

        logger.info("ApiValidationTool: calling Fabric API: %s", fabric_url)
        fabric_resp = _call_api(fabric_session, fabric_url, method, params, body, timeout)

        logger.info("ApiValidationTool: calling Denodo API: %s", denodo_url)
        denodo_resp = _call_api(denodo_session, denodo_url, method, params, body, timeout)

        # ---- Status code check ----
        status_ok = fabric_resp.get("success") and denodo_resp.get("success")

        # ---- Field-level comparison ----
        field_mismatches: List[Dict] = []
        masking_issues: List[Dict] = []
        if fabric_resp.get("body") is not None and denodo_resp.get("body") is not None:
            all_mismatches = _field_level_compare(
                denodo_resp["body"],  # source (Denodo) → left side
                fabric_resp["body"],  # target (Fabric) → right side
                masked_fields,
            )
            field_mismatches = [m for m in all_mismatches if m["issue_type"] == "data_mismatch"]
            masking_issues = [m for m in all_mismatches if m["issue_type"] == "masking_compliance"]

        # Masking compliance: flagged fields that differ are EXPECTED (masking works)
        # Fields in masked_fields that are identical indicate masking is NOT applied
        masking_passed = len(masking_issues) == 0 or all(
            m["target_value"] != m["source_value"] for m in masking_issues
        )

        overall_status = "pass" if (status_ok and not field_mismatches and masking_passed) else "fail"

        result = {
            "api_validation_status": overall_status,
            "fabric_api_url": fabric_url,
            "denodo_api_url": denodo_url,
            "fabric_http_status": fabric_resp.get("status_code"),
            "denodo_http_status": denodo_resp.get("status_code"),
            "fabric_response_summary": _summarise_response(fabric_resp),
            "denodo_response_summary": _summarise_response(denodo_resp),
            "field_level_mismatch_count": len(field_mismatches),
            "field_level_mismatches": field_mismatches[:100],  # cap payload
            "masking_compliance": masking_passed,
            "masking_issues": masking_issues[:50],
        }
        logger.info(
            "ApiValidationTool: status=%s, mismatches=%d, masking_ok=%s",
            overall_status, len(field_mismatches), masking_passed,
        )
        return json.dumps(result, default=str)


# ---------------------------------------------------------------------------
# Auth helper (Fabric service-principal)
# ---------------------------------------------------------------------------

def _resolve_fabric_token(
    tenant_id: Optional[str],
    client_id: Optional[str],
    client_secret: Optional[str],
) -> Optional[str]:
    """Obtain Fabric bearer token via service-principal; fall back to env var."""
    direct = os.getenv("FABRIC_BEARER_TOKEN", "").strip()
    if direct:
        return direct
    t = (tenant_id or os.getenv("FABRIC_TENANT_ID", "")).strip()
    c = (client_id or os.getenv("FABRIC_CLIENT_ID", "")).strip()
    s = (client_secret or os.getenv("FABRIC_CLIENT_SECRET", "")).strip()
    if not (t and c and s):
        return None
    try:
        resp = requests.post(
            f"https://login.microsoftonline.com/{t}/oauth2/v2.0/token",
            data={
                "grant_type": "client_credentials",
                "client_id": c,
                "client_secret": s,
                "scope": "https://api.fabric.microsoft.com/.default",
            },
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json().get("access_token")
    except Exception as exc:
        logger.error("Failed to obtain Fabric service-principal token: %s", exc)
        return None


def _summarise_response(resp: Dict) -> Dict:
    """Return a lightweight summary of an API response for the report."""
    body = resp.get("body")
    if isinstance(body, list):
        return {"type": "array", "length": len(body), "sample": body[:3]}
    if isinstance(body, dict):
        return {"type": "object", "keys": list(body.keys())[:20]}
    return {"type": type(body).__name__, "value": str(body)[:200] if body else None}
