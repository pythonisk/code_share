"""
download_excel_artifacts.py — Tool to read any JSON and create XLSX files in artifacts folder.

Usage by an LLM agent:
    result = download_excel_artifacts(json_data, filename="output.xlsx")

If operation fails, result contains {"status": "error", "errors": [...]}.
If operation succeeds, result contains {"status": "ok", "xlsx_path": "...", "message": "..."}.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

import pandas as pd

logger = logging.getLogger(__name__)

class DownloadExcelArtifacts:
    """DAAN native tool for creating XLSX files from JSON."""

    def __init__(self, data_dir: Optional[str] = None):
        self.tool_name = "DownloadExcelArtifacts"
        self._data_dir = data_dir
        logger.info("%s: Initialized (data_dir=%s)", self.tool_name, data_dir)

    def download_excel_artifacts(self, json_data: Any, filename: str = "output.xlsx", **kwargs) -> dict[str, Any]:
        """
        Reads any JSON-serializable data and writes it as an XLSX file in the artifacts folder.

        Args:
            json_data: JSON-serializable data (list of dicts, dict, etc.)
            filename: Name of the XLSX file to create (default: output.xlsx)

        Returns:
            dict with either:
              {"status": "ok",    "xlsx_path": "<absolute path>", "message": "..."}
              {"status": "error", "errors":   ["...", ...]}
        """
        try:
            # Convert JSON to DataFrame
            if isinstance(json_data, str):
                json_data = json.loads(json_data)
            if isinstance(json_data, dict):
                # Try to flatten dict to rows if possible
                if all(isinstance(v, list) for v in json_data.values()):
                    # Dict of lists: make columns
                    df = pd.DataFrame(json_data)
                else:
                    # Single row
                    df = pd.DataFrame([json_data])
            elif isinstance(json_data, list):
                df = pd.DataFrame(json_data)
            else:
                return {"status": "error", "errors": ["Unsupported JSON structure for XLSX export."]}
        except Exception as exc:
            logger.exception("Failed to parse JSON data.")
            return {"status": "error", "errors": [f"JSON parsing error: {exc}"]}

        # Resolve output directory — write into artifacts/ for universal download
        if self._data_dir:
            data_path = Path(self._data_dir)
            session_dir = data_path.parent if data_path.name == "inputs" else data_path
            output_dir = session_dir / "artifacts"
        else:
            output_dir = Path(__file__).resolve().parent / "artifacts"
        output_dir.mkdir(parents=True, exist_ok=True)

        xlsx_path = output_dir / filename
        try:
            df.to_excel(xlsx_path, index=False)
        except Exception as exc:
            logger.exception("Failed to write XLSX file.")
            return {"status": "error", "errors": [f"XLSX writing error: {exc}"]}

        msg = f"XLSX file created: {xlsx_path}"
        logger.info(msg)
        return {"status": "ok", "xlsx_path": str(xlsx_path), "message": msg}
