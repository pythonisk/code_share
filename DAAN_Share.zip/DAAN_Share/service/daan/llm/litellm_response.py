"""Shared LiteLLM response normalization helpers."""

from __future__ import annotations

from typing import Any


def extract_response_content(response: Any) -> str | None:
    """Extract assistant text from common LiteLLM response shapes."""
    if hasattr(response, "choices") and response.choices:
        choice = response.choices[0]
        message = getattr(choice, "message", None)
        content = getattr(message, "content", None) if message is not None else None
        if isinstance(content, str) and content.strip():
            return content.strip()
        if isinstance(content, list):
            text_parts = []
            for part in content:
                if isinstance(part, dict):
                    text = part.get("text")
                    if isinstance(text, str) and text:
                        text_parts.append(text)
            if text_parts:
                return "\n".join(text_parts).strip()

    if isinstance(response, dict):
        choices = response.get("choices") or []
        if choices:
            message = choices[0].get("message") or {}
            content = message.get("content")
            if isinstance(content, str) and content.strip():
                return content.strip()
            if isinstance(content, list):
                text_parts = []
                for part in content:
                    if isinstance(part, dict):
                        text = part.get("text")
                        if isinstance(text, str) and text:
                            text_parts.append(text)
                if text_parts:
                    return "\n".join(text_parts).strip()

    return None


def extract_usage_metadata(response: Any) -> dict[str, int]:
    """Extract token usage from common LiteLLM response shapes."""
    usage = getattr(response, "usage", None)
    if usage is None and isinstance(response, dict):
        usage = response.get("usage")

    if usage is None:
        return {}

    if isinstance(usage, dict):
        usage_dict = usage
    else:
        usage_dict = {
            "prompt_tokens": getattr(usage, "prompt_tokens", None),
            "completion_tokens": getattr(usage, "completion_tokens", None),
            "total_tokens": getattr(usage, "total_tokens", None),
            "input_tokens": getattr(usage, "input_tokens", None),
            "output_tokens": getattr(usage, "output_tokens", None),
        }

    return {key: value for key, value in usage_dict.items() if value is not None}


def provider_name_from_model(model_name: str, default_provider: str) -> str:
    """Infer provider name from the served model string when possible."""
    name = str(model_name or "").strip().lower()
    if name.startswith("azure/"):
        return "azure_openai"
    if name.startswith("gemini/") or name.startswith("gemini-") or name.startswith("models/gemini"):
        return "google"
    return default_provider


def normalize_completion_response(
    *,
    response: Any,
    default_model: str,
    default_provider: str,
    requested_model: str | None = None,
    requested_provider: str | None = None,
) -> dict[str, Any]:
    """Normalize a LiteLLM response into a metadata-rich payload."""
    text = extract_response_content(response)
    if not text:
        raise ValueError(
            "LiteLLM response did not contain assistant content in choices[0].message.content"
        )

    response_model = getattr(response, "model", None)
    if response_model is None and isinstance(response, dict):
        response_model = response.get("model")

    served_model = str(response_model or default_model)
    resolved_requested_model = str(requested_model or default_model)
    resolved_requested_provider = str(requested_provider or default_provider)
    actual_provider = provider_name_from_model(served_model, default_provider)
    fallback_used = bool(response_model and resolved_requested_model not in served_model)

    return {
        "text": text,
        "usage": extract_usage_metadata(response),
        "model": served_model,
        "provider": actual_provider,
        "served_by": served_model,
        "requested_model": resolved_requested_model,
        "requested_provider": resolved_requested_provider,
        "fallback_used": fallback_used,
    }