"""
LLM Fallback (compatibility shim).

Fallback is now owned by daan.llm.llm_provider: the LiteLLM gateway is the single
source of truth and the configured `fallback` provider is used ONLY when the
gateway path fails. This module remains as a thin compatibility layer for any
callers that still import the previous Router-based entry points.
"""

import logging
from typing import Any, Optional

from daan.llm.llm_provider import (
    get_fallback_settings,
    get_llm_completion_with_fallback,
)

logger = logging.getLogger(__name__)


def build_fallback_router() -> None:
    """Deprecated: the LiteLLM Router is no longer used. Kept for compatibility."""
    return None


def get_fallback_router() -> None:
    """Deprecated: the LiteLLM Router is no longer used. Kept for compatibility."""
    return None


def reset_fallback_router() -> None:
    """No-op retained for compatibility with previous cached-router behavior."""
    return None


def get_fallback_completion(
    prompt: str, provider_name: Optional[str] = None, **kwargs
) -> Optional[str | dict[str, Any]]:
    """Run a completion with failure-only fallback.

    Delegates to daan.llm.llm_provider.get_llm_completion_with_fallback so the
    LiteLLM gateway stays the single source of truth. Returns None when no
    fallback provider is configured, so callers may use the primary path.
    """
    if get_fallback_settings() is None:
        return None

    return_metadata = bool(kwargs.pop("return_metadata", False))
    # These flags were previously consumed by the Router path; drop unsupported ones.
    kwargs.pop("expect_json", None)
    kwargs.pop("json_required", None)

    completion = get_llm_completion_with_fallback(
        prompt=prompt, provider_name=provider_name, **kwargs
    )
    if return_metadata:
        return completion
    return str(completion.get("text") or "")
