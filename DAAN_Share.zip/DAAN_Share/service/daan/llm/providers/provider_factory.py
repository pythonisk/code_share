"""
Provider Factory
Dynamically loads and creates LLM providers based on configuration.
"""

import importlib
from typing import Dict, Any
from .base_provider import BaseLLMProvider


class ProviderFactory:
    """Factory for creating LLM providers dynamically."""
    
    # Mapping of provider names to their modules and classes
    PROVIDER_MAP = {
        'litellm': {
            'module': 'daan.llm.providers.litellm_provider',
            'class': 'LiteLLMProvider'
        },
        'azure_openai': {
            'module': 'daan.llm.providers.azure_openai_provider',
            'class': 'AzureOpenAIProvider'
        },
        'google': {
            'module': 'daan.llm.providers.google_provider',
            'class': 'GoogleProvider'
        },
        'openai': {
            'module': 'daan.llm.providers.openai_provider',
            'class': 'OpenAIProvider'
        }
    }
    
    @classmethod
    def create_provider(cls, provider_name: str, config: Dict[str, Any]) -> BaseLLMProvider:
        """Create a provider instance dynamically.
        
        Args:
            provider_name: Name of the provider (e.g., 'azure_openai', 'google')
            config: Provider configuration dictionary
            
        Returns:
            BaseLLMProvider: Provider instance
            
        Raises:
            ValueError: If provider is not supported
            ImportError: If provider module cannot be imported
        """
        if provider_name not in cls.PROVIDER_MAP:
            available = ', '.join(cls.PROVIDER_MAP.keys())
            raise ValueError(f"Unsupported provider '{provider_name}'. Available: {available}")
        
        provider_info = cls.PROVIDER_MAP[provider_name]
        
        try:
            # Import the module dynamically
            module = importlib.import_module(provider_info['module'])
            
            # Get the provider class
            provider_class = getattr(module, provider_info['class'])
            
            # Create and return the provider instance
            provider = provider_class(config)
            print(f"Created provider: {provider_info['class']}")
            
            return provider
            
        except ImportError as e:
            raise ImportError(f"Failed to import provider module {provider_info['module']}: {e}")
        except AttributeError as e:
            raise AttributeError(f"Provider class {provider_info['class']} not found in {provider_info['module']}: {e}")
    
    @classmethod
    def get_available_providers(cls) -> list:
        """Get list of available provider names."""
        return list(cls.PROVIDER_MAP.keys())