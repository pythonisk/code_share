"""
Base Provider Interface
Defines the interface that all LLM providers must implement.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Tuple


class BaseLLMProvider(ABC):
    """Base class for all LLM providers."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
    
    @abstractmethod
    def setup_environment(self) -> str:
        """Setup environment variables and return model name for LiteLLM.
        
        Returns:
            str: Model name formatted for LiteLLM
        """
        pass
    
    @abstractmethod
    def create_model(
        self,
        model_name: str,
        tags: list | None = None,
        reasoning: dict | None = None,
    ) -> Any:
        """Create the actual model object.

        Args:
            model_name: The formatted model name from setup_environment()
            tags: Optional LiteLLM tracking tags to attach to every call made with
                the returned model (applied by gateway-backed providers).
            reasoning: Optional reasoning/thinking config with keys ``profile``
                (anthropic_extended | openai_reasoning | gemini_thinking | none),
                ``enabled``, ``mode``, ``effort``, ``budget_tokens``. Providers
                route via ``daan.llm.reasoning_kwargs.apply_reasoning_to_model_kwargs``
                so unsupported profiles become a silent no-op.

        Returns:
            Model object compatible with Google ADK
        """
        pass
    
    def get_provider_name(self) -> str:
        """Get the provider name."""
        return self.__class__.__name__.replace('Provider', '').lower()