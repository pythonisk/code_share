"""
LiteLLM Gateway Provider
Routes all chat completions through a LiteLLM proxy/gateway.

LiteLLM is the single source of truth for chat models: models are defined and
managed in the LiteLLM Admin UI, not in llm_config.yml. This provider only needs
the gateway URL, an API key, and the model id to request from the gateway.
"""

import os
import logging
from typing import Any

from google.adk.models.lite_llm import LiteLlm

from daan.llm.litellm_response import extract_response_content
from daan.llm.reasoning_kwargs import (
    apply_reasoning_to_model_kwargs,
    call_with_reasoning_fallback,
    resolve_reasoning_profile,
)
from .base_provider import BaseLLMProvider

logger = logging.getLogger(__name__)


def _proxy_model(model_name: str) -> str:
    """Prefix a model id with the LiteLLM proxy route understood by litellm."""
    name = str(model_name or "").strip()
    if not name:
        raise ValueError("LiteLLM model name is required")
    if name.startswith("litellm_proxy/"):
        return name
    return f"litellm_proxy/{name}"


class LiteLLMProvider(BaseLLMProvider):
    """Provider that delegates all completions to a LiteLLM gateway."""

    def _url(self) -> str:
        url = str(self.config.get("url") or "").strip()
        if not url:
            raise ValueError("LiteLLM gateway url is required (config/llm_config.yml -> litellm.url)")
        return url

    def _api_key(self) -> str | None:
        return self.config.get("api_key") or None

    def _default_model(self) -> str:
        return str(self.config.get("default_model") or "").strip() or "gpt-4o"

    def setup_environment(self) -> str:
        """Validate gateway settings and return the default model id to request."""
        # Validate URL early so misconfiguration fails fast.
        self._url()
        return self._default_model()

    def create_model(
        self,
        model_name: str,
        tags: list | None = None,
        reasoning: dict | None = None,
    ) -> Any:
        """Create an ADK LiteLlm model that targets the LiteLLM gateway.
        Args:
            model_name: Model id to request from the gateway.
            tags: Optional LiteLLM tracking tags. Forwarded to the proxy on every
                  call via ``extra_body.metadata.tags`` so requests are attributable
                  in the LiteLLM Admin UI (Logs view).
            reasoning: Optional Anthropic-style extended-thinking config
                       (``{"enabled": bool, "budget_tokens": int}``). When enabled, adds
                       ``extra_body.thinking={"type":"enabled","budget_tokens":N}`` so
                       Claude models emit native thinking content parts. LiteLLM proxy
                       forwards the field; non-supporting models will error, so gate
                       enablement upstream (per-agent).
        """
        # Use team virtual key if set, otherwise fall back to default
        from daan.admin.team_service import get_team_api_key
        team_key = get_team_api_key()
        api_key = team_key if team_key else self._api_key()
        
        # Log which key source is being used
        if team_key:
            logger.info("🔑 LiteLLM using TEAM VIRTUAL KEY")
        else:
            logger.info("🔑 LiteLLM using GLOBAL KEY")

        max_tokens = self.config.get("max_tokens") or self.config.get("max_output_tokens") or 4096
        model_kwargs: dict[str, Any] = {
            "model": _proxy_model(model_name),
            "api_base": self._url(),
            "api_key": api_key,
            "temperature": self.config.get("temperature", 0.7),
            "max_tokens": max_tokens,
        }

        extra_body: dict[str, Any] = {}
        if tags:
            # LiteLLM proxy reads tracking tags from the request body's metadata.
            extra_body["metadata"] = {"tags": list(tags)}

        effective_reasoning = reasoning if reasoning is not None else self.config.get("reasoning")
        # Priority: caller explicit -> model-name inference -> config -> default.
        # Recognizable ids like ``azure/gpt-4o`` correctly override the gateway
        # config profile so ``thinking`` is never sent to non-reasoning models.
        explicit_profile = None
        if isinstance(effective_reasoning, dict):
            explicit_profile = effective_reasoning.get("profile")
        profile = resolve_reasoning_profile(
            explicit_profile,
            model_name,
            self.config.get("reasoning_profile"),
            default_profile="anthropic_extended",
        )
        apply_reasoning_to_model_kwargs(
            model_kwargs, profile, effective_reasoning, model_name,
        )

        if extra_body:
            model_kwargs["extra_body"] = extra_body
        return LiteLlm(**model_kwargs)

    def completion(self, prompt: str, model_name: str | None = None, **kwargs) -> str | Any:
        """Generate a completion by calling the LiteLLM gateway."""
        import litellm

        # Use team virtual key if set, otherwise fall back to default
        from daan.admin.team_service import get_team_api_key
        team_key = get_team_api_key()
        api_key = team_key if team_key else self._api_key()
        
        # Log which key source is being used
        if team_key:
            logger.info("🔑 LiteLLM completion using TEAM VIRTUAL KEY")
        else:
            logger.info("🔑 LiteLLM completion using GLOBAL KEY")

        return_metadata = bool(kwargs.pop("return_metadata", False))
        formatted_model = _proxy_model(model_name or self._default_model())
        messages = [{"role": "user", "content": prompt}]

        default_max_tokens = self.config.get("max_tokens")
        if default_max_tokens is None:
            default_max_tokens = self.config.get("max_output_tokens")

        request_kwargs = {
            "max_tokens": default_max_tokens if default_max_tokens is not None else 4096,
            "temperature": self.config.get("temperature", 0.7),
        }
        request_kwargs.update(kwargs)

        if "max_output_tokens" in request_kwargs and "max_tokens" not in kwargs:
            request_kwargs["max_tokens"] = request_kwargs.pop("max_output_tokens")
        else:
            request_kwargs.pop("max_output_tokens", None)

        call_kwargs: dict[str, Any] = {
            "model": formatted_model,
            "messages": messages,
            "api_base": self._url(),
            "api_key": api_key,
            **request_kwargs,
        }
        response = call_with_reasoning_fallback(
            litellm.completion,
            kwargs=call_kwargs,
            model_label=formatted_model,
        )

        if return_metadata:
            return response

        content = extract_response_content(response)
        if content:
            return content

        raise ValueError(
            "LiteLLM gateway response did not contain assistant content in "
            "choices[0].message.content"
        )
