"""
OpenAI Provider
Handles OpenAI specific configuration and model creation.
"""

import os
from typing import Any
from google.adk.models.lite_llm import LiteLlm
from daan.llm.litellm_response import extract_response_content
from daan.llm.reasoning_kwargs import (
    apply_reasoning_to_model_kwargs,
    call_with_reasoning_fallback,
    resolve_reasoning_profile,
)
from .base_provider import BaseLLMProvider


class OpenAIProvider(BaseLLMProvider):
    """OpenAI provider implementation."""
    
    def setup_environment(self) -> str:
        """Setup OpenAI environment variables."""
        api_key = self.config.get('api_key') or os.getenv(self.config.get('api_key_env', ''))
        if not api_key:
            raise ValueError("OpenAI API key not found")
        
        os.environ["OPENAI_API_KEY"] = api_key
        return self.config['model']
    
    def create_model(
        self,
        model_name: str,
        tags: list | None = None,
        reasoning: dict | None = None,
    ) -> Any:
        """Create OpenAI LiteLLM model."""
        model_kwargs: dict[str, Any] = {"model": model_name, "temperature": 0.7}
        # OpenAI o-series (o1/o3/o4) and GPT-5 -> openai_reasoning by name;
        # gpt-4o and friends -> none by name. Config still wins if explicit.
        explicit_profile = (reasoning or {}).get("profile") if isinstance(reasoning, dict) else None
        profile = resolve_reasoning_profile(
            explicit_profile, model_name, self.config.get("reasoning_profile"), default_profile="none",
        )
        apply_reasoning_to_model_kwargs(model_kwargs, profile, reasoning, model_name)
        return LiteLlm(**model_kwargs)

    def completion(self, prompt: str, model_name: str = None, **kwargs) -> str | Any:
        """
        Generate a completion using LiteLLM for OpenAI models.
        """
        import litellm
        return_metadata = bool(kwargs.pop("return_metadata", False))

        formatted_model = model_name or self.config["model"]
        messages = [{"role": "user", "content": prompt}]

        default_max_tokens = self.config.get("max_tokens")
        if default_max_tokens is None:
            default_max_tokens = self.config.get("max_output_tokens")

        request_kwargs = {
            "max_tokens": default_max_tokens if default_max_tokens is not None else 4096,
            "temperature": self.config.get("temperature", 0.7),
        }

        request_kwargs.update(kwargs)

        if "max_output_tokens" in request_kwargs and "max_tokens" not in kwargs:
            request_kwargs["max_tokens"] = request_kwargs.pop("max_output_tokens")
        else:
            request_kwargs.pop("max_output_tokens", None)

        call_kwargs: dict[str, Any] = {
            "model": formatted_model,
            "messages": messages,
            **request_kwargs,
        }
        response = call_with_reasoning_fallback(
            litellm.completion,
            kwargs=call_kwargs,
            model_label=formatted_model,
        )

        if return_metadata:
            return response

        content = extract_response_content(response)
        if content:
            return content

        raise ValueError("LiteLLM response did not contain assistant content in choices[0].message.content")