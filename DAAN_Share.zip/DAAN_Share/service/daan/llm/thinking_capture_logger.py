"""LiteLLM CustomLogger that surfaces Anthropic thinking deltas.

Registered once on ``litellm.callbacks`` at import time. LiteLLM calls the
hooks below at defined lifecycle points; we never sit in the request path
so ADK's ``LiteLlm`` bridge, chunk iterators, and response objects are
untouched.

Streaming path
    LiteLLM invokes ``log_stream_event`` / ``async_log_stream_event`` for
    every chunk. For chunks whose ``choices[0].delta`` carries
    ``reasoning_content``, we emit a ``thought`` event to the correct bus.

Non-streaming path
    ``log_success_event`` / ``async_log_success_event`` fires once at the
    end with the full ``ModelResponse``. We check
    ``choices[0].message.reasoning_content`` and emit a single ``thought``.

Session routing
    We already stamp ``extra_body.metadata.tags = ["session:<sid>", ...]``
    on every gateway call via ``build_llm_tags``. This module reads that
    tag and dispatches to ``get_bus(sid)``.
"""

from __future__ import annotations

import logging
from typing import Any

import litellm
from litellm.integrations.custom_logger import CustomLogger

logger = logging.getLogger(__name__)


# ── Session tag + reasoning extraction helpers ─────────────────────────────

def _session_id_from_kwargs(kwargs: dict[str, Any] | None) -> str | None:
    """Recover the DAAN session_id from LiteLLM call kwargs."""
    if not isinstance(kwargs, dict):
        return None
    try:
        # Tag may live under extra_body.metadata.tags or top-level metadata.tags
        # depending on how LiteLLM routes it internally.
        for path in ("extra_body", "metadata"):
            container = kwargs.get(path)
            if not isinstance(container, dict):
                continue
            metadata = container.get("metadata") if path == "extra_body" else container
            if not isinstance(metadata, dict):
                continue
            tags = metadata.get("tags") or []
            for tag in tags:
                if isinstance(tag, str) and tag.startswith("session:"):
                    sid = tag.split(":", 1)[1].strip()
                    # Runner may namespace ADK session as {sid}__{agent}[__iN];
                    # bus key is the real prefix.
                    return sid.split("__", 1)[0] if sid else None
    except Exception:
        return None
    return None


def _emit_model_call_end(session_id: str | None) -> None:
    """Emit the lifecycle marker for a completed model call.

    Skips duplicates (LiteLLM may fire both sync and async success hooks for
    the same call) by checking the last event already on the bus.
    """
    if not session_id:
        return
    try:
        from daan.core.observers.reasoning_observer import get_bus
    except Exception:
        return
    bus = get_bus(session_id)
    if bus is None:
        return
    if bus._events and bus._events[-1].get("type") == "model_call_end":
        return
    try:
        bus.emit("model_call_end", {})
    except Exception as exc:
        logger.debug("bus.emit model_call_end failed: %s", exc)


def _reasoning_from_stream_chunk(chunk: Any) -> str:
    """Extract incremental reasoning text from a streaming LiteLLM chunk.

    Works for both adaptive (Sonnet 5 / Opus 5) and enabled (Haiku 4.5) modes
    because LiteLLM normalizes Anthropic's thinking_delta events into
    `delta.reasoning_content` (or `delta.thinking_blocks`) regardless.
    """
    try:
        choices = getattr(chunk, "choices", None) or []
        for choice in choices:
            delta = getattr(choice, "delta", None)
            if delta is None:
                continue
            for attr in ("reasoning_content", "thinking"):
                value = getattr(delta, attr, None)
                if isinstance(value, str) and value:
                    return value
            blocks = getattr(delta, "thinking_blocks", None)
            if isinstance(blocks, list):
                parts = [
                    str(b.get("thinking") or b.get("text") or "")
                    for b in blocks
                    if isinstance(b, dict)
                ]
                joined = "".join(p for p in parts if p)
                if joined:
                    return joined
    except Exception:
        return ""
    return ""


def _reasoning_from_final_response(response: Any) -> str:
    """Extract accumulated reasoning text from a non-streaming final response.

    Fallback for when LiteLLM's per-chunk stream hooks don't fire — some
    LiteLLM versions / proxy modes only invoke the success hook at end.
    """
    try:
        choices = getattr(response, "choices", None) or []
        for choice in choices:
            message = getattr(choice, "message", None)
            if message is None:
                continue
            for attr in ("reasoning_content", "thinking"):
                value = getattr(message, attr, None)
                if isinstance(value, str) and value:
                    return value
            blocks = getattr(message, "thinking_blocks", None)
            if isinstance(blocks, list):
                parts = [
                    str(b.get("thinking") or b.get("text") or "")
                    for b in blocks
                    if isinstance(b, dict)
                ]
                joined = "".join(p for p in parts if p)
                if joined:
                    return joined
            psf = getattr(message, "provider_specific_fields", None)
            if isinstance(psf, dict):
                nested = psf.get("thinking_blocks") or psf.get("content")
                if isinstance(nested, list):
                    parts = [
                        str(b.get("thinking") or b.get("text") or "")
                        for b in nested
                        if isinstance(b, dict) and (b.get("type") == "thinking" or b.get("thinking"))
                    ]
                    joined = "".join(p for p in parts if p)
                    if joined:
                        return joined
    except Exception:
        return ""
    return ""


def _thinking_happened_but_redacted(response: Any) -> bool:
    """True when the response has thinking_blocks with empty text + a signature.

    That's the shape returned when Anthropic (or the upstream proxy) has
    redacted the raw reasoning but forwarded the cryptographic signature.
    """
    try:
        choices = getattr(response, "choices", None) or []
        for choice in choices:
            message = getattr(choice, "message", None)
            if message is None:
                continue
            for holder in (message, getattr(message, "provider_specific_fields", None)):
                if holder is None:
                    continue
                blocks = None
                if hasattr(holder, "thinking_blocks"):
                    blocks = getattr(holder, "thinking_blocks", None)
                elif isinstance(holder, dict):
                    blocks = holder.get("thinking_blocks")
                if isinstance(blocks, list):
                    for b in blocks:
                        if not isinstance(b, dict):
                            continue
                        text = b.get("thinking") or b.get("text") or ""
                        sig = b.get("signature")
                        if not text and sig:
                            return True
    except Exception:
        return False
    return False


def _bus_has_thought_since_last_call_start(session_id: str | None) -> bool:
    """True if a `thought` was emitted after the last `model_call_start`.

    Bus is per-session but a session runs many model calls (one per agent,
    plus scoring/refinement). Scoping to the current call prevents earlier
    agents' thoughts from suppressing the current agent's reasoning capture.
    """
    if not session_id:
        return False
    try:
        from daan.core.observers.reasoning_observer import get_bus
    except Exception:
        return False
    bus = get_bus(session_id)
    if bus is None:
        return False
    for event in reversed(bus._events):
        etype = event.get("type")
        if etype == "model_call_start":
            return False
        if etype == "thought":
            return True
    return False


def _emit_thought(session_id: str | None, text: str) -> None:
    """Push a streamed reasoning delta onto the session's bus as a `thought`."""
    if not session_id or not text:
        return
    try:
        from daan.core.observers.reasoning_observer import get_bus
    except Exception:
        return
    bus = get_bus(session_id)
    if bus is None:
        return
    try:
        bus.emit("thought", {"text": text, "token_count": max(1, len(text) // 4)})
    except Exception as exc:
        logger.debug("bus.emit thought failed: %s", exc)


def _emit_thinking_indicator(session_id: str | None) -> None:
    """Emit a visible placeholder when the response has signature-only thinking blocks."""
    if not session_id:
        return
    try:
        from daan.core.observers.reasoning_observer import get_bus
    except Exception:
        return
    bus = get_bus(session_id)
    if bus is None:
        return
    try:
        bus.emit("thought", {
            "text": "[reasoning captured but redacted by proxy — check LiteLLM proxy passthrough]",
            "token_count": 0,
        })
    except Exception as exc:
        logger.debug("bus.emit indicator failed: %s", exc)


def _is_final_model_response(response_obj: Any) -> bool:
    """True if the response is a terminal text answer (not an intermediate tool_use turn).

    Tool-using agents make multiple LLM calls per user turn; only the final
    (text-only) response is worth marking as "model response received".
    """
    try:
        choices = getattr(response_obj, "choices", None) or []
        if not choices:
            return True
        c0 = choices[0]
        finish = getattr(c0, "finish_reason", None)
        if finish in ("tool_calls", "tool_use", "function_call"):
            return False
        msg = getattr(c0, "message", None)
        if msg is not None:
            tc = getattr(msg, "tool_calls", None)
            if tc:
                return False
            fc = getattr(msg, "function_call", None)
            if fc:
                return False
    except Exception:
        return True
    return True


# ── CustomLogger implementation ────────────────────────────────────────────


class ThinkingCaptureLogger(CustomLogger):
    """LiteLLM CustomLogger for reasoning capture.

    Design: LiteLLM 1.93 in proxy mode doesn't invoke `log_stream_event` per
    chunk, so the streaming hooks are effectively no-ops today (kept in place
    for future SDK versions that do fire them). The success hook is authoritative:
    it extracts the aggregated reasoning from the final response and emits a
    single `thought` event, followed by `model_call_end`. Redacted-thinking
    responses (signature-only blocks) surface as a visible indicator instead.
    """

    def log_stream_event(  # type: ignore[override]
        self, kwargs: Any, response_obj: Any, start_time: Any, end_time: Any
    ) -> None:
        try:
            reasoning = _reasoning_from_stream_chunk(response_obj)
            if reasoning:
                _emit_thought(_session_id_from_kwargs(kwargs), reasoning)
        except Exception as exc:
            logger.debug("thought sync stream hook failed: %s", exc)

    async def async_log_stream_event(  # type: ignore[override]
        self, kwargs: Any, response_obj: Any, start_time: Any, end_time: Any
    ) -> None:
        try:
            reasoning = _reasoning_from_stream_chunk(response_obj)
            if reasoning:
                _emit_thought(_session_id_from_kwargs(kwargs), reasoning)
        except Exception as exc:
            logger.debug("thought async stream hook failed: %s", exc)

    def log_success_event(  # type: ignore[override]
        self, kwargs: Any, response_obj: Any, start_time: Any, end_time: Any
    ) -> None:
        try:
            sid = _session_id_from_kwargs(kwargs)
            if not _bus_has_thought_since_last_call_start(sid):
                reasoning = _reasoning_from_final_response(response_obj)
                if reasoning:
                    _emit_thought(sid, reasoning)
                elif _thinking_happened_but_redacted(response_obj):
                    _emit_thinking_indicator(sid)
            if _is_final_model_response(response_obj):
                _emit_model_call_end(sid)
        except Exception as exc:
            logger.debug("success sync hook failed: %s", exc)

    async def async_log_success_event(  # type: ignore[override]
        self, kwargs: Any, response_obj: Any, start_time: Any, end_time: Any
    ) -> None:
        try:
            sid = _session_id_from_kwargs(kwargs)
            if not _bus_has_thought_since_last_call_start(sid):
                reasoning = _reasoning_from_final_response(response_obj)
                if reasoning:
                    _emit_thought(sid, reasoning)
                elif _thinking_happened_but_redacted(response_obj):
                    _emit_thinking_indicator(sid)
            if _is_final_model_response(response_obj):
                _emit_model_call_end(sid)
        except Exception as exc:
            logger.debug("success async hook failed: %s", exc)


# ── One-time registration ──────────────────────────────────────────────────

_SINGLETON: ThinkingCaptureLogger | None = None


def register_once() -> None:
    """Attach the logger to ``litellm.callbacks`` exactly once."""
    global _SINGLETON
    if _SINGLETON is not None:
        return
    _SINGLETON = ThinkingCaptureLogger()
    try:
        callbacks = getattr(litellm, "callbacks", None)
        if callbacks is None:
            litellm.callbacks = [_SINGLETON]
        elif isinstance(callbacks, list):
            if not any(isinstance(cb, ThinkingCaptureLogger) for cb in callbacks):
                callbacks.append(_SINGLETON)
        logger.info("🧠 ThinkingCaptureLogger registered on litellm.callbacks")
    except Exception as exc:
        logger.warning("ThinkingCaptureLogger registration failed: %s", exc)


# Register at import time so it's live before the first LLM call.
register_once()
