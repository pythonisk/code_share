"""
Model-aware reasoning parameter routing for LiteLLM calls.

Different providers expose different "extended thinking / reasoning" APIs:

    anthropic_extended   Claude Opus/Sonnet/Haiku
                         -> thinking={"type": "enabled|adaptive", ...}
    openai_reasoning     OpenAI o-series (o1, o3, o4-mini) and GPT-5 reasoning
                         -> reasoning_effort="low|medium|high"
    gemini_thinking      Gemini 2.5 Pro/Flash "thinking"
                         -> reasoning_effort="low|medium|high"
                            (LiteLLM maps to thinkingConfig.thinkingBudget)
    none                 Everything else (azure/gpt-4o, gpt-4o-mini,
                         gemini-1.5-*): reasoning is silently a no-op.

Callers set the profile in llm_config.yml (per model / per component). This
module returns the correct kwargs shape for that profile, without ever guessing
from a model id (gateway ids in this project are opaque hashes).
"""

from __future__ import annotations

import logging
import re
from typing import Any, Callable, Dict, Iterable

logger = logging.getLogger(__name__)

# Keys we treat as reasoning-related when stripping on retry.
_REASONING_KEYS: tuple[str, ...] = (
    "thinking",
    "reasoning",
    "reasoning_effort",
    "output_config",
)

_VALID_PROFILES: frozenset[str] = frozenset(
    {"anthropic_extended", "openai_reasoning", "gemini_thinking", "none"}
)


# Ordered (regex, profile) rules. First match wins. Patterns are matched case-
# insensitively against the model name after stripping known route prefixes
# (litellm_proxy/, azure/, openai/, anthropic/, gemini/, vertex_ai/).
_INFERENCE_RULES: tuple[tuple[re.Pattern[str], str], ...] = (
    # OpenAI reasoning series: o1, o3, o4, gpt-5-* reasoning models.
    (re.compile(r"^(?:o[134])(?:[-_].*)?$"), "openai_reasoning"),
    (re.compile(r"^gpt-5(?:[-_].*)?$"), "openai_reasoning"),
    # Anthropic Claude — every Claude generation supports extended thinking
    # today. The mode picker inside the helper (haiku vs opus/sonnet) handles
    # the sub-shape.
    (re.compile(r"^claude(?:[-_].*)?$"), "anthropic_extended"),
    # Gemini 2.5+ thinking. 1.5 and older do NOT support it.
    (re.compile(r"^gemini-(?:2\.5|3(?:\.\d+)?)(?:[-_].*)?$"), "gemini_thinking"),
    # Known non-reasoning families — force "none" so `thinking` is never sent.
    (re.compile(r"^gpt-4o(?:[-_].*)?$"), "none"),
    (re.compile(r"^gpt-4(?:[-_].*)?$"), "none"),
    (re.compile(r"^gpt-3(?:\.\d+)?(?:[-_].*)?$"), "none"),
    (re.compile(r"^gemini-1\.\d+(?:[-_].*)?$"), "none"),
    (re.compile(r"^gemini-pro(?:[-_].*)?$"), "none"),
    (re.compile(r"^text-.*$"), "none"),
    (re.compile(r"^chat-bison(?:[-_].*)?$"), "none"),
    (re.compile(r"^mistral(?:[-_].*)?$"), "none"),
    (re.compile(r"^mixtral(?:[-_].*)?$"), "none"),
    (re.compile(r"^llama-?[23](?:[-_].*)?$"), "none"),
)

_ROUTE_PREFIXES: tuple[str, ...] = (
    "litellm_proxy/",
    "azure/",
    "openai/",
    "anthropic/",
    "gemini/",
    "vertex_ai/",
    "bedrock/",
    "groq/",
)


def infer_reasoning_profile(model_name: str) -> str | None:
    """Guess the reasoning capability profile from a model id.

    Returns one of the profile strings or ``None`` if the id doesn't match a
    known family (in which case callers fall through to the configured
    profile — this is the right behaviour for opaque LiteLLM gateway hashes).
    """
    name = str(model_name or "").strip().lower()
    if not name:
        return None
    for prefix in _ROUTE_PREFIXES:
        if name.startswith(prefix):
            name = name[len(prefix):]
            break
    for pattern, profile in _INFERENCE_RULES:
        if pattern.match(name):
            return profile
    return None


def resolve_reasoning_profile(
    explicit_profile: str | None,
    model_name: str,
    config_profile: str | None,
    default_profile: str = "none",
) -> str:
    """Pick the effective profile from explicit -> name inference -> config -> default.

    Any recognizable model name (e.g. ``azure/gpt-4o``) overrides a config
    default like ``anthropic_extended`` — so a UI-selected non-reasoning model
    never receives a ``thinking`` param, regardless of what the LiteLLM gateway
    block declares.
    """
    explicit = (explicit_profile or "").strip().lower()
    if explicit in _VALID_PROFILES:
        return explicit
    inferred = infer_reasoning_profile(model_name)
    if inferred:
        return inferred
    cfg_profile = (config_profile or "").strip().lower()
    if cfg_profile in _VALID_PROFILES:
        return cfg_profile
    return default_profile


def _resolve_thinking_mode(config_mode: str, model_name: str) -> str:
    """Pick the Anthropic thinking API shape the target Claude model accepts.

    Haiku 4.5 / older explicit-budget models require type=enabled with
    budget_tokens; Sonnet 5 / Opus 5 / late-4.x prefer type=adaptive.
    """
    name = (model_name or "").lower()
    if "haiku" in name:
        return "enabled"
    if any(
        m in name
        for m in ("opus-5", "opus5", "sonnet-5", "sonnet5",
                  "opus-4-6", "opus-4-7", "sonnet-4-6")
    ):
        return "adaptive"
    return (config_mode or "adaptive").lower()


def build_reasoning_kwargs(
    profile: str | None,
    cfg: Dict[str, Any] | None,
    model_name: str = "",
) -> Dict[str, Any]:
    """Return the LiteLLM kwargs that turn on reasoning for ``profile``.

    Args:
        profile: Capability profile of the target model. Values in
            _VALID_PROFILES; unknown values fall through to "none".
        cfg: The reasoning config block ({"enabled", "mode", "effort",
            "budget_tokens"}). If ``enabled`` is falsy the function returns {}.
        model_name: Used only by ``anthropic_extended`` to pick between the
            adaptive and enabled sub-modes.

    Returns:
        A dict to merge into the model_kwargs / request_kwargs dict passed to
        LiteLLM (or ADK's LiteLlm wrapper). Empty dict means "add nothing".
    """
    cfg = cfg or {}
    if not bool(cfg.get("enabled")):
        return {}

    p = (profile or "").strip().lower()
    if p not in _VALID_PROFILES:
        p = "none"

    if p == "none":
        # Explicit no-op; caller can log at DEBUG.
        return {}

    effort = str(cfg.get("effort") or "high").lower()
    if effort not in {"low", "medium", "high"}:
        effort = "high"

    if p in {"openai_reasoning", "gemini_thinking"}:
        logger.info(
            "🧠 reasoning kwargs profile=%s effort=%s model=%s",
            p, effort, model_name,
        )
        return {"reasoning_effort": effort}

    # anthropic_extended
    mode = _resolve_thinking_mode(str(cfg.get("mode") or "adaptive"), model_name)
    budget = int(cfg.get("budget_tokens") or 4000)
    out: Dict[str, Any] = {
        # Anthropic extended thinking requires temperature=1.
        "temperature": 1.0,
    }
    if mode == "adaptive":
        out["thinking"] = {"type": "adaptive"}
        out["output_config"] = {"effort": effort}
        out["_min_max_tokens"] = 8192
        logger.info(
            "🧠 reasoning kwargs profile=anthropic_extended mode=adaptive effort=%s model=%s",
            effort, model_name,
        )
    else:
        out["thinking"] = {"type": "enabled", "budget_tokens": budget}
        out["_min_max_tokens"] = budget + 4096
        logger.info(
            "🧠 reasoning kwargs profile=anthropic_extended mode=enabled budget=%d model=%s",
            budget, model_name,
        )
    return out


def apply_reasoning_to_model_kwargs(
    model_kwargs: Dict[str, Any],
    profile: str | None,
    cfg: Dict[str, Any] | None,
    model_name: str = "",
) -> Dict[str, Any]:
    """Merge reasoning kwargs into an existing ``model_kwargs`` dict in place.

    Handles the ``_min_max_tokens`` sentinel used by the Anthropic path so a
    caller's ``max_tokens`` is bumped only if it's below what the profile
    requires. Returns the same ``model_kwargs`` for convenience.
    """
    extra = build_reasoning_kwargs(profile, cfg, model_name)
    min_max = int(extra.pop("_min_max_tokens", 0) or 0)
    if min_max > 0:
        try:
            current = int(model_kwargs.get("max_tokens") or 0)
        except (TypeError, ValueError):
            current = 0
        if current < min_max:
            model_kwargs["max_tokens"] = min_max
    model_kwargs.update(extra)
    return model_kwargs


def strip_reasoning_kwargs(kwargs: Dict[str, Any]) -> list[str]:
    """Remove any reasoning-related keys from ``kwargs`` in place.

    Returns the list of keys that were actually removed (empty if none).
    """
    removed: list[str] = []
    for k in _REASONING_KEYS:
        if k in kwargs:
            kwargs.pop(k, None)
            removed.append(k)
    # extra_body.thinking is another place LiteLLM accepts the param.
    extra_body = kwargs.get("extra_body")
    if isinstance(extra_body, dict):
        for k in ("thinking", "reasoning", "reasoning_effort", "output_config"):
            if k in extra_body:
                extra_body.pop(k, None)
                removed.append(f"extra_body.{k}")
    return removed


def call_with_reasoning_fallback(
    fn: Callable[..., Any],
    /,
    *,
    kwargs: Dict[str, Any],
    model_label: str = "",
    is_retryable: Iterable[type[BaseException]] | None = None,
) -> Any:
    """Invoke ``fn(**kwargs)``; on UnsupportedParamsError retry once without reasoning.

    Args:
        fn: Callable to invoke (e.g. ``litellm.completion``).
        kwargs: Keyword arguments for ``fn``. Mutated on retry to drop reasoning
            keys so the second attempt is byte-identical minus those keys.
        model_label: Human-readable model id used only for log messages.
        is_retryable: Optional extra exception types to treat like
            ``UnsupportedParamsError`` (some LiteLLM versions raise
            ``BadRequestError`` for the same case).
    """
    try:
        return fn(**kwargs)
    except Exception as exc:  # noqa: BLE001
        # Detect UnsupportedParamsError without a hard import (LiteLLM's module
        # layout has moved between versions).
        exc_name = exc.__class__.__name__
        msg = str(exc)
        is_unsupported = (
            exc_name == "UnsupportedParamsError"
            or ("does not support parameters" in msg and "thinking" in msg.lower())
            or ("does not support parameters" in msg and "reasoning" in msg.lower())
        )
        if is_retryable:
            is_unsupported = is_unsupported or isinstance(exc, tuple(is_retryable))
        if not is_unsupported:
            raise
        removed = strip_reasoning_kwargs(kwargs)
        if not removed:
            raise
        logger.warning(
            "LiteLLM %s rejected reasoning params %s; retrying without them (model=%s)",
            exc_name, removed, model_label or kwargs.get("model", "?"),
        )
        return fn(**kwargs)


def install_litellm_safety_flags() -> bool:
    """Set ``litellm.drop_params=True`` and ``modify_params=True`` if litellm is importable.

    This is the belt-and-suspenders safety net: any reasoning-related param
    that slips past provider-level routing gets silently dropped by LiteLLM
    instead of raising UnsupportedParamsError.

    Returns True on success, False if litellm isn't importable yet.
    """
    try:
        import litellm  # noqa: WPS433 - deliberate deferred import
    except Exception:  # noqa: BLE001
        logger.debug("litellm not importable at startup; safety flags skipped")
        return False
    try:
        litellm.drop_params = True
        litellm.modify_params = True
        logger.info("🛡️ litellm safety flags set: drop_params=True modify_params=True")
        return True
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not set litellm safety flags: %s", exc)
        return False
