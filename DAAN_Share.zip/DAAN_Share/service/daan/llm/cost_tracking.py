"""Utilities for LLM token accounting and cost estimation."""

from __future__ import annotations
import os
from datetime import datetime
from typing import Any

import litellm

from daan.llm.llm_provider import get_default_provider_name, load_llm_config
from daan.llm.litellm_response import provider_name_from_model


def _to_int(value: Any, default: int = 0) -> int:
    try:
        if value is None:
            return default
        return int(value)
    except Exception:
        return default


def _provider_models() -> dict[str, str]:
    """Best-effort provider -> model map.

    LiteLLM is the single source of truth, so runtime metadata (served_by / event
    usage) is the primary source for model attribution. This map only provides
    config-level defaults used when runtime metadata is unavailable.
    """
    cfg = load_llm_config() or {}
    out: dict[str, str] = {}

    # Primary LiteLLM gateway model.
    lite = cfg.get("litellm") or {}
    if lite:
        default_model = str(
            os.getenv(str(lite.get("default_model_env") or ""), "")
            or lite.get("default_model")
            or ""
        ).strip()
        if default_model:
            out["litellm"] = default_model

    # Fallback provider model (env-driven), best-effort.
    fb = cfg.get("fallback") or {}
    if fb and bool(fb.get("enabled", False)):
        provider = str(fb.get("provider") or "azure_openai").strip()
        model = str(os.getenv(str(fb.get("model_env") or ""), "") or "").strip()
        if provider and model:
            out.setdefault(provider, model)

    # Legacy providers dict (pre-LiteLLM-only schema).
    providers = cfg.get("providers", {}) or {}
    for name, data in providers.items():
        if isinstance(data, dict):
            model = str(data.get("model") or "").strip()
            if model:
                out.setdefault(str(name).strip(), model)

    return out


def resolve_provider_and_model(provider_name: str | None = None) -> tuple[str, str]:
    """Resolve provider/model from config with defaults."""
    models = _provider_models()
    provider = (provider_name or "").strip() or get_default_provider_name()
    model = models.get(provider) or ""
    return provider, model


def resolve_agent_provider_and_model(agent_cfg: dict[str, Any] | None) -> tuple[str, str]:
    """Resolve provider/model for one agent config."""
    if not isinstance(agent_cfg, dict):
        return resolve_provider_and_model(None)

    provider = str(
        agent_cfg.get("provider")
        or agent_cfg.get("llm_provider")
        or agent_cfg.get("model_provider")
        or ""
    ).strip()

    provider_resolved, default_model = resolve_provider_and_model(provider or None)
    model = str(agent_cfg.get("model") or "").strip() or default_model
    return provider_resolved, model


def _string_or_empty(value: Any) -> str:
    text = str(value or "").strip()
    return text


def _usage_dicts_from_candidate(obj: Any) -> list[dict[str, Any]]:
    usage_dicts: list[dict[str, Any]] = []

    if obj is None:
        return usage_dicts

    if isinstance(obj, dict):
        usage_dicts.append(obj)
        for key in ("usage", "usage_metadata", "token_usage", "model_usage"):
            nested = obj.get(key)
            if isinstance(nested, dict):
                usage_dicts.append(nested)
        return usage_dicts

    candidate = {
        "prompt_tokens": getattr(obj, "prompt_tokens", None),
        "completion_tokens": getattr(obj, "completion_tokens", None),
        "total_tokens": getattr(obj, "total_tokens", None),
        "input_tokens": getattr(obj, "input_tokens", None),
        "output_tokens": getattr(obj, "output_tokens", None),
        "prompt_token_count": getattr(obj, "prompt_token_count", None),
        "candidates_token_count": getattr(obj, "candidates_token_count", None),
        "total_token_count": getattr(obj, "total_token_count", None),
    }
    usage_dicts.append(candidate)

    for key in ("usage", "usage_metadata", "token_usage", "model_usage"):
        nested = getattr(obj, key, None)
        if nested is None:
            continue
        if isinstance(nested, dict):
            usage_dicts.append(nested)
            continue
        try:
            payload = getattr(nested, "model_dump", None)
            if callable(payload):
                dumped = payload()
                if isinstance(dumped, dict):
                    usage_dicts.append(dumped)
                    continue
        except Exception:
            pass
        usage_dicts.append({
            "prompt_tokens": getattr(nested, "prompt_tokens", None),
            "completion_tokens": getattr(nested, "completion_tokens", None),
            "total_tokens": getattr(nested, "total_tokens", None),
            "input_tokens": getattr(nested, "input_tokens", None),
            "output_tokens": getattr(nested, "output_tokens", None),
            "prompt_token_count": getattr(nested, "prompt_token_count", None),
            "candidates_token_count": getattr(nested, "candidates_token_count", None),
            "total_token_count": getattr(nested, "total_token_count", None),
        })

    return usage_dicts


def extract_model_provider_from_event(event: Any) -> tuple[str, str]:
    """Best-effort runtime model/provider extraction from ADK/litellm events."""
    candidates: list[Any] = []

    if event is not None:
        candidates.append(event)

    for key in ("usage_metadata", "model_usage", "usage", "token_usage"):
        candidates.append(getattr(event, key, None))

    try:
        payload = getattr(event, "model_dump", None)
        if callable(payload):
            candidates.append(payload())
    except Exception:
        pass

    for obj in candidates:
        if obj is None:
            continue

        if isinstance(obj, dict):
            model = _string_or_empty(
                obj.get("model")
                or obj.get("model_name")
                or obj.get("served_by")
                or obj.get("model_version")
            )
            provider = _string_or_empty(
                obj.get("provider")
                or obj.get("provider_name")
                or obj.get("requested_provider")
            )

            nested_usage = obj.get("usage_metadata")
            if isinstance(nested_usage, dict):
                model = model or _string_or_empty(
                    nested_usage.get("model") or nested_usage.get("model_name")
                )
                provider = provider or _string_or_empty(
                    nested_usage.get("provider") or nested_usage.get("provider_name")
                )

            nested_model_usage = obj.get("model_usage")
            if isinstance(nested_model_usage, dict):
                model = model or _string_or_empty(
                    nested_model_usage.get("model") or nested_model_usage.get("model_name")
                )
                provider = provider or _string_or_empty(
                    nested_model_usage.get("provider") or nested_model_usage.get("provider_name")
                )
        else:
            model = _string_or_empty(
                getattr(obj, "model", None)
                or getattr(obj, "model_name", None)
                or getattr(obj, "served_by", None)
                or getattr(obj, "model_version", None)
            )
            provider = _string_or_empty(
                getattr(obj, "provider", None)
                or getattr(obj, "provider_name", None)
                or getattr(obj, "requested_provider", None)
            )

            usage_metadata = getattr(obj, "usage_metadata", None)
            if usage_metadata is not None:
                model = model or _string_or_empty(
                    getattr(usage_metadata, "model", None)
                    or getattr(usage_metadata, "model_name", None)
                )
                provider = provider or _string_or_empty(
                    getattr(usage_metadata, "provider", None)
                    or getattr(usage_metadata, "provider_name", None)
                )

            model_usage = getattr(obj, "model_usage", None)
            if model_usage is not None:
                model = model or _string_or_empty(
                    getattr(model_usage, "model", None)
                    or getattr(model_usage, "model_name", None)
                )
                provider = provider or _string_or_empty(
                    getattr(model_usage, "provider", None)
                    or getattr(model_usage, "provider_name", None)
                )

        if model and not provider:
            provider = provider_name_from_model(model, get_default_provider_name())

        if model or provider:
            return model, provider

    return "", ""


def extract_usage_from_event(event: Any) -> dict[str, int]:
    """Best-effort token extraction from ADK/litellm event metadata."""
    candidates: list[Any] = []

    if isinstance(event, dict):
        candidates.append(event)

    for key in ("usage", "usage_metadata", "token_usage", "model_usage"):
        candidates.append(getattr(event, key, None))

    try:
        payload = getattr(event, "model_dump", None)
        if callable(payload):
            candidates.append(payload())
    except Exception:
        pass

    prompt_tokens = 0
    completion_tokens = 0
    total_tokens = 0

    for obj in candidates:
        for usage_dict in _usage_dicts_from_candidate(obj):
            direct = usage_dict.get("usage")
            if isinstance(direct, dict):
                usage_dict = {**usage_dict, **direct}

            p = _to_int(usage_dict.get("prompt_tokens"), 0)
            if p == 0:
                p = _to_int(usage_dict.get("input_tokens"), 0)
            if p == 0:
                p = _to_int(usage_dict.get("prompt_token_count"), 0)

            c = _to_int(usage_dict.get("completion_tokens"), 0)
            if c == 0:
                c = _to_int(usage_dict.get("output_tokens"), 0)
            if c == 0:
                c = _to_int(usage_dict.get("candidates_token_count"), 0)

            t = _to_int(usage_dict.get("total_tokens"), 0)
            if t == 0:
                t = _to_int(usage_dict.get("total_token_count"), 0)
            if t == 0:
                t = p + c

            if p or c or t:
                prompt_tokens += p
                completion_tokens += c
                total_tokens += t

    if total_tokens == 0:
        total_tokens = prompt_tokens + completion_tokens

    return {
        "prompt_tokens": max(prompt_tokens, 0),
        "completion_tokens": max(completion_tokens, 0),
        "total_tokens": max(total_tokens, 0),
    }


def estimate_tokens(model: str, prompt: str, completion: str) -> dict[str, int]:
    """Estimate prompt/completion tokens when API usage metadata is unavailable."""
    model_name = (model or "").strip() or "gpt-4"
    p = 0
    c = 0

    try:
        p = int(litellm.token_counter(model=model_name, messages=[{"role": "user", "content": prompt or ""}]))
    except Exception:
        try:
            p = len(litellm.encode(model=model_name, text=prompt or ""))
        except Exception:
            p = max(len(prompt or "") // 4, 0)

    try:
        c = int(litellm.token_counter(model=model_name, messages=[{"role": "assistant", "content": completion or ""}]))
    except Exception:
        try:
            c = len(litellm.encode(model=model_name, text=completion or ""))
        except Exception:
            c = max(len(completion or "") // 4, 0)

    return {
        "prompt_tokens": max(p, 0),
        "completion_tokens": max(c, 0),
        "total_tokens": max(p + c, 0),
    }


def _pricing_model_name(model: str) -> str:
    """Normalize a model id for LiteLLM pricing lookup.

    The gateway stores models like ``litellm_proxy/azure/gpt-4o``; LiteLLM's
    pricing map only knows the underlying id (``azure/gpt-4o``), so the proxy
    prefix must be stripped or ``cost_per_token`` raises and cost becomes 0.
    """
    name = (model or "").strip()
    if name.startswith("litellm_proxy/"):
        name = name[len("litellm_proxy/"):]
    return name or "gpt-4"


def compute_cost_usd(model: str, prompt_tokens: int, completion_tokens: int) -> tuple[float | None, bool]:
    """Compute USD cost from token counts; returns (cost, used_fallback_pricing)."""
    model_name = _pricing_model_name(model)
    p = max(_to_int(prompt_tokens, 0), 0)
    c = max(_to_int(completion_tokens, 0), 0)

    try:
        prompt_cost, completion_cost = litellm.cost_per_token(
            model=model_name,
            prompt_tokens=p,
            completion_tokens=c,
        )
        return float(prompt_cost) + float(completion_cost), False
    except Exception:
        return None, True


def compute_cost_split_usd(model: str, prompt_tokens: int, completion_tokens: int) -> tuple[float, float]:
    """Compute the input (prompt) and output (completion) USD cost separately."""
    model_name = _pricing_model_name(model)
    p = max(_to_int(prompt_tokens, 0), 0)
    c = max(_to_int(completion_tokens, 0), 0)

    try:
        prompt_cost, completion_cost = litellm.cost_per_token(
            model=model_name,
            prompt_tokens=p,
            completion_tokens=c,
        )
        return float(prompt_cost), float(completion_cost)
    except Exception:
        return 0.0, 0.0


def build_cost_record(
    *,
    agent_id: str,
    run_type: str,
    provider: str,
    model: str,
    prompt_tokens: int,
    completion_tokens: int,
    cost_usd: float | None,
    estimated_tokens: bool = False,
    estimated_cost: float | None = None,
) -> dict[str, Any]:
    total_tokens = max(_to_int(prompt_tokens, 0), 0) + max(_to_int(completion_tokens, 0), 0)
    return {
        "agent_id": agent_id,
        "run_type": run_type,
        "provider": provider,
        "model": model,
        "prompt_tokens": max(_to_int(prompt_tokens, 0), 0),
        "completion_tokens": max(_to_int(completion_tokens, 0), 0),
        "total_tokens": total_tokens,
        "estimated_tokens": bool(estimated_tokens),
        "cost_usd": float(cost_usd) if cost_usd is not None else None,
        "estimated_cost": float(estimated_cost) if estimated_cost is not None else None,
        "created_at": datetime.utcnow().isoformat(),
    }


def record_llm_sidecall_cost(
    *,
    session: Any,
    agent_id: str,
    run_type: str,
    agent_cfg: dict[str, Any] | None,
    llm_prompt: str,
    llm_response: str,
    usage_metadata: Any | None = None,
    provider_name: str | None = None,
    model_name: str | None = None,
) -> dict[str, Any]:
    """Record a non-ADK LLM call (scoring/schema/etc.) into session token/cost totals.

    Existing agent execution paths record usage from ADK events.
    For plain provider calls (get_llm_response_with_fallback), usage metadata
    is not available, so we estimate tokens.

    Returns the cost record dict.
    """
    provider, model = resolve_agent_provider_and_model(agent_cfg)
    if provider_name:
        provider = str(provider_name).strip() or provider
    if model_name:
        model = str(model_name).strip() or model

    usage = extract_usage_from_event(usage_metadata)
    if not bool(usage.get("prompt_tokens") or usage.get("completion_tokens") or usage.get("total_tokens")):
        usage = estimate_tokens(model=model, prompt=llm_prompt or "", completion=llm_response or "")

    prompt_tokens = int(usage.get("prompt_tokens") or 0)
    completion_tokens = int(usage.get("completion_tokens") or 0)

    cost_usd = compute_cost_usd(
        model=model,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
    )[0]

    rec = build_cost_record(
        agent_id=(agent_id or "unknown_agent"),
        run_type=run_type,
        provider=provider,
        model=model,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        cost_usd=cost_usd,
    )

    if session is not None and hasattr(session, "record_agent_cost"):
        session.record_agent_cost((agent_id or "unknown_agent"), rec)

    return rec
