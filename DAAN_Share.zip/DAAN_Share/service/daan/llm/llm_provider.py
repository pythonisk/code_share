"""
LLM Provider Module

LiteLLM is the SINGLE SOURCE OF TRUTH for chat models. Models are defined and
managed in the LiteLLM Admin UI, not in llm_config.yml. This module resolves the
LiteLLM gateway connection and an optional failure-only fallback provider, and
builds Google ADK model objects / completions on top of them.
"""

import logging
import os
import yaml
from pathlib import Path
from typing import Dict, Any, Tuple, Optional

from dotenv import dotenv_values

from daan.llm.litellm_response import normalize_completion_response
from daan.llm.providers.provider_factory import ProviderFactory

logger = logging.getLogger(__name__)

# Canonical provider name for the primary LiteLLM gateway path.
LITELLM_PROVIDER_NAME = "litellm"


class LLMProviderError(Exception):
    """Custom exception for LLM provider errors."""
    pass


def load_llm_config() -> Dict[str, Any]:
    """Load LLM configuration from llm_config.yml (project root config/)."""
    # Find project root (4 levels up from this file)
    project_root = Path(__file__).resolve().parents[3]
    config_path = project_root / "config" / "llm_config.yml"
    if not config_path.exists():
        raise LLMProviderError(f"LLM config file not found: {config_path}")
    with open(config_path, 'r') as f:
        return yaml.safe_load(f) or {}


def _load_project_env_values() -> Dict[str, str]:
    """Read config/.env without requiring another module to call load_dotenv first."""
    project_root = Path(__file__).resolve().parents[3]
    env_path = project_root / "config" / ".env"
    raw_values = dotenv_values(env_path) if env_path.exists() else {}
    return {
        str(key): str(value)
        for key, value in (raw_values or {}).items()
        if key and value not in (None, "")
    }


def _env_or_value(env_key: str, direct_value: Any, *fallback_env_keys: str) -> str:
    """Return the first configured env value, then the direct value."""
    env_values = _load_project_env_values()
    for candidate in [env_key, *fallback_env_keys]:
        normalized_key = str(candidate or "").strip()
        if not normalized_key:
            continue
        env_val = os.getenv(normalized_key, "") or env_values.get(normalized_key, "")
        if env_val:
            return str(env_val)
    return str(direct_value or "")


def get_litellm_settings() -> Dict[str, Any]:
    """Resolve LiteLLM gateway settings from config/llm_config.yml (with env overrides)."""
    config = load_llm_config()
    lite = config.get("litellm") or {}

    url = _env_or_value(lite.get("url_env", ""), lite.get("url"), "LITELLM_URL").strip()
    if not url:
        url = os.getenv("LITELLM_URL", "").strip()
    if not url:
        raise LLMProviderError(
            "LiteLLM gateway URL not configured. Set 'litellm.url' (or the "
            "LITELLM_URL env var) in config/llm_config.yml."
        )

    api_key = _env_or_value(
        lite.get("api_key_env", "LITELLM_API_KEY"), lite.get("api_key")
        , "LITELLM_PROXY_API_KEY", "LITELLM_PROXY_ADMIN_KEY", "LITELLM_API_KEY"
    ).strip()
    default_model = _env_or_value(
        lite.get("default_model_env", ""), lite.get("default_model")
    ).strip() or "gpt-4o"

    reasoning_raw = lite.get("reasoning") or {}
    reasoning = {
        "enabled": bool(reasoning_raw.get("enabled", False)),
        "mode": str(reasoning_raw.get("mode", "adaptive") or "adaptive").lower(),
        "effort": str(reasoning_raw.get("effort", "high") or "high").lower(),
        "budget_tokens": int(reasoning_raw.get("budget_tokens", 4000) or 4000),
    }
    # Config-declared profile is kept OUTSIDE the reasoning dict on purpose:
    # storing it inside would look like an "explicit" caller override and would
    # short-circuit the provider's model-name inference (e.g. an ``azure/gpt-4o``
    # id would never get downgraded to ``none``). Providers read this via
    # ``self.config.get("reasoning_profile")`` as the last-resort fallback.
    reasoning_profile = str(
        reasoning_raw.get("profile")
        or lite.get("reasoning_profile")
        or "anthropic_extended"
    ).lower()

    max_tokens_raw = lite.get("max_tokens") or lite.get("max_output_tokens")
    try:
        max_tokens = int(max_tokens_raw) if max_tokens_raw else None
    except (TypeError, ValueError):
        max_tokens = None

    return {
        "url": url,
        "api_key": api_key or None,
        "default_model": default_model,
        "reasoning": reasoning,
        "reasoning_profile": reasoning_profile,
        "max_tokens": max_tokens,
    }

_LITELLM_MODEL_CACHE: Dict[str, Any] = {"ts": 0.0, "data": []}
_LITELLM_MODEL_CACHE_TTL_SEC = 60


def list_litellm_models(force_refresh: bool = False) -> list[Dict[str, Any]]:
    """Return the models registered in the LiteLLM gateway via /model/info.

    Result items are normalized to {id, model_name, provider, mode}. Results are
    cached in-process for ``_LITELLM_MODEL_CACHE_TTL_SEC`` seconds to avoid
    hammering the gateway from UI dropdown loads.
    """
    import time
    import httpx

    now = time.time()
    if (
        not force_refresh
        and _LITELLM_MODEL_CACHE["data"]
        and (now - float(_LITELLM_MODEL_CACHE["ts"])) < _LITELLM_MODEL_CACHE_TTL_SEC
    ):
        return list(_LITELLM_MODEL_CACHE["data"])

    settings = get_litellm_settings()
    url = str(settings.get("url") or "").rstrip("/")
    api_key = settings.get("api_key")
    if not url:
        raise LLMProviderError("LiteLLM gateway URL not configured.")

    headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
    try:
        with httpx.Client(timeout=15.0) as client:
            resp = client.get(f"{url}/model/info", headers=headers)
            resp.raise_for_status()
            payload = resp.json() or {}
    except Exception as exc:
        raise LLMProviderError(f"Failed to list LiteLLM models: {exc}") from exc

    out: list[Dict[str, Any]] = []
    for item in payload.get("data", []) or []:
        if not isinstance(item, dict):
            continue
        info = item.get("model_info") or {}
        lparams = item.get("litellm_params") or {}
        model_id = str(info.get("id") or "").strip()
        model_name = str(item.get("model_name") or "").strip()
        if not model_id or not model_name:
            continue
        out.append(
            {
                "id": model_id,
                "model_name": model_name,
                "provider": str(lparams.get("custom_llm_provider") or "").strip(),
                "mode": str(info.get("mode") or "chat").strip(),
            }
        )

    _LITELLM_MODEL_CACHE["data"] = out
    _LITELLM_MODEL_CACHE["ts"] = now
    return list(out)


def get_default_litellm_model_id() -> str:
    """Return the configured default LiteLLM model id."""
    return str(get_litellm_settings().get("default_model") or "").strip()

def get_core_agent_model(component: str) -> Optional[str]:
    """Return per-component LiteLLM model id from llm_config.yml (core_agents),
    or None to let the caller fall through to the LiteLLM default model.
    """
    key = str(component or "").strip()
    if not key:
        return None
    try:
        cfg = load_llm_config() or {}
    except LLMProviderError:
        return None
    entry = (cfg.get("core_agents") or {}).get(key) or {}
    if not isinstance(entry, dict):
        return None
    # `model_env` wins over `model` so ops can override without editing the yml.
    env_key = str(entry.get("model_env") or "").strip()
    if env_key:
        env_val = _env_or_value(env_key, "").strip()
        if env_val:
            return env_val
    model = str(entry.get("model") or "").strip()
    return model or None


def get_fallback_settings() -> Optional[Dict[str, Any]]:
    """Resolve the failure-only fallback settings, or None if disabled/unconfigured."""
    config = load_llm_config()
    fb = config.get("fallback") or {}
    if not fb or not bool(fb.get("enabled", False)):
        return None

    settings = fb.get("settings") or {}
    return {
        "provider": str(fb.get("provider") or "azure_openai").strip(),
        "api_key_env": fb.get("api_key_env", ""),
        "endpoint_env": fb.get("endpoint_env", ""),
        "api_version_env": fb.get("api_version_env", ""),
        "api_version": fb.get("api_version", "2024-08-01-preview"),
        "model_env": fb.get("model_env", ""),
        "num_retries": settings.get("num_retries", 2),
        "request_timeout": settings.get("request_timeout", 30),
    }


def _build_fallback_provider_config(fb: Dict[str, Any]) -> Dict[str, Any]:
    """Build an azure_openai provider config from fallback env-var settings."""
    env_values = _load_project_env_values()
    api_key = (
        os.getenv(str(fb.get("api_key_env") or ""), "")
        or env_values.get(str(fb.get("api_key_env") or ""), "")
    )
    endpoint = (
        os.getenv(str(fb.get("endpoint_env") or ""), "")
        or env_values.get(str(fb.get("endpoint_env") or ""), "")
    )
    api_version = (
        os.getenv(str(fb.get("api_version_env") or ""), "")
        or env_values.get(str(fb.get("api_version_env") or ""), "")
    ) or str(
        fb.get("api_version") or ""
    )
    deployment = (
        os.getenv(str(fb.get("model_env") or ""), "")
        or env_values.get(str(fb.get("model_env") or ""), "")
    )

    missing = []
    if not api_key:
        missing.append(fb.get("api_key_env") or "AZURE_OPENAI_API_KEY")
    if not endpoint:
        missing.append(fb.get("endpoint_env") or "AZURE_OPENAI_ENDPOINT")
    if not deployment:
        missing.append(fb.get("model_env") or "FALLBACK_MODEL")
    if missing:
        raise LLMProviderError(
            "Fallback provider misconfigured. Missing environment variables: "
            + ", ".join(str(m) for m in missing)
        )

    return {
        "api_key": api_key,
        "endpoint": endpoint,
        "api_version": api_version or "2024-08-01-preview",
        "deployment_name": deployment,
        "model": deployment,
    }


def get_default_provider_name() -> str:
    """Return the primary provider name. LiteLLM is the single source of truth."""
    config = load_llm_config()
    if config.get("litellm"):
        return LITELLM_PROVIDER_NAME
    # Legacy compatibility (pre-LiteLLM-only schema).
    legacy = str(config.get("default_provider") or config.get("provider") or "").strip()
    return legacy or LITELLM_PROVIDER_NAME


def _resolve_provider(provider_name: Optional[str]) -> Tuple[str, Dict[str, Any]]:
    """Resolve a provider name to (canonical_name, provider_config)."""
    selected = str(provider_name or "").strip() or get_default_provider_name()

    fb = get_fallback_settings()
    if fb and selected == fb["provider"]:
        return selected, _build_fallback_provider_config(fb)

    if selected == LITELLM_PROVIDER_NAME:
        return selected, get_litellm_settings()

    # Legacy providers dict (pre-LiteLLM-only schema).
    config = load_llm_config()
    providers = config.get("providers", {}) or {}
    if selected in providers:
        return selected, providers[selected]

    raise LLMProviderError(
        f"Provider '{selected}' is not configured. LiteLLM is the primary provider; "
        f"configure 'litellm' (and optionally 'fallback') in config/llm_config.yml."
    )


# Failures that should NOT trigger fallback: logical/content errors we deliberately
# raise (e.g. a caller demanded parseable JSON). Everything else from the primary
# LiteLLM gateway path is treated as a gateway failure.
def _is_litellm_transport_failure(exc: BaseException) -> bool:
    """Return True if a primary-path failure should trigger the fallback provider."""
    msg = str(exc).lower()
    if "parseable json" in msg or "json_required" in msg:
        return False
    return True


def create_completion_provider(provider_name: Optional[str] = None) -> Tuple[Any, Dict[str, Any]]:
    """Create a configured provider instance for completion-style runtime use."""
    try:
        selected_provider, provider_config = _resolve_provider(provider_name)
        provider = ProviderFactory.create_provider(selected_provider, provider_config)
        model_name = provider.setup_environment()

        return provider, {
            "provider": selected_provider,
            "model": model_name,
            "config": provider_config,
        }
    except Exception as e:
        raise LLMProviderError(f"Failed to create completion provider: {e}")


def get_llm_completion(prompt: str, provider_name: Optional[str] = None, tags: Optional[list] = None, **kwargs) -> dict[str, Any]:
    """Generate a normalized LLM completion payload using the selected provider.

    Primary path is the LiteLLM gateway. This function does NOT perform fallback;
    use get_llm_completion_with_fallback() for failure-only fallback behavior.

    Args:
        tags: Optional LiteLLM tracking tags. Attached to the gateway call so the
            request is attributable in the LiteLLM Admin UI (Logs view).
    """
    try:
        selected_provider, provider_config = _resolve_provider(provider_name)
        provider = ProviderFactory.create_provider(selected_provider, provider_config)
        model_name = provider.setup_environment()

        # Only meaningful for the LiteLLM gateway; fallback provider uses its fixed deployment.
        model_override = str(kwargs.pop("model", "") or "").strip()
        if model_override and selected_provider == LITELLM_PROVIDER_NAME:
            model_name = model_override

        # Attach LiteLLM tracking tags only on the gateway path; direct providers
        # (fallback) do not route through the proxy that records tags.
        if tags and selected_provider == LITELLM_PROVIDER_NAME:
            existing = kwargs.get("extra_body")
            extra_body = dict(existing) if isinstance(existing, dict) else {}
            metadata = dict(extra_body.get("metadata") or {})
            metadata["tags"] = list(tags)
            extra_body["metadata"] = metadata
            kwargs["extra_body"] = extra_body

        completion_fn = getattr(provider, "completion", None)
        if not callable(completion_fn):
            raise LLMProviderError(
                f"Provider '{selected_provider}' does not implement completion()."
            )

        response = completion_fn(
            prompt=prompt,
            model_name=model_name,
            return_metadata=True,
            **kwargs,
        )
        return normalize_completion_response(
            response=response,
            default_model=model_name,
            default_provider=selected_provider,
            requested_model=model_name,
            requested_provider=selected_provider,
        )
    except Exception as e:
        raise LLMProviderError(f"Failed to get LLM completion: {e}")


def get_llm_response(prompt: str, provider_name: Optional[str] = None, **kwargs) -> str:
    """Generate LLM response using selected provider (or default provider if omitted)."""
    completion = get_llm_completion(prompt=prompt, provider_name=provider_name, **kwargs)
    return str(completion.get("text") or "")


def get_llm_completion_with_fallback(prompt: str, provider_name: Optional[str] = None, **kwargs) -> dict[str, Any]:
    """Generate a normalized LLM completion payload with failure-only fallback.

    The primary path is the LiteLLM gateway (single source of truth). The fallback
    provider is used ONLY when the LiteLLM gateway path fails.
    """
    requested = str(provider_name or "").strip()
    fallback_provider = get_fallback_provider_name()

    try:
        return get_llm_completion(prompt=prompt, provider_name=provider_name, **kwargs)
    except LLMProviderError as primary_error:
        primary_is_litellm = (not requested) or requested == LITELLM_PROVIDER_NAME
        if (
            primary_is_litellm
            and fallback_provider
            and fallback_provider != LITELLM_PROVIDER_NAME
            and _is_litellm_transport_failure(primary_error)
        ):
            logger.warning(
                "LiteLLM gateway failed (%s). Falling back to provider '%s'.",
                str(primary_error)[:200],
                fallback_provider,
            )
            return get_llm_completion(
                prompt=prompt, provider_name=fallback_provider, **kwargs
            )
        raise


def get_llm_response_with_fallback(prompt: str, provider_name: Optional[str] = None, **kwargs) -> str:
    """
    Generate LLM response with automatic fallback support.

    Tries the fallback Router first (if configured). If no fallback is configured,
    falls back to the original get_llm_response() path — preserving existing behavior.

    This function is a drop-in replacement for get_llm_response() with added reliability.
    """
    completion = get_llm_completion_with_fallback(prompt=prompt, provider_name=provider_name, **kwargs)
    return str(completion.get("text") or "")


def get_fallback_provider_name() -> Optional[str]:
    """Return the fallback provider name if fallback is enabled, else None."""
    fb = get_fallback_settings()
    if fb:
        return fb["provider"]
    # Legacy compatibility.
    config = load_llm_config()
    legacy = str(config.get("fallback_provider") or "").strip()
    return legacy or None


def build_llm_tags(
    agent_name: Optional[str] = None,
    agent_type: Optional[str] = None,
    component: Optional[str] = None,
    extra: Optional[list] = None,
) -> list:
    """Build LiteLLM tracking tags for the current request context.

    Tags surface in the LiteLLM Admin UI (Logs view) so each call is attributable
    to the app, user, session, and the agent/component that issued it. Values come
    from request-scoped ContextVars, so callers only pass what they know locally.
    """
    from daan.flow.context_vars import daan_session_id, daan_user_id

    tags: list[str] = ["app:daan"]

    user_id = daan_user_id.get()
    if user_id:
        tags.append(f"user_id:{user_id}")

    session_id = daan_session_id.get()
    if session_id:
        tags.append(f"session:{session_id}")

    if component:
        tags.append(f"component:{component}")
    if agent_name:
        tags.append(f"agent:{agent_name}")
    if agent_type:
        tags.append(f"agent_type:{agent_type}")
    if extra:
        tags.extend(str(t) for t in extra if t)

    return tags


def get_core_agent_reasoning_profile(component: str) -> Optional[str]:
    """Return per-component ``reasoning_profile`` from llm_config.yml (core_agents),
    or None to let the caller fall through to the gateway default.
    """
    key = str(component or "").strip()
    if not key:
        return None
    try:
        cfg = load_llm_config() or {}
    except LLMProviderError:
        return None
    entry = (cfg.get("core_agents") or {}).get(key) or {}
    if not isinstance(entry, dict):
        return None
    profile = str(entry.get("reasoning_profile") or "").strip().lower()
    return profile or None


def create_litellm_model(
    provider_name: str,
    tags: Optional[list] = None,
    model_name: Optional[str] = None,
    reasoning: Optional[Dict[str, Any]] = None,
    component: Optional[str] = None,
) -> Tuple[Any, Dict[str, Any]]:
    """Create a Google ADK LiteLlm model object for the given provider.

    The primary provider is the LiteLLM gateway; the fallback provider name (if
    enabled) builds a direct provider model. This function is pure -- it never
    mutates config/llm_config.yml.

    Args:
        provider_name: Provider to resolve (or None for the default).
        tags: Optional LiteLLM tracking tags attached to every call made with the
            returned model. Only applied for the LiteLLM gateway provider.
        model_name: Optional per-agent model override. When provided and the
            resolved provider is the LiteLLM gateway, this overrides the
            ``default_model`` from config.
        reasoning: Optional reasoning config
            (``{"enabled", "mode", "effort", "budget_tokens", "profile"}``).
            If None, resolved from ``litellm.reasoning`` in llm_config.yml.
            Profile determines which provider param shape to emit and is
            required to keep unsupported models (e.g. azure/gpt-4o) safe.
        component: Optional core-agent component key. When set, the per-agent
            ``reasoning_profile`` in ``core_agents.<component>`` overrides the
            global gateway profile — lets a single stage force ``none`` even
            when reasoning is enabled globally.
    """
    try:
        selected_provider, provider_config = _resolve_provider(provider_name)
        provider = ProviderFactory.create_provider(selected_provider, provider_config)
        resolved_model = provider.setup_environment()
        override = str(model_name or "").strip()
        if override and selected_provider == LITELLM_PROVIDER_NAME:
            resolved_model = override

        effective_reasoning = reasoning if reasoning is not None else provider_config.get("reasoning")
        component_profile = get_core_agent_reasoning_profile(component or "")
        if component_profile:
            base = dict(effective_reasoning) if isinstance(effective_reasoning, dict) else {}
            base["profile"] = component_profile
            effective_reasoning = base

        model = provider.create_model(
            resolved_model, tags=tags, reasoning=effective_reasoning,
        )

        logger.info("Using %s model: %s", selected_provider, resolved_model)
        return model, {
            'provider': selected_provider,
            'model': resolved_model,
            'config': provider_config,
        }
    except Exception as e:
        raise LLMProviderError(f"Failed to create ADK model: {e}")

def get_provider_info() -> Dict[str, Any]:
    """Get current (primary) provider information."""
    try:
        selected_provider, provider_config = _resolve_provider(None)
        if selected_provider == LITELLM_PROVIDER_NAME:
            model = str(provider_config.get("default_model") or "")
        else:
            model = str(
                provider_config.get("model")
                or provider_config.get("deployment_name")
                or ""
            )
        return {
            'provider': selected_provider,
            'model': model,
            'config': provider_config,
        }
    except Exception as e:
        raise LLMProviderError(f"Failed to get provider info: {e}")
