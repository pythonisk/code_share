"""Bedrock embeddings provider."""

from __future__ import annotations

from typing import Any

from .base_embedding_provider import BaseEmbeddingProvider


class BedrockEmbeddingProvider(BaseEmbeddingProvider):
    """Embedding provider backed by LiteLLM for AWS Bedrock embeddings."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.model = config.get("model", "amazon.titan-embed-text-v1")

    def embed_text(self, text: str) -> list[float]:
        vectors = self.embed_batch([text])
        return vectors[0] if vectors else []

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []

        try:
            from litellm import embedding  # pylint: disable=import-outside-toplevel
        except Exception as exc:
            raise ImportError("litellm package is required for BedrockEmbeddingProvider") from exc

        request_kwargs: dict[str, Any] = {
            "model": self.model,
            "input": texts,
        }

        # Pass through supported optional fields for bedrock embeddings.
        for key in (
            "input_type",
            "dimensions",
            "timeout",
            "aws_region_name",
            "aws_access_key_id",
            "aws_secret_access_key",
            "aws_session_token",
        ):
            value = self.config.get(key)
            if value is not None:
                request_kwargs[key] = value

        response = embedding(**request_kwargs)
        data = response.get("data") if isinstance(response, dict) else getattr(response, "data", None)
        if not data:
            return [[] for _ in texts]

        data_sorted = sorted(data, key=lambda item: int(_item_get(item, "index", 0)))
        return [_item_get(item, "embedding", []) for item in data_sorted]


def _item_get(item: Any, key: str, default: Any = None) -> Any:
    """Read key from dict-like or object-like LiteLLM response items."""
    if isinstance(item, dict):
        return item.get(key, default)
    return getattr(item, key, default)
