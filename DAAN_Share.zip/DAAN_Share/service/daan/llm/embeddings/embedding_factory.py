"""Factory for creating embedding providers dynamically."""

import importlib
from typing import Any

from .base_embedding_provider import BaseEmbeddingProvider


class EmbeddingProviderFactory:
    """Create embedding providers using a registry and importlib."""

    EMBEDDING_MAP = {
        "azure_openai": {
            "module": "daan.llm.embeddings.azure_openai_embedding_provider",
            "class": "AzureOpenAIEmbeddingProvider",
        },
        "openai": {
            "module": "daan.llm.embeddings.openai_embedding_provider",
            "class": "OpenAIEmbeddingProvider",
        },
        "litellm": {
            "module": "daan.llm.embeddings.litellm_embedding_provider",
            "class": "LiteLLMEmbeddingProvider",
        },
        "sentence_transformer": {
            "module": "daan.llm.embeddings.sentence_transformer_embedding_provider",
            "class": "SentenceTransformerEmbeddingProvider",
        },
    }

    @classmethod
    def create_provider(cls, provider_name: str, config: dict[str, Any]) -> BaseEmbeddingProvider:
        """Create and return an embedding provider instance."""
        if provider_name not in cls.EMBEDDING_MAP:
            available = ", ".join(cls.EMBEDDING_MAP.keys())
            raise ValueError(f"Unsupported embedding provider '{provider_name}'. Available: {available}")

        provider_info = cls.EMBEDDING_MAP[provider_name]

        try:
            module = importlib.import_module(provider_info["module"])
            provider_class = getattr(module, provider_info["class"])
            return provider_class(config)
        except ImportError as exc:
            raise ImportError(
                f"Failed to import embedding provider module {provider_info['module']}: {exc}"
            ) from exc
        except AttributeError as exc:
            raise AttributeError(
                f"Embedding class {provider_info['class']} not found in {provider_info['module']}: {exc}"
            ) from exc

    @classmethod
    def get_available_providers(cls) -> list[str]:
        """List available provider keys."""
        return list(cls.EMBEDDING_MAP.keys())
