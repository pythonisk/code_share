"""LiteLLM embeddings provider."""

from __future__ import annotations

import os
from typing import Any

from .base_embedding_provider import BaseEmbeddingProvider


class LiteLLMEmbeddingProvider(BaseEmbeddingProvider):
    """Embedding provider backed by LiteLLM."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.model = config.get("model", "text-embedding-3-large")
        self.api_key = config.get("api_key") or os.getenv(config.get("api_key_env", "OPENAI_API_KEY"))

    def embed_text(self, text: str) -> list[float]:
        vectors = self.embed_batch([text])
        return vectors[0] if vectors else []

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []

        try:
            from litellm import embedding  # pylint: disable=import-outside-toplevel
        except Exception as exc:
            raise ImportError("litellm package is required for LiteLLMEmbeddingProvider") from exc

        request_kwargs = {
            "model": self.model,
            "input": texts,
        }
        if self.api_key:
            request_kwargs["api_key"] = self.api_key

        # Pass through optional LiteLLM settings when provided.
        for key in ("api_base", "api_version", "api_type", "organization"):
            if key in self.config and self.config[key] is not None:
                request_kwargs[key] = self.config[key]

        response = embedding(**request_kwargs)
        data = response.get("data") if isinstance(response, dict) else getattr(response, "data", None)
        if not data:
            return [[] for _ in texts]

        data_sorted = sorted(data, key=lambda item: int(_item_get(item, "index", 0)))
        return [_item_get(item, "embedding", []) for item in data_sorted]


def _item_get(item: Any, key: str, default: Any = None) -> Any:
    """Read key from dict-like or object-like LiteLLM response items."""
    if isinstance(item, dict):
        return item.get(key, default)
    return getattr(item, key, default)
