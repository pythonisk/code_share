"""Embedding providers and factory."""
