"""Sentence Transformer embeddings provider."""

from __future__ import annotations

from typing import Any

from .base_embedding_provider import BaseEmbeddingProvider


class SentenceTransformerEmbeddingProvider(BaseEmbeddingProvider):
    """Embedding provider backed by sentence-transformers."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.model_name = config.get("model_name", "sentence-transformers/all-MiniLM-L6-v2")
        self._model = None

    def _get_model(self):
        if self._model is not None:
            return self._model
        try:
            from sentence_transformers import SentenceTransformer  # pylint: disable=import-outside-toplevel
        except Exception as exc:
            raise ImportError(
                "sentence-transformers package is required for SentenceTransformerEmbeddingProvider"
            ) from exc
        self._model = SentenceTransformer(self.model_name)
        return self._model

    def embed_text(self, text: str) -> list[float]:
        vectors = self.embed_batch([text])
        return vectors[0] if vectors else []

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        model = self._get_model()
        vectors = model.encode(texts, normalize_embeddings=True)
        return [list(map(float, vector)) for vector in vectors]
