"""Vertex AI embeddings provider."""

from __future__ import annotations

import os
from typing import Any

from .base_embedding_provider import BaseEmbeddingProvider


class VertexAIEmbeddingProvider(BaseEmbeddingProvider):
    """Embedding provider backed by LiteLLM for Vertex AI embeddings."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.model = config.get("model", "vertex_ai/textembedding-gecko")

        # Optional auth/project settings.
        self.vertex_project = config.get("vertex_project") or os.getenv(
            config.get("vertex_project_env", "VERTEX_PROJECT")
        )
        self.vertex_location = config.get("vertex_location") or os.getenv(
            config.get("vertex_location_env", "VERTEX_LOCATION")
        )

        credentials_path = config.get("google_application_credentials") or os.getenv(
            config.get("google_application_credentials_env", "GOOGLE_APPLICATION_CREDENTIALS")
        )
        if credentials_path:
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = credentials_path

    def embed_text(self, text: str) -> list[float]:
        vectors = self.embed_batch([text])
        return vectors[0] if vectors else []

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []

        try:
            from litellm import embedding  # pylint: disable=import-outside-toplevel
        except Exception as exc:
            raise ImportError("litellm package is required for VertexAIEmbeddingProvider") from exc

        request_kwargs: dict[str, Any] = {
            "model": self.model,
            "input": texts,
        }

        if self.vertex_project:
            request_kwargs["vertex_project"] = self.vertex_project
        if self.vertex_location:
            request_kwargs["vertex_location"] = self.vertex_location

        for key in ("dimensions", "timeout", "input_type"):
            value = self.config.get(key)
            if value is not None:
                request_kwargs[key] = value

        response = embedding(**request_kwargs)
        data = response.get("data") if isinstance(response, dict) else getattr(response, "data", None)
        if not data:
            return [[] for _ in texts]

        data_sorted = sorted(data, key=lambda item: int(_item_get(item, "index", 0)))
        return [_item_get(item, "embedding", []) for item in data_sorted]


def _item_get(item: Any, key: str, default: Any = None) -> Any:
    """Read key from dict-like or object-like LiteLLM response items."""
    if isinstance(item, dict):
        return item.get(key, default)
    return getattr(item, key, default)
