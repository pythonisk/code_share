"""OpenAI embeddings provider."""

from __future__ import annotations

import os
from typing import Any

from .base_embedding_provider import BaseEmbeddingProvider


class OpenAIEmbeddingProvider(BaseEmbeddingProvider):
    """Embedding provider backed by LiteLLM for OpenAI embeddings."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.api_key = config.get("api_key") or os.getenv(config.get("api_key_env", "OPENAI_API_KEY"))
        self.model = config.get("model", "text-embedding-3-large")
        self.base_url = config.get("base_url", "https://api.openai.com/v1")

        if not self.api_key:
            raise ValueError("OpenAI API key is required. Set config.api_key or OPENAI_API_KEY.")

    def embed_text(self, text: str) -> list[float]:
        vectors = self.embed_batch([text])
        return vectors[0] if vectors else []

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []

        try:
            from litellm import embedding  # pylint: disable=import-outside-toplevel
        except Exception as exc:
            raise ImportError("litellm package is required for OpenAIEmbeddingProvider") from exc

        request_kwargs: dict[str, Any] = {
            "model": self.model,
            "input": texts,
            "api_key": self.api_key,
        }
        if self.base_url:
            request_kwargs["api_base"] = self.base_url

        response = embedding(**request_kwargs)
        data = response.get("data") if isinstance(response, dict) else getattr(response, "data", None)
        if not data:
            return [[] for _ in texts]

        data_sorted = sorted(data, key=lambda item: int(_item_get(item, "index", 0)))
        return [_item_get(item, "embedding", []) for item in data_sorted]


def _item_get(item: Any, key: str, default: Any = None) -> Any:
    """Read key from dict-like or object-like LiteLLM response items."""
    if isinstance(item, dict):
        return item.get(key, default)
    return getattr(item, key, default)
