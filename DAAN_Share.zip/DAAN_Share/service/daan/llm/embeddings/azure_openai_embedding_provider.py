"""Azure OpenAI embeddings provider."""

from __future__ import annotations

import os
from typing import Any

from .base_embedding_provider import BaseEmbeddingProvider


class AzureOpenAIEmbeddingProvider(BaseEmbeddingProvider):
    """Embedding provider backed by LiteLLM for Azure OpenAI embeddings."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config

        # Accept either direct values or env-backed values from config.
        self.api_key = config.get("api_key") or os.getenv(config.get("api_key_env", "AZURE_OPENAI_API_KEY"))
        self.endpoint = (
            config.get("endpoint")
            or os.getenv(config.get("endpoint_env", "AZURE_OPENAI_ENDPOINT"))
            or os.getenv("AZURE_API_BASE")
        )
        self.deployment = (
            config.get("deployment")
            or config.get("deployment_name")
            or os.getenv(config.get("deployment_env", "AZURE_OPENAI_EMBEDDING_DEPLOYMENT"))
        )
        self.model = config.get("model") or os.getenv("AZURE_OPENAI_EMBEDDING_MODEL", "text-embedding-3-large")
        self.api_version = config.get("api_version") or os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")

        if not self.api_key:
            raise ValueError(
                "Azure OpenAI API key is required. Set config.api_key or AZURE_OPENAI_API_KEY."
            )
        if not self.endpoint:
            raise ValueError(
                "Azure OpenAI endpoint is required. Set config.endpoint or AZURE_OPENAI_ENDPOINT."
            )

    def embed_text(self, text: str) -> list[float]:
        vectors = self.embed_batch([text])
        return vectors[0] if vectors else []

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []

        try:
            from litellm import embedding  # pylint: disable=import-outside-toplevel
        except Exception as exc:
            raise ImportError("litellm package is required for AzureOpenAIEmbeddingProvider") from exc

        # text-embedding-ada-002 has 8,191 token limit per request
        # With 512 token chunks, safe batch size is ~15 chunks (7,680 tokens)
        # Leaving buffer for overhead and safety
        MAX_BATCH_SIZE = 100  # Conservative limit for safety
        
        # Split large batches into smaller ones to avoid API limits
        if len(texts) <= MAX_BATCH_SIZE:
            return self._embed_single_batch(texts)
        
        # Process in smaller batches
        all_embeddings: list[list[float]] = []
        for i in range(0, len(texts), MAX_BATCH_SIZE):
            batch = texts[i:i + MAX_BATCH_SIZE]
            batch_embeddings = self._embed_single_batch(batch)
            all_embeddings.extend(batch_embeddings)
        
        return all_embeddings

    def _embed_single_batch(self, texts: list[str]) -> list[list[float]]:
        """Embed a single batch of texts (internal helper)."""
        if not texts:
            return []

        try:
            from litellm import embedding  # pylint: disable=import-outside-toplevel
        except Exception as exc:
            raise ImportError("litellm package is required for AzureOpenAIEmbeddingProvider") from exc

        model_name = f"azure/{self.deployment}" if self.deployment else self.model
        request_kwargs: dict[str, Any] = {
            "model": model_name,
            "input": texts,
            "api_key": self.api_key,
            "api_base": self.endpoint,
            "api_version": self.api_version,
        }

        if self.config.get("api_type"):
            request_kwargs["api_type"] = self.config.get("api_type")

        response = embedding(**request_kwargs)
        data = response.get("data") if isinstance(response, dict) else getattr(response, "data", None)
        if not data:
            return [[] for _ in texts]

        # Azure returns embeddings with an index for each input.
        data_sorted = sorted(data, key=lambda item: int(_item_get(item, "index", 0)))
        return [_item_get(item, "embedding", []) for item in data_sorted]


def _item_get(item: Any, key: str, default: Any = None) -> Any:
    """Read key from dict-like or object-like LiteLLM response items."""
    if isinstance(item, dict):
        return item.get(key, default)
    return getattr(item, key, default)
