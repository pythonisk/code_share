"""Factory for creating graph stores dynamically."""

import importlib
from typing import Any

from .providers.base_graph_store import BaseGraphStore


class GraphStoreFactory:
    """Create graph stores using a registry and importlib."""

    _instances: dict[str, "BaseGraphStore"] = {}

    GRAPH_STORE_MAP = {
        "kuzu": {
            "module": "daan.graph_stores.providers.kuzu_store",
            "class": "KuzuGraphStore",
        },
        "neo4j": {
            "module": "daan.graph_stores.providers.neo4j_store",
            "class": "Neo4jGraphStore",
        },
        "cosmos": {
            "module": "daan.graph_stores.providers.cosmos_graph_store",
            "class": "CosmosGraphStore",
        },
        "in_memory": {
            "module": "daan.graph_stores.providers.in_memory_graph_store",
            "class": "InMemoryGraphStore",
        },
    }

    @classmethod
    def create_store(cls, store_name: str, config: dict[str, Any]) -> BaseGraphStore:
        """Create and return a graph store instance."""
        if store_name not in cls.GRAPH_STORE_MAP:
            available = ", ".join(cls.GRAPH_STORE_MAP.keys())
            raise ValueError(f"Unsupported graph store '{store_name}'. Available: {available}")

        # Use store_name + db_path (kuzu) or graph+database (cosmos/neo4j) as cache key
        # so the same underlying store is never opened twice for the same target,
        # but different KBs that point to different graphs/databases get their own instance.
        cache_key = (
            f"{store_name}:"
            f"{config.get('db_path', '')}:"
            f"{config.get('graph', '')}:"
            f"{config.get('database', '')}"
        )
        if cache_key in cls._instances:
            return cls._instances[cache_key]

        store_info = cls.GRAPH_STORE_MAP[store_name]

        try:
            module = importlib.import_module(store_info["module"])
            store_class = getattr(module, store_info["class"])
            instance = store_class(config)
        except ImportError as exc:
            raise ImportError(f"Failed to import graph store module {store_info['module']}: {exc}") from exc
        except AttributeError as exc:
            raise AttributeError(
                f"Graph store class {store_info['class']} not found in {store_info['module']}: {exc}"
            ) from exc

        cls._instances[cache_key] = instance
        return instance

    @classmethod
    def get_available_stores(cls) -> list[str]:
        """List available graph stores."""
        return list(cls.GRAPH_STORE_MAP.keys())
