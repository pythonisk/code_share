"""In-memory graph store implementation for tests and local development."""

from __future__ import annotations

from collections import deque
from typing import Any

from .base_graph_store import BaseGraphStore
from ..graph_document import GraphEdge, GraphNode


class InMemoryGraphStore(BaseGraphStore):
    """Dictionary-backed graph store."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._nodes: dict[str, GraphNode] = {}
        self._edges: list[GraphEdge] = []

    def add_node(self, node: GraphNode) -> None:
        if node.id in self._nodes:
            raise ValueError(f"Node '{node.id}' already exists")
        self._nodes[node.id] = node

    def add_edge(self, edge: GraphEdge) -> None:
        self._validate_edge_nodes(edge)
        self._edges.append(edge)

    def query(self, cypher: str) -> list[dict]:
        raise NotImplementedError("Cypher queries are not supported in InMemoryGraphStore")

    def get_neighbors(self, node_id: str, depth: int) -> list[GraphNode]:
        if node_id not in self._nodes:
            return []

        visited = {node_id}
        result: list[GraphNode] = []
        queue: deque[tuple[str, int]] = deque([(node_id, 0)])

        adjacency: dict[str, list[str]] = {}
        for edge in self._edges:
            adjacency.setdefault(edge.source_id, []).append(edge.target_id)
            adjacency.setdefault(edge.target_id, []).append(edge.source_id)

        while queue:
            current, current_depth = queue.popleft()
            if current_depth >= depth:
                continue

            for neighbor in adjacency.get(current, []):
                if neighbor in visited:
                    continue
                visited.add(neighbor)
                result.append(self._nodes[neighbor])
                queue.append((neighbor, current_depth + 1))

        return result

    def get_subgraph(self, node_ids: list[str]) -> dict[str, list]:
        node_set = set(node_ids)
        nodes = [node for node_id, node in self._nodes.items() if node_id in node_set]
        edges = [
            edge
            for edge in self._edges
            if edge.source_id in node_set and edge.target_id in node_set
        ]
        return {"nodes": nodes, "edges": edges}

    def upsert_node(self, node: GraphNode) -> None:
        self._nodes[node.id] = node

    def upsert_edge(self, edge: GraphEdge) -> None:
        self._validate_edge_nodes(edge)
        for index, current in enumerate(self._edges):
            if (
                current.source_id == edge.source_id
                and current.target_id == edge.target_id
                and current.type == edge.type
            ):
                self._edges[index] = edge
                return
        self._edges.append(edge)

    def close(self) -> None:
        return

    def _validate_edge_nodes(self, edge: GraphEdge) -> None:
        missing = [node for node in (edge.source_id, edge.target_id) if node not in self._nodes]
        if missing:
            raise ValueError(f"Edge references missing node(s): {', '.join(missing)}")
