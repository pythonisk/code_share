"""Neo4j graph store placeholder for future phases."""

from typing import Any

from .base_graph_store import BaseGraphStore
from ..graph_document import GraphEdge, GraphNode


class Neo4jGraphStore(BaseGraphStore):
    """Neo4j implementation deferred in current scope."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config

    def add_node(self, node: GraphNode) -> None:
        raise NotImplementedError("Neo4jGraphStore is not implemented yet")

    def add_edge(self, edge: GraphEdge) -> None:
        raise NotImplementedError("Neo4jGraphStore is not implemented yet")

    def query(self, cypher: str) -> list[dict]:
        raise NotImplementedError("Neo4jGraphStore is not implemented yet")

    def get_neighbors(self, node_id: str, depth: int) -> list[GraphNode]:
        raise NotImplementedError("Neo4jGraphStore is not implemented yet")

    def get_subgraph(self, node_ids: list[str]) -> dict[str, list]:
        raise NotImplementedError("Neo4jGraphStore is not implemented yet")

    def upsert_node(self, node: GraphNode) -> None:
        raise NotImplementedError("Neo4jGraphStore is not implemented yet")

    def upsert_edge(self, edge: GraphEdge) -> None:
        raise NotImplementedError("Neo4jGraphStore is not implemented yet")

    def close(self) -> None:
        return
