"""Base interface for graph stores."""

from abc import ABC, abstractmethod

from ..graph_document import GraphEdge, GraphNode


class BaseGraphStore(ABC):
    """Contract for graph storage backends."""

    @abstractmethod
    def add_node(self, node: GraphNode) -> None:
        """Insert a node."""

    @abstractmethod
    def add_edge(self, edge: GraphEdge) -> None:
        """Insert an edge."""

    @abstractmethod
    def query(self, cypher: str) -> list[dict]:
        """Run a graph query and return records."""

    @abstractmethod
    def get_neighbors(self, node_id: str, depth: int) -> list[GraphNode]:
        """Fetch neighboring nodes within depth."""

    @abstractmethod
    def get_subgraph(self, node_ids: list[str]) -> dict[str, list]:
        """Return a node/edge subgraph for the supplied node ids."""

    @abstractmethod
    def upsert_node(self, node: GraphNode) -> None:
        """Insert or update a node."""

    @abstractmethod
    def upsert_edge(self, edge: GraphEdge) -> None:
        """Insert or update an edge."""

    @abstractmethod
    def close(self) -> None:
        """Close underlying connections/resources."""

    def list_concept_nodes(self) -> list[dict]:
        """Return curated concept vertices for ontology grounding.

        Each item is a plain dict with at least ``id`` and ``name`` keys (and
        optionally ``label`` / ``aliases``). Chunk vertices are excluded. The
        default implementation returns an empty list; stores backed by a curated
        ontology (e.g. Cosmos) override this.
        """
        return []

