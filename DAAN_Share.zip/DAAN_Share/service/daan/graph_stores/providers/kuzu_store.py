"""Kuzu graph store implementation."""

from __future__ import annotations

from typing import Any

from .base_graph_store import BaseGraphStore
from ..graph_document import GraphEdge, GraphNode
from .in_memory_graph_store import InMemoryGraphStore


class KuzuGraphStore(BaseGraphStore):
    """Kuzu-backed graph store with optional in-memory fallback."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self._db_path = config.get("db_path", ".kuzu")
        self._use_fallback = bool(config.get("allow_fallback_in_memory", True))
        self._fallback_store: InMemoryGraphStore | None = None

        self._connection = None
        try:
            import kuzu  # pylint: disable=import-outside-toplevel

            database = kuzu.Database(self._db_path)
            self._connection = kuzu.Connection(database)
            self._ensure_schema()
        except ImportError as exc:
            if not self._use_fallback:
                raise ImportError("kuzu package is required for KuzuGraphStore") from exc
            self._fallback_store = InMemoryGraphStore(config={})

    def add_node(self, node: GraphNode) -> None:
        if self._fallback_store:
            self._fallback_store.add_node(node)
            return

        query = (
            "MERGE (n:Entity {id: $id}) "
            "SET n.label = $label, n.properties = $properties"
        )
        self._execute(query, node.model_dump())

    def add_edge(self, edge: GraphEdge) -> None:
        if self._fallback_store:
            self._fallback_store.add_edge(edge)
            return

        query = (
            "MATCH (s:Entity {id: $source_id}), (t:Entity {id: $target_id}) "
            "MERGE (s)-[r:RELATION {type: $type}]->(t) "
            "SET r.properties = $properties"
        )
        self._execute(query, edge.model_dump())

    def query(self, cypher: str) -> list[dict]:
        if self._fallback_store:
            return self._fallback_store.query(cypher)

        result = self._connection.execute(cypher)
        rows: list[dict] = []
        while result.has_next():
            rows.append(result.get_next())
        return rows

    def get_neighbors(self, node_id: str, depth: int) -> list[GraphNode]:
        if self._fallback_store:
            return self._fallback_store.get_neighbors(node_id, depth)

        try:
            safe_depth = int(depth)
        except (TypeError, ValueError):
            safe_depth = 1
        safe_depth = max(1, min(safe_depth, 5))

        query = (
            f"MATCH (n:Entity {{id: $node_id}})-[*1..{safe_depth}]-(m:Entity) "
            "RETURN DISTINCT m.id AS id, m.label AS label, m.properties AS properties"
        )
        result = self._execute(query, {"node_id": node_id})

        return [
            GraphNode(
                id=row.get("id"),
                label=row.get("label", "Entity"),
                properties=row.get("properties") or {},
            )
            for row in result
        ]

    def get_subgraph(self, node_ids: list[str]) -> dict[str, list]:
        if self._fallback_store:
            return self._fallback_store.get_subgraph(node_ids)

        return {
            "nodes": [self._get_node(node_id) for node_id in node_ids if self._get_node(node_id)],
            "edges": self._get_edges(node_ids),
        }

    def upsert_node(self, node: GraphNode) -> None:
        self.add_node(node)

    def upsert_edge(self, edge: GraphEdge) -> None:
        self.add_edge(edge)

    def close(self) -> None:
        self._connection = None

    def _ensure_schema(self) -> None:
        if not self._connection:
            return

        self._connection.execute(
            "CREATE NODE TABLE IF NOT EXISTS Entity(id STRING, label STRING, properties STRING, PRIMARY KEY(id));"
        )
        self._connection.execute(
            "CREATE REL TABLE IF NOT EXISTS RELATION(FROM Entity TO Entity, type STRING, properties STRING);"
        )

    def _execute(self, query: str, params: dict[str, Any]) -> list[dict]:
        result = self._connection.execute(query, params)
        rows: list[dict] = []
        while result.has_next():
            rows.append(result.get_next())
        return rows

    def _get_node(self, node_id: str) -> GraphNode | None:
        rows = self._execute(
            "MATCH (n:Entity {id: $id}) RETURN n.id AS id, n.label AS label, n.properties AS properties",
            {"id": node_id},
        )
        if not rows:
            return None
        row = rows[0]
        return GraphNode(
            id=row.get("id"),
            label=row.get("label", "Entity"),
            properties=row.get("properties") or {},
        )

    def _get_edges(self, node_ids: list[str]) -> list[GraphEdge]:
        rows = self._execute(
            "MATCH (s:Entity)-[r:RELATION]->(t:Entity) "
            "WHERE s.id IN $node_ids AND t.id IN $node_ids "
            "RETURN s.id AS source_id, t.id AS target_id, r.type AS type, r.properties AS properties",
            {"node_ids": node_ids},
        )
        return [
            GraphEdge(
                source_id=row.get("source_id"),
                target_id=row.get("target_id"),
                type=row.get("type", "RELATION"),
                properties=row.get("properties") or {},
            )
            for row in rows
        ]
