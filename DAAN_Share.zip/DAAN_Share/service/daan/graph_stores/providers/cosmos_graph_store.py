"""CosmosDB Gremlin graph store (Advanced-RAG knowledge base).

Implements the BaseGraphStore contract on top of the Azure Cosmos DB Gremlin API,
pointed at a knowledge-base graph (per-KB `graph`/`database` from rag_config.yml).

Reuses the shared account endpoint + key (GREMLIN_ENDPOINT / GREMLIN_KEY).
Connection settings come from daan.core.config.Settings.
"""

from __future__ import annotations

import logging
import re
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from daan.core.config import get_settings

from .base_graph_store import BaseGraphStore
from ..graph_document import GraphEdge, GraphNode

logger = logging.getLogger(__name__)

# Cosmos vertex ids cannot contain these characters (must match the loader).
_INVALID_ID_CHARS = ("/", "\\", "?", "#")

_UNSAFE_GRAPH_NAME_CHARS = re.compile(r"[^a-zA-Z0-9_-]+")


def graph_name_for_kb(kb_id: str) -> str:
    """Return a Cosmos-safe graph (container) name for ``kb_id``."""
    cleaned = _UNSAFE_GRAPH_NAME_CHARS.sub("-", str(kb_id).strip()).strip("-")
    return f"{cleaned or 'kb'}-graph"[:255]


def _sanitize_id(raw: Any) -> str:
    sanitized = str(raw)
    for bad in _INVALID_ID_CHARS:
        sanitized = sanitized.replace(bad, "_")
    return sanitized


def _is_valid_id(node_id: str) -> bool:
    """Cosmos rejects vertices whose partition key is null/empty."""
    return bool(node_id) and node_id.strip() not in ("", "None", "null")


def _documents_endpoint(gremlin_endpoint: str) -> str:
    """Derive the HTTPS control-plane endpoint from the Gremlin WebSocket endpoint.

    The Gremlin data-plane endpoint looks like
    ``wss://<acct>.gremlin.cosmos.azure.com:443/`` whereas the azure-cosmos SDK
    (used to create databases/graphs) talks to
    ``https://<acct>.documents.azure.com:443/``.
    """
    ep = (gremlin_endpoint or "").strip()
    if "://" in ep:
        ep = ep.split("://", 1)[1]
    ep = ep.strip("/")
    host = ep.split(":", 1)[0]
    account = host.split(".", 1)[0]
    if not account:
        raise ValueError(
            f"Could not derive Cosmos account name from GREMLIN_ENDPOINT: {gremlin_endpoint!r}"
        )
    return f"https://{account}.documents.azure.com:443/"


class CosmosGraphStore(BaseGraphStore):
    """Graph store backed by Cosmos DB (Gremlin API)."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config or {}
        settings = get_settings()

        self._endpoint = self.config.get("endpoint") or settings.GREMLIN_ENDPOINT
        self._key = self.config.get("key") or settings.GREMLIN_KEY
        self._database = self.config.get("database")
        self._graph = self.config.get("graph")
        self._client = None
        # Track labels we've already warned about (invalid ids) to avoid log spam.
        self._warned_labels: set[str] = set()
        # gremlinpython's aiohttp transport patches the running event loop via
        # nest_asyncio, which fails under uvloop (used by uvicorn in production).
        # Pin the client to a single dedicated thread that never runs uvloop so
        # gremlinpython can create/patch its own standard asyncio loop instead.
        self._executor = ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="cosmos-gremlin"
        )

        if not self._key:
            raise ValueError("GREMLIN_KEY is not set. Add it to config/.env.")
        if not self._graph or not self._database:
            raise ValueError(
                "Cosmos graph store requires 'graph' and 'database' from the KB's "
                "rag_config.yml entry (knowledge_bases[].graph / .database)."
            )

    # ------------------------------------------------------------------
    # Provisioning (data plane)
    # ------------------------------------------------------------------

    def _cosmos_client(self):
        """Return an azure-cosmos client for the HTTPS endpoint of this account."""
        try:
            from azure.cosmos import CosmosClient
        except ImportError as exc:
            raise ImportError(
                'azure-cosmos is not installed. Run: pip install "azure-cosmos>=4.5.0"'
            ) from exc
        return CosmosClient(url=_documents_endpoint(self._endpoint), credential=self._key)

    def ensure_graph(
        self,
        throughput: int | None = None,
        partition_key_path: str = "/partition",
    ) -> None:
        """Create this store's database + graph container if they don't exist.

        Gremlin has no statement for creating containers, so this uses the
        ``azure-cosmos`` SDK against the HTTPS ``documents.azure.com`` endpoint
        derived from ``GREMLIN_ENDPOINT``, reusing the same account key. Idempotent.

        Args:
            throughput: Provisioned RU/s for a newly created graph. Leave ``None``
                for serverless accounts and shared-throughput databases, which
                reject an explicit value. Ignored when the graph already exists.
            partition_key_path: Partition key path. Defaults to ``/partition`` to
                match the property ``upsert_node`` writes on every vertex.

        Raises:
            ValueError: If the graph exists with a different partition key.
        """
        from azure.cosmos import PartitionKey

        with self._cosmos_client() as client:
            database = client.create_database_if_not_exists(id=self._database)

            create_kwargs: dict[str, Any] = {
                "id": self._graph,
                "partition_key": PartitionKey(path=partition_key_path),
            }
            if throughput is not None:
                create_kwargs["offer_throughput"] = throughput
            container = database.create_container_if_not_exists(**create_kwargs)

            # create_container_if_not_exists silently returns a pre-existing container,
            # so a partition-key mismatch would only surface later as failed writes.
            existing_paths = (container.read().get("partitionKey") or {}).get("paths") or []
            if existing_paths and partition_key_path not in existing_paths:
                raise ValueError(
                    f"Graph '{self._graph}' already exists with partition key {existing_paths}, "
                    f"expected '{partition_key_path}'."
                )

        logger.info(
            "Ensured Cosmos graph exists: db=%s graph=%s (pk=%s)",
            self._database, self._graph, partition_key_path,
        )

    def verify_writable(self) -> None:
        """Round-trip a probe vertex to prove Gremlin accepts this container.

        A container created through the SQL data plane is not guaranteed to be a
        usable Gremlin graph, so provisioning must prove it before a KB adopts it.

        Raises:
            RuntimeError: If the probe vertex cannot be written or read back.
        """
        probe_id = "__provision_probe__"
        try:
            self.upsert_node(GraphNode(id=probe_id, label="ProvisionProbe", properties={"name": "probe"}))
            if probe_id not in self.list_node_ids():
                raise RuntimeError("Probe vertex was written but could not be read back.")
        finally:
            try:
                self.purge_nodes_by_labels(["ProvisionProbe"])
            except Exception:  # noqa: BLE001
                logger.warning("Could not clean up provisioning probe vertex in graph %s.", self._graph)

    def delete_graph(self) -> bool:
        """Delete this store's graph container. Returns False if it was not present."""
        try:
            from azure.cosmos.exceptions import CosmosResourceNotFoundError
        except ImportError:
            return False

        try:
            with self._cosmos_client() as client:
                client.get_database_client(self._database).delete_container(self._graph)
            return True
        except CosmosResourceNotFoundError:
            return False
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not delete Cosmos graph '%s': %s", self._graph, exc)
            return False

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    def _connect(self):
        if self._client is not None:
            return self._client
        try:
            from gremlin_python.driver import client as gremlin_client, serializer
            from gremlin_python.driver.aiohttp.transport import AiohttpTransport
        except ImportError as exc:
            raise ImportError(
                'gremlinpython is not installed. Run: pip install "gremlinpython>=3.7.0"'
            ) from exc

        # Do NOT pass call_from_event_loop=True.
        # That flag triggers nest_asyncio.apply() which patches asyncio globally and
        # breaks asyncio.timeout() Task detection on Python 3.11+ / 3.14 (raises
        # "Timeout context manager should be used inside a task").
        # AiohttpTransport creates its own private event loop (self._loop =
        # asyncio.new_event_loop()) and runs every send/receive as a proper Task on
        # that loop — no nest_asyncio required.  All gremlin calls are already
        # isolated on a dedicated ThreadPoolExecutor thread so there is no conflict
        # with uvicorn's event loop.
        self._client = gremlin_client.Client(
            self._endpoint,
            "g",
            transport_factory=lambda: AiohttpTransport(),
            username=f"/dbs/{self._database}/colls/{self._graph}",
            password=self._key,
            message_serializer=serializer.GraphSONSerializersV2d0(),
        )
        return self._client

    def _submit(self, query: str, bindings: dict[str, Any] | None = None) -> list[Any]:
        # Run entirely on the dedicated worker thread so the gremlin client is
        # never touched from the uvloop / asyncio request thread.
        return self._executor.submit(self._submit_sync, query, bindings).result()

    def _submit_sync(self, query: str, bindings: dict[str, Any] | None = None) -> list[Any]:
        """Execute a Gremlin query synchronously on the dedicated worker thread.

        AiohttpTransport manages its own event loop internally; we simply call
        client.submit(...).all().result() which blocks the worker thread until the
        WebSocket response arrives.  Works on Python 3.12 and 3.14.
        
        Raises RuntimeError if a write operation fails, allowing callers to detect
        and handle failures. Read operations return empty lists on error for
        backwards compatibility.
        """
        # Substrings seen for a dead/stale WebSocket across gremlinpython versions
        # and Cosmos-side idle disconnects — any of these warrant a reconnect
        # instead of failing outright, since a single long-lived publish run can
        # legitimately span hours and outlive one connection.
        _stale_connection_markers = (
            "closing transport",
            "connection was already closed",
            "connection is already closed",
            "not open",
        )
        max_attempts = 3
        for attempt in range(max_attempts):
            client = self._connect()
            try:
                return list(client.submit(query, bindings or {}).all().result())
            except Exception as exc:  # noqa: BLE001
                err = str(exc)
                # Stale WebSocket — close the dead client, force a fresh one, retry.
                if attempt < max_attempts - 1 and any(marker in err.lower() for marker in _stale_connection_markers):
                    logger.warning("Gremlin connection stale (%.200s); reconnecting [%.200s]", err, query)
                    try:
                        client.close()
                    except Exception:  # noqa: BLE001
                        pass
                    self._client = None
                    continue
                
                logger.error("Gremlin query failed [%.200s]: %s", query, exc)
                if any(op in query for op in ["addV(", "addE(", ".drop()"]):
                    raise RuntimeError(f"Gremlin write operation failed: {exc}") from exc
                return []
        
        return []

    # ------------------------------------------------------------------
    # Write methods
    # ------------------------------------------------------------------

    def add_node(self, node: GraphNode) -> None:
        self.upsert_node(node)

    def add_edge(self, edge: GraphEdge) -> None:
        self.upsert_edge(edge)

    def upsert_node(self, node: GraphNode) -> None:
        """Insert or update a vertex in the graph.
        
        Each vertex is assigned a partition key equal to its ID for optimal
        distribution. The coalesce pattern checks for an existing vertex before
        creating a new one.
        """
        node_id = _sanitize_id(node.id)
        if not _is_valid_id(node_id):
            if node.label not in self._warned_labels:
                logger.warning(
                    "Skipping node with invalid/null ID (label=%s, raw_id=%r, sanitized=%r). "
                    "This node cannot be written to Cosmos.",
                    node.label, node.id, node_id
                )
                self._warned_labels.add(node.label)
            return
        
        label = str(node.label or "Entity")
        name = str((node.properties or {}).get("name", node.label or node_id))
        
        self._submit(
            "g.V(nid).fold()"
            ".coalesce(unfold(),"
            " addV(nlabel)"
            "  .property('id', nid)"
            "  .property('partition', nid)"
            "  .property('partitionKey', nid)"
            "  .property('pk', nid))"
            ".property('label_name', nname)",
            {"nid": node_id, "nlabel": label, "nname": name},
        )

    def upsert_edge(self, edge: GraphEdge) -> None:
        """Insert or update an edge between two vertices.
        
        Uses hasId() to reliably locate vertices across different partitions.
        The coalesce pattern checks for an existing edge before creating a new one.
        """
        src = _sanitize_id(edge.source_id)
        tgt = _sanitize_id(edge.target_id)
        if not _is_valid_id(src) or not _is_valid_id(tgt):
            return
        
        rel = str(edge.type)
        self._submit(
            "g.V(src).as('a').V(tgt)"
            ".coalesce("
            " __.inE(rel).where(outV().as('a')),"
            " __.addE(rel).from('a'))",
            {"src": src, "tgt": tgt, "rel": rel},
        )

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    def count_extracted_entities(self) -> int:
        """Count deprecated per-chunk extraction vertices (label ``Entity``)."""
        rows = self._submit("g.V().hasLabel('Entity').count()")
        return int(rows[0]) if rows else 0

    def purge_extracted_entities(self) -> int:
        """Drop deprecated ``Entity`` extraction vertices and their edges.

        Dropping a vertex in Gremlin also drops its incident edges, so the stray
        ``chunk -MENTIONS-> Entity`` links are removed as well. Curated ontology
        vertices (non-``Entity`` labels) and ``Chunk`` vertices are untouched.

        Returns the number of ``Entity`` vertices that existed before the drop.
        """
        before = self.count_extracted_entities()
        if before:
            self._submit("g.V().hasLabel('Entity').drop()")
        return before

    def count_nodes_by_labels(self, labels: list[str]) -> int:
        """Count vertices carrying any of the given Gremlin labels."""
        clean = [str(label).replace("'", "\\'") for label in labels if str(label).strip()]
        if not clean:
            return 0
        args = ",".join(f"'{label}'" for label in clean)
        rows = self._submit(f"g.V().hasLabel({args}).count()")
        return int(rows[0]) if rows else 0

    def purge_nodes_by_labels(self, labels: list[str]) -> int:
        """Drop all vertices carrying any of the given labels, plus their edges.

        Dropping a vertex in Gremlin also removes its incident edges, so the
        relationships attached to the deleted nodes disappear too. Vertices with
        other (e.g. curated ontology) labels are left untouched.

        Returns the number of matching vertices that existed before the drop.
        """
        clean = [str(label).replace("'", "\\'") for label in labels if str(label).strip()]
        if not clean:
            return 0
        before = self.count_nodes_by_labels(clean)
        if before:
            args = ",".join(f"'{label}'" for label in clean)
            self._submit(f"g.V().hasLabel({args}).drop()")
        return before

    # ------------------------------------------------------------------
    # Read methods
    # ------------------------------------------------------------------

    def query(self, cypher: str) -> list[dict]:
        """Run a raw Gremlin traversal string and return the raw result rows.

        Note: Cosmos uses Gremlin, not Cypher. The parameter name is kept as
        'cypher' only to satisfy the BaseGraphStore contract signature.
        """
        return list(self._submit(cypher))

    def list_node_ids(self) -> list[str]:
        """Return all vertex ids in the graph (used for query-time entity linking)."""
        rows = self._submit("g.V().id()")
        return [str(r) for r in rows if r is not None]

    def list_concept_nodes(self) -> list[dict]:
        """Return curated ontology concept vertices (id + name + label + aliases).

        Only human-curated ontology concepts are used for grounding, so two kinds
        of non-curated vertices are excluded:
          * ``Chunk`` vertices added by the indexing pipeline, and
          * ``Entity`` vertices left over from the deprecated per-chunk entity
            extractor (``KnowledgeGraphBuilder``), which produced noisy, generic
            nodes (e.g. "has", "more"). Linking chunks to those instead of the
            curated ontology is exactly the failure we want to avoid.

        ``label_name``/``name`` cover both the loader's and the ontology upload's
        property naming.
        """
        rows = self._submit(
            "g.V().not(hasLabel('Chunk')).not(hasLabel('Entity'))"
            ".project('id','label','name','aliases','description')"
            ".by(id()).by(label())"
            ".by(coalesce(values('name','label_name'), constant('')))"
            ".by(coalesce(values('aliases'), constant('')))"
            ".by(coalesce(values('description'), constant('')))"
        )
        concepts: list[dict] = []
        for row in rows:
            if not row:
                continue
            node_id = str(row.get("id") or "")
            # Belt-and-suspenders: skip the deprecated extractor's id scheme.
            if node_id.startswith("ent:"):
                continue
            name = str(row.get("name") or "").strip()
            if not name:
                continue
            concepts.append(
                {
                    "id": node_id,
                    "label": str(row.get("label", "Entity")),
                    "name": name,
                    "aliases": row.get("aliases") or "",
                    "description": str(row.get("description") or "").strip(),
                }
            )
        return concepts


    def get_neighbors(self, node_id: str, depth: int) -> list[GraphNode]:
        """Return distinct nodes within `depth` hops of node_id (both directions)."""
        nid = _sanitize_id(node_id)
        try:
            safe_depth = int(depth)
        except (TypeError, ValueError):
            safe_depth = 1
        safe_depth = max(1, min(safe_depth, 5))

        # Avoid g.V(nid) because Cosmos graphs with composite partition keys reject
        # direct vertex-id lookups unless the traversal is supplied with [pk, id].
        # Filtering by hasId(...) works across both composite-key and simple-id graphs.
        # Cosmos Gremlin also requires the times() count as an inline literal (not a
        # binding); safe_depth is clamped so it is safe to inline.
        if safe_depth <= 1:
            traversal = "g.V().hasId(nid).both().dedup().limit(200)"
        else:
            traversal = (
                f"g.V().hasId(nid).repeat(both().simplePath()).times({safe_depth})"
                ".emit().dedup().limit(200)"
            )

        rows = self._submit(
            traversal
            + ".project('id','label','name')"
            ".by(id()).by(label()).by(coalesce(values('label_name','name'), constant('')))",
            {"nid": nid},
        )
        return [self._row_to_node(row) for row in rows if row]

    def get_neighbors_batch(
        self, node_ids: list[str], depth: int
    ) -> list[GraphNode]:
        """Return the union of distinct neighbors for many seeds in ONE round-trip.

        Cosmos Gremlin round-trips are the dominant cost during graph retrieval;
        issuing one query per seed (N seeds x 2-hop fan-out) causes retrieval
        timeouts. This batches every seed into a single traversal using
        hasId(within(nids)).
        """
        nids = [_sanitize_id(n) for n in node_ids if n]
        if not nids:
            return []
        try:
            safe_depth = int(depth)
        except (TypeError, ValueError):
            safe_depth = 1
        safe_depth = max(1, min(safe_depth, 5))

        if safe_depth <= 1:
            traversal = "g.V().hasId(within(nids)).both().dedup().limit(400)"
        else:
            traversal = (
                f"g.V().hasId(within(nids)).repeat(both().simplePath()).times({safe_depth})"
                ".emit().dedup().limit(400)"
            )

        rows = self._submit(
            traversal
            + ".project('id','label','name')"
            ".by(id()).by(label()).by(coalesce(values('label_name','name'), constant('')))",
            {"nids": nids},
        )
        return [self._row_to_node(row) for row in rows if row]

    def get_subgraph(self, node_ids: list[str]) -> dict[str, list]:
        ids = [_sanitize_id(n) for n in node_ids]
        if not ids:
            return {"nodes": [], "edges": []}

        node_rows = self._submit(
            "g.V().hasId(within(ids)).project('id','label','name')"
            ".by(id()).by(label()).by(coalesce(values('label_name','name'), constant('')))",
            {"ids": ids},
        )
        nodes = [self._row_to_node(row) for row in node_rows if row]

        edge_rows = self._submit(
            "g.V().hasId(within(ids)).outE().as('e').inV().hasId(within(ids)).select('e')"
            ".project('source','target','type')"
            ".by(outV().id()).by(inV().id()).by(label())",
            {"ids": ids},
        )
        edges = [
            GraphEdge(
                source_id=str(row.get("source")),
                target_id=str(row.get("target")),
                type=str(row.get("type", "RELATION")),
                properties={},
            )
            for row in edge_rows
            if row
        ]
        return {"nodes": nodes, "edges": edges}

    def close(self) -> None:
        if self._client is not None:
            try:
                # Close on the worker thread that owns the client/loop.
                self._executor.submit(self._client.close).result(timeout=10)
            except Exception:  # noqa: BLE001
                pass
            self._client = None
        self._executor.shutdown(wait=False)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _row_to_node(row: dict[str, Any]) -> GraphNode:
        name = row.get("name") or ""
        return GraphNode(
            id=str(row.get("id")),
            label=str(row.get("label", "Entity")),
            properties={"name": name, "text": name},
        )
