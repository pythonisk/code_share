"""Graph node and edge models."""

from pydantic import BaseModel, Field


class GraphNode(BaseModel):
    """Graph node representation."""

    id: str
    label: str
    properties: dict = Field(default_factory=dict)


class GraphEdge(BaseModel):
    """Graph edge representation."""

    source_id: str
    target_id: str
    type: str
    properties: dict = Field(default_factory=dict)
