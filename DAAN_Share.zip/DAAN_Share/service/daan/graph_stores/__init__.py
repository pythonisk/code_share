"""Graph store abstractions and implementations."""
