"""SQLAlchemy models for per-user MCP server credential storage."""

from datetime import datetime
from enum import Enum as PyEnum

from sqlalchemy import Boolean, DateTime, Enum, ForeignKey, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from daan.core.database import Base


class ValidationStatus(PyEnum):
    """Status of credential validation."""

    NOT_TESTED = "not_tested"
    VALID = "valid"
    INVALID = "invalid"
    EXPIRED = "expired"
    CONNECTION_FAILED = "connection_failed"


class UserMcpConfig(Base):
    """User-specific MCP server configuration.

    Stores metadata and configuration for MCP servers per user.
    Actual credentials are stored in UserMcpSecret for better separation.
    """

    __tablename__ = "user_mcp_configs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    mcp_server_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)

    # Global default flag — when True, this config is the system-wide default for all users
    is_global_default: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, index=True)

    # Metadata and status
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    validation_status: Mapped[ValidationStatus] = mapped_column(
        Enum(ValidationStatus, values_callable=lambda x: [e.value for e in x]),
        default=ValidationStatus.NOT_TESTED,
        nullable=False
    )
    last_validation_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Usage tracking
    last_accessed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    access_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # Credential expiry
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Encryption version tracking (for key rotation)
    credential_version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)

    # Server-specific metadata (non-sensitive config like workspace paths)
    server_metadata: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON string

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relationships
    user = relationship("User", backref="mcp_configs")
    secret = relationship("UserMcpSecret", back_populates="config", uselist=False, cascade="all, delete-orphan")

    # Unique constraint: one config per user per server
    __table_args__ = (
        UniqueConstraint("user_id", "mcp_server_name", name="uq_user_server"),
    )

    def __repr__(self) -> str:
        return f"<UserMcpConfig(id={self.id}, user_id={self.user_id}, server={self.mcp_server_name})>"


class UserMcpSecret(Base):
    """Encrypted MCP server credentials.

    Separated from config for better security isolation.
    Contains only encrypted sensitive data.
    """

    __tablename__ = "user_mcp_secrets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    config_id: Mapped[int] = mapped_column(
        ForeignKey("user_mcp_configs.id", ondelete="CASCADE"), nullable=False, unique=True, index=True
    )

    # Encrypted credentials (Fernet-encrypted JSON blob)
    encrypted_credentials: Mapped[str] = mapped_column(Text, nullable=False)

    # Credential hash for breach detection (SHA256 of plaintext)
    credential_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    # Relationships
    config = relationship("UserMcpConfig", back_populates="secret")

    def __repr__(self) -> str:
        return f"<UserMcpSecret(id={self.id}, config_id={self.config_id})>"
