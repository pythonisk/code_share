from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from daan.models.evidence_models import (
    EvidenceDecision,
    EvidenceEnvelope,
    EvidenceProducer,
    EvidenceRuntime,
    EvidenceSubject,
    compact_evidence_mapping,
)


class MissingContextItem(BaseModel):
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    field: str = ""
    reason: str = ""
    priority: str = "medium"


class ProbeType(str, Enum):
    DOMAIN = "domain"
    CAPABILITY = "capability"
    WORKFLOW_STAGE = "workflow_stage"
    ARTIFACT_CLASS = "artifact_class"
    PLATFORM_COMPONENT = "platform_component"
    ONTOLOGY_CONCEPT = "ontology_concept"


class QueryType(str, Enum):
    FACTOID = "factoid"
    DEFINITION = "definition"
    WORKFLOW = "workflow"
    INTEGRATION = "integration"
    REQUIREMENTS = "requirements"
    GOVERNANCE = "governance"
    MULTI_ENTITY = "multi_entity"
    GENERAL = "general"


class KnowledgeAreaProbe(BaseModel):
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    probe_id: str = ""
    probe_type: ProbeType = ProbeType.DOMAIN
    label: str = ""
    rationale: str = ""
    exploration_questions: list[str] = Field(default_factory=list)
    retrieval_terms: list[str] = Field(default_factory=list)
    ontology_hints: list[str] = Field(default_factory=list)
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)

    def to_legacy_string(self) -> str:
        label = str(self.label or "").strip()
        rationale = str(self.rationale or "").strip()
        if not label:
            return ""
        if not rationale:
            return label
        if rationale[-1] not in ".!?":
            rationale += "."
        return f"{label}:\n{rationale}"


class ProbeValidationResult(BaseModel):
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    probe_id: str = ""
    accepted: bool = False
    rejection_reason: str | None = None
    rewrite_score: float = Field(default=0.0, ge=0.0, le=1.0)
    diversity_group: str | None = None


class QueryNormalizationResult(BaseModel):
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    original_query: str = ""
    normalized_query: str = ""
    query_type: QueryType = QueryType.GENERAL
    simple_query: bool = False
    detected_entities: list[str] = Field(default_factory=list)


class RetrievalBranchPlan(BaseModel):
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    branch_id: str = ""
    branch_type: str = "base_query"
    label: str = ""
    retrieval_query: str = ""
    probe_id: str | None = None
    probe_type: str | None = None
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)


class ContextExtrapolationResult(BaseModel):
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    schema_version: str = "1.0"
    intent: str = ""
    intent_confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    persona: str = ""
    persona_confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    task: str = ""
    task_confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    technologies: list[str] = Field(default_factory=list)
    industries: list[str] = Field(default_factory=list)
    expanded_queries: list[str] = Field(default_factory=list)
    retrieval_probes: list[str] = Field(default_factory=list)
    probes: list[KnowledgeAreaProbe] = Field(default_factory=list)
    probe_validation: list[ProbeValidationResult] = Field(default_factory=list)
    query_normalization: QueryNormalizationResult | None = None
    branch_plans: list[RetrievalBranchPlan] = Field(default_factory=list)
    metadata_hints: dict[str, Any] = Field(default_factory=dict)
    missing_context: list[MissingContextItem] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    overall_confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    use_plan: bool = False
    fallback_reason: str | None = None

    @staticmethod
    def _confidence_signal(value: str, confidence: float) -> float | None:
        return confidence if str(value or "").strip() else None

    def to_evidence_envelope(
        self,
        *,
        original_query: str,
        final_retrieval_query: str,
        runtime_trace: dict[str, Any] | None = None,
    ) -> EvidenceEnvelope:
        normalized_original_query = str(original_query or "").strip()
        normalized_final_retrieval_query = str(final_retrieval_query or "").strip()
        normalized_missing_context = [
            {
                "field": item.field,
                "reason": item.reason,
                "priority": item.priority,
            }
            for item in self.missing_context
            if item.field
        ]

        signals = compact_evidence_mapping(
            {
                "intent": self.intent,
                "intent_confidence": self._confidence_signal(self.intent, self.intent_confidence),
                "persona": self.persona,
                "persona_confidence": self._confidence_signal(self.persona, self.persona_confidence),
                "retrieval_probes": list(self.retrieval_probes),
                "knowledge_area_probes": [probe.model_dump(exclude_none=True) for probe in self.probes],
                "missing_context": normalized_missing_context,
            }
        )
        artifacts = compact_evidence_mapping(
            {
                "final_retrieval_query": normalized_final_retrieval_query,
                "branch_plans": [branch.model_dump(exclude_none=True) for branch in self.branch_plans],
            }
        )
        decisions = [
            EvidenceDecision(
                key="plan_acceptance",
                label="Plan Acceptance",
                value=self.use_plan,
                rationale=self.fallback_reason,
                confidence=self.overall_confidence,
                status="accepted" if self.use_plan else "fallback",
            )
        ]

        return EvidenceEnvelope(
            producer=EvidenceProducer(
                id="context_extrapolation_agent",
                name="Context Extrapolation Agent",
                version=self.schema_version,
            ),
            subject=EvidenceSubject(
                kind="query",
                title=normalized_original_query or None,
            ),
            signals=signals,
            artifacts=artifacts,
            decisions=decisions,
            runtime=EvidenceRuntime(
                metadata=compact_evidence_mapping(dict(runtime_trace or {})),
            ),
            extensions=compact_evidence_mapping(
                {
                    "probe_validation": [item.model_dump(exclude_none=True) for item in self.probe_validation],
                    "query_normalization": self.query_normalization.model_dump(exclude_none=True) if self.query_normalization else None,
                }
            ),
        )

    @classmethod
    def fallback(cls, reason: str) -> "ContextExtrapolationResult":
        return cls(use_plan=False, fallback_reason=reason, overall_confidence=0.0)


class StructuredMissingContextItem(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    field: str
    reason: str
    priority: str


class StructuredProbeExplorationQuestions(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    label: str
    exploration_questions: list[str] = Field(default_factory=list)


class StructuredContextExtrapolationOutput(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    schema_version: str
    intent: str
    intent_confidence: float
    persona: str
    persona_confidence: float
    retrieval_probes: list[str]
    probe_exploration_questions: list[StructuredProbeExplorationQuestions] = Field(default_factory=list)
    missing_context: list[StructuredMissingContextItem]
    overall_confidence: float
    use_plan: bool
    fallback_reason: str | None
