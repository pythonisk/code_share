"""Model for assigning users to archetypes with specific access levels."""

from sqlalchemy import Column, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from daan.core.database import Base


class UserArchetypeAssignment(Base):
    """Many-to-many relationship with extra data (access_level)."""

    __tablename__ = "user_archetype_assignment"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    archetype_id: Mapped[int] = mapped_column(ForeignKey("arch_types.id"), nullable=False)
    access_level: Mapped[str] = mapped_column(String(20), default="read", nullable=False)  # 'read' or 'edit'

    user = relationship("User", backref="archetype_assignments")
    archetype = relationship("Archetype", backref="user_assignments")

    __table_args__ = (UniqueConstraint("user_id", "archetype_id", name="uix_user_archetype"),)
