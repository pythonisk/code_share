from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


EVIDENCE_ENVELOPE_VERSION = "1.0"


def has_evidence_value(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple, set, frozenset, dict)):
        return len(value) > 0
    return True


def compact_evidence_value(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return compact_evidence_value(value.model_dump(exclude_none=True))
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for key, item in value.items():
            compacted = compact_evidence_value(item)
            if has_evidence_value(compacted):
                result[str(key)] = compacted
        return result
    if isinstance(value, (list, tuple, set, frozenset)):
        items = [compact_evidence_value(item) for item in value]
        return [item for item in items if has_evidence_value(item)]
    if isinstance(value, str):
        return value.strip()
    return value


def compact_evidence_mapping(mapping: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(mapping, dict):
        return {}
    compacted = compact_evidence_value(mapping)
    return compacted if isinstance(compacted, dict) else {}


class EvidenceProducer(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    id: str
    name: str
    version: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class EvidenceSubject(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    kind: str
    id: str | None = None
    title: str | None = None
    description: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class EvidenceSource(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    id: str
    kind: str = "reference"
    label: str | None = None
    locator: str | None = None
    snippet: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class EvidenceRuntime(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    timestamp: str | None = None
    latency_ms: int | None = Field(default=None, ge=0)
    status: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class EvidenceDecision(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    key: str
    label: str
    value: Any = None
    rationale: str | None = None
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    status: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class EvidenceEnvelope(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    version: str = EVIDENCE_ENVELOPE_VERSION
    producer: EvidenceProducer
    subject: EvidenceSubject
    signals: dict[str, Any] = Field(default_factory=dict)
    artifacts: dict[str, Any] = Field(default_factory=dict)
    decisions: list[EvidenceDecision] = Field(default_factory=list)
    sources: list[EvidenceSource] = Field(default_factory=list)
    runtime: EvidenceRuntime = Field(default_factory=EvidenceRuntime)
    extensions: dict[str, Any] = Field(default_factory=dict)
