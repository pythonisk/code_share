"""SQLAlchemy models for dynamic MCP server registry.

This module stores discovered MCP server definitions that can be
registered dynamically from the UI without editing YAML files.
"""

from datetime import datetime
from enum import Enum as PyEnum

from sqlalchemy import Boolean, DateTime, Enum, ForeignKey, Integer, JSON, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from daan.core.database import Base


class TransportType(PyEnum):
    """MCP server transport protocol."""

    HTTP = "http"
    STDIO = "stdio"
    SSE = "sse"


class AuthScheme(PyEnum):
    """Authentication scheme for MCP server."""

    NONE = "none"
    API_KEY = "api_key"
    BEARER = "bearer"
    BASIC = "basic"
    OAUTH = "oauth"
    OAUTH2 = "oauth2"
    CUSTOM = "custom"


class RegistryStatus(PyEnum):
    """Status of MCP server in registry."""

    DISCOVERED = "discovered"
    VALIDATED = "validated"
    FAILED = "failed"
    DEPRECATED = "deprecated"


class McpServerRegistry(Base):
    """Dynamic MCP server registry for auto-discovered servers.

    Stores server definitions that are discovered from user input
    (remote URL or npm package), allowing dynamic registration without
    editing config files.
    """

    __tablename__ = "mcp_server_registry"
    __table_args__ = (
        UniqueConstraint("server_name", "created_by_user_id", name="uq_registry_server_per_user"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)

    # Server Identification
    server_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    display_name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Transport Configuration
    transport: Mapped[TransportType] = mapped_column(
        Enum(TransportType, values_callable=lambda x: [e.value for e in x]),
        nullable=False
    )

    # Remote Transport (HTTP/SSE)
    base_url: Mapped[str | None] = mapped_column(String(500), nullable=True)

    # stdio Transport (npx, uvx, python)
    npm_package: Mapped[str | None] = mapped_column(String(200), nullable=True)
    command: Mapped[str | None] = mapped_column(String(200), nullable=True)
    args: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    # Environment Variables (all transports)
    env_vars: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    # Authentication Configuration
    auth_scheme: Mapped[AuthScheme] = mapped_column(
        Enum(AuthScheme, values_callable=lambda x: [e.value for e in x]),
        default=AuthScheme.NONE,
        nullable=False
    )
    required_credentials: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    # Discovered Capabilities (from MCP introspection)
    available_tools: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    available_resources: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    available_prompts: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    # Metadata
    category: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    icon_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    documentation_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    homepage_url: Mapped[str | None] = mapped_column(String(500), nullable=True)

    # Registry Status
    status: Mapped[RegistryStatus] = mapped_column(
        Enum(RegistryStatus, values_callable=lambda x: [e.value for e in x]),
        default=RegistryStatus.DISCOVERED,
        nullable=False,
        index=True
    )

    # Access Control
    is_global: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, index=True)
    is_public: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_by_user_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id"), nullable=True, index=True
    )

    # Discovery Metadata
    discovered_from: Mapped[str | None] = mapped_column(String(500), nullable=True)
    discovery_method: Mapped[str | None] = mapped_column(String(50), nullable=True)
    last_introspection_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    introspection_error: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Usage Tracking
    usage_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    user_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )
    deprecated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relationships
    creator = relationship("User", backref="created_mcp_servers")

    def __repr__(self) -> str:
        return f"<McpServerRegistry(id={self.id}, name={self.server_name}, transport={self.transport.value})>"


class McpDiscoveryLog(Base):
    """Log of MCP server discovery attempts for debugging and auditing."""

    __tablename__ = "mcp_discovery_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)

    # Discovery Input
    input_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    input_package: Mapped[str | None] = mapped_column(Text, nullable=True)
    input_file_name: Mapped[str | None] = mapped_column(Text, nullable=True)
    discovery_method: Mapped[str] = mapped_column(String(50), nullable=False)

    # Result
    success: Mapped[bool] = mapped_column(Boolean, nullable=False, index=True)
    server_name: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
    response_data: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    # Performance Metrics
    duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)

    # Timestamp
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False, index=True
    )

    # Relationships
    user = relationship("User", backref="mcp_discovery_logs")

    def __repr__(self) -> str:
        return f"<McpDiscoveryLog(id={self.id}, user_id={self.user_id}, success={self.success})>"
