"""Archetype model for managed architecture categories."""

from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, JSON, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from daan.core.database import Base


class Archetype(Base):
    """Architecture type entity used for cataloging use-case domains."""

    __tablename__ = "arch_types"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
    description: Mapped[str] = mapped_column(String(500), nullable=False)

    roles = relationship("ArchetypeRoleMap", back_populates="archetype")
    # Added relationship to usecase_archetype_mapping
    usecases = relationship("UseCaseArchetypeMapping", back_populates="archetype")

class UseCase(Base):
    """UseCase entity for storage in DB."""
    __tablename__ = "usecases"

    usecaseid: Mapped[str] = mapped_column(String(100), primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    account: Mapped[str | None] = mapped_column(String(255), nullable=True)
    task: Mapped[str | None] = mapped_column(String(255), nullable=True)
    role: Mapped[str | None] = mapped_column(String(255), nullable=True)
    premium: Mapped[str | None] = mapped_column(String(255), nullable=True)
    flow_of_agents: Mapped[str | None] = mapped_column(Text, nullable=True)
    dag: Mapped[str | None] = mapped_column(Text, nullable=True)
    loop_config: Mapped[int | None] = mapped_column(Integer, nullable=True)
    category: Mapped[str | None] = mapped_column(String(255), nullable=True)
    agents_involved: Mapped[str | None] = mapped_column(Text, nullable=True)

    archetypes = relationship("UseCaseArchetypeMapping", back_populates="usecase")
    agents = relationship("UseCaseAgentMapping", back_populates="usecase")

class UseCaseArchetypeMapping(Base):
    """Mapping between UseCases and Archetypes."""
    __tablename__ = "usecase_archetype_mapping"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    usecase_id: Mapped[str] = mapped_column(ForeignKey("usecases.usecaseid"), nullable=False)
    archetype_id: Mapped[int] = mapped_column(ForeignKey("arch_types.id"), nullable=False)
    isactive: Mapped[bool | None] = mapped_column(Boolean, nullable=True, default=True)
    archetype = relationship("Archetype", back_populates="usecases")
    usecase = relationship("UseCase", back_populates="archetypes")

class Category(Base):
    """Shared, portfolio-agnostic category (skill) catalog."""
    __tablename__ = "categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

class Agent(Base):
    """Agent entity for storage in DB."""
    __tablename__ = "agents"

    agent_id: Mapped[str] = mapped_column(String(100), primary_key=True, index=True)
    role: Mapped[str | None] = mapped_column(String(255), nullable=True)
    input_context: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    agent_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    agent_actions: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    output_format: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    output_validators: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    guardrails: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    mcp_server: Mapped[str | None] = mapped_column(String(255), nullable=True)
    local_tools: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    agent_type: Mapped[str | None] = mapped_column(String(255), nullable=True)
    depend_on: Mapped[str | None] = mapped_column(String(255), nullable=True)
    prompt_id: Mapped[int | None] = mapped_column(ForeignKey("prompt.id"), nullable=True)
    model: Mapped[str | None] = mapped_column(String(255), nullable=True)

    usecases = relationship("UseCaseAgentMapping", back_populates="agent")
    prompt_ref = relationship("GeneratedPrompt", back_populates="agents")

class UseCaseAgentMapping(Base):
    """Mapping between UseCases and Agents."""
    __tablename__ = "usecase_agent_mapping"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    usecase_id: Mapped[str] = mapped_column(ForeignKey("usecases.usecaseid"), nullable=False)
    agent_id: Mapped[str] = mapped_column(ForeignKey("agents.agent_id"), nullable=False)
    execution_order: Mapped[int | None] = mapped_column(Integer, nullable=True)

    usecase = relationship("UseCase", back_populates="agents")
    agent = relationship("Agent", back_populates="usecases")

class GeneratedPrompt(Base):
    """GeneratedPrompt entity (singular 'prompt' table)."""
    __tablename__ = "prompt"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    prompt_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    prompt_text: Mapped[str | None] = mapped_column(Text, nullable=True)

    agents = relationship("Agent", back_populates="prompt_ref")
    versions = relationship(
        "PromptVersion",
        back_populates="prompt_ref",
        order_by="PromptVersion.version_number",
        cascade="all, delete-orphan",
    )

class Prompt(Base):
    """Prompt entity managed in DB matching Agents.csv layout."""
    __tablename__ = "prompts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    archetype: Mapped[str | None] = mapped_column(String(255), nullable=True)
    use_case_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    role: Mapped[str | None] = mapped_column(String(255), nullable=True)
    agent_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    agents: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    agent_type: Mapped[str | None] = mapped_column(String(255), nullable=True)
    prompt: Mapped[str | None] = mapped_column(String(4000), nullable=True)
    refined_prompt: Mapped[str | None] = mapped_column(String(4000), nullable=True)
    input_keywords: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    output_format: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    output: Mapped[str | None] = mapped_column(String(4000), nullable=True)
    tools: Mapped[str | None] = mapped_column(String(2000), nullable=True)

class ArchetypeRoleMap(Base):
    """Association table for many-to-many mapping between arch types and roles."""
    __tablename__ = "archetype_role_map"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    archetype_id: Mapped[int] = mapped_column(ForeignKey("arch_types.id"), nullable=False)
    role_id: Mapped[int] = mapped_column(ForeignKey("roles.id"), nullable=False)

    archetype = relationship("Archetype", back_populates="roles")
    # Role relationship will be added in role.py


class PromptVersion(Base):
    """Append-only version history for prompt text.

    A new row is inserted every time a prompt's text changes.  The first
    version (version_number=1) is written when the prompt is first created.
    """

    __tablename__ = "prompt_versions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    prompt_id: Mapped[int] = mapped_column(
        ForeignKey("prompt.id", ondelete="CASCADE"), nullable=False, index=True
    )
    version_number: Mapped[int] = mapped_column(Integer, nullable=False)
    prompt_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by_user_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_by_username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    prompt_ref = relationship("GeneratedPrompt", back_populates="versions")


class AuditLog(Base):
    """Immutable audit trail for every UseCase / Agent / Prompt operation.

    Every significant mutation (create, edit, delete, map, unmap) writes one
    row here.  Names are denormalised so the breadcrumb remains readable even
    after the referenced entity is deleted.
    """

    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    # Human-readable action label stored verbatim, e.g. "Prompt Updated"
    action: Mapped[str] = mapped_column(String(60), nullable=False)
    # Use-case context (denormalised)
    usecase_id: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    usecase_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    # Agent context (denormalised)
    agent_id: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    agent_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    # Prompt context
    prompt_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    prompt_version: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # Who made the change
    changed_by_user_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    changed_by_username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    changed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False, index=True
    )
    # Short preview of the prompt text at the time of change (first 400 chars)
    prompt_preview: Mapped[str | None] = mapped_column(Text, nullable=True)
    # JSON diff: {field: {"before": ..., "after": ...}} for non-prompt changes
    changes: Mapped[dict | None] = mapped_column(JSON, nullable=True)
