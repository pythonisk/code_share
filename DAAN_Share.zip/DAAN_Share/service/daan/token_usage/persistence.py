"""Best-effort persistence for token usage event rows."""

from __future__ import annotations

from typing import Any

from daan.core.database import SessionLocal
from daan.core.logging import get_logger
from daan.models.token_usage import TokenUsageEvent

logger = get_logger(__name__)


def persist_token_usage_event(*, session: Any, record: dict[str, Any]) -> None:
    """Persist one token usage event row without breaking the workflow on failure."""
    if session is None or not isinstance(record, dict):
        return

    db = SessionLocal()
    try:
        event = TokenUsageEvent(
            session_id=str(getattr(session, "session_id", "") or ""),
            user_id=getattr(session, "user_id", None),
            usecase_id=str(getattr(session, "usecase_id", "") or "") or None,
            prompt_tokens=int(record.get("prompt_tokens") or 0),
            completion_tokens=int(record.get("completion_tokens") or 0),
            total_tokens=int(record.get("total_tokens") or 0),
            cost_usd=float(record.get("cost_usd")) if record.get("cost_usd") is not None else None,
            provider=str(record.get("provider") or "") or None,
            model=str(record.get("model") or "") or None,
            run_type=str(record.get("run_type") or "") or None,
        )
        db.add(event)
        db.commit()
        logger.debug(
            "Persisted token usage event",
            extra={
                "session_id": getattr(session, "session_id", None),
                "user_id": getattr(session, "user_id", None),
                "usecase_id": getattr(session, "usecase_id", None),
                "run_type": record.get("run_type"),
                "provider": record.get("provider"),
                "model": record.get("model"),
                "total_tokens": record.get("total_tokens"),
            },
        )
    except Exception as exc:
        db.rollback()
        logger.warning(
            "Failed to persist token usage event: %s",
            exc,
            extra={
                "session_id": getattr(session, "session_id", None),
                "user_id": getattr(session, "user_id", None),
                "usecase_id": getattr(session, "usecase_id", None),
                "run_type": record.get("run_type") if isinstance(record, dict) else None,
            },
        )
    finally:
        db.close()