"""Raw SQLAlchemy aggregation helpers for token usage analytics."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import distinct, func
from sqlalchemy.orm import Query, Session

from daan.models.archetype import Archetype, UseCase, UseCaseArchetypeMapping
from daan.models.token_usage import TokenUsageEvent
from daan.models.user import User


def date_bucket_expr():
    return func.date(TokenUsageEvent.created_at)


def build_base_query(db: Session, *, start_date: datetime, end_date: datetime) -> Query:
    return db.query(TokenUsageEvent).filter(
        TokenUsageEvent.created_at >= start_date,
        TokenUsageEvent.created_at <= end_date,
    )


def summary(query: Query) -> dict[str, Any]:
    total_sessions = query.with_entities(func.count(distinct(TokenUsageEvent.session_id))).scalar() or 0
    total_tokens = query.with_entities(func.sum(TokenUsageEvent.total_tokens)).scalar() or 0
    total_cost = query.with_entities(func.sum(TokenUsageEvent.cost_usd)).scalar() or 0.0
    return {
        "total_sessions": int(total_sessions),
        "total_tokens": int(total_tokens),
        "total_cost": float(total_cost),
    }


def tokens_over_time(query: Query) -> list[dict[str, Any]]:
    bucket = date_bucket_expr().label("bucket")
    rows = (
        query.with_entities(bucket, func.sum(TokenUsageEvent.total_tokens).label("total_tokens"))
        .group_by(bucket)
        .order_by(bucket.asc())
        .all()
    )
    return [{"date": row.bucket, "total_tokens": int(row.total_tokens or 0)} for row in rows]


def sessions_over_time(query: Query) -> list[dict[str, Any]]:
    bucket = date_bucket_expr().label("bucket")
    rows = (
        query.with_entities(bucket, func.count(distinct(TokenUsageEvent.session_id)).label("total_sessions"))
        .group_by(bucket)
        .order_by(bucket.asc())
        .all()
    )
    return [{"date": row.bucket, "total_sessions": int(row.total_sessions or 0)} for row in rows]


def tokens_by_dimension_over_time(query: Query, dimension_column) -> list[dict[str, Any]]:
    dimension = func.coalesce(dimension_column, "unknown").label("dimension")
    rows = (
        query.with_entities(
            dimension,
            func.sum(TokenUsageEvent.total_tokens).label("total_tokens"),
        )
        .group_by(dimension)
        .order_by(
            func.sum(TokenUsageEvent.total_tokens).desc(),
            dimension.asc(),
        )
        .all()
    )
    return [
        {
            "dimension": str(row.dimension),
            "total_tokens": int(row.total_tokens or 0),
        }
        for row in rows
    ]


def tokens_by_usecase_over_time(query: Query) -> list[dict[str, Any]]:
    rows = (
        query.join(UseCase, UseCase.usecaseid == TokenUsageEvent.usecase_id)
        .with_entities(
            TokenUsageEvent.usecase_id.label("usecase_id"),
            UseCase.name.label("name"),
            func.sum(TokenUsageEvent.total_tokens).label("total_tokens"),
        )
        .group_by(TokenUsageEvent.usecase_id, UseCase.name)
        .order_by(
            func.sum(TokenUsageEvent.total_tokens).desc(),
            UseCase.name.asc(),
        )
        .all()
    )
    return [
        {
            "usecase_id": str(row.usecase_id),
            "name": str(row.name or row.usecase_id),
            "total_tokens": int(row.total_tokens or 0),
        }
        for row in rows
    ]


def top_users(query: Query, limit: int = 10) -> list[dict[str, Any]]:
    rows = (
        query.outerjoin(User, User.id == TokenUsageEvent.user_id)
        .with_entities(
            TokenUsageEvent.user_id.label("user_id"),
            User.username.label("user_name"),
            func.count(distinct(TokenUsageEvent.session_id)).label("total_sessions"),
            func.sum(TokenUsageEvent.total_tokens).label("total_tokens"),
            func.sum(TokenUsageEvent.cost_usd).label("total_cost"),
        )
        .group_by(TokenUsageEvent.user_id, User.username)
        .order_by(
            func.sum(TokenUsageEvent.total_tokens).desc(),
            func.count(distinct(TokenUsageEvent.session_id)).desc(),
            User.username.asc(),
        )
        .limit(limit)
        .all()
    )
    return [
        {
            "user_id": row.user_id,
            "user_name": str(row.user_name) if row.user_name is not None else None,
            "total_sessions": int(row.total_sessions or 0),
            "total_tokens": int(row.total_tokens or 0),
            "total_cost": float(row.total_cost or 0.0),
        }
        for row in rows
    ]


def top_usecases(query: Query, limit: int = 25) -> list[dict[str, Any]]:
    rows = (
        query.join(UseCase, UseCase.usecaseid == TokenUsageEvent.usecase_id)
        .join(UseCaseArchetypeMapping, UseCaseArchetypeMapping.usecase_id == UseCase.usecaseid)
        .join(Archetype, Archetype.id == UseCaseArchetypeMapping.archetype_id)
        .with_entities(
            TokenUsageEvent.usecase_id.label("usecase_id"),
            UseCase.name.label("name"),
            func.min(Archetype.name).label("archetype"),
            func.sum(TokenUsageEvent.total_tokens).label("total_tokens"),
            func.count(distinct(TokenUsageEvent.session_id)).label("total_sessions"),
        )
        .group_by(TokenUsageEvent.usecase_id, UseCase.name)
        .order_by(
            func.sum(TokenUsageEvent.total_tokens).desc(),
            func.count(distinct(TokenUsageEvent.session_id)).desc(),
            UseCase.name.asc(),
        )
        .limit(limit)
        .all()
    )

    return [
        {
            "usecase_id": str(row.usecase_id),
            "name": str(row.name or row.usecase_id),
            "archetype": str(row.archetype) if row.archetype is not None else None,
            "total_tokens": int(row.total_tokens or 0),
            "total_sessions": int(row.total_sessions or 0),
        }
        for row in rows
    ]