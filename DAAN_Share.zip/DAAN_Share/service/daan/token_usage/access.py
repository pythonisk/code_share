"""Access-control helpers for token usage analytics."""

from __future__ import annotations

import re

from sqlalchemy.orm import Session

from daan.models.archetype import Archetype, UseCase, UseCaseArchetypeMapping
from daan.models.archetype_assignment import UserArchetypeAssignment
from daan.models.user import User


def is_admin_user(user: User) -> bool:
    return user.role is not None


def get_accessible_usecase_ids(db: Session, user: User) -> set[str]:
    if is_admin_user(user):
        rows = db.query(UseCase.usecaseid).all()
        return {str(usecase_id) for (usecase_id,) in rows if usecase_id}

    rows = (
        db.query(UseCaseArchetypeMapping.usecase_id)
        .join(
            UserArchetypeAssignment,
            UserArchetypeAssignment.archetype_id == UseCaseArchetypeMapping.archetype_id,
        )
        .filter(UserArchetypeAssignment.user_id == user.id)
        .distinct()
        .all()
    )
    return {str(usecase_id) for (usecase_id,) in rows if usecase_id}


def user_has_access_to_usecase(db: Session, user: User, usecase_id: str) -> bool:
    if is_admin_user(user):
        return True
    if not usecase_id:
        return False
    return usecase_id in get_accessible_usecase_ids(db, user)


def get_accessible_archetype_names(db: Session, user: User) -> set[str]:
    if is_admin_user(user):
        rows = db.query(Archetype.name).all()
        return {str(name).strip() for (name,) in rows if name}

    rows = (
        db.query(Archetype.name)
        .join(UserArchetypeAssignment, UserArchetypeAssignment.archetype_id == Archetype.id)
        .filter(UserArchetypeAssignment.user_id == user.id)
        .distinct()
        .all()
    )
    return {str(name).strip() for (name,) in rows if name}


def _coerce_scope_values(*values: object) -> set[str]:
    scoped_values: set[str] = set()
    for value in values:
        if value is None:
            continue
        if isinstance(value, str):
            parts = [part.strip() for part in re.split(r"[,;]", value) if part.strip()]
            scoped_values.update(parts)
            continue
        if isinstance(value, (list, tuple, set, frozenset)):
            scoped_values.update(_coerce_scope_values(*value))
            continue
        normalized = str(value).strip()
        if normalized:
            scoped_values.add(normalized)
    return scoped_values


def user_has_access_to_kb(
    db: Session,
    user: User,
    kb_id: str,
    *,
    kb_config: dict | None = None,
) -> bool:
    if is_admin_user(user):
        return True

    normalized_kb_id = str(kb_id or "").strip()
    if not normalized_kb_id:
        return False

    config = dict(kb_config or {})
    configured_kb_id = str(config.get("id") or "").strip()
    if configured_kb_id and configured_kb_id != normalized_kb_id:
        return False

    if bool(config.get("public")):
        return True

    allowed_usecase_ids = _coerce_scope_values(
        config.get("allowed_usecase_ids"),
        config.get("usecase_ids"),
        config.get("usecase_id"),
    )
    if allowed_usecase_ids:
        return bool(get_accessible_usecase_ids(db, user).intersection(allowed_usecase_ids))

    allowed_archetypes = {
        value.casefold() for value in _coerce_scope_values(
            config.get("allowed_archetypes"),
            config.get("archetypes"),
            config.get("archetype"),
        )
    }
    if allowed_archetypes:
        accessible_archetypes = {name.casefold() for name in get_accessible_archetype_names(db, user)}
        return bool(accessible_archetypes.intersection(allowed_archetypes))

    return False