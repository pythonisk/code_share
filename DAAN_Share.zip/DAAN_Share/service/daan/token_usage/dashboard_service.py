"""Aggregation helpers for token usage dashboard APIs."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy.orm import Session

from daan.models.archetype import UseCase
from daan.models.token_usage import TokenUsageEvent
from daan.models.user import User
from daan.token_usage.access import get_accessible_usecase_ids, is_admin_user
from daan.token_usage.queries import (
    build_base_query,
    sessions_over_time,
    summary,
    tokens_by_usecase_over_time,
    tokens_by_dimension_over_time,
    tokens_over_time,
    top_usecases,
    top_users,
)


def _resolve_user_name(db: Session, user_id: int | None) -> str | None:
    if user_id is None:
        return "All Users"
    user = db.query(User).filter(User.id == user_id).one_or_none()
    if user is None:
        return None
    return user.username


def _resolve_usecase_name(db: Session, usecase_id: str | None) -> str | None:
    if usecase_id is None:
        return "All Usecases"
    usecase_row = db.query(UseCase).filter(UseCase.usecaseid == usecase_id).one_or_none()
    if usecase_row is None:
        return None
    return usecase_row.name


def get_user_token_usage_dashboard(
    db: Session,
    *,
    start_date: datetime,
    end_date: datetime,
    user_id: int | None = None,
) -> dict:
    """Return aggregated token metrics for one user or all users in a date range."""
    query = build_base_query(db, start_date=start_date, end_date=end_date).filter(
        TokenUsageEvent.user_id.is_not(None)
    )
    if user_id is not None:
        query = query.filter(TokenUsageEvent.user_id == user_id)
    user_name = _resolve_user_name(db, user_id)
    return {
        "user_id": user_id,
        "user_name": user_name,
        "summary": summary(query),
        "tokens_over_time": tokens_over_time(query),
        "sessions_over_time": sessions_over_time(query),
        "tokens_by_usecase_over_time": tokens_by_usecase_over_time(query),
        "tokens_by_model_over_time": tokens_by_dimension_over_time(query, TokenUsageEvent.model),
    }


def get_usecase_token_usage_dashboard(
    db: Session,
    *,
    start_date: datetime,
    end_date: datetime,
    usecase_id: str | None = None,
    top_n: int = 10,
    accessible_usecase_ids: set[str] | None = None,
) -> dict:
    """Return aggregated token metrics for one use case or all visible use cases."""
    query = build_base_query(db, start_date=start_date, end_date=end_date).filter(
        TokenUsageEvent.usecase_id.is_not(None)
    )
    if usecase_id:
        query = query.filter(TokenUsageEvent.usecase_id == usecase_id)
    elif accessible_usecase_ids is not None:
        if not accessible_usecase_ids:
            return {
                "usecase_id": usecase_id,
                "usecase_name": _resolve_usecase_name(db, usecase_id),
                "summary": {"total_sessions": 0, "total_tokens": 0, "total_cost": 0.0},
                "tokens_over_time": [],
                "sessions_over_time": [],
                "top_users": [],
                "tokens_by_model_over_time": [],
            }
        query = query.filter(TokenUsageEvent.usecase_id.in_(accessible_usecase_ids))
    return {
        "usecase_id": usecase_id,
        "usecase_name": _resolve_usecase_name(db, usecase_id),
        "summary": summary(query),
        "tokens_over_time": tokens_over_time(query),
        "sessions_over_time": sessions_over_time(query),
        "top_users": top_users(query, limit=top_n),
        "tokens_by_model_over_time": tokens_by_dimension_over_time(query, TokenUsageEvent.model),
    }


def get_top_usecase_options(
    db: Session,
    *,
    start_date: datetime | None,
    end_date: datetime | None,
    user: User,
    limit: int = 10,
) -> list[dict]:
    """Return top use cases visible to the current user for selector population."""
    # If dates provided, filter by date range; otherwise query all data
    if start_date is not None and end_date is not None:
        query = build_base_query(db, start_date=start_date, end_date=end_date).filter(
            TokenUsageEvent.usecase_id.is_not(None)
        )
    else:
        # Query all data without date filtering
        query = db.query(TokenUsageEvent).filter(
            TokenUsageEvent.usecase_id.is_not(None)
        )
    
    if not is_admin_user(user):
        accessible_usecase_ids = get_accessible_usecase_ids(db, user)
        if not accessible_usecase_ids:
            return []
        query = query.filter(TokenUsageEvent.usecase_id.in_(accessible_usecase_ids))
    return top_usecases(query, limit=limit)