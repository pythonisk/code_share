"""Schemas for final quality score observability endpoints."""

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict


class FinalQualityScoreStoreRequest(BaseModel):
    """Backfill/persist final quality metrics for a finished session."""

    session_id: str


class FinalQualityScoreMetricResponse(BaseModel):
    """Persisted final quality score row."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    session_id: str
    usecase_id: str
    archetype: str
    username: str | None = None
    completeness_avg: float | None = None
    relevance_avg: float | None = None
    context_avg: float | None = None
    overall_avg: float | None = None
    reporter_output_path: str | None = None
    quality_output_path: str | None = None
    created_at: datetime
    updated_at: datetime


class FinalQualityScoreAverageResponse(BaseModel):
    """Aggregate average quality for one scope."""

    scope_type: Literal["usecase", "archetype"]
    scope_value: str
    average_score: float | None = None
    sample_count: int = 0
    latest_score: float | None = None
    latest_session_id: str | None = None
    updated_at: datetime | None = None


class AgentScoreItem(BaseModel):
    """Full per-dimension scores for one agent within a session."""

    agent_id: str
    agent_name: str
    completeness_score: float
    answer_relevance_score: float
    context_score: float
    overall_score: float
    passed: bool


class SessionScoreItem(BaseModel):
    """One finalized session with its averaged scores and per-agent scores."""

    session_id: str
    username: str | None = None
    run_timestamp: datetime | None = None
    completeness_avg: float | None = None
    relevance_avg: float | None = None
    context_avg: float | None = None
    overall_avg: float | None = None
    agents: list[AgentScoreItem] = []


class UsecaseScoreGroup(BaseModel):
    """A usecase grouping its sessions (and their agents) for the DQ dashboard."""

    usecase_id: str
    usecase_name: str | None = None
    archetype: str | None = None
    session_count: int = 0
    completeness_avg: float | None = None
    relevance_avg: float | None = None
    context_avg: float | None = None
    overall_avg: float | None = None
    sessions: list[SessionScoreItem] = []


class DqIndicatorsResponse(BaseModel):
    """Full usecase -> sessions -> agents quality hierarchy (all users)."""

    usecases: list[UsecaseScoreGroup] = []
