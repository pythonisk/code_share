"""Schemas for token usage event persistence and dashboard analytics."""

from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class TokenUsageEventBase(BaseModel):
    """Shared token usage event fields."""

    session_id: str
    user_id: int | None = None
    usecase_id: str | None = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost_usd: float | None = None
    provider: str | None = None
    model: str | None = None
    run_type: str | None = None


class TokenUsageEventCreate(TokenUsageEventBase):
    """Schema used when creating a token usage event row."""


class TokenUsageEventResponse(TokenUsageEventBase):
    """Response schema for one token usage event row."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime


class TokenUsageAnalyticsFilter(BaseModel):
    """Common date filter contract for token analytics endpoints."""

    start_date: datetime
    end_date: datetime
    granularity: Literal["day"] = "day"


class TokenUsageByUserRequest(TokenUsageAnalyticsFilter):
    """Dashboard query by user (admin can select any user)."""

    user_id: int | None = None


class TokenUsageByUsecaseRequest(TokenUsageAnalyticsFilter):
    """Dashboard query by use case."""

    usecase_id: str | None = None
    top_n: int = Field(default=10, ge=1, le=10)


class TokenUsageSummary(BaseModel):
    """Summary cards for token usage dashboards."""

    total_sessions: int = 0
    total_tokens: int = 0
    total_cost: float = 0.0


class DailyTokenPoint(BaseModel):
    """Time-series point for token totals."""

    date: date
    total_tokens: int


class DailySessionPoint(BaseModel):
    """Time-series point for distinct session totals."""

    date: date
    total_sessions: int


class DailyDimensionTokenPoint(BaseModel):
    """Ranked aggregate for one dimension (model/usecase)."""

    dimension: str
    total_tokens: int


class DailyUsecaseTokenPoint(BaseModel):
    """Ranked aggregate for one use case."""

    usecase_id: str
    name: str
    total_tokens: int


class TopUserPoint(BaseModel):
    """Ranked usage row for top users within a use case."""

    user_id: int | None = None
    user_name: str | None = None
    total_sessions: int
    total_tokens: int
    total_cost: float = 0.0


class TokenUsageByUserResponse(BaseModel):
    """Single payload used by frontend for user-specific dashboard."""

    user_id: int | None = None
    user_name: str | None = None
    summary: TokenUsageSummary
    tokens_over_time: list[DailyTokenPoint]
    sessions_over_time: list[DailySessionPoint]
    tokens_by_usecase_over_time: list[DailyUsecaseTokenPoint]
    tokens_by_model_over_time: list[DailyDimensionTokenPoint]


class TokenUsageByUsecaseResponse(BaseModel):
    """Single payload used by frontend for use-case-specific dashboard."""

    usecase_id: str | None = None
    usecase_name: str | None = None
    summary: TokenUsageSummary
    tokens_over_time: list[DailyTokenPoint]
    sessions_over_time: list[DailySessionPoint]
    top_users: list[TopUserPoint]
    tokens_by_model_over_time: list[DailyDimensionTokenPoint]


class TokenUsageUsecaseOption(BaseModel):
    """One ranked use case option for the use case selector."""

    usecase_id: str
    name: str
    archetype: str | None = None
    total_tokens: int
    total_sessions: int


class TokenUsageUsecaseOptionsResponse(BaseModel):
    """Response payload for the use case selector options."""

    usecases: list[TokenUsageUsecaseOption]