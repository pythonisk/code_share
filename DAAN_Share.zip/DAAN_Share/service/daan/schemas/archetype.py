"""Archetype schemas used by API responses."""

from datetime import datetime, timezone
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, field_validator

class ArchetypeResponse(BaseModel):
    """Public arch type response schema."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    description: str
    roles: List[str] = []


class ArchetypeRolesResponse(BaseModel):
    """Distinct role list for one archetype."""

    archetype: str
    roles: List[str]


class PromptSummaryResponse(BaseModel):
    """Prompt list item with ID."""

    id: int
    agent_id: Optional[str] = None
    usecase_id: Optional[str] = None
    role: Optional[str] = None
    archetype: Optional[str] = None
    agent_name: Optional[str] = None
    agent_type: Optional[str] = None
    depend_on: Optional[str] = None
    # Short preview text
    prompt: Optional[str] = None


class PromptDetailResponse(BaseModel):
    """Full agent payload by ID."""

    id: int
    archetype: Optional[str] = None
    use_case_id: Optional[str] = None
    category: Optional[str] = None
    agent_id: Optional[str] = None
    role: Optional[str] = None
    input_context: Optional[str] = None
    agent_name: Optional[str] = None
    agent_actions: Optional[str] = None
    output_format: Optional[str] = None
    output_validators: Optional[str] = None
    guardrails: Optional[str] = None
    mcp_server: Optional[str] = None
    local_tools: Optional[str] = None
    agent_type: Optional[str] = None
    depend_on: Optional[str] = None
    prompt_id: Optional[int] = None
    prompt: Optional[str] = None
    model: Optional[str] = None


class PromptCreateUpdate(BaseModel):
    """Schema for creating or updating an agent."""

    archetype: Optional[str] = None
    use_case_id: Optional[str] = None
    copy_from_agent_id: Optional[str] = None
    category: Optional[str] = None
    role: Optional[str] = None
    input_context: Optional[str] = None
    agent_name: Optional[str] = None
    agent_actions: Optional[str] = None
    output_format: Optional[str] = None
    output_validators: Optional[str] = None
    guardrails: Optional[str] = None
    mcp_server: Optional[str] = None
    local_tools: Optional[str] = None
    agent_type: Optional[str] = None
    depend_on: Optional[str] = None
    prompt: Optional[str] = None
    model: Optional[str] = None


class ArchetypeUpdate(BaseModel):
    """Schema for updating archetype details."""

    name: Optional[str] = None
    description: Optional[str] = None


class PromptVersionResponse(BaseModel):
    """One version entry returned by GET /agents/{agent_id}/prompt-versions."""

    model_config = ConfigDict(from_attributes=True)

    version_number: int
    prompt_text: Optional[str] = None
    created_by_username: Optional[str] = None
    created_at: datetime
    is_latest: bool = False


class AuditLogEntry(BaseModel):
    """Single audit log entry returned by GET /audit-log."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    usecase_name: Optional[str] = None
    usecase_id: Optional[str] = None
    agent_name: Optional[str] = None
    agent_id: Optional[str] = None
    prompt_version: Optional[int] = None
    prompt_preview: Optional[str] = None
    action: str
    changed_by_username: Optional[str] = None
    changed_at: datetime
    changes: Optional[dict] = None

    @field_validator('changed_at', mode='before')
    @classmethod
    def ensure_utc(cls, v: datetime) -> datetime:
        """Attach UTC timezone to naive datetimes so the API always returns
        a timezone-aware ISO string (e.g. 2026-07-28T14:55:30+00:00).
        JavaScript can then convert it correctly to the browser\'s local time."""
        if isinstance(v, datetime) and v.tzinfo is None:
            return v.replace(tzinfo=timezone.utc)
        return v