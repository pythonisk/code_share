"""Role schemas used by API responses."""

from datetime import datetime
from typing import List

from pydantic import BaseModel, ConfigDict


class PermissionSchema(BaseModel):
    """Public permission schema."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    description: str | None = None


class RoleResponse(BaseModel):
    """Public role response schema."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    description: str | None = None
    created_at: datetime
    permissions: List[PermissionSchema] = []
