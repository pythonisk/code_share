"""UseCase schemas used by API responses."""

from typing import List, Optional

from pydantic import BaseModel, ConfigDict


class UseCaseCreateRequest(BaseModel):
    """Request body for creating a new use case tile.

    ``premium`` is optional and accepts permissive truthy spellings
    ("Yes"/"No", "true"/"false", "1"/"0"). When omitted the use case is
    created as non-premium for backward compatibility.
    """

    name: str
    archetype: str
    role: str | None = None
    task: str
    category: str | None = None
    premium: str | None = None


class CategoryCreateRequest(BaseModel):
    """Request body for registering a shared category (skill)."""

    name: str


class UseCaseCreateResponse(BaseModel):
    """Created use case tile returned to the UI."""

    archetype: str
    usecaseid: str
    name: str
    account: str | None = None
    task: str = ""
    role: str = ""
    premium: str | None = "Yes"
    category: str | None = None
    agents_involved: str | None = None
    flow_of_agents: str | None = None
    dag: str | None = None
    loop_config: int | None = None
    chat_usecase: str | None = None



class UseCaseResponse(BaseModel):
    """Use case metadata for one archetype.

    List endpoints filter by tier using the ``premium_mode`` query parameter
    (``non_premium`` by default, or ``premium``). The ``premium`` field below
    reflects the stored tier for each returned use case.
    """

    usecaseid: str = ""
    name: str = ""
    account: str | None = None
    task: str = ""
    role: str = ""
    premium: str | None = None
    category: str | None = None
    agents_involved: str | None = None
    flow_of_agents: str | None = None
    dag: str | None = None
    loop_config: int | None = None
    chat_usecase: str | None = None


class UseCaseWithArchetypeResponse(UseCaseResponse):
    """Use case metadata including its archetype, for cross-archetype listings."""

    archetype: str | None = None


class PaginatedUseCasesResponse(BaseModel):
    """Paginated list of use cases across all archetypes."""

    items: list[UseCaseWithArchetypeResponse]
    page: int
    page_size: int
    total: int
    total_pages: int


class UseCaseAgentPromptResponse(BaseModel):
    """Agent + prompt details attached to a use case."""

    prompt_id: int | None = None
    agent_id: str = ""
    agent_name: str = ""
    role: str = ""
    agent_type: str | None = None
    prompt_file_path: str | None = None
    prompt: str | None = None
    inputs: str = ""
    output: str = ""
    agent_actions: str | None = None
    output_validators: str = ""
    guardrails: str = ""
    mcp_tools: str = ""
    local_tools: str = ""
    depends_on: str = ""


class UseCaseDetailResponse(BaseModel):
    """Use case details including involved agents and their prompts."""

    archetype: str
    usecase: str
    usecase_details: UseCaseResponse
    agents: List[UseCaseAgentPromptResponse]


class UsecaseInputSuggestionsRequest(BaseModel):
    archetype: str
    usecase: str
    provider: Optional[str] = None


class UsecaseInputSuggestionsResponse(BaseModel):
    llm_suggestion: str



class AgentOrderItem(BaseModel):
    """One agent entry in an ordered workflow.

    For agents already mapped to the use case (reordering): set ``agent_id``.
    For agents freshly dragged from the palette (duplication): set ``copy_from_agent_id``.
    """

    client_node_id: Optional[str] = None
    agent_id: Optional[str] = None
    copy_from_agent_id: Optional[str] = None
    is_canvas_draft: Optional[bool] = None
    agent_name: Optional[str] = None
    agent_type: Optional[str] = None
    role: Optional[str] = None
    inputs: Optional[str] = None
    output: Optional[str] = None
    actions: Optional[str] = None
    depends_on: Optional[str] = None
    mcp_tools: Optional[str] = None
    local_tools: Optional[str] = None
    prompt: Optional[str] = None
    model: Optional[str] = None
    execution_order: int


class UseCaseUpdateRequest(BaseModel):
    """Request body for updating an existing use case's metadata and/or agent order."""

    name: Optional[str] = None
    task: Optional[str] = None
    role: Optional[str] = None
    category: Optional[str] = None
    premium: Optional[str] = None
    dag: Optional[str] = None
    agents: Optional[List[AgentOrderItem]] = None


class UseCaseDuplicateRequest(BaseModel):
    """Request body for duplicating an existing use case into a target archetype."""

    name: str
    archetype: str


# ── Upload / prefill schemas ──────────────────────────────────────────────────

class UploadedUseCaseSpec(BaseModel):
    """Use-case metadata parsed from an uploaded JSON spec file."""

    model_config = ConfigDict(populate_by_name=True)

    usecaseid: str = ""
    name: str = ""
    task: str = ""
    role: str = ""
    category: str = ""


class UploadedAgentSpec(BaseModel):
    """Single agent entry parsed from an uploaded JSON spec file."""

    model_config = ConfigDict(populate_by_name=True)

    id: int = 0
    agent_id: str = ""
    prompt_id: Optional[int] = None
    archetype: str = ""
    use_case_id: str = ""
    role: str = ""
    agent_name: str = ""
    agent_type: str = "action_agent"
    inputs: str = "\u2014"
    output: str = "\u2014"
    actions: str = "\u2014"
    depends_on: str = "\u2014"
    mcp_tools: str = "\u2014"
    local_tools: str = "\u2014"
    prompt: str = ""


class UseCaseUploadResponse(BaseModel):
    """Validated spec returned to the UI after a JSON upload.

    No database writes are performed — parse-and-return only.
    """

    useCase: UploadedUseCaseSpec
    agents: List[UploadedAgentSpec]


class AgentDetailResponse(BaseModel):
    """Agent details for one use case."""

    archetype: str
    usecase: str
    agent: str
    details: UseCaseAgentPromptResponse


class ContextMapRequest(BaseModel):
    """Request body for the Context Map API."""

    session_id: str
    usecase_id: str
    archetype: str
    # Generic bag of runtime key-value pairs forwarded to action agents.
    # Examples:
    #   Databricks: {"databricks_workspace_url": "...", "databricks_token": "...", "databricks_workspace_path": "..."}
    #   Jira:       {"jira_project_key": "...", "jira_base_url": "..."}
    # These are injected into each action agent's reviewed_output at plan time.
    extra_context: Optional[dict] = None


class ContextMapResponse(BaseModel):
    """Response body for the Context Map API."""

    session_id: str
    archetype: str
    usecase_id: str
    context_map_output_path: str
    agents: List[dict]


# Backward-compatible aliases
PlanRequest = ContextMapRequest
PlanResponse = ContextMapResponse


class ReporterRunRequest(BaseModel):
    """Request body to execute the reporter agent."""

    archetype: str
    usecase_id: str
    session_id: str
    agent_outputs: dict
    metadata: Optional[dict] = None
    role: Optional[str] = None
    provider: Optional[str] = None

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "archetype": "Customer Proposed Use Cases",
                    "usecase_id": "UC001",
                    "session_id": "session-123",
                    "agent_outputs": {
                        "agent_1": "Output from agent 1",
                        "agent_2": "Output from agent 2"
                    },
                    "metadata": {
                        "usecase": "My Use Case",
                        "total_agents": 2
                    },
                    "role": "Business Analyst",
                    "provider": None
                }
            ]
        }
    )


class ReporterRunResponse(BaseModel):
    """Response from executing the reporter agent."""

    session_id: str
    archetype: str
    usecase_id: str
    reporter_output_path: str
    role: Optional[str] = None


class QualityAgentRequest(BaseModel):
    """
    Request body for the Quality Agent API.
    Accepts the report markdown (as string) and optional role/context.
    """
    session_id: str
    archetype: str
    usecase_id: str
    report: str
    role: Optional[str] = None
    provider: Optional[str] = None

class QualityAgentResponse(BaseModel):
    session_id: str
    archetype: str
    usecase_id: str
    quality_output_path: str
    role: Optional[str] = None


# Canonical names used by the API endpoint.
QualityRunRequest = QualityAgentRequest
QualityRunResponse = QualityAgentResponse
