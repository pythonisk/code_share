"""Pydantic schemas for MCP credential request validation and response serialisation."""

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field, field_validator


class McpCredentialCreate(BaseModel):
    """Schema for creating MCP credentials."""

    server_name: str = Field(..., min_length=1, max_length=100, description="MCP server name")
    credentials: dict[str, Any] = Field(..., description="Credential fields as key-value pairs")
    expires_at: datetime | None = Field(None, description="Credential expiration timestamp")
    server_metadata: dict[str, Any] | None = Field(None, description="Non-sensitive server metadata")
    is_global_default: bool = Field(False, description="Set as global default (admin only)")

    @field_validator("server_name")
    @classmethod
    def validate_server_name(cls, v: str) -> str:
        """Validate server name format."""
        if not v.replace("-", "").replace("_", "").isalnum():
            raise ValueError("Server name must contain only alphanumeric characters, hyphens, and underscores")
        return v

    @field_validator("credentials")
    @classmethod
    def validate_credentials(cls, v: dict[str, Any]) -> dict[str, Any]:
        """Validate credentials dictionary."""
        if not v:
            raise ValueError("Credentials cannot be empty")
        return v


class McpCredentialUpdate(BaseModel):
    """Schema for updating MCP credentials."""

    credentials: dict[str, Any] | None = Field(None, description="Updated credential fields")
    expires_at: datetime | None = Field(None, description="Updated expiration timestamp")
    server_metadata: dict[str, Any] | None = Field(None, description="Updated server metadata")
    is_active: bool | None = Field(None, description="Active status")

    @field_validator("credentials")
    @classmethod
    def validate_credentials(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        """Validate credentials dictionary."""
        if v is not None and not v:
            raise ValueError("Credentials cannot be empty if provided")
        return v


class McpCredentialResponse(BaseModel):
    """Schema for MCP credential response (without sensitive data)."""

    id: int
    user_id: int
    mcp_server_name: str
    is_active: bool
    validation_status: str
    last_validation_at: datetime | None
    last_accessed_at: datetime | None
    access_count: int
    expires_at: datetime | None
    credential_version: int
    server_metadata: dict[str, Any] | None
    created_at: datetime
    updated_at: datetime
    is_global: bool = False  # True if using global default credentials (admin-managed)

    class Config:
        from_attributes = True

    @field_validator("server_metadata", mode="before")
    @classmethod
    def parse_server_metadata(cls, v: Any) -> dict[str, Any] | None:
        """Parse server_metadata from JSON string if stored as text."""
        if isinstance(v, str):
            import json
            return json.loads(v)
        return v


class McpCredentialWithSecrets(McpCredentialResponse):
    """Schema for MCP credential with decrypted secrets (admin only)."""

    credentials: dict[str, Any]
    is_global: bool = False  # True if using global default credentials (admin-managed)


class McpCredentialValidate(BaseModel):
    """Schema for credential validation request."""

    server_name: str = Field(..., min_length=1, max_length=100)


class McpCredentialValidationResult(BaseModel):
    """Schema for validation result."""

    server_name: str
    is_valid: bool
    validation_message: str
    validation_status: str
    checked_at: datetime


class McpToolInfo(BaseModel):
    """Schema for a single MCP tool."""

    name: str
    description: str


class McpToolsListResponse(BaseModel):
    """Schema for tools discovered from an MCP server."""

    server_name: str
    connected: bool
    tools: list[McpToolInfo]
    tool_count: int
    error: str | None = None


class McpTestConnectionRequest(BaseModel):
    """Schema for inline (pre-save) test connection request."""

    server_name: str
    credentials: dict[str, str]


class McpTestConnectionResult(BaseModel):
    """Schema for test connection response."""

    server_name: str
    connected: bool
    latency_ms: int
    message: str
    auth_method: str
    server_info: dict[str, Any] | None = None


class McpProcessInfo(BaseModel):
    """Schema for MCP process information."""

    process_id: str
    server_name: str
    state: str
    created_at: datetime
    last_accessed_at: datetime
    access_count: int
    uptime_seconds: float


class McpServerDefinition(BaseModel):
    """Schema for MCP server definition from registry."""

    server_name: str
    display_name: str
    description: str
    transport: str
    required_fields: list[str]
    optional_fields: list[str]
    field_descriptions: dict[str, str]
    validation_config: dict[str, Any] | None = None
    connection_config: dict[str, Any] | None = None
    resource_limits: dict[str, Any] | None = None
    has_global_credentials: bool = False
    is_global: bool = False


class McpServerListResponse(BaseModel):
    """Schema for listing available MCP servers."""

    servers: list[McpServerDefinition]
    total: int


class McpStatistics(BaseModel):
    """Schema for MCP process manager statistics."""

    total_processes: int
    active_users: int
    state_counts: dict[str, int]
    avg_uptime_seconds: float
    max_connections_per_user: int
    idle_timeout_seconds: int


# ============================================================================
# MCP Discovery Schemas
# ============================================================================


class McpDiscoveryUrlRequest(BaseModel):
    """Schema for registering MCP server from URL."""

    url: str = Field(..., description="Remote MCP server URL")
    display_name: str = Field(
        ..., description="User-friendly display name"
    )
    auth_type: str = Field(
        "none", description="Auth type: none, api_key, bearer, basic, custom_header"
    )
    auth_credentials: dict[str, Any] | None = Field(
        None, description="Auth credentials (e.g., {header_name, header_value} or {token})"
    )
    required_credentials: dict[str, Any] | None = Field(
        None, description="Additional credential/env key definitions for UI"
    )
    is_global: bool = Field(
        False, description="Register as global server (MCP admin only)"
    )


class McpDiscoveryNpmRequest(BaseModel):
    """Schema for discovering MCP server from npm package."""

    package_name: str = Field(..., description="npm package identifier")
    display_name: str | None = Field(
        None, description="User-friendly display name"
    )
    runner_type: str | None = Field(
        None, description="Runner command: 'npx' (default) or 'uvx'"
    )
    custom_args: list[str] | None = Field(
        None, description="Additional command-line arguments (e.g., [\"-y\"])"
    )
    env_vars: dict[str, str] | None = Field(
        None, description="Required environment variables and their descriptions"
    )
    required_credentials: dict[str, Any] | None = Field(
        None, description="Credential field definitions for UI"
    )
    is_global: bool = Field(
        False, description="Register as global server (MCP admin only)"
    )


class McpDiscoveryFileRequest(BaseModel):
    """Schema for registering custom uploaded Python file."""

    server_name: str = Field(..., min_length=1, max_length=100)
    description: str | None = Field(None, description="Server description")
    custom_args: list[str] | None = Field(
        None, description="Additional command-line arguments"
    )
    env_vars: dict[str, str] | None = Field(
        None, description="Environment variables required by the server"
    )
    required_credentials: dict[str, Any] | None = Field(
        None, description="Credential field definitions for UI"
    )
    is_global: bool = Field(
        False, description="Register as global server (MCP admin only)"
    )


class McpDiscoveryResult(BaseModel):
    """Schema for discovery result."""

    success: bool
    server_name: str | None = None
    display_name: str | None = None
    description: str | None = None
    transport: str | None = None
    auth_scheme: str | None = None
    tools_count: int = 0
    resources_count: int = 0
    prompts_count: int = 0
    status: str | None = None
    error: str | None = None
    error_type: str | None = None
    registry_id: int | None = None


class McpRegistryEntryResponse(BaseModel):
    """Schema for registry entry response."""

    id: int
    server_name: str
    display_name: str
    description: str | None
    transport: str
    base_url: str | None
    npm_package: str | None
    command: str | None
    auth_scheme: str
    category: str | None
    status: str
    is_global: bool
    is_public: bool
    created_by_user_id: int | None
    tools_count: int = 0
    resources_count: int = 0
    prompts_count: int = 0
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class McpRegistryListResponse(BaseModel):
    """Schema for listing registry entries."""

    servers: list[McpRegistryEntryResponse]
    total: int
    personal_count: int
    global_count: int
