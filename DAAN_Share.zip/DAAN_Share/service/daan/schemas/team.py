"""Pydantic schemas for Team management."""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator
import re


class TeamCreate(BaseModel):
    """Schema for creating a team."""

    name: str = Field(min_length=1, max_length=100)
    description: str | None = Field(default=None, max_length=255)
    virtual_key: str | None = Field(default=None, max_length=255)

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str) -> str:
        cleaned = value.strip()
        if not re.match(r"^[a-zA-Z0-9_\- ]+$", cleaned):
            raise ValueError("Team name can only contain letters, numbers, spaces, hyphens and underscores")
        return cleaned


class TeamUpdate(BaseModel):
    """Schema for updating a team."""

    name: str | None = Field(default=None, min_length=1, max_length=100)
    description: str | None = Field(default=None, max_length=255)
    virtual_key: str | None = Field(default=None, max_length=255)

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str | None) -> str | None:
        if value is None:
            return None
        cleaned = value.strip()
        if not re.match(r"^[a-zA-Z0-9_\- ]+$", cleaned):
            raise ValueError("Team name can only contain letters, numbers, spaces, hyphens and underscores")
        return cleaned


class TeamMemberResponse(BaseModel):
    """A single member entry within a team response."""

    model_config = ConfigDict(from_attributes=True)

    user_id: int
    username: str
    email: str
    joined_at: datetime


class TeamResponse(BaseModel):
    """Public team response schema."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    description: str | None
    is_default: bool
    has_virtual_key: bool
    member_count: int
    created_at: datetime
    updated_at: datetime


class TeamDetailResponse(TeamResponse):
    """Team response with full member list and decrypted virtual key (admin only)."""

    members: list[TeamMemberResponse] = []
    virtual_key: str | None = None


class TeamMemberAdd(BaseModel):
    """Payload to add a user to a team."""

    user_id: int
