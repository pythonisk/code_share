"""User schemas for request validation and response serialization."""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator
import re

from daan.schemas.role import RoleResponse


class UserCreate(BaseModel):
    """Schema for user registration."""

    username: str = Field(min_length=3, max_length=50)
    email: str = Field(min_length=5, max_length=255)
    firstname: str = Field(min_length=1, max_length=100)
    lastname: str = Field(min_length=1, max_length=100)
    password: str = Field(min_length=8, max_length=128)
    role: str | None = Field(default=None, description="Name of the assigned role (e.g., Viewer)")
    archetypes: list[str] = Field(default_factory=list, description="Names of archetypes to assign")
    team_ids: list[int] = Field(default_factory=list, description="IDs of teams to add the user to (global is always included automatically)")

    @field_validator("username")
    @classmethod
    def validate_username(cls, value: str) -> str:
        """Validate username format."""
        if not re.match(r"^[a-zA-Z0-9_.]+$", value):
            raise ValueError("Username can only contain a-z, A-Z, 0-9, _, and .")
        return value

    @field_validator("email")
    @classmethod
    def validate_email(cls, value: str) -> str:
        """Perform a lightweight email format check."""
        cleaned = value.strip()
        if "@" not in cleaned or "." not in cleaned.split("@")[-1]:
            raise ValueError("Invalid email format")
        return cleaned.lower()


class UserUpdate(BaseModel):
    """Schema for user profile updates."""

    email: str | None = Field(default=None, min_length=5, max_length=255)
    firstname: str | None = Field(default=None, min_length=1, max_length=100)
    lastname: str | None = Field(default=None, min_length=1, max_length=100)
    role: str | None = Field(default=None, description="Name of the assigned role (e.g., Developer)")
    archetypes: list[str] | None = Field(default=None, description="Names of archetypes to assign")

    @field_validator("email")
    @classmethod
    def validate_email(cls, value: str | None) -> str | None:
        """Validate email only when field is provided."""
        if value is None:
            return None
        cleaned = value.strip()
        if "@" not in cleaned or "." not in cleaned.split("@")[-1]:
            raise ValueError("Invalid email format")
        return cleaned.lower()


class UserArchetypeAssignmentResponse(BaseModel):
    """Schema for user-archetype assignment."""

    model_config = ConfigDict(from_attributes=True)
    archetype_id: int
    archetype_name: str
    access_level: str


class UserArchetypeAssignmentCreate(BaseModel):
    """Schema for creating a user-archetype assignment."""

    archetype_id: int
    access_level: str = "read"  # 'read' or 'edit'


class UserResponse(BaseModel):
    """Public user response schema (without password)."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    email: str
    firstname: str
    lastname: str
    last_login: datetime | None = None
    is_active: bool
    role: RoleResponse
    created_at: datetime
    updated_at: datetime
    assigned_archetypes: list[UserArchetypeAssignmentResponse] = []
    accessible_archetypes: list[str] = []


class PaginatedUsersResponse(BaseModel):
    """Paginated user listing response."""

    items: list[UserResponse]
    total: int
    page: int
    page_size: int
    total_pages: int


class UserInDB(BaseModel):
    """Internal schema that includes hashed password."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    email: str
    firstname: str
    lastname: str
    hashed_password: str
    role_id: int


class UserLogin(BaseModel):
    """Login payload using username/email and password."""

    username_or_email: str = Field(min_length=3, max_length=255)
    password: str = Field(min_length=8, max_length=128)


class Token(BaseModel):
    """JWT token response."""

    access_token: str
    token_type: str = "bearer"
    user_id: int
    username: str
    role: str


class TokenData(BaseModel):
    """JWT payload data extracted during verification."""

    user_id: int
    username: str
    role: str
