"""Data models for the deterministic publish-reconciliation engine.

These types are backend-agnostic: the reconciler computes a plan from a desired
state (parsed from approved content) and an existing state (recorded in the KG),
and adapters (ADO / Jira / Trello / …) execute the plan against a specific
external system.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class DesiredItem:
    """A single item that should exist in the external system after sync."""

    local_key: str
    title: str
    kind: str  # epic | issue | task | user_story | story | …
    description: str = ""
    parent_local_key: Optional[str] = None
    acceptance_criteria: list[str] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class ExistingItem:
    """An item already published in a previous run (from the KG)."""

    local_key: str
    title: str
    kind: str
    resource_key: str  # external id (e.g. ADO work-item id, Jira issue key)
    external_url: str = ""


@dataclass
class SyncAction:
    """One reconciliation step to apply."""

    op: str  # create | update | remove
    local_key: str
    title: str
    kind: str
    resource_key: str = ""  # for update / remove
    parent_local_key: Optional[str] = None
    reason: str = ""


@dataclass
class SyncPlan:
    actions: list[SyncAction] = field(default_factory=list)

    def counts(self) -> dict[str, int]:
        out = {"create": 0, "update": 0, "remove": 0}
        for a in self.actions:
            out[a.op] = out.get(a.op, 0) + 1
        return out


@dataclass
class SyncItemResult:
    local_key: str
    op: str
    title: str
    kind: str
    resource_type: str = ""  # e.g. ado_work_item, jira_issue, trello_card
    resource_key: str = ""
    external_url: str = ""
    type_name: str = ""  # actual external issue type (e.g. Epic, Story, Task, Bug)
    parent_local_key: str = ""
    parent_key: str = ""
    ok: bool = True
    error: str = ""


@dataclass
class SyncResult:
    results: list[SyncItemResult] = field(default_factory=list)

    def manifest_resources(self) -> list[dict[str, Any]]:
        """Build resource-manifest entries for items that still exist.

        Removed items are excluded so the KG manifest reflects the live state.
        Entries are ordered with the epic(s) first, then the remaining items in
        natural ascending order of their ``local_key`` (so ``story-2`` precedes
        ``story-10``).
        """
        resources: list[dict[str, Any]] = []
        for r in self.results:
            if r.op == "remove" or not r.ok or not r.resource_key:
                continue
            resources.append({
                "local_key": r.local_key,
                "title": r.title,
                "type": r.resource_type or "external_resource",
                "type_name": r.type_name,
                "kind": r.kind,
                "id": r.resource_key,
                "url": r.external_url,
                "parent_local_key": r.parent_local_key,
                "parent_key": r.parent_key,
            })

        _epic_kinds = {"epic", "feature"}

        def _natural(key: str) -> list[Any]:
            return [
                int(tok) if tok.isdigit() else tok
                for tok in re.split(r"(\d+)", str(key or "").lower())
            ]

        resources.sort(
            key=lambda res: (
                0 if str(res.get("kind") or "").strip().lower() in _epic_kinds else 1,
                _natural(res.get("local_key") or ""),
            )
        )
        return resources

    def summary(self) -> dict[str, int]:
        out = {"created": 0, "updated": 0, "removed": 0, "failed": 0}
        for r in self.results:
            if not r.ok:
                out["failed"] += 1
            elif r.op == "create":
                out["created"] += 1
            elif r.op == "update":
                out["updated"] += 1
            elif r.op == "remove":
                out["removed"] += 1
        return out
