"""Parse the desired publish state from approved content.

The upstream story-generator emits a JSON object like::

    {"stories": [
        {"id": "EPIC_001", "title": "...", "type": "Epic", "description": "..."},
        {"id": "ITEM_001", "epic": "<parent epic title>", "title": "...",
         "type": "Issue", "description": "...", "acceptance_criteria": [...]}
    ]}

This module converts that (or, as a fallback, the ``EPIC_START`` /
``USER_STORY_START`` marker format) into a list of :class:`DesiredItem` with
stable, content-derived ``local_key`` values so the same item maps to the same
external resource across re-runs.
"""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any

from daan.publish.models import DesiredItem

_EPIC_KINDS = {"epic", "feature"}


def stable_local_key(prefix: str, identity: str) -> str:
    """Deterministic, content-derived key (shared with agent_runner Phase 2)."""
    digest = hashlib.sha1((identity or "").strip().lower().encode("utf-8")).hexdigest()[:10]
    return f"{prefix}-{digest}"


def _kind_prefix(kind: str) -> str:
    """Map a kind to a local_key prefix that reflects the item TYPE."""
    k = (kind or "").strip().lower()
    if k in _EPIC_KINDS:
        return "epic"
    if k in {"bug", "defect"}:
        return "bug"
    if k in {"task", "subtask", "sub_task", "sub-task"}:
        return "task"
    return "story"


def _local_key_for(story: dict[str, Any], prefix: str, title: str) -> str:
    """Stable identity for a story, always prefixed with its actual kind.

    The generator often labels every item with the same token (e.g. ``STORY_1``
    for epics and bugs too). To keep the published ``local_key`` meaningful, the
    key is always built as ``<kind>-<suffix>`` where the suffix is taken from the
    generator id (leading type token stripped) or, failing that, a hash of the
    title. This makes epics/bugs/tasks distinguishable instead of all reading
    like stories, while staying stable across re-runs.
    """
    ext_id = str(story.get("id") or story.get("local_key") or "").strip()
    if ext_id:
        # Drop a leading alpha type-token (STORY_, EPIC-, US ) and reuse the
        # remaining identifier as a stable suffix under the kind-derived prefix.
        suffix = re.sub(r"^[A-Za-z]+[-_ ]*", "", ext_id).strip().strip("-_").lower()
        if not suffix:
            suffix = hashlib.sha1(ext_id.lower().encode("utf-8")).hexdigest()[:10]
        return f"{prefix}-{suffix}"
    return stable_local_key(prefix, title)


_STORY_LIST_KEYS = (
    "epics",
    "features",
    "stories",
    "user_stories",
    "items",
    "work_items",
    "tasks",
    "subtasks",
    "sub_tasks",
    "bugs",
    "defects",
)


def _iter_balanced_json(text: str):
    """Yield every balanced top-level ``{...}`` / ``[...]`` substring in text.

    String contents (and escaped quotes) are respected so braces inside string
    values do not throw off the depth count.
    """
    n = len(text)
    i = 0
    while i < n:
        ch = text[i]
        if ch in "{[":
            close = "}" if ch == "{" else "]"
            depth = 0
            in_str = False
            esc = False
            j = i
            while j < n:
                c = text[j]
                if in_str:
                    if esc:
                        esc = False
                    elif c == "\\":
                        esc = True
                    elif c == '"':
                        in_str = False
                else:
                    if c == '"':
                        in_str = True
                    elif c == ch:
                        depth += 1
                    elif c == close:
                        depth -= 1
                        if depth == 0:
                            yield text[i:j + 1]
                            break
                j += 1
            i = j + 1
        else:
            i += 1


def _iter_json_story_lists(text: str):
    """Yield story lists from every JSON object/array embedded in the text.

    Handles raw JSON, fenced JSON, and JSON embedded after header lines (e.g.
    the ``--- Output from AGENT_x ---`` wrappers that ``run_action_agents_async``
    prepends) by scanning for balanced brace/bracket regions and parsing each.
    """
    for cand in _iter_balanced_json(text):
        try:
            data = json.loads(cand)
        except (ValueError, TypeError):
            continue
        if isinstance(data, dict):
            # A single object may split its items across several arrays (e.g.
            # separate "stories", "tasks", "bugs" and "epics" lists). Merge all
            # recognized item arrays into ONE list so every item is captured and
            # parent/epic linking works across them. Yielding each array
            # separately would let _from_json return on the first non-empty one
            # and silently drop the rest (e.g. newly added tasks).
            merged: list[Any] = []
            for key in _STORY_LIST_KEYS:
                val = data.get(key)
                if isinstance(val, list) and val:
                    merged.extend(val)
            if merged:
                yield merged
        elif isinstance(data, list):
            yield data


def _from_json(text: str) -> list[DesiredItem]:
    for stories in _iter_json_story_lists(text):
        if not all(isinstance(s, dict) for s in stories):
            continue
        # First pass: find explicit epic items so children can reference them.
        epic_titles: dict[str, str] = {}  # normalized title -> local_key
        for s in stories:
            kind = str(s.get("type") or s.get("kind") or "").strip()
            if kind.lower() in _EPIC_KINDS:
                title = str(s.get("title") or "").strip()
                if title:
                    epic_titles[title.strip().lower()] = _local_key_for(s, "epic", title)

        # Second pass (fallback): the generator frequently omits an explicit
        # Epic item and instead tags each story with an ``epic`` name. Without a
        # matching Epic item those references resolve to nothing, so the epic is
        # never created and the stories are left with no parent. Synthesize an
        # Epic ``DesiredItem`` for every referenced epic name that has no
        # explicit item, so the epic is actually created and its stories link to
        # it. Preserves insertion order of first reference.
        synthesized: dict[str, DesiredItem] = {}  # normalized title -> epic item
        for s in stories:
            kind = str(s.get("type") or s.get("kind") or "").strip()
            if kind.lower() in _EPIC_KINDS:
                continue
            ref = str(s.get("epic") or s.get("parent") or "").strip()
            if not ref:
                continue
            norm = ref.lower()
            if norm in epic_titles or norm in synthesized:
                continue
            epic_key = stable_local_key("epic", ref)
            epic_titles[norm] = epic_key
            synthesized[norm] = DesiredItem(
                local_key=epic_key,
                title=ref,
                kind="epic",
                description="",
            )

        items: list[DesiredItem] = list(synthesized.values())
        seen: set[str] = {it.local_key for it in items}
        for s in stories:
            title = str(s.get("title") or "").strip()
            if not title:
                continue
            kind = str(s.get("type") or s.get("kind") or "issue").strip()
            is_epic = kind.lower() in _EPIC_KINDS
            local_key = _local_key_for(s, _kind_prefix(kind), title)
            if local_key in seen:
                continue
            seen.add(local_key)
            parent_local_key = None
            if not is_epic:
                parent_title = str(s.get("epic") or s.get("parent") or "").strip().lower()
                parent_local_key = epic_titles.get(parent_title)
                if parent_local_key is None and len(epic_titles) == 1:
                    parent_local_key = next(iter(epic_titles.values()))
            ac = s.get("acceptance_criteria")
            items.append(DesiredItem(
                local_key=local_key,
                title=title,
                kind=kind.lower().replace(" ", "_"),
                description=str(s.get("description") or ""),
                parent_local_key=parent_local_key,
                acceptance_criteria=[str(x) for x in ac] if isinstance(ac, list) else [],
                raw=s,
            ))
        if items:
            return items
    return []


def _from_markers(text: str) -> list[DesiredItem]:
    try:
        from daan.utils.transformations.userstory import (
            extract_epic_and_story_blocks,
            extract_epic_summary,
            extract_story_summary,
            extract_story_id,
        )
    except Exception:
        return []
    epic_block, story_blocks = extract_epic_and_story_blocks(text)
    if not epic_block and not story_blocks:
        return []
    items: list[DesiredItem] = []
    epic_key = None
    if epic_block:
        epic_title = extract_epic_summary(epic_block, "Epic")
        epic_key = stable_local_key("epic", epic_title)
        items.append(DesiredItem(local_key=epic_key, title=epic_title, kind="epic",
                                 description=epic_block))
    seen: set[str] = set()
    for i, block in enumerate(story_blocks):
        title = extract_story_summary(block, f"Story {i + 1}")
        # Prefer the block's stable ``Story ID`` (e.g. US-001) so the same story
        # maps to the same work item across re-runs even when the LLM rewords
        # its title. Falls back to a title hash only when no id is present.
        story_id = extract_story_id(block, "")
        lk = _local_key_for({"id": story_id} if story_id else {}, "story", title)
        if lk in seen:
            continue
        seen.add(lk)
        items.append(DesiredItem(local_key=lk, title=title, kind="user_story",
                                 description=block, parent_local_key=epic_key))
    return items


def parse_desired_items(reviewed_output: str) -> list[DesiredItem]:
    """Return the desired publish state, or ``[]`` when nothing parseable."""
    text = reviewed_output or ""
    if not text.strip():
        return []
    items = _from_json(text)
    if items:
        return items
    return _from_markers(text)
