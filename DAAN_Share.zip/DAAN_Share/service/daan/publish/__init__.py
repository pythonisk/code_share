"""Deterministic publish-reconciliation engine (backend-agnostic).

Public entry point: :func:`daan.publish.service.sync_publish_target`.
"""

from daan.publish.service import get_adapter_for_agent, sync_publish_target

__all__ = ["sync_publish_target", "get_adapter_for_agent"]
