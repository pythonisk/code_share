"""Central, backend-agnostic reconciliation engine.

Given a desired state (parsed from approved content) and an existing state
(recorded in the KG from previous runs), compute the create / update / remove
actions needed. Matching is by stable ``local_key`` first, then by normalised
title (so items created under an older key scheme are updated, not duplicated
or deleted).

This logic is shared by every backend adapter — nothing here is specific to
Azure DevOps, Jira, Trello, or Databricks.
"""

from __future__ import annotations

import re

from daan.publish.models import DesiredItem, ExistingItem, SyncAction, SyncPlan


def _norm_title(title: str) -> str:
    """Normalise a title for cross-run matching (case/space/punctuation-insensitive)."""
    return re.sub(r"[^a-z0-9]+", " ", (title or "").strip().lower()).strip()


def _is_epic(kind: str) -> bool:
    return (kind or "").strip().lower() in {"epic", "feature"}


def reconcile(desired: list[DesiredItem], existing: list[ExistingItem]) -> SyncPlan:
    """Compute the reconciliation plan.

    - desired matched to existing (by local_key or title) → ``update``
    - desired with no match                              → ``create``
    - existing with no matching desired                 → ``remove``

    Parents (epics) are ordered before children for creates, and children
    before parents for removes, so referential integrity holds when adapters
    apply the plan.
    """
    existing_by_lk: dict[str, ExistingItem] = {}
    existing_by_title: dict[str, ExistingItem] = {}
    for e in existing:
        if e.local_key:
            existing_by_lk.setdefault(e.local_key, e)
        nt = _norm_title(e.title)
        if nt:
            existing_by_title.setdefault(nt, e)

    matched_keys: set[str] = set()
    creates: list[SyncAction] = []
    updates: list[SyncAction] = []

    for d in desired:
        match = existing_by_lk.get(d.local_key)
        if match is None:
            match = existing_by_title.get(_norm_title(d.title))
        if match is not None and match.resource_key:
            matched_keys.add(match.resource_key)
            updates.append(SyncAction(
                op="update",
                local_key=d.local_key,
                title=d.title,
                kind=d.kind,
                resource_key=match.resource_key,
                parent_local_key=d.parent_local_key,
                reason="matched existing",
            ))
        else:
            creates.append(SyncAction(
                op="create",
                local_key=d.local_key,
                title=d.title,
                kind=d.kind,
                parent_local_key=d.parent_local_key,
                reason="new item",
            ))

    removes: list[SyncAction] = []
    for e in existing:
        if not e.resource_key or e.resource_key in matched_keys:
            continue
        removes.append(SyncAction(
            op="remove",
            local_key=e.local_key,
            title=e.title,
            kind=e.kind,
            resource_key=e.resource_key,
            reason="absent from desired state",
        ))

    # Order: epics/parents created first (children need a parent id); children
    # removed before epics.
    creates.sort(key=lambda a: 0 if _is_epic(a.kind) else 1)
    removes.sort(key=lambda a: 1 if _is_epic(a.kind) else 0)

    return SyncPlan(actions=creates + updates + removes)
