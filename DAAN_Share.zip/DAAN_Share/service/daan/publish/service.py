"""Orchestrator for deterministic publish reconciliation.

Selects a backend MCP server from the action agent's configured MCP target
(data-driven — no hardcoded agent ids/usecases), computes the reconciliation
plan from desired vs existing state, executes it by calling the backend's MCP
work-item tools, and returns a resource manifest in the same fenced
``daan-resources`` format the rest of the pipeline already captures into the KG.

All backend specifics live in the corresponding MCP server module under
``daan/mcp_servers`` (e.g. ``ado_mcp_server``). Adding Jira / Trello later =
add its MCP server module + one entry in ``_MCP_BACKENDS``.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Callable, Optional

from daan.publish.models import (
    DesiredItem,
    ExistingItem,
    SyncItemResult,
    SyncResult,
)
from daan.publish.parser import parse_desired_items
from daan.publish.reconciler import reconcile

logger = logging.getLogger(__name__)


def _ado_backend() -> dict[str, Any]:
    """Bundle of ADO work-item MCP tools.

    All ADO-specific logic lives in ``daan.mcp_servers.ado_mcp_server``; this
    just wires its tools to the generic create/update/remove operations the
    executor calls.
    """
    from daan.mcp_servers.ado_mcp_server import (
        AdoCreateWorkItemTool,
        AdoDeleteWorkItemTool,
        AdoUpdateWorkItemTool,
        ado_is_configured,
    )
    return {
        "name": "azure_devops_mcp",
        "resource_type": "ado_work_item",
        "is_configured": ado_is_configured,
        "create": lambda item, parent_id: AdoCreateWorkItemTool(
            title=item.title,
            kind=item.kind,
            description=item.description or "",
            acceptance_criteria=item.acceptance_criteria or [],
            parent_id=parent_id,
        ),
        "update": lambda item, resource_key, parent_id: AdoUpdateWorkItemTool(
            item_id=resource_key,
            title=item.title,
            description=item.description or "",
            acceptance_criteria=item.acceptance_criteria or [],
            parent_id=parent_id,
        ),
        "remove": lambda resource_key, title, kind, local_key: AdoDeleteWorkItemTool(
            item_id=resource_key,
        ),
    }


def _jira_backend() -> dict[str, Any]:
    """Bundle of Jira work-item MCP tools.

    All Jira-specific logic (credentials, issue-type mapping, epic linking)
    lives in ``daan.mcp_servers.jira_mcp_server``; this just wires its tools to
    the generic create/update/remove operations the executor calls. Epic-per-
    session linking is handled by the publish engine: it loads each session's
    prior resources from the KG and reconciles against them, so every story of a
    session is attached to that session's single epic.
    """
    from daan.mcp_servers.jira_mcp_server import (
        JiraCreateWorkItemTool,
        JiraDeleteWorkItemTool,
        JiraUpdateWorkItemTool,
        jira_is_configured,
    )
    return {
        "name": "jira_mcp",
        "resource_type": "jira_issue",
        "is_configured": jira_is_configured,
        "create": lambda item, parent_id: JiraCreateWorkItemTool(
            title=item.title,
            kind=item.kind,
            description=item.description or "",
            acceptance_criteria=item.acceptance_criteria or [],
            parent_id=parent_id,
        ),
        "update": lambda item, resource_key, parent_id: JiraUpdateWorkItemTool(
            item_id=resource_key,
            title=item.title,
            description=item.description or "",
            acceptance_criteria=item.acceptance_criteria or [],
            parent_id=parent_id,
            kind=item.kind,
        ),
        "remove": lambda resource_key, title, kind, local_key: JiraDeleteWorkItemTool(
            item_id=resource_key,
        ),
    }


# Data-driven backend selection: substrings matched against the agent's MCP
# server name(s) → a loader that returns the backend's MCP tool bundle.
_MCP_BACKENDS: list[tuple[tuple[str, ...], Callable[[], dict[str, Any]]]] = [
    (("azure-devops-mcp", "azure-devops", "ado-work", "ado_work"), _ado_backend),
    (("jira-mcp-server", "jira"), _jira_backend),
    # ("trello-mcp-server", "trello") -> _trello_backend,   (future)
]


def _agent_server_names(agent_cfg: dict[str, Any]) -> list[str]:
    raw = agent_cfg.get("mcp_tools") or agent_cfg.get("mcp_servers") or ""
    if isinstance(raw, list):
        names = [str(s).strip() for s in raw if str(s).strip()]
    else:
        cleaned = str(raw or "").strip().strip("[]")
        names = [s.strip() for s in cleaned.replace(";", ",").split(",") if s.strip()]
    return names


def get_adapter_for_agent(agent_cfg: dict[str, Any]) -> Optional[dict[str, Any]]:
    """Return the MCP tool bundle for this agent, or ``None`` if unsupported.

    Never raises — a backend whose MCP module fails to import is treated as
    unsupported so the caller can fall back to the LLM path.
    """
    server_names = [s.lower() for s in _agent_server_names(agent_cfg)]
    if not server_names:
        return None
    for needles, loader in _MCP_BACKENDS:
        if any(any(n in s for s in server_names) for n in needles):
            try:
                return loader()
            except Exception as exc:  # noqa: BLE001
                logger.warning("MCP backend load failed for %s: %s", needles, exc)
                return None
    return None


def _existing_from_kg(existing_resources: list[dict[str, Any]]) -> list[ExistingItem]:
    out: list[ExistingItem] = []
    for r in existing_resources or []:
        resource_key = str(r.get("resource_key") or r.get("id") or "").strip()
        if not resource_key:
            continue
        out.append(ExistingItem(
            local_key=str(r.get("local_key") or "").strip(),
            title=str(r.get("title") or "").strip(),
            kind=str(r.get("resource_kind") or r.get("kind") or "").strip(),
            resource_key=resource_key,
            external_url=str(r.get("external_url") or r.get("url") or "").strip(),
        ))
    return out


def _result_from_mcp(
    res: dict[str, Any],
    op: str,
    *,
    local_key: str,
    title: str,
    kind: str,
    resource_type: str,
    resource_key: str = "",
    parent_local_key: str = "",
    parent_key: str = "",
) -> SyncItemResult:
    """Map an MCP tool's ``{success, item_id, url, error}`` dict to a result."""
    res = res or {}
    if res.get("success"):
        return SyncItemResult(
            local_key=local_key, op=op, title=title, kind=kind,
            resource_type=resource_type,
            resource_key=str(res.get("item_id") or resource_key or ""),
            external_url=str(res.get("url") or ""),
            type_name=str(res.get("type") or ""),
            parent_local_key=parent_local_key or "",
            parent_key=parent_key or "",
            ok=True,
        )
    return SyncItemResult(
        local_key=local_key, op=op, title=title, kind=kind,
        resource_type=resource_type, resource_key=str(resource_key or ""),
        parent_local_key=parent_local_key or "",
        parent_key=parent_key or "",
        ok=False, error=str(res.get("error") or f"{op} failed"),
    )


def _execute_plan(plan, backend: dict[str, Any], desired: list[DesiredItem]) -> SyncResult:
    desired_by_key = {d.local_key: d for d in desired}
    resource_type = backend["resource_type"]
    # local_key -> external resource id, populated as items are created/updated,
    # so children can be linked to their parent.
    resolved_keys: dict[str, str] = {}
    # Pre-seed with the ids of items that already exist (update/remove actions
    # carry the matched resource_key). Without this, a NEW child created before
    # its already-existing parent's update action runs would get no parent link
    # (creates are ordered before updates), leaving it orphaned in the backend.
    for action in plan.actions:
        if action.resource_key:
            resolved_keys[action.local_key] = action.resource_key
    result = SyncResult()

    for action in plan.actions:
        item = desired_by_key.get(action.local_key)
        parent_key = None
        if item and item.parent_local_key:
            parent_key = resolved_keys.get(item.parent_local_key)

        if action.op == "create" and item is not None:
            res = backend["create"](item, parent_key)
            r = _result_from_mcp(
                res, "create", local_key=action.local_key, title=item.title,
                kind=item.kind, resource_type=resource_type,
                parent_local_key=item.parent_local_key or "", parent_key=parent_key or "",
            )
        elif action.op == "update" and item is not None:
            res = backend["update"](item, action.resource_key, parent_key)
            r = _result_from_mcp(
                res, "update", local_key=action.local_key, title=item.title,
                kind=item.kind, resource_type=resource_type, resource_key=action.resource_key,
                parent_local_key=item.parent_local_key or "", parent_key=parent_key or "",
            )
        elif action.op == "remove":
            res = backend["remove"](action.resource_key, action.title, action.kind, action.local_key)
            r = _result_from_mcp(
                res, "remove", local_key=action.local_key, title=action.title,
                kind=action.kind, resource_type=resource_type, resource_key=action.resource_key,
            )
        else:
            continue

        if r.ok and r.resource_key:
            resolved_keys[action.local_key] = r.resource_key
        result.results.append(r)
    return result


def _display_type(kind: str) -> str:
    """Fallback display type derived from an item's ``kind``."""
    k = (kind or "").strip().lower()
    if k in ("epic", "feature"):
        return "Epic"
    if k in ("user_story", "story"):
        return "Story"
    if k in ("bug", "defect"):
        return "Bug"
    if k in ("task", "subtask", "sub_task"):
        return "Task"
    return (kind or "Task").replace("_", " ").title()


def _platform_label(resource_type: str) -> str:
    rt = (resource_type or "").strip().lower()
    if rt == "jira_issue":
        return "Jira"
    if rt == "ado_work_item":
        return "Azure DevOps"
    return "the tracker"


def _manifest_text(
    resources: list[dict[str, Any]],
    summary: dict[str, int],
    backend: dict[str, Any],
    errors: Optional[list[dict[str, Any]]] = None,
) -> str:
    """Human-readable publish manifest.

    Display-only: the KG is persisted separately from the structured resources,
    so this intentionally omits machine fields (local_key/kind). Every item gets
    a sequential ``story_00N`` id (epic first = ``story_001``, then the rest).
    Jira additionally carries its external issue key; ADO does not.
    """
    resource_type = str(backend.get("resource_type") or "")
    is_jira = resource_type == "jira_issue"
    platform = _platform_label(resource_type)
    epic_kinds = {"epic", "feature"}

    # Sequential display id per item (epic first = story_001, then the rest).
    seq_by_local: dict[str, str] = {}
    for idx, r in enumerate(resources, 1):
        seq_by_local[str(r.get("local_key") or "")] = f"story_{idx:03d}"

    def _seq(r: dict[str, Any]) -> str:
        return seq_by_local.get(str(r.get("local_key") or ""), "")

    def _parent_seq(r: dict[str, Any]) -> str:
        return seq_by_local.get(str(r.get("parent_local_key") or ""), "")

    def _ext_key(r: dict[str, Any]) -> str:
        return str(r.get("id") or "")

    def _disp_type(r: dict[str, Any]) -> str:
        return str(r.get("type_name") or "").strip() or _display_type(r.get("kind"))

    def _summary_key(r: dict[str, Any]) -> str:
        # Jira shows its external key (e.g. KAN-54); ADO shows the sequential id.
        return _ext_key(r) if is_jira else _seq(r)

    epics = [r for r in resources if str(r.get("kind") or "").strip().lower() in epic_kinds]
    children = [r for r in resources if str(r.get("kind") or "").strip().lower() not in epic_kinds]

    created = int(summary.get("created") or 0)
    updated = int(summary.get("updated") or 0)
    removed = int(summary.get("removed") or 0)
    failed = int(summary.get("failed") or 0)
    errors = errors or []

    # Truthful headline: never claim unconditional success. Reflect what
    # actually happened based on the reconciliation summary.
    if not resources and created == 0 and updated == 0:
        # Nothing landed in the tracker (every item was removed or failed).
        if failed > 0:
            headline = (
                f"Publish attempted on {platform}, but no resources were created "
                f"or updated — all {failed} item(s) failed."
            )
        else:
            headline = f"No resources were created or updated on {platform}."
    elif failed > 0:
        headline = (
            f"Publish attempted on {platform}: "
            f"{created} created, {updated} updated, {failed} failed."
        )
    else:
        headline = f"All user stories have been successfully published on {platform}."

    lines: list[str] = [
        headline,
        "",
    ]

    # Surface per-item failures so the report tells the truth about what broke.
    if failed > 0 and errors:
        lines += ["### Failed Items:", ""]
        for i, err in enumerate(errors, 1):
            local_key = str(err.get("local_key") or "").strip() or "(unknown)"
            op = str(err.get("op") or "").strip() or "publish"
            reason = str(err.get("error") or "").strip() or "unknown error"
            lines.append(f"{i}. **{op}** `{local_key}` — {reason}")
        lines.append("")

    lines += [
        "### Summary of Created Resources:",
        "",
    ]

    if not resources:
        lines += ["_No resources were created or updated._", ""]
    else:
        if epics:
            lines += ["#### Epic:", ""]
            for epic in epics:
                lines.append(
                    f"**Title**: {epic.get('title', '')} <br>"
                    f"**Key**: {_summary_key(epic)} <br>"
                    f"**Type**: {_disp_type(epic)} <br>"
                    f"**URL**: [View Epic in {platform}]({epic.get('url', '')})"
                )
                lines.append("")

        if children:
            lines += ["#### Stories, Tasks and Bugs:", ""]
            for i, item in enumerate(children, 1):
                lines.append(
                    f"{i}. **Title**: {item.get('title', '')} <br>"
                    f"**Key**: {_summary_key(item)} <br>"
                    f"**Type**: {_disp_type(item)} <br>"
                    f"**URL**: [View in {platform}]({item.get('url', '')})"
                )
                lines.append("")

    # Resource manifest (display). id = sequential story_00N; Jira also carries
    # its external key; parent references the epic's sequential id.
    manifest_entries: list[dict[str, Any]] = []
    for r in resources:
        is_epic = str(r.get("kind") or "").strip().lower() in epic_kinds
        entry: dict[str, Any] = {"id": _seq(r), "title": r.get("title", "")}
        if is_jira:
            entry["key"] = _ext_key(r)
        entry["type"] = _disp_type(r)
        entry["url"] = r.get("url", "")
        if not is_epic:
            entry["parent"] = _parent_seq(r)
        manifest_entries.append(entry)

    body = json.dumps({"resources": manifest_entries}, ensure_ascii=False, indent=2)
    lines += ["### Resource Manifest:", "```json", body, "```"]
    return "\n".join(lines)


def sync_publish_target(
    agent_cfg: dict[str, Any],
    reviewed_output: str,
    existing_resources: list[dict[str, Any]],
) -> Optional[dict[str, Any]]:
    """Run deterministic reconciliation for one action agent.

    Returns ``None`` when this agent has no supported MCP backend or the content
    does not parse into publishable items (callers then fall back to the LLM
    path). Otherwise returns a dict with the manifest text and diagnostics.
    Never raises — failures are captured per item.
    """
    agent_id = str(agent_cfg.get("agent_id") or "").strip() or "?"

    backend = get_adapter_for_agent(agent_cfg)
    if backend is None:
        logger.info(
            "Deterministic publish skipped for agent %s: no publish adapter for its "
            "MCP target (mcp_tools=%r). Falling back to the LLM pipeline.",
            agent_id, agent_cfg.get("mcp_tools") or agent_cfg.get("mcp_servers") or "",
        )
        return None

    ok, reason = backend["is_configured"]()
    if not ok:
        logger.warning(
            "Deterministic publish skipped for agent %s: backend '%s' not configured: %s",
            agent_id, backend["name"], reason,
        )
        return None

    desired = parse_desired_items(reviewed_output)
    if not desired:
        logger.warning(
            "Deterministic publish skipped for agent %s via %s: approved content did not "
            "parse into any publishable items (no recognized epics/stories/tasks/bugs "
            "arrays, or all were empty). Nothing was uploaded.",
            agent_id, backend["name"],
        )
        return None

    existing = _existing_from_kg(existing_resources)
    plan = reconcile(desired, existing)
    logger.info(
        "Publish reconcile plan (%s): %s desired, %s existing, actions=%s",
        backend["name"], len(desired), len(existing), plan.counts(),
    )

    result = _execute_plan(plan, backend, desired)
    summary = result.summary()
    resources = result.manifest_resources()
    logger.info("Publish sync result (%s): %s", backend["name"], summary)

    removed_keys = [
        r.resource_key for r in result.results
        if r.op == "remove" and r.ok and r.resource_key
    ]

    errors = [
        {"local_key": r.local_key, "op": r.op, "error": r.error}
        for r in result.results if not r.ok
    ]

    return {
        "adapter": backend["name"],
        "manifest_text": _manifest_text(resources, summary, backend, errors),
        "resources": resources,
        "summary": summary,
        "removed_keys": removed_keys,
        "errors": errors,
    }
