"""Package generator - creates ZIP file with all exported files."""

import json
import logging
import shutil
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
from zipfile import ZipFile

from daan.usecases.export.executor_template import ExecutorTemplateGenerator
from daan.usecases.export.schemas import UseCaseConfig

logger = logging.getLogger(__name__)


def _to_class_name(agent_id: str) -> str:
    """Convert agent_id to PascalCase class name."""
    return "".join(part.capitalize() for part in agent_id.replace("-", "_").split("_")) + "Agent"


def _resolved_basename(resolved_paths: List[Path], db_file_path: str) -> str:
    """Return the actual bundled filename for a tool, falling back to the DB path basename."""
    db_name = Path(db_file_path).name
    db_stem = Path(db_file_path).stem
    for p in (resolved_paths or []):
        if p.name == db_name or p.stem == db_stem:
            return p.name
    return resolved_paths[0].name if resolved_paths else db_name


class PackageGenerator:
    """Generate standalone package as ZIP file."""
    
    def __init__(self, config: UseCaseConfig):
        """Initialize generator."""
        self.config = config
        self.temp_dir = None
        self.package_dir = None
    
    def generate(self, tool_files: Dict[str, List[Path]], mcp_files: Dict[str, List[Path]]) -> Path:
        """
        Generate complete package.
        
        Args:
            tool_files: Mapping of agent_id to list of tool file paths
            mcp_files: Mapping of server_id to list of MCP file paths
        
        Returns:
            Path to generated ZIP file
        """
        self.temp_dir = Path(tempfile.mkdtemp())
        # Store resolved paths so _write_agents can emit the actual bundled filename
        self._resolved_tool_files: Dict[str, List[Path]] = tool_files

        try:
            # Create package directory structure
            package_name = f"usecase_{self.config.usecase_id}_v{self.config.version}"
            self.package_dir = self.temp_dir / package_name
            self.package_dir.mkdir(parents=True)
            
            logger.info(f"Creating package at {self.package_dir}")
            
            # Generate and write executor
            self._write_executor()
            
            # Create config directory and files
            self._write_configs()
            
            # Create agents directory and prompts
            self._write_agents()
            
            # Copy tool files
            self._write_tools(tool_files)
            
            # Copy MCP server files
            self._write_mcp_servers(mcp_files)
            
            # Create environment template
            self._write_env_template()
            
            # Generate requirements.txt
            self._write_requirements()
            
            # Generate README
            self._write_readme()
            
            # Create ZIP file
            zip_path = self._create_zip()
            
            logger.info(f"Package generated successfully: {zip_path}")
            return zip_path
        
        finally:
            # Cleanup temp directory
            if self.temp_dir and self.temp_dir.exists():
                shutil.rmtree(self.temp_dir)
    
    def _write_executor(self):
        """Generate and write executor_main.py."""
        generator = ExecutorTemplateGenerator()
        executor_code = generator.generate(self.config)
        
        executor_file = self.package_dir / 'executor_main.py'
        with open(executor_file, 'w', encoding='utf-8') as f:
            f.write(executor_code)
        
        # Make executable on Unix
        executor_file.chmod(0o755)
        logger.info("Written executor_main.py")
    
    def _write_configs(self):
        """Write configuration files."""
        config_dir = self.package_dir / 'config'
        config_dir.mkdir(parents=True, exist_ok=True)
        
        # Usecase config
        usecase_config = self._serialize_usecase_config()
        with open(config_dir / 'usecase_config.json', 'w', encoding='utf-8') as f:
            json.dump(usecase_config, f, indent=2)
        
        # LLM configs
        llm_configs = self._serialize_llm_configs()
        with open(config_dir / 'llm_config.json', 'w', encoding='utf-8') as f:
            json.dump(llm_configs, f, indent=2)
        
        # MCP mapping (agent → server list)
        mcp_mapping = self._serialize_mcp_mapping()
        with open(config_dir / 'mcp_mapping.json', 'w', encoding='utf-8') as f:
            json.dump(mcp_mapping, f, indent=2)

        # Bundle mcp_servers_registry.yml so executor can start/connect MCP servers at runtime
        mcp_registry_src = Path(__file__).resolve().parents[4] / 'config' / 'mcp_servers_registry.yml'
        if mcp_registry_src.exists():
            shutil.copy2(mcp_registry_src, config_dir / 'mcp_servers_registry.yml')
            logger.info("Bundled mcp_servers_registry.yml")

        logger.info("Written configuration files")
    
    def _write_agents(self):
        """Write agent configurations and prompts."""
        agents_dir = self.package_dir / 'agents'
        agents_dir.mkdir(parents=True, exist_ok=True)
        
        for agent in self.config.agents:
            agent_dir = agents_dir / agent.agent_id
            agent_dir.mkdir(parents=True, exist_ok=True)
            
            llm_cfg = self.config.llm_configs.get(agent.agent_id)
            
            # 1. prompt.json - structured prompt data
            prompt_data = {
                'agent_id': agent.agent_id,
                'prompt': agent.prompt,
                'role': agent.role,
                'instructions': agent.instructions,
                'expected_outputs': agent.expected_outputs,
            }
            with open(agent_dir / 'prompt.json', 'w', encoding='utf-8') as f:
                json.dump(prompt_data, f, indent=2)
            
            # 2. prompt.txt - plain text prompt for easy reading/editing
            with open(agent_dir / 'prompt.txt', 'w', encoding='utf-8') as f:
                f.write(f"AGENT: {agent.agent_id}\n")
                f.write(f"ROLE: {agent.role or ''}\n")
                f.write(f"{'=' * 60}\n\n")
                f.write(f"INSTRUCTIONS:\n{agent.instructions or ''}\n\n")
                f.write(f"PROMPT:\n{agent.prompt or ''}\n\n")
                if agent.expected_outputs:
                    f.write(f"EXPECTED OUTPUT:\n{agent.expected_outputs}\n")
            
            # 3. agent_config.json - agent metadata and LLM settings
            agent_config_data = {
                'agent_id': agent.agent_id,
                'role': agent.role,
                'instructions': agent.instructions,
                'expected_outputs': agent.expected_outputs,
                'llm': {
                    'model': llm_cfg.model if llm_cfg else 'gpt-4o',
                    'provider': llm_cfg.provider if llm_cfg else 'azure_openai',
                    'temperature': llm_cfg.temperature if llm_cfg else 0.7,
                    'max_tokens': llm_cfg.max_tokens if llm_cfg else 16384,
                } if llm_cfg else {},
                'tools': [
                    {
                        'tool_name': t.tool_name,
                        'file_path': _resolved_basename(
                            self._resolved_tool_files.get(agent.agent_id, []), t.file_path
                        ),
                        'method_name': t.method_name or 'run',
                    }
                    for t in (self.config.agent_tools or {}).get(agent.agent_id, [])
                ],
                'mcp_servers': (self.config.agent_mcp_mappings or {}).get(agent.agent_id, {}).mcp_servers
                    if (self.config.agent_mcp_mappings or {}).get(agent.agent_id) else [],
                'agent_type': agent.agent_type,
            }
            with open(agent_dir / 'agent_config.json', 'w', encoding='utf-8') as f:
                json.dump(agent_config_data, f, indent=2)
            
            # 4. agent.py - standalone agent class
            with open(agent_dir / 'agent.py', 'w', encoding='utf-8') as f:
                f.write(self._generate_agent_py(agent, llm_cfg))
        
        logger.info("Written agent configurations")
    
    def _generate_agent_py(self, agent, llm_cfg) -> str:
        """Generate a standalone agent.py class for individual agent execution."""
        model = llm_cfg.model if llm_cfg else 'gpt-4o'
        provider = llm_cfg.provider if llm_cfg else 'azure_openai'
        temperature = llm_cfg.temperature if llm_cfg else 0.7
        max_tokens = llm_cfg.max_tokens if llm_cfg else 16384
        
        # Safely escape the prompt for embedding in Python source
        safe_prompt = (agent.prompt or '').replace('\\', '\\\\').replace('"""', '\\"\\"\\"')
        safe_instructions = (agent.instructions or '').replace('\\', '\\\\').replace('"""', '\\"\\"\\"')
        safe_role = (agent.role or 'Agent').replace('"', '\\"')
        
        agent_class = _to_class_name(agent.agent_id)
        
        return f'''#!/usr/bin/env python3
"""
Standalone agent: {agent.agent_id}
Role: {agent.role or "Agent"}

Generated by DAAN Export. Run independently or import into other scripts.
"""

import json
import os
import sys
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv

load_dotenv()


AGENT_ID = "{agent.agent_id}"
AGENT_ROLE = "{safe_role}"

PROMPT_TEMPLATE = """{safe_prompt}"""

INSTRUCTIONS = """{safe_instructions}"""

LLM_CONFIG = {{
    "model": "{model}",
    "provider": "{provider}",
    "temperature": {temperature},
    "max_tokens": {max_tokens},
}}


class {agent_class}:
    """
    Standalone agent class for {agent.agent_id}.
    Role: {agent.role or "Agent"}
    """

    def __init__(self, model: Optional[str] = None, temperature: Optional[float] = None):
        self.model = model or LLM_CONFIG["model"]
        self.temperature = temperature or LLM_CONFIG["temperature"]
        self.max_tokens = LLM_CONFIG["max_tokens"]

    def run(self, user_input: str, context: Optional[str] = None) -> str:
        """
        Execute this agent with the given input.

        Args:
            user_input: The input to process
            context: Optional context from a previous agent

        Returns:
            Agent response string
        """
        import litellm

        messages = [
            {{
                "role": "system",
                "content": f"You are {{AGENT_ROLE}}.\\n\\n{{INSTRUCTIONS}}"
            }},
        ]

        if context:
            messages.append({{"role": "assistant", "content": f"Previous context:\\n{{context}}"}})

        try:
            prompt_content = PROMPT_TEMPLATE.format(input=user_input)
        except KeyError:
            prompt_content = f"{{PROMPT_TEMPLATE}}\\n\\nInput: {{user_input}}"

        messages.append({{"role": "user", "content": prompt_content}})

        response = litellm.completion(
            model=self.model,
            messages=messages,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )

        return response.choices[0].message.content

    def run_and_save(self, user_input: str, output_file: str, context: Optional[str] = None) -> str:
        """Run agent and save result to a JSON file."""
        result = self.run(user_input, context)
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump({{"agent_id": AGENT_ID, "input": user_input, "output": result}}, f, indent=2)
        return result


def _load_input_file(file_path: str) -> str:
    """Load input from various file formats and return as string for the agent."""
    from pathlib import Path
    ext = Path(file_path).suffix.lower()
    
    if ext == '.json':
        with open(file_path, encoding="utf-8") as f:
            content = json.load(f)
            return content.get("input", str(content))
    
    elif ext == '.csv':
        try:
            import pandas as pd
            df = pd.read_csv(file_path)
            return df.to_string(index=False)
        except ImportError:
            with open(file_path, encoding="utf-8") as f:
                return f.read()
    
    elif ext in ['.xlsx', '.xls']:
        try:
            import pandas as pd
            df = pd.read_excel(file_path)
            return df.to_string(index=False)
        except ImportError:
            raise RuntimeError(f"pandas required for {{ext}} files: pip install pandas openpyxl")
    
    else:
        with open(file_path, encoding="utf-8", errors="ignore") as f:
            return f.read()


def _save_output(agent_id: str, user_input: str, result: str, output_path: str):
    """Save output in format determined by output_path extension."""
    from pathlib import Path
    ext = Path(output_path).suffix.lower()
    
    if ext in ('.xlsx', '.xls'):
        try:
            import pandas as pd, re
            lines = [l.strip() for l in result.splitlines() if l.strip()]
            numbered = [(m.group(1), m.group(2)) for l in lines
                        if (m := re.match(r"^(\\d+)[.)\\s]+(.+)$", l))]
            if numbered:
                rows = [{{"#": n, "User Story": t}} for n, t in numbered]
            else:
                rows = [{{"output": l}} for l in lines if l]
            pd.DataFrame(rows).to_excel(output_path, index=False)
        except ImportError:
            raise RuntimeError("pandas + openpyxl required: pip install pandas openpyxl")
    
    elif ext == '.csv':
        try:
            import pandas as pd, re
            lines = [l.strip() for l in result.splitlines() if l.strip()]
            numbered = [(m.group(1), m.group(2)) for l in lines
                        if (m := re.match(r"^(\\d+)[.)\\s]+(.+)$", l))]
            rows = [{{"#": n, "User Story": t}} for n, t in numbered] if numbered else [{{"output": l}} for l in lines if l]
            pd.DataFrame(rows).to_csv(output_path, index=False, encoding="utf-8")
        except ImportError:
            raise RuntimeError("pandas required: pip install pandas")
    
    elif ext == '.txt':
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(result)
    
    else:  # default JSON
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump({{"agent_id": agent_id, "input": user_input, "output": result}}, f, indent=2)


if __name__ == "__main__":
    import argparse
    from pathlib import Path

    parser = argparse.ArgumentParser(description=f"Run agent: {agent.agent_id}")
    parser.add_argument("--input", required=True, help="Input text or path (JSON/CSV/XLSX/text)")
    parser.add_argument("--output", help="Output file (.xlsx/.csv/.txt/.json). Auto-detected from input if omitted.")
    parser.add_argument("--context", help="Context from previous agent (optional)")
    args = parser.parse_args()

    try:
        if os.path.isfile(args.input):
            user_input = _load_input_file(args.input)
            if not args.output:
                in_ext = Path(args.input).suffix.lower()
                args.output = "output.xlsx" if in_ext in (".xlsx", ".xls") else \\
                              "output.csv" if in_ext == ".csv" else "output.json"
        else:
            user_input = args.input
            if not args.output:
                args.output = "output.json"

        agent_instance = {agent_class}()
        result = agent_instance.run(user_input, args.context)

        _save_output(AGENT_ID, user_input, result, args.output)
        print(f"Result saved to {{args.output}}")

    except Exception as e:
        print(f"Error: {{e}}", file=sys.stderr)
        sys.exit(1)
'''

    def _write_tools(self, tool_files: Dict[str, List[Path]]):
        """Copy tool files to package."""
        if not tool_files or all(not files for files in tool_files.values()):
            return
        
        tools_dir = self.package_dir / 'tools'
        tools_dir.mkdir(parents=True, exist_ok=True)
        
        for agent_id, files in tool_files.items():
            if not files:
                continue
            
            agent_tools_dir = tools_dir / agent_id
            agent_tools_dir.mkdir(parents=True, exist_ok=True)
            
            for file_path in files:
                if file_path.exists():
                    import re as _re
                    target = agent_tools_dir / file_path.name
                    content = file_path.read_text(encoding='utf-8', errors='replace')
                    # Rewrite daan.* imports to flat local names — all deps are bundled in same dir
                    content = _re.sub(r'from\s+daan(?:\.\w+)*\.(\w+)\s+import', r'from \1 import', content)
                    target.write_text(content, encoding='utf-8')
                    logger.debug(f"Copied tool: {file_path.name}")
        
        logger.info("Copied tool files")
    
    def _write_mcp_servers(self, mcp_files: Dict[str, List[Path]]):
        """Copy MCP server Python files to flat mcp_servers/ directory."""
        if not mcp_files or all(not files for files in mcp_files.values()):
            return

        mcp_dir = self.package_dir / 'mcp_servers'
        mcp_dir.mkdir(parents=True, exist_ok=True)

        for server_id, files in mcp_files.items():
            for file_path in files:
                if file_path.exists():
                    shutil.copy2(file_path, mcp_dir / file_path.name)
                    logger.debug(f"Copied MCP server file: {file_path.name} ({server_id})")

        logger.info("Copied MCP server files")

    def _write_env_template(self):
        """Generate .env.template file."""
        from daan.usecases.export.secret_scanner import SecretScanner
        
        scanner = SecretScanner()
        required_vars = self._extract_env_vars()
        env_template = scanner.create_env_template(list(required_vars))
        
        with open(self.package_dir / '.env.template', 'w', encoding='utf-8') as f:
            f.write(env_template)
        
        logger.info("Generated .env.template")
    
    def _write_requirements(self):
        """Generate requirements.txt with dependencies."""
        base_deps = [
            'litellm>=1.0.0',
            'python-dotenv>=1.0.0',
            'pydantic>=2.0.0',
            'pandas>=1.0.0',
            'openpyxl>=3.0.0',
            'mcp>=1.0.0',             # MCP client for connecting to MCP servers
            'pyyaml>=6.0',            # Read mcp_servers_registry.yml at runtime
        ]

        with open(self.package_dir / 'requirements.txt', 'w', encoding='utf-8') as f:
            f.write('\n'.join(base_deps))
            f.write('\n')

        logger.info("Generated requirements.txt")
    
    def _write_readme(self):
        """Generate README.md with setup instructions."""
        readme = f'''# {self.config.usecase_name}

Standalone executor for the **{self.config.usecase_name}** use case.

Generated: {datetime.now().isoformat()}

## Overview

{self.config.description or 'No description provided.'}

## Setup Instructions

### 1. Extract Package
\\`\\`\\`bash
unzip usecase_{self.config.usecase_id}_v{self.config.version}.zip
cd usecase_{self.config.usecase_id}_v{self.config.version}/
\\`\\`\\`

### 2. Create Environment File
\\`\\`\\`bash
cp .env.template .env
\\`\\`\\`

### 3. Configure Credentials
Edit `.env` and fill in required API keys:
- OpenAI API Key (if using OpenAI models)
- Anthropic API Key (if using Claude models)
- Other provider keys as needed

### 4. Install Dependencies
\\`\\`\\`bash
pip install -r requirements.txt
\\`\\`\\`

### 5. Run Use Case
\\`\\`\\`bash
python executor_main.py --input sample.json --output result.json
\\`\\`\\`

## Input Format

The use case accepts input as any of:
- CSV file: `--input data.csv`
- Excel file: `--input data.xlsx`
- JSON file: `--input data.json`
- Plain text file: `--input data.txt`
- Multiple files: `--input file1.csv file2.xlsx`
- Interactive stdin (if no file specified)

## Configuration

All configurations are stored in the `config/` directory:
- `usecase_config.json` - Workflow orchestration
- `llm_config.json` - LLM provider settings
- `mcp_mapping.json` - MCP server configurations

## Agents

The following agents are executed in order:

{self._generate_agent_list()}

## Execution Flow

{self._generate_execution_flow()}

## Troubleshooting

### Missing API Keys
If you see authentication errors, check that `.env` is properly configured with valid API keys.

### Module Import Errors
Ensure all dependencies are installed: `pip install -r requirements.txt`

### Timeout Errors
If agents are timing out, increase timeout in `executor_main.py` or in `config/usecase_config.json`.

## Support

For issues or questions, refer to the DAAN documentation.

---
Generated by DAAN Export Feature v{self.config.version}
'''
        
        with open(self.package_dir / 'README.md', 'w', encoding='utf-8') as f:
            f.write(readme)
        
        logger.info("Generated README.md")
    
    def _create_zip(self) -> Path:
        """Create ZIP file from package directory."""
        # Write ZIP to a separate temp file OUTSIDE temp_dir so the finally
        # cleanup doesn't delete it before FileResponse can stream it.
        fd, zip_file = tempfile.mkstemp(suffix='.zip', prefix=f"{self.package_dir.name}_")
        import os
        os.close(fd)
        zip_path = Path(zip_file)
        
        with ZipFile(zip_path, 'w') as zipf:
            for file_path in self.package_dir.rglob('*'):
                if file_path.is_file():
                    arcname = file_path.relative_to(self.package_dir.parent)
                    zipf.write(file_path, arcname)
        
        logger.info(f"Created ZIP: {zip_path}")
        return zip_path
    
    def _serialize_usecase_config(self) -> Dict:
        """Serialize use case config to JSON-safe format."""
        agents = []
        for agent in self.config.agents:
            agents.append({
                'agent_id': agent.agent_id,
                'prompt': agent.prompt,
                'role': agent.role,
                'instructions': agent.instructions,
                'expected_outputs': agent.expected_outputs,
                'tools': [
                    {
                        'tool_name': t.tool_name,
                        'file_path': _resolved_basename(
                            self._resolved_tool_files.get(agent.agent_id, []), t.file_path
                        ),
                        'method_name': t.method_name or 'run',
                    }
                    for t in (self.config.agent_tools or {}).get(agent.agent_id, [])
                ],
                'mcp_servers': (self.config.agent_mcp_mappings or {}).get(agent.agent_id).mcp_servers
                    if (self.config.agent_mcp_mappings or {}).get(agent.agent_id) else [],
                'agent_type': agent.agent_type,
            })
        
        orchestration = []
        for step in self.config.orchestration:
            orchestration.append({
                'agent_id': step.agent_id,
                'step_index': step.step_index,
                'input_source': step.input_source,
                'input_key': step.input_key,
                'source_agent_id': step.source_agent_id,
                'output_key': step.output_key,
            })
        
        return {
            'usecase_id': self.config.usecase_id,
            'usecase_name': self.config.usecase_name,
            'version': self.config.version,
            'description': self.config.description,
            'agents': agents,
            'orchestration': orchestration,
            'input_schema': self.config.input_schema,
            'output_schema': self.config.output_schema,
            'output_mapping': self._build_output_mapping(),
        }
    
    def _serialize_llm_configs(self) -> Dict:
        """Serialize LLM configs, removing secrets."""
        result = {}
        for agent_id, config in self.config.llm_configs.items():
            result[agent_id] = {
                'model': config.model,
                'provider': config.provider,
                'temperature': config.temperature,
                'max_tokens': config.max_tokens,
                'top_p': config.top_p,
                'top_k': config.top_k,
                'presence_penalty': config.presence_penalty,
                'frequency_penalty': config.frequency_penalty,
            }
        return result
    
    def _serialize_mcp_mapping(self) -> Dict:
        """Serialize MCP mappings."""
        return {
            agent_id: {
                'mcp_servers': mapping.mcp_servers
            }
            for agent_id, mapping in self.config.agent_mcp_mappings.items()
        }
    
    def _extract_env_vars(self) -> set:
        """Extract required environment variables from configs."""
        vars_needed = set()
        
        # Add provider-specific vars
        for llm_config in self.config.llm_configs.values():
            provider = llm_config.provider.upper()
            if 'LITELLM' in provider:
                vars_needed.add('LITELLM_URL')
                vars_needed.add('LITELLM_API_KEY')
                vars_needed.add('LITELLM_PROXY_API_KEY')
                # LiteLLM often routes to Azure, so include those
                vars_needed.add('AZURE_OPENAI_API_KEY')
                vars_needed.add('AZURE_OPENAI_ENDPOINT')
            elif 'OPENAI' in provider:
                vars_needed.add('OPENAI_API_KEY')
            elif 'AZURE' in provider:
                vars_needed.add('AZURE_OPENAI_API_KEY')
                vars_needed.add('AZURE_OPENAI_ENDPOINT')
            elif 'ANTHROPIC' in provider:
                vars_needed.add('ANTHROPIC_API_KEY')
        
        # Add MCP env vars and credential keys (dynamic — works for any integration)
        import re as _re
        for mcp_config in self.config.mcp_servers:
            vars_needed.update(mcp_config.env_vars.keys())
            for k in mcp_config.config.get('credentials', {}).keys():
                vars_needed.add(k.upper())
            for env_val in mcp_config.config.get('env', {}).values():
                for ref in _re.findall(r'\$\{([^}]+)\}', str(env_val)):
                    vars_needed.add(ref)

        # Read env_mapping from registry to determine required env vars
        _registry_yml = Path(__file__).resolve().parents[4] / 'config' / 'mcp_servers_registry.yml'
        if _registry_yml.exists():
            try:
                import yaml as _yaml
                _full = (_yaml.safe_load(_registry_yml.read_text(encoding='utf-8')) or {}).get('servers', {})
                for mcp_config in self.config.mcp_servers:
                    _srv = _full.get(mcp_config.server_id, {})
                    for env_var in _srv.get('env_mapping', {}).values():
                        vars_needed.add(env_var)
            except Exception:
                pass
        
        return vars_needed
    
    def _build_output_mapping(self) -> Dict:
        """Build output mapping from last agent."""
        if not self.config.orchestration:
            return {}
        
        last_step = max(self.config.orchestration, key=lambda s: s.step_index)
        output_key = last_step.output_key or last_step.agent_id
        
        return {
            'result': {
                'source': output_key,
                'type': 'string'
            }
        }
    
    def _generate_agent_list(self) -> str:
        """Generate list of agents for README."""
        lines = []
        for agent in self.config.agents:
            lines.append(f"- **{agent.agent_id}**: {agent.role}")
        return '\n'.join(lines) if lines else 'No agents defined'
    
    def _generate_execution_flow(self) -> str:
        """Generate execution flow diagram for README."""
        if not self.config.orchestration:
            return 'No execution flow defined'
        
        sorted_steps = sorted(self.config.orchestration, key=lambda s: s.step_index)
        lines = []
        
        for step in sorted_steps:
            arrow = '↓' if step.step_index < len(self.config.orchestration) - 1 else '✓'
            lines.append(f"Step {step.step_index}: {step.agent_id} {arrow}")
        
        return '\n'.join(lines)
