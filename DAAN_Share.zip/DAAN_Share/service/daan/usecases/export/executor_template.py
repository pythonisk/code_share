"""Generates standalone executor for exported use case."""

import json
import logging
from datetime import datetime
from typing import Dict, List

from daan.usecases.export.schemas import UseCaseConfig

logger = logging.getLogger(__name__)


class ExecutorTemplateGenerator:
    """Generate standalone executor_main.py for exported use case."""
    
    def generate(self, config: UseCaseConfig) -> str:
        """
        Generate complete executor_main.py file content.
        
        Returns:
            Python code as string
        """
        timestamp = datetime.now().isoformat()
        
        code_parts = [
            self._header(timestamp),
            self._imports(),
            self._config_loader(),
            self._agent_executor(),
            self._mcp_manager(),
            self._workflow_orchestrator(),
            self._input_handler(),
            self._main_function(),
        ]
        
        return '\n\n'.join(code_parts)
    
    @staticmethod
    def _header(timestamp: str) -> str:
        """Generate file header."""
        return f'''#!/usr/bin/env python3
"""
Standalone executor for exported use case.

Generated: {timestamp}
This file executes the use case without requiring the DAAN platform.
"""

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Optional'''
    
    @staticmethod
    def _imports() -> str:
        """Generate import statements."""
        return '''
# Standard library imports
import logging
from dataclasses import dataclass, asdict
from enum import Enum

# Third-party imports (install with: pip install -r requirements.txt)
try:
    import litellm
    from dotenv import load_dotenv
except ImportError as e:
    print(f"Error: Required package not installed: {e}")
    print("Run: pip install -r requirements.txt")
    sys.exit(1)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)'''
    
    @staticmethod
    def _config_loader() -> str:
        """Generate configuration loader."""
        return '''

class ConfigLoader:
    """Load runtime configuration."""
    
    @staticmethod
    def load_env():
        """Load environment variables from .env file."""
        env_file = Path(__file__).parent / '.env'
        if env_file.exists():
            load_dotenv(env_file)
            logger.info("Loaded environment variables from .env")
        else:
            logger.warning(f".env file not found at {env_file}")
            logger.info("Please copy .env.template to .env and fill in required values")
    
    @staticmethod
    def load_config(config_type: str) -> Dict[str, Any]:
        """Load configuration file."""
        config_dir = Path(__file__).parent / 'config'
        config_file = config_dir / f'{config_type}.json'
        
        if not config_file.exists():
            raise FileNotFoundError(f"Config file not found: {config_file}")
        
        with open(config_file, 'r') as f:
            return json.load(f)
    
    @staticmethod
    def load_agent_prompt(agent_id: str) -> Dict[str, str]:
        """Load agent prompt and role."""
        agents_dir = Path(__file__).parent / 'agents'
        agent_file = agents_dir / agent_id / 'prompt.json'
        
        if not agent_file.exists():
            raise FileNotFoundError(f"Agent prompt not found: {agent_file}")
        
        with open(agent_file, 'r') as f:
            return json.load(f)


class InputValidator:
    """Validate input against schema."""
    
    @staticmethod
    def validate(input_data: Dict[str, Any], schema: Dict[str, Any]) -> bool:
        """
        Validate input against schema.
        
        Returns:
            True if valid, raises ValueError otherwise
        """
        # Basic schema validation
        if not isinstance(input_data, dict):
            raise ValueError("Input must be a dictionary")
        
        for key, prop_schema in schema.get('properties', {}).items():
            if prop_schema.get('required', False) and key not in input_data:
                raise ValueError(f"Required field missing: {key}")
            
            if key in input_data:
                value = input_data[key]
                expected_type = prop_schema.get('type', 'string')
                
                type_map = {
                    'string': str,
                    'number': (int, float),
                    'integer': int,
                    'boolean': bool,
                    'array': list,
                    'object': dict,
                }
                
                expected_python_type = type_map.get(expected_type)
                if expected_python_type and not isinstance(value, expected_python_type):
                    raise ValueError(
                        f"Field '{key}' has wrong type. Expected {expected_type}, got {type(value).__name__}"
                    )
        
        return True'''
    
    @staticmethod
    def _agent_executor() -> str:
        """Generate agent executor."""
        return '''

class AgentExecutor:
    """Execute a single agent, including tool calls."""
    
    def __init__(self, agent_id: str, agent_config: Dict[str, Any], llm_config: Dict[str, Any], data_dir=None):
        self.agent_id = agent_id
        self.agent_config = agent_config
        self.llm_config = llm_config
        self.data_dir = data_dir  # passed to tool constructors that declare a data_dir param
        self.logger = logging.getLogger(f"Agent[{agent_id}]")
    
    # ------------------------------------------------------------------
    # Tool loading
    # ------------------------------------------------------------------
    def _load_tools(self):
        """
        Dynamically load tool implementations from tools/{agent_id}/.
        Returns (tool_specs, tool_callables):
          - tool_specs: list of OpenAI-format tool dicts (for LLM)
          - tool_callables: dict of name -> callable (for execution)
        """
        import importlib.util, inspect, sys
        tool_refs = self.agent_config.get('tools') or []
        if not tool_refs:
            return [], {}
        
        tools_base = Path(__file__).parent / 'tools' / self.agent_id
        # Ensure bundled deps in tools dir are importable without daan.* prefix
        if str(tools_base) not in sys.path:
            sys.path.insert(0, str(tools_base))
        tool_specs = []
        tool_callables = {}
        
        for ref in tool_refs:
            tool_name = ref.get('tool_name', '')
            file_path = ref.get('file_path', '')
            method_name = ref.get('method_name') or 'run'
            
            # Locate the file inside the bundled tools directory
            candidate = tools_base / Path(file_path).name
            if not candidate.exists():
                self.logger.warning(f"Tool file not found: {candidate}")
                continue
            
            try:
                spec = importlib.util.spec_from_file_location(tool_name, candidate)
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
            except Exception as e:
                self.logger.warning(f"Failed to import tool {tool_name}: {e}")
                continue
            
            # Resolve callable: try method_name, then tool_name, then any function
            fn = getattr(mod, method_name, None) or getattr(mod, tool_name, None)

            # Handle Class.method pattern: method not at module level → instantiate class
            if fn is None and '.' in tool_name:
                class_part = tool_name.split('.')[0]
                tool_class = getattr(mod, class_part, None)
                if tool_class and isinstance(tool_class, type):
                    try:
                        # Inject data_dir if the constructor declares it — generic, no hardcoding
                        _init_params = inspect.signature(tool_class.__init__).parameters
                        _ctor_kw = {'data_dir': self.data_dir} if 'data_dir' in _init_params and self.data_dir else {}
                        instance = tool_class(**_ctor_kw)
                        fn = getattr(instance, method_name, None)
                    except Exception as ie:
                        self.logger.warning(f"Could not instantiate {class_part}: {ie}")

            if fn is None:
                fns = [v for v in vars(mod).values() if callable(v) and not getattr(v, '__name__', '').startswith('_')]
                fn = fns[0] if fns else None
            if fn is None:
                self.logger.warning(f"No callable found in tool {tool_name}")
                continue
            
            tool_callables[tool_name] = fn
            
            # Build OpenAI function schema by inspecting the signature
            try:
                sig = inspect.signature(fn)
                props, required = {}, []
                for pname, param in sig.parameters.items():
                    if pname in ('self', 'cls'):
                        continue
                    ann = param.annotation
                    ptype = 'string'
                    if ann in (int,):
                        ptype = 'integer'
                    elif ann in (float,):
                        ptype = 'number'
                    elif ann in (bool,):
                        ptype = 'boolean'
                    props[pname] = {'type': ptype, 'description': pname}
                    if param.default is inspect.Parameter.empty:
                        required.append(pname)
                schema = {'type': 'object', 'properties': props}
                if required:
                    schema['required'] = required
            except Exception:
                schema = {'type': 'object', 'properties': {}}
            
            tool_specs.append({
                'type': 'function',
                'function': {
                    'name': tool_name,
                    'description': (fn.__doc__ or f'Tool: {tool_name}').strip().split('\\n')[0],
                    'parameters': schema,
                }
            })
            self.logger.info(f"Loaded tool: {tool_name} ({method_name})")
        
        return tool_specs, tool_callables
    
    # ------------------------------------------------------------------
    # LLM call with tool-calling loop
    # ------------------------------------------------------------------
    def _call_llm(self, messages: list, tool_specs: list, tool_callables: dict,
                  litellm_url: str, litellm_key: str, gateway_model: str,
                  azure_key: str, azure_endpoint: str, azure_version: str, azure_deployment: str):
        """
        Call the LLM, execute any tool calls, and loop until a final text
        response is returned.  Mirrors DAAN runtime semantics exactly.
        """
        call_kwargs = dict(
            temperature=self.llm_config.get('temperature', 0.7),
            max_tokens=self.llm_config.get('max_tokens', 2000),
            timeout=60,
        )
        if tool_specs:
            call_kwargs['tools'] = tool_specs
            call_kwargs['tool_choice'] = 'auto'
        
        MAX_TOOL_ROUNDS = 10  # guard against infinite loops
        
        for _round in range(MAX_TOOL_ROUNDS):
            # --- choose provider ---
            try:
                if litellm_url:
                    response = litellm.completion(
                        model=gateway_model,
                        api_base=litellm_url,
                        api_key=litellm_key or 'no-key',
                        messages=messages,
                        **call_kwargs,
                    )
                else:
                    raise RuntimeError("LITELLM_URL not set")
            except Exception as primary_err:
                if azure_key and azure_endpoint:
                    self.logger.warning(
                        f"LiteLLM gateway failed ({primary_err}). Falling back to Azure OpenAI."
                    )
                    response = litellm.completion(
                        model=f"azure/{azure_deployment}",
                        api_key=azure_key,
                        api_base=azure_endpoint,
                        api_version=azure_version,
                        messages=messages,
                        **call_kwargs,
                    )
                else:
                    raise RuntimeError(f"Agent execution failed: {primary_err}")
            
            msg = response.choices[0].message
            tool_calls = getattr(msg, 'tool_calls', None) or []
            
            # No tool calls → final text answer
            if not tool_calls:
                return msg.content
            
            # Append the assistant turn (contains tool_calls)
            messages.append(msg)
            
            # Execute each tool and append results
            for tc in tool_calls:
                fn_name = tc.function.name
                try:
                    fn_args = json.loads(tc.function.arguments)
                except Exception:
                    fn_args = {}
                
                if fn_name in tool_callables:
                    try:
                        tool_result = tool_callables[fn_name](**fn_args)
                        tool_output = str(tool_result)
                        self.logger.info(f"Tool {fn_name} executed OK")
                    except Exception as te:
                        tool_output = f"Tool error: {te}"
                        self.logger.warning(f"Tool {fn_name} raised: {te}")
                else:
                    tool_output = f"Tool '{fn_name}' is not available in the bundled package."
                    self.logger.warning(f"Unknown tool requested: {fn_name}")
                
                messages.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": tool_output,
                })
        
        raise RuntimeError(f"Tool-calling loop exceeded {MAX_TOOL_ROUNDS} rounds without a final answer.")
    
    # ------------------------------------------------------------------
    # Main execute
    # ------------------------------------------------------------------
    def execute(self, input_text: str, context: Dict[str, Any] = None) -> str:
        """Execute agent: build messages, load tools, call LLM with tool loop."""
        if context is None:
            context = {}

        # Action agents (those with agent_type==action_agent) receive an INPUT_JSON payload; instruct LLM accordingly
        is_action = self.agent_config.get('agent_type') == 'action_agent'
        action_prefix = (
            "You are an Action Agent. The user message is an INPUT_JSON payload.\\n"
            "Parse the JSON and extract ALL fields including credential/config fields\\n"
            "(workspace URLs, tokens, API keys, etc.) then pass them directly to tool calls.\\n"
            "Never hardcode or invent values — extract every parameter from the JSON.\\n\\n"
        ) if is_action else ""

        system_prompt = f"""{action_prefix}Role: {self.agent_config.get('role', '')}

Instructions: {self.agent_config.get('instructions', '')}

Expected Output: {self.agent_config.get('expected_outputs', '')}"""

        # Send INPUT_JSON payloads verbatim; go through prompt template for normal agents
        if is_action and str(input_text).startswith('INPUT_JSON:'):
            user_message = input_text
        else:
            prompt_template = self.agent_config.get('prompt', '{input}')
            try:
                user_message = prompt_template.format(input=input_text, **context)
            except KeyError:
                user_message = f"{prompt_template}\\n\\nInput:\\n{input_text}"

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ]
        
        self.logger.info(f"Executing agent {self.agent_id}")
        
        # Load native tools
        tool_specs, tool_callables = self._load_tools()
        if tool_specs:
            self.logger.info(f"Tools available: {[t['function']['name'] for t in tool_specs]}")

        # Load MCP tools for this agent
        mcp_server_ids = self.agent_config.get('mcp_servers') or []
        if mcp_server_ids:
            mcp_mgr = MCPClientManager(self.agent_id, mcp_server_ids)
            mcp_specs, mcp_callables = mcp_mgr.load_tools()
            tool_specs.extend(mcp_specs)
            tool_callables.update(mcp_callables)
            if mcp_specs:
                self.logger.info(f"MCP tools available: {[t['function']['name'] for t in mcp_specs]}")
        
        # LLM credentials
        litellm_url = os.getenv('LITELLM_URL', '').strip()
        litellm_key = os.getenv('LITELLM_API_KEY', '').strip() or os.getenv('LITELLM_PROXY_API_KEY', '').strip()
        base_model = self.llm_config.get('model', 'gpt-4o')
        bare_model = base_model.split('/')[-1] if '/' in base_model else base_model
        gateway_model = f"litellm_proxy/{bare_model}"
        azure_key = os.getenv('AZURE_OPENAI_API_KEY', '').strip()
        azure_endpoint = os.getenv('AZURE_OPENAI_ENDPOINT', '').strip()
        azure_version = os.getenv('AZURE_OPENAI_API_VERSION', '2024-08-01-preview').strip()
        azure_deployment = os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME', bare_model).strip()
        
        output = self._call_llm(
            messages, tool_specs, tool_callables,
            litellm_url, litellm_key, gateway_model,
            azure_key, azure_endpoint, azure_version, azure_deployment,
        )
        self.logger.info(f"Agent {self.agent_id} completed")
        return output'''

    @staticmethod
    def _mcp_manager() -> str:
        """Generate MCPClientManager class for MCP tool execution."""
        return '''

class MCPClientManager:
    """Connect to MCP servers, list tools, execute tool calls."""

    def __init__(self, agent_id: str, server_ids: list):
        self.agent_id = agent_id
        self.server_ids = server_ids
        self.logger = logging.getLogger(f"MCP[{agent_id}]")

    def load_tools(self) -> tuple:
        """Read mcp_servers_registry.yml, connect to each server, return (specs, callables)."""
        try:
            import yaml, asyncio
        except ImportError:
            self.logger.warning("pyyaml not installed. MCP tools unavailable. Run: pip install pyyaml mcp")
            return [], {}

        cfg_file = Path(__file__).parent / 'config' / 'mcp_servers_registry.yml'
        if not cfg_file.exists():
            self.logger.warning("mcp_servers_registry.yml not found in config/")
            return [], {}

        mcp_cfg = yaml.safe_load(cfg_file.read_text(encoding='utf-8')).get('servers', {})
        tool_specs, tool_callables = [], {}

        for sid in self.server_ids:
            srv = mcp_cfg.get(sid)
            if not srv:
                self.logger.warning(f"MCP server '{sid}' not in registry")
                continue
            transport = str(srv.get('transport', 'stdio')).lower()
            if transport == 'stdio':
                self._load_stdio(sid, srv, tool_specs, tool_callables)
            elif transport in ('streamable_http', 'http', 'https'):
                self._load_http(sid, srv, tool_specs, tool_callables)

        return tool_specs, tool_callables

    @staticmethod
    def _build_spec(tool):
        return {'type': 'function', 'function': {
            'name': tool.name,
            'description': (tool.description or tool.name)[:200],
            'parameters': tool.inputSchema or {'type': 'object', 'properties': {}},
        }}

    def _load_stdio(self, sid, srv, specs, callables):
        import asyncio, re, os
        cmd = str(srv.get('command', 'python'))
        raw_args = srv.get('args', [])

        # Remap DAAN internal module references to bundled mcp_servers/ directory
        args = []
        for a in raw_args:
            s = str(a)
            m = re.search(r"daan\\.mcp_servers\\.(\\w+)", s)
            if m:
                local_py = Path(__file__).parent / 'mcp_servers' / f'{m.group(1)}.py'
                if local_py.exists():
                    s = s.replace(f"daan.mcp_servers.{m.group(1)}", f"mcp_servers.{m.group(1)}")
            args.append(s)

        import re as _re
        env = {**os.environ}
        for k, v in (srv.get('env') or {}).items():
            # Resolve ${VAR_NAME} references to their actual env values
            resolved = _re.sub(r'\$\{([^}]+)\}', lambda m: os.getenv(m.group(1), ''), str(v))
            env_val = resolved or os.getenv(k, '')
            if env_val:
                env[k] = env_val
        # Inject credentials block as UPPER_CASE env vars; user .env values take priority
        for k, v in (srv.get('credentials') or {}).items():
            _ek = k.upper()
            if v and _ek not in env:
                env[_ek] = str(v)

        try:
            import threading as _thr
            from mcp import ClientSession, StdioServerParameters
            from mcp.client.stdio import stdio_client

            # Single long-running task owns the session — avoids AnyIO cross-task cancel-scope errors
            _loop = asyncio.new_event_loop()
            _thread = _thr.Thread(target=_loop.run_forever, daemon=True)
            _thread.start()
            _state = {'queue': None, 'tools': None, 'err': None}
            _ready = _thr.Event()

            async def _run():
                q = asyncio.Queue()
                _state['queue'] = q
                try:
                    _p = StdioServerParameters(command=cmd, args=args, env=env)
                    async with stdio_client(_p) as (r, w):
                        async with ClientSession(r, w) as session:
                            await session.initialize()
                            _state['tools'] = await session.list_tools()
                            _ready.set()
                            while True:
                                item = await q.get()
                                if item is None:
                                    break
                                _tn, _kw, _ev, _box = item
                                try:
                                    r2 = await session.call_tool(_tn, _kw)
                                    _box[0] = r2.content[0].text if r2.content else ''
                                except Exception as _te:
                                    _box[0] = f'Tool error: {_te}'
                                finally:
                                    _ev.set()
                except Exception as _e:
                    _state['err'] = _e
                    _ready.set()

            asyncio.run_coroutine_threadsafe(_run(), _loop)
            _ready.wait(timeout=30)
            if _state.get('err'):
                raise _state['err']

            result = _state['tools']

            def _make_call(tool_name, __loop=_loop):
                def _call(**kw):
                    ev = _thr.Event()
                    box = [None]
                    asyncio.run_coroutine_threadsafe(
                        _state['queue'].put((tool_name, kw, ev, box)), __loop
                    ).result(timeout=5)
                    ev.wait(timeout=60)
                    return box[0] or ''
                return _call

            for t in result.tools:
                specs.append(MCPClientManager._build_spec(t))
                callables[t.name] = _make_call(t.name)
            self.logger.info(f"MCP '{sid}' (stdio): {len(result.tools)} tools loaded")
        except ImportError:
            self.logger.warning("mcp package not installed. Run: pip install mcp")
        except Exception as e:
            self.logger.warning(f"MCP '{sid}' stdio failed: {e}")

    def _load_http(self, sid, srv, specs, callables):
        import asyncio, os
        url = str(srv.get('url', '') or os.getenv(f"{sid.upper().replace('-','_')}_URL", ''))
        if not url:
            self.logger.warning(f"MCP '{sid}' has no url")
            return
        try:
            from mcp.client.streamable_http import streamablehttp_client
            from mcp import ClientSession

            async def _list():
                async with streamablehttp_client(url) as (r, w, _):
                    async with ClientSession(r, w) as session:
                        await session.initialize()
                        return await session.list_tools()

            result = asyncio.run(_list())

            # Each call reconnects independently — avoids closed-session and unawaited-coroutine bugs
            def _make_call(tool_name):
                def _call(**kw):
                    async def _invoke():
                        async with streamablehttp_client(url) as (r_, w_, _2):
                            async with ClientSession(r_, w_) as s_:
                                await s_.initialize()
                                r2 = await s_.call_tool(tool_name, kw)
                                return r2.content[0].text if r2.content else ''
                    return asyncio.run(_invoke())
                return _call

            for t in result.tools:
                specs.append(MCPClientManager._build_spec(t))
                callables[t.name] = _make_call(t.name)
            self.logger.info(f"MCP '{sid}' (HTTP): {len(result.tools)} tools loaded")
        except ImportError:
            self.logger.warning("mcp package not installed. Run: pip install mcp")
        except Exception as e:
            self.logger.warning(f"MCP '{sid}' HTTP failed: {e}")'''

    @staticmethod
    def _workflow_orchestrator() -> str:
        """Generate workflow orchestrator."""
        return '''

class WorkflowOrchestrator:
    """Orchestrate multi-agent workflow."""
    
    def __init__(self, usecase_config: Dict[str, Any], llm_configs: Dict[str, Any], data_dir=None):
        """Initialize orchestrator."""
        self.usecase_config = usecase_config
        self.llm_configs = llm_configs
        self.data_dir = data_dir
        self.logger = logging.getLogger("Orchestrator")
        self.agent_outputs = {}
    
    def execute(self, user_input: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute workflow with given user input.
        
        Args:
            user_input: User input dictionary
        
        Returns:
            Final output dictionary
        """
        self.logger.info("Starting workflow execution")
        orchestration = self.usecase_config['orchestration']
        
        # Sort by step index
        sorted_steps = sorted(orchestration, key=lambda s: s['step_index'])
        
        context = {}
        
        for step in sorted_steps:
            agent_id = step['agent_id']
            input_source = step.get('input_source', 'user_input')
            
            # Determine input for this agent
            if input_source == 'user_input':
                input_key = step.get('input_key', 'input')
                agent_input = user_input.get(input_key, '') or InputHandler.normalize(user_input)
            elif input_source == 'previous_agent':
                source_agent_id = step.get('source_agent_id')
                agent_input = self.agent_outputs.get(source_agent_id, '')
            else:
                agent_input = ''
            
            # Get agent configuration
            agents_config = self.usecase_config['agents']
            agent_config = next((a for a in agents_config if a['agent_id'] == agent_id), None)
            
            if not agent_config:
                raise RuntimeError(f"Agent {agent_id} not found in configuration")
            
            # Get LLM configuration
            llm_config = self.llm_configs.get(agent_id, {})

            # Inject MCP server credentials into input so action agents can pass them to tools
            mcp_server_ids = agent_config.get('mcp_servers') or []
            if agent_config.get('agent_type') == 'action_agent' and mcp_server_ids:
                cfg_file = Path(__file__).parent / 'config' / 'mcp_servers_registry.yml'
                try:
                    import yaml
                    if cfg_file.exists():
                        mcp_cfg = yaml.safe_load(cfg_file.read_text(encoding='utf-8')).get('servers', {})
                        injected_creds = {}
                        for sid in mcp_server_ids:
                            # In exported packages, credentials are passed via env vars at runtime
                            env_mapping = (mcp_cfg.get(sid) or {}).get('env_mapping', {})
                            for cred_key, env_var in env_mapping.items():
                                val = os.environ.get(env_var, '')
                                if val:
                                    injected_creds[cred_key] = val
                        if injected_creds:
                            try:
                                payload = json.loads(agent_input) if isinstance(agent_input, str) and str(agent_input).strip().startswith('{') else {'reviewed_output': str(agent_input)}
                            except Exception:
                                payload = {'reviewed_output': str(agent_input)}
                            payload.update(injected_creds)
                            agent_input = 'INPUT_JSON:\\n' + json.dumps(payload, ensure_ascii=False)
                except Exception as _cred_err:
                    self.logger.warning(f"Could not load MCP credentials for agent {agent_id}: {_cred_err}")

            # Execute agent
            executor = AgentExecutor(agent_id, agent_config, llm_config, data_dir=self.data_dir)
            output = executor.execute(str(agent_input), context)
            
            # Store output for next agent
            output_key = step.get('output_key', agent_id)
            self.agent_outputs[output_key] = output
            context[agent_id] = output
            
            self.logger.info(f"Step {step['step_index']}: Agent {agent_id} completed")
        
        # Build final output
        output_mapping = self.usecase_config.get('output_mapping', {})
        result = {}
        
        for output_key, output_config in output_mapping.items():
            source = output_config.get('source', 'final_agent')
            result[output_key] = self.agent_outputs.get(source, '')
        
        self.logger.info("Workflow execution completed")
        return result'''
    
    @staticmethod
    def _input_handler() -> str:
        """Generate input handler."""
        return '''

class InputHandler:
    """Handle input from various sources and formats."""
    
    @staticmethod
    def get_input(input_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Get input from file (any format) or stdin.
        Supports: JSON, CSV, XLSX, text, etc.
        
        Args:
            input_path: Path to input file
        
        Returns:
            Input dictionary
        """
        if input_path:
            if not os.path.exists(input_path):
                raise FileNotFoundError(f"Input file not found: {input_path}")
            
            # Detect format by extension
            file_ext = Path(input_path).suffix.lower()
            
            try:
                if file_ext == '.json':
                    return InputHandler._load_json(input_path)
                elif file_ext == '.csv':
                    return InputHandler._load_csv(input_path)
                elif file_ext in ['.xlsx', '.xls']:
                    return InputHandler._load_excel(input_path)
                else:
                    # Try JSON first, then plain text
                    try:
                        return InputHandler._load_json(input_path)
                    except:
                        return InputHandler._load_text(input_path)
            except Exception as e:
                logger.error(f"Failed to parse {file_ext} file: {e}")
                # Fallback: treat as plain text
                return InputHandler._load_text(input_path)
        else:
            # Read from stdin
            logger.info("Enter input (Ctrl+D to finish):")
            lines = []
            try:
                while True:
                    line = input()
                    lines.append(line)
            except EOFError:
                pass
            
            content = '\\n'.join(lines)
            try:
                return json.loads(content)
            except json.JSONDecodeError:
                return {'input': content}
    
    @staticmethod
    def _load_json(file_path: str) -> Dict[str, Any]:
        """Load JSON file."""
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    @staticmethod
    def _load_csv(file_path: str) -> Dict[str, Any]:
        """Load CSV file as list of dictionaries."""
        try:
            import pandas as pd
            df = pd.read_csv(file_path)
            # Schema + sample only — avoids context window errors on large files
            return {
                'columns': list(df.columns),
                'dtypes': df.dtypes.astype(str).to_dict(),
                'total_rows': len(df),
                'sample_data': df.head(10).to_dict('records'),
                'format': 'csv',
            }
        except ImportError:
            logger.warning("pandas not installed, reading CSV as text")
            return InputHandler._load_text(file_path)
    
    @staticmethod
    def _load_excel(file_path: str) -> Dict[str, Any]:
        """Load XLSX/XLS file as list of dictionaries."""
        try:
            import pandas as pd
            df = pd.read_excel(file_path)
            return {
                'columns': list(df.columns),
                'dtypes': df.dtypes.astype(str).to_dict(),
                'total_rows': len(df),
                'sample_data': df.head(10).to_dict('records'),
                'format': 'xlsx',
            }
        except ImportError:
            logger.warning("pandas not installed, cannot read Excel file")
            raise RuntimeError("pandas required for Excel files: pip install pandas openpyxl")
    
    @staticmethod
    def _load_text(file_path: str) -> Dict[str, Any]:
        """Load plain text file."""
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        return {'input': content, 'format': 'text'}

    @staticmethod
    def normalize(loaded: Dict[str, Any]) -> str:
        """Convert any loaded input dict to a plain string for agent consumption."""
        if loaded and 'data' in loaded and isinstance(loaded['data'], list):
            try:
                import pandas as pd
                return pd.DataFrame(loaded['data']).to_string(index=False)
            except Exception:
                return str(loaded['data'])
        return str(loaded.get('input', loaded) if loaded else '')

    @staticmethod
    def merge_inputs(paths: list) -> Dict[str, Any]:
        """Merge multiple input files into combined context for multi-file workflows."""
        parts, all_data = [], []
        for p in paths:
            loaded = InputHandler.get_input(p)
            parts.append(f"=== {Path(p).name} ===\\n{InputHandler.normalize(loaded)}")
            if isinstance(loaded.get('data'), list):
                all_data.extend(loaded['data'])
        result = {'input': '\\n\\n'.join(parts)}
        if all_data:
            result['data'] = all_data
        return result

    @staticmethod
    def save_output(output: Dict[str, Any], output_path: str):
        """Save output to file. Format detected from extension (.xlsx, .csv, .txt, .json)."""
        ext = Path(output_path).suffix.lower()
        
        if ext in ('.xlsx', '.xls'):
            try:
                import pandas as pd
                # If output has a 'data' key with list, write as rows; otherwise wrap result
                data = output.get('data') or output.get('user_stories') or output.get('stories') or output.get('rows')
                if data and isinstance(data, list):
                    df = pd.DataFrame(data)
                else:
                    # Parse agent text output into rows if possible
                    result_text = output.get('result', output.get('output', str(output)))
                    rows = OutputParser.parse_to_rows(result_text)
                    df = pd.DataFrame(rows)
                df.to_excel(output_path, index=False)
                logger.info(f"Output saved as Excel: {output_path}")
            except ImportError:
                raise RuntimeError("pandas + openpyxl required for Excel output: pip install pandas openpyxl")
        
        elif ext == '.csv':
            try:
                import pandas as pd
                data = output.get('data') or output.get('rows')
                if data and isinstance(data, list):
                    df = pd.DataFrame(data)
                else:
                    result_text = output.get('result', output.get('output', str(output)))
                    rows = OutputParser.parse_to_rows(result_text)
                    df = pd.DataFrame(rows)
                df.to_csv(output_path, index=False, encoding='utf-8')
                logger.info(f"Output saved as CSV: {output_path}")
            except ImportError:
                raise RuntimeError("pandas required for CSV output: pip install pandas")
        
        elif ext == '.xml':
            # Write as-is: LLM-generated XML is already a text string
            result_text = output.get('result', output.get('output', str(output)))
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(result_text)
            logger.info(f"Output saved as XML: {output_path}")

        elif ext == '.txt':
            result_text = output.get('result', output.get('output', str(output)))
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(result_text)
            logger.info(f"Output saved as text: {output_path}")
        
        else:  # default JSON
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(output, f, indent=2, ensure_ascii=False)
            logger.info(f"Output saved as JSON: {output_path}")


class OutputParser:
    """Parse LLM text output into structured rows for tabular formats."""
    
    @staticmethod
    def parse_to_rows(text: str) -> list:
        """
        Try to parse LLM output text into a list of dicts for DataFrame.
        Handles numbered lists, markdown tables, and plain text.
        """
        if not text:
            return [{"output": ""}]
        
        lines = [l.strip() for l in text.strip().splitlines() if l.strip()]
        
        # Try markdown table: | col | col |
        if any("|".strip() in l for l in lines[:5]):
            table_lines = [l for l in lines if l.startswith("|")]
            if len(table_lines) >= 2:
                try:
                    headers = [h.strip() for h in table_lines[0].strip("|").split("|")]
                    rows = []
                    for row_line in table_lines[2:]:  # skip separator line
                        vals = [v.strip() for v in row_line.strip("|").split("|")]
                        rows.append(dict(zip(headers, vals)))
                    if rows:
                        return rows
                except Exception:
                    pass
        
        # Try numbered list: "1. ...", "2. ..."
        import re
        numbered = [(m.group(1), m.group(2)) for l in lines
                    if (m := re.match(r"^(\\d+)[.)\\s]+(.+)$", l))]
        if len(numbered) >= 2:
            return [{"#": n, "User Story": text} for n, text in numbered]
        
        # Fallback: each non-empty line as a row
        return [{"output": l} for l in lines if l]'''
    
    @staticmethod
    def _main_function() -> str:
        """Generate main function."""
        return '''

def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Execute exported use case'
    )
    parser.add_argument(
        '--input',
        nargs='+',
        help='Input file path(s) — pass multiple files for multi-file workflows',
        default=None
    )
    parser.add_argument(
        '--output',
        help='Output file (.json/.xlsx/.csv/.txt). Default: auto-detect from first input format.',
        default=None
    )
    args = parser.parse_args()

    # Auto-determine output format from first input
    if not args.output:
        first = (args.input or [None])[0]
        if first:
            in_ext = Path(first).suffix.lower()
            if in_ext in ('.xlsx', '.xls'):
                args.output = 'output.xlsx'
            elif in_ext == '.csv':
                args.output = 'output.csv'
            elif in_ext == '.xml':
                args.output = 'output.xml'
            else:
                args.output = 'output.json'
        else:
            args.output = 'output.json'
    
    try:
        # Load environment
        ConfigLoader.load_env()
        
        # Load configurations
        logger.info("Loading configurations...")
        usecase_config = ConfigLoader.load_config('usecase_config')
        llm_configs_raw = ConfigLoader.load_config('llm_config')
        
        # Convert LLM configs to proper format
        llm_configs = {}
        for agent_id, config in llm_configs_raw.items():
            llm_configs[agent_id] = {
                'model': config.get('model'),
                'provider': config.get('provider'),
                'temperature': config.get('temperature', 0.7),
                'max_tokens': config.get('max_tokens', 2000),
                'top_p': config.get('top_p', 1.0),
            }
        
        # Get user input — single or multiple files
        logger.info("Retrieving input...")
        inputs = args.input or []
        user_input = InputHandler.merge_inputs(inputs) if len(inputs) > 1 else InputHandler.get_input(inputs[0] if inputs else None)
        
        # Validate input against schema
        input_schema = usecase_config.get('input_schema', {})
        if input_schema:
            InputValidator.validate(user_input, input_schema)
        
        # Stage inputs under package_dir/inputs/ so artifacts resolve to package_dir/artifacts/
        import shutil as _shutil
        _data_dir = None
        if inputs:
            _data_dir = Path(__file__).parent / 'inputs'
            _data_dir.mkdir(exist_ok=True)
            for _p in inputs:
                try:
                    _shutil.copy2(_p, _data_dir / Path(_p).name)
                except Exception:
                    pass

        # Execute workflow
        logger.info("Starting workflow...")
        orchestrator = WorkflowOrchestrator(usecase_config, llm_configs, data_dir=_data_dir)
        output = orchestrator.execute(user_input)
        
        # Save output (format auto-detected from extension)
        InputHandler.save_output(output, args.output)
        logger.info(f"Output format: {Path(args.output).suffix} → {args.output}")
        logger.info("Execution completed successfully")
        return 0
    
    except Exception as e:
        logger.error(f"Execution failed: {str(e)}", exc_info=True)
        return 1


if __name__ == '__main__':
    sys.exit(main())'''
