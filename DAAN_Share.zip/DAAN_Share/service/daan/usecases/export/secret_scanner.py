"""Security scanning for secrets in export packages."""

import json
import logging
import re
from pathlib import Path
from typing import Dict, List, Set, Tuple

logger = logging.getLogger(__name__)


class SecretScanner:
    """Scan files and configurations for secrets."""
    
    # Patterns for detecting secrets
    SECRET_PATTERNS = {
        'openai_key': r'sk-[A-Za-z0-9\-_]{40,}',
        'azure_key': r'[A-Za-z0-9+/]{88}==',
        'aws_access': r'AKIA[0-9A-Z]{16}',
        'aws_secret': r'aws_secret_access_key\s*=\s*[^\s]+',
        'api_key': r'api[_-]?key\s*[:=]\s*["\']?[A-Za-z0-9\-_]{20,}["\']?',
        'bearer_token': r'bearer\s+[A-Za-z0-9\-_\.]+',
        'jwt_token': r'eyJ[A-Za-z0-9\-_\.]+',
        'password': r'password\s*[:=]\s*["\']?[^\s"\']+["\']?',
        'private_key': r'-----BEGIN (RSA|PRIVATE|EC) PRIVATE KEY-----',
        'connection_string': r'Server=.*Password=.*',
        'db_password': r'(postgresql|mysql|mongodb)://[^:]+:([^\s@]+)@',
    }
    
    def __init__(self):
        """Initialize scanner."""
        self.compiled_patterns = {
            name: re.compile(pattern, re.IGNORECASE)
            for name, pattern in self.SECRET_PATTERNS.items()
        }
    
    def scan_file(self, file_path: Path) -> List[Tuple[str, int, str]]:
        """
        Scan a single file for secrets.
        
        Returns:
            List of (pattern_name, line_number, matched_text)
        """
        secrets = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line_no, line in enumerate(f, 1):
                    for pattern_name, pattern in self.compiled_patterns.items():
                        matches = pattern.finditer(line)
                        for match in matches:
                            secrets.append((pattern_name, line_no, match.group(0)))
        except Exception as e:
            logger.warning(f"Failed to scan {file_path}: {str(e)}")
        
        return secrets
    
    def scan_json(self, obj: dict, path: str = "") -> List[Tuple[str, str, str]]:
        """
        Scan JSON/dict structure for secrets.
        
        Returns:
            List of (pattern_name, json_path, value)
        """
        secrets = []
        
        for key, value in obj.items():
            current_path = f"{path}.{key}" if path else key
            
            if isinstance(value, dict):
                secrets.extend(self.scan_json(value, current_path))
            elif isinstance(value, str):
                for pattern_name, pattern in self.compiled_patterns.items():
                    if pattern.search(value):
                        # Don't include full value for security
                        secrets.append((pattern_name, current_path, f"***{len(value)} chars***"))
            elif isinstance(value, list):
                for idx, item in enumerate(value):
                    if isinstance(item, dict):
                        secrets.extend(self.scan_json(item, f"{current_path}[{idx}]"))
                    elif isinstance(item, str):
                        for pattern_name, pattern in self.compiled_patterns.items():
                            if pattern.search(item):
                                secrets.append((pattern_name, f"{current_path}[{idx}]", f"***{len(item)} chars***"))
        
        return secrets
    
    def scan_directory(self, directory: Path, extensions: Set[str] = None) -> Dict[str, List]:
        """
        Scan all files in a directory.
        
        Args:
            directory: Directory to scan
            extensions: File extensions to check (e.g., {'.py', '.json', '.env'})
        
        Returns:
            Dict mapping file paths to list of secrets found
        """
        if extensions is None:
            extensions = {'.py', '.json', '.yml', '.yaml', '.env'}
        
        results = {}
        
        for file_path in directory.rglob('*'):
            if file_path.is_file() and file_path.suffix in extensions:
                if file_path.name == '.env.template':
                    continue  # Skip templates
                
                secrets = self.scan_file(file_path)
                if secrets:
                    results[str(file_path)] = secrets
        
        return results
    
    def sanitize_llm_config(self, config: dict) -> dict:
        """
        Remove sensitive fields from LLM configuration.
        
        Args:
            config: LLM config dict
        
        Returns:
            Sanitized config dict
        """
        sensitive_keys = {'api_key', 'apikey', 'secret', 'password', 'token', 'key'}
        
        def _sanitize(obj):
            if isinstance(obj, dict):
                result = {}
                for k, v in obj.items():
                    if any(sensitive in k.lower() for sensitive in sensitive_keys):
                        result[k] = None
                    elif isinstance(v, (dict, list)):
                        result[k] = _sanitize(v)
                    else:
                        result[k] = v
                return result
            elif isinstance(obj, list):
                return [_sanitize(item) for item in obj]
            else:
                return obj
        
        return _sanitize(config)
    
    def sanitize_mcp_config(self, config: dict) -> dict:
        """
        Remove sensitive fields from MCP configuration.
        
        Args:
            config: MCP config dict
        
        Returns:
            Sanitized config dict
        """
        result = self.sanitize_llm_config(config)
        
        # Also blank out env_vars in MCP config
        if isinstance(result, dict):
            if 'env_vars' in result:
                result['env_vars'] = {}
            if 'config' in result and isinstance(result['config'], dict):
                for key in list(result['config'].keys()):
                    if any(sensitive in key.lower() for sensitive in {'api_key', 'token', 'secret', 'password'}):
                        result['config'][key] = None
        
        return result
    
    def create_env_template(self, required_vars: List[str]) -> str:
        """
        Generate .env.template file content.
        
        Args:
            required_vars: List of required environment variable names
        
        Returns:
            Content for .env.template file
        """
        lines = [
            "# Environment configuration for exported use case",
            "# Copy this file to .env and fill in the required values",
            "# DO NOT commit .env to version control",
            ""
        ]
        
        var_descriptions = {
            'LITELLM_URL': 'Your LiteLLM gateway URL (https://...)',
            'LITELLM_API_KEY': 'Your LiteLLM API key for gateway access',
            'LITELLM_PROXY_API_KEY': 'Your LiteLLM proxy API key',
            'AZURE_OPENAI_API_KEY': 'Your Azure OpenAI API key',
            'AZURE_OPENAI_ENDPOINT': 'Your Azure OpenAI endpoint URL',
            'AZURE_OPENAI_API_KEY': 'Your Azure OpenAI API key',
            'OPENAI_API_KEY': 'Your OpenAI API key (sk-...)',
            'ANTHROPIC_API_KEY': 'Your Anthropic API key',
            'GROQ_API_KEY': 'Your Groq API key',
            'COHERE_API_KEY': 'Your Cohere API key',
            'TOGETHER_API_KEY': 'Your Together API key',
            'DATABASE_URL': 'Database connection string (postgresql://...)',
        }
        
        for var in sorted(set(required_vars)):
            desc = var_descriptions.get(var, f'Configuration for {var}')
            lines.append(f"# {desc}")
            lines.append(f"{var}=<YOUR_VALUE_HERE>")
            lines.append("")
        
        return '\n'.join(lines)
