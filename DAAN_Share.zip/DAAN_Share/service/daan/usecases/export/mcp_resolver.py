"""MCP server configuration resolver and bundler."""

import logging
import re
from pathlib import Path
from typing import Dict, List, Optional

from daan.usecases.export.schemas import MCPServerConfig

logger = logging.getLogger(__name__)


class MCPResolver:
    """Resolve and prepare MCP server configurations from mcp_servers_registry.yml."""

    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.registry_path = project_root.parent / 'config' / 'mcp_servers_registry.yml'
        self.mcp_servers_dir = project_root / 'daan' / 'mcp_servers'

    def _load_yaml_config(self) -> dict:
        if not self.registry_path.exists():
            logger.warning(f"mcp_servers_registry.yml not found at {self.registry_path}")
            return {}
        try:
            import yaml
            return yaml.safe_load(self.registry_path.read_text(encoding='utf-8')) or {}
        except Exception as e:
            logger.error(f"Failed to load mcp_servers_registry.yml: {e}")
            return {}

    def resolve_server(self, server_id: str) -> Optional[MCPServerConfig]:
        """Resolve an MCP server by ID from the registry."""
        data = self._load_yaml_config()
        srv = data.get('servers', {}).get(server_id)
        if not srv:
            logger.warning(f"MCP server '{server_id}' not found in registry")
            return None

        command = str(srv.get('command', '')).strip()
        server_type = 'python' if command == 'python' else 'external'

        env_vars = {k: '' for k in srv.get('env_mapping', {}).values()}

        return MCPServerConfig(
            server_id=server_id,
            server_name=srv.get('display_name', server_id),
            transport=str(srv.get('transport', 'stdio')).lower(),
            server_type=server_type,
            config=srv,
            env_vars=env_vars,
        )

    def get_server_files(self, server_config: MCPServerConfig) -> List[Path]:
        """
        Return the Python file(s) for python-command MCP servers.
        For external (npx etc.) servers returns [] — no file to bundle.
        """
        if server_config.server_type != 'python':
            return []

        args = server_config.config.get('args', [])
        for arg in args:
            # DAAN python MCP servers use: importlib.import_module('daan.mcp_servers.X')
            m = re.search(r"import_module\(['\"]daan\.mcp_servers\.(\w+)['\"]", str(arg))
            if m:
                py_file = self.mcp_servers_dir / f'{m.group(1)}.py'
                if py_file.exists():
                    return [py_file]
                logger.warning(f"MCP server file not found: {py_file}")
        return []

    def sanitize_config(self, config: MCPServerConfig) -> Dict:
        """Return config safe for export (credentials stripped)."""
        srv = dict(config.config)
        srv.pop('credentials', None)
        return {
            'server_id': config.server_id,
            'server_name': config.server_name,
            'transport': config.transport,
            'server_type': config.server_type,
            'config': srv,
            'env_vars': {},
        }
