"""AST-based import resolver for Python tool files."""

import ast
import logging
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


class ImportResolver:
    """Resolve and rewrite imports in Python files."""
    
    def __init__(self, project_root: Path):
        """
        Initialize resolver.
        
        Args:
            project_root: Root path of the DAAN project
        """
        self.project_root = project_root
        self.resolved_modules: Dict[str, Path] = {}
        self.import_errors: List[Tuple[str, str]] = []
        self._module_cache: Dict[str, Optional[Path]] = {}
    
    def resolve_imports(self, file_path: Path) -> Tuple[List[str], List[str]]:
        """
        Resolve all imports in a file.
        
        Returns:
            (list of resolved module paths, list of error messages)
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            return [], [f"Failed to read {file_path}: {str(e)}"]
        
        try:
            tree = ast.parse(content)
        except SyntaxError as e:
            return [], [f"Syntax error in {file_path}: {str(e)}"]
        
        resolved = []
        errors = []
        visited = set()
        
        # Extract imports from AST
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                module_name = node.module
                if module_name and module_name.startswith('daan.'):
                    # Resolve daan.* imports
                    resolved_path = self._resolve_module(module_name)
                    if resolved_path:
                        if str(resolved_path) not in visited:
                            resolved.append(str(resolved_path))
                            visited.add(str(resolved_path))
                    else:
                        errors.append(f"Cannot resolve module: {module_name}")
        
        return resolved, errors
    
    def _resolve_module(self, module_name: str) -> Optional[Path]:
        """
        Resolve a daan.* module to its file path.
        
        Examples:
            daan.tools.math -> service/daan/tools/math.py or .../math/__init__.py
            daan.agents.calculator -> service/daan/agents/calculator.py
        """
        if module_name in self._module_cache:
            return self._module_cache[module_name]
        
        # Convert module name to path
        parts = module_name.split('.')
        
        # Try both file and package directory
        # e.g., daan.tools.math -> daan/tools/math.py or daan/tools/math/__init__.py
        rel_parts = parts[1:]  # Skip 'daan' prefix
        
        # Try as .py file
        file_path = self.project_root / 'daan' / '/'.join(rel_parts[:-1]) / f"{rel_parts[-1]}.py"
        if file_path.exists():
            self._module_cache[module_name] = file_path
            return file_path
        
        # Try as package directory
        pkg_path = self.project_root / 'daan' / '/'.join(rel_parts) / '__init__.py'
        if pkg_path.exists():
            self._module_cache[module_name] = pkg_path
            return pkg_path
        
        self._module_cache[module_name] = None
        return None
    
    def rewrite_imports(self, file_content: str, new_package_prefix: str = "tools") -> str:
        """
        Rewrite daan.* imports to relative imports.
        
        Args:
            file_content: Original file content
            new_package_prefix: Prefix for new imports (e.g., 'tools')
        
        Returns:
            File content with rewritten imports
        """
        try:
            tree = ast.parse(file_content)
        except SyntaxError:
            return file_content  # Return unchanged if parse fails
        
        lines = file_content.split('\n')
        replacements = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                if node.module and node.module.startswith('daan.'):
                    # Build new import statement
                    old_module = node.module
                    
                    # Convert daan.tools.math.helper -> tools.math.helper
                    parts = old_module.split('.')
                    if parts[1] == 'tools':
                        # For tool imports, convert to relative
                        new_module = '.'.join([new_package_prefix] + parts[2:])
                    else:
                        # For other daan.* imports, try to map intelligently
                        new_module = '.'.join([new_package_prefix] + parts[1:])
                    
                    # Reconstruct import statement
                    imported_names = ', '.join(alias.name for alias in node.names)
                    new_stmt = f"from {new_module} import {imported_names}"
                    
                    # Find and replace in lines
                    if node.lineno > 0:
                        old_line = lines[node.lineno - 1]
                        if 'from' in old_line and 'import' in old_line:
                            replacements.append((node.lineno - 1, old_line, new_stmt))
        
        # Apply replacements (in reverse order to maintain line numbers)
        for line_idx, old, new in reversed(replacements):
            lines[line_idx] = new
        
        return '\n'.join(lines)
    
    def find_tool_dependencies(self, tool_file: Path) -> Set[Path]:
        """
        Recursively find all local tool dependencies.
        
        Returns:
            Set of all required tool file paths
        """
        dependencies = set()
        visited = set()
        
        def _collect_deps(file_path: Path):
            if str(file_path) in visited:
                return
            visited.add(str(file_path))
            
            resolved, _ = self.resolve_imports(file_path)
            for dep_path in resolved:
                dep = Path(dep_path)
                if dep.exists() and dep not in dependencies:
                    dependencies.add(dep)
                    _collect_deps(dep)
        
        _collect_deps(tool_file)
        return dependencies
    
    def detect_circular_imports(self, file_path: Path) -> List[str]:
        """Detect circular import chains."""
        cycles = []
        visited = set()
        rec_stack = set()
        
        def _visit(path: Path, chain: List[str]):
            path_str = str(path)
            if path_str in rec_stack:
                # Found a cycle
                cycle_start = chain.index(path_str)
                cycle = chain[cycle_start:] + [path_str]
                cycles.append(' -> '.join(cycle))
                return
            
            if path_str in visited:
                return
            
            visited.add(path_str)
            rec_stack.add(path_str)
            
            resolved, _ = self.resolve_imports(path)
            for dep_path in resolved:
                _visit(Path(dep_path), chain + [path_str])
            
            rec_stack.remove(path_str)
        
        _visit(file_path, [])
        return cycles
