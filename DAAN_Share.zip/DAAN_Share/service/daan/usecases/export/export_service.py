"""Main export service - orchestrates the entire export process."""

import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from daan.usecases.export.export_validator import ExportValidator
from daan.usecases.export.import_resolver import ImportResolver
from daan.usecases.export.mcp_resolver import MCPResolver
from daan.usecases.export.package_generator import PackageGenerator
from daan.usecases.export.schemas import UseCaseConfig, ValidationResult
from daan.usecases.export.secret_scanner import SecretScanner

logger = logging.getLogger(__name__)


class UseCaseExportService:
    """Main service for exporting use cases."""
    
    def __init__(self, project_root: Optional[Path] = None):
        """
        Initialize export service.
        
        Args:
            project_root: Root path of DAAN project (defaults to service root)
        """
        if project_root is None:
            project_root = Path(__file__).parent.parent.parent.parent  # export/ -> usecases/ -> daan/ -> service/
        
        self.project_root = project_root
        self.import_resolver = ImportResolver(project_root)
        self.mcp_resolver = MCPResolver(project_root)
        self.secret_scanner = SecretScanner()
        self.validator = ExportValidator()
    
    def export_usecase(self, usecase_config: UseCaseConfig) -> Tuple[Optional[Path], Optional[ValidationResult]]:
        """
        Export a use case to a standalone ZIP package.
        
        Args:
            usecase_config: Complete use case configuration
        
        Returns:
            (path_to_zip_file, validation_result)
            If successful: (zip_path, None)
            If validation fails: (None, validation_result_with_errors)
        """
        logger.info(f"Exporting use case: {usecase_config.usecase_id}")
        
        # Step 1: Validate configuration
        logger.info("Step 1: Validating configuration...")
        validation_result = self.validator.validate(usecase_config)
        if not validation_result.is_valid:
            logger.error("Validation failed")
            return None, validation_result
        
        try:
            # Step 2: Resolve tool dependencies
            logger.info("Step 2: Resolving tool dependencies...")
            tool_files = self._resolve_tools(usecase_config)
            
            # Step 3: Scan for secrets
            logger.info("Step 3: Scanning for secrets...")
            secret_scan_result = self._scan_for_secrets(usecase_config, tool_files)
            if not secret_scan_result['is_clean']:
                logger.error("Secrets detected in export")
                validation_result.add_error(
                    self._create_secret_error(secret_scan_result['findings'])
                )
                return None, validation_result
            
            # Step 4: Resolve MCP servers
            logger.info("Step 4: Resolving MCP servers...")
            mcp_files = self._resolve_mcp_servers(usecase_config)
            
            # Step 5: Generate package
            logger.info("Step 5: Generating package...")
            generator = PackageGenerator(usecase_config)
            zip_path = generator.generate(tool_files, mcp_files)
            
            logger.info(f"Export completed successfully: {zip_path}")
            return zip_path, None
        
        except Exception as e:
            logger.error(f"Export failed: {str(e)}", exc_info=True)
            validation_result.add_error(
                self._create_export_error(str(e))
            )
            return None, validation_result
    
    def _resolve_tools(self, config: UseCaseConfig) -> Dict[str, List[Path]]:
        """
        Resolve all tool files and their dependencies.
        
        Returns:
            Dict mapping agent_id to list of tool file paths
        """
        tool_files = {}
        
        for agent_id, tools in config.agent_tools.items():
            resolved_tools = []
            
            for tool_ref in tools:
                tool_path = self.project_root / tool_ref.file_path

                if not tool_path.exists():
                    native_tools_dir = self.project_root / 'daan' / 'native_tools'
                    # CamelCase class name → snake_case (DAAN tools_loader convention)
                    import re as _re
                    class_part = tool_ref.tool_name.split('.')[0] if '.' in tool_ref.tool_name else tool_ref.tool_name
                    _s = _re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1_\2', class_part)
                    snake_name = _re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', _s).lower()
                    candidates = [
                        native_tools_dir / Path(tool_ref.file_path).name,
                        native_tools_dir / f'{snake_name}.py',
                        native_tools_dir / f'{class_part}.py',
                    ]
                    tool_path = next((c for c in candidates if c.exists()), None)
                    if not tool_path:
                        # MCP agents may declare tools with no local file — MCP handles execution
                        agent_mcp = config.agent_mcp_mappings.get(agent_id)
                        if agent_mcp and agent_mcp.mcp_servers:
                            logger.warning(
                                f"Tool '{tool_ref.tool_name}' for agent '{agent_id}' not found; "
                                f"agent has MCP servers {agent_mcp.mcp_servers}, skipping local tool"
                            )
                            continue
                        raise FileNotFoundError(
                            f"Tool '{tool_ref.tool_name}' for agent '{agent_id}' not found. "
                            f"Checked: {[c.name for c in candidates]}"
                        )
                
                # Find all dependencies for this tool
                dependencies = self.import_resolver.find_tool_dependencies(tool_path)
                
                # Add main tool file and dependencies
                resolved_tools.append(tool_path)
                resolved_tools.extend(dependencies)
            
            # Remove duplicates while preserving order
            unique_tools = []
            seen = set()
            for tool in resolved_tools:
                tool_str = str(tool)
                if tool_str not in seen:
                    unique_tools.append(tool)
                    seen.add(tool_str)
            
            tool_files[agent_id] = unique_tools
        
        return tool_files
    
    def _resolve_mcp_servers(self, config: UseCaseConfig) -> Dict[str, List[Path]]:
        """Resolve MCP server Python files for bundling."""
        mcp_files = {}
        for mcp_config in config.mcp_servers:
            # Re-resolve from registry — router creates configs with server_type='external'
            resolved = self.mcp_resolver.resolve_server(mcp_config.server_id)
            target = resolved if resolved else mcp_config
            server_files = self.mcp_resolver.get_server_files(target)
            if server_files:
                mcp_files[mcp_config.server_id] = server_files
        return mcp_files
    
    def _scan_for_secrets(
        self, 
        config: UseCaseConfig, 
        tool_files: Dict[str, List[Path]]
    ) -> Dict:
        """
        Scan configuration and tool files for secrets.
        
        Returns:
            Dict with 'is_clean' flag and 'findings' list
        """
        findings = []
        
        # Scan LLM configs
        for agent_id, llm_config in config.llm_configs.items():
            llm_dict = {
                'model': llm_config.model,
                'provider': llm_config.provider,
                'other_params': llm_config.other_params,
            }
            secrets = self.secret_scanner.scan_json(llm_dict, f"llm_config.{agent_id}")
            if secrets:
                findings.extend(secrets)
        
        # Scan MCP configs
        for mcp_config in config.mcp_servers:
            mcp_dict = {
                'config': mcp_config.config,
                'env_vars': mcp_config.env_vars,
            }
            secrets = self.secret_scanner.scan_json(mcp_dict, f"mcp.{mcp_config.server_id}")
            if secrets:
                findings.extend(secrets)
        
        # Scan tool files — skip .py source files (code references cred keys, not values)
        for tool_list in tool_files.values():
            for tool_path in tool_list:
                if tool_path.suffix == '.py':
                    continue
                file_secrets = self.secret_scanner.scan_file(tool_path)
                if file_secrets:
                    findings.extend([(pat, ln, f"In {tool_path.name}") for pat, ln, _ in file_secrets])
        
        return {
            'is_clean': len(findings) == 0,
            'findings': findings
        }
    
    @staticmethod
    def _create_secret_error(findings: List[Tuple]) -> 'ValidationError':
        """Create validation error for secrets found."""
        from daan.usecases.export.schemas import ValidationError
        
        return ValidationError(
            error_code="SECRET_DETECTED_IN_EXPORT",
            message="Secrets detected in configuration or tool files",
            details={
                'findings': [
                    {
                        'pattern': pattern,
                        'location': location,
                    }
                    for pattern, location, _ in findings[:5]  # Limit to first 5
                ],
                'count': len(findings)
            }
        )
    
    @staticmethod
    def _create_export_error(error_message: str) -> 'ValidationError':
        """Create validation error for export failure."""
        from daan.usecases.export.schemas import ValidationError
        
        return ValidationError(
            error_code="EXPORT_FAILED",
            message=f"Export process failed: {error_message}"
        )
