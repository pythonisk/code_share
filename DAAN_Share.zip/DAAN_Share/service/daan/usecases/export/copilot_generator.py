"""Copilot package generator — emits GitHub Copilot customization files.

Alternative export target to :class:`PackageGenerator`. Instead of a runnable
Python package, this produces a ``.github/`` + ``.vscode/`` layout so a DAAN use
case can be dropped into any repository and consumed by GitHub Copilot as:

* ``.github/prompts/<agent>.prompt.md``   — each agent as a slash-command prompt
* ``.github/skills/<usecase>/SKILL.md``   — the ordered multi-agent workflow
* ``.github/agents/<usecase>.agent.md``   — an optional workflow persona
* ``.vscode/mcp.json``                     — MCP tool parity (only if MCP is used)

All content is derived from the same :class:`UseCaseConfig` used by the Python
export, so no additional data plumbing is required.
"""

import json
import logging
import os
import re
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
from zipfile import ZipFile

import yaml

from daan.usecases.export.schemas import UseCaseConfig

logger = logging.getLogger(__name__)

# Matches DAAN input placeholders like {questionnaire_context} but NOT escaped
# JSON braces ({{ }}). A token is a single brace pair wrapping a snake/space word.
_PLACEHOLDER_RE = re.compile(r"(?<!\{)\{([a-zA-Z_][\w ]*)\}(?!\})")


def _slugify(value: str) -> str:
    """Turn an arbitrary name into a safe, lowercase file-name slug."""
    slug = re.sub(r"[^\w\s-]", "", (value or "").strip().lower())
    slug = re.sub(r"[\s_-]+", "-", slug).strip("-")
    return slug or "item"


def _convert_placeholders(text: str) -> str:
    """Convert DAAN ``{var}`` placeholders to Copilot ``${input:var}`` inputs."""
    def _repl(match: re.Match) -> str:
        name = match.group(1).strip().replace(" ", "_")
        return f"${{input:{name}}}"

    return _PLACEHOLDER_RE.sub(_repl, text or "")


class CopilotPackageGenerator:
    """Generate a GitHub Copilot customization package as a ZIP file."""

    def __init__(self, config: UseCaseConfig, project_root: Optional[Path] = None):
        self.config = config
        # export/ -> usecases/ -> daan/ -> service/ -> repo root is one more up
        self.project_root = project_root or Path(__file__).resolve().parents[4]
        self.temp_dir: Optional[Path] = None
        self.package_dir: Optional[Path] = None
        self._uc_slug = _slugify(config.usecase_name or config.usecase_id)

    # ── public API ────────────────────────────────────────────────────────────
    def generate(self) -> Path:
        """Build the package and return the path to the generated ZIP."""
        self.temp_dir = Path(tempfile.mkdtemp())
        try:
            package_name = f"copilot_{self.config.usecase_id}"
            self.package_dir = self.temp_dir / package_name
            self.package_dir.mkdir(parents=True)

            self._write_prompt_files()
            self._write_skill()
            self._write_agent_file()
            self._write_mcp_json()
            self._write_readme()

            zip_path = self._create_zip()
            logger.info("Copilot package generated: %s", zip_path)
            return zip_path
        finally:
            if self.temp_dir and self.temp_dir.exists():
                import shutil
                shutil.rmtree(self.temp_dir, ignore_errors=True)

    # ── helpers ───────────────────────────────────────────────────────────────
    def _ordered_agents(self):
        """Agents in execution order (config.agents already ordered by mapping)."""
        return list(self.config.agents)

    def _mcp_servers_for(self, agent_id: str) -> List[str]:
        mapping = (self.config.agent_mcp_mappings or {}).get(agent_id)
        return list(mapping.mcp_servers) if mapping else []

    def _all_mcp_servers(self) -> List[str]:
        seen: List[str] = []
        for agent in self.config.agents:
            for sid in self._mcp_servers_for(agent.agent_id):
                if sid not in seen:
                    seen.append(sid)
        return seen

    def _agent_tools_frontmatter(self, agent_id: str) -> List[str]:
        tools = ["codebase"]
        tools.extend(self._mcp_servers_for(agent_id))
        return tools

    # ── writers ───────────────────────────────────────────────────────────────
    def _write_prompt_files(self):
        prompts_dir = self.package_dir / ".github" / "prompts"
        prompts_dir.mkdir(parents=True, exist_ok=True)

        for agent in self._ordered_agents():
            llm = (self.config.llm_configs or {}).get(agent.agent_id)
            model = llm.model if llm else ""
            description = (agent.role or agent.agent_id).strip().replace("'", "")
            tools = self._agent_tools_frontmatter(agent.agent_id)

            fm = ["---", f"description: '{description}'", "mode: agent"]
            if model:
                fm.append(f"model: {model}")
            fm.append(f"tools: {json.dumps(tools)}")
            fm.append("---")

            body = [
                f"You are a {agent.role or 'specialist agent'}.",
                "",
                _convert_placeholders(agent.instructions or ""),
                "",
                "## Task",
                _convert_placeholders(agent.prompt or ""),
            ]
            if agent.expected_outputs:
                body += ["", "## Expected output", _convert_placeholders(agent.expected_outputs)]

            content = "\n".join(fm) + "\n\n" + "\n".join(body).strip() + "\n"
            fname = f"{self._uc_slug}-{_slugify(agent.agent_id)}.prompt.md"
            (prompts_dir / fname).write_text(content, encoding="utf-8")

        logger.info("Wrote %d prompt file(s)", len(self.config.agents))

    def _write_skill(self):
        skill_dir = self.package_dir / ".github" / "skills" / self._uc_slug
        steps_dir = skill_dir / "steps"
        steps_dir.mkdir(parents=True, exist_ok=True)

        agents = self._ordered_agents()
        depends = {
            s.agent_id: s.source_agent_id for s in (self.config.orchestration or [])
        }

        step_lines: List[str] = []
        for idx, agent in enumerate(agents, start=1):
            step_slug = f"{idx}_{_slugify(agent.agent_id)}"
            dep = depends.get(agent.agent_id)
            dep_note = f" (depends on `{dep}`)" if dep else ""
            step_lines.append(
                f"{idx}. **{agent.role or agent.agent_id}** — see "
                f"[`steps/{step_slug}.md`](steps/{step_slug}.md){dep_note}"
            )

            step_body = [
                f"# Step {idx}: {agent.role or agent.agent_id}",
                "",
                f"Agent ID: `{agent.agent_id}`",
            ]
            if dep:
                step_body.append(f"Consumes the output of `{dep}` as context.")
            step_body += [
                "",
                "## Instructions",
                _convert_placeholders(agent.instructions or ""),
                "",
                "## Prompt",
                _convert_placeholders(agent.prompt or ""),
            ]
            if agent.expected_outputs:
                step_body += ["", "## Expected output", _convert_placeholders(agent.expected_outputs)]
            (steps_dir / f"{step_slug}.md").write_text(
                "\n".join(step_body).strip() + "\n", encoding="utf-8"
            )

        mcp_servers = self._all_mcp_servers()
        tools_section = ""
        if mcp_servers:
            tool_items = "\n".join(f"- `{s}` (configured in `.vscode/mcp.json`)" for s in mcp_servers)
            tools_section = f"\n## Tools\n\n{tool_items}\n"

        description = (
            (self.config.description or f"Runs the {self.config.usecase_name} workflow.").strip()
        )
        skill = (
            "---\n"
            f"name: {self._uc_slug}\n"
            f"description: >\n"
            f"  Use when {description} Runs the {self.config.usecase_name} "
            f"multi-agent workflow in order.\n"
            "---\n\n"
            f"# {self.config.usecase_name}\n\n"
            "This skill runs a multi-step workflow. Execute the steps **in order**, "
            "passing each step's output as context to the next.\n\n"
            "## Steps\n\n"
            + "\n".join(step_lines)
            + "\n"
            + tools_section
        )
        (skill_dir / "SKILL.md").write_text(skill, encoding="utf-8")
        logger.info("Wrote SKILL.md with %d step(s)", len(agents))

    def _write_agent_file(self):
        agents_dir = self.package_dir / ".github" / "agents"
        agents_dir.mkdir(parents=True, exist_ok=True)

        tools = ["codebase", *self._all_mcp_servers()]
        agents = self._ordered_agents()
        first_llm = next(iter(self.config.llm_configs.values()), None) if self.config.llm_configs else None
        model = first_llm.model if first_llm else ""

        roster = "\n".join(
            f"- **{a.role or a.agent_id}** — {(a.expected_outputs or 'produces intermediate output').splitlines()[0][:120]}"
            for a in agents
        )

        fm = ["---", f"description: '{self.config.usecase_name} workflow orchestrator'"]
        if model:
            fm.append(f"model: {model}")
        fm.append(f"tools: {json.dumps(tools)}")
        fm.append("---")

        body = (
            f"You orchestrate the **{self.config.usecase_name}** workflow.\n\n"
            f"{self.config.description or ''}\n\n"
            "Run these sub-agents in order, feeding each one's output to the next:\n\n"
            f"{roster}\n\n"
            "Follow the detailed step prompts under "
            f"`.github/skills/{self._uc_slug}/steps/`.\n"
        )
        content = "\n".join(fm) + "\n\n" + body
        (agents_dir / f"{self._uc_slug}.agent.md").write_text(content, encoding="utf-8")
        logger.info("Wrote %s.agent.md", self._uc_slug)

    def _write_mcp_json(self):
        server_ids = self._all_mcp_servers()
        if not server_ids:
            return

        registry = self._load_mcp_registry()
        servers: Dict[str, dict] = {}
        for sid in server_ids:
            entry = registry.get(sid, {})
            command = entry.get("command", "python")
            args = entry.get("args", [])
            env_mapping = entry.get("env_mapping", {}) or {}
            env = {var: f"${{input:{var}}}" for var in env_mapping.values()}

            server_def: Dict[str, object] = {"command": command, "args": args}
            if env:
                server_def["env"] = env
            servers[sid] = server_def

        vscode_dir = self.package_dir / ".vscode"
        vscode_dir.mkdir(parents=True, exist_ok=True)
        (vscode_dir / "mcp.json").write_text(
            json.dumps({"servers": servers}, indent=2) + "\n", encoding="utf-8"
        )
        logger.info("Wrote .vscode/mcp.json for %d server(s)", len(servers))

    def _load_mcp_registry(self) -> Dict[str, dict]:
        registry_path = self.project_root / "config" / "mcp_servers_registry.yml"
        if not registry_path.exists():
            logger.warning("MCP registry not found at %s", registry_path)
            return {}
        try:
            data = yaml.safe_load(registry_path.read_text(encoding="utf-8")) or {}
            return data.get("servers", {}) or {}
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to parse MCP registry: %s", exc)
            return {}

    def _write_readme(self):
        agents = self._ordered_agents()
        prompt_list = "\n".join(
            f"- `/{self._uc_slug}-{_slugify(a.agent_id)}` — {a.role or a.agent_id}"
            for a in agents
        )
        mcp_note = ""
        if self._all_mcp_servers():
            mcp_note = (
                "\n### MCP tools\n\n"
                "Copy `.vscode/mcp.json` into your repo, fill the `${input:...}` env "
                "values, and start the servers from the MCP view so Copilot agent mode "
                "can call the same tools DAAN uses.\n"
            )

        readme = (
            f"# {self.config.usecase_name} — GitHub Copilot pack\n\n"
            f"Generated: {datetime.now().isoformat()}\n\n"
            f"{self.config.description or ''}\n\n"
            "## Install\n\n"
            "Copy the `.github/` (and `.vscode/`) folders into the root of your "
            "repository, then reload VS Code.\n\n"
            "## Use\n\n"
            "**As prompts (one agent at a time)** — run these slash commands in Copilot Chat:\n\n"
            f"{prompt_list}\n\n"
            "**As a skill (full workflow)** — Copilot auto-selects "
            f"`.github/skills/{self._uc_slug}/SKILL.md` by its description, or ask it to "
            f"\"run the {self.config.usecase_name} workflow\".\n\n"
            "**As a custom agent** — pick "
            f"`{self._uc_slug}` from the agent selector.\n"
            f"{mcp_note}"
        )
        (self.package_dir / "README.md").write_text(readme, encoding="utf-8")
        logger.info("Wrote README.md")

    def _create_zip(self) -> Path:
        fd, zip_file = tempfile.mkstemp(suffix=".zip", prefix=f"{self.package_dir.name}_")
        os.close(fd)
        zip_path = Path(zip_file)
        with ZipFile(zip_path, "w") as zipf:
            for file_path in self.package_dir.rglob("*"):
                if file_path.is_file():
                    arcname = file_path.relative_to(self.package_dir.parent)
                    zipf.write(file_path, arcname)
        return zip_path


class CopilotExportService:
    """Thin wrapper mirroring UseCaseExportService for the Copilot target."""

    def export(self, config: UseCaseConfig, project_root: Optional[Path] = None) -> Path:
        return CopilotPackageGenerator(config, project_root=project_root).generate()
