"""Export validation service."""

import logging
from typing import List, Optional

from daan.usecases.export.schemas import (
    UseCaseConfig,
    ValidationError,
    ValidationResult,
)

logger = logging.getLogger(__name__)


class ExportValidator:
    """Validate use case configuration for export."""
    
    def validate(self, config: UseCaseConfig) -> ValidationResult:
        """
        Perform comprehensive validation.
        
        Returns ValidationResult with all errors collected (non-fail-fast).
        """
        result = ValidationResult(is_valid=True)
        
        # Validate usecase metadata
        self._validate_usecase_metadata(config, result)
        
        # Validate agents
        self._validate_agents(config, result)
        
        # Validate orchestration
        self._validate_orchestration(config, result)
        
        # Validate LLM configs
        self._validate_llm_configs(config, result)
        
        # Validate tools
        self._validate_tools(config, result)
        
        # Validate MCP mappings
        self._validate_mcp_mappings(config, result)
        
        # Validate input/output schemas
        self._validate_schemas(config, result)
        
        # Validate workflow connectivity
        self._validate_workflow_connectivity(config, result)
        
        return result
    
    def _validate_usecase_metadata(self, config: UseCaseConfig, result: ValidationResult):
        """Validate use case metadata."""
        if not config.usecase_id or not config.usecase_id.strip():
            result.add_error(ValidationError(
                error_code="USECASE_ID_MISSING",
                message="Use case ID is required"
            ))
        
        if not config.usecase_name or not config.usecase_name.strip():
            result.add_error(ValidationError(
                error_code="USECASE_NAME_MISSING",
                message="Use case name is required"
            ))
    
    def _validate_agents(self, config: UseCaseConfig, result: ValidationResult):
        """Validate agent configurations."""
        if not config.agents:
            result.add_error(ValidationError(
                error_code="NO_AGENTS",
                message="At least one agent is required"
            ))
            return
        
        for agent in config.agents:
            # Check prompt
            if not agent.prompt or not agent.prompt.strip():
                result.add_error(ValidationError(
                    error_code="PROMPT_MISSING",
                    agent_id=agent.agent_id,
                    message=f"Prompt missing for agent '{agent.agent_id}'"
                ))
            else:
                # Check for dangling placeholders
                placeholders = self._extract_placeholders(agent.prompt)
                if placeholders:
                    logger.warning(f"Agent {agent.agent_id} has placeholders: {placeholders}")
            
            # Check role
            if not agent.role or not agent.role.strip():
                result.add_error(ValidationError(
                    error_code="ROLE_MISSING",
                    agent_id=agent.agent_id,
                    message=f"Role missing for agent '{agent.agent_id}'"
                ))
            
            # Check instructions
            if not agent.instructions or not agent.instructions.strip():
                result.add_error(ValidationError(
                    error_code="INSTRUCTIONS_MISSING",
                    agent_id=agent.agent_id,
                    message=f"Instructions missing for agent '{agent.agent_id}'"
                ))
    
    def _validate_orchestration(self, config: UseCaseConfig, result: ValidationResult):
        """Validate orchestration steps."""
        if not config.orchestration:
            result.add_error(ValidationError(
                error_code="ORCHESTRATION_EMPTY",
                message="Orchestration must define execution steps"
            ))
            return
        
        agent_ids = {agent.agent_id for agent in config.agents}
        
        for step in config.orchestration:
            if step.agent_id not in agent_ids:
                result.add_error(ValidationError(
                    error_code="AGENT_NOT_FOUND",
                    agent_id=step.agent_id,
                    message=f"Agent '{step.agent_id}' in orchestration step {step.step_index} not found"
                ))
            
            # Validate input source
            if step.input_source == 'user_input':
                if not step.input_key:
                    result.add_error(ValidationError(
                        error_code="ORCHESTRATION_INVALID_INPUT_SOURCE",
                        agent_id=step.agent_id,
                        message=f"Step {step.step_index}: user_input requires input_key"
                    ))
            elif step.input_source == 'previous_agent':
                if not step.source_agent_id:
                    result.add_error(ValidationError(
                        error_code="ORCHESTRATION_INVALID_INPUT_SOURCE",
                        agent_id=step.agent_id,
                        message=f"Step {step.step_index}: previous_agent requires source_agent_id"
                    ))
                elif step.source_agent_id not in agent_ids:
                    result.add_error(ValidationError(
                        error_code="AGENT_NOT_FOUND",
                        agent_id=step.source_agent_id,
                        message=f"Step {step.step_index}: source agent '{step.source_agent_id}' not found"
                    ))
    
    def _validate_llm_configs(self, config: UseCaseConfig, result: ValidationResult):
        """Validate LLM configurations."""
        agent_ids = {agent.agent_id for agent in config.agents}
        
        for agent_id, llm_config in config.llm_configs.items():
            if agent_id not in agent_ids:
                result.add_error(ValidationError(
                    error_code="UNKNOWN_AGENT_IN_LLM_CONFIG",
                    agent_id=agent_id,
                    message=f"LLM config references unknown agent '{agent_id}'"
                ))
                continue
            
            if not llm_config.model or not llm_config.model.strip():
                result.add_error(ValidationError(
                    error_code="LLM_CONFIG_MISSING",
                    agent_id=agent_id,
                    component="model",
                    message=f"Model not specified for agent '{agent_id}'"
                ))
            
            if not llm_config.provider or not llm_config.provider.strip():
                result.add_error(ValidationError(
                    error_code="LLM_CONFIG_MISSING",
                    agent_id=agent_id,
                    component="provider",
                    message=f"Provider not specified for agent '{agent_id}'"
                ))
    
    def _validate_tools(self, config: UseCaseConfig, result: ValidationResult):
        """Validate tool references."""
        for agent_id, tools in config.agent_tools.items():
            if not any(a.agent_id == agent_id for a in config.agents):
                result.add_error(ValidationError(
                    error_code="UNKNOWN_AGENT_IN_TOOLS",
                    agent_id=agent_id,
                    message=f"Tool config references unknown agent '{agent_id}'"
                ))
                continue
            
            for tool in tools:
                if not tool.file_path or not tool.file_path.strip():
                    result.add_error(ValidationError(
                        error_code="TOOL_FILE_NOT_FOUND",
                        agent_id=agent_id,
                        tool_name=tool.tool_name,
                        message=f"Tool '{tool.tool_name}' has no file path"
                    ))
    
    def _validate_mcp_mappings(self, config: UseCaseConfig, result: ValidationResult):
        """Validate MCP server mappings."""
        mcp_server_ids = {mcp.server_id for mcp in config.mcp_servers}
        agent_ids = {agent.agent_id for agent in config.agents}
        
        for agent_id, mapping in config.agent_mcp_mappings.items():
            if agent_id not in agent_ids:
                result.add_error(ValidationError(
                    error_code="UNKNOWN_AGENT_IN_MCP_MAPPING",
                    agent_id=agent_id,
                    message=f"MCP mapping references unknown agent '{agent_id}'"
                ))
                continue
            
            for server_id in mapping.mcp_servers:
                if server_id not in mcp_server_ids:
                    result.add_error(ValidationError(
                        error_code="MCP_CONFIG_MISSING",
                        agent_id=agent_id,
                        component=server_id,
                        message=f"MCP server '{server_id}' referenced but not configured"
                    ))
    
    def _validate_schemas(self, config: UseCaseConfig, result: ValidationResult):
        """Validate input and output schemas."""
        if not config.input_schema and not config.input_mappings:
            result.add_error(ValidationError(
                error_code="INPUT_SCHEMA_UNDEFINED",
                message="Input schema or input mappings must be defined"
            ))
        
        if not config.output_schema and not config.output_mappings:
            result.add_error(ValidationError(
                error_code="OUTPUT_SCHEMA_UNDEFINED",
                message="Output schema or output mappings must be defined"
            ))
    
    def _validate_workflow_connectivity(self, config: UseCaseConfig, result: ValidationResult):
        """Validate that workflow is properly connected."""
        if not config.orchestration:
            return
        
        # Check first step uses user_input
        first_step = min(config.orchestration, key=lambda s: s.step_index)
        if first_step.input_source != 'user_input':
            result.add_error(ValidationError(
                error_code="WORKFLOW_CONNECTIVITY",
                message="First orchestration step must accept user_input"
            ))
        
        # Check all agents in orchestration are defined
        agent_ids = {agent.agent_id for agent in config.agents}
        orch_agents = {step.agent_id for step in config.orchestration}
        
        missing = orch_agents - agent_ids
        if missing:
            result.add_error(ValidationError(
                error_code="ORCHESTRATION_INVALID_AGENT",
                message=f"Orchestration references undefined agents: {missing}"
            ))
    
    @staticmethod
    def _extract_placeholders(text: str) -> List[str]:
        """Extract placeholder patterns like {placeholder} from text."""
        import re
        return re.findall(r'\{([^}]+)\}', text)
