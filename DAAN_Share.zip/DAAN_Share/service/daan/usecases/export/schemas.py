"""Data classes for export configurations."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class AgentPromptConfig:
    """Agent prompt configuration."""
    agent_id: str
    prompt: str
    role: str
    instructions: Optional[str] = None
    expected_outputs: Optional[str] = None
    agent_type: Optional[str] = None


@dataclass
class ToolReference:
    """Reference to a tool used by an agent."""
    tool_name: str
    tool_id: str
    file_path: str
    method_name: Optional[str] = None
    parameters: Dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMConfig:
    """LLM configuration for an agent."""
    agent_id: str
    model: str
    provider: str
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    top_k: Optional[int] = None
    presence_penalty: Optional[float] = None
    frequency_penalty: Optional[float] = None
    other_params: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MCPServerConfig:
    """MCP server configuration."""
    server_id: str
    server_name: str
    transport: str
    server_type: str  # 'builtin' or 'external'
    config: Dict[str, Any] = field(default_factory=dict)
    env_vars: Dict[str, str] = field(default_factory=dict)
    implementation_path: Optional[str] = None


@dataclass
class AgentMCPMapping:
    """Mapping of agents to MCP servers."""
    agent_id: str
    mcp_servers: List[str] = field(default_factory=list)


@dataclass
class InputMapping:
    """Input configuration for a use case."""
    input_key: str
    input_type: str
    required: bool = True
    description: Optional[str] = None
    validation_rules: Dict[str, Any] = field(default_factory=dict)
    accepted_formats: List[str] = field(default_factory=list)


@dataclass
class OutputMapping:
    """Output configuration for a use case."""
    output_key: str
    output_type: str
    description: Optional[str] = None
    format: Optional[str] = None


@dataclass
class AgentOrchestrationStep:
    """Single step in agent orchestration."""
    agent_id: str
    step_index: int
    input_source: str  # 'user_input', 'previous_agent', etc.
    input_key: Optional[str] = None
    source_agent_id: Optional[str] = None
    output_key: Optional[str] = None


@dataclass
class UseCaseConfig:
    """Complete use case configuration."""
    usecase_id: str
    usecase_name: str
    version: str
    description: Optional[str] = None
    
    # Agent info
    agents: List[AgentPromptConfig] = field(default_factory=list)
    
    # Orchestration
    orchestration: List[AgentOrchestrationStep] = field(default_factory=list)
    
    # Tool mappings
    agent_tools: Dict[str, List[ToolReference]] = field(default_factory=dict)
    
    # LLM configs
    llm_configs: Dict[str, LLMConfig] = field(default_factory=dict)
    
    # MCP mappings
    agent_mcp_mappings: Dict[str, AgentMCPMapping] = field(default_factory=dict)
    mcp_servers: List[MCPServerConfig] = field(default_factory=list)
    
    # Input/Output schemas
    input_mappings: List[InputMapping] = field(default_factory=list)
    output_mappings: List[OutputMapping] = field(default_factory=list)
    input_schema: Dict[str, Any] = field(default_factory=dict)
    output_schema: Dict[str, Any] = field(default_factory=dict)
    input_validation_logic: Optional[str] = None
    output_transformation_logic: Optional[str] = None
    
    # Runtime config
    timeout_seconds: Optional[int] = None
    max_retries: int = 3
    retry_delay: int = 1


@dataclass
class ValidationError:
    """A single validation error."""
    error_code: str
    agent_id: Optional[str] = None
    tool_name: Optional[str] = None
    component: Optional[str] = None
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ValidationResult:
    """Result of validation."""
    is_valid: bool
    errors: List[ValidationError] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    def add_error(self, error: ValidationError):
        """Add an error."""
        self.errors.append(error)
        self.is_valid = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "status": "success" if self.is_valid else "failed",
            "errors": [
                {
                    "code": e.error_code,
                    "agent": e.agent_id,
                    "tool": e.tool_name,
                    "component": e.component,
                    "message": e.message,
                    "details": e.details,
                }
                for e in self.errors
            ],
            "warnings": self.warnings,
        }


@dataclass
class ExportPackageMetadata:
    """Metadata for the exported package."""
    usecase_id: str
    usecase_name: str
    version: str
    export_timestamp: str
    include_tools: bool = True
    include_mcp: bool = True
    tool_files: Dict[str, List[str]] = field(default_factory=dict)
    mcp_servers_included: List[str] = field(default_factory=list)
    environment_variables: List[str] = field(default_factory=list)
    python_version_required: str = ">=3.11"
