"""Usecase input suggestion helpers driven by LLM."""

from __future__ import annotations
from daan.llm.llm_provider import get_llm_response

def usecase_input_suggestion(archetype: str, usecase: str) -> str:
    """Use usecase details to generate input guidance via configured LLM."""
    

    try:
        from daan.usecases.usecase_service import get_usecase_details

        usecase_details = get_usecase_details(archetype, usecase)
    except FileNotFoundError as exc:
        return str(exc)

    agent_contents: list[str] = []
    for agent in usecase_details.get("agents", []):
        agent_id = str(agent.get("agent_id", "")).strip()
        agent_name = str(agent.get("agent_name", "")).strip()
        prompt_text = str(agent.get("prompt", "")).strip()
        if not prompt_text:
            continue

        label = agent_name or agent_id or "agent"
        agent_contents.append(f"--- {label} ---\n{prompt_text}")

    if not agent_contents:
        return f"No agent prompts found for archetype '{archetype}' and usecase '{usecase}'."

    prompt = (
        "You are an expert assistant for a data/AI platform. "
        "Below are the contents of all agent files in a workflow folder. "
        "Analyze these files and generate a concise, user-friendly suggestion for what files or data the user should upload to satisfy all agent requirements. "
        "If possible, group similar requirements and clarify any ambiguous terms.\n\n"
        "Only suggest about input required from the user and nothing else. Be as specific as possible about file types, data formats, and any required fields or structures. "
        "If input is coming from any agent and not required from user, do not include in suggestion. Focus on actionable insights that a user can follow to prepare their data for the workflow.\n\n"
        + "\n\n".join(agent_contents)
        + "\n\nRespond with a properly formatted actionable suggestion. Always give output as valid markdown without any explanations or disclaimers. Do not mention the agent file names in your suggestion."
    )

    try:
        return get_llm_response(prompt=prompt, max_tokens=220, temperature=0.2)
    except Exception as exc:
        return f"Error generating suggestion with LLM: {exc}"
