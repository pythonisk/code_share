"""UseCase file-backed data access using DATA_DIR as root."""

from __future__ import annotations

import csv
import re
from pathlib import Path
from sqlalchemy import func, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from daan.admin.user_service import can_edit_archetype
from daan.agents.agent_type_utils import is_chat_agent
from daan.agents.dag_validator import flatten_dag_agent_order, parse_dag_stages, remap_dag_agent_ids, remove_agent_from_dag, validate_stage_dag
from daan.core.database import get_db, SessionLocal
from daan.models.archetype import Agent, Archetype, Category, GeneratedPrompt, PromptVersion, UseCase, UseCaseAgentMapping, UseCaseArchetypeMapping
from daan.models.user import User
from daan.schemas.usecase import AgentOrderItem, UseCaseCreateRequest, UseCaseDuplicateRequest, UseCaseUpdateRequest
from daan.audit.audit_service import write_audit, USE_CASE_CREATED, USE_CASE_DELETED, AGENT_UNMAPPED

from daan.agents.agent_service import list_agents_for_usecase
from daan.core.config import get_settings
from daan.usecases.usecase_input_suggestions import usecase_input_suggestion

WORKSPACE_ROOT = Path(__file__).resolve().parents[3]


def _normalize(value: str) -> str:
    return value.strip().casefold()


def _build_agents_involved(existing_agents: dict[str, Agent], ordered_agent_ids: list[str]) -> str:
    parts = [
        f"{agent_id}:{existing_agents[agent_id].agent_name or ''}|{existing_agents[agent_id].agent_type or ''}"
        for agent_id in ordered_agent_ids
        if agent_id in existing_agents
    ]
    return ";".join(parts)


def _normalize_agent_field(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    if not normalized or normalized == "—":
        return None
    return normalized


def _parse_depends_on_values(value: str | None) -> list[str]:
    normalized = _normalize_agent_field(value)
    if not normalized:
        return []
    return [item.strip().strip("[]") for item in normalized.split(",") if item.strip()]


def _remap_depends_on(value: str | None, logical_to_resolved_agent_id: dict[str, str]) -> str:
    remapped_values = [
        logical_to_resolved_agent_id.get(item, item)
        for item in _parse_depends_on_values(value)
    ]
    return ", ".join(remapped_values)


def _derive_depends_on_from_dag(dag_str: str | None) -> dict[str, str | None]:
    """Mirror the resolved DAG into per-agent upstream IDs for DB compatibility.

    The DAG remains the canonical orchestration source. This helper derives a
    best-effort ``depend_on`` field for each agent so runtime code that still
    consults dependency fields stays aligned with the saved flow.
    """
    depends_on_by_agent_id: dict[str, str | None] = {}
    previous_stage_agent_ids: list[str] = []

    for stage in parse_dag_stages(dag_str or ""):
        stage_agent_ids = [
            str(agent_id).strip()
            for agent_id in stage.get("agents") or []
            if str(agent_id).strip()
        ]
        if not stage_agent_ids:
            continue

        upstream_value = ", ".join(previous_stage_agent_ids) if previous_stage_agent_ids else None
        for agent_id in stage_agent_ids:
            depends_on_by_agent_id[agent_id] = upstream_value

        previous_stage_agent_ids = stage_agent_ids

    return depends_on_by_agent_id


def _apply_agent_item_overrides(db: Session, agent: Agent, item) -> None:
    from daan.prompt_catalog.prompt_service import _generate_duplicate_agent_name, _split_copy_suffix

    prompt_record = db.query(GeneratedPrompt).filter(GeneratedPrompt.id == agent.prompt_id).first() if agent.prompt_id else None
    source_agent = None
    if getattr(item, "copy_from_agent_id", None):
        source_agent = db.query(Agent).filter(Agent.agent_id == item.copy_from_agent_id).first()

    role_value = _normalize_agent_field(item.role)
    inputs_value = _normalize_agent_field(item.inputs)
    agent_name_value = _normalize_agent_field(item.agent_name)
    actions_value = _normalize_agent_field(item.actions)
    output_value = _normalize_agent_field(item.output)
    mcp_tools_value = _normalize_agent_field(item.mcp_tools)
    local_tools_value = _normalize_agent_field(item.local_tools)
    agent_type_value = _normalize_agent_field(item.agent_type)
    depends_on_value = _normalize_agent_field(item.depends_on)
    model_value = _normalize_agent_field(getattr(item, "model", None))
    prompt_value = item.prompt if item.prompt is not None else None

    if getattr(item, "is_canvas_draft", False) and source_agent is not None:
        source_name = _normalize_agent_field(source_agent.agent_name)
        if agent_name_value == source_name:
            agent_name_value = None
        current_name = _normalize_agent_field(agent.agent_name)
        if agent_name_value is None and source_name:
            agent_name_value = _generate_duplicate_agent_name(db, source_agent.agent_name)
        elif agent_name_value is not None:
            base_name, _copy_number = _split_copy_suffix(agent_name_value)
            has_copy_suffix = agent_name_value.strip().casefold() != (base_name or "").strip().casefold()
            if not has_copy_suffix:
                agent_name_value = _generate_duplicate_agent_name(db, agent_name_value)

    if role_value is not None:
        agent.role = role_value
    if inputs_value is not None:
        agent.input_context = inputs_value
    if agent_name_value is not None:
        agent.agent_name = agent_name_value
    if actions_value is not None:
        agent.agent_actions = actions_value
    if output_value is not None:
        agent.output_format = output_value
    if mcp_tools_value is not None:
        agent.mcp_server = mcp_tools_value
    if local_tools_value is not None:
        agent.local_tools = local_tools_value
    if agent_type_value is not None:
        agent.agent_type = agent_type_value
    if depends_on_value is not None:
        agent.depend_on = depends_on_value
    if model_value is not None:
        agent.model = model_value

    if prompt_record is not None:
        if agent_name_value is not None:
            prompt_record.prompt_name = agent_name_value
        if prompt_value is not None:
            prompt_record.prompt_text = prompt_value
            initial_version = db.query(PromptVersion).filter(PromptVersion.prompt_id == prompt_record.id, PromptVersion.version_number == 1).first()
            if initial_version is not None:
                initial_version.prompt_text = prompt_value


# Accepted query values for the premium filter on list endpoints.
PREMIUM_MODE_PREMIUM = "premium"
PREMIUM_MODE_NON_PREMIUM = "non_premium"
VALID_PREMIUM_MODES = {PREMIUM_MODE_PREMIUM, PREMIUM_MODE_NON_PREMIUM}

# Truthy spellings of the stored `premium` field. Kept permissive so the same
# logic works whether the DB stores "Yes"/"No", "true"/"false" or "1"/"0".
_PREMIUM_TRUTHY = {"yes", "y", "true", "1", "premium"}


def is_premium(value) -> bool:
    """Return True when the stored premium value represents a premium use case."""
    if value is None:
        return False
    return str(value).strip().casefold() in _PREMIUM_TRUTHY


def _chat_usecase_flag(agents_involved: str | None) -> str:
    entries = [entry.strip() for entry in str(agents_involved or "").split(";") if entry.strip()]
    for entry in entries:
        agent_type = entry.split("|")[-1].strip() if "|" in entry else entry
        if is_chat_agent(agent_type):
            return "Yes"
    return "No"


def _filter_by_premium_mode(usecases: list, premium_mode: str | None) -> list:
    """Filter ORM use cases by the requested premium mode.

    - ``non_premium`` (default): only non-premium use cases.
    - ``premium``: only premium use cases.
    """
    if not premium_mode:
        return usecases
    if premium_mode == PREMIUM_MODE_PREMIUM:
        return [uc for uc in usecases if is_premium(uc.premium)]
    if premium_mode == PREMIUM_MODE_NON_PREMIUM:
        return [uc for uc in usecases if not is_premium(uc.premium)]
    raise ValueError(
        f"Invalid premium_mode '{premium_mode}'. Expected one of {sorted(VALID_PREMIUM_MODES)}."
    )


def _data_root() -> Path:
    configured = get_settings().DATA_DIR.strip()
    if configured:
        configured_path = Path(configured)
        if configured_path.is_absolute():
            return configured_path
        return (WORKSPACE_ROOT / configured_path).resolve()
    return WORKSPACE_ROOT / "data"


def _archetypes_root() -> Path:
    return _data_root() / "Archetypes"


def _find_archetype_dir(archetype: str) -> Path:
    root = _archetypes_root()
    if not root.exists() or not root.is_dir():
        raise FileNotFoundError("Archetypes root folder not found")

    for candidate in root.iterdir():
        if candidate.is_dir() and _normalize(candidate.name) == _normalize(archetype):
            return candidate

    raise FileNotFoundError(f"Archetype '{archetype}' not found")


def _resolve_usecases_csv(archetype_dir: Path) -> Path | None:
    for file_path in archetype_dir.iterdir():
        if file_path.is_file() and file_path.name.lower() == "usecases.csv":
            return file_path
    return None


def _read_usecase_rows(archetype_dir: Path) -> list[dict[str, str]]:
    csv_path = _resolve_usecases_csv(archetype_dir)
    if csv_path is None:
        return []

    with csv_path.open("r", encoding="utf-8-sig", newline="") as csv_file:
        reader = csv.DictReader(csv_file)
        rows: list[dict[str, str]] = []
        for row in reader:
            normalized_row = {
                str(key).strip().lower(): str(value).strip()
                for key, value in row.items()
                if key is not None
            }
            rows.append(normalized_row)
        return rows



def _get_archetype_by_name(db: Session, archetype_name: str) -> Archetype | None:
    normalized_name = archetype_name.strip()

    archetype = db.query(Archetype).filter(Archetype.name == normalized_name).first()
    if archetype:
        return archetype
    return (
        db.query(Archetype)
        .filter(func.lower(Archetype.name) == normalized_name.casefold())
        .first()
    )


def _require_value(field_name: str, value: str) -> str:
    cleaned = value.strip()
    if not cleaned:
        raise ValueError(f"{field_name} is required")
    return cleaned


def _derive_usecase_initials(archetype_name: str) -> str:
    words = [part for part in re.split(r"\s+", archetype_name.strip()) if part]
    initials: list[str] = []
    for word in words[:2]:
        match = re.search(r"[A-Za-z0-9]", word)
        if match:
            initials.append(match.group(0).upper())

    if len(initials) == 2:
        return "".join(initials)

    fallback = re.sub(r"[^A-Za-z0-9]", "", archetype_name).upper()
    if not fallback:
        return "XX"
    if len(initials) == 1:
        next_char = next((char for char in fallback if char != initials[0]), "X")
        return f"{initials[0]}{next_char}"
    return fallback[:2].ljust(2, "X")


def _generate_next_usecase_id(db: Session, archetype_id: int, prefix: str) -> str:
    token = f"UC_{prefix}_"
    # Query all use case IDs with this prefix globally — not just for this archetype —
    # so we never collide with IDs that exist under a different archetype mapping.
    existing_ids = (
        db.query(UseCase.usecaseid)
        .filter(UseCase.usecaseid.like(f"{token}%"))
        .all()
    )
    latest_suffix = 0
    for (usecase_id,) in existing_ids:
        if not usecase_id:
            continue
        suffix = usecase_id[len(token):]
        if suffix.isdigit():
            latest_suffix = max(latest_suffix, int(suffix))
    return f"UC_{prefix}_{latest_suffix + 1:03d}"


def _list_archetype_roles(db: Session, archetype_name: str) -> list[str]:
    archetype = _get_archetype_by_name(db, archetype_name)
    if archetype is None:
        raise FileNotFoundError(f"Archetype '{archetype_name}' not found")

    mapped_roles = (
        db.query(UseCase.role)
        .join(UseCaseArchetypeMapping, UseCase.usecaseid == UseCaseArchetypeMapping.usecase_id)
        .filter(UseCaseArchetypeMapping.archetype_id == archetype.id)
        .all()
    )
    return sorted(
        {role_name.strip() for (role_name,) in mapped_roles if role_name and role_name.strip()},
        key=str.casefold,
    )


def create_usecase(db: Session, current_user: User, request: UseCaseCreateRequest) -> dict:
    """Create a use case tile and its archetype mapping."""
    archetype_name = _require_value("archetype", request.archetype)
    name = _require_value("name", request.name)
    role = (request.role or "").strip()
    task = _require_value("task", request.task)
    category = (request.category or "").strip() or None

    archetype = _get_archetype_by_name(db, archetype_name)
    if archetype is None:
        raise FileNotFoundError(f"Archetype '{archetype_name}' not found")

    if not can_edit_archetype(db, current_user, archetype.name):
        raise PermissionError(
            f"You do not have edit permission for archetype {archetype.name}"
        )

    duplicate = (
        db.query(UseCase.usecaseid)
        .join(
            UseCaseArchetypeMapping,
            UseCase.usecaseid == UseCaseArchetypeMapping.usecase_id,
        )
        .filter(
            UseCaseArchetypeMapping.archetype_id == archetype.id,
            func.lower(UseCase.name) == name.casefold(),
        )
        .first()
    )
    if duplicate is not None:
        raise ValueError(
            f"Use case name '{name}' already exists in archetype '{archetype.name}'"
        )

    usecase_id = _generate_next_usecase_id(
        db,
        archetype.id,
        _derive_usecase_initials(archetype.name),
    )
    usecase = UseCase(
        usecaseid=usecase_id,
        name=name,
        account=None,
        task=task,
        role=role,
        premium="Yes" if is_premium(request.premium) else "No",
        flow_of_agents="",
        dag="",
        category=category,
    )
    mapping = UseCaseArchetypeMapping(
        usecase_id=usecase_id,
        archetype_id=archetype.id,
    )

    try:
        db.add(usecase)
        db.add(mapping)
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise ValueError("Failed to create use case. Please retry.") from exc

    db.refresh(usecase)

    if category:
        add_category(category)

    write_audit(
        db,
        USE_CASE_CREATED,
        changed_by_user=current_user,
        usecase_id=usecase.usecaseid,
        usecase_name=usecase.name,
    )
    db.commit()

    return {
        "archetype": archetype.name,
        "usecaseid": usecase.usecaseid,
        "name": usecase.name,
        "account": usecase.account,
        "task": usecase.task or "",
        "role": usecase.role or "",
        "premium": usecase.premium,
        "category": usecase.category,
        "agents_involved": usecase.agents_involved,
        "flow_of_agents": usecase.flow_of_agents,
        "dag": usecase.dag,
        "loop_config": usecase.loop_config,
        "chat_usecase": _chat_usecase_flag(usecase.agents_involved),
    }


def duplicate_usecase(
    db: Session,
    current_user: User,
    source_usecase_id: str,
    request: UseCaseDuplicateRequest,
) -> dict:
    """Create a full copy of a use case (metadata + duplicated agents/prompts).

    Reuses ``create_usecase`` for the new tile and ``update_usecase`` for agent
    duplication, so prompt/agent/mapping/DAG linkage matches the canvas save path.
    The copy is created as non-premium (editable) with fresh use case and agent IDs.
    """
    source_id = (source_usecase_id or "").strip()
    if not source_id:
        raise ValueError("Source use case id is required")

    details = get_usecase_details("", source_id)
    source_details = details.get("usecase_details") or {}
    source_agents = details.get("agents") or []
    source_dag = (source_details.get("dag") or "").strip()

    create_request = UseCaseCreateRequest(
        name=request.name,
        archetype=request.archetype,
        role=(source_details.get("role") or ""),
        task=(source_details.get("task") or request.name),
        category=(source_details.get("category") or None),
        premium="No",
    )
    created = create_usecase(db, current_user, create_request)
    new_usecase_id = created["usecaseid"]

    if not source_agents:
        return created

    ordered_agents = [
        AgentOrderItem(
            copy_from_agent_id=agent.get("agent_id"),
            is_canvas_draft=True,
            agent_type=agent.get("agent_type") or "",
            depends_on=agent.get("depends_on") or "",
            execution_order=index + 1,
        )
        for index, agent in enumerate(source_agents)
    ]
    update_request = UseCaseUpdateRequest(dag=source_dag, agents=ordered_agents)

    try:
        return update_usecase(db, new_usecase_id, update_request, current_user)
    except Exception:
        # Roll back pending inserts, then remove the empty tile so no partial copy remains.
        db.rollback()
        try:
            delete_usecase(db, current_user, new_usecase_id)
            db.commit()
        except Exception:
            db.rollback()
        raise


def list_usecases(archetype_name: str, premium_mode: str | None = PREMIUM_MODE_NON_PREMIUM) -> list[dict]:
    """List use cases for one archetype from the database using the mapping table.

    ``premium_mode`` controls which tier is returned:
    - ``non_premium`` (default): only non-premium use cases.
    - ``premium``: only premium use cases.
    Raises ``ValueError`` for any other value.
    """
    with SessionLocal() as db:
        # Find the archetype by name
        arch = db.query(Archetype).filter(Archetype.name == archetype_name).first()
        if not arch:
            # Fallback to case-insensitive name check
            arch = db.query(Archetype).filter(text("LOWER(name) = LOWER(:name)")).params(name=archetype_name).first()
            if not arch:
                raise FileNotFoundError(f"Archetype '{archetype_name}' not found")
        
        # Join UseCase through UseCaseArchetypeMapping, excluding deactivated mappings
        usecases = db.query(UseCase).join(
            UseCaseArchetypeMapping, UseCase.usecaseid == UseCaseArchetypeMapping.usecase_id
        ).filter(
            UseCaseArchetypeMapping.archetype_id == arch.id,
            UseCaseArchetypeMapping.isactive.isnot(False),
        ).all()

        # Apply premium tier filtering before serialization.
        usecases = _filter_by_premium_mode(usecases, premium_mode)

        # Sort alphabetically by use case name.
        usecases = sorted(usecases, key=lambda uc: (uc.name or "").lower())

        return [
            {
                "usecaseid": uc.usecaseid,
                "name": uc.name,
                "account": uc.account,
                "task": uc.task,
                "role": uc.role,
                "premium": uc.premium,
                "category": uc.category,
                "agents_involved": uc.agents_involved,
                "flow_of_agents": uc.flow_of_agents,
                "dag": uc.dag,
                "loop_config": uc.loop_config,
                "chat_usecase": _chat_usecase_flag(uc.agents_involved),
            }
            for uc in usecases
        ]


def list_all_usecases_paginated(
    page: int | None = None,
    page_size: int | None = None,
    premium_mode: str | None = None,
    search: str | None = None,
) -> dict:
    """Return a list of use cases across every archetype.

    ``premium_mode`` is optional: omit for all tiers, or pass ``premium`` /
    ``non_premium`` to filter. If both ``page`` and ``page_size`` are provided,
    pagination is applied. If either is omitted, all matching use cases are
    returned in a single response.
    """
    if premium_mode is not None and premium_mode not in VALID_PREMIUM_MODES:
        raise ValueError(
            f"Invalid premium_mode '{premium_mode}'. Expected one of {sorted(VALID_PREMIUM_MODES)}."
        )

    use_pagination = page is not None and page_size is not None
    if use_pagination:
        if page < 1:
            raise ValueError("page must be >= 1")
        if page_size < 1 or page_size > 600:
            raise ValueError("page_size must be between 1 and 600")
    else:
        page = 1

    search_lower = search.strip().lower() if search and search.strip() else None

    with SessionLocal() as db:
        rows = (
            db.query(UseCase, Archetype.name)
            .join(UseCaseArchetypeMapping, UseCase.usecaseid == UseCaseArchetypeMapping.usecase_id)
            .join(Archetype, Archetype.id == UseCaseArchetypeMapping.archetype_id)
            .filter(UseCaseArchetypeMapping.isactive.isnot(False))
            .all()
        )

        filtered: list[tuple] = []
        for usecase, archetype_name in rows:
            if premium_mode == PREMIUM_MODE_PREMIUM and not is_premium(usecase.premium):
                continue
            if premium_mode == PREMIUM_MODE_NON_PREMIUM and is_premium(usecase.premium):
                continue
            if search_lower:
                haystack = " ".join(
                    filter(None, [usecase.name, usecase.task, usecase.role, usecase.category, archetype_name])
                ).lower()
                if search_lower not in haystack:
                    continue
            filtered.append((usecase, archetype_name))

        filtered.sort(key=lambda pair: ((pair[1] or "").lower(), (pair[0].name or "").lower()))

        total = len(filtered)
        if use_pagination:
            assert page_size is not None
            total_pages = (total + page_size - 1) // page_size if total else 0
            start = (page - 1) * page_size
            page_rows = filtered[start:start + page_size]
            response_page_size = page_size
        else:
            total_pages = 1 if total else 0
            page_rows = filtered
            response_page_size = total

        items = [
            {
                "archetype": archetype_name,
                "usecaseid": usecase.usecaseid,
                "name": usecase.name,
                "account": usecase.account,
                "task": usecase.task,
                "role": usecase.role,
                "premium": usecase.premium,
                "category": usecase.category,
                "agents_involved": usecase.agents_involved,
                "flow_of_agents": usecase.flow_of_agents,
                "dag": usecase.dag,
                "loop_config": usecase.loop_config,
                "chat_usecase": _chat_usecase_flag(usecase.agents_involved),
            }
            for usecase, archetype_name in page_rows
        ]

        return {
            "items": items,
            "page": page,
            "page_size": response_page_size,
            "total": total,
            "total_pages": total_pages,
        }


def resolve_archetype_for_usecase(usecase_id_or_name: str) -> str | None:
    """Return the mapped archetype name for a use case when available."""
    target = (usecase_id_or_name or "").strip()
    if not target:
        return None

    with SessionLocal() as db:
        row = (
            db.query(Archetype.name)
            .join(UseCaseArchetypeMapping, Archetype.id == UseCaseArchetypeMapping.archetype_id)
            .join(UseCase, UseCase.usecaseid == UseCaseArchetypeMapping.usecase_id)
            .filter(
                (UseCase.usecaseid == target) | (UseCase.name == target)
            )
            .first()
        )
        if row is None:
            return None
        return str(row[0] or "").strip() or None

def get_usecase_details(archetype: str, usecase_id_or_name: str) -> dict:
    """Get use case details and its associated agents from the database."""
    with SessionLocal() as db:
        # Get the UseCase
        usecase = db.query(UseCase).filter(
            (UseCase.usecaseid == usecase_id_or_name) | (UseCase.name == usecase_id_or_name)
        ).first()
        
        if not usecase:
            raise FileNotFoundError(f"Usecase '{usecase_id_or_name}' not found")
            
        # Get mapping to agents
        agent_mappings = db.query(UseCaseAgentMapping).filter(
            UseCaseAgentMapping.usecase_id == usecase.usecaseid
        ).order_by(UseCaseAgentMapping.execution_order).all()
        
        agents_data = []
        for mapping in agent_mappings:
            agent = mapping.agent
            if agent is None:
                continue
            # agent.prompt_ref is set via relationship prompt_id -> prompt.id
            prompt_text = agent.prompt_ref.prompt_text if agent.prompt_ref else None
            
            agents_data.append({
                "prompt_id": agent.prompt_id,
                "agent_id": agent.agent_id,
                "agent_name": agent.agent_name,
                "role": agent.role or usecase.role or "",
                "agent_type": agent.agent_type,
                "prompt_file_path": None,
                "prompt": prompt_text,
                "inputs": agent.input_context or "",
                "output": agent.output_format or "",
                "agent_actions": agent.agent_actions or "",
                "output_validators": agent.output_validators or "",
                "guardrails": agent.guardrails or "",
                "mcp_tools": agent.mcp_server or "",
                "local_tools": agent.local_tools or "",
                "depends_on": agent.depend_on or "",
                "model": agent.model or "",
            })
            
        resolved_archetype = str(archetype or "").strip() or resolve_archetype_for_usecase(usecase.usecaseid) or ""

        return {
            "archetype": resolved_archetype,
            "usecase": usecase.usecaseid,
            "usecase_details": {
                "usecaseid": usecase.usecaseid,
                "name": usecase.name,
                "account": usecase.account,
                "task": usecase.task,
                "role": usecase.role,
                "category": usecase.category,
                "premium": usecase.premium,
                "agents_involved": usecase.agents_involved,
                "flow_of_agents": usecase.flow_of_agents,
                "dag": usecase.dag,
                "loop_config": usecase.loop_config,
            },
            "agents": agents_data
        }

def list_agents_for_usecase_db(archetype: str, usecase_id: str) -> list[dict]:
    """List agents for a usecase from the database (full agent profile)."""
    db: Session = next(get_db())
    # Single query: join agents + prompts to avoid N+1
    from sqlalchemy.orm import joinedload
    agent_mappings = (
        db.query(UseCaseAgentMapping)
        .options(joinedload(UseCaseAgentMapping.agent).joinedload(Agent.prompt_ref))
        .filter(UseCaseAgentMapping.usecase_id == usecase_id)
        .order_by(UseCaseAgentMapping.execution_order)
        .all()
    )

    agents_list = []
    for mapping in agent_mappings:
        agent = mapping.agent
        if agent:
            prompt_text = (agent.prompt_ref.prompt_text or '') if agent.prompt_ref else ''
            agents_list.append({
                "agent_id": agent.agent_id,
                "agent_name": agent.agent_name,
                "role": agent.role,
                "agent_type": agent.agent_type,
                "inputs": agent.input_context or "",
                "input_context": agent.input_context or "",
                "agent_actions": agent.agent_actions or "",
                "output_format": agent.output_format or "",
                "output_validators": agent.output_validators or "",
                "guardrails": agent.guardrails or "",
                "mcp_tools": agent.mcp_server or "",
                "local_tools": agent.local_tools or "",
                "depends_on": agent.depend_on or "",
                "prompt": prompt_text,
                "refined_prompt": prompt_text,
                "model": agent.model or "",
            })
    return agents_list

def list_archetype_roles(archetype: str) -> list[str]:
    """Get distinct role names for one archetype."""
    with SessionLocal() as db:
        return _list_archetype_roles(db, archetype)


def list_distinct_categories(archetype: str | None = None) -> list[str]:
    """Return the shared category (skill) catalog, sorted; archetype is ignored."""
    _ = archetype
    with SessionLocal() as db:
        rows = db.query(Category.name).all()
        return sorted(
            {name.strip() for (name,) in rows if name and name.strip()},
            key=str.casefold,
        )


def add_category(name: str) -> str:
    """Idempotently add a category to the shared catalog and return its stored name."""
    clean = (name or "").strip()
    if not clean:
        raise ValueError("Category name is required")
    with SessionLocal() as db:
        existing = (
            db.query(Category)
            .filter(func.lower(Category.name) == clean.casefold())
            .first()
        )
        if existing:
            return existing.name
        db.add(Category(name=clean))
        try:
            db.commit()
        except IntegrityError:
            db.rollback()
        return clean


def backfill_categories_from_usecases() -> None:
    """One-time seed of the shared catalog from distinct existing use-case categories."""
    with SessionLocal() as db:
        if db.query(Category.id).first() is not None:
            return
        rows = db.query(UseCase.category).all()
        names = sorted(
            {cat.strip() for (cat,) in rows if cat and cat.strip()},
            key=str.casefold,
        )
        existing = {n.casefold() for (n,) in db.query(Category.name).all()}
        added = False
        for name in names:
            if name.casefold() in existing:
                continue
            db.add(Category(name=name))
            existing.add(name.casefold())
            added = True
        if added:
            try:
                db.commit()
            except IntegrityError:
                db.rollback()




def get_usecase_input_suggestions(archetype: str, usecase: str, provider_name: str | None = None) -> str:
    """Generate input suggestions for a specific archetype/usecase."""
    _ = provider_name
    return usecase_input_suggestion(archetype, usecase)


def update_usecase(db: Session, usecase_id: str, request: UseCaseUpdateRequest, current_user: User) -> dict:
    """Update metadata and/or agent ordering for an existing use case."""
    usecase = db.query(UseCase).filter(UseCase.usecaseid == usecase_id).first()
    if not usecase:
        raise FileNotFoundError(f"Use case '{usecase_id}' not found")

    # Permission check via archetype mapping
    archetype_name = resolve_archetype_for_usecase(usecase_id)
    if archetype_name and not can_edit_archetype(db, current_user, archetype_name):
        raise PermissionError("You do not have edit permission for this use case")

    # Update scalar metadata fields when provided
    if request.name is not None:
        usecase.name = request.name.strip()
    if request.task is not None:
        usecase.task = request.task.strip()
    if request.role is not None:
        usecase.role = request.role.strip()
    if request.category is not None:
        usecase.category = request.category.strip()
        if usecase.category:
            add_category(usecase.category)
    if request.premium is not None:
        usecase.premium = "Yes" if is_premium(request.premium) else "No"

    # Rebuild agent mappings when an agents list is provided
    if request.agents is not None:
        from daan.prompt_catalog.prompt_service import save_prompt
        from daan.schemas.archetype import PromptCreateUpdate

        logical_dag = (request.dag or "").strip()

        logical_validation_agents: list[dict] = []
        for item in request.agents:
            logical_agent_id = str(item.agent_id or item.copy_from_agent_id or "").strip()
            if not logical_agent_id:
                raise ValueError(
                    "Each agent item must have either agent_id (existing) "
                    "or copy_from_agent_id (dragged from palette)."
                )

            logical_validation_agents.append({
                "agent_id": logical_agent_id,
                "agent_type": item.agent_type or "",
                "depends_on": item.depends_on or "",
            })

        if logical_dag:
            validate_stage_dag(logical_dag, logical_validation_agents)

        # Step 1: Resolve any palette-dragged draft agents into new persisted Agent + Prompt rows.
        resolved_items: list[tuple[str, int]] = []  # (agent_id, execution_order)
        logical_to_resolved_agent_id: dict[str, str] = {}
        resolved_item_by_agent_id: dict[str, object] = {}
        for item in request.agents:
            logical_agent_id = str(item.agent_id or item.copy_from_agent_id or "").strip()
            if item.copy_from_agent_id and item.is_canvas_draft:
                result = save_prompt(db, PromptCreateUpdate(
                    copy_from_agent_id=item.copy_from_agent_id
                ))
                resolved_agent_id = result["agent_id"]
            elif item.is_canvas_draft:
                # Canvas-created or uploaded draft with no source agent: file a brand-new
                # agent on the same rail as the copy button (no use_case_id here — this
                # function owns the mapping/dag). The placeholder agent_id is ignored.
                result = save_prompt(db, PromptCreateUpdate(
                    agent_name=item.agent_name,
                    role=item.role,
                    input_context=item.inputs,
                    agent_actions=item.actions,
                    output_format=item.output,
                    mcp_server=item.mcp_tools,
                    local_tools=item.local_tools,
                    agent_type=item.agent_type,
                    prompt=item.prompt,
                    model=getattr(item, "model", None),
                ))
                resolved_agent_id = result["agent_id"]
            elif item.agent_id:
                resolved_agent_id = item.agent_id
            else:
                raise ValueError(
                    "Each agent item must have either agent_id (existing) "
                    "or copy_from_agent_id (dragged from palette)."
                )

            logical_to_resolved_agent_id[logical_agent_id] = resolved_agent_id
            resolved_item_by_agent_id[resolved_agent_id] = item
            resolved_items.append((resolved_agent_id, item.execution_order))

        submitted_ids = [aid for aid, _ in resolved_items]

        # Validate all resolved agent_ids exist in the DB
        existing_agents: dict[str, Agent] = {
            a.agent_id: a
            for a in db.query(Agent).filter(Agent.agent_id.in_(submitted_ids)).all()
        }
        missing = [aid for aid in submitted_ids if aid not in existing_agents]
        if missing:
            raise ValueError(f"Unknown agent_id(s): {', '.join(missing)}")

        for resolved_agent_id, _execution_order in resolved_items:
            item = resolved_item_by_agent_id[resolved_agent_id]
            db_agent = existing_agents[resolved_agent_id]
            _apply_agent_item_overrides(db, db_agent, item)

        # Step 2: Remove current mappings for this use case only
        # (the agents table and mappings for other use cases are untouched)
        db.query(UseCaseAgentMapping).filter(
            UseCaseAgentMapping.usecase_id == usecase_id
        ).delete(synchronize_session=False)

        resolved_dag = remap_dag_agent_ids(logical_dag, logical_to_resolved_agent_id) if logical_dag else ""

        validation_agents: list[dict] = []
        if resolved_dag:
            for agent_id in flatten_dag_agent_order(resolved_dag):
                db_agent = existing_agents.get(agent_id)
                if db_agent is None:
                    raise ValueError(
                        "Flow references an unknown agent; re-open and re-save the flow."
                    )
                validation_agents.append({
                    "agent_id": agent_id,
                    "agent_type": db_agent.agent_type or "",
                    "depends_on": db_agent.depend_on or "",
                })

            validate_stage_dag(resolved_dag, validation_agents)

        derived_depends_on_by_agent_id = _derive_depends_on_from_dag(resolved_dag)
        for agent_id in submitted_ids:
            db_agent = existing_agents[agent_id]
            db_agent.depend_on = derived_depends_on_by_agent_id.get(agent_id)

        # Step 3: Insert new ordered mappings
        for agent_id, execution_order in resolved_items:
            db.add(UseCaseAgentMapping(
                usecase_id=usecase_id,
                agent_id=agent_id,
                execution_order=execution_order,
            ))

        # Step 4: Recompute dag and flow_of_agents from the resolved order
        ordered_ids = flatten_dag_agent_order(resolved_dag)
        usecase.dag = resolved_dag
        usecase.flow_of_agents = _build_agents_involved(existing_agents, ordered_ids)
        usecase.agents_involved = usecase.flow_of_agents

    try:
        db.commit()
        db.refresh(usecase)
    except IntegrityError as exc:
        db.rollback()
        raise ValueError("Failed to update use case.") from exc

    resolved_archetype = archetype_name or resolve_archetype_for_usecase(usecase_id) or ""
    return {
        "archetype": resolved_archetype,
        "usecaseid": usecase.usecaseid,
        "name": usecase.name,
        "account": usecase.account,
        "task": usecase.task or "",
        "role": usecase.role or "",
        "premium": usecase.premium,
        "category": usecase.category,
        "agents_involved": usecase.agents_involved,
        "flow_of_agents": usecase.flow_of_agents,
        "dag": usecase.dag,
        "loop_config": usecase.loop_config,
        "chat_usecase": _chat_usecase_flag(usecase.agents_involved),
    }


def delete_usecase(db: Session, current_user: User, usecase_id: str) -> None:
    """Delete a use case, its mappings, and its agents/prompts.  Agents that are
    also mapped to another use case are preserved (only unmapped) so no other
    use case loses data.  Raises ``PermissionError`` if the caller lacks edit
    rights and ``FileNotFoundError`` if the use case does not exist.
    """
    usecase = db.query(UseCase).filter(UseCase.usecaseid == usecase_id).first()
    if not usecase:
        raise FileNotFoundError(f"Use case '{usecase_id}' not found")

    # Resolve archetype for permission check
    arch_mapping = (
        db.query(UseCaseArchetypeMapping)
        .filter(UseCaseArchetypeMapping.usecase_id == usecase_id)
        .first()
    )
    if arch_mapping:
        arch = db.query(Archetype).filter(Archetype.id == arch_mapping.archetype_id).first()
        arch_name = arch.name if arch else None
        if arch_name and not can_edit_archetype(db, current_user, arch_name):
            raise PermissionError(
                f"You do not have edit permission for archetype '{arch_name}'"
            )

    # Capture names before deletion for the audit row
    uc_name = usecase.name

    # Agents mapped to this use case.
    agent_ids = [
        agent_id
        for (agent_id,) in db.query(UseCaseAgentMapping.agent_id)
        .filter(UseCaseAgentMapping.usecase_id == usecase_id)
        .distinct()
        .all()
    ]
    # Agents also used by another use case must be kept (only unmapped here).
    shared_agent_ids = {
        agent_id
        for (agent_id,) in db.query(UseCaseAgentMapping.agent_id)
        .filter(
            UseCaseAgentMapping.agent_id.in_(agent_ids),
            UseCaseAgentMapping.usecase_id != usecase_id,
        )
        .distinct()
        .all()
    } if agent_ids else set()
    deletable_agent_ids = [agent_id for agent_id in agent_ids if agent_id not in shared_agent_ids]
    prompt_ids = (
        [
            prompt_id
            for (prompt_id,) in db.query(Agent.prompt_id)
            .filter(Agent.agent_id.in_(deletable_agent_ids), Agent.prompt_id.isnot(None))
            .all()
        ]
        if deletable_agent_ids
        else []
    )

    # Remove this use case's mappings first (unmaps shared agents too).
    db.query(UseCaseAgentMapping).filter(
        UseCaseAgentMapping.usecase_id == usecase_id
    ).delete(synchronize_session=False)
    db.query(UseCaseArchetypeMapping).filter(
        UseCaseArchetypeMapping.usecase_id == usecase_id
    ).delete(synchronize_session=False)

    # Delete the agents and prompts that belong only to this use case.
    if deletable_agent_ids:
        db.query(Agent).filter(Agent.agent_id.in_(deletable_agent_ids)).delete(synchronize_session=False)
    if prompt_ids:
        # Remove prompt versions first so the prompt rows delete cleanly on any DB.
        db.query(PromptVersion).filter(PromptVersion.prompt_id.in_(prompt_ids)).delete(synchronize_session=False)
        db.query(GeneratedPrompt).filter(GeneratedPrompt.id.in_(prompt_ids)).delete(synchronize_session=False)

    db.delete(usecase)
    db.flush()

    write_audit(
        db,
        USE_CASE_DELETED,
        changed_by_user=current_user,
        usecase_id=usecase_id,
        usecase_name=uc_name,
    )
    db.commit()



def unmap_agent_from_usecase(db: Session, current_user: User, usecase_id: str, agent_id: str) -> None:
    """Remove an agent from a use case without deleting the agent itself.

    Updates the UseCase DAG / flow_of_agents / agents_involved strings and
    removes the UseCaseAgentMapping row.  Raises ``FileNotFoundError`` if
    either entity does not exist.
    """
    usecase = db.query(UseCase).filter(UseCase.usecaseid == usecase_id).first()
    if not usecase:
        raise FileNotFoundError(f"Use case '{usecase_id}' not found")

    agent = db.query(Agent).filter(Agent.agent_id == agent_id).first()
    if not agent:
        raise FileNotFoundError(f"Agent '{agent_id}' not found")

    # Remove the mapping row
    db.query(UseCaseAgentMapping).filter(
        UseCaseAgentMapping.usecase_id == usecase_id,
        UseCaseAgentMapping.agent_id == agent_id,
    ).delete(synchronize_session=False)

    # Update UseCase string fields
    if usecase.dag:
        usecase.dag = remove_agent_from_dag(usecase.dag, agent_id)

    if usecase.flow_of_agents and agent.agent_name:
        flow_parts = [entry.strip() for entry in usecase.flow_of_agents.split(";") if entry.strip()]
        usecase.flow_of_agents = ";".join(
            entry for entry in flow_parts if not entry.startswith(f"{agent_id}:")
        )

    if usecase.agents_involved:
        involved_parts = [e.strip() for e in usecase.agents_involved.split(";") if e.strip()]
        involved_parts = [e for e in involved_parts if not e.startswith(f"{agent_id}:")]
        usecase.agents_involved = ";".join(involved_parts)

    db.flush()

    write_audit(
        db,
        AGENT_UNMAPPED,
        changed_by_user=current_user,
        usecase_id=usecase_id,
        usecase_name=usecase.name,
        agent_id=agent_id,
        agent_name=agent.agent_name,
    )
    db.commit()
