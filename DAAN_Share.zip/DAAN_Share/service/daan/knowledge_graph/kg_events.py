"""
Knowledge Graph event emitter — captures workflow lifecycle events.

Each function writes one or more nodes / edges into the KG.
All operations are fire-and-forget: failures are logged but never
propagate to the workflow.  This keeps the KG entirely non-blocking.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from datetime import datetime, timezone
from typing import Any, TYPE_CHECKING

from daan.core.logging import get_logger

if TYPE_CHECKING:
    import kuzu

logger = get_logger(__name__)


def _id() -> str:
    return uuid.uuid4().hex


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _esc(val: Any) -> str:
    """Escape a value for safe embedding in single-quoted Cypher literals."""
    if val is None:
        return ""
    return str(val).replace("\\", "\\\\").replace("'", "\\'")


def _safe_exec(conn: "kuzu.Connection", cypher: str) -> None:
    """Execute Cypher with error swallowing — KG writes must never crash the workflow."""
    try:
        conn.execute(cypher)
    except Exception as exc:
        logger.error("KG write failed [%s]: %s", exc, cypher[:300])


# ═══════════════════════════════════════════════════════════════════════════
#  Stable entity upserts (idempotent — MERGE)
# ═══════════════════════════════════════════════════════════════════════════

def ensure_archetype(conn: "kuzu.Connection", archetype_name: str) -> str:
    """Ensure an Archetype node exists; return its id."""
    now = _now()
    # Check if exists
    result = conn.execute(f"MATCH (a:Archetype) WHERE a.name = '{_esc(archetype_name)}' RETURN a.id AS id")
    if result.has_next():
        return result.get_next()[0]
    # Create new
    aid = _id()
    _safe_exec(conn, f"CREATE (a:Archetype {{id: '{aid}', name: '{_esc(archetype_name)}', description: '', created_at: timestamp('{now}'), updated_at: timestamp('{now}')}})")
    return aid


def ensure_usecase(conn: "kuzu.Connection", usecase_id: str, usecase_name: str = "") -> str:
    """Ensure a UseCase node exists (with a human-readable name); return its id.

    The display name shown in the graph is ``UseCase.name``.  When a real
    ``usecase_name`` is supplied it is also back-filled onto pre-existing nodes
    whose name was previously stored as the raw id (so older graphs upgrade in
    place instead of keeping the cryptic use-case id as the label).
    """
    now = _now()
    canonical_id = _esc((usecase_id or "").strip())
    if not canonical_id:
        canonical_id = _id()

    display_name = _esc((usecase_name or "").strip())

    # Canonical lookup by primary id.
    result = conn.execute(f"MATCH (uc:UseCase) WHERE uc.id = '{canonical_id}' RETURN uc.id AS id, uc.name AS name")
    if result.has_next():
        row = result.get_next()
        existing_id, existing_name = row[0], row[1]
        # Back-fill the friendly name if we now know it and the stored name is
        # missing or is just the raw id.
        if display_name and (not existing_name or existing_name == canonical_id):
            _safe_exec(conn, f"MATCH (uc:UseCase) WHERE uc.id = '{canonical_id}' SET uc.name = '{display_name}', uc.updated_at = timestamp('{now}')")
        return existing_id

    # Backward compatibility for legacy records keyed by name.
    legacy = conn.execute(f"MATCH (uc:UseCase) WHERE uc.name = '{canonical_id}' RETURN uc.id AS id")
    if legacy.has_next():
        return legacy.get_next()[0]

    name = display_name or canonical_id
    _safe_exec(conn, f"CREATE (uc:UseCase {{id: '{canonical_id}', name: '{name}', description: '', category: '', created_at: timestamp('{now}'), updated_at: timestamp('{now}')}})")
    return canonical_id


def ensure_user(conn: "kuzu.Connection", username: str, email: str = "") -> str:
    """Ensure a User node exists; return its id."""
    now = _now()
    canonical_id = _esc((username or "").strip())
    if not canonical_id:
        canonical_id = _id()

    result = conn.execute(f"MATCH (u:User) WHERE u.id = '{canonical_id}' RETURN u.id AS id")
    if result.has_next():
        return result.get_next()[0]

    result = conn.execute(f"MATCH (u:User) WHERE u.username = '{canonical_id}' RETURN u.id AS id")
    if result.has_next():
        return result.get_next()[0]

    _safe_exec(conn, f"CREATE (u:User {{id: '{canonical_id}', username: '{canonical_id}', email: '{_esc(email)}', created_at: timestamp('{now}')}})")
    return canonical_id


# ═══════════════════════════════════════════════════════════════════════════
#  Session lifecycle
# ═══════════════════════════════════════════════════════════════════════════

def on_session_created(
    conn: "kuzu.Connection",
    session_id: str,
    username: str,
    archetype: str,
    usecase_id: str,
    usecase_name: str = "",
) -> str:
    """Record that a session was started by a user for a given use case.

    Creates: Session, User (if needed), UseCase (if needed), Archetype (if needed).
    Edges:   User -[INITIATED]-> Session,  UseCase -[HAS_SESSION]-> Session
    Returns: The KG session node id (= session_id).
    """
    now = _now()
    kg_session_id = _esc(session_id)

    # Even when the session already exists, make sure the use-case name is
    # back-filled (older sessions were created before the name was wired in).
    uc_kg_id = ensure_usecase(conn, usecase_id, usecase_name)

    # Idempotency: skip the rest if session already exists
    result = conn.execute(f"MATCH (s:Session) WHERE s.id = '{kg_session_id}' RETURN s.id")
    if result.has_next():
        return session_id

    # Create session node
    _safe_exec(conn, f"CREATE (s:Session {{id: '{kg_session_id}', status: 'running', started_at: timestamp('{now}'), ended_at: null, metadata: '{{}}'}})")

    # Ensure related entities
    user_id = ensure_user(conn, username)
    arch_kg_id = ensure_archetype(conn, archetype)

    # Edges
    _safe_exec(conn, f"MATCH (u:User {{id: '{user_id}'}}), (s:Session {{id: '{kg_session_id}'}}) CREATE (u)-[:INITIATED {{initiated_at: timestamp('{now}')}}]->(s)")
    _safe_exec(conn, f"MATCH (uc:UseCase {{id: '{uc_kg_id}'}}), (s:Session {{id: '{kg_session_id}'}}) CREATE (uc)-[:HAS_SESSION {{created_at: timestamp('{now}')}}]->(s)")
    _safe_exec(conn, f"MATCH (s:Session {{id: '{kg_session_id}'}}), (a:Archetype {{id: '{arch_kg_id}'}}) CREATE (s)-[:HAS_ARCHETYPE {{created_at: timestamp('{now}')}}]->(a)")

    logger.info("KG: session %s created", session_id)
    return session_id


# ═══════════════════════════════════════════════════════════════════════════
#  Run lifecycle
# ═══════════════════════════════════════════════════════════════════════════

def on_run_started(
    conn: "kuzu.Connection",
    session_id: str,
    iteration_id: str,
    run_number: int,
    trigger: str = "manual",
    previous_run_id: str | None = None,
) -> str:
    """Record that a new run started within a session.

    Creates: Run node
    Edges:   Session -[HAS_RUN]-> Run,  Run -[PREVIOUS_RUN]-> PrevRun (if rerun)
    """
    now = _now()
    esc_rid = _esc(iteration_id)
    esc_sid = _esc(session_id)

    existing = conn.execute(f"MATCH (r:Run) WHERE r.id = '{esc_rid}' RETURN r.id")
    if not existing.has_next():
        _safe_exec(conn, f"CREATE (r:Run {{id: '{esc_rid}', run_number: {run_number}, status: 'running', started_at: timestamp('{now}'), ended_at: null, duration_ms: 0, trigger: '{_esc(trigger)}', metadata: '{{}}'}})")
    _safe_exec(conn, f"MATCH (s:Session {{id: '{esc_sid}'}}), (r:Run {{id: '{esc_rid}'}}) CREATE (s)-[:HAS_RUN {{created_at: timestamp('{now}')}}]->(r)")

    if previous_run_id:
        _safe_exec(conn, f"MATCH (r2:Run {{id: '{esc_rid}'}}), (r1:Run {{id: '{_esc(previous_run_id)}'}}) CREATE (r2)-[:PREVIOUS_RUN {{created_at: timestamp('{now}')}}]->(r1)")

    logger.info("KG: run %s started (session=%s, #%d)", iteration_id, session_id, run_number)
    return iteration_id


def on_run_completed(
    conn: "kuzu.Connection",
    iteration_id: str,
    status: str = "completed",
    duration_ms: int = 0,
) -> None:
    """Mark a run as completed/failed."""
    now = _now()
    _safe_exec(conn, f"MATCH (r:Run) WHERE r.id = '{_esc(iteration_id)}' SET r.status = '{_esc(status)}', r.ended_at = timestamp('{now}'), r.duration_ms = {duration_ms}")


# ═══════════════════════════════════════════════════════════════════════════
#  Agent execution
# ═══════════════════════════════════════════════════════════════════════════

def ensure_agent(conn: "kuzu.Connection", agent_id: str, agent_name: str = "", agent_type: str = "Sub_Agent") -> str:
    """Ensure an Agent blueprint node exists."""
    now = _now()
    esc_aid = _esc((agent_id or "").strip())
    if not esc_aid:
        esc_aid = _id()

    result = conn.execute(f"MATCH (a:Agent) WHERE a.id = '{esc_aid}' RETURN a.id AS id")
    if result.has_next():
        return result.get_next()[0]

    result = conn.execute(f"MATCH (a:Agent) WHERE a.name = '{esc_aid}' RETURN a.id AS id")
    if result.has_next():
        return result.get_next()[0]

    _safe_exec(conn, f"CREATE (a:Agent {{id: '{esc_aid}', name: '{esc_aid}', agent_type: '{_esc(agent_type)}', version: '1.0', description: '{_esc(agent_name)}', config_ref: '', created_at: timestamp('{now}'), updated_at: timestamp('{now}')}})")
    return esc_aid


def on_agent_run_started(
    conn: "kuzu.Connection",
    iteration_id: str,
    agent_run_id: str,
    agent_id: str,
    agent_name: str = "",
    agent_type: str = "Sub_Agent",
    execution_order: int = 1,
) -> str:
    """Record an agent execution starting within a run.

    Creates: AgentRun, Agent (if needed)
    Edges:   Run -[EXECUTED_AGENT]-> AgentRun,  AgentRun -[INSTANCE_OF]-> Agent
    """
    now = _now()
    esc_arid = _esc(agent_run_id)

    agent_kg_id = ensure_agent(conn, agent_id, agent_name, agent_type)

    existing = conn.execute(f"MATCH (ar:AgentRun) WHERE ar.id = '{esc_arid}' RETURN ar.id")
    if not existing.has_next():
        _safe_exec(conn, f"CREATE (ar:AgentRun {{id: '{esc_arid}', status: 'running', execution_order: {execution_order}, started_at: timestamp('{now}'), ended_at: null, duration_ms: 0, error_message: null, retry_count: 0, log_ref: '', metadata: '{{}}'}})")
    _safe_exec(conn, f"MATCH (r:Run {{id: '{_esc(iteration_id)}'}}), (ar:AgentRun {{id: '{esc_arid}'}}) CREATE (r)-[:EXECUTED_AGENT {{execution_order: {execution_order}}}]->(ar)")
    _safe_exec(conn, f"MATCH (ar:AgentRun {{id: '{esc_arid}'}}), (a:Agent {{id: '{agent_kg_id}'}}) CREATE (ar)-[:INSTANCE_OF {{created_at: timestamp('{now}')}}]->(a)")

    return agent_run_id


def on_agent_run_completed(
    conn: "kuzu.Connection",
    agent_run_id: str,
    status: str = "completed",
    duration_ms: int = 0,
    error_message: str | None = None,
) -> None:
    """Mark an agent run as completed/failed."""
    now = _now()
    err = f", ar.error_message = '{_esc(error_message)}'" if error_message else ""
    _safe_exec(conn, f"MATCH (ar:AgentRun) WHERE ar.id = '{_esc(agent_run_id)}' SET ar.status = '{_esc(status)}', ar.ended_at = timestamp('{now}'), ar.duration_ms = {duration_ms}{err}")


# ═══════════════════════════════════════════════════════════════════════════
#  Artifacts
# ═══════════════════════════════════════════════════════════════════════════

def on_artifact_created(
    conn: "kuzu.Connection",
    agent_run_id: str,
    artifact_name: str,
    artifact_type: str = "output",
    content_ref: str = "",
    mime_type: str = "text/plain",
    size_bytes: int = 0,
    direction: str = "generated",
) -> str:
    """Record an artifact being generated or consumed by an agent run.

    direction: "generated" or "used_input"
    """
    now = _now()
    art_id = _id()
    _safe_exec(conn, f"CREATE (art:Artifact {{id: '{art_id}', name: '{_esc(artifact_name)}', artifact_type: '{_esc(artifact_type)}', content_ref: '{_esc(content_ref)}', mime_type: '{_esc(mime_type)}', size_bytes: {size_bytes}, hash: '', created_at: timestamp('{now}'), metadata: '{{}}'}})")

    if direction == "generated":
        _safe_exec(conn, f"MATCH (ar:AgentRun {{id: '{_esc(agent_run_id)}'}}), (art:Artifact {{id: '{art_id}'}}) CREATE (ar)-[:GENERATED {{generated_at: timestamp('{now}')}}]->(art)")
    else:
        _safe_exec(conn, f"MATCH (ar:AgentRun {{id: '{_esc(agent_run_id)}'}}), (art:Artifact {{id: '{art_id}'}}) CREATE (ar)-[:USED_INPUT {{consumed_at: timestamp('{now}')}}]->(art)")

    return art_id


# ═══════════════════════════════════════════════════════════════════════════
#  Quality & Issues
# ═══════════════════════════════════════════════════════════════════════════

def on_quality_assessed(
    conn: "kuzu.Connection",
    iteration_id: str,
    score: float,
    max_score: float = 100.0,
    assessment_type: str = "qc_check",
    summary: str = "",
    details_ref: str = "",
) -> str:
    """Record a quality assessment for a run."""
    now = _now()
    qa_id = _id()
    _safe_exec(conn, f"CREATE (qa:QualityAssessment {{id: '{qa_id}', score: {score}, max_score: {max_score}, assessment_type: '{_esc(assessment_type)}', summary: '{_esc(summary)}', details_ref: '{_esc(details_ref)}', created_at: timestamp('{now}')}})")
    _safe_exec(conn, f"MATCH (r:Run {{id: '{_esc(iteration_id)}'}}), (qa:QualityAssessment {{id: '{qa_id}'}}) CREATE (r)-[:HAS_QUALITY {{assessed_at: timestamp('{now}')}}]->(qa)")
    return qa_id

def on_agent_quality_assessed(
    conn: "kuzu.Connection",
    agent_run_id: str,
    score: float,
    max_score: float = 100.0,
    assessment_type: str = "per_agent_qc",
    summary: str = "",
    details_ref: str = "",
) -> str:
    """Record a per-agent quality assessment linked to an AgentRun node.

    Unlike :func:`on_quality_assessed` (which links from a *Run*), this creates
    the ``AgentRun -[HAS_QUALITY]-> QualityAssessment`` edge so each individual
    agent's quality score is independently queryable in the knowledge graph.
    Both dynamic and action agents are covered; the schema already supports the
    ``AgentRun`` source on the ``HAS_QUALITY`` relation.
    """
    now = _now()
    qa_id = _id()
    _safe_exec(conn, f"CREATE (qa:QualityAssessment {{id: '{qa_id}', score: {score}, max_score: {max_score}, assessment_type: '{_esc(assessment_type)}', summary: '{_esc(summary)}', details_ref: '{_esc(details_ref)}', created_at: timestamp('{now}')}})") 
    _safe_exec(conn, f"MATCH (ar:AgentRun {{id: '{_esc(agent_run_id)}'}}), (qa:QualityAssessment {{id: '{qa_id}'}}) CREATE (ar)-[:HAS_QUALITY {{assessed_at: timestamp('{now}')}}]->(qa)")
    return qa_id

# ═══════════════════════════════════════════════════════════════════════════
#  Feedback
# ═══════════════════════════════════════════════════════════════════════════

def on_feedback_submitted(
    conn: "kuzu.Connection",
    session_id: str,
    feedback_id: str,
    feedback_type: str = "user",
    rating: int = 0,
    comment: str = "",
    source: str = "user",
    refers_to_run_id: str | None = None,
    targets_agent_id: str | None = None,
    usecase_id: str | None = None,
) -> str:
    """Record user feedback within a session."""
    now = _now()
    esc_fid = _esc(feedback_id)
    existing = conn.execute(f"MATCH (f:Feedback) WHERE f.id = '{esc_fid}' RETURN f.id")
    if not existing.has_next():
        _safe_exec(conn, f"CREATE (f:Feedback {{id: '{esc_fid}', feedback_type: '{_esc(feedback_type)}', rating: {rating}, comment: '{_esc(comment)}', source: '{_esc(source)}', created_at: timestamp('{now}')}})")
    _safe_exec(conn, f"MATCH (s:Session {{id: '{_esc(session_id)}'}}), (f:Feedback {{id: '{esc_fid}'}}) CREATE (s)-[:HAS_FEEDBACK {{created_at: timestamp('{now}')}}]->(f)")

    if refers_to_run_id:
        _safe_exec(conn, f"MATCH (f:Feedback {{id: '{esc_fid}'}}), (r:Run {{id: '{_esc(refers_to_run_id)}'}}) CREATE (f)-[:REFERS_TO_RUN]->(r)")

    if targets_agent_id:
        agent_kg_id = ensure_agent(conn, targets_agent_id)
        _safe_exec(conn, f"MATCH (f:Feedback {{id: '{esc_fid}'}}), (a:Agent {{id: '{agent_kg_id}'}}) CREATE (f)-[:TARGETS_AGENT]->(a)")

    if usecase_id:
        uc_kg_id = ensure_usecase(conn, usecase_id)
        _safe_exec(conn, f"MATCH (f:Feedback {{id: '{esc_fid}'}}), (uc:UseCase {{id: '{uc_kg_id}'}}) CREATE (f)-[:FOR_USECASE]->(uc)")

    return feedback_id


def on_feedback_triggered_rerun(
    conn: "kuzu.Connection",
    feedback_id: str,
    new_run_id: str,
) -> None:
    """Link feedback to the rerun it triggered."""
    now = _now()
    _safe_exec(conn, f"MATCH (f:Feedback {{id: '{_esc(feedback_id)}'}}), (r:Run {{id: '{_esc(new_run_id)}'}}) CREATE (f)-[:TRIGGERED_RERUN {{triggered_at: timestamp('{now}')}}]->(r)")


# ═══════════════════════════════════════════════════════════════════════════
#  Session completion
# ═══════════════════════════════════════════════════════════════════════════

def on_session_completed(conn: "kuzu.Connection", session_id: str, status: str = "completed") -> None:
    """Mark a session as completed."""
    now = _now()
    _safe_exec(conn, f"MATCH (s:Session) WHERE s.id = '{_esc(session_id)}' SET s.status = '{_esc(status)}', s.ended_at = timestamp('{now}')")


# ═══════════════════════════════════════════════════════════════════════════
#  External resources (MCP-created artefacts — for idempotent re-runs)
# ═══════════════════════════════════════════════════════════════════════════

def _external_resource_id(session_id: str, agent_id: str, local_key: str) -> str:
    """Deterministic node id so re-runs update the same ExternalResource."""
    raw = f"{session_id}|{agent_id}|{local_key}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()


def upsert_external_resource(
    conn: "kuzu.Connection",
    session_id: str,
    agent_id: str,
    resource: dict[str, Any],
) -> str | None:
    """Idempotently record an external resource created by an action agent.

    The node identity is the external resource id (e.g. the ADO work-item id)
    when present, falling back to ``local_key`` only for items that have no
    external id yet. Keying on the external id means the same real-world
    resource collapses to a single node even if the agent re-emits it under a
    different ``local_key`` across feedback re-runs (which otherwise produces
    duplicate manifest entries pointing at the same id). ``resource`` is the
    parsed manifest entry emitted by the agent, e.g.::

        {"local_key": "epic-1", "type": "ado_work_item", "kind": "epic",
         "id": "12345", "url": "https://dev.azure.com/.../12345"}

    Returns the ExternalResource node id, or ``None`` when there is nothing
    meaningful to store. Never raises — KG writes must not break the workflow.
    """
    sid = (session_id or "").strip()
    aid = (agent_id or "").strip()
    if not sid or not aid or not isinstance(resource, dict):
        return None

    resource_key = str(
        resource.get("id")
        or resource.get("key")
        or resource.get("resource_key")
        or ""
    ).strip()
    local_key = str(
        resource.get("local_key")
        or resource.get("localKey")
        or resource_key
    ).strip()
    if not resource_key and not local_key:
        return None

    # Identity = external id when known (dedupes re-emitted local_keys), else local_key.
    identity = f"key:{resource_key}" if resource_key else f"local:{local_key}"
    node_id = _external_resource_id(sid, aid, identity)
    resource_type = str(resource.get("type") or resource.get("resource_type") or "").strip()
    resource_kind = str(resource.get("kind") or resource.get("resource_kind") or "").strip()
    external_url = str(resource.get("url") or resource.get("external_url") or "").strip()
    metadata = json.dumps(resource, ensure_ascii=False)
    now = _now()

    _safe_exec(
        conn,
        "MERGE (er:ExternalResource {id: '%s'}) "
        "ON CREATE SET er.session_id = '%s', er.agent_id = '%s', er.local_key = '%s', "
        "er.resource_type = '%s', er.resource_kind = '%s', er.resource_key = '%s', "
        "er.external_url = '%s', er.metadata = '%s', "
        "er.created_at = timestamp('%s'), er.updated_at = timestamp('%s') "
        "ON MATCH SET er.resource_type = '%s', er.resource_kind = '%s', er.resource_key = '%s', "
        "er.external_url = '%s', er.metadata = '%s', er.updated_at = timestamp('%s')"
        % (
            node_id,
            _esc(sid), _esc(aid), _esc(local_key),
            _esc(resource_type), _esc(resource_kind), _esc(resource_key),
            _esc(external_url), _esc(metadata),
            now, now,
            _esc(resource_type), _esc(resource_kind), _esc(resource_key),
            _esc(external_url), _esc(metadata), now,
        ),
    )
    _safe_exec(
        conn,
        f"MATCH (s:Session {{id: '{_esc(sid)}'}}), (er:ExternalResource {{id: '{node_id}'}}) "
        f"MERGE (s)-[:HAS_EXTERNAL_RESOURCE]->(er)",
    )
    logger.info("KG: external resource upserted (session=%s, agent=%s, key=%s)", sid, aid, resource_key or local_key)
    return node_id


def delete_external_resource(
    conn: "kuzu.Connection",
    session_id: str,
    agent_id: str,
    resource_key: str,
) -> None:
    """Remove an ExternalResource node once its external item has been deleted.

    Keeps the KG in sync with the external system so a removed item is not
    reloaded as "existing" on the next run (which would otherwise cause it to be
    re-removed or resurrected). Best-effort — never raises.
    """
    sid = (session_id or "").strip()
    aid = (agent_id or "").strip()
    key = str(resource_key or "").strip()
    if not sid or not aid or not key:
        return
    _safe_exec(
        conn,
        f"MATCH (er:ExternalResource) "
        f"WHERE er.session_id = '{_esc(sid)}' AND er.agent_id = '{_esc(aid)}' "
        f"AND er.resource_key = '{_esc(key)}' "
        f"DETACH DELETE er",
    )
    logger.info("KG: external resource deleted (session=%s, agent=%s, key=%s)", sid, aid, key)


# ═══════════════════════════════════════════════════════════════════════════
#  Workflow Stage & SubStage (stable, idempotent)
# ═══════════════════════════════════════════════════════════════════════════

# Default workflow stages matching the flow:
# session → context → dynamic → quality → feedback → agent_action → reporter → qc
_DEFAULT_STAGES = [
    ("context", 1, "Context extraction and mapping"),
    ("dynamic", 2, "Dynamic agent execution / content generation"),
    ("quality", 3, "Quality score assessment of generated content"),
    ("feedback", 4, "User feedback collection and evaluation"),
    ("agent_action", 5, "Agent action selection (finalize/generate_report/escalate)"),
    ("reporter", 6, "Report generation"),
    ("qc", 7, "Quality check validation"),
]


def ensure_workflow_stages(conn: "kuzu.Connection") -> dict[str, str]:
    """Ensure all default workflow stages exist. Returns {name: id} map."""
    now = _now()
    stage_ids = {}
    for name, order, desc in _DEFAULT_STAGES:
        result = conn.execute(f"MATCH (ws:WorkflowStage) WHERE ws.name = '{_esc(name)}' RETURN ws.id AS id")
        if result.has_next():
            stage_ids[name] = result.get_next()[0]
        else:
            sid = _id()
            _safe_exec(conn, f"CREATE (ws:WorkflowStage {{id: '{sid}', name: '{_esc(name)}', stage_order: {order}, description: '{_esc(desc)}', is_required: true, created_at: timestamp('{now}')}})")
            stage_ids[name] = sid
    return stage_ids


def ensure_substage(conn: "kuzu.Connection", stage_name: str, substage_name: str, stage_order: int = 1) -> str:
    """Ensure a SubStage exists under a WorkflowStage. Returns substage id."""
    now = _now()
    esc_name = _esc(substage_name)
    result = conn.execute(f"MATCH (ss:SubStage) WHERE ss.name = '{esc_name}' RETURN ss.id AS id")
    if result.has_next():
        return result.get_next()[0]
    ss_id = _id()
    _safe_exec(conn, f"CREATE (ss:SubStage {{id: '{ss_id}', name: '{esc_name}', stage_order: {stage_order}, description: '', created_at: timestamp('{now}')}})")
    # Link to parent stage
    _safe_exec(conn, f"MATCH (ws:WorkflowStage {{name: '{_esc(stage_name)}'}}), (ss:SubStage {{id: '{ss_id}'}}) CREATE (ws)-[:HAS_SUBSTAGE {{stage_order: {stage_order}}}]->(ss)")
    return ss_id


# ═══════════════════════════════════════════════════════════════════════════
#  Stage Execution (per Run × Stage)
# ═══════════════════════════════════════════════════════════════════════════

def on_stage_execution_started(
    conn: "kuzu.Connection",
    iteration_id: str,
    stage_name: str,
    substage_name: str | None = None,
) -> str:
    """Record that a stage execution started within a run.

    Creates: StageExecution node
    Edges:   Run -[HAS_STAGE_EXEC]-> StageExecution -[FOR_STAGE]-> WorkflowStage
             StageExecution -[FOR_SUBSTAGE]-> SubStage (if substage provided)
    Returns: stage_exec_id
    """
    now = _now()
    se_id = _id()

    # Ensure stages exist
    ensure_workflow_stages(conn)

    _safe_exec(conn, f"CREATE (se:StageExecution {{id: '{se_id}', status: 'running', started_at: timestamp('{now}'), ended_at: null, duration_ms: 0, metadata: '{{}}'}})")
    _safe_exec(conn, f"MATCH (r:Run {{id: '{_esc(iteration_id)}'}}), (se:StageExecution {{id: '{se_id}'}}) CREATE (r)-[:HAS_STAGE_EXEC {{created_at: timestamp('{now}')}}]->(se)")
    _safe_exec(conn, f"MATCH (se:StageExecution {{id: '{se_id}'}}), (ws:WorkflowStage {{name: '{_esc(stage_name)}'}}) CREATE (se)-[:FOR_STAGE {{created_at: timestamp('{now}')}}]->(ws)")

    if substage_name:
        ss_id = ensure_substage(conn, stage_name, substage_name)
        _safe_exec(conn, f"MATCH (se:StageExecution {{id: '{se_id}'}}), (ss:SubStage {{id: '{ss_id}'}}) CREATE (se)-[:FOR_SUBSTAGE {{created_at: timestamp('{now}')}}]->(ss)")

    logger.info("KG: stage_exec %s started (run=%s, stage=%s)", se_id, iteration_id, stage_name)
    return se_id


def on_stage_execution_completed(
    conn: "kuzu.Connection",
    stage_exec_id: str,
    status: str = "completed",
    duration_ms: int = 0,
) -> None:
    """Mark a stage execution as completed/failed."""
    now = _now()
    _safe_exec(conn, f"MATCH (se:StageExecution) WHERE se.id = '{_esc(stage_exec_id)}' SET se.status = '{_esc(status)}', se.ended_at = timestamp('{now}'), se.duration_ms = {duration_ms}")


# ═══════════════════════════════════════════════════════════════════════════
#  Step Execution (per StageExecution × step)
# ═══════════════════════════════════════════════════════════════════════════

def on_step_execution_started(
    conn: "kuzu.Connection",
    stage_exec_id: str,
    step_name: str,
    step_order: int = 1,
) -> str:
    """Record a step execution within a stage.

    Creates: StepExecution node
    Edges:   StageExecution -[HAS_STEP]-> StepExecution
    Returns: step_exec_id
    """
    now = _now()
    step_id = _id()

    _safe_exec(conn, f"CREATE (step:StepExecution {{id: '{step_id}', step_name: '{_esc(step_name)}', step_order: {step_order}, status: 'running', started_at: timestamp('{now}'), ended_at: null, duration_ms: 0, error_message: '', prompt_ref: '', tool_ref: '', artifact_ref: '', metadata: '{{}}'}})")
    _safe_exec(conn, f"MATCH (se:StageExecution {{id: '{_esc(stage_exec_id)}'}}), (step:StepExecution {{id: '{step_id}'}}) CREATE (se)-[:HAS_STEP {{step_order: {step_order}}}]->(step)")

    return step_id


def on_step_execution_completed(
    conn: "kuzu.Connection",
    step_exec_id: str,
    status: str = "completed",
    duration_ms: int = 0,
    error_message: str | None = None,
    prompt_ref: str = "",
    tool_ref: str = "",
    artifact_ref: str = "",
) -> None:
    """Mark a step execution as completed/failed with evidence references."""
    now = _now()
    err = f", step.error_message = '{_esc(error_message)}'" if error_message else ""
    pref = f", step.prompt_ref = '{_esc(prompt_ref)}'" if prompt_ref else ""
    tref = f", step.tool_ref = '{_esc(tool_ref)}'" if tool_ref else ""
    aref = f", step.artifact_ref = '{_esc(artifact_ref)}'" if artifact_ref else ""
    _safe_exec(conn, f"MATCH (step:StepExecution) WHERE step.id = '{_esc(step_exec_id)}' SET step.status = '{_esc(status)}', step.ended_at = timestamp('{now}'), step.duration_ms = {duration_ms}{err}{pref}{tref}{aref}")


def link_step_to_agent_run(conn: "kuzu.Connection", step_exec_id: str, agent_run_id: str) -> None:
    """Link a step execution to an agent run."""
    now = _now()
    _safe_exec(conn, f"MATCH (step:StepExecution {{id: '{_esc(step_exec_id)}'}}), (ar:AgentRun {{id: '{_esc(agent_run_id)}'}}) CREATE (step)-[:STEP_AGENT_RUN {{created_at: timestamp('{now}')}}]->(ar)")


def link_step_to_tool(conn: "kuzu.Connection", step_exec_id: str, tool_id: str) -> None:
    """Link a step execution to a tool used."""
    now = _now()
    _safe_exec(conn, f"MATCH (step:StepExecution {{id: '{_esc(step_exec_id)}'}}), (t:Tool {{id: '{_esc(tool_id)}'}}) CREATE (step)-[:STEP_USED_TOOL {{created_at: timestamp('{now}')}}]->(t)")


def link_step_to_prompt(conn: "kuzu.Connection", step_exec_id: str, prompt_id: str) -> None:
    """Link a step execution to a prompt version used."""
    now = _now()
    _safe_exec(conn, f"MATCH (step:StepExecution {{id: '{_esc(step_exec_id)}'}}), (pv:PromptVersion {{id: '{_esc(prompt_id)}'}}) CREATE (step)-[:STEP_USED_PROMPT {{created_at: timestamp('{now}')}}]->(pv)")


def link_step_to_artifact(conn: "kuzu.Connection", step_exec_id: str, artifact_id: str, direction: str = "generated") -> None:
    """Link a step execution to an artifact (input or output)."""
    now = _now()
    _safe_exec(conn, f"MATCH (step:StepExecution {{id: '{_esc(step_exec_id)}'}}), (art:Artifact {{id: '{_esc(artifact_id)}'}}) CREATE (step)-[:STEP_ARTIFACT {{direction: '{_esc(direction)}', created_at: timestamp('{now}')}}]->(art)")


def link_step_to_quality(conn: "kuzu.Connection", step_exec_id: str, quality_id: str) -> None:
    """Link a step execution to a quality assessment."""
    now = _now()
    _safe_exec(conn, f"MATCH (step:StepExecution {{id: '{_esc(step_exec_id)}'}}), (qa:QualityAssessment {{id: '{_esc(quality_id)}'}}) CREATE (step)-[:STEP_QUALITY {{created_at: timestamp('{now}')}}]->(qa)")


def link_step_to_issue(conn: "kuzu.Connection", step_exec_id: str, issue_id: str) -> None:
    """Link a step execution to an issue detected."""
    now = _now()
    _safe_exec(conn, f"MATCH (step:StepExecution {{id: '{_esc(step_exec_id)}'}}), (i:Issue {{id: '{_esc(issue_id)}'}}) CREATE (step)-[:STEP_ISSUE {{created_at: timestamp('{now}')}}]->(i)")


def on_issue_created(
    conn: "kuzu.Connection",
    iteration_id: str,
    issue_type: str,
    severity: str = "medium",
    description: str = "",
    agent_run_id: str | None = None,
) -> str:
    """Record an issue detected during a run or agent run."""
    now = _now()
    issue_id = _id()
    _safe_exec(conn, f"CREATE (i:Issue {{id: '{issue_id}', issue_type: '{_esc(issue_type)}', severity: '{_esc(severity)}', description: '{_esc(description)}', status: 'open', created_at: timestamp('{now}'), resolved_at: null}})")
    _safe_exec(conn, f"MATCH (r:Run {{id: '{_esc(iteration_id)}'}}), (i:Issue {{id: '{issue_id}'}}) CREATE (r)-[:HAS_ISSUE {{detected_at: timestamp('{now}')}}]->(i)")
    if agent_run_id:
        _safe_exec(conn, f"MATCH (ar:AgentRun {{id: '{_esc(agent_run_id)}'}}), (i:Issue {{id: '{issue_id}'}}) CREATE (ar)-[:HAS_ISSUE {{detected_at: timestamp('{now}')}}]->(i)")
    return issue_id


def link_issue_to_artifact(conn: "kuzu.Connection", issue_id: str, artifact_id: str, impact: str = "corrupted") -> None:
    """Link an issue to an affected artifact."""
    _safe_exec(conn, f"MATCH (i:Issue {{id: '{_esc(issue_id)}'}}), (art:Artifact {{id: '{_esc(artifact_id)}'}}) CREATE (i)-[:AFFECTS {{impact: '{_esc(impact)}'}}]->(art)")
