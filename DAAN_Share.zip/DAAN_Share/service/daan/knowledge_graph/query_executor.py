"""Natural Language -> Cypher -> KuzuDB executor.
 
This module keeps the NLQ flow intentionally simple:
1. Convert natural language to one read-only Cypher query.
2. Execute the Cypher on KuzuDB.
3. Return rows plus the generated Cypher.
"""
 
from __future__ import annotations
 
import argparse
import json
import re
import sys
from typing import Any
 
from daan.knowledge_graph.connection import get_kg_connection
from daan.llm.llm_provider import get_llm_response
 
 
# ═══════════════════════════════════════════════════════════════════════════
#  Safety guard
# ═══════════════════════════════════════════════════════════════════════════
 
_WRITE_CYPHER_PATTERN = re.compile(
    r"\b(CREATE|MERGE|SET|DELETE|REMOVE|DROP|ALTER|COPY)\b",
    re.IGNORECASE,
)
 
DEFAULT_MAX_ROWS = 20
 
# ═══════════════════════════════════════════════════════════════════════════
#  KG Schema for Cypher fallback
# ═══════════════════════════════════════════════════════════════════════════
 
_SCHEMA_CONTEXT = """
Node labels and their properties (use ONLY these property names — do not invent properties like "timestamp"):
- Archetype(id, name, description, created_at, updated_at)
- Role(id, name, description, created_at, updated_at)
- UseCase(id, name, description, category, created_at, updated_at)
- User(id, username, email, created_at)
- Agent(id, name, agent_type, version, description, config_ref, created_at, updated_at)
- Session(id, status, started_at, ended_at, metadata)
- Run(id, run_number, status, started_at, ended_at, duration_ms, trigger, metadata)
- AgentRun(id, status, execution_order, started_at, ended_at, duration_ms, error_message, retry_count, log_ref, metadata)
- Artifact(id, name, artifact_type, content_ref, mime_type, size_bytes, hash, created_at, metadata)
- QualityAssessment(id, score, max_score, assessment_type, summary, details_ref, created_at)
- Issue(id, issue_type, severity, description, status, created_at, resolved_at)
- Feedback(id, feedback_type, rating, comment, source, created_at)
- WorkflowStage, StageExecution, StepExecution.
 
Core relationships:
- (User)-[:INITIATED]->(Session)
- (UseCase)-[:HAS_SESSION]->(Session)
- (Session)-[:HAS_ARCHETYPE]->(Archetype)
- (Session)-[:HAS_RUN]->(Run)
- (Run)-[:PREVIOUS_RUN]->(Run)
- (Run)-[:EXECUTED_AGENT]->(AgentRun)
- (AgentRun)-[:INSTANCE_OF]->(Agent)
- (AgentRun)-[:GENERATED]->(Artifact)
- (Run)-[:HAS_QUALITY]->(QualityAssessment)
- (Run)-[:HAS_ISSUE]->(Issue)
- (Session)-[:HAS_FEEDBACK]->(Feedback)
- (Feedback)-[:REFERS_TO_RUN|TRIGGERED_RERUN]->(Run)
 
Ordering guidance:
- "Most recent" / "latest" Run means the most recently STARTED run: ORDER BY started_at DESC.
  Do NOT order by run_number for "most recent" — run_number is per-session (it restarts
  at 1 for every session), so it is NOT a global chronological order. Run has NO "timestamp" property.
- For time ordering use started_at / ended_at / created_at as listed above — never "timestamp".
- Artifacts are produced via (Run)-[:EXECUTED_AGENT]->(AgentRun)-[:GENERATED]->(Artifact).
- When a question asks for things belonging to "the most recent / latest" entity, first narrow
  to that single entity (ORDER BY started_at/created_at DESC then LIMIT 1) and only AFTER that
  expand to its related rows — applying LIMIT to the joined rows would drop valid related rows.
""".strip()
 
 
# ═══════════════════════════════════════════════════════════════════════════
#  Core helpers
# ═══════════════════════════════════════════════════════════════════════════
 
def _rows_from_result(result: Any) -> list[dict[str, Any]]:
    columns = result.get_column_names()
    rows: list[dict[str, Any]] = []
    while result.has_next():
        row = result.get_next()
        rows.append(dict(zip(columns, row)))
    return rows
 
 
def _extract_cypher(text: str) -> str:
    match = re.search(r"```(?:cypher)?\s*(.*?)```", text, re.IGNORECASE | re.DOTALL)
    if match:
        return match.group(1).strip()
    return text.strip()
 
 
def _ensure_read_only(cypher: str) -> None:
    if _WRITE_CYPHER_PATTERN.search(cypher):
        raise ValueError("Generated Cypher contains a write operation — query rejected.")
 
 
def convert_nl_to_cypher(question: str, max_rows: int = DEFAULT_MAX_ROWS) -> str:
    """Convert a natural-language question into one read-only Cypher query."""
    question = (question or "").strip()
    if not question:
        raise ValueError("question is required")
 
    prompt = (
        "Convert the question into one KuzuDB read-only Cypher query. "
        "Return only Cypher. No explanation. No markdown unless needed. "
        "Never use CREATE, MERGE, SET, DELETE, REMOVE, DROP, ALTER, or COPY.\n\n"
        f"Schema:\n{_SCHEMA_CONTEXT}\n\n"
        f"Question: {question}\n"
        f"If the query has no LIMIT, use LIMIT {max_rows}."
    )
    llm_output = str(get_llm_response(prompt=prompt))
    cypher = _extract_cypher(llm_output)
    if not re.search(r"\blimit\b", cypher, re.IGNORECASE):
        cypher = f"{cypher.rstrip(';')} LIMIT {max_rows}"
    _ensure_read_only(cypher)
    return cypher
 
 
def execute_cypher(cypher: str) -> list[dict[str, Any]]:
    """Execute a read-only Cypher query on KuzuDB and return rows."""
    cypher = (cypher or "").strip()
    if not cypher:
        raise ValueError("cypher is required")
    _ensure_read_only(cypher)
    conn = get_kg_connection()
    result = conn.execute(cypher)
    return _rows_from_result(result)
 
 
# ═══════════════════════════════════════════════════════════════════════════
#  Public API
# ═══════════════════════════════════════════════════════════════════════════
 
def run_nlq(
    question: str,
    max_rows: int = DEFAULT_MAX_ROWS,
    include_summary: bool = True,
) -> dict[str, Any]:
    """Convert NL to Cypher, execute it, and return a response payload."""
    question = (question or "").strip()
    if not question:
        raise ValueError("question is required")
 
    cypher = convert_nl_to_cypher(question=question, max_rows=max_rows)
    rows = execute_cypher(cypher)
    result_payload: dict[str, Any] = {
        "question": question,
        "generated_cypher": cypher,
        "rows": rows,
        "count": len(rows),
        "summary": f"Found {len(rows)} rows.",
    }
 
    # ── Step 4: LLM summary (optional) ───────────────────────────────────
    if include_summary and rows:
        try:
            summary_prompt = (
                "Summarize these KG query rows in 2-3 short lines for a business user.\n"
                f"Question: {question}\nRows: {rows[:10]}"
            )
            result_payload["summary"] = (
                str(get_llm_response(prompt=summary_prompt)).strip()
                or result_payload["summary"]
            )
        except Exception:
            pass
 
    return result_payload
 
 
# ═══════════════════════════════════════════════════════════════════════════
#  CLI entry point
# ═══════════════════════════════════════════════════════════════════════════
 
def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="query_executor",
        description="Natural Language → Cypher → KuzuDB query executor",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m daan.knowledge_graph.query_executor "Show all sessions"
    python -m daan.knowledge_graph.query_executor "Quality trend for session abc-123"
    python -m daan.knowledge_graph.query_executor "Top failing agents" --max-rows 10
  python -m daan.knowledge_graph.query_executor "Custom graph query" --no-summary
        """,
    )
    parser.add_argument(
        "question",
        nargs="?",
        default=None,
        help="Natural-language question (omit to enter interactively)",
    )
    parser.add_argument(
        "--max-rows",
        type=int,
        default=DEFAULT_MAX_ROWS,
        metavar="N",
        help="Row cap for generated Cypher queries (default: 20)",
    )
    parser.add_argument(
        "--no-summary",
        action="store_true",
        help="Skip the LLM summary step",
    )
    return parser
 
 
def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()
 
    question = args.question
    if not question:
        try:
            question = input("Enter your question: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.", file=sys.stderr)
            return 1
 
    if not question:
        print("Error: question cannot be empty.", file=sys.stderr)
        return 2
 
    if args.max_rows < 1:
        print("Error: --max-rows must be >= 1.", file=sys.stderr)
        return 2
 
    try:
        payload = run_nlq(
            question=question,
            max_rows=args.max_rows,
            include_summary=not args.no_summary,
        )
    except Exception as exc:
        print(json.dumps({"error": str(exc)}, indent=2, ensure_ascii=False), file=sys.stderr)
        return 1
 
    print(json.dumps(payload, indent=2, ensure_ascii=False, default=str))
    return 0
 
 
if __name__ == "__main__":
    raise SystemExit(main())