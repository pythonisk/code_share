"""Knowledge Graph package — KuzuDB-backed workflow execution graph for DAAN.

Public surface:
    get_kg_connection   – singleton connection (thread-safe)
    close_kg_connection – explicit teardown for app shutdown
    queries             – Cypher query library (import submodule)
    graph_export        – Graph visualization export functions
    kg_events           – Workflow event emitter (fire-and-forget writes)
                          includes stage/substage/step execution events
"""

from daan.knowledge_graph.connection import close_kg_connection, get_kg_connection

__all__ = [
    "get_kg_connection",
    "close_kg_connection",
]
