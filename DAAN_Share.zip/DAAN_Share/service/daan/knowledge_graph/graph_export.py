"""
Graph export functions for visualization.

Converts KuzuDB query results into a { nodes, edges } format
suitable for frontend graph libraries (react-force-graph, cytoscape, d3).
"""

from __future__ import annotations
import logging
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    import kuzu

logger = logging.getLogger(__name__)


def _rows(result) -> list[dict[str, Any]]:
    """Drain a KuzuDB QueryResult into a list of dicts."""
    columns = result.get_column_names()
    out: list[dict[str, Any]] = []
    while result.has_next():
        row = result.get_next()
        out.append(dict(zip(columns, row)))
    return out


def _safe_str(val: Any) -> str:
    """Convert a value to a JSON-safe string."""
    if val is None:
        return ""
    return str(val)


# ═══════════════════════════════════════════════════════════════════════════
#  Full Graph Export
# ═══════════════════════════════════════════════════════════════════════════

def export_full_graph(conn: kuzu.Connection, limit: int = 500) -> dict[str, Any]:
    """Export the full graph as nodes + edges for visualization.

    Returns { graph: { nodes, edges }, stats: { ... } }
    """
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    seen_nodes: set[str] = set()
    edge_counter = 0

    # ── Collect all nodes by type ───────────────────────────────────────
    node_queries = [
        ("Archetype", "MATCH (n:Archetype) RETURN n.id AS id, n.name AS name, 'Archetype' AS type"),
        ("Role", "MATCH (n:Role) RETURN n.id AS id, n.name AS name, 'Role' AS type"),
        ("UseCase", "MATCH (n:UseCase) RETURN n.id AS id, n.name AS name, 'UseCase' AS type"),
        ("User", "MATCH (n:User) RETURN n.id AS id, n.username AS name, 'User' AS type"),
        ("Planner", "MATCH (n:Planner) RETURN n.id AS id, n.name AS name, 'Planner' AS type"),
        ("Agent", "MATCH (n:Agent) RETURN n.id AS id, n.name AS name, n.agent_type AS agent_type, 'Agent' AS type"),
        ("PromptVersion", "MATCH (n:PromptVersion) RETURN n.id AS id, n.version AS name, 'PromptVersion' AS type"),
        ("Tool", "MATCH (n:Tool) RETURN n.id AS id, n.name AS name, 'Tool' AS type"),
        ("WorkflowStage", "MATCH (n:WorkflowStage) RETURN n.id AS id, n.name AS name, 'WorkflowStage' AS type"),
        ("SubStage", "MATCH (n:SubStage) RETURN n.id AS id, n.name AS name, 'SubStage' AS type"),
        ("Session", "MATCH (n:Session) RETURN n.id AS id, n.status AS name, 'Session' AS type"),
        ("Run", "MATCH (n:Run) RETURN n.id AS id, n.status AS name, 'Run' AS type"),
        ("AgentRun", "MATCH (n:AgentRun) RETURN n.id AS id, n.status AS name, 'AgentRun' AS type"),
        ("StageExecution", "MATCH (n:StageExecution) RETURN n.id AS id, n.status AS name, 'StageExecution' AS type"),
        ("StepExecution", "MATCH (n:StepExecution) RETURN n.id AS id, n.step_name AS name, 'StepExecution' AS type"),
        ("Artifact", "MATCH (n:Artifact) RETURN n.id AS id, n.name AS name, 'Artifact' AS type"),
        ("QualityAssessment", "MATCH (n:QualityAssessment) RETURN n.id AS id, n.summary AS name, 'QualityAssessment' AS type"),
        ("Issue", "MATCH (n:Issue) RETURN n.id AS id, n.issue_type AS name, 'Issue' AS type"),
        ("Feedback", "MATCH (n:Feedback) RETURN n.id AS id, n.feedback_type AS name, 'Feedback' AS type"),
    ]

    total_nodes = 0
    for node_type, cypher in node_queries:
        if total_nodes >= limit:
            break
        try:
            rows = _rows(conn.execute(cypher))
            for row in rows:
                if total_nodes >= limit:
                    break
                nid = row["id"]
                if nid not in seen_nodes:
                    seen_nodes.add(nid)
                    props: dict[str, Any] = {}
                    if node_type == "Agent":
                        props = {
                            "agent_id": nid,
                            "agent_name": _safe_str(row.get("name")),
                            "role": "",
                            "agent_type": _safe_str(row.get("agent_type")),
                        }
                    nodes.append({
                        "id": nid,
                        "label": _safe_str(row.get("name")) or nid[:12],
                        "type": node_type,
                        "properties": props,
                    })
                    total_nodes += 1
        except Exception as exc:
            logger.debug("Skipping node type %s: %s", node_type, exc)

    # ── Collect all edges ───────────────────────────────────────────────
    rel_queries = [
        ("HAS_ROLE", "MATCH (a:Archetype)-[r:HAS_ROLE]->(b:Role) RETURN a.id AS src, b.id AS tgt"),
        ("HAS_USECASE", "MATCH (a:Role)-[r:HAS_USECASE]->(b:UseCase) RETURN a.id AS src, b.id AS tgt"),
        ("INITIATED", "MATCH (a:User)-[r:INITIATED]->(b:Session) RETURN a.id AS src, b.id AS tgt"),
        ("HAS_SESSION", "MATCH (a:UseCase)-[r:HAS_SESSION]->(b:Session) RETURN a.id AS src, b.id AS tgt"),
        ("HAS_RUN", "MATCH (a:Session)-[r:HAS_RUN]->(b:Run) RETURN a.id AS src, b.id AS tgt"),
        ("PREVIOUS_RUN", "MATCH (a:Run)-[r:PREVIOUS_RUN]->(b:Run) RETURN a.id AS src, b.id AS tgt"),
        ("USES_PLANNER", "MATCH (a:Run)-[r:USES_PLANNER]->(b:Planner) RETURN a.id AS src, b.id AS tgt"),
        ("PLANS_AGENT", "MATCH (a:Planner)-[r:PLANS_AGENT]->(b:Agent) RETURN a.id AS src, b.id AS tgt"),
        ("USES_PROMPT", "MATCH (a:Agent)-[r:USES_PROMPT]->(b:PromptVersion) RETURN a.id AS src, b.id AS tgt"),
        ("USES_TOOL", "MATCH (a:Agent)-[r:USES_TOOL]->(b:Tool) RETURN a.id AS src, b.id AS tgt"),
        ("DEPENDS_ON", "MATCH (a:Agent)-[r:DEPENDS_ON]->(b:Agent) RETURN a.id AS src, b.id AS tgt"),
        ("EXECUTED_AGENT", "MATCH (a:Run)-[r:EXECUTED_AGENT]->(b:AgentRun) RETURN a.id AS src, b.id AS tgt"),
        ("INSTANCE_OF", "MATCH (a:AgentRun)-[r:INSTANCE_OF]->(b:Agent) RETURN a.id AS src, b.id AS tgt"),
        ("USED_TOOL", "MATCH (a:AgentRun)-[r:USED_TOOL]->(b:Tool) RETURN a.id AS src, b.id AS tgt"),
        ("USED_INPUT", "MATCH (a:AgentRun)-[r:USED_INPUT]->(b:Artifact) RETURN a.id AS src, b.id AS tgt"),
        ("GENERATED", "MATCH (a:AgentRun)-[r:GENERATED]->(b:Artifact) RETURN a.id AS src, b.id AS tgt"),
        ("HAS_QUALITY", "MATCH (a:Run)-[r:HAS_QUALITY]->(b:QualityAssessment) RETURN a.id AS src, b.id AS tgt"),
        ("HAS_ISSUE", "MATCH (a:Run)-[r:HAS_ISSUE]->(b:Issue) RETURN a.id AS src, b.id AS tgt"),
        ("AFFECTS", "MATCH (a:Issue)-[r:AFFECTS]->(b:Artifact) RETURN a.id AS src, b.id AS tgt"),
        ("HAS_FEEDBACK", "MATCH (a:Session)-[r:HAS_FEEDBACK]->(b:Feedback) RETURN a.id AS src, b.id AS tgt"),
        ("FOR_USECASE", "MATCH (a:Feedback)-[r:FOR_USECASE]->(b:UseCase) RETURN a.id AS src, b.id AS tgt"),
        ("REFERS_TO_RUN", "MATCH (a:Feedback)-[r:REFERS_TO_RUN]->(b:Run) RETURN a.id AS src, b.id AS tgt"),
        ("TRIGGERED_RERUN", "MATCH (a:Feedback)-[r:TRIGGERED_RERUN]->(b:Run) RETURN a.id AS src, b.id AS tgt"),
        ("HAS_SUBSTAGE", "MATCH (a:WorkflowStage)-[r:HAS_SUBSTAGE]->(b:SubStage) RETURN a.id AS src, b.id AS tgt"),
        ("HAS_STAGE_EXEC", "MATCH (a:Run)-[r:HAS_STAGE_EXEC]->(b:StageExecution) RETURN a.id AS src, b.id AS tgt"),
        ("FOR_STAGE", "MATCH (a:StageExecution)-[r:FOR_STAGE]->(b:WorkflowStage) RETURN a.id AS src, b.id AS tgt"),
        ("FOR_SUBSTAGE", "MATCH (a:StageExecution)-[r:FOR_SUBSTAGE]->(b:SubStage) RETURN a.id AS src, b.id AS tgt"),
        ("HAS_STEP", "MATCH (a:StageExecution)-[r:HAS_STEP]->(b:StepExecution) RETURN a.id AS src, b.id AS tgt"),
        ("STEP_AGENT_RUN", "MATCH (a:StepExecution)-[r:STEP_AGENT_RUN]->(b:AgentRun) RETURN a.id AS src, b.id AS tgt"),
        ("STEP_USED_TOOL", "MATCH (a:StepExecution)-[r:STEP_USED_TOOL]->(b:Tool) RETURN a.id AS src, b.id AS tgt"),
        ("STEP_ARTIFACT", "MATCH (a:StepExecution)-[r:STEP_ARTIFACT]->(b:Artifact) RETURN a.id AS src, b.id AS tgt"),
        ("STEP_QUALITY", "MATCH (a:StepExecution)-[r:STEP_QUALITY]->(b:QualityAssessment) RETURN a.id AS src, b.id AS tgt"),
        ("STEP_ISSUE", "MATCH (a:StepExecution)-[r:STEP_ISSUE]->(b:Issue) RETURN a.id AS src, b.id AS tgt"),
    ]

    for rel_label, cypher in rel_queries:
        try:
            rows = _rows(conn.execute(cypher))
            for row in rows:
                src, tgt = row["src"], row["tgt"]
                if src in seen_nodes and tgt in seen_nodes:
                    edge_counter += 1
                    edges.append({
                        "id": f"e{edge_counter}",
                        "source": src,
                        "target": tgt,
                        "label": rel_label,
                        "properties": {},
                    })
        except Exception as exc:
            logger.debug("Skipping rel type %s: %s", rel_label, exc)

    stats = {"nodes": len(nodes), "edges": len(edges)}
    return {"graph": {"nodes": nodes, "edges": edges}, "stats": stats}


# ═══════════════════════════════════════════════════════════════════════════
#  Session Subgraph Export
# ═══════════════════════════════════════════════════════════════════════════

def export_session_subgraph(conn: kuzu.Connection, session_id: str) -> dict[str, Any]:
    """Export the subgraph for a specific session including all runs, agents, artifacts, quality."""
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    seen_nodes: set[str] = set()
    edge_counter = 0
    session_role_name = ""

    def _add_node(nid: str, label: str, ntype: str, props: dict | None = None):
        nonlocal seen_nodes
        if nid and nid not in seen_nodes:
            seen_nodes.add(nid)
            nodes.append({
                "id": nid,
                "label": _safe_str(label) or nid[:12],
                "type": ntype,
                "properties": props or {},
            })

    def _add_edge(src: str, tgt: str, label: str, props: dict | None = None):
        nonlocal edge_counter
        if src in seen_nodes and tgt in seen_nodes:
            edge_counter += 1
            edges.append({
                "id": f"e{edge_counter}",
                "source": src,
                "target": tgt,
                "label": label,
                "properties": props or {},
            })

    # Session node
    sess_rows = _rows(conn.execute(f"MATCH (s:Session) WHERE s.id = '{session_id}' RETURN s.id AS id, s.status AS status"))
    if not sess_rows:
        return {"graph": {"nodes": [], "edges": []}, "stats": {"nodes": 0, "edges": 0}}
    _add_node(session_id, f"Session ({sess_rows[0]['status']})", "Session")

    # User who initiated
    user_rows = _rows(conn.execute(f"MATCH (u:User)-[:INITIATED]->(s:Session) WHERE s.id = '{session_id}' RETURN u.id AS id, u.username AS name"))
    for r in user_rows:
        _add_node(r["id"], r["name"], "User")
        _add_edge(r["id"], session_id, "INITIATED")

    # UseCase -> Session
    uc_rows = _rows(conn.execute(f"MATCH (uc:UseCase)-[:HAS_SESSION]->(s:Session) WHERE s.id = '{session_id}' RETURN uc.id AS id, uc.name AS name"))
    for r in uc_rows:
        _add_node(r["id"], r["name"], "UseCase")
        _add_edge(r["id"], session_id, "HAS_SESSION")

        # Role -> UseCase
        role_rows = _rows(conn.execute(f"MATCH (role:Role)-[:HAS_USECASE]->(uc:UseCase) WHERE uc.id = '{r['id']}' RETURN role.id AS id, role.name AS name"))
        for rr in role_rows:
            if not session_role_name:
                session_role_name = _safe_str(rr.get("name"))
            _add_node(rr["id"], rr["name"], "Role")
            _add_edge(rr["id"], r["id"], "HAS_USECASE")

            # Archetype -> Role
            arch_rows = _rows(conn.execute(f"MATCH (a:Archetype)-[:HAS_ROLE]->(role:Role) WHERE role.id = '{rr['id']}' RETURN a.id AS id, a.name AS name"))
            for ar in arch_rows:
                _add_node(ar["id"], ar["name"], "Archetype")
                _add_edge(ar["id"], rr["id"], "HAS_ROLE")

    # Runs in session
    run_rows = _rows(conn.execute(f"MATCH (s:Session)-[:HAS_RUN]->(r:Run) WHERE s.id = '{session_id}' RETURN r.id AS id, r.run_number AS run_number, r.status AS status, r.trigger AS trigger ORDER BY r.run_number"))
    for r in run_rows:
        iteration_id = r["id"]
        _add_node(iteration_id, f"Run #{r['run_number']} ({r['status']})", "Run", {"trigger": _safe_str(r.get("trigger"))})
        _add_edge(session_id, iteration_id, "HAS_RUN")

        # Planner
        plan_rows = _rows(conn.execute(f"MATCH (r:Run)-[:USES_PLANNER]->(p:Planner) WHERE r.id = '{iteration_id}' RETURN p.id AS id, p.name AS name"))
        for p in plan_rows:
            _add_node(p["id"], p["name"], "Planner")
            _add_edge(iteration_id, p["id"], "USES_PLANNER")

        # Agent Runs
        ar_rows = _rows(conn.execute(f"MATCH (r:Run)-[:EXECUTED_AGENT]->(ar:AgentRun)-[:INSTANCE_OF]->(a:Agent) WHERE r.id = '{iteration_id}' RETURN ar.id AS ar_id, ar.status AS ar_status, ar.execution_order AS exec_order, a.id AS agent_id, a.name AS agent_name, a.agent_type AS agent_type ORDER BY ar.execution_order"))
        for ar in ar_rows:
            _add_node(
                ar["agent_id"],
                ar["agent_name"],
                "Agent",
                {
                    "agent_id": _safe_str(ar.get("agent_id")),
                    "agent_name": _safe_str(ar.get("agent_name")),
                    "role": session_role_name,
                    "agent_type": _safe_str(ar.get("agent_type")),
                },
            )
            _add_node(ar["ar_id"], f"{ar['agent_name']} (#{ar['exec_order']})", "AgentRun", {"status": ar["ar_status"]})
            _add_edge(iteration_id, ar["ar_id"], "EXECUTED_AGENT")
            _add_edge(ar["ar_id"], ar["agent_id"], "INSTANCE_OF")

            # Artifacts generated
            gen_rows = _rows(conn.execute(f"MATCH (ar:AgentRun)-[:GENERATED]->(art:Artifact) WHERE ar.id = '{ar['ar_id']}' RETURN art.id AS id, art.name AS name, art.artifact_type AS atype"))
            for g in gen_rows:
                _add_node(g["id"], g["name"], "Artifact", {"artifact_type": _safe_str(g.get("atype"))})
                _add_edge(ar["ar_id"], g["id"], "GENERATED")

            # Artifacts consumed
            inp_rows = _rows(conn.execute(f"MATCH (ar:AgentRun)-[:USED_INPUT]->(art:Artifact) WHERE ar.id = '{ar['ar_id']}' RETURN art.id AS id, art.name AS name, art.artifact_type AS atype"))
            for i in inp_rows:
                _add_node(i["id"], i["name"], "Artifact", {"artifact_type": _safe_str(i.get("atype"))})
                _add_edge(ar["ar_id"], i["id"], "USED_INPUT")

            # Tools used at runtime
            tool_rows = _rows(conn.execute(f"MATCH (ar:AgentRun)-[u:USED_TOOL]->(t:Tool) WHERE ar.id = '{ar['ar_id']}' RETURN t.id AS id, t.name AS name, u.invocation_count AS cnt"))
            for t in tool_rows:
                _add_node(t["id"], t["name"], "Tool")
                _add_edge(ar["ar_id"], t["id"], "USED_TOOL")

        # Quality assessments
        qa_rows = _rows(conn.execute(f"MATCH (r:Run)-[:HAS_QUALITY]->(q:QualityAssessment) WHERE r.id = '{iteration_id}' RETURN q.id AS id, q.score AS score, q.summary AS summary"))
        for q in qa_rows:
            _add_node(q["id"], f"QA: {q.get('score', '?')}", "QualityAssessment", {"score": q.get("score"), "summary": _safe_str(q.get("summary"))})
            _add_edge(iteration_id, q["id"], "HAS_QUALITY")

        # Issues
        issue_rows = _rows(conn.execute(f"MATCH (r:Run)-[:HAS_ISSUE]->(i:Issue) WHERE r.id = '{iteration_id}' RETURN i.id AS id, i.issue_type AS itype, i.severity AS severity"))
        for i in issue_rows:
            _add_node(i["id"], f"{i['itype']} [{i['severity']}]", "Issue")
            _add_edge(iteration_id, i["id"], "HAS_ISSUE")

            # Issue -> Artifact
            aff_rows = _rows(conn.execute(f"MATCH (i:Issue)-[:AFFECTS]->(art:Artifact) WHERE i.id = '{i['id']}' RETURN art.id AS id, art.name AS name"))
            for a in aff_rows:
                _add_node(a["id"], a["name"], "Artifact")
                _add_edge(i["id"], a["id"], "AFFECTS")

        # Stage Executions for this run
        se_rows = _rows(conn.execute(f"MATCH (r:Run)-[:HAS_STAGE_EXEC]->(se:StageExecution)-[:FOR_STAGE]->(ws:WorkflowStage) WHERE r.id = '{iteration_id}' RETURN se.id AS se_id, se.status AS se_status, ws.id AS ws_id, ws.name AS ws_name, ws.stage_order AS ws_order ORDER BY ws.stage_order"))
        for se in se_rows:
            _add_node(se["ws_id"], se["ws_name"], "WorkflowStage")
            _add_node(se["se_id"], f"{se['ws_name']} ({se['se_status']})", "StageExecution", {"status": se["se_status"]})
            _add_edge(iteration_id, se["se_id"], "HAS_STAGE_EXEC")
            _add_edge(se["se_id"], se["ws_id"], "FOR_STAGE")

            # Steps within this stage execution
            step_rows = _rows(conn.execute(f"MATCH (se:StageExecution)-[:HAS_STEP]->(step:StepExecution) WHERE se.id = '{se['se_id']}' RETURN step.id AS id, step.step_name AS name, step.status AS status ORDER BY step.step_order"))
            for step in step_rows:
                _add_node(step["id"], f"{step['name']} ({step['status']})", "StepExecution", {"status": step["status"]})
                _add_edge(se["se_id"], step["id"], "HAS_STEP")

    # PREVIOUS_RUN edges between runs
    prev_rows = _rows(conn.execute(f"MATCH (s:Session)-[:HAS_RUN]->(r1:Run)-[:PREVIOUS_RUN]->(r2:Run) WHERE s.id = '{session_id}' RETURN r1.id AS src, r2.id AS tgt"))
    for p in prev_rows:
        _add_edge(p["src"], p["tgt"], "PREVIOUS_RUN")

    # Feedback
    fb_rows = _rows(conn.execute(f"MATCH (s:Session)-[:HAS_FEEDBACK]->(f:Feedback) WHERE s.id = '{session_id}' RETURN f.id AS id, f.feedback_type AS ftype, f.comment AS comment"))
    for f in fb_rows:
        _add_node(f["id"], f"Feedback: {_safe_str(f.get('ftype'))}", "Feedback", {"comment": _safe_str(f.get("comment"))})
        _add_edge(session_id, f["id"], "HAS_FEEDBACK")

        # Feedback -> triggered rerun
        tr_rows = _rows(conn.execute(f"MATCH (f:Feedback)-[:TRIGGERED_RERUN]->(r:Run) WHERE f.id = '{f['id']}' RETURN r.id AS rid"))
        for tr in tr_rows:
            _add_edge(f["id"], tr["rid"], "TRIGGERED_RERUN")

        # Feedback -> refers to run
        ref_rows = _rows(conn.execute(f"MATCH (f:Feedback)-[:REFERS_TO_RUN]->(r:Run) WHERE f.id = '{f['id']}' RETURN r.id AS rid"))
        for ref in ref_rows:
            _add_edge(f["id"], ref["rid"], "REFERS_TO_RUN")

    stats = {"nodes": len(nodes), "edges": len(edges)}
    return {"graph": {"nodes": nodes, "edges": edges}, "stats": stats}


# ═══════════════════════════════════════════════════════════════════════════
#  Run Subgraph Export
# ═══════════════════════════════════════════════════════════════════════════

def export_run_subgraph(conn: kuzu.Connection, iteration_id: str) -> dict[str, Any]:
    """Export the subgraph for a single run."""
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    seen_nodes: set[str] = set()
    edge_counter = 0
    run_role_name = ""

    role_rows = _rows(conn.execute(
        f"MATCH (r:Run)<-[:HAS_RUN]-(s:Session)<-[:HAS_SESSION]-(uc:UseCase)<-[:HAS_USECASE]-(role:Role) WHERE r.id = '{iteration_id}' RETURN role.name AS role LIMIT 1"
    ))
    if role_rows:
        run_role_name = _safe_str(role_rows[0].get("role"))

    def _add_node(nid: str, label: str, ntype: str, props: dict | None = None):
        nonlocal seen_nodes
        if nid and nid not in seen_nodes:
            seen_nodes.add(nid)
            nodes.append({"id": nid, "label": _safe_str(label) or nid[:12], "type": ntype, "properties": props or {}})

    def _add_edge(src: str, tgt: str, label: str, props: dict | None = None):
        nonlocal edge_counter
        if src in seen_nodes and tgt in seen_nodes:
            edge_counter += 1
            edges.append({"id": f"e{edge_counter}", "source": src, "target": tgt, "label": label, "properties": props or {}})

    # Run node
    run_rows = _rows(conn.execute(f"MATCH (r:Run) WHERE r.id = '{iteration_id}' RETURN r.id AS id, r.run_number AS rn, r.status AS status"))
    if not run_rows:
        return {"graph": {"nodes": [], "edges": []}, "stats": {"nodes": 0, "edges": 0}}
    _add_node(iteration_id, f"Run #{run_rows[0]['rn']} ({run_rows[0]['status']})", "Run")

    # Planner
    plan_rows = _rows(conn.execute(f"MATCH (r:Run)-[:USES_PLANNER]->(p:Planner) WHERE r.id = '{iteration_id}' RETURN p.id AS id, p.name AS name"))
    for p in plan_rows:
        _add_node(p["id"], p["name"], "Planner")
        _add_edge(iteration_id, p["id"], "USES_PLANNER")

        # Planner -> Agents
        pa_rows = _rows(conn.execute(f"MATCH (p:Planner)-[:PLANS_AGENT]->(a:Agent) WHERE p.id = '{p['id']}' RETURN a.id AS id, a.name AS name"))
        for a in pa_rows:
            _add_node(a["id"], a["name"], "Agent")
            _add_edge(p["id"], a["id"], "PLANS_AGENT")

    # Agent Runs
    ar_rows = _rows(conn.execute(f"MATCH (r:Run)-[:EXECUTED_AGENT]->(ar:AgentRun)-[:INSTANCE_OF]->(a:Agent) WHERE r.id = '{iteration_id}' RETURN ar.id AS ar_id, ar.status AS ar_status, ar.execution_order AS exec_order, ar.duration_ms AS duration, a.id AS agent_id, a.name AS agent_name, a.agent_type AS agent_type ORDER BY ar.execution_order"))
    for ar in ar_rows:
        _add_node(
            ar["agent_id"],
            ar["agent_name"],
            "Agent",
            {
                "agent_id": _safe_str(ar.get("agent_id")),
                "agent_name": _safe_str(ar.get("agent_name")),
                "role": run_role_name,
                "agent_type": _safe_str(ar.get("agent_type")),
            },
        )
        _add_node(ar["ar_id"], f"{ar['agent_name']} (#{ar['exec_order']})", "AgentRun", {"status": ar["ar_status"], "duration_ms": ar.get("duration")})
        _add_edge(iteration_id, ar["ar_id"], "EXECUTED_AGENT")
        _add_edge(ar["ar_id"], ar["agent_id"], "INSTANCE_OF")

        # Artifacts
        for rel_type in ["GENERATED", "USED_INPUT"]:
            art_rows = _rows(conn.execute(f"MATCH (ar:AgentRun)-[:{rel_type}]->(art:Artifact) WHERE ar.id = '{ar['ar_id']}' RETURN art.id AS id, art.name AS name, art.artifact_type AS atype"))
            for a in art_rows:
                _add_node(a["id"], a["name"], "Artifact", {"artifact_type": _safe_str(a.get("atype"))})
                _add_edge(ar["ar_id"], a["id"], rel_type)

        # Tools used at runtime
        tool_rows = _rows(conn.execute(f"MATCH (ar:AgentRun)-[u:USED_TOOL]->(t:Tool) WHERE ar.id = '{ar['ar_id']}' RETURN t.id AS id, t.name AS name, u.invocation_count AS cnt, u.duration_ms AS dur"))
        for t in tool_rows:
            _add_node(t["id"], t["name"], "Tool", {"invocations": t.get("cnt"), "duration_ms": t.get("dur")})
            _add_edge(ar["ar_id"], t["id"], "USED_TOOL")

    # Quality
    qa_rows = _rows(conn.execute(f"MATCH (r:Run)-[:HAS_QUALITY]->(q:QualityAssessment) WHERE r.id = '{iteration_id}' RETURN q.id AS id, q.score AS score, q.summary AS summary"))
    for q in qa_rows:
        _add_node(q["id"], f"QA: {q.get('score', '?')}", "QualityAssessment", {"score": q.get("score")})
        _add_edge(iteration_id, q["id"], "HAS_QUALITY")

    # Issues
    issue_rows = _rows(conn.execute(f"MATCH (r:Run)-[:HAS_ISSUE]->(i:Issue) WHERE r.id = '{iteration_id}' RETURN i.id AS id, i.issue_type AS itype, i.severity AS severity"))
    for i in issue_rows:
        _add_node(i["id"], f"{i['itype']} [{i['severity']}]", "Issue")
        _add_edge(iteration_id, i["id"], "HAS_ISSUE")
        aff_rows = _rows(conn.execute(f"MATCH (i:Issue)-[:AFFECTS]->(art:Artifact) WHERE i.id = '{i['id']}' RETURN art.id AS id, art.name AS name"))
        for a in aff_rows:
            _add_node(a["id"], a["name"], "Artifact")
            _add_edge(i["id"], a["id"], "AFFECTS")

    # Stage Executions
    se_rows = _rows(conn.execute(f"MATCH (r:Run)-[:HAS_STAGE_EXEC]->(se:StageExecution)-[:FOR_STAGE]->(ws:WorkflowStage) WHERE r.id = '{iteration_id}' RETURN se.id AS se_id, se.status AS se_status, ws.id AS ws_id, ws.name AS ws_name ORDER BY ws.stage_order"))
    for se in se_rows:
        _add_node(se["ws_id"], se["ws_name"], "WorkflowStage")
        _add_node(se["se_id"], f"{se['ws_name']} ({se['se_status']})", "StageExecution")
        _add_edge(iteration_id, se["se_id"], "HAS_STAGE_EXEC")
        _add_edge(se["se_id"], se["ws_id"], "FOR_STAGE")

        step_rows = _rows(conn.execute(f"MATCH (se:StageExecution)-[:HAS_STEP]->(step:StepExecution) WHERE se.id = '{se['se_id']}' RETURN step.id AS id, step.step_name AS name, step.status AS status ORDER BY step.step_order"))
        for step in step_rows:
            _add_node(step["id"], f"{step['name']} ({step['status']})", "StepExecution")
            _add_edge(se["se_id"], step["id"], "HAS_STEP")

    stats = {"nodes": len(nodes), "edges": len(edges)}
    return {"graph": {"nodes": nodes, "edges": edges}, "stats": stats}
