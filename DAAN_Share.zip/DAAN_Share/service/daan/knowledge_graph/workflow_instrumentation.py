"""Fire-and-forget Knowledge Graph instrumentation for the workflow endpoints.

This module is the single integration seam between the workflow API and the
KuzuDB knowledge graph.  Every function here is intentionally *best-effort*:

* The KG connection is acquired lazily and any failure (including the store
  being locked by another process) degrades silently to a no-op.
* No function in this module may ever raise — workflow execution must never be
  broken by graph bookkeeping.

Keeping all of this in one place (rather than scattering ``try/except`` import
blocks across ``workflow.py``) means the endpoints only ever make clean,
single-line calls, and the graph schema/event coupling lives next to the rest
of the ``knowledge_graph`` package.
"""

from __future__ import annotations

import time
from typing import Any
from uuid import uuid4

from daan.core.logging import get_logger

logger = get_logger(__name__)

# Runs scoring below this quality value are also recorded as an Issue so the
# shortfall becomes part of the use-case history used for recurrence validation.
_QUALITY_ISSUE_THRESHOLD = 70.0


# ── Connection / helpers ────────────────────────────────────────────────────

def _conn():
    """Return the singleton KG connection, or ``None`` if unavailable."""
    try:
        from daan.knowledge_graph.connection import get_kg_connection

        return get_kg_connection()
    except Exception:
        logger.debug("KG connection unavailable; skipping instrumentation", exc_info=True)
        return None


def _username(current_user: Any) -> str:
    return str(getattr(current_user, "username", None) or "unknown")


def _agent_field(agent: Any, *names: str) -> str:
    """Read the first present field from an agent config dict (or object)."""
    for name in names:
        if isinstance(agent, dict):
            value = agent.get(name)
        else:
            value = getattr(agent, name, None)
        if value:
            return str(value)
    return ""


def _applied_learning_history(agent: Any) -> list[dict[str, str]]:
    """Return the currently selected learning-history items for an agent."""
    raw = agent.get("applied_learning_history") if isinstance(agent, dict) else getattr(agent, "applied_learning_history", None)
    items: list[dict[str, str]] = []
    if not isinstance(raw, list):
        return items
    for entry in raw:
        if not isinstance(entry, dict):
            continue
        feedback_id = str(entry.get("feedback_id") or "").strip()
        comment = str(entry.get("comment") or "").strip()
        if feedback_id and comment:
            items.append({"feedback_id": feedback_id, "comment": comment})
    return items


def _next_run_number(conn, session_id: str) -> int:
    """Return the next 1-based run number for a session."""
    try:
        result = conn.execute(
            "MATCH (s:Session)-[:HAS_RUN]->(r:Run) WHERE s.id = $sid "
            "RETURN count(r) AS cnt",
            {"sid": session_id},
        )
        if result.has_next():
            return int(result.get_next()[0] or 0) + 1
    except Exception:
        logger.debug("KG run-number lookup failed", exc_info=True)
    return 1


def _latest_run_id(conn, session_id: str) -> str | None:
    try:
        from daan.knowledge_graph.queries import _latest_run_id_for_session

        return _latest_run_id_for_session(conn, session_id)
    except Exception:
        logger.debug("KG latest-run lookup failed", exc_info=True)
        return None


def _parse_score(text: str) -> float:
    """Best-effort extraction of a leading numeric score from assessment text."""
    import re

    match = re.search(r"\d+(?:\.\d+)?", str(text or ""))
    if not match:
        return 0.0
    try:
        return float(match.group(0))
    except ValueError:
        return 0.0


# ── Public instrumentation API ──────────────────────────────────────────────

def record_session_created(
    session_id: str,
    current_user: Any,
    archetype: str,
    usecase_id: str,
    usecase_name: str = "",
) -> None:
    """Record session creation (idempotent)."""
    conn = _conn()
    if conn is None:
        return
    try:
        from daan.knowledge_graph.kg_events import on_session_created

        on_session_created(
            conn,
            session_id,
            _username(current_user),
            archetype or "",
            usecase_id or "",
            usecase_name or "",
        )
    except Exception:
        logger.debug("KG session-created event failed", exc_info=True)


def record_agent_run(
    session: Any,
    current_user: Any,
    agents: list[dict[str, Any]],
    outputs: dict[str, Any],
    output_paths: dict[str, str],
    trigger: str = "manual",
) -> str | None:
    """Record one execution phase as a Run with its AgentRuns and Artifacts.

    Returns the created run id, or ``None`` if instrumentation was skipped.
    """
    conn = _conn()
    if conn is None:
        return None

    started = time.monotonic()
    try:
        from daan.knowledge_graph.kg_events import (
            on_session_created,
            on_run_started,
            on_run_completed,
            on_agent_run_started,
            on_agent_run_completed,
            on_artifact_created,
            on_agent_quality_assessed,
            on_feedback_submitted,
        )

        session_id = str(session.session_id)
        # Defensive: ensure the session node exists even if context-map was skipped.
        on_session_created(
            conn,
            session_id,
            _username(current_user),
            str(getattr(session, "archetype", "") or ""),
            str(getattr(session, "usecase_id", "") or ""),
        )

        run_id = str(uuid4())
        run_number = _next_run_number(conn, session_id)
        previous_run_id = _latest_run_id(conn, session_id)
        on_run_started(
            conn,
            session_id,
            run_id,
            run_number,
            trigger=trigger,
            previous_run_id=previous_run_id,
        )

        for order, agent in enumerate(agents or [], start=1):
            agent_id = _agent_field(agent, "agent_id", "id")
            if not agent_id:
                continue
            agent_name = _agent_field(agent, "agent_name", "name") or agent_id
            agent_type = _agent_field(agent, "agent_type") or "Sub_Agent"

            agent_run_id = str(uuid4())
            on_agent_run_started(
                conn,
                run_id,
                agent_run_id,
                agent_id,
                agent_name=agent_name,
                agent_type=agent_type,
                execution_order=order,
            )

            content = outputs.get(agent_id) if outputs else None
            content_ref = str((output_paths or {}).get(agent_id) or "")
            on_artifact_created(
                conn,
                agent_run_id,
                f"{agent_id}_output",
                artifact_type="output",
                content_ref=content_ref,
                size_bytes=len(str(content or "")),
            )

            for learning_item in _applied_learning_history(agent):
                on_feedback_submitted(
                    conn,
                    session_id,
                    feedback_id=str(uuid4()),
                    feedback_type="learning_history",
                    comment=str(learning_item.get("comment") or ""),
                    source="learning_history",
                    refers_to_run_id=run_id,
                    targets_agent_id=agent_id,
                    usecase_id=str(getattr(session, "usecase_id", "") or "") or None,
                )

            on_agent_run_completed(conn, agent_run_id, status="completed")

            # Record per-agent quality from the score.json written to disk just
            # before this KG call.  Covers both dynamic and action agents since
            # both write score.json prior to record_agent_run being invoked.
            try:
                from daan.flow.session_service import read_agent_score
                score_data = read_agent_score(session_id, agent_id)
                if score_data and isinstance(score_data, dict):
                    overall = float(
                        score_data.get("overall_score")
                        or score_data.get("overall")
                        or 0.0
                    )
                    summary_text = str(score_data.get("summary") or "")[:500]
                    on_agent_quality_assessed(
                        conn,
                        agent_run_id,
                        score=overall,
                        assessment_type="per_agent_qc",
                        summary=summary_text,
                        details_ref=content_ref,
                    )
            except Exception:
                pass  # quality recording is best-effort; never block the run

        duration_ms = int((time.monotonic() - started) * 1000)
        on_run_completed(conn, run_id, status="completed", duration_ms=duration_ms)
        return run_id
    except Exception:
        logger.debug("KG agent-run instrumentation failed", exc_info=True)
        return None


def record_feedback_rerun(
    session: Any,
    current_user: Any,
    agent_id: str,
    agent: dict[str, Any] | None,
    comment: str,
    output: str,
    output_path: str,
    score_dict: "dict[str, Any] | None" = None,
) -> None:
    """Record user feedback on an agent plus the rerun it triggered.

    ``score_dict`` – optional per-agent quality score (from score.json) to
    attach as a :class:`~daan.knowledge_graph.kg_events.QualityAssessment`
    on the agent's run node so every feedback rerun also has a quality entry.
    """
    conn = _conn()
    if conn is None:
        return
    try:
        from daan.knowledge_graph.kg_events import (
            on_session_created,
            on_feedback_submitted,
            on_feedback_triggered_rerun,
            on_run_started,
            on_run_completed,
            on_agent_run_started,
            on_agent_run_completed,
            on_artifact_created,
            on_agent_quality_assessed,
        )

        session_id = str(session.session_id)
        usecase_id = str(getattr(session, "usecase_id", "") or "")
        on_session_created(
            conn,
            session_id,
            _username(current_user),
            str(getattr(session, "archetype", "") or ""),
            usecase_id,
        )

        previous_run_id = _latest_run_id(conn, session_id)
        feedback_id = str(uuid4())
        on_feedback_submitted(
            conn,
            session_id,
            feedback_id,
            feedback_type="user",
            comment=str(comment or ""),
            source="user",
            refers_to_run_id=previous_run_id,
            targets_agent_id=agent_id,
            usecase_id=usecase_id or None,
        )

        rerun_id = str(uuid4())
        run_number = _next_run_number(conn, session_id)
        on_run_started(
            conn,
            session_id,
            rerun_id,
            run_number,
            trigger="feedback",
            previous_run_id=previous_run_id,
        )
        on_feedback_triggered_rerun(conn, feedback_id, rerun_id)

        agent_name = _agent_field(agent, "agent_name", "name") or agent_id
        agent_type = _agent_field(agent, "agent_type") or "Sub_Agent"
        agent_run_id = str(uuid4())
        on_agent_run_started(
            conn,
            rerun_id,
            agent_run_id,
            agent_id,
            agent_name=agent_name,
            agent_type=agent_type,
        )
        on_artifact_created(
            conn,
            agent_run_id,
            f"{agent_id}_output",
            artifact_type="output",
            content_ref=str(output_path or ""),
            size_bytes=len(str(output or "")),
        )
        on_agent_run_completed(conn, agent_run_id, status="completed")

        # Record per-agent quality for the feedback rerun when a score was
        # provided by the caller (computed and written to disk just before
        # this function is called in the feedback endpoint).
        if score_dict and isinstance(score_dict, dict):
            try:
                overall = float(
                    score_dict.get("overall_score")
                    or score_dict.get("overall")
                    or 0.0
                )
                summary_text = str(score_dict.get("summary") or "")[:500]
                on_agent_quality_assessed(
                    conn,
                    agent_run_id,
                    score=overall,
                    assessment_type="per_agent_qc_feedback",
                    summary=summary_text,
                    details_ref=str(output_path or ""),
                )
            except Exception:
                pass

        on_run_completed(conn, rerun_id, status="completed")
    except Exception:
        logger.debug("KG feedback-rerun instrumentation failed", exc_info=True)


def record_chat_feedback_rerun(
    session_id: str,
    current_user: Any,
    archetype: str,
    usecase_id: str,
    feedback_text: str,
    updated_agents: list[dict[str, Any]],
    target_agent_ids: list[str] | None = None,
    assessment: str | None = None,
) -> str | None:
    """Record a chat-driven feedback rerun and its quality assessment.

    Unlike :func:`record_feedback_rerun` (which is driven by the live workflow
    session and targets a single agent), this works from a ``session_id`` alone
    so it can be used when the user gives feedback through the run-history chat
    on a session that is no longer in memory.

    A single new :class:`Run` (trigger ``chat_feedback``) is created for the whole
    chat action, every refined agent deliverable is attached to it, and the user
    feedback is recorded against the explicitly edited agent set when available.
    This prevents downstream cascade updates from polluting another agent's
    Learning History. When an ``assessment`` is supplied, a
    :class:`QualityAssessment` (and, below the quality bar, an :class:`Issue`)
    is attached so the per-run quality score reflects the update.

    Returns the new run id, or ``None`` if instrumentation was skipped/failed.
    """
    conn = _conn()
    if conn is None:
        return None
    try:
        from daan.knowledge_graph.kg_events import (
            on_session_created,
            on_feedback_submitted,
            on_feedback_triggered_rerun,
            on_run_started,
            on_run_completed,
            on_agent_run_started,
            on_agent_run_completed,
            on_artifact_created,
            on_quality_assessed,
            on_issue_created,
        )

        on_session_created(
            conn,
            session_id,
            _username(current_user),
            str(archetype or ""),
            str(usecase_id or ""),
        )

        previous_run_id = _latest_run_id(conn, session_id)
        feedback_ids: list[str] = []
        explicit_target_ids = [
            str(agent_id or "").strip()
            for agent_id in (target_agent_ids or [])
            if str(agent_id or "").strip()
        ]
        if not explicit_target_ids:
            explicit_target_ids = [
                str(entry.get("agent_id") or "").strip()
                for entry in updated_agents
                if str(entry.get("agent_id") or "").strip()
            ]
        explicit_target_ids = list(dict.fromkeys(explicit_target_ids))

        if explicit_target_ids:
            for agent_id in explicit_target_ids:
                feedback_id = str(uuid4())
                feedback_ids.append(feedback_id)
                on_feedback_submitted(
                    conn,
                    session_id,
                    feedback_id,
                    feedback_type="user",
                    comment=str(feedback_text or ""),
                    source="chat",
                    refers_to_run_id=previous_run_id,
                    targets_agent_id=agent_id,
                    usecase_id=str(usecase_id or "") or None,
                )
        else:
            feedback_id = str(uuid4())
            feedback_ids.append(feedback_id)
            on_feedback_submitted(
                conn,
                session_id,
                feedback_id,
                feedback_type="user",
                comment=str(feedback_text or ""),
                source="chat",
                refers_to_run_id=previous_run_id,
                usecase_id=str(usecase_id or "") or None,
            )

        rerun_id = str(uuid4())
        run_number = _next_run_number(conn, session_id)
        on_run_started(
            conn,
            session_id,
            rerun_id,
            run_number,
            trigger="chat_feedback",
            previous_run_id=previous_run_id,
        )
        for feedback_id in feedback_ids:
            on_feedback_triggered_rerun(conn, feedback_id, rerun_id)

        for entry in updated_agents:
            agent_id = str(entry.get("agent_id") or "").strip()
            if not agent_id:
                continue
            agent_run_id = str(uuid4())
            on_agent_run_started(
                conn,
                rerun_id,
                agent_run_id,
                agent_id,
                agent_name=str(entry.get("agent_name") or agent_id),
                agent_type=str(entry.get("agent_type") or "Sub_Agent"),
            )
            on_artifact_created(
                conn,
                agent_run_id,
                f"{agent_id}_output",
                artifact_type="output",
                content_ref=str(entry.get("output_path") or ""),
                size_bytes=len(str(entry.get("output") or "")),
            )
            on_agent_run_completed(conn, agent_run_id, status="completed")

        if assessment is not None:
            summary = str(assessment or "")[:500]
            score = _parse_score(assessment)
            on_quality_assessed(
                conn,
                rerun_id,
                score=score,
                assessment_type="qc_check",
                summary=summary,
            )
            if 0 < score < _QUALITY_ISSUE_THRESHOLD:
                severity = "high" if score < (_QUALITY_ISSUE_THRESHOLD / 2) else "medium"
                on_issue_created(
                    conn,
                    rerun_id,
                    issue_type="quality_below_threshold",
                    severity=severity,
                    description=(
                        f"Quality score {score:g} below threshold "
                        f"{_QUALITY_ISSUE_THRESHOLD:g}. {summary}"
                    )[:1000],
                )

        on_run_completed(conn, rerun_id, status="completed")
        return rerun_id
    except Exception:
        logger.debug("KG chat-feedback-rerun instrumentation failed", exc_info=True)
        return None



def record_quality_assessment(session_id: str, assessment: str, score: float | None = None) -> None:
    """Attach a quality assessment to the latest run WITHOUT completing session.

    Captures the run-level quality score (e.g. at the end of the action stage,
    before any feedback) so it can later be compared against a feedback rerun's
    quality via the knowledge graph. When the score is below the acceptable bar
    the shortfall is also persisted as an :class:`Issue` for the recurrence
    guard, mirroring :func:`record_quality_and_completion`.

    ``score`` – the authoritative overall quality score (0–100). When provided,
    it is recorded verbatim; otherwise it is parsed from ``assessment`` text as
    a best-effort fallback.
    """
    conn = _conn()
    if conn is None:
        return
    try:
        from daan.knowledge_graph.kg_events import (
            on_quality_assessed,
            on_issue_created,
        )

        run_id = _latest_run_id(conn, session_id)
        if not run_id:
            return
        summary = str(assessment or "")[:500]
        resolved_score = float(score) if score is not None else _parse_score(assessment)
        on_quality_assessed(
            conn,
            run_id,
            score=resolved_score,
            assessment_type="qc_check",
            summary=summary,
        )
        if 0 < resolved_score < _QUALITY_ISSUE_THRESHOLD:
            severity = "high" if resolved_score < (_QUALITY_ISSUE_THRESHOLD / 2) else "medium"
            on_issue_created(
                conn,
                run_id,
                issue_type="quality_below_threshold",
                severity=severity,
                description=(
                    f"Quality score {resolved_score:g} below threshold "
                    f"{_QUALITY_ISSUE_THRESHOLD:g}. {summary}"
                )[:1000],
            )
    except Exception:
        logger.debug("KG quality instrumentation failed", exc_info=True)


def record_quality_and_completion(
    session_id: str,
    assessment: str,
    score: float | None = None,
) -> None:
    """Attach a quality assessment to the latest run and complete the session.

    When the assessment indicates the run fell below the acceptable quality bar,
    the shortfall is also persisted as an :class:`Issue` so it becomes part of
    the use-case history and can be used to prevent the same problem recurring
    in later executions.

    ``score`` – the authoritative overall quality score (0–100). When provided,
    it is recorded verbatim on the quality node; otherwise the score is parsed
    from ``assessment`` text as a best-effort fallback.
    """
    record_quality_assessment(session_id, assessment, score=score)
    conn = _conn()
    if conn is None:
        return
    try:
        from daan.knowledge_graph.kg_events import on_session_completed

        on_session_completed(conn, session_id, status="completed")
    except Exception:
        logger.debug("KG completion instrumentation failed", exc_info=True)



def record_issue(
    session_id: str,
    issue_type: str,
    description: str = "",
    severity: str = "medium",
) -> None:
    """Attach an issue to the latest run of a session (best-effort)."""
    conn = _conn()
    if conn is None:
        return
    try:
        from daan.knowledge_graph.kg_events import on_issue_created

        run_id = _latest_run_id(conn, session_id)
        if run_id:
            on_issue_created(
                conn,
                run_id,
                issue_type=str(issue_type or "issue"),
                severity=str(severity or "medium"),
                description=str(description or "")[:1000],
            )
    except Exception:
        logger.debug("KG issue instrumentation failed", exc_info=True)


def record_agent_score_issue(session_id: str, agent_name: str, score: dict[str, Any]) -> None:
    """Persist an Issue when a per-agent quality score falls below threshold.

    The score's dimension feedback (completeness / relevance / context) and
    summary are folded into the issue description so that later executions of the
    same use case surface *what* went wrong (e.g. "Only 10 of 20 SQL blocks
    generated") in the refinement agent's "Previous issues to avoid" section.

    Best-effort and never raises.
    """
    built = _build_agent_score_issue(agent_name, score)
    if built is None:
        return
    description, severity = built
    record_issue(
        session_id,
        issue_type="agent_quality_below_threshold",
        description=description,
        severity=severity,
    )


def _build_agent_score_issue(
    agent_name: str, score: dict[str, Any]
) -> tuple[str, str] | None:
    """Build ``(description, severity)`` for a failing agent score.

    Returns ``None`` when the score is missing/invalid, scoring errored
    (``overall <= 0``) or the agent passed (``passed is True`` or
    ``overall >= threshold``).  Only the dimensions that actually underperformed
    contribute to the description so it stays specific and actionable.
    """
    if not isinstance(score, dict):
        return None
    try:
        threshold = float(score.get("THRESHOLD") or 80)
        overall = float(score.get("overall_score") or 0)
    except (TypeError, ValueError):
        return None

    # A non-positive overall typically means scoring failed/errored
    # (agent_scoring returns 0 on error), so it is ignored to avoid emitting
    # misleading quality issues. ``passed`` (when present) is authoritative.
    if overall <= 0:
        return None
    if score.get("passed") is True:
        return None
    if overall >= threshold:
        return None

    parts: list[str] = []
    dimensions = (
        ("completeness_score", "completeness_feedback", "Completeness"),
        ("answer_relevance_score", "relevance_feedback", "Relevance"),
        ("context_score", "context_feedback", "Context"),
    )
    for score_key, feedback_key, label in dimensions:
        try:
            dim_score = float(score.get(score_key) or 0)
        except (TypeError, ValueError):
            dim_score = 0.0
        feedback = str(score.get(feedback_key) or "").strip()
        if feedback and dim_score < threshold:
            parts.append(f"{label} ({dim_score:g}): {feedback}")

    summary = str(score.get("summary") or "").strip()
    if summary:
        parts.append(summary)

    if not parts:
        parts.append(f"Overall quality score {overall:g} below threshold {threshold:g}.")

    name = str(agent_name or "agent").strip()
    description = f"[{name}] " + " | ".join(parts)
    severity = "high" if overall < (threshold / 2) else "medium"
    return description, severity


def _json_safe(value: Any) -> Any:
    """Recursively convert KG rows into JSON-serializable values.

    KuzuDB returns native ``datetime``/``date`` objects for timestamp columns,
    which break ``json.dumps`` when the guard is later embedded into a prompt
    context.  This normalizes those (and any nested containers) to ISO strings.
    """
    import datetime as _dt

    if isinstance(value, (_dt.datetime, _dt.date)):
        return value.isoformat()
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    return value


def get_recurrence_guard(
    usecase_id: str,
    run_limit: int = 5,
    agent_id: str | None = None,
    owner_username: str | None = None,
) -> dict[str, Any]:
    """Return recent feedback + issues for a use case, for recurrence validation.

    Best-effort: returns an empty structure when the KG is unavailable so callers
    can safely embed the result into a validation/quality prompt context.

    When ``owner_username`` is supplied the history is scoped to that user's own
    sessions so one user's feedback/issues never influence another user's runs.
    """
    empty = {
        "usecase_id": usecase_id,
        "agent_id": agent_id,
        "runs": [],
        "issues": [],
        "feedback": [],
    }
    if not usecase_id:
        return empty
    conn = _conn()
    if conn is None:
        return empty
    try:
        if agent_id:
            from daan.knowledge_graph.queries import (
                get_recent_feedback_for_agent_history,
                get_recent_issues_for_agent_history,
            )

            feedback = get_recent_feedback_for_agent_history(
                conn,
                usecase_id=usecase_id,
                agent_id=agent_id,
                limit=run_limit,
                owner_username=owner_username,
            )
            issues = get_recent_issues_for_agent_history(
                conn,
                usecase_id=usecase_id,
                agent_id=agent_id,
                limit=run_limit,
                owner_username=owner_username,
            )
            return _json_safe({
                "usecase_id": usecase_id,
                "agent_id": agent_id,
                "runs": [],
                "issues": issues,
                "feedback": feedback,
            })

        from daan.knowledge_graph.queries import (
            get_recent_feedback_and_issues_for_usecase,
        )

        result = get_recent_feedback_and_issues_for_usecase(
            conn, usecase_id, run_limit=run_limit, owner_username=owner_username
        )
        return _json_safe(result)
    except Exception:
        logger.debug("KG recurrence-guard lookup failed", exc_info=True)
        return empty


def _iter_session_score_files(session_id: str):
    """Yield ``(agent_name, score_dict)`` for every persisted score in a session.

    Scans both base scores (``agents/<id>/score.json``) and feedback-rerun
    scores (``agents/<id>/feedback/<seq>/score.json``).  Best-effort: silently
    skips unreadable / malformed files.
    """
    import json as _json

    try:
        from daan.flow.session_service import _storage_root
    except Exception:
        return
    try:
        agents_dir = _storage_root() / session_id / "agents"
        if not agents_dir.is_dir():
            return
        for score_path in agents_dir.glob("*/**/score.json"):
            try:
                data = _json.loads(score_path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if not isinstance(data, dict):
                continue
            name = str(
                data.get("agent_name")
                or score_path.parent.name
                or "agent"
            ).strip()
            yield name, data
    except Exception:
        logger.debug("Reading session score files failed", exc_info=True)
        return


def _collect_score_file_issues(
    usecase_id: str, run_limit: int = 5, owner_username: str | None = None
) -> list[dict[str, Any]]:
    """Derive 'issues to avoid' from persisted score files of recent sessions.

    KG Issue nodes only exist for runs executed after issue-instrumentation was
    enabled, so failing scores from earlier runs would never surface.  This reads
    the on-disk ``score.json`` files for the use case's most recent sessions and
    converts each failing agent score into an issue dict matching the KG issue
    shape.  Best-effort: returns ``[]`` on any failure.

    Scoped to the requesting user's own sessions when ``owner_username`` is set.
    """
    if not usecase_id:
        return []
    conn = _conn()
    if conn is None:
        return []
    try:
        from daan.knowledge_graph.queries import get_recent_sessions_for_usecase

        session_ids = get_recent_sessions_for_usecase(
            conn, usecase_id, limit=run_limit, owner_username=owner_username
        )
    except Exception:
        logger.debug("Recent-session lookup failed", exc_info=True)
        return []

    issues: list[dict[str, Any]] = []
    seen: set[str] = set()
    for sid in session_ids:
        for agent_name, score in _iter_session_score_files(sid):
            built = _build_agent_score_issue(agent_name, score)
            if built is None:
                continue
            description, severity = built
            if description in seen:
                continue
            seen.add(description)
            issues.append(
                {
                    "issue_type": "agent_quality_below_threshold",
                    "severity": severity,
                    "description": description,
                }
            )
    return issues


def get_recurrence_guidance_text(
    usecase_id: str,
    run_limit: int = 5,
    agent_id: str | None = None,
    owner_username: str | None = None,
) -> str:
    """Build a prompt-ready guidance block from the use case's recent history.

    Returns a markdown block listing the issues and user feedback recorded in
    the last ``run_limit`` executions of the use case, so generation agents can
    proactively avoid repeating them.  Returns an empty string when there is no
    history (e.g. the first run) or the KG is unavailable.

    When ``owner_username`` is supplied the guidance is scoped to that user's
    own sessions so refinement prompts stay isolated per user.
    """
    guard = get_recurrence_guard(
        usecase_id, run_limit=run_limit, agent_id=agent_id, owner_username=owner_username
    )
    issues = list(guard.get("issues") or [])
    feedback = guard.get("feedback") or []

    # Augment KG-recorded issues with failing agent scores persisted on disk so
    # that quality shortfalls surface even when no KG Issue node was recorded for
    # an earlier run.  Dedupe by description against the KG issues.
    seen_desc = {str(i.get("description") or "").strip() for i in issues}
    for extra in _collect_score_file_issues(
        usecase_id, run_limit=run_limit, owner_username=owner_username
    ):
        desc = str(extra.get("description") or "").strip()
        if desc and desc not in seen_desc:
            seen_desc.add(desc)
            issues.append(extra)

    if not issues and not feedback:
        return ""

    lines: list[str] = [
        (
            f"### Lessons from the last executions of this agent ({agent_id})"
            if agent_id
            else "### Lessons from the last executions of this use case"
        ),
        (
            "Ensure the feedback below is addressed and do NOT reintroduce any previously reported problems."
            if agent_id
            else "Ensure the issues below do NOT recur and that the prior feedback is addressed."
        ),
    ]

    if issues:
        lines.append("")
        lines.append(
            "Previous issues for this agent to avoid:"
            if agent_id
            else "Previous issues to avoid:"
        )
        for i in issues[:20]:
            issue_type = str(i.get("issue_type") or "issue")
            severity = str(i.get("severity") or "")
            desc = str(i.get("description") or "").strip()
            sev = f" [{severity}]" if severity else ""
            lines.append(f"- {issue_type}{sev}: {desc}" if desc else f"- {issue_type}{sev}")

    if feedback:
        lines.append("")
        lines.append(
            "Previous user feedback for this agent to incorporate:"
            if agent_id
            else "Previous user feedback to incorporate:"
        )
        for f in feedback[:20]:
            comment = str(f.get("comment") or "").strip()
            if comment:
                lines.append(f"- {comment}")

    return "\n".join(lines).strip()
