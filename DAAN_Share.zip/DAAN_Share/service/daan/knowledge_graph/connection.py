"""Thread-safe singleton connection manager for the KuzuDB knowledge graph."""

from __future__ import annotations

import threading
from pathlib import Path
from typing import TYPE_CHECKING

import kuzu

from daan.core.logging import get_logger
from daan.knowledge_graph.schema import init_kg

if TYPE_CHECKING:
    pass

logger = get_logger(__name__)

# ── Module-level singleton state ────────────────────────────────────────────
_lock = threading.Lock()
_db: kuzu.Database | None = None
_conn: kuzu.Connection | None = None

_REPO_ROOT = Path(__file__).resolve().parents[3]
_DEFAULT_DB_PATH = _REPO_ROOT / "data" / "knowledge_graph_db"


class KnowledgeGraphLockedError(RuntimeError):
    """Raised when the KuzuDB store is already locked by another process."""


def get_kg_connection(db_path: str | None = None) -> kuzu.Connection:
    """Return a singleton KuzuDB connection, creating it on first call.

    Parameters
    ----------
    db_path:
        Filesystem path for the KuzuDB store.  Falls back to
        ``Settings.KUZU_DB_PATH`` (if present in daan config) or
        ``data/knowledge_graph_db``.
    """
    global _db, _conn  # noqa: PLW0603

    if _conn is not None:
        return _conn

    with _lock:
        # Double-checked locking
        if _conn is not None:
            return _conn

        resolved_path = _resolve_db_path(db_path)
        logger.info("Opening KuzuDB at %s", resolved_path)

        db_dir = resolved_path
        db_dir.parent.mkdir(parents=True, exist_ok=True)

        try:
            _db = kuzu.Database(str(db_dir))
            init_kg(_db)
            _conn = kuzu.Connection(_db)
        except RuntimeError as exc:
            if _is_lock_error(exc):
                raise KnowledgeGraphLockedError(
                    f"KuzuDB is already locked at '{db_dir}'. Stop the other DAAN process or set KUZU_DB_PATH for this instance."
                ) from exc
            raise

        logger.info("KuzuDB connection established")
        return _conn


def close_kg_connection() -> None:
    """Explicitly close the singleton connection (for app shutdown)."""
    global _db, _conn  # noqa: PLW0603

    with _lock:
        if _conn is not None:
            _conn.close()
            _conn = None
        _db = None
        logger.info("KuzuDB connection closed")


def get_kg_db_path(db_path: str | None = None) -> Path:
    """Return resolved filesystem path used by the KG database."""
    return _resolve_db_path(db_path)


# ── Internal helpers ────────────────────────────────────────────────────────

def _resolve_db_path(override: str | None) -> Path:
    """Resolve DB path: explicit override > config setting > default."""
    if override:
        return _normalize_db_path(override)

    try:
        from daan.core.config import get_settings
        settings = get_settings()
        path = getattr(settings, "KUZU_DB_PATH", None)
        if path:
            return _normalize_db_path(path)
    except Exception:
        pass

    return _DEFAULT_DB_PATH


def _normalize_db_path(path: str | Path) -> Path:
    candidate = Path(path).expanduser()
    if not candidate.is_absolute():
        candidate = _REPO_ROOT / candidate
    return candidate.resolve()


def _is_lock_error(exc: RuntimeError) -> bool:
    message = str(exc).lower()
    return "could not set lock on file" in message or "lock on file" in message
