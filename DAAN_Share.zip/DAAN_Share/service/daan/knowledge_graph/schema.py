"""
KuzuDB Graph Schema – DAAN Agentic Workflow Knowledge Graph.

Enterprise-grade agentic workflow execution graph with stage/substage/step
level execution evidence for full debuggability.

Flow: session → context → dynamic → quality score → feedback → agent action → reporter → QC

Key semantics:
- A Session persists until the user explicitly switches context / creates a new Session.
- When the user changes UseCase, a NEW Session is created.
- WorkflowStage defines top-level stages (context, dynamic, quality, feedback, agent_action, reporter, qc).
- SubStage defines nested sub-stages under each stage.
- StageExecution is per Run × Stage (tracks per-run stage progress).
- StepExecution is per StageExecution × step, links to AgentRun/Tool/Prompt/Artifact/Issue/Quality.

Notes:
- Uses CREATE ... IF NOT EXISTS for idempotency.
- REL TABLE GROUP is deprecated since v0.8.0; use multi FROM...TO inside CREATE REL TABLE.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from daan.core.logging import get_logger

if TYPE_CHECKING:
    import kuzu

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# STABLE ENTITY NODE TABLES (config-time)
# ---------------------------------------------------------------------------

_STABLE_NODE_TABLES: list[str] = [
    # ── Business Hierarchy ──────────────────────────────────────────────
    """
    CREATE NODE TABLE IF NOT EXISTS Archetype(
        id          STRING,
        name        STRING,
        description STRING,
        created_at  TIMESTAMP,
        updated_at  TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,
    """
    CREATE NODE TABLE IF NOT EXISTS Role(
        id          STRING,
        name        STRING,
        description STRING,
        created_at  TIMESTAMP,
        updated_at  TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,
    """
    CREATE NODE TABLE IF NOT EXISTS UseCase(
        id          STRING,
        name        STRING,
        description STRING,
        category    STRING,
        created_at  TIMESTAMP,
        updated_at  TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,

    # ── Identity ────────────────────────────────────────────────────────
    """
    CREATE NODE TABLE IF NOT EXISTS User(
        id          STRING,
        username    STRING,
        email       STRING,
        created_at  TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,

    # ── Agent Blueprint ─────────────────────────────────────────────────
    """
    CREATE NODE TABLE IF NOT EXISTS Planner(
        id          STRING,
        name        STRING,
        strategy    STRING,
        version     STRING,
        config_ref  STRING,
        created_at  TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,
    """
    CREATE NODE TABLE IF NOT EXISTS Agent(
        id          STRING,
        name        STRING,
        agent_type  STRING,
        version     STRING,
        description STRING,
        config_ref  STRING,
        created_at  TIMESTAMP,
        updated_at  TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,
    """
    CREATE NODE TABLE IF NOT EXISTS PromptVersion(
        id           STRING,
        agent_id     STRING,
        version      STRING,
        template_ref STRING,
        hash         STRING,
        created_at   TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,
    """
    CREATE NODE TABLE IF NOT EXISTS Tool(
        id          STRING,
        name        STRING,
        tool_type   STRING,
        version     STRING,
        description STRING,
        created_at  TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,

    # ── Workflow Stage Blueprint ────────────────────────────────────────
    """
    CREATE NODE TABLE IF NOT EXISTS WorkflowStage(
        id           STRING,
        name         STRING,
        stage_order  INT64,
        description  STRING,
        is_required  BOOLEAN,
        created_at   TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,
    """
    CREATE NODE TABLE IF NOT EXISTS SubStage(
        id           STRING,
        name         STRING,
        stage_order  INT64,
        description  STRING,
        created_at   TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,
]

# ---------------------------------------------------------------------------
# RUNTIME ENTITY NODE TABLES (execution-time)
# ---------------------------------------------------------------------------

_RUNTIME_NODE_TABLES: list[str] = [
    """
    CREATE NODE TABLE IF NOT EXISTS Session(
        id          STRING,
        status      STRING,
        started_at  TIMESTAMP,
        ended_at    TIMESTAMP,
        metadata    STRING,
        PRIMARY KEY (id)
    )
    """,
    """
    CREATE NODE TABLE IF NOT EXISTS Run(
        id          STRING,
        run_number  INT64,
        status      STRING,
        started_at  TIMESTAMP,
        ended_at    TIMESTAMP,
        duration_ms INT64,
        trigger     STRING,
        metadata    STRING,
        PRIMARY KEY (id)
    )
    """,
    """
    CREATE NODE TABLE IF NOT EXISTS AgentRun(
        id              STRING,
        status          STRING,
        execution_order INT64,
        started_at      TIMESTAMP,
        ended_at        TIMESTAMP,
        duration_ms     INT64,
        error_message   STRING,
        retry_count     INT64,
        log_ref         STRING,
        metadata        STRING,
        PRIMARY KEY (id)
    )
    """,
    """
    CREATE NODE TABLE IF NOT EXISTS Artifact(
        id            STRING,
        name          STRING,
        artifact_type STRING,
        content_ref   STRING,
        mime_type     STRING,
        size_bytes    INT64,
        hash          STRING,
        created_at    TIMESTAMP,
        metadata      STRING,
        PRIMARY KEY (id)
    )
    """,
    """
    CREATE NODE TABLE IF NOT EXISTS QualityAssessment(
        id              STRING,
        score           DOUBLE,
        max_score       DOUBLE,
        assessment_type STRING,
        summary         STRING,
        details_ref     STRING,
        created_at      TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,
    """
    CREATE NODE TABLE IF NOT EXISTS Issue(
        id          STRING,
        issue_type  STRING,
        severity    STRING,
        description STRING,
        status      STRING,
        created_at  TIMESTAMP,
        resolved_at TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,
    """
    CREATE NODE TABLE IF NOT EXISTS Feedback(
        id            STRING,
        feedback_type STRING,
        rating        INT64,
        comment       STRING,
        source        STRING,
        created_at    TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,

    # ── Stage Execution (per Run × Stage) ──────────────────────────────
    """
    CREATE NODE TABLE IF NOT EXISTS StageExecution(
        id          STRING,
        status      STRING,
        started_at  TIMESTAMP,
        ended_at    TIMESTAMP,
        duration_ms INT64,
        metadata    STRING,
        PRIMARY KEY (id)
    )
    """,

    # ── Step Execution (per StageExecution × step) ─────────────────────
    """
    CREATE NODE TABLE IF NOT EXISTS StepExecution(
        id            STRING,
        step_name     STRING,
        step_order    INT64,
        status        STRING,
        started_at    TIMESTAMP,
        ended_at      TIMESTAMP,
        duration_ms   INT64,
        error_message STRING,
        prompt_ref    STRING,
        tool_ref      STRING,
        artifact_ref  STRING,
        metadata      STRING,
        PRIMARY KEY (id)
    )
    """,

    # ── External Resource (MCP-created external artefacts) ─────────────
    # Records identifiers of resources an action agent creates in external
    # systems (Jira issue, Azure DevOps work item/epic, Confluence page, …)
    # so a later re-run can UPDATE the same resource instead of duplicating it.
    # Keyed by a deterministic id derived from (session_id, agent_id, local_key).
    """
    CREATE NODE TABLE IF NOT EXISTS ExternalResource(
        id            STRING,
        session_id    STRING,
        agent_id      STRING,
        local_key     STRING,
        resource_type STRING,
        resource_kind STRING,
        resource_key  STRING,
        external_url  STRING,
        metadata      STRING,
        created_at    TIMESTAMP,
        updated_at    TIMESTAMP,
        PRIMARY KEY (id)
    )
    """,
]

# ---------------------------------------------------------------------------
# RELATIONSHIP TABLES
# Multiplicities enforce your lifecycle constraints. [1](https://kuzudb.github.io/docs/cypher/data-definition/create-table/)
# ---------------------------------------------------------------------------

_REL_TABLES: list[str] = [
    # ── Business Hierarchy ──────────────────────────────────────────────
    """
    CREATE REL TABLE IF NOT EXISTS HAS_ROLE(
        FROM Archetype TO Role,
        assigned_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS HAS_USECASE(
        FROM Role TO UseCase,
        assigned_at TIMESTAMP
    )
    """,

    # ── Session semantics (your requirement) ────────────────────────────
    # Each Session is initiated by exactly one User, and a User can have many Sessions.
    """
    CREATE REL TABLE IF NOT EXISTS INITIATED(
        FROM User TO Session,
        initiated_at TIMESTAMP
    )
    """,
    # Each Session belongs to exactly one UseCase.
    # When UseCase changes, you create a NEW Session (so this should be ONE_MANY).
    """
    CREATE REL TABLE IF NOT EXISTS HAS_SESSION(
        FROM UseCase TO Session,
        created_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS HAS_ARCHETYPE(
        FROM Session TO Archetype,
        created_at TIMESTAMP
    )
    """,

    # ── Run lifecycle inside a session ──────────────────────────────────
    # Session can contain many Runs; each Run belongs to exactly one Session.
    """
    CREATE REL TABLE IF NOT EXISTS HAS_RUN(
        FROM Session TO Run,
        created_at TIMESTAMP
    )
    """,
    # Each Run can have at most one previous Run pointer.
    """
    CREATE REL TABLE IF NOT EXISTS PREVIOUS_RUN(
        FROM Run TO Run,
        created_at TIMESTAMP
    )
    """,

    # ── Planner & Agent Blueprint ───────────────────────────────────────
    # Each Run uses at most one Planner; many Runs can use the same Planner.
    """
    CREATE REL TABLE IF NOT EXISTS USES_PLANNER(
        FROM Run TO Planner,
        created_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS PLANS_AGENT(
        FROM Planner TO Agent,
        execution_order INT64,
        created_at      TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS USES_PROMPT(
        FROM Agent TO PromptVersion,
        assigned_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS USES_TOOL(
        FROM Agent TO Tool,
        assigned_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS DEPENDS_ON(
        FROM Agent TO Agent,
        dependency_type STRING
    )
    """,

    # ── Agent Execution ─────────────────────────────────────────────────
    # Run has many AgentRuns; each AgentRun belongs to exactly one Run.
    """
    CREATE REL TABLE IF NOT EXISTS EXECUTED_AGENT(
        FROM Run TO AgentRun,
        execution_order INT64
    )
    """,
    # AgentRun is instance of exactly one Agent.
    """
    CREATE REL TABLE IF NOT EXISTS INSTANCE_OF(
        FROM AgentRun TO Agent,
        created_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS DEPENDS_ON_RUN(
        FROM AgentRun TO AgentRun,
        dependency_type STRING
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS USED_TOOL(
        FROM AgentRun TO Tool,
        invocation_count INT64,
        duration_ms      INT64
    )
    """,

    # ── Artifact flow ───────────────────────────────────────────────────
    """
    CREATE REL TABLE IF NOT EXISTS USED_INPUT(
        FROM AgentRun TO Artifact,
        consumed_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS GENERATED(
        FROM AgentRun TO Artifact,
        generated_at TIMESTAMP
    )
    """,

    # ── Quality & Issues (polymorphic edges)
    # REL TABLE GROUP is deprecated; use multi FROM...TO in CREATE REL TABLE. [1](https://kuzudb.github.io/docs/cypher/data-definition/create-table/)
    """
    CREATE REL TABLE IF NOT EXISTS HAS_QUALITY(
        FROM Run      TO QualityAssessment,
        FROM AgentRun TO QualityAssessment,
        assessed_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS HAS_ISSUE(
        FROM Run      TO Issue,
        FROM AgentRun TO Issue,
        detected_at TIMESTAMP
    )
    """,

    # ── Issue & Artifact impact ─────────────────────────────────────────
    """
    CREATE REL TABLE IF NOT EXISTS AFFECTS(
        FROM Issue TO Artifact,
        impact STRING
    )
    """,

    # ── Feedback ────────────────────────────────────────────────────────
    # Session can have many Feedback records; each Feedback belongs to one Session.
    """
    CREATE REL TABLE IF NOT EXISTS HAS_FEEDBACK(
        FROM Session TO Feedback,
        created_at TIMESTAMP
    )
    """,
    # Feedback typically targets one UseCase / one Run / one AgentRun etc.
    """
    CREATE REL TABLE IF NOT EXISTS FOR_USECASE(
        FROM Feedback TO UseCase
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS TARGETS_AGENT(
        FROM Feedback TO Agent
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS TARGETS_AGENT_RUN(
        FROM Feedback TO AgentRun
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS REFERS_TO_RUN(
        FROM Feedback TO Run
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS TRIGGERED_RERUN(
        FROM Feedback TO Run,
        triggered_at TIMESTAMP
    )
    """,

    # ── Workflow Stage Hierarchy ────────────────────────────────────────
    """
    CREATE REL TABLE IF NOT EXISTS HAS_SUBSTAGE(
        FROM WorkflowStage TO SubStage,
        stage_order INT64
    )
    """,

    # ── Stage Execution linkage ─────────────────────────────────────────
    """
    CREATE REL TABLE IF NOT EXISTS HAS_STAGE_EXEC(
        FROM Run TO StageExecution,
        created_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS FOR_STAGE(
        FROM StageExecution TO WorkflowStage,
        created_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS FOR_SUBSTAGE(
        FROM StageExecution TO SubStage,
        created_at TIMESTAMP
    )
    """,

    # ── Step Execution linkage ──────────────────────────────────────────
    """
    CREATE REL TABLE IF NOT EXISTS HAS_STEP(
        FROM StageExecution TO StepExecution,
        step_order INT64
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS STEP_AGENT_RUN(
        FROM StepExecution TO AgentRun,
        created_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS STEP_USED_TOOL(
        FROM StepExecution TO Tool,
        created_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS STEP_USED_PROMPT(
        FROM StepExecution TO PromptVersion,
        created_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS STEP_ARTIFACT(
        FROM StepExecution TO Artifact,
        direction STRING,
        created_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS STEP_QUALITY(
        FROM StepExecution TO QualityAssessment,
        created_at TIMESTAMP
    )
    """,
    """
    CREATE REL TABLE IF NOT EXISTS STEP_ISSUE(
        FROM StepExecution TO Issue,
        created_at TIMESTAMP
    )
    """,

    # ── External Resource linkage ───────────────────────────────────────
    # A Session owns the external resources its action agents created.
    """
    CREATE REL TABLE IF NOT EXISTS HAS_EXTERNAL_RESOURCE(
        FROM Session TO ExternalResource,
        created_at TIMESTAMP
    )
    """,
]

# ---------------------------------------------------------------------------
# Public initialization helper
# ---------------------------------------------------------------------------

def init_kg(db: kuzu.Database) -> None:
    """
    Create all node and relationship tables idempotently.

    Uses conn.execute() (same approach shown in Kùzu Python API docs). [2](https://kuzudb.github.io/docs/client-apis/python/)
    Because IF NOT EXISTS is used, most DDL failures indicate real issues,
    so we fail-fast to avoid partial schema. [1](https://kuzudb.github.io/docs/cypher/data-definition/create-table/)
    """
    import kuzu as _kuzu

    conn = _kuzu.Connection(db)
    all_ddl = _STABLE_NODE_TABLES + _RUNTIME_NODE_TABLES + _REL_TABLES

    for ddl in all_ddl:
        stmt = ddl.strip()
        try:
            conn.execute(stmt)
        except RuntimeError as exc:
            logger.error("KG DDL failed: %s\nStatement: %s", exc, stmt)
            raise

    logger.info("Knowledge-graph schema initialised (%d DDL statements)", len(all_ddl))