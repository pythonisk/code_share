"""
Cypher query library for the DAAN Knowledge Graph.

Organised by query-pattern category:
  • Retrieval / hierarchy
  • Lineage
  • Debugging
  • Quality analytics
  • Operational tracing

Every public function accepts a ``kuzu.Connection`` and returns
``list[dict]`` for easy consumption by API layers and prompt builders.
"""

from __future__ import annotations

import json
from datetime import date, datetime, timezone
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    import kuzu


# ═══════════════════════════════════════════════════════════════════════════
#  Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _rows(result: kuzu.QueryResult) -> list[dict[str, Any]]:
    """Drain a KuzuDB QueryResult into a list of dicts."""
    columns = result.get_column_names()
    out: list[dict[str, Any]] = []
    while result.has_next():
        row = result.get_next()
        out.append(dict(zip(columns, row)))
    return out


def _to_iso_str(value: Any) -> str:
    """Normalize date/time values into API-safe strings.

    KuzuDB returns TIMESTAMP columns as naive ``datetime`` objects that are in
    UTC. Emitting ``.isoformat()`` on a naive value drops the timezone, which
    makes the frontend's ``new Date()`` interpret the instant as *local* time
    and display the wrong clock time. To avoid that, naive datetimes are treated
    as UTC and serialized with an explicit offset so clients convert correctly.
    """
    if value is None:
        return ""
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    return str(value)


def _latest_run_id_for_session(conn: kuzu.Connection, session_id: str) -> str | None:
    """Return the latest run id for a session, if present."""
    rows = _rows(conn.execute(
        """
        MATCH (s:Session)-[:HAS_RUN]->(r:Run)
        WHERE s.id = $sid
        RETURN r.id AS iteration_id
        ORDER BY r.run_number DESC, r.started_at DESC
        LIMIT 1
        """,
        {"sid": session_id},
    ))
    if not rows:
        return None
    return rows[0].get("iteration_id")


def get_external_resources(
    conn: kuzu.Connection,
    session_id: str,
    agent_id: str | None = None,
) -> list[dict[str, Any]]:
    """Return external resources recorded for a session.

    When ``agent_id`` is provided, only that agent's resources are returned.
    Each row exposes the stable ``local_key`` and the external identifier so a
    re-running action agent can update the same resource instead of creating a
    new one.
    """
    sid = (session_id or "").strip()
    if not sid:
        return []

    params: dict[str, Any] = {"sid": sid}
    where = "er.session_id = $sid"
    aid = (agent_id or "").strip()
    if aid:
        where += " AND er.agent_id = $aid"
        params["aid"] = aid

    rows = _rows(conn.execute(
        f"""
        MATCH (er:ExternalResource)
        WHERE {where}
        RETURN er.agent_id AS agent_id,
               er.local_key AS local_key,
               er.resource_type AS resource_type,
               er.resource_kind AS resource_kind,
               er.resource_key AS resource_key,
               er.external_url AS external_url,
               er.metadata AS metadata,
               er.updated_at AS updated_at
        ORDER BY er.updated_at DESC
        """,
        params,
    ))
    # Dedupe by external id (resource_key): the same real-world resource may have
    # been recorded under multiple local_keys by older runs. Keep the most recent
    # (rows are already ordered updated_at DESC).
    deduped: list[dict[str, Any]] = []
    seen_keys: set[str] = set()
    for row in rows:
        row["updated_at"] = _to_iso_str(row.get("updated_at"))
        # Surface the item title (stored in metadata JSON) so a re-running agent
        # can match items across local_key naming schemes.
        raw_meta = row.pop("metadata", None)
        title = ""
        if isinstance(raw_meta, str) and raw_meta:
            try:
                meta = json.loads(raw_meta)
                if isinstance(meta, dict):
                    title = str(meta.get("title") or meta.get("name") or "").strip()
            except (ValueError, TypeError):
                title = ""
        row["title"] = title
        key = str(row.get("resource_key") or "").strip()
        if key:
            dedup_id = f"{row.get('agent_id')}|{key}"
            if dedup_id in seen_keys:
                continue
            seen_keys.add(dedup_id)
        deduped.append(row)
    return deduped


# ═══════════════════════════════════════════════════════════════════════════
#  1.  RETRIEVAL / HIERARCHY
# ═══════════════════════════════════════════════════════════════════════════

def get_active_hierarchy(conn: kuzu.Connection) -> list[dict[str, Any]]:
    """Archetype → Role → UseCase for currently running executions.

    Returns rows with archetype/role/usecase names and the active run id.
    """
    cypher = """
        MATCH (a:Archetype)-[:HAS_ROLE]->(r:Role)-[:HAS_USECASE]->(uc:UseCase)
              -[:HAS_SESSION]->(s:Session)-[:HAS_RUN]->(run:Run)
        WHERE run.status = 'running'
         RETURN a.name          AS archetype,
             r.name          AS role,
             uc.name         AS use_case,
             s.id            AS session_id,
             run.run_number  AS iteration_number,
             run.started_at  AS started_at
        ORDER BY run.started_at DESC
    """
    return _rows(conn.execute(cypher))


def get_recent_running_runs(
    conn: kuzu.Connection, limit: int = 10
) -> list[dict[str, Any]]:
    """Fetch the last *limit* currently running runs."""
    cypher = """
        MATCH (run:Run)
        WHERE run.status = 'running'
        RETURN run.*
        ORDER BY run.started_at DESC
        LIMIT $limit
    """
    return _rows(conn.execute(cypher, {"limit": limit}))


def get_full_run_details(
    conn: kuzu.Connection, iteration_id: str
) -> dict[str, Any]:
    """All details for a single run: planner, agent runs, issues, quality, feedback.

    Returns a dict with keys: run, planner, agent_runs, issues, quality, feedback.
    """
    run = _rows(conn.execute(
        "MATCH (r:Run) WHERE r.id = $rid RETURN r.*", {"rid": iteration_id}
    ))

    planner = _rows(conn.execute("""
        MATCH (r:Run)-[:USES_PLANNER]->(p:Planner)
        WHERE r.id = $rid
        RETURN p.*
    """, {"rid": iteration_id}))

    agent_runs = _rows(conn.execute("""
        MATCH (r:Run)-[e:EXECUTED_AGENT]->(ar:AgentRun)-[:INSTANCE_OF]->(a:Agent)
        WHERE r.id = $rid
        RETURN ar.id            AS agent_run_id,
               ar.status        AS status,
               ar.execution_order AS execution_order,
               ar.duration_ms   AS duration_ms,
               ar.error_message AS error_message,
               a.name           AS agent_name,
               a.agent_type     AS agent_type
        ORDER BY ar.execution_order
    """, {"rid": iteration_id}))

    issues = _rows(conn.execute("""
        MATCH (r:Run)-[:HAS_ISSUE]->(i:Issue)
        WHERE r.id = $rid
        RETURN i.*
    """, {"rid": iteration_id}))

    quality = _rows(conn.execute("""
        MATCH (r:Run)-[:HAS_QUALITY]->(q:QualityAssessment)
        WHERE r.id = $rid
        RETURN q.*
    """, {"rid": iteration_id}))

    feedback = _rows(conn.execute("""
        MATCH (s:Session)-[:HAS_RUN]->(r:Run),
              (s)-[:HAS_FEEDBACK]->(f:Feedback)
        WHERE r.id = $rid
        RETURN f.*
    """, {"rid": iteration_id}))

    return {
        "run": run[0] if run else None,
        "planner": planner[0] if planner else None,
        "agent_runs": agent_runs,
        "issues": issues,
        "quality": quality,
        "feedback": feedback,
    }


# ═══════════════════════════════════════════════════════════════════════════
#  2.  LINEAGE
# ═══════════════════════════════════════════════════════════════════════════

def get_session_runs(
    conn: kuzu.Connection, session_id: str
) -> list[dict[str, Any]]:
    """All runs in a session, ordered by run_number."""
    cypher = """
        MATCH (s:Session)-[:HAS_RUN]->(r:Run)
        WHERE s.id = $sid
         RETURN r.run_number AS iteration_number,
             r.status     AS status,
             r.trigger    AS trigger,
             r.started_at AS started_at,
             r.ended_at   AS ended_at,
             r.duration_ms AS duration_ms
        ORDER BY r.run_number
    """
    return _rows(conn.execute(cypher, {"sid": session_id}))


def get_feedback_caused_rerun(
    conn: kuzu.Connection, session_id: str
) -> list[dict[str, Any]]:
    """Show which feedback triggered a rerun within a session."""
    cypher = """
        MATCH (s:Session)-[:HAS_FEEDBACK]->(f:Feedback)-[tr:TRIGGERED_RERUN]->(r:Run)
        WHERE s.id = $sid
        RETURN f.id            AS feedback_id,
               f.feedback_type AS feedback_type,
               f.comment       AS comment,
               r.id            AS rerun_id,
               r.run_number    AS rerun_number,
               tr.triggered_at AS triggered_at
        ORDER BY tr.triggered_at
    """
    return _rows(conn.execute(cypher, {"sid": session_id}))


def get_previous_and_current_outputs(
    conn: kuzu.Connection, iteration_id: str
) -> dict[str, list[dict[str, Any]]]:
    """Show outputs of the given run and its predecessor (if any)."""
    current = _rows(conn.execute("""
        MATCH (r:Run)-[:EXECUTED_AGENT]->(ar:AgentRun)-[:GENERATED]->(art:Artifact)
        WHERE r.id = $rid
        RETURN ar.id AS agent_run_id, art.*
    """, {"rid": iteration_id}))

    previous = _rows(conn.execute("""
        MATCH (r:Run)-[:PREVIOUS_RUN]->(prev:Run)
              -[:EXECUTED_AGENT]->(ar:AgentRun)-[:GENERATED]->(art:Artifact)
        WHERE r.id = $rid
        RETURN ar.id AS agent_run_id, art.*
    """, {"rid": iteration_id}))

    return {"current": current, "previous": previous}


def get_run_lineage(
    conn: kuzu.Connection, iteration_id: str, max_depth: int = 20
) -> list[dict[str, Any]]:
    """Trace the rerun chain backwards via PREVIOUS_RUN (variable-length path)."""
    cypher = f"""
        MATCH (start:Run)-[:PREVIOUS_RUN*1..{max_depth}]->(ancestor:Run)
        WHERE start.id = $rid
        RETURN ancestor.id         AS iteration_id,
               ancestor.run_number AS run_number,
               ancestor.status     AS status,
               ancestor.trigger    AS trigger,
               ancestor.started_at AS started_at
        ORDER BY ancestor.run_number
    """
    return _rows(conn.execute(cypher, {"rid": iteration_id}))


# ═══════════════════════════════════════════════════════════════════════════
#  3.  DEBUGGING
# ═══════════════════════════════════════════════════════════════════════════

def get_most_failed_agents(
    conn: kuzu.Connection, limit: int = 10
) -> list[dict[str, Any]]:
    """Agents ranked by failure count."""
    cypher = """
        MATCH (ar:AgentRun)-[:INSTANCE_OF]->(a:Agent)
        WHERE ar.status = 'failed'
        RETURN a.id   AS agent_id,
               a.name AS agent_name,
               count(ar) AS failure_count
        ORDER BY failure_count DESC
        LIMIT $limit
    """
    return _rows(conn.execute(cypher, {"limit": limit}))


def get_agent_dependencies(
    conn: kuzu.Connection, agent_id: str
) -> list[dict[str, Any]]:
    """Direct blueprint-level dependencies of an agent."""
    cypher = """
        MATCH (a:Agent)-[d:DEPENDS_ON]->(dep:Agent)
        WHERE a.id = $aid
        RETURN dep.id              AS dependency_id,
               dep.name            AS dependency_name,
               d.dependency_type   AS dependency_type
    """
    return _rows(conn.execute(cypher, {"aid": agent_id}))


def get_top_issue_types_for_usecase(
    conn: kuzu.Connection, usecase_id: str, limit: int = 10
) -> list[dict[str, Any]]:
    """Most frequent issue types for a use case."""
    cypher = """
        MATCH (uc:UseCase)-[:HAS_SESSION]->(s:Session)-[:HAS_RUN]->(r:Run)
              -[:HAS_ISSUE]->(i:Issue)
        WHERE uc.id = $ucid
        RETURN i.issue_type AS issue_type,
               i.severity   AS severity,
               count(i)     AS occurrence_count
        ORDER BY occurrence_count DESC
        LIMIT $limit
    """
    return _rows(conn.execute(cypher, {"ucid": usecase_id, "limit": limit}))


def get_recent_feedback_and_issues_for_usecase(
    conn: kuzu.Connection, usecase_id: str, run_limit: int = 5,
    owner_username: str | None = None,
) -> dict[str, Any]:
    """Feedback + issues recorded across the last ``run_limit`` executions of a use case.

    Used to validate a new execution against the recent history of the same
    use case so that previously reported problems are not allowed to recur.

    When ``owner_username`` is provided the history is row-level scoped to the
    sessions that user initiated (via the ``INITIATED`` edge), so one user's
    feedback and issues never leak into another user's executions. Pass ``None``
    to consider every user's sessions (e.g. an admin / system view).

    Returns a dict with keys:
      • ``usecase_id``  – the use case the history belongs to
      • ``runs``        – the recent runs that were inspected (most recent first)
      • ``issues``      – distinct issues detected across those runs
      • ``feedback``    – user feedback attached to those runs / sessions
    """
    owner = (owner_username or "").strip()
    owner_join = "MATCH (owner:User)-[:INITIATED]->(s)" if owner else ""
    owner_where = "AND owner.username = $owner" if owner else ""

    # The most recent runs for this use case (newest first), scoped to the
    # requesting user's own sessions when an owner filter is supplied.
    run_params: dict[str, Any] = {"ucid": usecase_id, "limit": run_limit}
    if owner:
        run_params["owner"] = owner
    recent_runs = _rows(conn.execute(
        f"""
        MATCH (uc:UseCase)-[:HAS_SESSION]->(s:Session)-[:HAS_RUN]->(r:Run)
        {owner_join}
        WHERE uc.id = $ucid {owner_where}
        RETURN r.id          AS run_id,
               r.run_number  AS run_number,
               r.status      AS status,
               r.trigger     AS trigger,
               r.started_at  AS started_at
        ORDER BY r.started_at DESC
        LIMIT $limit
        """,
        run_params,
    ))
    run_ids = [row["run_id"] for row in recent_runs if row.get("run_id")]
    if not run_ids:
        return {"usecase_id": usecase_id, "runs": [], "issues": [], "feedback": []}

    issues = _rows(conn.execute(
        """
        MATCH (r:Run)-[:HAS_ISSUE]->(i:Issue)
        WHERE r.id IN $rids
        RETURN DISTINCT i.id          AS issue_id,
               i.issue_type  AS issue_type,
               i.severity    AS severity,
               i.description AS description,
               i.status      AS status,
               i.created_at  AS created_at
        ORDER BY created_at DESC
        """,
        {"rids": run_ids},
    ))

    # Feedback that either explicitly refers to one of the recent runs or that
    # was submitted in a session containing one of those runs (owner-scoped).
    fb_params: dict[str, Any] = {"ucid": usecase_id, "rids": run_ids}
    if owner:
        fb_params["owner"] = owner
    feedback = _rows(conn.execute(
        f"""
        MATCH (uc:UseCase)-[:HAS_SESSION]->(s:Session)-[:HAS_RUN]->(r:Run),
              (s)-[:HAS_FEEDBACK]->(f:Feedback)
        {owner_join}
        WHERE uc.id = $ucid AND r.id IN $rids {owner_where}
        RETURN DISTINCT f.id           AS feedback_id,
               f.feedback_type AS feedback_type,
               f.rating        AS rating,
               f.comment       AS comment,
               f.source        AS source,
               f.created_at    AS created_at
        ORDER BY created_at DESC
        """,
        fb_params,
    ))

    return {
        "usecase_id": usecase_id,
        "runs": recent_runs,
        "issues": issues,
        "feedback": feedback,
    }


def get_recent_sessions_for_usecase(
    conn: kuzu.Connection, usecase_id: str, limit: int = 5,
    owner_username: str | None = None,
) -> list[str]:
    """Return the session ids of the last ``limit`` executions of a use case.

    Ordered most-recent-first by the latest run within each session.  Used to
    locate the on-disk agent score files for recent runs so that persisted
    quality shortfalls can feed the recurrence guidance even when no KG Issue
    node was recorded for them.

    When ``owner_username`` is provided, only the sessions initiated by that
    user are returned so on-disk score history stays isolated per user.
    """
    owner = (owner_username or "").strip()
    owner_join = "MATCH (owner:User)-[:INITIATED]->(s)" if owner else ""
    owner_where = "AND owner.username = $owner" if owner else ""
    params: dict[str, Any] = {"ucid": usecase_id, "limit": limit}
    if owner:
        params["owner"] = owner
    rows = _rows(conn.execute(
        f"""
        MATCH (uc:UseCase)-[:HAS_SESSION]->(s:Session)-[:HAS_RUN]->(r:Run)
        {owner_join}
        WHERE uc.id = $ucid {owner_where}
        RETURN s.id AS session_id, max(r.started_at) AS last_run
        ORDER BY last_run DESC
        LIMIT $limit
        """,
        params,
    ))
    return [row["session_id"] for row in rows if row.get("session_id")]


def get_feedback_for_sessions(
    conn: kuzu.Connection,
    session_ids: list[str],
    agent_id: str | None = None,
) -> list[dict[str, Any]]:
    """Return newest user feedback from the supplied sessions.

    When ``agent_id`` is supplied, only feedback explicitly targeted to that
    agent is returned. Older chat feedback that updated multiple agents in one
    rerun is excluded so downstream cascade updates do not pollute another
    agent's Learning History.
    Callers are responsible for passing an already owner-scoped session list.
    """
    clean_session_ids = [str(sid or "").strip() for sid in session_ids if str(sid or "").strip()]
    if not clean_session_ids:
        return []

    params: dict[str, Any] = {"session_ids": clean_session_ids}
    if (agent_id or "").strip():
        params["agent_id"] = str(agent_id).strip()
        return _rows(conn.execute(
            """
            MATCH (s:Session)-[:HAS_FEEDBACK]->(f:Feedback)-[:TARGETS_AGENT]->(target:Agent)
            OPTIONAL MATCH (f)-[:TRIGGERED_RERUN]->(rr:Run)-[:EXECUTED_AGENT]->(ar:AgentRun)-[:INSTANCE_OF]->(run_agent:Agent)
            WHERE s.id IN $session_ids AND target.id = $agent_id
            WITH f, s, target, count(DISTINCT run_agent.id) AS rerun_agent_count
            WHERE f.source <> 'chat' OR rerun_agent_count <= 1
            RETURN DISTINCT f.id          AS feedback_id,
                   s.id                   AS session_id,
                   target.id              AS agent_id,
                   f.feedback_type        AS feedback_type,
                   f.comment              AS comment,
                   f.source               AS source,
                   f.created_at           AS created_at
            ORDER BY created_at DESC
            """,
            params,
        ))

    return _rows(conn.execute(
        """
        MATCH (s:Session)-[:HAS_FEEDBACK]->(f:Feedback)
        OPTIONAL MATCH (f)-[:TARGETS_AGENT]->(target:Agent)
        WHERE s.id IN $session_ids
        RETURN DISTINCT f.id          AS feedback_id,
               s.id                   AS session_id,
               target.id              AS agent_id,
               f.feedback_type        AS feedback_type,
               f.comment              AS comment,
               f.source               AS source,
               f.created_at           AS created_at
        ORDER BY created_at DESC
        """,
        params,
    ))


def get_run_history_for_archetype(
    conn: kuzu.Connection, archetype_name: str, limit: int = 200,
    owner_username: str | None = None,
) -> list[dict[str, Any]]:
    """Return the run history for every session under a given archetype.

    One row per session (most-recent first) with the role, session status, the
    *final* quality score (the latest :class:`QualityAssessment` recorded for the
    session – i.e. after all feedback / refinement runs), and the start time.

    When ``owner_username`` is provided, results are row-level scoped to the
    sessions that user initiated (via the ``INITIATED`` edge). Pass ``None`` to
    return every session (e.g. for an admin view).
    """
    rows = _rows(conn.execute(
        """
        MATCH (s:Session)-[:HAS_ARCHETYPE]->(a:Archetype)
        WHERE a.name = $arch
        OPTIONAL MATCH (uc:UseCase)-[:HAS_SESSION]->(s)
        OPTIONAL MATCH (s)-[:HAS_RUN]->(:Run)-[:HAS_QUALITY]->(q:QualityAssessment)
        OPTIONAL MATCH (role:Role)-[:HAS_USECASE]->(uc)
        OPTIONAL MATCH (owner:User)-[:INITIATED]->(s)
        RETURN s.id          AS session_id,
               s.status       AS status,
               s.started_at    AS started_at,
               uc.id          AS usecase_id,
               uc.name        AS usecase_name,
               q.score        AS quality_score,
               q.created_at    AS quality_created_at,
               role.name       AS role,
               owner.username  AS owner_username
        """,
        {"arch": archetype_name},
    ))

    # Aggregate per session in Python: pick the role (first non-empty) and the
    # quality score from the most-recently created QualityAssessment.
    by_session: dict[str, dict[str, Any]] = {}
    for row in rows:
        sid = row.get("session_id")
        if not sid:
            continue
        entry = by_session.get(sid)
        if entry is None:
            entry = {
                "session_id": sid,
                "status": row.get("status") or "",
                "started_at": row.get("started_at"),
                "usecase_id": str(row.get("usecase_id") or "").strip(),
                "usecase_name": str(row.get("usecase_name") or "").strip(),
                "role": "",
                "owner_username": "",
                "quality_score": None,
                "_quality_created_at": None,
            }
            by_session[sid] = entry

        role_name = str(row.get("role") or "").strip()
        if role_name and not entry["role"]:
            entry["role"] = role_name

        owner_name = str(row.get("owner_username") or "").strip()
        if owner_name and not entry["owner_username"]:
            entry["owner_username"] = owner_name

        score = row.get("quality_score")
        created = row.get("quality_created_at")
        if score is not None:
            prev_created = entry["_quality_created_at"]
            if prev_created is None or (created is not None and created > prev_created):
                entry["quality_score"] = score
                entry["_quality_created_at"] = created

    # Row-level scoping: keep only the requesting user's own sessions when an
    # owner filter is supplied (admins pass None to see everything).
    owner_filter = (owner_username or "").strip()

    out: list[dict[str, Any]] = []
    for entry in by_session.values():
        if owner_filter and entry.get("owner_username") != owner_filter:
            continue
        started = entry.pop("started_at", None)
        entry.pop("_quality_created_at", None)
        entry.pop("owner_username", None)
        score = entry.get("quality_score")
        out.append({
            "session_id": entry["session_id"],
            "role": entry["role"],
            "usecase_id": entry["usecase_id"],
            "usecase_name": entry["usecase_name"],
            "status": entry["status"],
            "quality_score": float(score) if score is not None else None,
            "started_at": _to_iso_str(started),
            "_sort_key": started,
        })

    out.sort(
        key=lambda r: (r["_sort_key"] is not None, r["_sort_key"]),
        reverse=True,
    )
    for r in out:
        r.pop("_sort_key", None)
    return out[: max(0, int(limit))]


def get_session_meta(conn: kuzu.Connection, session_id: str) -> dict[str, Any] | None:
    """Return high-level metadata for a single session, or None if missing.

    Includes the owner username, use case, archetype, status, start time and the
    *final* quality score (latest :class:`QualityAssessment` for the session).
    """
    base = _rows(conn.execute(
        """
        MATCH (s:Session)
        WHERE s.id = $sid
        OPTIONAL MATCH (u:User)-[:INITIATED]->(s)
        OPTIONAL MATCH (uc:UseCase)-[:HAS_SESSION]->(s)
        OPTIONAL MATCH (s)-[:HAS_ARCHETYPE]->(a:Archetype)
        OPTIONAL MATCH (role:Role)-[:HAS_USECASE]->(uc)
        RETURN s.id          AS session_id,
               s.status       AS status,
               s.started_at    AS started_at,
               u.username      AS owner_username,
               uc.id          AS usecase_id,
               uc.name        AS usecase_name,
               a.name         AS archetype,
               role.name       AS role
        LIMIT 1
        """,
        {"sid": session_id},
    ))
    if not base:
        return None
    row = base[0]

    # Final quality = the most recently created QualityAssessment for the session.
    quality = _rows(conn.execute(
        """
        MATCH (s:Session)-[:HAS_RUN]->(:Run)-[:HAS_QUALITY]->(q:QualityAssessment)
        WHERE s.id = $sid
        RETURN q.score AS score, q.created_at AS created_at
        ORDER BY created_at DESC
        LIMIT 1
        """,
        {"sid": session_id},
    ))
    quality_score = None
    if quality and quality[0].get("score") is not None:
        try:
            quality_score = float(quality[0]["score"])
        except (TypeError, ValueError):
            quality_score = None

    return {
        "session_id": row.get("session_id"),
        "status": str(row.get("status") or "").strip(),
        "started_at": _to_iso_str(row.get("started_at")),
        "owner_username": str(row.get("owner_username") or "").strip(),
        "usecase_id": str(row.get("usecase_id") or "").strip(),
        "usecase_name": str(row.get("usecase_name") or "").strip(),
        "archetype": str(row.get("archetype") or "").strip(),
        "role": str(row.get("role") or "").strip(),
        "quality_score": quality_score,
    }


def list_trace_sessions(
    conn: kuzu.Connection,
    *,
    limit: int = 200,
) -> list[dict[str, Any]]:
    """Return recent workflow sessions for traceability views.

    This is intentionally admin-oriented and not owner-scoped. The API layer is
    responsible for enforcing authorization.
    """
    rows = _rows(conn.execute(
        """
        MATCH (s:Session)
        OPTIONAL MATCH (u:User)-[:INITIATED]->(s)
        OPTIONAL MATCH (uc:UseCase)-[:HAS_SESSION]->(s)
        RETURN DISTINCT s.id AS session_id,
               s.started_at AS started_at,
               u.username AS owner_username,
               uc.id AS usecase_id,
               uc.name AS usecase_name
        ORDER BY started_at DESC
        LIMIT $limit
        """,
        {"limit": max(1, int(limit))},
    ))

    items: list[dict[str, Any]] = []
    for row in rows:
        items.append({
            "session_id": str(row.get("session_id") or "").strip(),
            "owner_username": str(row.get("owner_username") or "").strip(),
            "usecase_id": str(row.get("usecase_id") or "").strip(),
            "usecase_name": str(row.get("usecase_name") or "").strip(),
            "timestamp": _to_iso_str(row.get("started_at")),
        })
    return [item for item in items if item.get("session_id")]


def get_artifacts_affected_by_issues(
    conn: kuzu.Connection, iteration_id: str
) -> list[dict[str, Any]]:
    """Artifacts affected by issues in a particular run."""
    cypher = """
        MATCH (r:Run)-[:HAS_ISSUE]->(i:Issue)-[:AFFECTS]->(art:Artifact)
        WHERE r.id = $rid
        RETURN i.id          AS issue_id,
               i.issue_type  AS issue_type,
               i.severity    AS severity,
               art.id        AS artifact_id,
               art.name      AS artifact_name,
               art.artifact_type AS artifact_type
    """
    return _rows(conn.execute(cypher, {"rid": iteration_id}))


# ═══════════════════════════════════════════════════════════════════════════
#  4.  QUALITY ANALYTICS
# ═══════════════════════════════════════════════════════════════════════════

def get_avg_score_by_usecase(
    conn: kuzu.Connection,
) -> list[dict[str, Any]]:
    """Average quality score grouped by use case."""
    cypher = """
        MATCH (uc:UseCase)-[:HAS_SESSION]->(s:Session)-[:HAS_RUN]->(r:Run)
              -[:HAS_QUALITY]->(q:QualityAssessment)
        RETURN uc.id   AS usecase_id,
               uc.name AS usecase_name,
               avg(q.score)     AS avg_score,
               count(q)         AS assessment_count
        ORDER BY avg_score DESC
    """
    return _rows(conn.execute(cypher))


def get_quality_trend_across_reruns(
    conn: kuzu.Connection, session_id: str
) -> list[dict[str, Any]]:
    """Quality scores ordered by run_number within a session (rerun trend)."""
    cypher = """
        MATCH (s:Session)-[:HAS_RUN]->(r:Run)-[:HAS_QUALITY]->(q:QualityAssessment)
        WHERE s.id = $sid
        RETURN r.run_number AS iteration_number,
               r.trigger    AS trigger,
               q.score      AS score,
               q.max_score  AS max_score,
               q.summary    AS summary
        ORDER BY r.run_number
    """
    return _rows(conn.execute(cypher, {"sid": session_id}))


def get_session_run_timeline(
    conn: kuzu.Connection, session_id: str
) -> list[dict[str, Any]]:
    """All runs of a session ordered by run_number, including runs that have no
    quality assessment yet.

    Unlike :func:`get_quality_trend_across_reruns` (which only returns scored
    runs), this returns the full timeline so callers can reason about earlier
    runs even when a score was never recorded for them. When a run has multiple
    quality assessments, the most recently created one is used.
    """
    rows = _rows(conn.execute(
        """
        MATCH (s:Session)-[:HAS_RUN]->(r:Run)
        WHERE s.id = $sid
        OPTIONAL MATCH (r)-[:HAS_QUALITY]->(q:QualityAssessment)
        RETURN r.run_number AS run_number,
               r.trigger    AS trigger,
               r.status     AS status,
               r.started_at AS started_at,
               q.score      AS score,
               q.max_score  AS max_score,
               q.created_at AS quality_created_at
        """,
        {"sid": session_id},
    ))

    # Aggregate per run_number, keeping the most recent quality assessment.
    by_run: dict[Any, dict[str, Any]] = {}
    for row in rows:
        run_number = row.get("run_number")
        entry = by_run.get(run_number)
        if entry is None:
            entry = {
                "run_number": run_number,
                "trigger": str(row.get("trigger") or "").strip(),
                "status": str(row.get("status") or "").strip(),
                "started_at": _to_iso_str(row.get("started_at")),
                "score": None,
                "max_score": None,
                "_quality_created_at": None,
            }
            by_run[run_number] = entry
        score = row.get("score")
        if score is not None:
            created = row.get("quality_created_at")
            if entry["_quality_created_at"] is None or (
                created is not None and created > entry["_quality_created_at"]
            ):
                try:
                    entry["score"] = float(score)
                except (TypeError, ValueError):
                    entry["score"] = None
                entry["max_score"] = row.get("max_score")
                entry["_quality_created_at"] = created

    timeline = sorted(
        by_run.values(),
        key=lambda e: (e["run_number"] is None, e["run_number"]),
    )
    for entry in timeline:
        entry.pop("_quality_created_at", None)
    return timeline


def get_feedback_with_score_improvement(
    conn: kuzu.Connection, session_id: str
) -> list[dict[str, Any]]:
    """Feedback that triggered a rerun, paired with score delta."""
    cypher = """
        MATCH (s:Session)-[:HAS_FEEDBACK]->(f:Feedback)-[:TRIGGERED_RERUN]->(new_run:Run)
              -[:HAS_QUALITY]->(new_q:QualityAssessment),
              (new_run)-[:PREVIOUS_RUN]->(old_run:Run)
              -[:HAS_QUALITY]->(old_q:QualityAssessment)
        WHERE s.id = $sid
         RETURN f.id            AS feedback_id,
             f.comment       AS feedback_comment,
             old_run.run_number AS previous_iteration,
             old_q.score     AS old_score,
             new_run.run_number AS new_iteration,
             new_q.score     AS new_score,
               (new_q.score - old_q.score) AS score_delta
        ORDER BY score_delta DESC
    """
    return _rows(conn.execute(cypher, {"sid": session_id}))


def get_recent_feedback_for_agent(
    conn: kuzu.Connection,
    username: str,
    usecase_id: str,
    agent_id: str,
    exclude_session_id: str | None = None,
    limit: int = 5,
) -> list[dict[str, Any]]:
    """Return the last *limit* feedback comments a user gave for a specific agent.

    Two-level lookup:
      1. Feedback scoped to the same use case (most relevant).
      2. Fallback: feedback from any use case (handles first-time-on-this-usecase).

    The current session is excluded via *exclude_session_id* so that an agent
    cannot read feedback it has not yet produced.

    Returns ``[]`` on any error — this must never break the workflow.
    """
    try:
        exclude_clause = (
            f"AND s.id <> $exclude_sid" if exclude_session_id else ""
        )
        params: dict[str, Any] = {
            "uname": username,
            "aid": agent_id,
            "lim": limit,
        }
        if exclude_session_id:
            params["exclude_sid"] = exclude_session_id

        # Level 1: same user + same use case + same agent
        level1 = f"""
            MATCH (u:User)-[:INITIATED]->(s:Session)<-[:HAS_SESSION]-(uc:UseCase),
                  (s)-[:HAS_FEEDBACK]->(f:Feedback)-[:TARGETS_AGENT]->(a:Agent)
            WHERE u.username = $uname
              AND uc.id = $ucid
              AND a.id = $aid
              {exclude_clause}
              AND f.comment IS NOT NULL AND f.comment <> ''
            RETURN f.comment    AS comment,
                   f.created_at AS created_at,
                   s.id         AS session_id
            ORDER BY f.created_at DESC
            LIMIT $lim
        """
        params_l1 = {**params, "ucid": usecase_id}
        rows = _rows(conn.execute(level1, params_l1))
        if rows:
            return rows

        # Level 2 fallback: same user + same agent, any use case
        level2 = f"""
            MATCH (u:User)-[:INITIATED]->(s:Session),
                  (s)-[:HAS_FEEDBACK]->(f:Feedback)-[:TARGETS_AGENT]->(a:Agent)
            WHERE u.username = $uname
              AND a.id = $aid
              {exclude_clause}
              AND f.comment IS NOT NULL AND f.comment <> ''
            RETURN f.comment    AS comment,
                   f.created_at AS created_at,
                   s.id         AS session_id
            ORDER BY f.created_at DESC
            LIMIT $lim
        """
        return _rows(conn.execute(level2, params))
    except Exception:
        return []


def get_recent_feedback_for_agent_history(
    conn: kuzu.Connection,
    usecase_id: str,
    agent_id: str,
    limit: int = 5,
    owner_username: str | None = None,
) -> list[dict[str, Any]]:
    """Return recent feedback comments linked to a specific agent.

    This is use-case scoped, but the returned feedback is filtered to the
    agent itself so later refinements can use the agent's own history instead
    of a global use-case-wide summary. When ``owner_username`` is provided the
    feedback is further restricted to the requesting user's own sessions so
    refinement prompts never carry another user's feedback.
    """
    try:
        owner = (owner_username or "").strip()
        owner_join = "MATCH (owner:User)-[:INITIATED]->(s)" if owner else ""
        owner_where = "AND owner.username = $owner" if owner else ""
        params: dict[str, Any] = {"ucid": usecase_id, "aid": agent_id, "lim": limit}
        if owner:
            params["owner"] = owner
        cypher = f"""
            MATCH (uc:UseCase)-[:HAS_SESSION]->(s:Session)-[:HAS_FEEDBACK]->(f:Feedback)
                  -[:TARGETS_AGENT]->(a:Agent)
            {owner_join}
            WHERE uc.id = $ucid
              AND a.id = $aid
              AND f.comment IS NOT NULL AND f.comment <> '' {owner_where}
            RETURN f.comment    AS comment,
                   f.created_at AS created_at,
                   s.id         AS session_id
            ORDER BY f.created_at DESC
            LIMIT $lim
        """
        return _rows(conn.execute(cypher, params))
    except Exception:
        return []


def get_recent_issues_for_agent_history(
    conn: kuzu.Connection,
    usecase_id: str,
    agent_id: str,
    limit: int = 5,
    owner_username: str | None = None,
) -> list[dict[str, Any]]:
    """Return recent issues linked to runs that executed a specific agent.

    When ``owner_username`` is provided, only issues from the requesting user's
    own sessions are returned so recurrence history stays isolated per user.
    """
    try:
        owner = (owner_username or "").strip()
        owner_join = "MATCH (owner:User)-[:INITIATED]->(s)" if owner else ""
        owner_where = "AND owner.username = $owner" if owner else ""
        params: dict[str, Any] = {"ucid": usecase_id, "aid": agent_id, "lim": limit}
        if owner:
            params["owner"] = owner
        cypher = f"""
            MATCH (uc:UseCase)-[:HAS_SESSION]->(s:Session)-[:HAS_RUN]->(r:Run)
                  -[:EXECUTED_AGENT]->(ar:AgentRun)-[:INSTANCE_OF]->(a:Agent)
            {owner_join}
            WHERE uc.id = $ucid
              AND a.id = $aid {owner_where}
            OPTIONAL MATCH (r)-[:HAS_ISSUE]->(i1:Issue)
            OPTIONAL MATCH (ar)-[:HAS_ISSUE]->(i2:Issue)
            WITH coalesce(i1, i2) AS issue, r.started_at AS created_at
            WHERE issue IS NOT NULL
            RETURN DISTINCT issue.issue_type AS issue_type,
                   issue.severity   AS severity,
                   issue.description AS description,
                   created_at       AS created_at
            ORDER BY created_at DESC
            LIMIT $lim
        """
        return _rows(conn.execute(cypher, params))
    except Exception:
        return []


# ═══════════════════════════════════════════════════════════════════════════
#  5.  OPERATIONAL TRACING
# ═══════════════════════════════════════════════════════════════════════════

def get_planner_for_run(
    conn: kuzu.Connection, iteration_id: str
) -> list[dict[str, Any]]:
    """Which planner created the given run."""
    cypher = """
        MATCH (r:Run)-[:USES_PLANNER]->(p:Planner)
        WHERE r.id = $rid
        RETURN p.*
    """
    return _rows(conn.execute(cypher, {"rid": iteration_id}))


def get_tools_used_by_agent(
    conn: kuzu.Connection, agent_id: str
) -> list[dict[str, Any]]:
    """Blueprint-level tool assignments for an agent."""
    cypher = """
        MATCH (a:Agent)-[:USES_TOOL]->(t:Tool)
        WHERE a.id = $aid
        RETURN t.*
    """
    return _rows(conn.execute(cypher, {"aid": agent_id}))


def get_tools_used_at_runtime(
    conn: kuzu.Connection, agent_run_id: str
) -> list[dict[str, Any]]:
    """Runtime tool usage for a specific agent run."""
    cypher = """
        MATCH (ar:AgentRun)-[u:USED_TOOL]->(t:Tool)
        WHERE ar.id = $arid
        RETURN t.id               AS tool_id,
               t.name             AS tool_name,
               u.invocation_count AS invocation_count,
               u.duration_ms      AS duration_ms
    """
    return _rows(conn.execute(cypher, {"arid": agent_run_id}))


def get_prompt_version_for_agent(
    conn: kuzu.Connection, agent_id: str
) -> list[dict[str, Any]]:
    """Which prompt version(s) an agent blueprint is wired to."""
    cypher = """
        MATCH (a:Agent)-[:USES_PROMPT]->(pv:PromptVersion)
        WHERE a.id = $aid
        RETURN pv.*
        ORDER BY pv.created_at DESC
    """
    return _rows(conn.execute(cypher, {"aid": agent_id}))


def get_artifacts_generated_by_agent_run(
    conn: kuzu.Connection, agent_run_id: str
) -> list[dict[str, Any]]:
    """Artifacts produced by a specific agent run."""
    cypher = """
        MATCH (ar:AgentRun)-[g:GENERATED]->(art:Artifact)
        WHERE ar.id = $arid
        RETURN art.*,
               g.generated_at AS generated_at
    """
    return _rows(conn.execute(cypher, {"arid": agent_run_id}))


def get_input_artifacts_for_agent_run(
    conn: kuzu.Connection, agent_run_id: str
) -> list[dict[str, Any]]:
    """Input artifacts consumed by a specific agent run."""
    cypher = """
        MATCH (ar:AgentRun)-[u:USED_INPUT]->(art:Artifact)
        WHERE ar.id = $arid
        RETURN art.*,
               u.consumed_at AS consumed_at
    """
    return _rows(conn.execute(cypher, {"arid": agent_run_id}))


# ═══════════════════════════════════════════════════════════════════════════
#  6.  STAGE VISIBILITY & EXECUTION
# ═══════════════════════════════════════════════════════════════════════════

def get_stage_visibility_per_run(
    conn: kuzu.Connection, iteration_id: str
) -> list[dict[str, Any]]:
    """All stage executions for a run with their status and steps."""
    cypher = """
        MATCH (r:Run)-[:HAS_STAGE_EXEC]->(se:StageExecution)-[:FOR_STAGE]->(ws:WorkflowStage)
        WHERE r.id = $rid
        OPTIONAL MATCH (se)-[:FOR_SUBSTAGE]->(ss:SubStage)
        RETURN ws.name       AS stage,
               ws.stage_order AS stage_order,
               ss.name       AS substage,
               se.id         AS stage_exec_id,
               se.status     AS status,
               se.started_at AS started_at,
               se.ended_at   AS ended_at,
               se.duration_ms AS duration_ms
        ORDER BY ws.stage_order
    """
    return _rows(conn.execute(cypher, {"rid": iteration_id}))


def get_stage_visibility_per_session(
    conn: kuzu.Connection, session_id: str
) -> list[dict[str, Any]]:
    """All stage executions across all runs in a session."""
    cypher = """
        MATCH (s:Session)-[:HAS_RUN]->(r:Run)-[:HAS_STAGE_EXEC]->(se:StageExecution)
              -[:FOR_STAGE]->(ws:WorkflowStage)
        WHERE s.id = $sid
        OPTIONAL MATCH (se)-[:FOR_SUBSTAGE]->(ss:SubStage)
        RETURN r.run_number  AS iteration_number,
               ws.name       AS stage,
               ws.stage_order AS stage_order,
               ss.name       AS substage,
               se.status     AS status,
               se.duration_ms AS duration_ms
        ORDER BY r.run_number, ws.stage_order
    """
    return _rows(conn.execute(cypher, {"sid": session_id}))


def get_failed_stage_root_cause(
    conn: kuzu.Connection, iteration_id: str
) -> list[dict[str, Any]]:
    """Find where a run failed: stage/substage/step + issue + affected artifacts."""
    cypher = """
        MATCH (r:Run)-[:HAS_STAGE_EXEC]->(se:StageExecution)-[:FOR_STAGE]->(ws:WorkflowStage)
        WHERE r.id = $rid AND se.status = 'failed'
        OPTIONAL MATCH (se)-[:FOR_SUBSTAGE]->(ss:SubStage)
        OPTIONAL MATCH (se)-[:HAS_STEP]->(step:StepExecution)
        WHERE step.status = 'failed'
        OPTIONAL MATCH (step)-[:STEP_ISSUE]->(i:Issue)
        OPTIONAL MATCH (i)-[:AFFECTS]->(art:Artifact)
        OPTIONAL MATCH (step)-[:STEP_AGENT_RUN]->(ar:AgentRun)
        RETURN ws.name          AS stage,
               ss.name          AS substage,
               step.step_name   AS step_name,
               step.error_message AS error_message,
               step.prompt_ref  AS prompt_ref,
               step.tool_ref    AS tool_ref,
               step.artifact_ref AS artifact_ref,
               i.id             AS issue_id,
               i.issue_type     AS issue_type,
               i.severity       AS severity,
               i.description    AS issue_description,
               art.id           AS affected_artifact_id,
               art.name         AS affected_artifact_name,
               ar.id            AS agent_run_id,
               ar.error_message AS agent_error
        ORDER BY ws.stage_order, step.step_order
    """
    return _rows(conn.execute(cypher, {"rid": iteration_id}))


def get_rerun_lineage_from_feedback(
    conn: kuzu.Connection, session_id: str
) -> list[dict[str, Any]]:
    """Trace feedback -> rerun chain with quality deltas."""
    cypher = """
        MATCH (s:Session)-[:HAS_FEEDBACK]->(f:Feedback)-[:TRIGGERED_RERUN]->(new_run:Run)
        WHERE s.id = $sid
        OPTIONAL MATCH (f)-[:REFERS_TO_RUN]->(old_run:Run)
        OPTIONAL MATCH (new_run)-[:HAS_QUALITY]->(nq:QualityAssessment)
        OPTIONAL MATCH (old_run)-[:HAS_QUALITY]->(oq:QualityAssessment)
        RETURN f.id                AS feedback_id,
               f.feedback_type     AS feedback_type,
               f.comment           AS comment,
               old_run.run_number  AS previous_iteration,
               oq.score            AS previous_score,
               new_run.run_number  AS new_iteration,
               nq.score            AS new_score
        ORDER BY new_run.run_number
    """
    return _rows(conn.execute(cypher, {"sid": session_id}))


def get_full_run_details_by_session(
    conn: kuzu.Connection,
    session_id: str,
) -> dict[str, Any]:
    """Session-first wrapper around run details using the latest run."""
    iteration_id = _latest_run_id_for_session(conn, session_id)
    if not iteration_id:
        return {
            "run": None,
            "planner": None,
            "agent_runs": [],
            "issues": [],
            "quality": [],
            "feedback": [],
        }
    return get_full_run_details(conn, iteration_id)


def get_artifacts_affected_by_issues_by_session(
    conn: kuzu.Connection,
    session_id: str,
) -> list[dict[str, Any]]:
    """Session-first wrapper for run issue artifacts using the latest run."""
    iteration_id = _latest_run_id_for_session(conn, session_id)
    if not iteration_id:
        return []
    return get_artifacts_affected_by_issues(conn, iteration_id)


def get_stage_visibility_for_latest_run(
    conn: kuzu.Connection,
    session_id: str,
) -> list[dict[str, Any]]:
    """Session-first wrapper for stage visibility using the latest run."""
    iteration_id = _latest_run_id_for_session(conn, session_id)
    if not iteration_id:
        return []
    return get_stage_visibility_per_run(conn, iteration_id)


def get_failed_stage_root_cause_by_session(
    conn: kuzu.Connection,
    session_id: str,
) -> list[dict[str, Any]]:
    """Session-first wrapper for failed stage root cause using the latest run."""
    iteration_id = _latest_run_id_for_session(conn, session_id)
    if not iteration_id:
        return []
    return get_failed_stage_root_cause(conn, iteration_id)


def get_quality_trend_across_stages_by_session(
    conn: kuzu.Connection,
    session_id: str,
) -> list[dict[str, Any]]:
    """Session-first wrapper for stage-level quality trend using the latest run."""
    iteration_id = _latest_run_id_for_session(conn, session_id)
    if not iteration_id:
        return []
    return get_quality_trend_across_stages(conn, iteration_id)


def get_run_lineage_by_session(
    conn: kuzu.Connection,
    session_id: str,
) -> list[dict[str, Any]]:
    """Session-first wrapper for run lineage using the latest run."""
    iteration_id = _latest_run_id_for_session(conn, session_id)
    if not iteration_id:
        return []
    rows = get_run_lineage(conn, iteration_id)
    for row in rows:
        row.pop("iteration_id", None)
    return rows


def get_top_failing_agents_by_usecase(
    conn: kuzu.Connection, usecase_id: str, limit: int = 10
) -> list[dict[str, Any]]:
    """Top failing agents + issue frequency for a use case."""
    cypher = """
        MATCH (uc:UseCase)-[:HAS_SESSION]->(s:Session)-[:HAS_RUN]->(r:Run)
              -[:EXECUTED_AGENT]->(ar:AgentRun)-[:INSTANCE_OF]->(a:Agent)
        WHERE uc.id = $ucid AND ar.status = 'failed'
        OPTIONAL MATCH (ar)-[:HAS_ISSUE]->(i:Issue)
        RETURN a.name          AS agent_name,
               a.id            AS agent_id,
               count(DISTINCT ar) AS failure_count,
               count(DISTINCT i)  AS issue_count
        ORDER BY failure_count DESC
        LIMIT $limit
    """
    return _rows(conn.execute(cypher, {"ucid": usecase_id, "limit": limit}))


def get_quality_trend_across_stages(
    conn: kuzu.Connection, iteration_id: str
) -> list[dict[str, Any]]:
    """Quality scores per stage within a single run."""
    cypher = """
        MATCH (r:Run)-[:HAS_STAGE_EXEC]->(se:StageExecution)-[:FOR_STAGE]->(ws:WorkflowStage)
        WHERE r.id = $rid
        OPTIONAL MATCH (se)-[:HAS_STEP]->(step:StepExecution)-[:STEP_QUALITY]->(q:QualityAssessment)
        RETURN ws.name          AS stage,
               ws.stage_order   AS stage_order,
               se.status        AS stage_status,
               avg(q.score)     AS avg_score,
               count(q)         AS assessment_count
        ORDER BY ws.stage_order
    """
    return _rows(conn.execute(cypher, {"rid": iteration_id}))


def get_steps_for_stage_execution(
    conn: kuzu.Connection, stage_exec_id: str
) -> list[dict[str, Any]]:
    """All steps within a stage execution with linked evidence."""
    cypher = """
        MATCH (se:StageExecution)-[:HAS_STEP]->(step:StepExecution)
        WHERE se.id = $seid
        OPTIONAL MATCH (step)-[:STEP_AGENT_RUN]->(ar:AgentRun)-[:INSTANCE_OF]->(a:Agent)
        OPTIONAL MATCH (step)-[:STEP_USED_TOOL]->(t:Tool)
        OPTIONAL MATCH (step)-[:STEP_USED_PROMPT]->(pv:PromptVersion)
        OPTIONAL MATCH (step)-[:STEP_ARTIFACT]->(art:Artifact)
        OPTIONAL MATCH (step)-[:STEP_ISSUE]->(i:Issue)
        OPTIONAL MATCH (step)-[:STEP_QUALITY]->(q:QualityAssessment)
        RETURN step.id           AS step_id,
               step.step_name    AS step_name,
               step.step_order   AS step_order,
               step.status       AS status,
               step.duration_ms  AS duration_ms,
               step.error_message AS error_message,
               a.name            AS agent_name,
               ar.id             AS agent_run_id,
               t.name            AS tool_name,
               pv.version        AS prompt_version,
               art.id            AS artifact_id,
               art.name          AS artifact_name,
               i.id              AS issue_id,
               i.issue_type      AS issue_type,
               q.score           AS quality_score
        ORDER BY step.step_order
    """
    return _rows(conn.execute(cypher, {"seid": stage_exec_id}))


# ═══════════════════════════════════════════════════════════════════════════
#  7.  SESSION OUTPUT CONTRACT
# ═══════════════════════════════════════════════════════════════════════════

def get_session_output(
    conn: kuzu.Connection, session_id: str
) -> dict[str, Any]:
    """Build the full session output contract for UI visualization.

    Returns a simplified JSON contract with session, timestamp,
    agents, and feedback.
    """
    # Session
    sess = _rows(conn.execute("""
        MATCH (s:Session)
        WHERE s.id = $sid
        OPTIONAL MATCH (uc:UseCase)-[:HAS_SESSION]->(s)
        OPTIONAL MATCH (u:User)-[:INITIATED]->(s)
        RETURN s.id         AS session_id,
               uc.id        AS usecase_id,
               u.id         AS user_id,
               s.status     AS status,
               s.started_at AS created_ts
    """, {"sid": session_id}))

    session_data = sess[0] if sess else {
        "session_id": session_id, "usecase_id": "", "user_id": "",
        "status": "UNKNOWN", "created_ts": ""
    }
    session_data["created_ts"] = _to_iso_str(session_data.get("created_ts"))

    hierarchy = _rows(conn.execute("""
        MATCH (s:Session)
        WHERE s.id = $sid
        OPTIONAL MATCH (s)-[:HAS_ARCHETYPE]->(a:Archetype)
        OPTIONAL MATCH (uc:UseCase)-[:HAS_SESSION]->(s)
        OPTIONAL MATCH (role:Role)-[:HAS_USECASE]->(uc)
        RETURN a.name AS archetype,
               role.name AS role,
               uc.id AS usecase_id
        LIMIT 1
    """, {"sid": session_id}))
    hierarchy_data = hierarchy[0] if hierarchy else {"archetype": "", "role": "", "usecase_id": session_data.get("usecase_id", "")}

    # Feedback base rows
    fbs = _rows(conn.execute("""
        MATCH (s:Session)-[:HAS_FEEDBACK]->(f:Feedback)
        WHERE s.id = $sid
        RETURN f.id            AS feedback_id,
               f.feedback_type AS type,
               f.comment       AS ref,
               f.created_at    AS created_at
        ORDER BY f.created_at
    """, {"sid": session_id}))

    # For each feedback, find the output generated in the rerun it triggered.
    # If feedback targets an agent, prefer that agent's output from rerun run.
    fb_output_rows = _rows(conn.execute("""
        MATCH (s:Session)-[:HAS_FEEDBACK]->(f:Feedback)
        WHERE s.id = $sid
        OPTIONAL MATCH (f)-[:TARGETS_AGENT]->(ta:Agent)
        OPTIONAL MATCH (f)-[:TRIGGERED_RERUN]->(rr:Run)-[:EXECUTED_AGENT]->(ar:AgentRun)-[:INSTANCE_OF]->(a:Agent)
        OPTIONAL MATCH (ar)-[:GENERATED]->(art:Artifact)
        RETURN f.id             AS feedback_id,
               ta.id            AS target_agent_id,
               a.id             AS run_agent_id,
               rr.run_number    AS run_number,
               art.content_ref  AS output_ref
        ORDER BY rr.run_number, a.id
    """, {"sid": session_id}))

    feedback_output_by_id: dict[str, str] = {}
    feedback_rerun_runs: set[int] = set()
    for row in fb_output_rows:
        fid = str(row.get("feedback_id") or "").strip()
        if not fid:
            continue

        run_number = int(row.get("run_number") or 0)
        if run_number > 0:
            feedback_rerun_runs.add(run_number)

        out_ref = str(row.get("output_ref") or "").strip()
        if not out_ref:
            continue

        target_aid = str(row.get("target_agent_id") or "").strip()
        run_aid = str(row.get("run_agent_id") or "").strip()
        if target_aid and run_aid and target_aid != run_aid:
            continue

        # Keep the first valid output ref for each feedback id.
        if fid not in feedback_output_by_id:
            feedback_output_by_id[fid] = out_ref

    all_feedback = [
        {
            "feedback_id": f["feedback_id"],
            "type": f["type"],
            "ref": f.get("ref"),
            "output_generated": feedback_output_by_id.get(str(f.get("feedback_id") or "").strip()),
        }
        for f in fbs
    ]

    # Agent details with output / feedback / output-after-feedback mapping.
    # For each agent we keep first output as baseline and latest output as post-feedback (if changed).
    agent_rows = _rows(conn.execute("""
        MATCH (s:Session)-[:HAS_RUN]->(r:Run)-[:EXECUTED_AGENT]->(ar:AgentRun)-[:INSTANCE_OF]->(a:Agent)
        WHERE s.id = $sid
        OPTIONAL MATCH (ar)-[:GENERATED]->(art:Artifact)
        RETURN a.id AS agent_id,
               a.name AS agent_name,
               a.agent_type AS agent_type,
               r.run_number AS run_number,
               r.started_at AS run_started_at,
               art.content_ref AS output_ref
        ORDER BY a.id, r.run_number
    """, {"sid": session_id}))

    feedback_rows = _rows(conn.execute("""
        MATCH (s:Session)-[:HAS_FEEDBACK]->(f:Feedback)
        WHERE s.id = $sid
        OPTIONAL MATCH (f)-[:TARGETS_AGENT]->(a:Agent)
        RETURN f.id AS feedback_id,
               a.id AS agent_id,
               f.comment AS comment,
               f.created_at AS created_at
        ORDER BY f.created_at
    """, {"sid": session_id}))

    feedback_by_agent: dict[str, list[str]] = {}
    latest_feedback_id_by_agent: dict[str, str] = {}
    for fr in feedback_rows:
        aid = str(fr.get("agent_id") or "").strip()
        if not aid:
            continue
        fid = str(fr.get("feedback_id") or "").strip()
        if fid:
            latest_feedback_id_by_agent[aid] = fid
        comment = str(fr.get("comment") or "").strip()
        if not comment:
            continue
        feedback_by_agent.setdefault(aid, []).append(comment)

    agents_map: dict[str, dict[str, Any]] = {}
    for row in agent_rows:
        aid = str(row.get("agent_id") or "").strip()
        if not aid:
            continue

        if aid not in agents_map:
            agents_map[aid] = {
                "agent_id": aid,
                "agent_name": str(row.get("agent_name") or "").strip() or aid,
                "role": str(hierarchy_data.get("role") or "").strip(),
                "agent_type": str(row.get("agent_type") or "").strip(),
                "timestamp": _to_iso_str(row.get("run_started_at")) or session_data.get("created_ts", ""),
                "output_generated": None,
                "feedback_id": None,
                "feedback": None,
                "outputs_after_feedback": [],   # all post-feedback outputs, ordered by run
                "_base_run": None,              # run_number of the first (base) run
                "_latest_run": -1,
            }

        output_ref = str(row.get("output_ref") or "").strip() or None
        run_number = int(row.get("run_number") or 0)

        if output_ref:
            if agents_map[aid]["output_generated"] is None:
                # First output seen — this is the baseline
                agents_map[aid]["output_generated"] = output_ref
                agents_map[aid]["_base_run"] = run_number
            else:
                # Subsequent run — include only feedback-triggered rerun outputs
                existing_refs = [e["output_ref"] for e in agents_map[aid]["outputs_after_feedback"]]
                if run_number in feedback_rerun_runs and output_ref not in existing_refs:
                    agents_map[aid]["outputs_after_feedback"].append({"output_ref": output_ref, "run_number": run_number})

        if run_number >= int(agents_map[aid].get("_latest_run") or -1):
            agents_map[aid]["_latest_run"] = run_number
            agents_map[aid]["timestamp"] = _to_iso_str(row.get("run_started_at")) or agents_map[aid]["timestamp"]

    agents: list[dict[str, Any]] = []
    for aid, agent_info in agents_map.items():
        fb_items = feedback_by_agent.get(aid, [])
        fid = latest_feedback_id_by_agent.get(aid)
        if fid:
            agent_info["feedback_id"] = fid
        if fb_items:
            agent_info["feedback"] = " | ".join(fb_items)
        agent_info.pop("_latest_run", None)
        agent_info.pop("_base_run", None)

        # Attach overall_score from disk if available
        try:
            from daan.flow.session_service import read_agent_score
            from pathlib import Path
            score_data = read_agent_score(session_id, aid)
            agent_info["overall_score"] = score_data.get("overall_score") if score_data else None
            # Enrich each feedback rerun output with its own overall_score
            enriched: list[dict[str, Any]] = []
            for fb_out in agent_info.get("outputs_after_feedback", []):
                out_ref = fb_out.get("output_ref", "")
                run_num = fb_out.get("run_number")
                fb_score: float | None = None
                try:
                    seq_str = Path(out_ref).parent.name  # e.g. "001"
                    fb_seq = int(seq_str)
                    fb_score_data = read_agent_score(session_id, aid, feedback_seq=fb_seq)
                    fb_score = fb_score_data.get("overall_score") if fb_score_data else None
                except Exception:
                    pass
                enriched.append({"output_ref": out_ref, "overall_score": fb_score})
            agent_info["outputs_after_feedback"] = enriched
        except Exception:
            agent_info["overall_score"] = None
            agent_info["outputs_after_feedback"] = [
                {"output_ref": e.get("output_ref"), "overall_score": None}
                for e in agent_info.get("outputs_after_feedback", [])
            ]

        agents.append(agent_info)

    return {
        "session": session_data,
        "agents": agents,
        "feedback": all_feedback,
    }


def prune_old_runs_for_user(
    conn: kuzu.Connection,
    user_id: str,
    keep_last: int = 10,
) -> dict[str, int]:
    """Keep only the latest runs for a user and prune older runtime data."""
    keep_last = max(1, int(keep_last))

    old_runs = _rows(conn.execute(
        """
        MATCH (u:User)-[:INITIATED]->(:Session)-[:HAS_RUN]->(r:Run)
        WHERE u.id = $uid OR u.username = $uid
        RETURN r.id AS iteration_id
        ORDER BY r.started_at DESC, r.run_number DESC
        SKIP $keep_last
        """,
        {"uid": user_id, "keep_last": keep_last},
    ))

    deleted_runs = 0
    for row in old_runs:
        iteration_id = row["iteration_id"]

        conn.execute(
            """
            MATCH (f:Feedback)-[:REFERS_TO_RUN|TRIGGERED_RERUN]->(r:Run)
            WHERE r.id = $rid
            DETACH DELETE f
            """,
            {"rid": iteration_id},
        )
        conn.execute(
            """
            MATCH (r:Run)-[:HAS_STAGE_EXEC]->(se:StageExecution)
            WHERE r.id = $rid
            OPTIONAL MATCH (se)-[:HAS_STEP]->(step:StepExecution)
            DETACH DELETE step, se
            """,
            {"rid": iteration_id},
        )
        conn.execute(
            """
            MATCH (r:Run)-[:EXECUTED_AGENT]->(ar:AgentRun)
            WHERE r.id = $rid
            OPTIONAL MATCH (ar)-[:GENERATED|USED_INPUT]->(art:Artifact)
            OPTIONAL MATCH (ar)-[:HAS_ISSUE]->(ari:Issue)
            OPTIONAL MATCH (ar)-[:HAS_QUALITY]->(arq:QualityAssessment)
            DETACH DELETE art, ari, arq, ar
            """,
            {"rid": iteration_id},
        )
        conn.execute(
            """
            MATCH (r:Run)-[:HAS_ISSUE]->(i:Issue)
            WHERE r.id = $rid
            DETACH DELETE i
            """,
            {"rid": iteration_id},
        )
        conn.execute(
            """
            MATCH (r:Run)-[:HAS_QUALITY]->(q:QualityAssessment)
            WHERE r.id = $rid
            DETACH DELETE q
            """,
            {"rid": iteration_id},
        )
        conn.execute("MATCH (r:Run) WHERE r.id = $rid DETACH DELETE r", {"rid": iteration_id})
        deleted_runs += 1

    return {"deleted_runs": deleted_runs, "kept_runs": keep_last}
