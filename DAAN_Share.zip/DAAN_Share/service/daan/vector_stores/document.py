"""Shared RAG document model for vector operations."""

from pydantic import BaseModel, Field


class RagDocument(BaseModel):
    """Document payload used in indexing and retrieval."""

    id: str
    content: str
    metadata: dict = Field(default_factory=dict)
    source: str | None = None
    chunk_index: int = 0
    embedding: list[float] | None = None
