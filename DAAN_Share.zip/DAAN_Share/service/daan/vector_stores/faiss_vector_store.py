"""FAISS vector store implementation with optional in-memory fallback."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .base_vector_store import BaseVectorStore
from ..document import RagDocument
from .in_memory_vector_store import InMemoryVectorStore


class FAISSVectorStore(BaseVectorStore):
    """FAISS-backed vector store with simple metadata tracking and disk persistence."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self._docs: dict[str, RagDocument] = {}
        self._doc_order: list[str] = []
        self._index = None
        self._faiss = None
        self._fallback_store: InMemoryVectorStore | None = None
        
        # Persistence settings
        self.persist_dir = config.get("persist_dir", ".faiss_store")
        self._ensure_persist_dir()

        allow_fallback = bool(config.get("allow_fallback_in_memory", True))
        try:
            import faiss  # pylint: disable=import-outside-toplevel

            self._faiss = faiss
        except ImportError as exc:
            if not allow_fallback:
                raise ImportError("faiss-cpu package is required for FAISSVectorStore") from exc
            self._fallback_store = InMemoryVectorStore(config={})
        
        # Load persisted data if available
        self._load_from_disk()

    def _ensure_persist_dir(self) -> None:
        """Create persistence directory if it doesn't exist."""
        Path(self.persist_dir).mkdir(parents=True, exist_ok=True)

    def _load_from_disk(self) -> None:
        """Load FAISS index and metadata from disk if available."""
        if self._fallback_store is not None:
            return
        
        index_path = Path(self.persist_dir) / "index.faiss"
        docs_path = Path(self.persist_dir) / "docs.json"
        order_path = Path(self.persist_dir) / "doc_order.json"
        
        if index_path.exists() and docs_path.exists() and order_path.exists():
            try:
                self._index = self._faiss.read_index(str(index_path))
                
                with open(docs_path, "r", encoding="utf-8") as f:
                    docs_data = json.load(f)
                    self._docs = {
                        doc_id: RagDocument(
                            id=doc["id"],
                            content=doc["content"],
                            source=doc.get("source", ""),
                            embedding=doc.get("embedding"),
                            metadata=doc.get("metadata", {}),
                        )
                        for doc_id, doc in docs_data.items()
                    }
                
                with open(order_path, "r", encoding="utf-8") as f:
                    self._doc_order = json.load(f)
                
                import logging
                logger = logging.getLogger(__name__)
                logger.info(f"FAISS: Loaded {len(self._docs)} docs from disk")
            except Exception as exc:
                import logging
                logger = logging.getLogger(__name__)
                logger.warning(f"FAISS: Failed to load from disk: {exc}. Starting fresh.")

    def _save_to_disk(self) -> None:
        """Save FAISS index and metadata to disk."""
        if self._fallback_store is not None or self._index is None:
            return
        
        try:
            index_path = Path(self.persist_dir) / "index.faiss"
            docs_path = Path(self.persist_dir) / "docs.json"
            order_path = Path(self.persist_dir) / "doc_order.json"
            
            # Save index
            self._faiss.write_index(self._index, str(index_path))
            
            # Save docs metadata
            docs_data = {}
            for doc_id, doc in self._docs.items():
                docs_data[doc_id] = {
                    "id": doc.id,
                    "content": doc.content,
                    "source": doc.source,
                    "embedding": doc.embedding,
                    "metadata": doc.metadata or {},
                }
            
            with open(docs_path, "w", encoding="utf-8") as f:
                json.dump(docs_data, f, indent=2)
            
            # Save doc order
            with open(order_path, "w", encoding="utf-8") as f:
                json.dump(self._doc_order, f)
            
            import logging
            logger = logging.getLogger(__name__)
            logger.info(f"FAISS: Saved {len(self._docs)} docs to disk")
        except Exception as exc:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"FAISS: Failed to save to disk: {exc}")


    def add_documents(self, docs: list[RagDocument]) -> None:
        if self._fallback_store is not None:
            self._fallback_store.add_documents(docs)
            return

        docs_with_embeddings = 0
        docs_skipped = 0
        for doc in docs:
            if not doc.embedding:
                docs_skipped += 1
                continue
            self._docs[doc.id] = doc
            if doc.id not in self._doc_order:
                self._doc_order.append(doc.id)
            docs_with_embeddings += 1
        
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"FAISS: Added {docs_with_embeddings} docs with embeddings (skipped {docs_skipped} without)")
        logger.info(f"FAISS: Total docs in store: {len(self._docs)}")
        
        self._rebuild_index()
        self._save_to_disk()

    def similarity_search(self, query_embedding: list[float], k: int) -> list[RagDocument]:
        if self._fallback_store is not None:
            return self._fallback_store.similarity_search(query_embedding, k)
        if self._index is None or not self._doc_order:
            import logging
            logger = logging.getLogger(__name__)
            logger.warning(f"FAISS: No index or docs. Index exists: {self._index is not None}, Docs count: {len(self._doc_order)}")
            return []

        query = [float(value) for value in query_embedding]
        if not query:
            return []

        faiss = self._faiss
        import numpy as np  # pylint: disable=import-outside-toplevel
        import logging
        logger = logging.getLogger(__name__)

        query_array = np.array([query], dtype="float32")
        faiss.normalize_L2(query_array)

        top_k = min(k, len(self._doc_order))
        _, idx = self._index.search(query_array, top_k)
        results: list[RagDocument] = []
        for raw_idx in idx[0]:
            if raw_idx < 0:
                continue
            doc_id = self._doc_order[int(raw_idx)]
            doc = self._docs.get(doc_id)
            if doc is not None:
                results.append(doc)
        
        logger.info(f"FAISS: Searched {len(self._doc_order)} docs, returned {len(results)} results")
        return results

    def hybrid_search(self, query: str, query_embedding: list[float], k: int) -> list[RagDocument]:
        if self._fallback_store is not None:
            return self._fallback_store.hybrid_search(query, query_embedding, k)

        base = self.similarity_search(query_embedding, max(k * 3, k))
        query_terms = [term.lower() for term in query.split() if term.strip()]
        rescored: list[tuple[float, RagDocument]] = []
        for rank, doc in enumerate(base):
            lexical_hits = sum(1 for term in query_terms if term in doc.content.lower())
            vector_bonus = 1.0 / (rank + 1)
            rescored.append((lexical_hits + vector_bonus, doc))
        rescored.sort(key=lambda item: item[0], reverse=True)
        return [doc for _, doc in rescored[:k]]

    def delete(self, doc_id: str) -> None:
        if self._fallback_store is not None:
            self._fallback_store.delete(doc_id)
            return

        self._docs.pop(doc_id, None)
        self._doc_order = [existing for existing in self._doc_order if existing != doc_id]
        self._rebuild_index()
        self._save_to_disk()

    def upsert(self, doc: RagDocument) -> None:
        if self._fallback_store is not None:
            self._fallback_store.upsert(doc)
            return

        self._docs[doc.id] = doc
        if doc.id not in self._doc_order:
            self._doc_order.append(doc.id)
        self._rebuild_index()
        self._save_to_disk()

    def _rebuild_index(self) -> None:
        if self._fallback_store is not None:
            return
        if not self._doc_order:
            self._index = None
            return

        import numpy as np  # pylint: disable=import-outside-toplevel

        vectors: list[list[float]] = []
        filtered_order: list[str] = []
        target_dim = None
        for doc_id in self._doc_order:
            doc = self._docs.get(doc_id)
            if doc is None or not doc.embedding:
                continue
            vector = [float(value) for value in doc.embedding]
            if target_dim is None:
                target_dim = len(vector)
            if len(vector) != target_dim:
                continue
            vectors.append(vector)
            filtered_order.append(doc_id)

        if not vectors:
            self._index = None
            self._doc_order = []
            return

        dim = len(vectors[0])
        self._doc_order = filtered_order
        matrix = np.array(vectors, dtype="float32")
        self._faiss.normalize_L2(matrix)
        self._index = self._faiss.IndexFlatIP(dim)
        self._index.add(matrix)
