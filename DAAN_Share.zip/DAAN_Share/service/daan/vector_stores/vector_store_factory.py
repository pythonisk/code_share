"""Factory for creating vector stores dynamically."""

import importlib
from typing import Any

from .providers.base_vector_store import BaseVectorStore


class VectorStoreFactory:
    """Create vector stores using a registry and importlib."""

    VECTOR_STORE_MAP = {
        "chroma": {
            "module": "daan.vector_stores.providers.chroma_vector_store",
            "class": "ChromaVectorStore",
        },
        "postgres": {
            "module": "daan.vector_stores.providers.postgres_vector_store",
            "class": "PostgresVectorStore",
        },
        "pgvector": {
            "module": "daan.vector_stores.providers.postgres_vector_store",
            "class": "PostgresVectorStore",
        },
        "faiss": {
            "module": "daan.vector_stores.providers.faiss_vector_store",
            "class": "FAISSVectorStore",
        },
        "in_memory": {
            "module": "daan.vector_stores.providers.in_memory_vector_store",
            "class": "InMemoryVectorStore",
        },
    }

    @classmethod
    def create_store(cls, store_name: str, config: dict[str, Any]) -> BaseVectorStore:
        """Create and return a vector store instance."""
        if store_name not in cls.VECTOR_STORE_MAP:
            available = ", ".join(cls.VECTOR_STORE_MAP.keys())
            raise ValueError(f"Unsupported vector store '{store_name}'. Available: {available}")

        store_info = cls.VECTOR_STORE_MAP[store_name]

        try:
            module = importlib.import_module(store_info["module"])
            store_class = getattr(module, store_info["class"])
            return store_class(config)
        except ImportError as exc:
            raise ImportError(f"Failed to import vector store module {store_info['module']}: {exc}") from exc
        except AttributeError as exc:
            raise AttributeError(
                f"Vector store class {store_info['class']} not found in {store_info['module']}: {exc}"
            ) from exc

    @classmethod
    def get_available_stores(cls) -> list[str]:
        """List available vector stores."""
        return list(cls.VECTOR_STORE_MAP.keys())
