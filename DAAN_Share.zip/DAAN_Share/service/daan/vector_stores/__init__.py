"""Vector store abstractions and implementations."""
