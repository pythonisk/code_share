"""In-memory vector store implementation for tests and local development."""

from __future__ import annotations

import math
from typing import Any

from .base_vector_store import BaseVectorStore
from ..document import RagDocument


class InMemoryVectorStore(BaseVectorStore):
    """Simple dictionary-backed vector store."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self._docs: dict[str, RagDocument] = {}

    def add_documents(self, docs: list[RagDocument]) -> None:
        for doc in docs:
            self._docs[doc.id] = doc

    def similarity_search(
        self,
        query_embedding: list[float],
        k: int,
        where: dict | None = None,
    ) -> list[RagDocument]:
        scored: list[tuple[float, RagDocument]] = []
        for doc in self._docs.values():
            if not doc.embedding:
                continue
            if where:
                metadata = doc.metadata or {}
                matched = True
                for key, cond in where.items():
                    value = metadata.get(key)
                    if isinstance(cond, dict):
                        if "$eq" in cond and value != cond["$eq"]:
                            matched = False
                            break
                    elif value != cond:
                        matched = False
                        break
                if not matched:
                    continue
            scored.append((self._cosine_similarity(query_embedding, doc.embedding), doc))

        scored.sort(key=lambda item: item[0], reverse=True)
        return [doc for _, doc in scored[:k]]

    def hybrid_search(
        self,
        query: str,
        query_embedding: list[float],
        k: int,
        where: dict | None = None,
    ) -> list[RagDocument]:
        # Minimal hybrid baseline: vector rank + keyword presence in content.
        base_results = self.similarity_search(query_embedding, max(k * 3, k), where=where)
        query_terms = [term.lower() for term in query.split() if term.strip()]

        scored: list[tuple[float, RagDocument]] = []
        for index, doc in enumerate(base_results):
            lexical_hits = sum(1 for term in query_terms if term in doc.content.lower())
            vector_bonus = 1.0 / (index + 1)
            score = lexical_hits + vector_bonus
            scored.append((score, doc))

        scored.sort(key=lambda item: item[0], reverse=True)
        return [doc for _, doc in scored[:k]]

    def delete(self, doc_id: str) -> None:
        self._docs.pop(doc_id, None)

    def upsert(self, doc: RagDocument) -> None:
        self._docs[doc.id] = doc

    @staticmethod
    def _cosine_similarity(vector_a: list[float], vector_b: list[float]) -> float:
        if len(vector_a) != len(vector_b) or not vector_a:
            return 0.0

        dot = sum(a * b for a, b in zip(vector_a, vector_b))
        norm_a = math.sqrt(sum(a * a for a in vector_a))
        norm_b = math.sqrt(sum(b * b for b in vector_b))
        if norm_a == 0.0 or norm_b == 0.0:
            return 0.0
        return dot / (norm_a * norm_b)
