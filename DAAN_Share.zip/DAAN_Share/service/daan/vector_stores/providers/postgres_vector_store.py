"""PostgreSQL vector store implementation backed by pgvector."""

from __future__ import annotations

import re
import time
from threading import Lock
from typing import Any

from pgvector.psycopg import register_vector
from pgvector.sqlalchemy import VECTOR
from sqlalchemy import Column, Integer, MetaData, String, Table, Text, create_engine, event, inspect, select, text
from sqlalchemy.dialects.postgresql import JSONB, insert as pg_insert

from daan.core.config import get_settings

from .base_vector_store import BaseVectorStore
from ..document import RagDocument


def _tokenize(text_value: str) -> list[str]:
    return re.findall(r"[a-z0-9][a-z0-9_\-./]*", (text_value or "").lower())


class PostgresVectorStore(BaseVectorStore):
    """Vector store implementation backed by PostgreSQL and pgvector."""

    _cache_lock = Lock()
    _engine_cache: dict[str, Any] = {}
    _schema_ready: set[tuple[str, str]] = set()
    _table_ready: set[tuple[str, str, str]] = set()
    _stats_cache: dict[tuple[str, str], tuple[float, dict[str, dict[str, Any]]]] = {}
    _stats_cache_ttl_seconds = 60.0

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        settings = get_settings()
        database_url = (
            config.get("database_url")
            or config.get("url")
            or config.get("connection_string")
            or settings.get_vector_database_url()
        )
        if not str(database_url).startswith("postgresql"):
            raise ValueError("PostgresVectorStore requires a PostgreSQL database URL")

        self.embedding_dimension = int(config.get("embedding_dimension", 0) or 0)
        if self.embedding_dimension <= 0:
            raise ValueError("PostgresVectorStore requires vector_store_config.embedding_dimension")

        self.schema = str(config.get("schema") or "public").strip() or "public"
        self.table_name = str(config.get("table_name") or "rag_documents").strip() or "rag_documents"

        self._engine_key = str(database_url).strip()
        self._engine = self._get_or_create_engine(self._engine_key)

        self._metadata = MetaData(schema=self.schema)
        self._documents = Table(
            self.table_name,
            self._metadata,
            Column("id", String(255), primary_key=True),
            Column("content", Text, nullable=False),
            Column("metadata", JSONB, nullable=False, server_default=text("'{}'::jsonb")),
            Column("source", String(1024), nullable=True),
            Column("chunk_index", Integer, nullable=False, server_default=text("0")),
            Column("embedding", VECTOR(self.embedding_dimension), nullable=False),
            extend_existing=True,
        )

        schema_key = (self._engine_key, self.schema)
        table_key = (self._engine_key, self.schema, self.table_name)
        with self._cache_lock:
            ensure_schema = schema_key not in self._schema_ready
            ensure_table = table_key not in self._table_ready

        if ensure_schema:
            self._ensure_extension()
            with self._cache_lock:
                self._schema_ready.add(schema_key)

        if ensure_table:
            self._metadata.create_all(self._engine, tables=[self._documents])
            self._ensure_indexes()
            with self._cache_lock:
                self._table_ready.add(table_key)

    @classmethod
    def _get_or_create_engine(cls, database_url: str):
        with cls._cache_lock:
            engine = cls._engine_cache.get(database_url)
            if engine is None:
                engine = create_engine(database_url, future=True, pool_pre_ping=True)
                event.listen(engine, "connect", cls._register_vector_types)
                cls._engine_cache[database_url] = engine
            return engine

    @classmethod
    def clear_caches(cls) -> None:
        with cls._cache_lock:
            cls._stats_cache.clear()

    @staticmethod
    def _register_vector_types(dbapi_connection: Any, connection_record: Any) -> None:
        register_vector(dbapi_connection)

    def _ensure_extension(self) -> None:
        try:
            with self._engine.begin() as connection:
                connection.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{self.schema}"'))
                connection.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        except Exception as exc:
            raise RuntimeError(
                "PostgreSQL pgvector extension is not available or cannot be created "
                f"for schema '{self.schema}': {exc}"
            ) from exc

    def _ensure_indexes(self) -> None:
        safe_table = re.sub(r"[^a-zA-Z0-9_]+", "_", self.table_name).strip("_") or "rag_documents"
        embedding_index = f"{safe_table}_embedding_hnsw_idx"
        metadata_index = f"{safe_table}_metadata_gin_idx"
        search_index = f"{safe_table}_search_idx"
        with self._engine.begin() as connection:
            connection.execute(
                text(
                    f'CREATE INDEX IF NOT EXISTS "{embedding_index}" '
                    f'ON "{self.schema}"."{self.table_name}" USING hnsw (embedding vector_cosine_ops)'
                )
            )
            connection.execute(
                text(
                    f'CREATE INDEX IF NOT EXISTS "{metadata_index}" '
                    f'ON "{self.schema}"."{self.table_name}" USING gin (metadata)'
                )
            )
            # Generated tsvector column backs hybrid_search's FTS branch; PostgreSQL
            # keeps it in sync automatically on every insert/upsert, no app code needed.
            connection.execute(
                text(
                    f'ALTER TABLE "{self.schema}"."{self.table_name}" '
                    f"ADD COLUMN IF NOT EXISTS search_text tsvector "
                    f"GENERATED ALWAYS AS (to_tsvector('english', content)) STORED"
                )
            )
            connection.execute(
                text(
                    f'CREATE INDEX IF NOT EXISTS "{search_index}" '
                    f'ON "{self.schema}"."{self.table_name}" USING gin (search_text)'
                )
            )

    def _where_clause(self, where: dict | None = None):
        clause = None
        for key, cond in (where or {}).items():
            expected = cond.get("$eq") if isinstance(cond, dict) else cond
            expr = self._documents.c["metadata"][key].as_string() == str(expected)
            clause = expr if clause is None else clause & expr
        return clause

    def _invalidate_stats_cache(self) -> None:
        cache_key = (self._engine_key, self.schema)
        with self._cache_lock:
            self._stats_cache.pop(cache_key, None)

    @staticmethod
    def _quote_identifier(value: str) -> str:
        return '"' + str(value).replace('"', '""') + '"'

    @staticmethod
    def _basename(source: str) -> str:
        normalized = str(source or "").replace("\\", "/").rstrip("/")
        return normalized.rsplit("/", 1)[-1]

    @classmethod
    def _clone_stats(cls, stats: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
        return {
            str(kb_id): {
                "chunks": int((payload or {}).get("chunks", 0) or 0),
                "documents": list((payload or {}).get("documents", []) or []),
            }
            for kb_id, payload in (stats or {}).items()
        }

    def _row_to_document(self, row: Any) -> RagDocument:
        metadata = row["metadata"] or {}
        raw_chunk_index = metadata.get("chunk_index", row["chunk_index"] if "chunk_index" in row else 0)
        try:
            chunk_index = int(raw_chunk_index)
        except (TypeError, ValueError):
            chunk_index = 0

        embedding = row["embedding"]
        # Raw text() queries return pgvector's native Vector type, not a plain
        # list; RagDocument requires a list, so normalize it here.
        if embedding is not None and not isinstance(embedding, list):
            to_list = getattr(embedding, "to_list", None)
            embedding = to_list() if callable(to_list) else list(embedding)

        return RagDocument(
            id=row["id"],
            content=row["content"] or "",
            metadata=metadata,
            source=row["source"] or metadata.get("source"),
            chunk_index=chunk_index,
            embedding=embedding,
        )

    def _serialize_doc(self, doc: RagDocument) -> dict[str, Any]:
        if not doc.embedding:
            raise ValueError(f"Document '{doc.id}' is missing an embedding")
        return {
            "id": doc.id,
            "content": doc.content,
            "metadata": doc.metadata or {},
            "source": doc.source or (doc.metadata or {}).get("source"),
            "chunk_index": int(doc.chunk_index or 0),
            "embedding": [float(value) for value in doc.embedding],
        }

    def _upsert_rows(self, rows: list[dict[str, Any]]) -> None:
        if not rows:
            return

        stmt = pg_insert(self._documents).values(rows)
        excluded = stmt.excluded
        stmt = stmt.on_conflict_do_update(
            index_elements=[self._documents.c.id],
            set_={
                "content": excluded.content,
                "metadata": excluded.metadata,
                "source": excluded.source,
                "chunk_index": excluded.chunk_index,
                "embedding": excluded.embedding,
            },
        )
        with self._engine.begin() as connection:
            connection.execute(stmt)
        self._invalidate_stats_cache()

    def list_knowledge_base_stats(self) -> dict[str, dict]:
        """Return chunk counts and document names grouped by session_id across the schema."""
        cache_key = (self._engine_key, self.schema)
        with self._cache_lock:
            cached = self._stats_cache.get(cache_key)
        if cached and (time.monotonic() - cached[0]) < self._stats_cache_ttl_seconds:
            return self._clone_stats(cached[1])

        stats: dict[str, dict[str, Any]] = {}
        inspector = inspect(self._engine)
        table_names = inspector.get_table_names(schema=self.schema)
        quoted_schema = self._quote_identifier(self.schema)

        with self._engine.begin() as connection:
            for table_name in table_names:
                # Concept-embedding tables (<collection>_concepts) hold ontology
                # entity vectors for GraphRAG entity search, not user documents;
                # they must not appear as knowledge bases in the stats listing.
                if table_name.endswith("_concepts"):
                    continue
                quoted_table = self._quote_identifier(table_name)
                stmt = text(
                    f'''
                    SELECT
                        COALESCE(metadata->>'session_id', :table_name) AS kb_id,
                        COUNT(*)::bigint AS chunks,
                        ARRAY_REMOVE(ARRAY_AGG(DISTINCT COALESCE(source, metadata->>'source', '')), '') AS sources,
                        ARRAY_REMOVE(ARRAY_AGG(DISTINCT COALESCE(metadata->>'title', '')), '') AS titles,
                        ARRAY_REMOVE(ARRAY_AGG(DISTINCT COALESCE(metadata->>'source_type', '')), '') AS source_types
                    FROM {quoted_schema}.{quoted_table}
                    GROUP BY COALESCE(metadata->>'session_id', :table_name)
                    '''
                )
                rows = connection.execute(stmt, {"table_name": table_name}).mappings().all()

                for row in rows:
                    kb_id = str(row.get("kb_id") or table_name)
                    chunk_count = int(row.get("chunks") or 0)
                    source_types = {
                        str(source_type)
                        for source_type in (row.get("source_types") or [])
                        if str(source_type).strip()
                    }
                    sources = [
                        str(source)
                        for source in (row.get("sources") or [])
                        if str(source).strip()
                    ]
                    titles = [
                        str(title)
                        for title in (row.get("titles") or [])
                        if str(title).strip()
                    ]

                    documents: list[str] = []
                    if any(source.startswith("db:") for source in sources) or source_types.intersection(
                        {"usecase", "agent", "prompt"}
                    ):
                        documents.append("Use cases (database)")

                    for source in sources:
                        if source.startswith("db:"):
                            continue
                        name = self._basename(source)
                        if name and name not in documents:
                            documents.append(name)

                    for title in titles:
                        if title and title not in documents:
                            documents.append(title)

                    current = stats.setdefault(kb_id, {"chunks": 0, "documents": []})
                    current["chunks"] += chunk_count
                    for name in documents:
                        if name not in current["documents"]:
                            current["documents"].append(name)

        for payload in stats.values():
            payload["documents"] = sorted(payload["documents"])

        cloned = self._clone_stats(stats)
        with self._cache_lock:
            self._stats_cache[cache_key] = (time.monotonic(), cloned)
        return self._clone_stats(cloned)

    def delete_by_session_id(self, kb_id: str) -> int:
        """Delete all vectors for a given session_id / knowledge base."""
        clause = self._where_clause({"session_id": kb_id})
        if clause is None:
            return 0

        stmt = self._documents.delete().where(clause)
        with self._engine.begin() as connection:
            result = connection.execute(stmt)
        self._invalidate_stats_cache()
        return int(getattr(result, "rowcount", 0) or 0)

    def purge_knowledge_base(self, kb_id: str, drop_tables: bool = False) -> dict[str, Any]:
        """Remove a KB's rows from both the document and companion concept tables.

        The concept table holds ontology embeddings under the same ``session_id``,
        so deleting only the document table leaves those rows orphaned.
        """
        concept_table = f"{self.table_name}_concepts"
        deleted = self.delete_by_session_id(kb_id)
        deleted += self._delete_session_rows(concept_table, kb_id)

        dropped: list[str] = []
        if drop_tables:
            for table_name in (self.table_name, concept_table):
                if self._drop_table(table_name):
                    dropped.append(table_name)

        self._invalidate_stats_cache()
        return {"deleted_rows": deleted, "dropped_tables": dropped}

    def _qualified(self, table_name: str) -> str:
        """Return a safely quoted schema-qualified identifier."""
        schema = str(self.schema).replace('"', '""')
        table = str(table_name).replace('"', '""')
        return f'"{schema}"."{table}"'

    def _table_exists(self, table_name: str) -> bool:
        stmt = text(
            "select 1 from information_schema.tables "
            "where table_schema = :schema and table_name = :table"
        )
        with self._engine.begin() as connection:
            row = connection.execute(stmt, {"schema": self.schema, "table": table_name}).first()
        return row is not None

    def _delete_session_rows(self, table_name: str, kb_id: str) -> int:
        if not self._table_exists(table_name):
            return 0
        stmt = text(f"delete from {self._qualified(table_name)} where metadata->>'session_id' = :kb_id")
        with self._engine.begin() as connection:
            result = connection.execute(stmt, {"kb_id": kb_id})
        return int(getattr(result, "rowcount", 0) or 0)

    def _drop_table(self, table_name: str) -> bool:
        if not self._table_exists(table_name):
            return False
        with self._engine.begin() as connection:
            connection.execute(text(f"drop table if exists {self._qualified(table_name)}"))
        # Clear the DDL cache so a KB recreated with this name rebuilds its indexes.
        with self._cache_lock:
            self._table_ready.discard((self._engine_key, self.schema, table_name))
        return True
    
    def list_sources(self, source_type: str | None = None) -> set[str]:
        """Return distinct `source` values in this collection, for resumable ingestion."""
        stmt = select(self._documents.c.source).distinct()
        if source_type:
            stmt = stmt.where(self._documents.c.metadata["source_type"].astext == source_type)
        with self._engine.begin() as connection:
            rows = connection.execute(stmt).all()
        return {str(row[0]) for row in rows if row[0]}


    def add_documents(self, docs: list[RagDocument]) -> None:
        rows = []
        for doc in docs:
            if doc.embedding:
                rows.append(self._serialize_doc(doc))
        self._upsert_rows(rows)

    def similarity_search(
        self,
        query_embedding: list[float],
        k: int,
        where: dict | None = None,
    ) -> list[RagDocument]:
        if not query_embedding:
            return []

        stmt = select(self._documents)
        clause = self._where_clause(where)
        if clause is not None:
            stmt = stmt.where(clause)
        stmt = stmt.order_by(self._documents.c.embedding.cosine_distance(query_embedding)).limit(k)

        with self._engine.begin() as connection:
            rows = connection.execute(stmt).mappings().all()
        return [self._row_to_document(row) for row in rows]

    def hybrid_search(
        self,
        query: str,
        query_embedding: list[float],
        k: int,
        where: dict | None = None,
    ) -> list[RagDocument]:
        dense_docs = self.similarity_search(query_embedding, max(2 * k, k), where=where)
        sparse_docs = self._fts_search(query, max(2 * k, k), where=where)

        rrf_k = 60
        scores: dict[str, float] = {}
        merged: dict[str, RagDocument] = {}
        for ranked in (dense_docs, sparse_docs):
            for rank, doc in enumerate(ranked, start=1):
                merged[doc.id] = doc
                scores[doc.id] = scores.get(doc.id, 0.0) + 1.0 / (rrf_k + rank)

        ranked_ids = sorted(scores, key=scores.get, reverse=True)
        return [merged[doc_id] for doc_id in ranked_ids[:k]]

    def _fts_search(self, query: str, k: int, where: dict | None = None) -> list[RagDocument]:
        """Sparse keyword search via PostgreSQL FTS (search_text GIN index), not BM25.

        Terms are OR-joined (not plainto_tsquery's implicit AND) so partial keyword
        matches still surface and get ranked lower, matching BM25's original recall
        behavior instead of requiring every query word to be present.
        """
        query_tokens = _tokenize(query)
        if not query_tokens:
            return []
        tsquery_expr = " | ".join(query_tokens)

        quoted_schema = self._quote_identifier(self.schema)
        quoted_table = self._quote_identifier(self.table_name)
        params: dict[str, Any] = {"tsquery": tsquery_expr, "row_limit": int(k)}
        filters = ""
        for index, (key, cond) in enumerate((where or {}).items()):
            expected = cond.get("$eq") if isinstance(cond, dict) else cond
            pname = f"w{index}"
            filters += f" AND metadata->>'{key}' = :{pname}"
            params[pname] = str(expected)

        stmt = text(
            f"SELECT * FROM {quoted_schema}.{quoted_table} "
            f"WHERE search_text @@ to_tsquery('english', :tsquery)"
            f"{filters} "
            f"ORDER BY ts_rank(search_text, to_tsquery('english', :tsquery)) DESC "
            f"LIMIT :row_limit"
        )
        with self._engine.begin() as connection:
            rows = connection.execute(stmt, params).mappings().all()
        return [self._row_to_document(row) for row in rows]

    def delete(self, doc_id: str) -> None:
        stmt = self._documents.delete().where(self._documents.c.id == doc_id)
        with self._engine.begin() as connection:
            connection.execute(stmt)
        self._invalidate_stats_cache()

    def upsert(self, doc: RagDocument) -> None:
        self._upsert_rows([self._serialize_doc(doc)])

    def get_documents_by_ids(self, ids: list[str]) -> list[RagDocument]:
        clean_ids = [str(i) for i in (ids or []) if i]
        if not clean_ids:
            return []

        stmt = select(self._documents).where(self._documents.c.id.in_(clean_ids))
        with self._engine.begin() as connection:
            rows = connection.execute(stmt).mappings().all()

        by_id = {row["id"]: self._row_to_document(row) for row in rows}
        return [by_id[doc_id] for doc_id in clean_ids if doc_id in by_id]

    def fetch_by_concept_overlap(
        self,
        concept_ids: list[str],
        where: dict | None = None,
        limit: int = 50,
    ) -> list[RagDocument]:
        """Return chunks whose ``metadata['concept_ids']`` overlaps ``concept_ids``.

        Backs the GraphRAG entity -> text-unit mapping: given a set of ontology
        concept ids, pull the chunks that mention any of them. Uses the JSONB GIN
        index via ``jsonb_exists_any`` (the functional form of the ``?|`` operator).
        ``where`` accepts simple equality filters (e.g. ``{"session_id": kb_id}``).
        """
        ids = [str(c) for c in (concept_ids or []) if str(c).strip()]
        if not ids:
            return []

        quoted_schema = self._quote_identifier(self.schema)
        quoted_table = self._quote_identifier(self.table_name)
        params: dict[str, Any] = {"concept_ids": ids, "row_limit": int(limit)}
        filters = ""
        for index, (key, cond) in enumerate((where or {}).items()):
            expected = cond.get("$eq") if isinstance(cond, dict) else cond
            pname = f"w{index}"
            # Keys originate from internal call sites (not user input); quote the
            # value only via a bound parameter.
            filters += f" AND metadata->>'{key}' = :{pname}"
            params[pname] = str(expected)

        stmt = text(
            f"SELECT * FROM {quoted_schema}.{quoted_table} "
            f"WHERE jsonb_exists_any(metadata->'concept_ids', :concept_ids::text[])"
            f"{filters} LIMIT :row_limit"
        )
        with self._engine.begin() as connection:
            rows = connection.execute(stmt, params).mappings().all()
        return [self._row_to_document(row) for row in rows]

    def documents_containing(self, term: str, limit: int = 5) -> list[RagDocument]:
        if not term:
            return []

        stmt = select(self._documents).where(self._documents.c.content.ilike(f"%{term}%")).limit(limit)
        with self._engine.begin() as connection:
            rows = connection.execute(stmt).mappings().all()
        return [self._row_to_document(row) for row in rows]

    def iter_all_documents(self, batch_size: int = 500):
        """Yield every stored document in id order, paginated to bound memory.

        Used by offline maintenance jobs (e.g. ontology grounding backfill) that
        need to re-scan all chunk text without loading the whole table at once.
        """
        offset = 0
        while True:
            stmt = (
                select(self._documents)
                .order_by(self._documents.c.id)
                .limit(batch_size)
                .offset(offset)
            )
            with self._engine.begin() as connection:
                rows = connection.execute(stmt).mappings().all()
            if not rows:
                break
            for row in rows:
                yield self._row_to_document(row)
            if len(rows) < batch_size:
                break
            offset += batch_size

