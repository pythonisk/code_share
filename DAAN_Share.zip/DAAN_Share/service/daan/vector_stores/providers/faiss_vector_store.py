"""FAISS vector store implementation with optional in-memory fallback."""

from __future__ import annotations

from typing import Any

from .base_vector_store import BaseVectorStore
from ..document import RagDocument
from .in_memory_vector_store import InMemoryVectorStore


class FAISSVectorStore(BaseVectorStore):
    """FAISS-backed vector store with simple metadata tracking."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self._docs: dict[str, RagDocument] = {}
        self._doc_order: list[str] = []
        self._index = None
        self._faiss = None
        self._fallback_store: InMemoryVectorStore | None = None

        allow_fallback = bool(config.get("allow_fallback_in_memory", True))
        try:
            import faiss  # pylint: disable=import-outside-toplevel

            self._faiss = faiss
        except ImportError as exc:
            if not allow_fallback:
                raise ImportError("faiss-cpu package is required for FAISSVectorStore") from exc
            self._fallback_store = InMemoryVectorStore(config={})

    def add_documents(self, docs: list[RagDocument]) -> None:
        if self._fallback_store is not None:
            self._fallback_store.add_documents(docs)
            return

        for doc in docs:
            if not doc.embedding:
                continue
            self._docs[doc.id] = doc
            if doc.id not in self._doc_order:
                self._doc_order.append(doc.id)
        self._rebuild_index()

    def similarity_search(
        self,
        query_embedding: list[float],
        k: int,
        where: dict | None = None,
    ) -> list[RagDocument]:
        if self._fallback_store is not None:
            return self._fallback_store.similarity_search(query_embedding, k, where=where)
        if self._index is None or not self._doc_order:
            return []

        query = [float(value) for value in query_embedding]
        if not query:
            return []

        faiss = self._faiss
        import numpy as np  # pylint: disable=import-outside-toplevel

        query_array = np.array([query], dtype="float32")
        faiss.normalize_L2(query_array)

        top_k = min(k, len(self._doc_order))
        _, idx = self._index.search(query_array, top_k)
        results: list[RagDocument] = []
        for raw_idx in idx[0]:
            if raw_idx < 0:
                continue
            doc_id = self._doc_order[int(raw_idx)]
            doc = self._docs.get(doc_id)
            if doc is not None:
                results.append(doc)
        return results

    def hybrid_search(
        self,
        query: str,
        query_embedding: list[float],
        k: int,
        where: dict | None = None,
    ) -> list[RagDocument]:
        if self._fallback_store is not None:
            return self._fallback_store.hybrid_search(query, query_embedding, k, where=where)

        base = self.similarity_search(query_embedding, max(k * 3, k), where=where)
        query_terms = [term.lower() for term in query.split() if term.strip()]
        rescored: list[tuple[float, RagDocument]] = []
        for rank, doc in enumerate(base):
            lexical_hits = sum(1 for term in query_terms if term in doc.content.lower())
            vector_bonus = 1.0 / (rank + 1)
            rescored.append((lexical_hits + vector_bonus, doc))
        rescored.sort(key=lambda item: item[0], reverse=True)
        return [doc for _, doc in rescored[:k]]

    def delete(self, doc_id: str) -> None:
        if self._fallback_store is not None:
            self._fallback_store.delete(doc_id)
            return

        self._docs.pop(doc_id, None)
        self._doc_order = [existing for existing in self._doc_order if existing != doc_id]
        self._rebuild_index()

    def upsert(self, doc: RagDocument) -> None:
        if self._fallback_store is not None:
            self._fallback_store.upsert(doc)
            return

        self._docs[doc.id] = doc
        if doc.id not in self._doc_order:
            self._doc_order.append(doc.id)
        self._rebuild_index()

    def _rebuild_index(self) -> None:
        if self._fallback_store is not None:
            return
        if not self._doc_order:
            self._index = None
            return

        import numpy as np  # pylint: disable=import-outside-toplevel

        vectors: list[list[float]] = []
        filtered_order: list[str] = []
        target_dim = None
        for doc_id in self._doc_order:
            doc = self._docs.get(doc_id)
            if doc is None or not doc.embedding:
                continue
            vector = [float(value) for value in doc.embedding]
            if target_dim is None:
                target_dim = len(vector)
            if len(vector) != target_dim:
                continue
            vectors.append(vector)
            filtered_order.append(doc_id)

        if not vectors:
            self._index = None
            self._doc_order = []
            return

        dim = len(vectors[0])
        self._doc_order = filtered_order
        matrix = np.array(vectors, dtype="float32")
        self._faiss.normalize_L2(matrix)
        self._index = self._faiss.IndexFlatIP(dim)
        self._index.add(matrix)
