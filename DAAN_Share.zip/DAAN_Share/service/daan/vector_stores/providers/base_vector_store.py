"""Base interface for vector stores."""

from abc import ABC, abstractmethod

from ..document import RagDocument


class BaseVectorStore(ABC):
    """Contract for vector storage backends."""

    @abstractmethod
    def add_documents(self, docs: list[RagDocument]) -> None:
        """Insert documents into the store."""

    @abstractmethod
    def similarity_search(
        self,
        query_embedding: list[float],
        k: int,
        where: dict | None = None,
    ) -> list[RagDocument]:
        """Return top-k most similar documents for an embedding."""

    @abstractmethod
    def hybrid_search(
        self,
        query: str,
        query_embedding: list[float],
        k: int,
        where: dict | None = None,
    ) -> list[RagDocument]:
        """Return top-k documents using vector and lexical signals."""

    @abstractmethod
    def delete(self, doc_id: str) -> None:
        """Delete a document by id."""

    @abstractmethod
    def upsert(self, doc: RagDocument) -> None:
        """Insert or update a single document."""
