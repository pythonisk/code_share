"""Chroma vector store implementation."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .base_vector_store import BaseVectorStore
from ..document import RagDocument


def _tokenize(text: str) -> list[str]:
    """Lowercase word/identifier tokens (keeps hyphenated codes like ABC-123 intact)."""
    return re.findall(r"[a-z0-9][a-z0-9_\-./]*", (text or "").lower())


def _matches_where(metadata: dict | None, where: dict | None) -> bool:
    """Lightweight metadata match for the BM25 half (mirrors a simple chroma `where`).

    Supports flat equality ({"usecase_id": "UC_X"}) and {"$eq": value}. Used so the
    sparse results respect the same filter chroma applies to the dense results.
    """
    md = metadata or {}
    for key, cond in (where or {}).items():
        value = md.get(key)
        if isinstance(cond, dict):
            if "$eq" in cond and value != cond["$eq"]:
                return False
        elif value != cond:
            return False
    return True


class ChromaVectorStore(BaseVectorStore):
    """Vector store implementation backed by chromadb."""

    def __init__(self, config: dict[str, Any]) -> None:
        try:
            import chromadb  # pylint: disable=import-outside-toplevel
        except ImportError as exc:
            raise ImportError("chromadb package is required for ChromaVectorStore") from exc

        self.config = config
        persist_dir = config.get("persist_directory", ".chroma")
        collection_name = config.get("collection_name", "default")

        # Resolve a relative persist directory against the repo root (not the process
        # cwd), so the same store is used no matter where the server is started from.
        persist_path = Path(persist_dir)
        if not persist_path.is_absolute():
            repo_root = Path(__file__).resolve().parents[4]
            persist_path = repo_root / persist_dir

        client = chromadb.PersistentClient(path=str(persist_path))
        self._collection = client.get_or_create_collection(name=collection_name)

        # Lazily-built BM25 sparse index (over the same chunks) for hybrid search.
        self._bm25 = None
        self._bm25_ids: list[str] = []
        self._bm25_docs: list[RagDocument] = []

    def add_documents(self, docs: list[RagDocument]) -> None:
        if not docs:
            return

        ids = [doc.id for doc in docs]
        documents = [doc.content for doc in docs]
        metadatas = [doc.metadata for doc in docs]
        embeddings = [doc.embedding for doc in docs]

        self._collection.add(ids=ids, documents=documents, metadatas=metadatas, embeddings=embeddings)
        self._bm25 = None  # invalidate cached sparse index

    def similarity_search(
        self, query_embedding: list[float], k: int, where: dict | None = None
    ) -> list[RagDocument]:
        kwargs: dict[str, Any] = {"query_embeddings": [query_embedding], "n_results": k}
        if where:
            kwargs["where"] = where
        result = self._collection.query(**kwargs)
        return self._to_documents(result)

    def hybrid_search(
        self, query: str, query_embedding: list[float], k: int, where: dict | None = None
    ) -> list[RagDocument]:
        """Dense (embeddings) + sparse (BM25) hybrid, fused with Reciprocal Rank Fusion.

        Dense catches meaning (paraphrased questions); sparse/BM25 nails exact
        identifiers and keywords (record ids, domain codes). Both run over the same chunks.
        An optional `where` metadata filter scopes both halves (e.g. {"usecase_id": "UC_X"}).
        """
        dense_docs = self.similarity_search(query_embedding, max(2 * k, k), where=where)
        sparse_docs = self._bm25_search(query, max(2 * k, k), where=where)

        rrf_k = 60
        scores: dict[str, float] = {}
        merged: dict[str, RagDocument] = {}
        for ranked in (dense_docs, sparse_docs):
            for rank, doc in enumerate(ranked, start=1):
                merged[doc.id] = doc
                scores[doc.id] = scores.get(doc.id, 0.0) + 1.0 / (rrf_k + rank)

        ranked_ids = sorted(scores, key=scores.get, reverse=True)
        return [merged[doc_id] for doc_id in ranked_ids[:k]]

    def _bm25_search(self, query: str, k: int, where: dict | None = None) -> list[RagDocument]:
        """Rank chunks by BM25 keyword relevance (optionally filtered by metadata)."""
        self._ensure_bm25()
        if self._bm25 is None or not self._bm25_docs:
            return []
        query_tokens = _tokenize(query)
        if not query_tokens:
            return []
        scores = self._bm25.get_scores(query_tokens)
        ranked = sorted(zip(scores, self._bm25_docs), key=lambda item: item[0], reverse=True)
        out: list[RagDocument] = []
        for score, doc in ranked:
            if score <= 0:
                continue
            if where and not _matches_where(doc.metadata, where):
                continue
            out.append(doc)
            if len(out) >= k:
                break
        return out

    def _ensure_bm25(self) -> None:
        """Build the BM25 index from the current collection if not cached."""
        if self._bm25 is not None:
            return
        try:
            from rank_bm25 import BM25Okapi  # pylint: disable=import-outside-toplevel
        except ImportError:
            self._bm25 = None
            return

        payload = self._collection.get(include=["documents", "metadatas"])
        ids = payload.get("ids", []) or []
        documents = payload.get("documents", []) or []
        metadatas = payload.get("metadatas", []) or []
        if not ids:
            self._bm25 = None
            return

        corpus_tokens: list[list[str]] = []
        self._bm25_docs = []
        for index, doc_id in enumerate(ids):
            content = documents[index] if index < len(documents) else ""
            metadata = (metadatas[index] if index < len(metadatas) else {}) or {}
            corpus_tokens.append(_tokenize(content))
            self._bm25_docs.append(
                RagDocument(
                    id=doc_id,
                    content=content,
                    metadata=metadata,
                    source=metadata.get("source"),
                    chunk_index=int(metadata.get("chunk_index", 0) or 0),
                )
            )
        self._bm25 = BM25Okapi(corpus_tokens)

    def get_documents_by_ids(self, ids: list[str]) -> list[RagDocument]:
        """Fetch stored chunks by id (ids not present are silently skipped).

        Used by graph expansion to resolve chunk-node neighbors back to real text.
        Graph-only entity-node ids are not in the collection, so they drop out.
        """
        clean_ids = [str(i) for i in (ids or []) if i]
        if not clean_ids:
            return []
        result = self._collection.get(ids=clean_ids, include=["documents", "metadatas"])
        got_ids = result.get("ids", []) or []
        documents = result.get("documents", []) or []
        metadatas = result.get("metadatas", []) or []

        out: list[RagDocument] = []
        for index, doc_id in enumerate(got_ids):
            metadata = (metadatas[index] if index < len(metadatas) else {}) or {}
            out.append(
                RagDocument(
                    id=doc_id,
                    content=documents[index] if index < len(documents) else "",
                    metadata=metadata,
                    source=metadata.get("source"),
                    chunk_index=int(metadata.get("chunk_index", 0) or 0),
                )
            )
        return out

    def documents_containing(self, term: str, limit: int = 5) -> list[RagDocument]:
        """Return documents whose content literally contains `term` (case-insensitive).

        Used for query-time entity linking (sparse/keyword match of exact ids and
        codes) that embeddings alone may miss.
        """
        if not term:
            return []
        needle = term.lower()
        payload = self._collection.get(include=["documents", "metadatas"])
        ids = payload.get("ids", []) or []
        documents = payload.get("documents", []) or []
        metadatas = payload.get("metadatas", []) or []

        matches: list[RagDocument] = []
        for index, doc_id in enumerate(ids):
            content = documents[index] if index < len(documents) else ""
            if needle in (content or "").lower():
                metadata = (metadatas[index] if index < len(metadatas) else {}) or {}
                matches.append(
                    RagDocument(
                        id=doc_id,
                        content=content,
                        metadata=metadata,
                        source=metadata.get("source"),
                        chunk_index=int(metadata.get("chunk_index", 0) or 0),
                    )
                )
                if len(matches) >= limit:
                    break
        return matches

    def delete(self, doc_id: str) -> None:
        self._collection.delete(ids=[doc_id])

    def upsert(self, doc: RagDocument) -> None:
        self._collection.upsert(
            ids=[doc.id],
            documents=[doc.content],
            metadatas=[doc.metadata],
            embeddings=[doc.embedding],
        )

    @staticmethod
    def _to_documents(result: dict[str, Any]) -> list[RagDocument]:
        docs = result.get("documents", [[]])[0]
        ids = result.get("ids", [[]])[0]
        metadatas = result.get("metadatas", [[]])[0]
        embeddings = result.get("embeddings", [[]])[0] if result.get("embeddings") else []

        built: list[RagDocument] = []
        for index, doc_id in enumerate(ids):
            metadata = metadatas[index] or {}
            raw_chunk_index = metadata.get("chunk_index", 0)
            try:
                chunk_index = int(raw_chunk_index)
            except (TypeError, ValueError):
                chunk_index = 0

            built.append(
                RagDocument(
                    id=doc_id,
                    content=docs[index],
                    metadata=metadata,
                    source=metadata.get("source"),
                    chunk_index=chunk_index,
                    embedding=embeddings[index] if index < len(embeddings) else None,
                )
            )
        return built
