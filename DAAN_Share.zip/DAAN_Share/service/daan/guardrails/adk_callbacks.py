from __future__ import annotations

from dataclasses import dataclass
import logging
import re
from collections import defaultdict
from typing import Any

from google.adk.agents.callback_context import CallbackContext
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.genai import types

from daan.guardrails.base_guardrail import BaseGuardrail, GuardrailBlockedError
from daan.guardrails.guardrail_provider import get_guardrail

_SUPPORTED_HOOKS: frozenset[str] = frozenset(
    {"before_agent", "before_model", "after_model", "after_agent"}
)
_DEFAULT_BLOCK_MESSAGE = "Request blocked by configured guardrail."
logger = logging.getLogger(__name__)
NamedGuardrail = tuple[str, BaseGuardrail]


@dataclass(slots=True)
class GuardrailRunResult:
    changed: bool
    executed_guardrails: list[str]
    blocked_message: str | None = None


def _split_guardrail_specs(value: str | list[str] | None) -> list[str]:
    """Parse guardrail specs from API-friendly string or list input."""
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]

    text = str(value).strip()
    if not text or text == "[]":
        return []
    if text.startswith("[") and text.endswith("]"):
        text = text[1:-1]

    return [item.strip() for item in re.split(r"[|,;\n]+", text) if item.strip()]


def parse_guardrail_specs(value: str | list[str] | None) -> dict[str, list[str]]:
    """Parse `hook:name` specs into an ADK hook -> guardrail-name mapping.

    Specs that are plain text (no colon separator) or use an unsupported hook
    are silently skipped — they are treated as instructional notes, not ADK callbacks.
    """
    hook_map: dict[str, list[str]] = defaultdict(list)
    for raw_item in _split_guardrail_specs(value):
        hook_name, separator, guardrail_name = raw_item.partition(":")
        hook = hook_name.strip().lower()
        guardrail = guardrail_name.strip()

        if not separator or not hook or not guardrail:
            logger.debug(
                "Skipping non-ADK guardrail spec '%s' (plain text, not 'hook:name' format).",
                raw_item,
            )
            continue
        if hook not in _SUPPORTED_HOOKS:
            logger.debug(
                "Skipping guardrail spec '%s': unsupported hook '%s'. Supported: %s",
                raw_item,
                hook,
                sorted(_SUPPORTED_HOOKS),
            )
            continue

        hook_map[hook].append(guardrail)

    return dict(hook_map)


def _build_content(text: str) -> types.Content:
    return types.Content(role="model", parts=[types.Part.from_text(text=text)])


def _build_llm_response(text: str) -> LlmResponse:
    return LlmResponse(content=_build_content(text))


def _merge_guardrail_names(*name_groups: list[str]) -> list[str]:
    merged: list[str] = []
    seen: set[str] = set()
    for names in name_groups:
        for name in names:
            if name in seen:
                continue
            seen.add(name)
            merged.append(name)
    return merged


def _log_guardrail_execution(
    request_data: dict[str, Any],
    guardrail_names: list[str],
    *,
    changed: bool,
    blocked: bool = False,
) -> None:
    if not guardrail_names:
        return

    logger.info(
        "Guardrail(s) %s applied, result: %s",
        ", ".join(guardrail_names),
        "blocked" if blocked else ("changed" if changed else "no_change"),
        extra={
            "session_id": request_data.get("session_id", ""),
            "agent_name": request_data.get("agent_name", ""),
            "hook": request_data.get("hook", ""),
            "guardrails": guardrail_names,
            "guardrail_result": "blocked" if blocked else ("changed" if changed else "no_change"),
        },
    )


async def _apply_guardrails_to_text(
    text: str,
    guardrails: list[NamedGuardrail],
    *,
    request_data: dict[str, Any],
) -> tuple[str, list[str]]:
    current_text = text
    executed_guardrails: list[str] = []
    for guardrail_name, guardrail in guardrails:
        executed_guardrails.append(guardrail_name)
        try:
            current_text = await guardrail.apply_guardrail(
                current_text,
                request_data=request_data,
            )
        except GuardrailBlockedError as exc:
            setattr(exc, "executed_guardrails", executed_guardrails.copy())
            raise
    return current_text, executed_guardrails


async def _apply_guardrails_to_content(
    content: types.Content | None,
    guardrails: list[NamedGuardrail],
    *,
    request_data: dict[str, Any],
) -> tuple[bool, list[str]]:
    if content is None or not getattr(content, "parts", None):
        return False, []

    changed = False
    executed_guardrails: list[str] = []
    for part in content.parts:
        text = getattr(part, "text", None)
        if not text:
            continue
        new_text, part_executed_guardrails = await _apply_guardrails_to_text(
            text,
            guardrails,
            request_data=request_data,
        )
        executed_guardrails = _merge_guardrail_names(executed_guardrails, part_executed_guardrails)
        if new_text != text:
            part.text = new_text
            changed = True
    return changed, executed_guardrails


async def _apply_guardrails_to_instruction(
    llm_request: LlmRequest,
    guardrails: list[NamedGuardrail],
    *,
    request_data: dict[str, Any],
) -> tuple[bool, list[str]]:
    instruction = getattr(llm_request.config, "system_instruction", None)
    if not instruction:
        return False, []

    if isinstance(instruction, str):
        new_instruction, executed_guardrails = await _apply_guardrails_to_text(
            instruction,
            guardrails,
            request_data=request_data,
        )
        if new_instruction != instruction:
            llm_request.config.system_instruction = new_instruction
            return True, executed_guardrails
        return False, executed_guardrails

    if isinstance(instruction, types.Content):
        return await _apply_guardrails_to_content(
            instruction,
            guardrails,
            request_data=request_data,
        )

    return False, []


def _get_request_metadata(callback_context: CallbackContext | None, hook: str) -> dict[str, Any]:
    return {
        "hook": hook,
        "agent_name": getattr(callback_context, "agent_name", ""),
        "session_id": getattr(getattr(callback_context, "session", None), "id", ""),
    }


def _blocked_guardrail_result(exc: GuardrailBlockedError) -> GuardrailRunResult:
    return GuardrailRunResult(
        changed=False,
        executed_guardrails=list(getattr(exc, "executed_guardrails", [])),
        blocked_message=str(exc) or _DEFAULT_BLOCK_MESSAGE,
    )


async def _execute_guardrail_operation(
    request_data: dict[str, Any],
    operation,
) -> GuardrailRunResult:
    try:
        changed, executed_guardrails = await operation()
        result = GuardrailRunResult(
            changed=changed,
            executed_guardrails=executed_guardrails,
        )
    except GuardrailBlockedError as exc:
        result = _blocked_guardrail_result(exc)

    _log_guardrail_execution(
        request_data,
        result.executed_guardrails,
        changed=result.changed,
        blocked=result.blocked_message is not None,
    )
    return result


def _find_latest_agent_content(callback_context: CallbackContext) -> types.Content | None:
    invocation_context = getattr(callback_context, "_invocation_context", None)
    if invocation_context is None or not hasattr(invocation_context, "_get_events"):
        return None

    try:
        events = invocation_context._get_events(current_invocation=True, current_branch=True)
    except TypeError:
        events = invocation_context._get_events(current_invocation=True)

    for event in reversed(events):
        if event.author == callback_context.agent_name and event.content:
            return event.content
    return None


def _sync_latest_user_content(callback_context: CallbackContext, user_content: types.Content) -> None:
    invocation_context = getattr(callback_context, "_invocation_context", None)
    if invocation_context is None or not hasattr(invocation_context, "_get_events"):
        return

    events = invocation_context._get_events(current_invocation=True)
    for event in reversed(events):
        if event.author == "user":
            event.content = user_content
            return


def build_adk_guardrail_callbacks(agent_config: dict[str, Any]) -> dict[str, Any]:
    """Build ADK callback hooks from a generic `guardrails` field."""
    hook_specs = parse_guardrail_specs(agent_config.get("guardrails"))
    if not hook_specs:
        return {}

    instantiated: dict[str, list[NamedGuardrail]] = {
        hook: [(name, get_guardrail(name)) for name in names]
        for hook, names in hook_specs.items()
    }
    callback_kwargs: dict[str, Any] = {}

    if instantiated.get("before_agent"):
        guardrails = instantiated["before_agent"]

        async def before_agent_callback(
            callback_context: CallbackContext,
        ) -> types.Content | None:
            user_content = callback_context.user_content
            if user_content is None:
                return None

            request_data = _get_request_metadata(callback_context, "before_agent")

            result = await _execute_guardrail_operation(
                request_data,
                lambda: _apply_guardrails_to_content(
                    user_content,
                    guardrails,
                    request_data=request_data,
                )
            )
            if result.blocked_message is not None:
                return _build_content(result.blocked_message)

            if result.changed:
                _sync_latest_user_content(callback_context, user_content)
            return None

        callback_kwargs["before_agent_callback"] = before_agent_callback

    if instantiated.get("before_model"):
        guardrails = instantiated["before_model"]

        async def before_model_callback(
            callback_context: CallbackContext,
            llm_request: LlmRequest,
        ) -> LlmResponse | None:
            request_data = _get_request_metadata(callback_context, "before_model")

            async def _run_before_model() -> tuple[bool, list[str]]:
                any_changed = False
                executed_guardrails: list[str] = []
                for content in llm_request.contents:
                    content_changed, content_guardrails = await _apply_guardrails_to_content(
                        content,
                        guardrails,
                        request_data=request_data,
                    )
                    any_changed = any_changed or content_changed
                    executed_guardrails = _merge_guardrail_names(executed_guardrails, content_guardrails)
                instruction_changed, instruction_guardrails = await _apply_guardrails_to_instruction(
                    llm_request,
                    guardrails,
                    request_data=request_data,
                )
                any_changed = any_changed or instruction_changed
                executed_guardrails = _merge_guardrail_names(executed_guardrails, instruction_guardrails)
                return any_changed, executed_guardrails

            result = await _execute_guardrail_operation(request_data, _run_before_model)
            if result.blocked_message is not None:
                return _build_llm_response(result.blocked_message)
            return None

        callback_kwargs["before_model_callback"] = before_model_callback

    if instantiated.get("after_model"):
        guardrails = instantiated["after_model"]

        async def after_model_callback(
            callback_context: CallbackContext,
            llm_response: LlmResponse,
        ) -> LlmResponse | None:
            request_data = _get_request_metadata(callback_context, "after_model")

            result = await _execute_guardrail_operation(
                request_data,
                lambda: _apply_guardrails_to_content(
                    llm_response.content,
                    guardrails,
                    request_data=request_data,
                )
            )
            if result.blocked_message is not None:
                return _build_llm_response(result.blocked_message)
            return llm_response if result.changed else None

        callback_kwargs["after_model_callback"] = after_model_callback

    if instantiated.get("after_agent"):
        guardrails = instantiated["after_agent"]

        async def after_agent_callback(
            callback_context: CallbackContext,
        ) -> types.Content | None:
            latest_content = _find_latest_agent_content(callback_context)
            if latest_content is None:
                return None

            sanitized_content = latest_content.model_copy(deep=True)
            request_data = _get_request_metadata(callback_context, "after_agent")

            result = await _execute_guardrail_operation(
                request_data,
                lambda: _apply_guardrails_to_content(
                    sanitized_content,
                    guardrails,
                    request_data=request_data,
                )
            )
            if result.blocked_message is not None:
                return _build_content(result.blocked_message)
            return sanitized_content if result.changed else None

        callback_kwargs["after_agent_callback"] = after_agent_callback

    return callback_kwargs