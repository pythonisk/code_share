import re
from typing import Optional, List

from litellm._logging import verbose_proxy_logger
from litellm.types.guardrails import PiiEntityType

from .base_guardrail import BaseGuardrail

# ---------------------------------------------------------------------------
# PII patterns relevant to the DAAN Capital Markets / Enterprise AI platform
# ---------------------------------------------------------------------------
_PII_PATTERNS: List[tuple[str, str]] = [
    # --- User / contact data ---
    # Corporate email addresses (employees, vendors)
    ("EMAIL",
     r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+"),

    # Phone numbers (international + US formats from questionnaire data)
    ("PHONE",
     r"\b(?:\+?1[\s.-]?)?(?:\(?\d{3}\)?[\s.-]?)?\d{3}[\s.-]?\d{4}\b"),

    # --- Project / system identifiers ---
    # Planview project IDs  e.g. PV8676
    ("PLANVIEW_ID",
     r"\bPV\d{4,6}\b"),

    # Internal system IDs  e.g. SYSID-09215
    ("SYSTEM_ID",
     r"\bSYSID-\d{4,6}\b"),

    # --- Financial instrument identifiers ---
    # CUSIP  — 9-char alphanumeric (letters + digits, last char is check digit)
    ("CUSIP",
     r"\b[0-9]{3}[A-Z0-9]{5}[0-9]\b"),

    # ISIN  — 2-letter country code + 9 alphanum + 1 check digit
    ("ISIN",
     r"\b[A-Z]{2}[A-Z0-9]{9}[0-9]\b"),

    # --- Credentials / secrets ---
    # Bearer / API tokens (Authorization headers or inline token strings)
    ("API_TOKEN",
     r"(?i)(?:bearer\s+|api[_-]?key[=:\s]+|token[=:\s]+)[A-Za-z0-9\-._~+/]{20,}"),

    # Azure storage connection strings / SAS tokens
    ("AZURE_SECRET",
     r"(?i)(?:AccountKey=|SharedAccessSignature=|sv=)[A-Za-z0-9+/=%&]{20,}"),

    # --- Network ---
    # Internal / vendor IP addresses
    ("IP_ADDRESS",
     r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
]


class PIIMaskingGuardrail(BaseGuardrail):
    """
    Masks PII relevant to the DAAN platform in both requests and responses.

    Covers: corporate emails, phone numbers, Planview/system IDs,
    CUSIP/ISIN instrument codes, API tokens, Azure secrets, and IP addresses.
    Uses regex-based detection — no external API required.
    """

    def __init__(self, mask_char: str = "*", **kwargs):
        self.mask_char = mask_char
        super().__init__(**kwargs)

    def _mask(self, text: str) -> str:
        for label, pattern in _PII_PATTERNS:
            def _replace(match: re.Match, _label: str = label) -> str:
                return f"[{_label}:{'*' * len(match.group())}]"
            text = re.sub(pattern, _replace, text)
        return text

    async def apply_guardrail(
        self,
        text: str,
        language: Optional[str] = None,
        entities: Optional[List[PiiEntityType]] = None,
        request_data: Optional[dict] = None,
    ) -> str:
        masked = self._mask(text)
        if masked != text:
            verbose_proxy_logger.debug("PIIMaskingGuardrail: PII detected and masked.")
        return masked
