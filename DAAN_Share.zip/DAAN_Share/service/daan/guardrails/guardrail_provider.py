from typing import Dict
from .base_guardrail import BaseGuardrail
from .pii_masking import PIIMaskingGuardrail

# Registry maps guardrail name -> class
_REGISTRY: Dict[str, type] = {
    "pii_masking": PIIMaskingGuardrail,
}


def get_guardrail(name: str, **kwargs) -> BaseGuardrail:
    """
    Instantiate and return a guardrail by name.

    Args:
        name: Registered guardrail name (e.g. "pii_masking").
        **kwargs: Passed to the guardrail constructor.

    Raises:
        ValueError: If the name is not registered.
    """
    cls = _REGISTRY.get(name)
    if cls is None:
        raise ValueError(
            f"Unknown guardrail '{name}'. Available: {list(_REGISTRY)}"
        )
    return cls(**kwargs)


def list_guardrails() -> list[str]:
    """Return names of all registered guardrails."""
    return list(_REGISTRY)
