from typing import Optional, List
from litellm.integrations.custom_guardrail import CustomGuardrail
from litellm.types.guardrails import PiiEntityType


class GuardrailBlockedError(ValueError):
    """Raised when a guardrail should stop agent execution at a callback hook."""


class BaseGuardrail(CustomGuardrail):
    """
    Base class for all DAAN guardrails.
    Extends LiteLLM's CustomGuardrail and provides a common interface.
    Subclasses should override `apply_guardrail` and/or the event hooks.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    async def apply_guardrail(
        self,
        text: str,
        # IMPORTANT: This is the text to check against your guardrail rules.
        language: Optional[str] = None,
        entities: Optional[List[PiiEntityType]] = None,
        request_data: Optional[dict] = None,
    ) -> str:
        """
        Override in subclasses to inspect/modify text.
        Return (optionally modified) text to allow through,
        or raise GuardrailBlockedError to block the request.
        """
        return text
