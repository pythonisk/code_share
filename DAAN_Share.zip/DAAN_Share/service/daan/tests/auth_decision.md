# Decision Record: E2E Testing Authentication Bypass

## Problem
The `workflow_e2e_test.ipynb` notebook tests endpoints that are protected by the `get_current_active_user` dependency. When running the notebook, users faced Authentication errors (401 Unauthorized) because the API expects a valid `Bearer` token.
Since multiple engineers will use this test script to validate the multi-agent backend, passing around real usernames and passwords or having to manually create users slows down development and complicates onboarding.

## Solution
Rather than modifying the core API application logic (e.g. bypassing security dynamically or modifying `dependencies.py`), which could accidentally bleed into production, the decision was made to:
1. Use an automated seeding script inside the notebook to generate a test user directly in the local database.
2. Programmatically call the existing `POST /users/generateToken` API endpoint to authenticate and retrieve a valid JWT.
3. Automatically append this JWT to the HTTP `HEADERS` used by all subsequent cells in the notebook workflow.

## Why this approach?
*   **Security Safety:** Doing this requires no "dev mode auth bypass" hacks in the production API endpoints.
*   **Frictionless:** Any engineer running the notebook will automatically generate (`e2e_test_user`) via SQLAlchemy and then log in successfully without knowing or sharing passwords.
*   **Test Integrity:** The notebook interacts with the system using real tokens, accurately testing the authorization layer just like the UI would. 

*Code for the auth implementation can be viewed in the first code cell of the `workflow_e2e_test.ipynb` file.*