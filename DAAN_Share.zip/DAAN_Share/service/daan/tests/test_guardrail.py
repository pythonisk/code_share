from daan.guardrails import guardrail_provider

def test_guardrail_provider():
    # Test that we can get the PII masking guardrail
    guardrail = guardrail_provider.get_guardrail("pii_masking")
    assert guardrail is not None
    assert guardrail.__class__.__name__ == "PIIMaskingGuardrail"

    text = guardrail.apply_guardrail("Contact me at shreya@gmail.com")
    print(text)
    # Test that requesting an unknown guardrail raises an error
    try:
        guardrail_provider.get_guardrail("unknown_guardrail")
        assert False, "Expected ValueError for unknown guardrail"
    except ValueError as e:
        assert "Unknown guardrail" in str(e)