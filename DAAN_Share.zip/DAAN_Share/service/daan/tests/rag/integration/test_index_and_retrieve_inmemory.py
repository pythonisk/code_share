import asyncio
import hashlib
from pathlib import Path

from daan.graph_stores.providers.in_memory_graph_store import InMemoryGraphStore
from daan.llm.embeddings.base_embedding_provider import BaseEmbeddingProvider
from daan.rag.chunking.fixed_size_chunker import FixedSizeChunker
from daan.rag.indexing.rag_indexing_service import RagIndexingService
from daan.rag.retrieval.vector_retriever import VectorRetriever
from daan.vector_stores.providers.in_memory_vector_store import InMemoryVectorStore


class DummyEmbeddingProvider(BaseEmbeddingProvider):
    def embed_text(self, text: str) -> list[float]:
        size = max(1, min(8, len(text)))
        return [float(size), 1.0, 0.5]

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [self.embed_text(text) for text in texts]


def test_index_then_vector_retrieve(tmp_path: Path) -> None:
    doc_path = tmp_path / "sample.md"
    doc_path.write_text("Graph RAG retrieval test content for integration.", encoding="utf-8")

    vector_store = InMemoryVectorStore()
    graph_store = InMemoryGraphStore()
    embedding_provider = DummyEmbeddingProvider()
    chunker = FixedSizeChunker({"chunk_size": 64, "chunk_overlap": 8})

    service = RagIndexingService()
    result = asyncio.run(
        service.index_documents(
            session_id="s1",
            files=[str(doc_path)],
            vector_store=vector_store,
            graph_store=graph_store,
            embedding_provider=embedding_provider,
            chunker=chunker,
        )
    )

    assert result["chunks_indexed"] >= 1

    retriever = VectorRetriever(
        {
            "vector_store": vector_store,
            "embedding_provider": embedding_provider,
        }
    )
    docs = retriever.retrieve(query="graph rag", k=3)
    assert docs


def test_query_link_stored_in_metadata(tmp_path: Path) -> None:
    """query_link value must be persisted in each chunk's metadata."""
    doc_path = tmp_path / "ql_sample.md"
    doc_path.write_text("Advanced RAG with query-link wiring test.", encoding="utf-8")

    query = "query link wiring"
    query_link = hashlib.sha1(query.strip().lower().encode()).hexdigest()[:16]

    vector_store = InMemoryVectorStore()
    graph_store = InMemoryGraphStore()
    embedding_provider = DummyEmbeddingProvider()
    chunker = FixedSizeChunker({"chunk_size": 64, "chunk_overlap": 8})

    service = RagIndexingService()
    result = asyncio.run(
        service.index_documents(
            session_id="s_ql",
            files=[str(doc_path)],
            vector_store=vector_store,
            graph_store=graph_store,
            embedding_provider=embedding_provider,
            chunker=chunker,
            query=query,
            query_link=query_link,
        )
    )

    assert result["query_link"] == query_link
    assert result["chunks_indexed"] >= 1

    # All stored docs should carry query_link in their metadata
    all_docs = vector_store._docs.values()
    for doc in all_docs:
        assert doc.metadata.get("query_link") == query_link


def test_query_link_filters_retrieval(tmp_path: Path) -> None:
    """VectorRetriever must filter by query_link_key and return only matching docs."""
    doc_a = tmp_path / "doc_a.md"
    doc_b = tmp_path / "doc_b.md"
    doc_a.write_text("Customer satisfaction metrics overview.", encoding="utf-8")
    doc_b.write_text("Completely unrelated revenue report content.", encoding="utf-8")

    query = "customer satisfaction"
    query_link = hashlib.sha1(query.strip().lower().encode()).hexdigest()[:16]

    vector_store = InMemoryVectorStore()
    graph_store = InMemoryGraphStore()
    embedding_provider = DummyEmbeddingProvider()
    chunker = FixedSizeChunker({"chunk_size": 64, "chunk_overlap": 8})

    service = RagIndexingService()

    # Index doc_a WITH query_link
    asyncio.run(
        service.index_documents(
            session_id="s_filter",
            files=[str(doc_a)],
            vector_store=vector_store,
            graph_store=graph_store,
            embedding_provider=embedding_provider,
            chunker=chunker,
            query=query,
            query_link=query_link,
        )
    )
    # Index doc_b WITHOUT query_link
    asyncio.run(
        service.index_documents(
            session_id="s_filter",
            files=[str(doc_b)],
            vector_store=vector_store,
            graph_store=graph_store,
            embedding_provider=embedding_provider,
            chunker=chunker,
        )
    )

    retriever = VectorRetriever(
        {
            "vector_store": vector_store,
            "embedding_provider": embedding_provider,
            "query_link_key": query_link,
        }
    )
    docs = retriever.retrieve(query=query, k=10)
    assert docs
    for doc in docs:
        assert doc.metadata.get("query_link") == query_link


def test_embed_with_retry_recovers_from_rate_limit(monkeypatch) -> None:
    calls = {"count": 0}

    class FlakyEmbeddingProvider(DummyEmbeddingProvider):
        def embed_batch(self, texts: list[str]) -> list[list[float]]:
            calls["count"] += 1
            if calls["count"] < 3:
                raise RuntimeError("litellm.RateLimitError: 429 Too Many Requests")
            return super().embed_batch(texts)

    monkeypatch.setattr("daan.rag.indexing.rag_indexing_service.time.sleep", lambda _seconds: None)

    result = RagIndexingService._embed_with_retry(FlakyEmbeddingProvider(), ["hello"], max_retries=5, base_delay_seconds=1)

    assert calls["count"] == 3
    assert result == [[5.0, 1.0, 0.5]]


def test_embed_with_retry_reraises_non_rate_limit_errors() -> None:
    class BrokenEmbeddingProvider(DummyEmbeddingProvider):
        def embed_batch(self, texts: list[str]) -> list[list[float]]:
            raise ValueError("malformed input")

    try:
        RagIndexingService._embed_with_retry(BrokenEmbeddingProvider(), ["hello"], max_retries=3, base_delay_seconds=1)
        assert False, "expected ValueError to propagate"
    except ValueError:
        pass
