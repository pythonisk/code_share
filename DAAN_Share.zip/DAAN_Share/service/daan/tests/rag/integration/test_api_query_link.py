"""API-level integration tests for query-link round-trip via TestClient."""

from __future__ import annotations

import hashlib
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient
from daan.core.dependencies import get_current_active_user

from daan.main import app

client = TestClient(app)

@pytest.fixture
def authenticated_user_override():
    """Keep RAG tests auth-aware without changing runtime auth behavior."""
    app.dependency_overrides[get_current_active_user] = lambda: SimpleNamespace(
        id=1,
        username="tester",
        is_active=True,
    )
    try:
        yield
    finally:
        app.dependency_overrides.clear()


@pytest.fixture
def authenticated_user_override():
    """Keep RAG tests auth-aware without changing runtime auth behavior."""
    app.dependency_overrides[get_current_active_user] = lambda: SimpleNamespace(
        id=1,
        username="tester",
        is_active=True,
    )
    try:
        yield
    finally:
        app.dependency_overrides.clear()


def _make_rag_config(tmp_path: Path) -> dict:
    return {
        "embedding_provider": "demo",
        "vector_store_type": "in_memory",
        "graph_store_type": "in_memory",
        "chunker_type": "fixed_size",
        "chunk_size": 64,
        "chunk_overlap": 8,
        "default_retriever_type": "vector",
        "reranker_type": "llm",
        "top_k": 5,
        "knowledge_bases": [{"id": "test_kb", "enabled": True}],
    }
def test_search_returns_query_link(tmp_path: Path, authenticated_user_override) -> None:
    """POST /rag/search must echo back the resolved query_link in the response."""
    query = "what is retrieval augmented generation"
    expected_ql = hashlib.sha1(query.strip().lower().encode()).hexdigest()[:16]

    mock_tool = MagicMock()
    mock_tool.search_documents.return_value = [
        {"id": "doc1", "content": "RAG context chunk", "source": "test.md", "chunk_index": 0, "query_link": expected_ql}
    ]

    with patch("daan.api.v1.endpoints.rag_router.RagTool", return_value=mock_tool):
        with patch("daan.api.v1.endpoints.rag_router.get_settings") as mock_get_settings:
            mock_get_settings.return_value.load_rag_config.return_value = _make_rag_config(tmp_path)
            response = client.post(
                "/api/rag/search",
                json={"query": query, "kb_id": "test_kb", "synthesize": False},
            )

    assert response.status_code == 200
    body = response.json()
    assert body["query_link"] == expected_ql
    assert len(body["references"]) == 1
    assert body["references"][0]["content"] == "RAG context chunk"


def test_search_with_explicit_query_link(tmp_path: Path, authenticated_user_override) -> None:
    """An explicitly supplied query_link must be passed through, not overwritten."""
    explicit_ql = "deadbeef12345678"
    mock_tool = MagicMock()
    mock_tool.search_documents.return_value = []

    with patch("daan.api.v1.endpoints.rag_router.RagTool", return_value=mock_tool):
        with patch("daan.api.v1.endpoints.rag_router.get_settings") as mock_get_settings:
            mock_get_settings.return_value.load_rag_config.return_value = _make_rag_config(tmp_path)
            response = client.post(
                "/api/rag/search",
                json={"query": "some query", "query_link": explicit_ql, "kb_id": "test_kb"},
            )

    assert response.status_code == 200
    body = response.json()
    assert body["query_link"] == explicit_ql
    mock_tool.search_documents.assert_called_once()
    call_kwargs = mock_tool.search_documents.call_args
    assert call_kwargs.kwargs.get("query_link") == explicit_ql or call_kwargs.args[4] == explicit_ql


def test_index_endpoint_calls_tool(tmp_path: Path, authenticated_user_override) -> None:
    """POST /rag/knowledge-bases/{kb_id}/index must call index_file_structured."""
    doc_path = tmp_path / "test_doc.md"
    doc_path.write_text("Advanced RAG indexing test document content.", encoding="utf-8")

    mock_tool = MagicMock()
    mock_tool.index_file_structured = AsyncMock(
        return_value={
            "session_id": "kb1",
            "files_indexed": 1,
            "chunks_indexed": 3,
            "query_link": "abc123def456abcd",
            "chunk_ids": ["c1", "c2", "c3"],
        }
    )

    with patch("daan.api.v1.endpoints.rag_router.RagTool", return_value=mock_tool):
        with patch("daan.api.v1.endpoints.rag_router.get_settings") as mock_get_settings:
            mock_get_settings.return_value.SESSION_STORAGE_DIR = str(tmp_path)
            mock_get_settings.return_value.load_rag_config.return_value = _make_rag_config(tmp_path)
            response = client.post(
                "/api/rag/knowledge-bases/kb1/index",
                json={"file_path": str(doc_path), "query": "rag test"},
            )

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["chunks_indexed"] == 3
    mock_tool.index_file_structured.assert_called_once()


def test_list_knowledge_bases(tmp_path: Path, authenticated_user_override) -> None:
    """GET /rag/knowledge-bases must return the list from RagTool."""
    mock_tool = MagicMock()
    mock_tool.list_knowledge_bases.return_value = [{"id": "default", "enabled": True}]

    with patch("daan.api.v1.endpoints.rag_router.RagTool", return_value=mock_tool):
        with patch("daan.api.v1.endpoints.rag_router.get_settings") as mock_get_settings:
            mock_get_settings.return_value.load_rag_config.return_value = _make_rag_config(tmp_path)
            response = client.get("/api/rag/knowledge-bases")

    assert response.status_code == 200
    body = response.json()
    assert body["knowledge_bases"] == [{"id": "default", "enabled": True}]


def test_list_knowledge_bases_uses_endpoint_cache(tmp_path: Path, authenticated_user_override) -> None:
    """GET /rag/knowledge-bases should reuse the short-lived response cache."""
    mock_tool = MagicMock()
    mock_tool.list_knowledge_bases.return_value = [{"id": "default", "enabled": True, "documents": []}]

    with patch("daan.api.v1.endpoints.rag_router._kb_list_cache", {}):
        with patch("daan.api.v1.endpoints.rag_router.RagTool", return_value=mock_tool):
            with patch("daan.api.v1.endpoints.rag_router.get_settings") as mock_get_settings:
                mock_get_settings.return_value.load_rag_config.return_value = _make_rag_config(tmp_path)

                first = client.get("/api/rag/knowledge-bases")
                second = client.get("/api/rag/knowledge-bases")

    assert first.status_code == 200
    assert second.status_code == 200
    assert first.json()["knowledge_bases"] == second.json()["knowledge_bases"]
    mock_tool.list_knowledge_bases.assert_called_once()


def test_traces_endpoint(tmp_path: Path, authenticated_user_override) -> None:
    """GET /rag/traces/{session_id} must return persisted traces."""
    with patch("daan.api.v1.endpoints.rag_router.tracer") as mock_tracer:
        mock_tracer.read_traces.return_value = [{"query": "test", "latency_ms": 42}]
        response = client.get("/api/rag/traces/some_session")

    assert response.status_code == 200
    body = response.json()
    assert body["kb_id"] == "some_session"
    assert len(body["traces"]) == 1
    assert body["traces"][0]["latency_ms"] == 42


def test_search_can_return_explainability(tmp_path: Path, authenticated_user_override) -> None:
    query = "show me why"
    expected_ql = hashlib.sha1(query.strip().lower().encode()).hexdigest()[:16]

    mock_tool = MagicMock()
    mock_tool.search_documents.return_value = {
        "results": [
            {
                "id": "doc-1",
                "content": "Claims are matched on member id.",
                "source": "design.docx",
                "chunk_index": 2,
                "query_link": expected_ql,
            }
        ],
        "explainability": {
            "query_link": expected_ql,
            "retriever_type": "graph_rag",
            "seed_chunk_ids": ["doc-1"],
            "seed_chunks": [{"id": "doc-1", "source": "design.docx", "chunk_index": 2, "snippet": "Claims are matched"}],
            "reranked_chunks": [{"id": "doc-1", "source": "design.docx", "chunk_index": 2, "snippet": "Claims are matched", "score": 0.9}],
            "selected_references": [{"id": "doc-1", "source": "design.docx", "chunk_index": 2, "snippet": "Claims are matched"}],
            "visited_node_ids": ["doc-1", "entity-member"],
            "traversal_hops": [{"seed_chunk_id": "doc-1", "depth": 2, "neighbor_ids": ["entity-member"], "neighbor_count": 1}],
            "edge_list": [{"source_id": "query:test", "target_id": "doc-1", "type": "seed", "properties": {}}],
            "final_selected_chunk_ids": ["doc-1"],
            "graph_nodes": [{"id": "query:test", "label": "Query", "properties": {"name": "Query"}}, {"id": "doc-1", "label": "Chunk", "properties": {"text": "Claims are matched"}}],
            "graph_edges": [{"source_id": "query:test", "target_id": "doc-1", "type": "seed", "properties": {}}],
            "final_context_snapshot": "Claims are matched on member id.",
        },
        "graph": {"nodes": [], "edges": []},
    }

    with patch("daan.api.v1.endpoints.rag_router.RagTool", return_value=mock_tool):
        with patch("daan.api.v1.endpoints.rag_router.get_settings") as mock_get_settings:
            mock_get_settings.return_value.load_rag_config.return_value = _make_rag_config(tmp_path)
            response = client.post(
                "/api/rag/search",
                json={"query": query, "kb_id": "test_kb", "include_explainability": True},
            )

    assert response.status_code == 200
    body = response.json()
    assert body["explainability"]["query_link"] == expected_ql
    assert body["explainability"]["selected_references"][0]["id"] == "doc-1"


def test_query_link_endpoints_return_explainability_and_graph(authenticated_user_override) -> None:
    trace_payload = {
        "query": "why",
        "query_link": "abcd1234",
        "retriever_type": "graph_rag",
        "latency_ms": 12,
        "explainability": {
            "query_link": "abcd1234",
            "retriever_type": "graph_rag",
            "latency_ms": 12,
            "selected_references": [{"id": "doc-1", "source": "design.docx", "chunk_index": 0, "snippet": "snippet"}],
        },
        "traversal_hops": [{"seed_chunk_id": "doc-1", "depth": 2, "neighbor_ids": ["entity-1"], "neighbor_count": 1}],
        "final_selected_chunk_ids": ["doc-1"],
        "graph_nodes": [
            {"id": "query:abcd1234", "label": "Query", "properties": {"name": "Query"}},
            {"id": "doc-1", "label": "Chunk", "properties": {"text": "snippet"}},
        ],
        "graph_edges": [
            {"source_id": "query:abcd1234", "target_id": "doc-1", "type": "seed", "properties": {}},
        ],
    }

    with patch("daan.api.v1.endpoints.rag_router.tracer") as mock_tracer:
        mock_tracer.read_trace_by_query_link.return_value = trace_payload

        explainability_response = client.get("/api/rag/knowledge-bases/test_kb/explainability/abcd1234")
        graph_response = client.get("/api/rag/knowledge-bases/test_kb/graph/abcd1234")

    assert explainability_response.status_code == 200
    assert explainability_response.json()["query_link"] == "abcd1234"

    assert graph_response.status_code == 200
    graph_body = graph_response.json()
    assert graph_body["query_link"] == "abcd1234"
    assert len(graph_body["nodes"]) == 2
    assert len(graph_body["edges"]) == 1


def test_rag_requires_authentication() -> None:
    app.dependency_overrides.clear()
    response = client.get("/api/rag/knowledge-bases")
    assert response.status_code == 401


def test_index_rejects_file_path_outside_allowed_dirs(tmp_path: Path, authenticated_user_override) -> None:
    outside_file = tmp_path / "outside.txt"
    outside_file.write_text("not in allowed dirs", encoding="utf-8")

    session_dir = tmp_path / "session_storage"
    session_dir.mkdir(parents=True, exist_ok=True)
    fake_settings = MagicMock()
    fake_settings.SESSION_STORAGE_DIR = str(session_dir)
    fake_settings.load_rag_config.return_value = _make_rag_config(tmp_path)

    with patch("daan.api.v1.endpoints.rag_router.get_settings", return_value=fake_settings):
        response = client.post(
            "/api/rag/knowledge-bases/kb1/index",
            json={"file_path": str(outside_file)},
        )

    assert response.status_code == 400
    assert "outside allowed ingestion directories" in response.json()["detail"]


def test_upload_and_index_rejects_unsupported_extension(tmp_path: Path, authenticated_user_override) -> None:
    session_dir = tmp_path / "session_storage"
    session_dir.mkdir(parents=True, exist_ok=True)
    fake_settings = MagicMock()
    fake_settings.SESSION_STORAGE_DIR = str(session_dir)
    fake_settings.load_rag_config.return_value = _make_rag_config(tmp_path)

    with patch("daan.api.v1.endpoints.rag_router.get_settings", return_value=fake_settings):
        response = client.post(
            "/api/rag/knowledge-bases/kb1/upload-and-index",
            files={"file": ("payload.exe", b"MZ", "application/octet-stream")},
        )

    assert response.status_code == 400
    assert "Unsupported file type" in response.json()["detail"]
