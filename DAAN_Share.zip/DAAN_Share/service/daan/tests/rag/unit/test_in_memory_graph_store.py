from daan.graph_stores.graph_document import GraphEdge, GraphNode
from daan.graph_stores.providers.in_memory_graph_store import InMemoryGraphStore


def test_neighbors_and_subgraph() -> None:
    store = InMemoryGraphStore()
    store.add_node(GraphNode(id="a", label="Entity"))
    store.add_node(GraphNode(id="b", label="Entity"))
    store.add_node(GraphNode(id="c", label="Entity"))

    store.add_edge(GraphEdge(source_id="a", target_id="b", type="REL"))
    store.add_edge(GraphEdge(source_id="b", target_id="c", type="REL"))

    neighbors = store.get_neighbors("a", depth=2)
    neighbor_ids = {node.id for node in neighbors}
    assert "b" in neighbor_ids
    assert "c" in neighbor_ids

    subgraph = store.get_subgraph(["a", "b"])
    assert len(subgraph["nodes"]) == 2
    assert len(subgraph["edges"]) == 1
