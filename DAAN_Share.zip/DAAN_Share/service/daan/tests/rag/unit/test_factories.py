from daan.graph_stores.graph_store_factory import GraphStoreFactory
from daan.llm.embedding_provider import EmbeddingProviderFactory
from daan.rag.chunking.chunker_factory import ChunkerFactory
from daan.rag.retrieval.retriever_factory import RetrieverFactory
from daan.rag.reranking.reranker_factory import RerankerFactory
from daan.vector_stores.vector_store_factory import VectorStoreFactory


def test_factory_registries_have_expected_entries() -> None:
    assert "azure_openai" in EmbeddingProviderFactory.get_available_providers()
    assert "chroma" in VectorStoreFactory.get_available_stores()
    assert "kuzu" in GraphStoreFactory.get_available_stores()
    assert "graph_rag" in RetrieverFactory.get_available_retrievers()
    assert "llm" in RerankerFactory.get_available_rerankers()
    assert "recursive_text" in ChunkerFactory.get_available_chunkers()
