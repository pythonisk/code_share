from daan.usecases.usecase_service import _chat_usecase_flag


def test_chat_usecase_flag_returns_yes_when_chat_agent_is_listed() -> None:
    agents_involved = "AGENT_17:Planner|dynamic_agent;AGENT_18:Chat|chat_agent"
    assert _chat_usecase_flag(agents_involved) == "Yes"


def test_chat_usecase_flag_returns_no_when_chat_agent_is_not_listed() -> None:
    agents_involved = "AGENT_17:Planner|dynamic_agent;AGENT_18:Executor|Custom_Action_Agent"
    assert _chat_usecase_flag(agents_involved) == "No"