from __future__ import annotations

import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from daan.native_tools.aida_sttm_tool import AidaSttmTool
from daan.utils.sttm import generate_sttm_from_files
from daan.utils.sttm.parsers import (
    InformaticaPowerMartXmlParser,
    JsonMappingParser,
    PySparkMappingParser,
    SnowparkJavaMappingParser,
    SqlMappingParser,
    TalendXmlParser,
)
from daan.utils.sttm.registry import ParserRegistry


def sample_mapping_payload() -> dict:
    return {
        "sttm_mappings": [
            {
                "Source Table Name": "src_customer",
                "Source Attribute Name": "customer_id",
                "Source Data Type": "INTEGER",
                "Target Table Name": "dim_customer",
                "Target Attribute Name": "customer_key",
                "Target Data Type": "INTEGER",
                "Mapping Type": "Direct",
                "Transformation Rule": "customer_id",
                "Business Rule Applied": "None",
            }
        ]
    }


class TestAidaSttmParsers(unittest.TestCase):
        def test_parser_registry_dispatches_json_mapping(self) -> None:
                registry = ParserRegistry()
                result = registry.parse_file("sample_mapping.json", json.dumps(sample_mapping_payload()))
                self.assertEqual(result.parser_name, "json_mapping")
                self.assertGreaterEqual(len(result.rows), 1)

        def test_informatica_parser_extracts_mapping(self) -> None:
                content = """
                <POWERMART>
                    <SOURCE NAME="SRC_CUSTOMER" DATABASETYPE="Oracle">
                        <SOURCEFIELD NAME="CUSTOMER_ID" DATATYPE="NUMBER"/>
                    </SOURCE>
                    <TARGET NAME="DIM_CUSTOMER" DATABASETYPE="Snowflake">
                        <TARGETFIELD NAME="CUSTOMER_KEY" DATATYPE="NUMBER"/>
                    </TARGET>
                    <CONNECTOR FROMINSTANCE="SRC_CUSTOMER" FROMFIELD="CUSTOMER_ID" TOINSTANCE="DIM_CUSTOMER" TOFIELD="CUSTOMER_KEY"/>
                </POWERMART>
                """
                result = InformaticaPowerMartXmlParser().parse("mapping.xml", content)
                self.assertGreaterEqual(len(result.rows), 1)
                self.assertEqual(result.rows[0]["Target Attribute Name"], "CUSTOMER_KEY")

        def test_sql_parser_extracts_insert_select_mapping(self) -> None:
                content = "INSERT INTO dim_customer (customer_key) SELECT src.customer_id AS customer_key FROM src_customer src;"
                result = SqlMappingParser().parse("mapping.sql", content)
                self.assertGreaterEqual(len(result.rows), 1)
                self.assertEqual(result.rows[0]["Target Attribute Name"], "customer_key")

        def test_pyspark_parser_extracts_withcolumn_mapping(self) -> None:
                content = """
df = spark.table('src_customer')
df2 = df.withColumn('customer_key', col('customer_id'))
df2.write.saveAsTable('dim_customer')
                """
                result = PySparkMappingParser().parse("job.py", content)
                self.assertGreaterEqual(len(result.rows), 1)
                self.assertEqual(result.rows[0]["Target Table Name"], "dim_customer")

        def test_snowpark_parser_extracts_withcolumn_mapping(self) -> None:
                content = """
Dataset df = session.table(\"SRC_CUSTOMER\");
Dataset df2 = df.withColumn(\"CUSTOMER_KEY\", Functions.col(\"CUSTOMER_ID\"));
df2.saveAsTable(\"DIM_CUSTOMER\");
                """
                result = SnowparkJavaMappingParser().parse("job.java", content)
                self.assertGreaterEqual(len(result.rows), 1)
                self.assertEqual(result.rows[0]["Target Table Name"], "DIM_CUSTOMER")

        def test_json_parser_normalizes_mapping_rows(self) -> None:
                result = JsonMappingParser().parse("mapping.json", json.dumps(sample_mapping_payload()))
                self.assertGreaterEqual(len(result.rows), 1)
                self.assertEqual(result.rows[0]["Target Attribute Name"], "customer_key")

        def test_talend_parser_extracts_mapping(self) -> None:
                content = """
                <talendfile:ProcessType xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:TalendMapper="http://www.talend.org/mapper" xmlns:talendfile="platform:/resource/org.talend.model/model/TalendFile.xsd" framework="Spark">
                    <node componentName="tFileInputDelimited">
                        <elementParameter name="UNIQUE_NAME" value="tFileInputDelimited_1"/>
                        <elementParameter name="FILENAME" value="&quot;/landing/src_customer.csv&quot;"/>
                        <metadata connector="FLOW" name="tFileInputDelimited_1">
                            <column name="CUSTOMER_ID" type="id_Long" length="-1" precision="0"/>
                        </metadata>
                    </node>
                    <node componentName="tMap">
                        <elementParameter name="UNIQUE_NAME" value="tMap_1"/>
                        <nodeData xsi:type="TalendMapper:MapperData">
                            <outputTables name="out1">
                                <mapperTableEntries name="CUSTOMER_KEY" expression="row1.CUSTOMER_ID" type="id_Long" nullable="true"/>
                            </outputTables>
                            <inputTables name="row1"/>
                        </nodeData>
                    </node>
                    <node componentName="tFileOutputParquet">
                        <elementParameter name="UNIQUE_NAME" value="tFileOutputParquet_1"/>
                        <elementParameter name="FILENAME" value="&quot;/curated/dim_customer&quot;"/>
                        <metadata connector="FLOW" name="tFileOutputParquet_1">
                            <column name="CUSTOMER_KEY" type="id_Long" length="-1" precision="0"/>
                        </metadata>
                    </node>
                    <connection connectorName="FLOW" label="row1" source="tFileInputDelimited_1" target="tMap_1"/>
                    <connection connectorName="FLOW" label="out1" source="tMap_1" target="tFileOutputParquet_1"/>
                </talendfile:ProcessType>
                """
                result = TalendXmlParser().parse("job.xml", content)
                self.assertGreaterEqual(len(result.rows), 1)
                self.assertEqual(result.rows[0]["Source Table Name"], "/landing/src_customer.csv")
                self.assertEqual(result.rows[0]["Target Table Name"], "/curated/dim_customer")
                self.assertEqual(result.rows[0]["Target Attribute Name"], "CUSTOMER_KEY")

        def test_parser_registry_dispatches_talend_xml(self) -> None:
                content = """
                <talendfile:ProcessType xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:TalendMapper="http://www.talend.org/mapper" xmlns:talendfile="platform:/resource/org.talend.model/model/TalendFile.xsd" framework="Spark">
                    <node componentName="tFileInputDelimited">
                        <elementParameter name="UNIQUE_NAME" value="tFileInputDelimited_1"/>
                        <elementParameter name="FILENAME" value="&quot;/landing/src_customer.csv&quot;"/>
                        <metadata connector="FLOW" name="tFileInputDelimited_1">
                            <column name="CUSTOMER_ID" type="id_Long" length="-1" precision="0"/>
                        </metadata>
                    </node>
                    <node componentName="tMap">
                        <elementParameter name="UNIQUE_NAME" value="tMap_1"/>
                        <nodeData xsi:type="TalendMapper:MapperData">
                            <outputTables name="out1">
                                <mapperTableEntries name="CUSTOMER_KEY" expression="row1.CUSTOMER_ID" type="id_Long" nullable="true"/>
                            </outputTables>
                            <inputTables name="row1"/>
                        </nodeData>
                    </node>
                    <node componentName="tFileOutputParquet">
                        <elementParameter name="UNIQUE_NAME" value="tFileOutputParquet_1"/>
                        <elementParameter name="FILENAME" value="&quot;/curated/dim_customer&quot;"/>
                        <metadata connector="FLOW" name="tFileOutputParquet_1">
                            <column name="CUSTOMER_KEY" type="id_Long" length="-1" precision="0"/>
                        </metadata>
                    </node>
                    <connection connectorName="FLOW" label="row1" source="tFileInputDelimited_1" target="tMap_1"/>
                    <connection connectorName="FLOW" label="out1" source="tMap_1" target="tFileOutputParquet_1"/>
                </talendfile:ProcessType>
                """
                registry = ParserRegistry()
                result = registry.parse_file("job.xml", content)
                self.assertEqual(result.parser_name, "talend_xml")
                self.assertGreaterEqual(len(result.rows), 1)


class TestAidaSttmService(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = Path(tempfile.mkdtemp(prefix="aida_sttm_service_"))
        self.input_file = self.temp_dir / "sample_mapping.json"
        self.input_file.write_text(json.dumps(sample_mapping_payload(), indent=2), encoding="utf-8")

    def tearDown(self) -> None:
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_generate_sttm_from_files_creates_workbook(self) -> None:
        artifacts_dir = self.temp_dir / "artifacts"
        result = generate_sttm_from_files(
            file_paths=[str(self.input_file)],
            output_folder=str(artifacts_dir),
            file_name="service_generated.xlsx",
        )
        artifact_path = Path(result["artifact_path"])
        self.assertEqual(result["status"], "ok")
        self.assertTrue(artifact_path.is_file())
        self.assertEqual(artifact_path.name, "service_generated.xlsx")
        self.assertGreaterEqual(result["mapping_count"], 1)


class TestAidaSttmTool(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = Path(tempfile.mkdtemp(prefix="aida_sttm_tool_"))
        self.session_dir = self.temp_dir / "session_123"
        self.inputs_dir = self.session_dir / "inputs"
        self.inputs_dir.mkdir(parents=True, exist_ok=True)
        self.input_file = self.inputs_dir / "sample_mapping.json"
        self.input_file.write_text(json.dumps(sample_mapping_payload(), indent=2), encoding="utf-8")
        self.artifacts_dir = self.session_dir / "artifacts"

    def tearDown(self) -> None:
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_generate_sttm_excel_writes_artifact(self) -> None:
        tool = AidaSttmTool(data_dir=str(self.inputs_dir))
        with patch("daan.native_tools.aida_sttm_tool.get_artifacts_dir", return_value=self.artifacts_dir):
            result = tool.generate_sttm_excel(output_file_name="tool_generated.xlsx")
        artifact_path = self.artifacts_dir / "tool_generated.xlsx"
        self.assertEqual(result["status"], "ok")
        self.assertTrue(artifact_path.is_file())
        self.assertEqual(result["artifact_file"], "tool_generated.xlsx")
        self.assertEqual(Path(result["artifact_path"]), artifact_path)
        self.assertGreaterEqual(result["mapping_count"], 1)