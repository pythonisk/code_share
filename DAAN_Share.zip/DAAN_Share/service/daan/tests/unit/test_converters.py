"""
Comprehensive test suite for file-to-JSON converters.

Covers:
  - FileToJsonConverter: convert_file_to_json, convert_directory_to_json,
    get_supported_file_types, is_file_supported
  - Individual converters: CSV, Excel, Text (txt/md/py/sql/log), JSON, XML,
    PDF, DOCX, PBIT, PBIX, PBIP, Tableau (TWB/TWBX)
  - Customer-supplied sample files from the "Inputs - Customer Proposed Use Cases" folder
  - Edge cases: unsupported extensions, missing files, empty files

Every test stores its result in the class-level ``results`` dict and prints
a summary on success so the CI log is self-documenting.
"""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

import pandas as pd

# ---------------------------------------------------------------------------
# Fix sys.path so we can import from the service package
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parents[4]
SERVICE_DIR = PROJECT_ROOT / "service"
if str(SERVICE_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_DIR))

from daan.utils.file_to_json import FileToJsonConverter
from daan.utils.converters.csv_converter import CsvConverter
from daan.utils.converters.directory_converter import DirectoryConverter
from daan.utils.converters.docx_converter import DocxConverter
from daan.utils.converters.excel_converter import ExcelConverter
from daan.utils.converters.json_converter import JsonConverter
from daan.utils.converters.pbip_converter import PbipConverter
from daan.utils.converters.pbit_converter import PbitConverter
from daan.utils.converters.pbix_converter import PbixConverter
from daan.utils.converters.pdf_converter import PdfConverter
from daan.utils.converters.tableau_converter import TableauConverter
from daan.utils.converters.text_converter import TextConverter
from daan.utils.converters.xml_converter import XmlConverter

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
SAMPLES_DIR = Path(__file__).resolve().parent / "samples"
POWERBI_DIR = SAMPLES_DIR / "Power BI - Inputs"

# Collector for all results (class_name -> {test_name: result_dict})
ALL_RESULTS: dict = {}


def _store(cls_name: str, test_name: str, result):
    """Store a test result for later inspection."""
    ALL_RESULTS.setdefault(cls_name, {})[test_name] = result


def _print_ok(label: str, result, max_chars: int = 300):
    """Print a compact success message with a snippet of the result."""
    snippet = json.dumps(result, default=str)[:max_chars]
    print(f"  [OK] {label}: {snippet}")


# ======================================================================
#  1. CSV Converter
# ======================================================================
class TestCsvConverter(unittest.TestCase):
    """Validate CsvConverter against every .csv file in samples/."""

    def _run_csv(self, path: Path):
        converter = CsvConverter()
        result = converter.convert(str(path))
        self.assertEqual(result["type"], "tabular_data")
        self.assertIn("rows", result)
        self.assertIn("columns", result)
        self.assertGreater(len(result["columns"]), 0)
        _store("CsvConverter", path.name, result)
        _print_ok(f"CSV -> {path.name}", result)
        return result

    def test_sample_csv(self):
        self._run_csv(SAMPLES_DIR / "sample.csv")

    def test_databricks_sttm_csv(self):
        self._run_csv(SAMPLES_DIR / "Databricks_STTM_SourceToTarget.csv")

    def test_powerbi_csv_product(self):
        self._run_csv(POWERBI_DIR / "Product 1.csv")

    def test_powerbi_csv_purchase1(self):
        self._run_csv(POWERBI_DIR / "Purchase 1.csv")

    def test_powerbi_csv_purchase2(self):
        self._run_csv(POWERBI_DIR / "Purchase 2.csv")

    def test_powerbi_csv_purchase3(self):
        self._run_csv(POWERBI_DIR / "Purchase 3.csv")

    def test_powerbi_csv_sales(self):
        self._run_csv(POWERBI_DIR / "Sales 1.csv")

    def test_powerbi_csv_transportation(self):
        self._run_csv(POWERBI_DIR / "Transportation 1.csv")


# ======================================================================
#  2. Excel Converter
# ======================================================================
class TestExcelConverter(unittest.TestCase):
    """Validate ExcelConverter against every .xlsx / .xls in samples/."""

    def _run_excel(self, path: Path):
        converter = ExcelConverter()
        result = converter.convert(str(path))
        self.assertEqual(result["type"], "excel_workbook")
        self.assertIn("sheets", result)
        self.assertGreater(len(result["sheets"]), 0)
        _store("ExcelConverter", path.name, result)
        sheet_names = list(result["sheets"].keys())
        _print_ok(f"Excel -> {path.name} (sheets: {sheet_names})", {"type": result["type"], "sheets": sheet_names})
        return result

    def test_adf_sttm(self):
        self._run_excel(SAMPLES_DIR / "ADF_STTM.xlsx")

    def test_bquery_sttm(self):
        self._run_excel(SAMPLES_DIR / "BQuery_STTM.xlsx")

    def test_brd_questionnaire(self):
        self._run_excel(SAMPLES_DIR / "BRD-User story Datalake_Source_System_Questionnaire_Template_v3.0 3 2.xlsx")

    def test_dbt_sttm(self):
        self._run_excel(SAMPLES_DIR / "DBT_STTM.xlsx")

    def test_medium_l2_sttm(self):
        self._run_excel(SAMPLES_DIR / "Medium_L2_STTM_ADF_Input_Template.xlsx")

    def test_simple_sttm(self):
        self._run_excel(SAMPLES_DIR / "simple_STTM_Data Engineer 7.xlsx")

    def test_snowflake_sttm(self):
        self._run_excel(SAMPLES_DIR / "Snowflake_STTM.xlsx")

    def test_sample_xls(self):
        self._run_excel(SAMPLES_DIR / "sample.xls")


# ======================================================================
#  3. Text Converter (txt, md, py, sql, log)
# ======================================================================
class TestTextConverter(unittest.TestCase):
    """Validate TextConverter for all text-based extensions."""

    def _run_text(self, path: Path):
        converter = TextConverter()
        result = converter.convert(str(path))
        self.assertIn(result["type"], ("text_file", "code_file"))
        self.assertIn("summary", result)
        _store("TextConverter", path.name, result)
        _print_ok(f"Text -> {path.name}", result)
        return result

    def test_sample_txt(self):
        self._run_text(SAMPLES_DIR / "sample.txt")

    def test_sample_md(self):
        self._run_text(SAMPLES_DIR / "sample.md")

    def test_sample_py(self):
        self._run_text(SAMPLES_DIR / "sample.py")

    def test_sample_sql(self):
        self._run_text(SAMPLES_DIR / "sample.sql")

    def test_sample_log(self):
        self._run_text(SAMPLES_DIR / "sample.log")

    def test_sttm_prompt_txt(self):
        self._run_text(SAMPLES_DIR / "STTM_to_BigQuery_Enterprise_Prompt.txt")


# ======================================================================
#  4. JSON Converter
# ======================================================================
class TestJsonConverter(unittest.TestCase):

    def test_sample_json(self):
        converter = JsonConverter()
        result = converter.convert(str(SAMPLES_DIR / "sample.json"))
        self.assertEqual(result["type"], "json_file")
        self.assertTrue(result["summary"]["is_valid_json"])
        _store("JsonConverter", "sample.json", result)
        _print_ok("JSON -> sample.json", result)


# ======================================================================
#  5. XML Converter
# ======================================================================
class TestXmlConverter(unittest.TestCase):

    def test_sample_xml(self):
        converter = XmlConverter()
        result = converter.convert(str(SAMPLES_DIR / "sample.xml"))
        self.assertEqual(result["type"], "xml_file")
        self.assertEqual(result["root_tag"], "root")
        _store("XmlConverter", "sample.xml", result)
        _print_ok("XML -> sample.xml", result)


# ======================================================================
#  6. PDF Converter (mocked internals)
# ======================================================================
class TestPdfConverter(unittest.TestCase):

    @patch("daan.utils.converters.pdf_converter.PDF_AVAILABLE", True)
    @patch.object(PdfConverter, "_extract_pdf_with_pdfplumber")
    @patch.object(PdfConverter, "_extract_pdf_structure")
    def test_sample_pdf_mocked(self, extract_structure, extract_plumber):
        extract_plumber.return_value = {
            "pages": [{"page_number": 1, "text": "DAAN Sample PDF\nBody text", "tables": [], "char_count": 26}]
        }
        extract_structure.return_value = {"Title": {"content": "Body text", "type": "section_content"}}

        converter = PdfConverter()
        result = converter.convert(str(SAMPLES_DIR / "sample.pdf"))

        self.assertEqual(result["type"], "pdf_file")
        self.assertEqual(result["summary"]["total_pages"], 1)
        _store("PdfConverter", "sample.pdf", result)
        _print_ok("PDF -> sample.pdf (mocked)", result)


# ======================================================================
#  7. DOCX Converter (mocked python-docx)
# ======================================================================
class _FakeStyle:
    def __init__(self, name):
        self.name = name


class _FakeParagraph:
    def __init__(self, text, style_name="Normal"):
        self.text = text
        self.style = _FakeStyle(style_name)
        self.runs = []


class _FakeDoc:
    def __init__(self):
        self.paragraphs = [
            _FakeParagraph("DAAN Test Document", "Heading 1"),
            _FakeParagraph("This is sample content for testing the DOCX converter."),
        ]
        self.tables = []


class TestDocxConverter(unittest.TestCase):

    @patch("daan.utils.converters.docx_converter.DOCX_AVAILABLE", True)
    @patch("daan.utils.converters.docx_converter.Document")
    @patch.object(DocxConverter, "_extract_docx_structure")
    @patch.object(DocxConverter, "_extract_docx_tables")
    @patch.object(DocxConverter, "_extract_docx_embedded_files")
    def test_sample_docx_mocked(self, embed_mock, tables_mock, structure_mock, doc_mock):
        doc_mock.return_value = _FakeDoc()
        structure_mock.return_value = {
            "DAAN Test Document": {"content": "This is sample content.", "header_type": "heading"}
        }
        tables_mock.return_value = []
        embed_mock.return_value = {"files": [], "embedded_content": "", "count": 0, "file_types": []}

        converter = DocxConverter()
        result = converter.convert(str(SAMPLES_DIR / "sample.docx"))

        self.assertEqual(result["type"], "docx_file")
        self.assertIn("structured_sections", result)
        _store("DocxConverter", "sample.docx", result)
        _print_ok("DOCX -> sample.docx (mocked)", result)


# ======================================================================
#  8. Power BI Converters (PBIT / PBIX / PBIP)
# ======================================================================
class TestPowerBIConverters(unittest.TestCase):

    def test_pbit_converter(self):
        converter = PbitConverter()
        with patch.object(converter, "_parse_pbit_layout", return_value={"layout": "ok"}):
            result = converter.convert(str(SAMPLES_DIR / "sample.pbit"))
        self.assertEqual(result["type"], "pbit_file")
        _store("PbitConverter", "sample.pbit", result)
        _print_ok("PBIT -> sample.pbit", result)

    def test_pbix_converter(self):
        converter = PbixConverter()
        with patch.object(converter, "_parse_pbix_model", return_value={"model": "ok"}):
            result = converter.convert(str(SAMPLES_DIR / "sample.pbix"))
        self.assertEqual(result["type"], "pbix_file")
        _store("PbixConverter", "sample.pbix", result)
        _print_ok("PBIX -> sample.pbix", result)

    def test_pbip_converter(self):
        converter = PbipConverter()
        with patch.object(
            converter,
            "_parse_pbip_project",
            return_value={"model": {"m": 1}, "layout": {"l": 1}, "source": {"s": 1}},
        ):
            result = converter.convert(str(SAMPLES_DIR / "sample.pbip"))
        self.assertEqual(result["type"], "pbip_project")
        self.assertIn("model", result)
        _store("PbipConverter", "sample.pbip", result)
        _print_ok("PBIP -> sample.pbip", result)

    def test_pbip_real_folder_structure(self):
        """Parse the real sample.pbip folder we created."""
        converter = PbipConverter()
        result = converter._parse_pbip_project(str(SAMPLES_DIR / "sample.pbip"))
        self.assertIn("model", result)
        self.assertIn("layout", result)
        self.assertEqual(result["source"]["fileType"], "PBIP")
        self.assertEqual(len(result["model"]["tables"]), 1)
        _store("PbipConverter", "sample.pbip_folder", result)
        _print_ok("PBIP folder parse", result)


# ======================================================================
#  9. Tableau Converter (TWB / TWBX)
# ======================================================================
class TestTableauConverter(unittest.TestCase):

    def test_twb(self):
        converter = TableauConverter()
        result = converter.convert(str(SAMPLES_DIR / "sample.twb"))
        self.assertEqual(result["type"], "tableau_file")
        self.assertIn("summary", result)
        _store("TableauConverter", "sample.twb", result)
        _print_ok("TWB -> sample.twb", result)

    def test_twbx(self):
        converter = TableauConverter()
        result = converter.convert(str(SAMPLES_DIR / "sample.twbx"))
        self.assertEqual(result["type"], "tableau_file")
        _store("TableauConverter", "sample.twbx", result)
        _print_ok("TWBX -> sample.twbx", result)


# ======================================================================
# 10. FileToJsonConverter (orchestrator)
# ======================================================================
class TestFileToJsonConverter(unittest.TestCase):
    """Validate the main orchestrator: convert_file_to_json, convert_directory_to_json."""

    def setUp(self):
        self.converter = FileToJsonConverter()

    # --- convert_file_to_json ---

    def test_dispatch_csv(self):
        result = self.converter.convert_file_to_json(str(SAMPLES_DIR / "sample.csv"))
        self.assertEqual(result["file_type"], ".csv")
        self.assertIn("content", result)
        _store("FileToJsonConverter", "dispatch_csv", result)
        _print_ok("FileToJson -> sample.csv", result)

    def test_dispatch_json(self):
        result = self.converter.convert_file_to_json(str(SAMPLES_DIR / "sample.json"))
        self.assertEqual(result["file_type"], ".json")
        _store("FileToJsonConverter", "dispatch_json", result)
        _print_ok("FileToJson -> sample.json", result)

    def test_dispatch_xml(self):
        result = self.converter.convert_file_to_json(str(SAMPLES_DIR / "sample.xml"))
        self.assertEqual(result["file_type"], ".xml")
        _store("FileToJsonConverter", "dispatch_xml", result)
        _print_ok("FileToJson -> sample.xml", result)

    def test_dispatch_txt(self):
        result = self.converter.convert_file_to_json(str(SAMPLES_DIR / "sample.txt"))
        self.assertEqual(result["file_type"], ".txt")
        _store("FileToJsonConverter", "dispatch_txt", result)
        _print_ok("FileToJson -> sample.txt", result)

    def test_dispatch_sql(self):
        result = self.converter.convert_file_to_json(str(SAMPLES_DIR / "sample.sql"))
        self.assertEqual(result["file_type"], ".sql")
        _store("FileToJsonConverter", "dispatch_sql", result)
        _print_ok("FileToJson -> sample.sql", result)

    def test_dispatch_md(self):
        result = self.converter.convert_file_to_json(str(SAMPLES_DIR / "sample.md"))
        self.assertEqual(result["file_type"], ".md")
        _store("FileToJsonConverter", "dispatch_md", result)
        _print_ok("FileToJson -> sample.md", result)

    def test_dispatch_py(self):
        result = self.converter.convert_file_to_json(str(SAMPLES_DIR / "sample.py"))
        self.assertEqual(result["file_type"], ".py")
        _store("FileToJsonConverter", "dispatch_py", result)
        _print_ok("FileToJson -> sample.py", result)

    def test_dispatch_log(self):
        result = self.converter.convert_file_to_json(str(SAMPLES_DIR / "sample.log"))
        self.assertEqual(result["file_type"], ".log")
        _store("FileToJsonConverter", "dispatch_log", result)
        _print_ok("FileToJson -> sample.log", result)

    def test_dispatch_excel_xlsx(self):
        result = self.converter.convert_file_to_json(str(SAMPLES_DIR / "ADF_STTM.xlsx"))
        self.assertEqual(result["file_type"], ".xlsx")
        _store("FileToJsonConverter", "dispatch_xlsx", result)
        _print_ok("FileToJson -> ADF_STTM.xlsx", result)

    def test_dispatch_excel_xls(self):
        result = self.converter.convert_file_to_json(str(SAMPLES_DIR / "sample.xls"))
        self.assertEqual(result["file_type"], ".xls")
        _store("FileToJsonConverter", "dispatch_xls", result)
        _print_ok("FileToJson -> sample.xls", result)

    def test_dispatch_twb(self):
        result = self.converter.convert_file_to_json(str(SAMPLES_DIR / "sample.twb"))
        self.assertEqual(result["file_type"], ".twb")
        _store("FileToJsonConverter", "dispatch_twb", result)
        _print_ok("FileToJson -> sample.twb", result)

    # --- unsupported / missing ---

    def test_unsupported_extension_fallback(self):
        with tempfile.TemporaryDirectory() as td:
            fp = Path(td) / "data.zzz"
            fp.write_text("some content", encoding="utf-8")
            result = self.converter.convert_file_to_json(str(fp))
            self.assertEqual(result["type"], "binary_file_as_text")
            _store("FileToJsonConverter", "unsupported_ext", result)
            _print_ok("FileToJson -> unsupported .zzz", result)

    def test_missing_file_raises(self):
        with self.assertRaises(FileNotFoundError):
            self.converter.convert_file_to_json("/nonexistent/file.csv")

    # --- is_file_supported ---

    def test_is_file_supported_csv(self):
        self.assertTrue(self.converter.is_file_supported("test.csv"))

    def test_is_file_supported_unknown(self):
        self.assertFalse(self.converter.is_file_supported("test.zzz"))

    # --- get_supported_file_types ---

    def test_supported_types_include_all(self):
        types = self.converter.get_supported_file_types()
        for ext in [".csv", ".xlsx", ".xls", ".txt", ".json", ".xml", ".pdf",
                    ".docx", ".pbit", ".pbix", ".pbip", ".twb", ".twbx",
                    ".md", ".py", ".sql", ".log"]:
            self.assertIn(ext, types, f"{ext} not in supported types")

    # --- convert_directory_to_json ---

    def test_convert_directory_non_recursive(self):
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "a.txt").write_text("aaa", encoding="utf-8")
            (Path(td) / "b.csv").write_text("x,y\n1,2\n", encoding="utf-8")
            result = self.converter.convert_directory_to_json(td, recursive=False)
            self.assertIn("conversion_summary", result)
            self.assertEqual(result["conversion_summary"]["total_files"], 2)
            _store("FileToJsonConverter", "directory_non_recursive", result)
            _print_ok("Dir non-recursive", result)

    def test_convert_directory_recursive(self):
        with tempfile.TemporaryDirectory() as td:
            sub = Path(td) / "sub"
            sub.mkdir()
            (Path(td) / "root.txt").write_text("r", encoding="utf-8")
            (sub / "nested.txt").write_text("n", encoding="utf-8")
            result = self.converter.convert_directory_to_json(td, recursive=True)
            self.assertTrue(result["recursive_processing"])
            self.assertEqual(result["conversion_summary"]["total_files"], 2)
            _store("FileToJsonConverter", "directory_recursive", result)
            _print_ok("Dir recursive", result)

    def test_convert_samples_directory(self):
        """Convert the full samples directory (non-recursive) and verify summary."""
        result = self.converter.convert_directory_to_json(str(SAMPLES_DIR), recursive=False)
        summary = result["conversion_summary"]
        self.assertGreater(summary["total_files"], 0)
        print(f"  [OK] Full samples dir: {summary['successful_conversions']}/{summary['total_files']} converted")
        _store("FileToJsonConverter", "full_samples_dir", result)

    def test_convert_powerbi_inputs_directory(self):
        """Convert the Power BI - Inputs sub-directory."""
        result = self.converter.convert_directory_to_json(str(POWERBI_DIR), recursive=False)
        summary = result["conversion_summary"]
        self.assertGreater(summary["total_files"], 0)
        self.assertGreater(summary["successful_conversions"], 0)
        print(f"  [OK] Power BI dir: {summary['successful_conversions']}/{summary['total_files']} converted")
        _store("FileToJsonConverter", "powerbi_dir", result)


# ======================================================================
# 11. JSON output storage & validation
# ======================================================================
class TestJsonOutputStorage(unittest.TestCase):
    """Write JSON outputs to the results/ directory for permanent storage."""

    def test_store_all_json_outputs(self):
        """Convert every sample file and write individual JSON outputs."""
        converter = FileToJsonConverter()
        output_dir = Path(__file__).resolve().parent / "results" / "converter_outputs"
        output_dir.mkdir(parents=True, exist_ok=True)
        errors = []

        for sample_file in sorted(SAMPLES_DIR.iterdir()):
            if sample_file.is_dir():
                continue
            try:
                result = converter.convert_file_to_json(str(sample_file))
                out_path = output_dir / f"{sample_file.stem}.output.json"
                out_path.write_text(json.dumps(result, default=str, indent=2), encoding="utf-8")
                self.assertIn("content", result)
                print(f"  [OK] Stored {out_path.name}")
            except Exception as e:
                errors.append(f"{sample_file.name}: {e}")

        print(f"\n  JSON outputs stored in: {output_dir}")
        if errors:
            print(f"  Conversion errors ({len(errors)}):")
            for err in errors:
                print(f"    - {err}")
        # Allow a few failures (e.g. binary files) but most should succeed
        total = sum(1 for f in SAMPLES_DIR.iterdir() if f.is_file())
        self.assertLessEqual(len(errors), total // 2, f"Too many errors: {errors}")


# ======================================================================
# Summary printer
# ======================================================================
class TestZZZSummary(unittest.TestCase):
    """Runs last (alphabetically) to print the full results summary."""

    def test_print_summary(self):
        print("\n" + "=" * 70)
        print("CONVERTER TEST RESULTS SUMMARY")
        print("=" * 70)
        for cls_name, tests in sorted(ALL_RESULTS.items()):
            print(f"\n  {cls_name} ({len(tests)} tests):")
            for test_name, result in sorted(tests.items()):
                rtype = result.get("type") or result.get("file_type") or "?"
                print(f"    - {test_name}: type={rtype}")
        total = sum(len(v) for v in ALL_RESULTS.values())
        print(f"\n  Total stored results: {total}")
        print("=" * 70)


if __name__ == "__main__":
    unittest.main(verbosity=2)
