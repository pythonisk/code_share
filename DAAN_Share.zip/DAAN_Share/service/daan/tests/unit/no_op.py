# To test if the tool is working correctly
def no_op():
    pass