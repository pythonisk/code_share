"""Unit tests for Snowflake MCP SQL extraction and splitting helpers."""

import sys
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[4]
SERVICE_DIR = PROJECT_ROOT / "service"
if str(SERVICE_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_DIR))

from daan.mcp_servers.snowflake_mcp_server import (  # noqa: E402
    _classify_statement,
    _extract_sql_text,
    _split_sql_statements,
)


class TestSnowflakeMcpServerSql(unittest.TestCase):
    def test_extracts_sql_from_fenced_block(self):
        content = "Before text\n```sql\nSELECT CURRENT_VERSION();\n```\nAfter text"
        extracted = _extract_sql_text(content)
        self.assertEqual(extracted, "SELECT CURRENT_VERSION();")

    def test_extracts_plain_sql_from_mixed_content(self):
        content = "Use this query for validation:\nSELECT CURRENT_DATABASE();"
        extracted = _extract_sql_text(content)
        self.assertEqual(extracted, "SELECT CURRENT_DATABASE();")

    def test_splits_procedure_body_as_single_statement(self):
        sql = """
        CREATE OR REPLACE PROCEDURE demo_proc()
        RETURNS STRING
        LANGUAGE SQL
        AS
        $$
        BEGIN
          LET query STRING := 'SELECT 1;';
          RETURN query;
        END;
        $$;
        SELECT CURRENT_VERSION();
        """
        statements = _split_sql_statements(sql)
        self.assertEqual(len(statements), 2)
        self.assertTrue(statements[0].startswith("CREATE OR REPLACE PROCEDURE"))
        self.assertEqual(statements[1], "SELECT CURRENT_VERSION()")

    def test_classifies_fetch_and_non_fetch_statements(self):
        self.assertEqual(_classify_statement("SELECT * FROM demo"), ("select", True))
        self.assertEqual(_classify_statement("CREATE TABLE demo(id INT)"), ("create", False))
        self.assertEqual(_classify_statement("INSERT INTO demo VALUES (1)"), ("insert", False))


if __name__ == "__main__":
    unittest.main()