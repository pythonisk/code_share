import sys
from pathlib import Path

import pytest


# Ensure `import daan` works when pytest is invoked from the repo root.
_SERVICE_DIR = Path(__file__).resolve().parents[3]
if str(_SERVICE_DIR) not in sys.path:
    sys.path.insert(0, str(_SERVICE_DIR))


from daan.utils.log_sanitizer import sanitize_log_line


def test_redacts_bearer_token() -> None:
    line = "Authorization: Bearer abc.def.ghi"
    redacted, summary = sanitize_log_line(line)
    assert "Bearer <REDACTED>" in redacted
    assert summary.get("bearer", 0) >= 1


def test_strips_plaintext_prefix_and_extras() -> None:
    line = (
        "2026-04-19 21:19:44 | INFO | daan.session | sanity_event | "
        "session_id='session_sanity_1' actor='sanity' action='run'"
    )
    redacted, _summary = sanitize_log_line(line)
    assert redacted == "sanity_event"


@pytest.mark.parametrize(
    "line,expected",
    [
        (
            "Wrote agent output for AGENT_1 (C:/Users/alice/OneDrive - LTIMindtree/Desktop/file.md)",
            "Wrote agent output for AGENT_1",
        ),
        (
            "Wrote agent score for AGENT_1 (C:/Users/alice/OneDrive - LTIMindtree/Desktop/score.json)",
            "Wrote agent score for AGENT_1",
        ),
    ],
)
def test_trims_agent_write_paths(line: str, expected: str) -> None:
    redacted, _summary = sanitize_log_line(line)
    assert redacted == expected


@pytest.mark.parametrize(
    "line,expected",
    [
        (
            "Wrote feedback text for AGENT_1 (C:/Users/alice/OneDrive - LTIMindtree/Desktop/feedback.txt)",
            "Wrote feedback text for AGENT_1",
        ),
        (
            "Wrote feedback sample schema for AGENT_1 (C:/Users/alice/OneDrive - LTIMindtree/Desktop/sample_schema.json)",
            "Wrote feedback sample schema for AGENT_1",
        ),
    ],
)
def test_trims_feedback_write_paths(line: str, expected: str) -> None:
    redacted, _summary = sanitize_log_line(line)
    assert redacted == expected


def test_drops_any_remaining_path_payload() -> None:
    line = (
        "Created session directory: C:/Users/alice/OneDrive - LTIMindtree/Desktop/GENAI COE/TASKS/DAAN_v5.0/DAAN_5/session_storage/abc"
    )
    redacted, _summary = sanitize_log_line(line)
    assert redacted == "Created session directory:"


def test_keeps_selected_state_change_extras() -> None:
    line = (
        "2026-04-24 21:52:56 | INFO | daan.flow.session_store | Session state changed | "
        "session_id='94027968-9baa-49df-9921-872402bd13d8' old_state='INITIALIZED' "
        "new_state='CONTEXT_MAPPED' archetype='Customer Proposed Use Cases'"
    )
    redacted, _summary = sanitize_log_line(line)
    assert "Session state changed" in redacted
    assert "old_state=INITIALIZED" in redacted
    assert "new_state=CONTEXT_MAPPED" in redacted
    assert "archetype=Customer Proposed Use Cases" in redacted
    assert "94027968-9baa" not in redacted


def test_keeps_selected_file_upload_extras() -> None:
    line = (
        "2026-04-24 18:28:03 | INFO | daan.api.v1.endpoints.sessions | File upload requested | "
        "session_id='0e8718df-1ec7-4ad9-95e8-111a019c20c2' endpoint='/upload-files' file_count=1 "
        "filenames=['questionnaire_context_123.csv']"
    )
    redacted, _summary = sanitize_log_line(line)
    assert redacted.startswith("File upload requested")
    assert "filenames=['questionnaire_context_123.csv']" in redacted
    assert "endpoint=" not in redacted
    assert "file_count=" not in redacted
    assert "0e8718df-1ec7" not in redacted


def test_keeps_selected_files_uploaded_extras() -> None:
    line = (
        "2026-04-24 18:28:03 | INFO | daan.api.v1.endpoints.sessions | Files uploaded successfully | "
        "session_id='0e8718df-1ec7-4ad9-95e8-111a019c20c2' endpoint='/upload-files' uploaded_count=1 "
        "uploaded_files=['questionnaire_context_123.csv']"
    )
    redacted, _summary = sanitize_log_line(line)
    assert redacted.startswith("Files uploaded successfully")
    assert "uploaded_files=['questionnaire_context_123.csv']" in redacted
    assert "endpoint=" not in redacted
    assert "uploaded_count=" not in redacted
    assert "0e8718df-1ec7" not in redacted


def test_redacts_jwt_like_token() -> None:
    line = "token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c2VyIn0.sgnaturepart"
    redacted, summary = sanitize_log_line(line)
    assert "<REDACTED>" in redacted
    assert summary.get("jwt", 0) >= 1


@pytest.mark.parametrize(
    "line",
    [
        "api_key=sk-aaaaaaaaaaaaaaaaaaaaaaaa",
        "password: supersecret",
        "client_secret='verysecret'",
        "refresh_token=xyz123",
    ],
)
def test_redacts_keyvalue_secrets(line: str) -> None:
    redacted, summary = sanitize_log_line(line)
    assert "<REDACTED>" in redacted
    assert summary.get("keyvalue_secret", 0) >= 1


def test_redacts_email() -> None:
    line = "user email is alice@example.com"
    redacted, summary = sanitize_log_line(line)
    assert "<REDACTED_EMAIL>" in redacted
    assert summary.get("email", 0) == 1


@pytest.mark.parametrize(
    "line,expected",
    [
        (r"C:\\Users\\alice\\secrets\\file.txt", "<PATH>"),
        (r"error at C:\\temp\\debug.log", "error at"),
        (r"C:/Users/alice/secrets/file.txt", "<PATH>"),
        (r"session_storage/abc123/agents/planner/output.md", "<PATH>"),
        ("/home/alice/.ssh/id_rsa", "<PATH>"),
        ("/Users/bob/Documents/report.txt", "<PATH>"),
    ],
)
def test_redacts_absolute_paths(line: str, expected: str) -> None:
    redacted, summary = sanitize_log_line(line)
    assert redacted == expected
    assert summary.get("path", 0) >= 1


def test_redacts_connection_string() -> None:
    line = "postgresql://user:pass@localhost:5432/dbname"
    redacted, summary = sanitize_log_line(line)
    assert "postgresql://<redacted>" in redacted.lower()
    assert summary.get("connection_string", 0) >= 1
