from types import SimpleNamespace
from unittest.mock import patch

from sqlalchemy.exc import OperationalError

from daan.core.config import Settings
from daan.main import _init_db_with_retry
from daan.vector_stores.providers.postgres_vector_store import PostgresVectorStore


SETTINGS_NO_ENV = {"_env_file": None, "_env_file_encoding": None}


def _build_settings(**kwargs) -> Settings:
    with patch.dict("os.environ", {}, clear=True):
        return Settings(**SETTINGS_NO_ENV, **kwargs)


def test_database_url_prefers_legacy_mysql_db_names() -> None:
    settings = _build_settings(
        DB_TYPE="mysql",
        DB_HOST="legacy-host",
        DB_PORT=3306,
        DB_NAME="legacydb",
        DB_USER="legacyuser",
        DB_PASSWORD="legacypass",
        DB1_TYPE="postgresql",
        DB1_HOST="vector-host",
        DB1_PORT=5432,
        DB1_NAME="vectordb",
        DB1_USER="vectoruser",
        DB1_PASSWORD="vectorpass",
    )

    assert settings.DATABASE_URL == "mysql+pymysql://legacyuser:legacypass@legacy-host:3306/legacydb"


def test_database_url_falls_back_to_sqlite_when_no_app_db_is_configured() -> None:
    settings = _build_settings()

    assert settings.DATABASE_URL.startswith("sqlite:///")


def test_get_vector_database_url_prefers_db1_when_it_is_postgresql() -> None:
    settings = _build_settings(
        DB_TYPE="mysql",
        DB_HOST="legacy-host",
        DB_PORT=3306,
        DB_NAME="legacydb",
        DB_USER="legacyuser",
        DB_PASSWORD="legacypass",
        DB1_TYPE="postgresql",
        DB1_HOST="vector-host",
        DB1_PORT=5432,
        DB1_NAME="vectordb",
        DB1_USER="vectoruser",
        DB1_PASSWORD="vectorpass",
    )

    assert settings.get_vector_database_url() == "postgresql+psycopg://vectoruser:vectorpass@vector-host:5432/vectordb"


def test_get_vector_database_url_falls_back_to_db2_for_older_layout() -> None:
    settings = _build_settings(
        DB1_TYPE="mysql",
        DB1_HOST="localhost",
        DB1_PORT=3306,
        DB1_NAME="appdb",
        DB1_USER="appuser",
        DB1_PASSWORD="apppass",
        DB2_TYPE="postgresql",
        DB2_HOST="vector-host",
        DB2_PORT=5432,
        DB2_NAME="vectordb",
        DB2_USER="vectoruser",
        DB2_PASSWORD="vectorpass",
    )

    assert settings.get_vector_database_url() == "postgresql+psycopg://vectoruser:vectorpass@vector-host:5432/vectordb"


def test_get_vector_database_url_returns_none_when_no_vector_credentials_are_available() -> None:
    settings = _build_settings(
        DB_TYPE="mysql",
        DB_HOST="legacy-host",
        DB_PORT=3306,
        DB_NAME="legacydb",
        DB_USER="legacyuser",
        DB_PASSWORD="legacypass",
        DB1_TYPE="postgresql",
        DB1_HOST=None,
        DB1_PORT=5432,
        DB1_NAME=None,
        DB1_USER=None,
        DB1_PASSWORD=None,
    )

    assert settings.get_vector_database_url() is None


def test_postgres_vector_store_fails_cleanly_without_vector_database_url() -> None:
    settings = SimpleNamespace(get_vector_database_url=lambda: None)

    with patch("daan.vector_stores.providers.postgres_vector_store.get_settings", return_value=settings):
        try:
            PostgresVectorStore({"embedding_dimension": 1536, "schema": "rag_vectors"})
        except ValueError as exc:
            assert str(exc) == "PostgresVectorStore requires a PostgreSQL database URL"
        else:
            raise AssertionError("Expected PostgresVectorStore to reject missing vector DB configuration")


def test_init_db_with_retry_falls_back_to_sqlite_in_development() -> None:
    logger = SimpleNamespace(warning=lambda *args, **kwargs: None, debug=lambda *args, **kwargs: None)
    db_error = OperationalError("SELECT 1", {}, Exception("db down"))
    settings = SimpleNamespace(
        ENVIRONMENT="development",
        APP_DB_ENABLE_STARTUP_SQLITE_FALLBACK=True,
        DATABASE_URL="postgresql+psycopg://user:pass@remote-host:5432/appdb",
    )

    with patch("daan.main.get_settings", return_value=settings), \
        patch("daan.main.init_db", side_effect=[db_error, None]) as init_db_mock, \
        patch("daan.main.activate_sqlite_fallback", return_value="sqlite:///fallback.db") as fallback_mock, \
        patch("daan.main.engine.dispose") as dispose_mock:
        _init_db_with_retry(logger, attempts=1, delay=0)

    fallback_mock.assert_called_once_with()
    dispose_mock.assert_called_once_with()
    assert init_db_mock.call_count == 2


def test_init_db_with_retry_does_not_fall_back_outside_development() -> None:
    logger = SimpleNamespace(warning=lambda *args, **kwargs: None, debug=lambda *args, **kwargs: None)
    db_error = OperationalError("SELECT 1", {}, Exception("db down"))
    settings = SimpleNamespace(
        ENVIRONMENT="production",
        APP_DB_ENABLE_STARTUP_SQLITE_FALLBACK=True,
        DATABASE_URL="postgresql+psycopg://user:pass@remote-host:5432/appdb",
    )

    with patch("daan.main.get_settings", return_value=settings), \
        patch("daan.main.init_db", side_effect=db_error), \
        patch("daan.main.activate_sqlite_fallback") as fallback_mock, \
        patch("daan.main.engine.dispose"):
        try:
            _init_db_with_retry(logger, attempts=1, delay=0)
        except OperationalError:
            pass
        else:
            raise AssertionError("Expected production startup to surface the database failure")

    fallback_mock.assert_not_called()