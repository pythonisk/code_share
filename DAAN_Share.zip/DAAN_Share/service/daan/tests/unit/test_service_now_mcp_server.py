import sys
import json
import unittest
from pathlib import Path
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[4]
SERVICE_DIR = PROJECT_ROOT / "service"
if str(SERVICE_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_DIR))

from daan.mcp_servers import service_now_mcp_server as snow_mcp  # noqa: E402


class TestPublishTriageDecision(unittest.TestCase):
    @patch("daan.mcp_servers.service_now_mcp_server._write_publish_event")
    @patch("daan.mcp_servers.service_now_mcp_server._api_patch")
    @patch("daan.mcp_servers.service_now_mcp_server._resolve_incident_sys_id")
    def test_publish_uses_single_patch_per_incident(
        self,
        mock_resolve_incident_sys_id,
        mock_api_patch,
        mock_write_publish_event,
    ):
        mock_resolve_incident_sys_id.return_value = ("sys-123", None)
        mock_api_patch.return_value = {
            "result": {
                "priority": "2",
                "impact": "1",
                "urgency": "2",
                "category": "network",
            }
        }

        result = snow_mcp.publish_triage_decision([
            {
                "incident_id": "INC0010001",
                "recommended_priority": "P2",
                "recommended_impact": "1",
                "recommended_urgency": "2",
                "recommended_category": "network",
                "comment": "triage note",
            }
        ])

        payload = json.loads(result)

        self.assertEqual(1, mock_api_patch.call_count)
        self.assertEqual(
            (
                "/api/now/table/incident/sys-123",
                {
                    "work_notes": "triage note",
                    "impact": "1",
                    "urgency": "2",
                    "category": "network",
                },
            ),
            mock_api_patch.call_args.args,
        )
        self.assertEqual("success", payload["status"])
        self.assertEqual("success", payload["results"][0]["update_status"])
        self.assertEqual("success", payload["results"][0]["comment_status"])
        self.assertEqual("success", payload["results"][0]["incident_status"])
        self.assertEqual(3, mock_write_publish_event.call_count)
