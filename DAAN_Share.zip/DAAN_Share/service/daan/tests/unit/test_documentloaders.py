from __future__ import annotations

import sys
import types
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[4]
SERVICE_DIR = PROJECT_ROOT / "service"
if str(SERVICE_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_DIR))

from daan.utils.documentloaders.base_loader import BaseDocumentLoader
from daan.utils.documentloaders.csv_loader import CsvDocumentLoader
from daan.utils.documentloaders.docx_loader import DocxDocumentLoader
from daan.utils.documentloaders.excel_loader import ExcelDocumentLoader
from daan.utils.documentloaders.json_loader import JsonDocumentLoader
from daan.utils.documentloaders.pdf_loader import PdfDocumentLoader
from daan.utils.documentloaders.ppt_loader import PptDocumentLoader
from daan.utils.documentloaders.sharepoint_loader import SharePointDocumentLoader
from daan.utils.documentloaders.text_loader import TextDocumentLoader


class _FakeDoc:
    def __init__(self, page_content: object, metadata: dict | None = None) -> None:
        self.page_content = page_content
        self.metadata = metadata or {}


def _install_fake_langchain_document_loaders(monkeypatch, **loader_classes: object) -> None:
    fake_submodule = types.ModuleType("langchain_community.document_loaders")
    for name, loader_class in loader_classes.items():
        setattr(fake_submodule, name, loader_class)

    fake_package = types.ModuleType("langchain_community")
    setattr(fake_package, "document_loaders", fake_submodule)

    monkeypatch.setitem(sys.modules, "langchain_community", fake_package)
    monkeypatch.setitem(sys.modules, "langchain_community.document_loaders", fake_submodule)


def test_base_payload_includes_common_metadata(tmp_path: Path) -> None:
    file_path = tmp_path / "sample.txt"
    file_path.write_text("hello", encoding="utf-8")

    payload = BaseDocumentLoader._build_payload(
        file_path=str(file_path),
        file_type="text",
        content={"type": "text_file", "content": "hello"},
    )

    metadata = payload.get("metadata", {})
    assert metadata.get("loader") == "text"
    assert metadata.get("extraction_method") == "unknown"
    assert isinstance(metadata.get("extraction_warnings"), list)
    assert isinstance(metadata.get("extraction_errors"), list)
    assert metadata.get("source_extension") == ".txt"


def test_text_loader_builtin_fallback_reader(tmp_path: Path) -> None:
    file_path = tmp_path / "fallback.txt"
    file_path.write_text("line1\nline2\n", encoding="utf-8")

    content, encoding = TextDocumentLoader._read_text_with_fallback(str(file_path), "utf-8")

    assert "line1" in content
    assert encoding in {"utf-8", "utf-8-sig", "latin-1", "utf-8-replace"}


def test_csv_loader_delimiter_detection(tmp_path: Path) -> None:
    file_path = tmp_path / "sample.csv"
    file_path.write_text("a;b\n1;2\n", encoding="utf-8")

    delimiter = CsvDocumentLoader._detect_delimiter(str(file_path), "utf-8")
    assert delimiter == ";"


def test_json_loader_depth_and_array_detection() -> None:
    nested = {"a": {"b": [{"c": 1}]}}
    assert JsonDocumentLoader._max_depth(nested) >= 4
    assert JsonDocumentLoader._has_arrays(nested) is True


def test_sharepoint_env_mapping(monkeypatch) -> None:
    monkeypatch.setenv("SHAREPOINT_TENANT_ID", "tenant")
    monkeypatch.setenv("SHAREPOINT_CLIENT_ID", "client")
    monkeypatch.setenv("SHAREPOINT_CLIENT_SECRET", "secret")
    monkeypatch.setenv("SHAREPOINT_SITE_ID", "site-id-abc")
    monkeypatch.setenv("SHAREPOINT_SITE_NAME", "DNA KA")

    creds = SharePointDocumentLoader._load_credentials_from_environment()

    assert creds.get("tenant_id") == "tenant"
    assert creds.get("client_id") == "client"
    assert creds.get("client_secret") == "secret"
    assert creds.get("site_id") == "site-id-abc"
    assert creds.get("site_name") == "DNA KA"


def test_text_loader_populates_summary_and_metadata(tmp_path: Path, monkeypatch) -> None:
    class FakeTextLoader:
        def __init__(self, file_path: str, encoding: str, autodetect_encoding: bool) -> None:
            self.file_path = file_path
            self.encoding = encoding
            self.autodetect_encoding = autodetect_encoding

        def load(self) -> list[_FakeDoc]:
            return [_FakeDoc("# Header\ncontent line")]

    _install_fake_langchain_document_loaders(monkeypatch, TextLoader=FakeTextLoader)

    file_path = tmp_path / "sample.md"
    file_path.write_text("dummy", encoding="utf-8")

    payload = TextDocumentLoader().load_document(str(file_path))
    summary = payload["content"]["summary"]
    metadata = payload["metadata"]

    assert summary["line_count"] >= 1
    assert summary["has_structured_sections"] is True
    assert metadata["extraction_method"] == "langchain_textloader"


def test_csv_loader_populates_schema_fields(tmp_path: Path, monkeypatch) -> None:
    class FakeCSVLoader:
        def __init__(self, **kwargs: object) -> None:
            self.kwargs = kwargs

        def load(self) -> list[_FakeDoc]:
            return [_FakeDoc("a: 1, b: 2", {"row": 1})]

    _install_fake_langchain_document_loaders(monkeypatch, CSVLoader=FakeCSVLoader)

    file_path = tmp_path / "sample.csv"
    file_path.write_text("a,b\n1,2\n", encoding="utf-8")
    payload = CsvDocumentLoader().load_document(str(file_path))

    summary = payload["content"]["summary"]
    assert summary["total_rows"] == 1
    assert summary["column_count"] >= 1
    assert payload["metadata"]["extraction_method"] == "langchain_csvloader"


def test_json_loader_marks_jq_parse_method(tmp_path: Path, monkeypatch) -> None:
    class FakeJSONLoader:
        def __init__(self, file_path: str, jq_schema: str, text_content: bool) -> None:
            self.file_path = file_path
            self.jq_schema = jq_schema
            self.text_content = text_content

        def load(self) -> list[_FakeDoc]:
            return [_FakeDoc({"a": [1, 2, 3]})]

    _install_fake_langchain_document_loaders(monkeypatch, JSONLoader=FakeJSONLoader)

    file_path = tmp_path / "sample.json"
    file_path.write_text("{}", encoding="utf-8")
    payload = JsonDocumentLoader().load_document(str(file_path))
    summary = payload["content"]["summary"]

    assert summary["parse_method"] == "jq"
    assert summary["has_arrays"] is True
    assert payload["metadata"]["extraction_method"] == "langchain_jsonloader"


def test_pdf_loader_uses_fallback_when_langchain_fails(tmp_path: Path, monkeypatch) -> None:
    class FakePyPDFLoader:
        def __init__(self, file_path: str) -> None:
            raise ValueError("boom")

    _install_fake_langchain_document_loaders(monkeypatch, PyPDFLoader=FakePyPDFLoader)

    monkeypatch.setattr(
        PdfDocumentLoader,
        "_load_with_pypdf",
        staticmethod(lambda file_path: ([{"page_number": 1, "text": "fallback", "tables": [], "char_count": 8, "rotation": 0, "extraction_status": "ok", "has_images": False, "detected_font_sizes": []}], "producer", False)),
    )

    file_path = tmp_path / "sample.pdf"
    file_path.write_bytes(b"%PDF-1.4")
    payload = PdfDocumentLoader().load_document(str(file_path))

    assert payload["metadata"]["extraction_method"] == "pypdf_reader"
    assert payload["content"]["summary"]["producer"] == "producer"
    assert payload["content"]["summary"]["total_pages"] == 1


def test_sharepoint_loader_resolves_drive_and_fetches_documents(monkeypatch) -> None:
    import daan.utils.documentloaders.sharepoint_loader as _sp_mod

    # Stub MSAL so no real network auth occurs.
    fake_msal = types.ModuleType("msal")
    class _FakeMSALApp:
        def __init__(self, *a, **kw): pass
        def acquire_token_for_client(self, **kw): return {"access_token": "tok"}
    fake_msal.ConfidentialClientApplication = _FakeMSALApp
    monkeypatch.setitem(sys.modules, "msal", fake_msal)

    def _fake_get(url, headers=None, timeout=None, allow_redirects=None):
        class _Resp:
            ok = True
            status_code = 200
            def raise_for_status(self): pass
            def json(self):
                # drive resolution endpoint
                if url.endswith("/drive"):
                    return {"id": "drive-xyz"}
                # item listing endpoint
                return {
                    "value": [{
                        "id": "f1",
                        "file": {},
                        "createdDateTime": "2024-01-01",
                        "lastModifiedDateTime": "2024-01-02",
                        "lastModifiedBy": {"user": {"displayName": "Alice"}},
                    }]
                }
            @property
            def content(self): return b"doc text"
        return _Resp()

    monkeypatch.setattr(_sp_mod.requests, "get", _fake_get)
    monkeypatch.setattr(
        _sp_mod,
        "load_local_document",
        lambda file_path: {"content": {"type": "text_file", "content": "doc text"}},
    )

    loader = SharePointDocumentLoader(config={
        "loader_kwargs": {
            "tenant_id": "t", "client_id": "c", "client_secret": "s",
            "site_id": "site-123", "site_name": "DNA KA",
        }
    })
    payload = loader.load_document("")

    assert payload["metadata"]["extraction_method"] == "msal_graph_api"
    assert payload["metadata"]["credentials_source"] == "config_dict"
    assert payload["content"]["summary"]["total_documents"] == 1
    assert payload["content"]["documents"][0]["sharepoint_id"] == "f1"
    assert payload["content"]["documents"][0]["modified_by"] == "Alice"


def test_sharepoint_loader_routes_downloaded_file_by_extension(monkeypatch) -> None:
    import daan.utils.documentloaders.sharepoint_loader as _sp_mod

    parsed_paths: list[str] = []

    def _fake_local_loader(file_path: str) -> dict:
        parsed_paths.append(file_path)
        return {"content": {"type": "pdf_file", "pages": [{"text": "pdf text"}]}}

    monkeypatch.setattr(_sp_mod, "load_local_document", _fake_local_loader)
    warnings: list[str] = []
    content = _sp_mod.SharePointDocumentLoader._parse_downloaded_content(
        "policy.pdf", b"pdf bytes", warnings
    )

    assert content == "pdf text"
    assert Path(parsed_paths[0]).suffix == ".pdf"
    assert warnings == []


def test_sharepoint_loader_recurses_nested_folders_and_paginates(monkeypatch) -> None:
    import daan.utils.documentloaders.sharepoint_loader as _sp_mod

    responses = {
        "/root:/D-AURA:/children": {
            "value": [
                {"id": "folder-1", "folder": {}},
                {"id": "file-root", "file": {}, "name": "root.txt"},
            ],
            "@odata.nextLink": "https://graph.test/root-page-2",
        },
        "https://graph.test/root-page-2": {
            "value": [{"id": "folder-1", "folder": {}}],
        },
        "/items/folder-1/children": {
            "value": [
                {"id": "folder-2", "folder": {}},
                {"id": "file-nested", "file": {}, "name": "nested.pdf"},
            ],
        },
        "/items/folder-2/children": {
            "value": [{"id": "file-deep", "file": {}, "name": "deep.docx"}],
        },
    }

    def _fake_get(url, headers=None, timeout=None, allow_redirects=None):
        class _Response:
            ok = True
            status_code = 200
            text = ""

            def json(self):
                for key, value in responses.items():
                    if key in url:
                        return value
                raise AssertionError(f"Unexpected URL: {url}")

        return _Response()

    monkeypatch.setattr(_sp_mod.requests, "get", _fake_get)
    warnings: list[str] = []
    items = _sp_mod.SharePointDocumentLoader._list_items("token", "drive", "D-AURA", warnings)

    assert {item["id"] for item in items} == {"file-root", "file-nested", "file-deep"}
    assert warnings == []


def test_sharepoint_loader_yields_bounded_document_batches(monkeypatch) -> None:
    import daan.utils.documentloaders.sharepoint_loader as _sp_mod

    monkeypatch.setenv("SHAREPOINT_TENANT_ID", "tenant")
    monkeypatch.setenv("SHAREPOINT_CLIENT_ID", "client")
    monkeypatch.setenv("SHAREPOINT_CLIENT_SECRET", "secret")
    monkeypatch.setenv("SHAREPOINT_SITE_ID", "site-id")
    monkeypatch.setenv("SHAREPOINT_SITE_NAME", "DNA KA")
    monkeypatch.setattr(_sp_mod.SharePointDocumentLoader, "_acquire_token", staticmethod(lambda *args: "token"))
    monkeypatch.setattr(_sp_mod.SharePointDocumentLoader, "_resolve_default_drive_id", staticmethod(lambda *args: "drive"))
    monkeypatch.setattr(
        _sp_mod.SharePointDocumentLoader,
        "_iter_item_batches",
        staticmethod(
            lambda *args: iter([
                [{"id": "f1", "name": "one.txt", "file": {}}],
                [{"id": "f2", "name": "two.txt", "file": {}}],
            ])
        ),
    )
    monkeypatch.setattr(_sp_mod.SharePointDocumentLoader, "_fetch_item_content", staticmethod(lambda *args: b"text"))
    monkeypatch.setattr(
        _sp_mod.SharePointDocumentLoader,
        "_parse_downloaded_content",
        staticmethod(lambda item_name, item_bytes, warnings: "parsed " + item_name),
    )

    batches = list(
        SharePointDocumentLoader(config={"loader_kwargs": {"folder_path": "D-AURA"}})
        .iter_document_batches("D-AURA", batch_size=1)
    )

    assert len(batches) == 2
    assert batches[0]["content"]["documents"][0]["content"] == "parsed one.txt"
    assert batches[1]["metadata"]["batch_number"] == 2


def test_sharepoint_loader_skips_already_indexed_sources(monkeypatch) -> None:
    import daan.utils.documentloaders.sharepoint_loader as _sp_mod

    def _fake_fetch_folder_items(url, headers):
        return (
            [
                {"id": "f1", "name": "already.xlsx", "file": {}, "parentReference": {"path": "root:/D-AURA"}},
                {"id": "f2", "name": "fresh.xlsx", "file": {}, "parentReference": {"path": "root:/D-AURA"}},
                    {"id": "f3", "name": "video.mp4", "file": {}, "parentReference": {"path": "root:/D-AURA"}},
            ],
            [],
        )

    monkeypatch.setattr(_sp_mod.SharePointDocumentLoader, "_fetch_folder_items", staticmethod(_fake_fetch_folder_items))

    batches = list(
        _sp_mod.SharePointDocumentLoader._iter_item_batches(
            "token", "drive", "D-AURA", 25, {"D-AURA\\already.xlsx"}
        )
    )
    names = [item["name"] for batch in batches for item in batch]

    assert names == ["fresh.xlsx"]


def test_sharepoint_loader_limits_discovery_to_max_candidates(monkeypatch) -> None:
    import daan.utils.documentloaders.sharepoint_loader as _sp_mod

    requested_urls: list[str] = []

    def _fake_fetch_folder_items(url, headers):
        requested_urls.append(url)
        if url.endswith("root:/D-AURA:/children"):
            return (
                [
                    {"id": "f1", "name": "first.xlsx", "file": {}},
                    {"id": "folder-1", "name": "nested", "folder": {}},
                ],
                [],
            )
        raise AssertionError(f"Unexpected nested-folder request: {url}")

    monkeypatch.setattr(_sp_mod.SharePointDocumentLoader, "_fetch_folder_items", staticmethod(_fake_fetch_folder_items))

    batches = list(_sp_mod.SharePointDocumentLoader._iter_item_batches("token", "drive", "D-AURA", 1, max_candidates=1))

    assert [item["name"] for batch in batches for item in batch] == ["first.xlsx"]
    assert len(requested_urls) == 1


def test_sharepoint_loader_continues_after_empty_candidate(monkeypatch) -> None:
    import daan.utils.documentloaders.sharepoint_loader as _sp_mod

    monkeypatch.setenv("SHAREPOINT_TENANT_ID", "tenant")
    monkeypatch.setenv("SHAREPOINT_CLIENT_ID", "client")
    monkeypatch.setenv("SHAREPOINT_CLIENT_SECRET", "secret")
    monkeypatch.setenv("SHAREPOINT_SITE_ID", "site-id")
    monkeypatch.setattr(_sp_mod.SharePointDocumentLoader, "_acquire_token", staticmethod(lambda *args: "token"))
    monkeypatch.setattr(_sp_mod.SharePointDocumentLoader, "_resolve_default_drive_id", staticmethod(lambda *args: "drive"))
    monkeypatch.setattr(
        _sp_mod.SharePointDocumentLoader,
        "_iter_item_batches",
        staticmethod(lambda *args: iter([
            [{"id": "f1", "name": "malformed.xlsx", "file": {}}],
            [{"id": "f2", "name": "valid.xlsx", "file": {}}],
        ])),
    )
    monkeypatch.setattr(_sp_mod.SharePointDocumentLoader, "_fetch_item_content", staticmethod(lambda *args: b"text"))
    monkeypatch.setattr(
        _sp_mod.SharePointDocumentLoader,
        "_parse_downloaded_content",
        staticmethod(lambda item_name, *args: "" if item_name == "malformed.xlsx" else "valid content"),
    )

    payloads = list(
        _sp_mod.SharePointDocumentLoader(
            config={
                "loader_kwargs": {
                    "folder_path": "D-AURA",
                    "max_files": 1,
                    "max_candidates": 2,
                    "parse_timeout_seconds": 0,
                }
            }
        ).iter_document_batches("D-AURA", batch_size=1)
    )

    assert len(payloads) == 1
    assert payloads[0]["metadata"]["sharepoint_name"] == "valid.xlsx"


def test_sharepoint_loader_filters_unsupported_file_types(monkeypatch) -> None:
    import daan.utils.documentloaders.sharepoint_loader as _sp_mod

    monkeypatch.setattr(
        _sp_mod.SharePointDocumentLoader,
        "_fetch_folder_items",
        staticmethod(
            lambda url, headers: (
                [
                    {"id": "f1", "name": "notes.txt", "file": {}},
                    {"id": "f2", "name": "video.mp4", "file": {}},
                ],
                [],
            )
        ),
    )

    batches = list(_sp_mod.SharePointDocumentLoader._iter_item_batches("token", "drive", "D-AURA", 25))

    assert [item["name"] for batch in batches for item in batch] == ["notes.txt"]


def test_sharepoint_source_identity_distinguishes_duplicate_filenames() -> None:
    import daan.utils.documentloaders.sharepoint_loader as _sp_mod

    first = {"id": "f1", "name": "case-study.pptx", "parentReference": {"path": "root:/D-AURA/01_CaseStudy"}}
    second = {"id": "f2", "name": "case-study.pptx", "parentReference": {"path": "root:/D-AURA/02_CaseStudy"}}

    assert _sp_mod.SharePointDocumentLoader._source_identity(first, "D-AURA") == "D-AURA\\01_CaseStudy\\case-study.pptx"
    assert _sp_mod.SharePointDocumentLoader._source_identity(second, "D-AURA") == "D-AURA\\02_CaseStudy\\case-study.pptx"


def test_docx_loader_uses_python_docx_fallback(monkeypatch, tmp_path: Path) -> None:
    class FakeDocx2txtLoader:
        def __init__(self, file_path: str) -> None:
            raise ValueError("docx loader failed")

    _install_fake_langchain_document_loaders(monkeypatch, Docx2txtLoader=FakeDocx2txtLoader)

    monkeypatch.setattr(
        DocxDocumentLoader,
        "_extract_with_python_docx",
        staticmethod(
            lambda file_path: {
                "text": "fallback docx text",
                "paragraph_count": 2,
                "tables": [{"table_index": 1, "rows": [["a", "b"]]}],
                "hyperlinks": [{"text": "", "url": "https://example.com"}],
                "image_count": 1,
                "core_props": {"author": "tester", "created": "", "modified": ""},
            }
        ),
    )

    file_path = tmp_path / "sample.docx"
    file_path.write_bytes(b"not-real-docx")

    payload = DocxDocumentLoader().load_document(str(file_path))
    summary = payload["content"]["summary"]

    assert payload["metadata"]["extraction_method"] == "python_docx"
    assert summary["paragraph_count"] == 2
    assert summary["table_count"] == 1
    assert summary["has_images"] is True


def test_excel_loader_uses_pandas_extraction(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(
        ExcelDocumentLoader,
        "_read_sheets_with_pandas",
        staticmethod(
            lambda file_path: (
                {
                    "Input": {
                        "sheet_name": "Input",
                        "tables": [
                            {
                                "table_name": "Input_table",
                                "table_type": "tabular",
                                "rows": [{"content": {"col1": "x"}, "metadata": {"sheet_name": "Input"}}],
                                "columns": ["col1"],
                                "shape": [1, 1],
                            }
                        ],
                        "sheet_analysis": {"detected_type": "data_table"},
                        "total_tables": 1,
                    }
                },
                ["Input"],
                {"Input": 1},
            )
        ),
    )

    file_path = tmp_path / "sample.xlsx"
    file_path.write_bytes(b"not-real-xlsx")

    payload = ExcelDocumentLoader().load_document(str(file_path))
    summary = payload["content"]["summary"]

    assert payload["metadata"]["extraction_method"] == "pandas_read_excel"
    assert summary["total_sheets"] == 1
    assert summary["per_sheet_row_counts"]["Input"] == 1


def test_excel_loader_returns_empty_payload_for_malformed_workbook(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(
        ExcelDocumentLoader,
        "_read_sheets_with_pandas",
        staticmethod(lambda file_path: (_ for _ in ()).throw(ValueError("Sheet name is an empty list"))),
    )

    file_path = tmp_path / "malformed.xlsx"
    file_path.write_bytes(b"not-real-xlsx")

    payload = ExcelDocumentLoader().load_document(str(file_path))

    assert payload["content"]["sheets"] == {}
    assert payload["content"]["summary"]["total_sheets"] == 0
    assert "Sheet name is an empty list" in payload["metadata"]["extraction_warnings"][0]


def test_sharepoint_loader_propagates_document_extraction_warnings(monkeypatch, tmp_path: Path) -> None:
    import daan.utils.documentloaders.sharepoint_loader as _sp_mod

    monkeypatch.setattr(
        _sp_mod,
        "load_local_document",
        lambda file_path: {
            "content": {"type": "excel_workbook", "sheets": {}},
            "metadata": {"extraction_warnings": ["Excel extraction failed: malformed workbook"]},
        },
    )

    warnings: list[str] = []

    assert _sp_mod.SharePointDocumentLoader._parse_downloaded_content("malformed.xlsx", b"content", warnings) == ""
    assert warnings == ["Excel extraction failed: malformed workbook"]


def test_sharepoint_loader_skips_parser_after_timeout(monkeypatch) -> None:
    import daan.utils.documentloaders.sharepoint_loader as _sp_mod

    terminated: list[bool] = []
    worker_args: list[tuple] = []

    class FakeQueue:
        def close(self) -> None:
            pass

        def join_thread(self) -> None:
            pass

    class FakeProcess:
        def start(self) -> None:
            pass

        def join(self, timeout=None) -> None:
            pass

        def is_alive(self) -> bool:
            return True

        def terminate(self) -> None:
            terminated.append(True)

    class FakeContext:
        def Queue(self):
            return FakeQueue()

        def Process(self, target, args):
            worker_args.extend(args)
            return FakeProcess()

    monkeypatch.setattr(_sp_mod.multiprocessing, "get_context", lambda name: FakeContext())

    content, warnings = _sp_mod.SharePointDocumentLoader._parse_downloaded_content_with_timeout(
        "slow.xlsx",
        b"content",
        60,
    )

    assert content == ""
    assert terminated == [True]
    assert warnings == ["SharePoint file parse timed out after 60s: slow.xlsx"]
    assert worker_args[0] == "slow.xlsx"
    assert Path(worker_args[1]).suffix == ".xlsx"
    assert worker_args[1] != b"content"
    assert Path(worker_args[1]).exists() is False


def test_ppt_loader_uses_python_pptx_fallback(monkeypatch, tmp_path: Path) -> None:
    class FakeUnstructuredPowerPointLoader:
        def __init__(self, file_path: str, mode: str) -> None:
            raise ValueError("ppt loader failed")

    _install_fake_langchain_document_loaders(monkeypatch, UnstructuredPowerPointLoader=FakeUnstructuredPowerPointLoader)

    monkeypatch.setattr(
        PptDocumentLoader,
        "_load_with_python_pptx",
        staticmethod(
            lambda file_path: [
                {
                    "slide_number": 1,
                    "text": "Slide body",
                    "char_count": 10,
                    "metadata": {},
                    "has_speaker_notes": True,
                    "speaker_notes": "notes",
                    "layout_type": "Title and Content",
                    "shapes_count": 3,
                }
            ]
        ),
    )

    file_path = tmp_path / "sample.pptx"
    file_path.write_bytes(b"not-real-pptx")

    payload = PptDocumentLoader().load_document(str(file_path))
    summary = payload["content"]["summary"]

    assert payload["metadata"]["extraction_method"] == "python_pptx"
    assert summary["total_slides"] == 1
    assert payload["content"]["slides"][0]["has_speaker_notes"] is True
