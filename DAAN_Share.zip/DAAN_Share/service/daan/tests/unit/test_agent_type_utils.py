from daan.agents.agent_type_utils import is_action_agent, is_chat_agent, normalize_agent_type
from daan.flow.session_store import WorkflowSession


def test_normalize_agent_type_recognizes_action_variants() -> None:
    assert normalize_agent_type("action_agent") == "action_agent"
    assert normalize_agent_type("actionagent") == "action_agent"
    assert normalize_agent_type("Custom_Action_Agent") == "action_agent"


def test_normalize_agent_type_defaults_subagents_to_dynamic() -> None:
    assert normalize_agent_type("") == "dynamic_agent"
    assert normalize_agent_type("sub-agent") == "dynamic_agent"
    assert normalize_agent_type("dynamic_agent") == "dynamic_agent"


def test_normalize_agent_type_recognizes_chat_variants() -> None:
    assert normalize_agent_type("chat_agent") == "chat_agent"
    assert normalize_agent_type("chatagent") == "chat_agent"
    assert normalize_agent_type("ChatBotAgent") == "chat_agent"


def test_session_splits_dynamic_and_action_agents_by_normalized_type() -> None:
    session = WorkflowSession(
        session_id="test-session",
        user_id=None,
        archetype="Customer Proposed Use Cases",
        usecase_id="UC_CP_006",
        context_map_result={
            "agents": [
                {"agent_id": "AGENT_13", "agent_type": "dynamic_agent"},
                {"agent_id": "AGENT_14", "agent_type": "actionagent"},
                {"agent_id": "AGENT_15", "agent_type": "Custom_Action_Agent"},
            ]
        },
    )

    assert [agent["agent_id"] for agent in session.get_dynamic_agents()] == ["AGENT_13"]
    assert [agent["agent_id"] for agent in session.get_action_agents()] == ["AGENT_14", "AGENT_15"]
    assert session.get_chat_agents() == []
    assert is_action_agent("actionagent") is True
    assert is_chat_agent("chatagent") is True