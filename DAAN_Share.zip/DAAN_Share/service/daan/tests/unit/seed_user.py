import sys
import os

# Ensure the DAAN_5/service directory is in the import path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../")))

try:
    from daan.models import role
    from daan.core.database import SessionLocal
    from daan.models import user, role, archetype  # Ensure all dependent models are loaded for SQLAlchemy registry
    from daan.schemas.user import UserCreate
    from daan.admin.user_service import create_user, get_user_by_username
    from daan.core.database import engine

    # Note: create_all is not strictly necessary if uvicorn already started, but we just verify it exists
    user.Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    existing = get_user_by_username(db, 'e2e_test_user')
    if not existing:
        user_in = UserCreate(
            username='e2e_test_user',
            email='e2e@test.com',
            firstname='E2E',
            lastname='Test',
            password='password123'
        )
        create_user(db, user_in)
        print('SUCCESS: E2E Test user created in database.')
    else:
        print('SUCCESS: E2E Test user already exists.')
    db.close()
except Exception as e:
    print(f"Failed to seed user: {e}")
    sys.exit(1)
