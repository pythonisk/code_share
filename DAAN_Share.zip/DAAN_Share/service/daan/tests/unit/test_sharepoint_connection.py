from __future__ import annotations

import os
from pathlib import Path

import msal
import requests
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[4]
load_dotenv(PROJECT_ROOT / "config" / ".env")

TENANT_ID = os.environ["SHAREPOINT_TENANT_ID"]
CLIENT_ID = os.environ["SHAREPOINT_CLIENT_ID"]
CLIENT_SECRET = os.environ["SHAREPOINT_CLIENT_SECRET"]
SITE_ID = os.environ["SHAREPOINT_SITE_ID"]

print("--- Step 1: Acquiring MSAL token ---")
app = msal.ConfidentialClientApplication(
    CLIENT_ID,
    authority=f"https://login.microsoftonline.com/{TENANT_ID}",
    client_credential=CLIENT_SECRET,
)
result = app.acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])
if "access_token" not in result:
    print("FAILED:", result.get("error_description") or result.get("error"))
    raise SystemExit(1)
print("OK - token acquired")

token = result["access_token"]
headers = {"Authorization": f"Bearer {token}"}

print("\n--- Step 2: Resolving default drive ---")
response = requests.get(
    f"https://graph.microsoft.com/v1.0/sites/{SITE_ID}/drive",
    headers=headers,
    timeout=30,
)
print("Status:", response.status_code)
response.raise_for_status()
drive = response.json()
drive_id = drive["id"]
print("Drive ID  :", drive_id)
print("Drive Name:", drive.get("name"))
print("Drive Type:", drive.get("driveType"))

print("\n--- Step 3: Listing root items ---")
items_response = requests.get(
    f"https://graph.microsoft.com/v1.0/drives/{drive_id}/root/children",
    headers=headers,
    timeout=30,
)
print("Status:", items_response.status_code)
items_response.raise_for_status()
items = items_response.json().get("value", [])
print("Items found:", len(items))
for item in items[:5]:
    kind = "(folder)" if "folder" in item else "(file)"
    print(" ", item.get("name"), kind)
