from __future__ import annotations

import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from fastapi import HTTPException

from daan.api.v1.endpoints.chat import _handle_chat_agent_message, send_message
from daan.flow.session_service import ensure_context_map_output, read_context_map_output


class _WorkflowSessionStub:
    def __init__(self) -> None:
        self.context_map_result: dict = {}
        self.archetype = ""
        self.usecase_id = ""
        self.context_map_output_path: str | None = None
        self.state = None

    def touch(self) -> None:
        return None


def test_ensure_context_map_output_seeds_canonical_payload(tmp_path) -> None:
    settings = SimpleNamespace(SESSION_STORAGE_DIR=str(tmp_path), load_rag_config=lambda: {})

    with patch("daan.flow.session_service.get_settings", return_value=settings):
        payload = ensure_context_map_output(
            "chat-agent-context-contract",
            agents=[{"agent_id": "chat1", "agent_type": "chat_agent"}],
            usecase_details={"dag": "chat1", "name": "Claims"},
        )
        reread = read_context_map_output("chat-agent-context-contract")

    assert payload == reread
    assert payload["agents"] == [{"agent_id": "chat1", "agent_type": "chat_agent"}]
    assert payload["usecase_details"] == {"dag": "chat1", "name": "Claims"}
    assert payload["context_map"] == {}
    assert payload["dag"] == "chat1"
    assert payload["token_usage"] == {}
def test_handle_chat_agent_message_uses_existing_rag_pipeline_with_vector_retrieval() -> None:
    rag_config = {
        "knowledge_bases": [
            {"id": "claims", "enabled": True, "system_prompt": "Claims persona"},
        ]
    }
    chat_agent = {
        "agent_id": "chat1",
        "agent_name": "Claims Chat",
        "agent_type": "chat_agent",
        "prompt": "Answer from the supplied context only.",
    }
    usecase_details = {
        "agents": [chat_agent],
        "usecase_details": {"dag": "chat1", "name": "Claims QA"},
    }
    canonical_context = {
        "agents": [chat_agent],
        "usecase_details": {"dag": "chat1", "name": "Claims QA"},
        "context_map": {"chat1": {"notes": "Uploaded policy context"}},
        "dag": "chat1",
        "token_usage": {},
    }
    workflow_session = _WorkflowSessionStub()
    mock_tool = MagicMock()
    mock_tool.search_documents.return_value = [
        {"id": "doc-1", "content": "Claim adjudication facts."},
    ]

    with patch("daan.api.v1.endpoints.chat.get_settings") as mock_get_settings, \
        patch("daan.api.v1.endpoints.chat.resolve_archetype_for_usecase", return_value="Data Pipeline"), \
        patch("daan.api.v1.endpoints.chat.get_usecase_details", return_value=usecase_details), \
        patch("daan.api.v1.endpoints.chat.read_chat_session_manifest", return_value={}), \
        patch("daan.api.v1.endpoints.chat.create_session_dir"), \
        patch("daan.api.v1.endpoints.chat.write_chat_session_manifest"), \
        patch("daan.api.v1.endpoints.chat.ensure_context_map_output", return_value=canonical_context), \
        patch("daan.api.v1.endpoints.chat.read_context_map_output", return_value=canonical_context), \
        patch("daan.api.v1.endpoints.chat.get_workflow_session", return_value=None), \
        patch("daan.api.v1.endpoints.chat.create_workflow_session", return_value=workflow_session), \
        patch("daan.api.v1.endpoints.chat.read_chat_session_messages", return_value=[]), \
        patch("daan.api.v1.endpoints.chat.append_chat_session_message"), \
        patch("daan.api.v1.endpoints.chat.RagTool", return_value=mock_tool), \
        patch("daan.api.v1.endpoints.chat._synthesize", return_value="Grounded answer") as mock_synthesize:
        mock_get_settings.return_value.load_rag_config.return_value = rag_config

        result = asyncio.run(
            _handle_chat_agent_message(
                session_id="chat-agent-session",
                message="How is the claim answered?",
                usecase_id="UC_CP_006",
                kb_id="claims",
                user_id=7,
                files=[],
            )
        )

    mock_tool.search_documents.assert_called_once_with(
        query="How is the claim answered?",
        k=8,
        retriever_type="vector",
        kb_id="claims",
        metadata_filter=None,
    )
    mock_synthesize.assert_called_once()
    assert result == {
        "response": "Grounded answer",
        "references": ["doc-1"],
        "session_id": "chat-agent-session",
        "mode": "chat_agent",
    }


def test_send_message_resumes_chat_agent_session_from_manifest_without_usecase_id() -> None:
    current_user = SimpleNamespace(id=7)
    db = MagicMock()
    expected = {
        "response": "Grounded answer",
        "references": ["doc-1"],
        "session_id": "chat-agent-session",
        "mode": "chat_agent",
    }

    with patch(
        "daan.api.v1.endpoints.chat.read_chat_session_manifest",
        return_value={"mode": "chat_agent", "usecase_id": "UC_CP_006", "kb_id": "claims"},
    ), patch(
        "daan.api.v1.endpoints.chat._is_chat_agent_usecase",
        return_value=True,
    ), patch(
        "daan.api.v1.endpoints.chat._handle_chat_agent_message",
        new_callable=AsyncMock,
        return_value=expected,
    ) as mock_handle:
        result = asyncio.run(
            send_message(
                db=db,
                current_user=current_user,
                message="Resume chat-agent session",
                session_id="chat-agent-session",
                usecase_id=None,
                kb_id=None,
                files=[],
            )
        )

    assert result == expected
    mock_handle.assert_awaited_once_with(
        session_id="chat-agent-session",
        message="Resume chat-agent session",
        usecase_id="UC_CP_006",
        kb_id=None,
        user_id=7,
        files=[],
    )


def test_send_message_rejects_mismatched_chat_agent_usecase_for_existing_session() -> None:
    current_user = SimpleNamespace(id=7)
    db = MagicMock()

    with patch(
        "daan.api.v1.endpoints.chat.read_chat_session_manifest",
        return_value={"mode": "chat_agent", "usecase_id": "UC_CP_006", "kb_id": "claims"},
    ):
        try:
            asyncio.run(
                send_message(
                    db=db,
                    current_user=current_user,
                    message="Resume chat-agent session",
                    session_id="chat-agent-session",
                    usecase_id="UC_OTHER_001",
                    kb_id=None,
                    files=[],
                )
            )
        except HTTPException as exc:
            assert exc.status_code == 400
            assert "belongs to use case 'UC_CP_006'" in str(exc.detail)
        else:
            raise AssertionError("Expected mismatched usecase_id to raise HTTPException")


def test_send_message_uses_requested_kb_for_standard_chat() -> None:
    current_user = SimpleNamespace(id=7)
    db = MagicMock()
    session = MagicMock(title="New Chat", uploaded_context_text="", updated_at=None)
    db.get.return_value = session
    db.query.return_value.filter.return_value.order_by.return_value.all.return_value = []
    mock_tool = MagicMock()
    mock_tool.search_documents.return_value = [{"id": "doc-1", "content": "Claims context"}]

    with patch(
        "daan.api.v1.endpoints.chat.read_chat_session_manifest",
        return_value={},
    ), patch(
        "daan.api.v1.endpoints.chat._is_chat_agent_usecase",
        return_value=False,
    ), patch(
        "daan.api.v1.endpoints.chat.get_settings"
    ) as mock_get_settings, patch(
        "daan.api.v1.endpoints.chat.RagTool",
        return_value=mock_tool,
    ), patch(
        "daan.api.v1.endpoints.chat._synthesize",
        return_value="Grounded answer",
    ):
        mock_get_settings.return_value.load_rag_config.return_value = {
            "knowledge_bases": [
                {"id": "claims_scenarios", "enabled": True, "system_prompt": "Claims persona"},
                {"id": "daan", "enabled": True, "system_prompt": "DAAN persona"},
            ]
        }

        result = asyncio.run(
            send_message(
                db=db,
                current_user=current_user,
                message="What does this KB say?",
                session_id="chat-session",
                usecase_id=None,
                kb_id="claims_scenarios",
                files=[],
            )
        )

    mock_tool.search_documents.assert_called_once_with(
        query="What does this KB say?",
        k=8,
        retriever_type="graph_rag",
        kb_id="claims_scenarios",
        metadata_filter=None,
    )
    assert result == {"response": "Grounded answer", "references": ["doc-1"], "session_id": "chat-session"}