import json
import sys
from pathlib import Path
from unittest.mock import patch


_SERVICE_DIR = Path(__file__).resolve().parents[3]
if str(_SERVICE_DIR) not in sys.path:
    sys.path.insert(0, str(_SERVICE_DIR))


from daan.native_tools.incident_publish_preparer import IncidentPublishPreparer


def test_prepare_publish_batches_builds_single_publish_payload() -> None:
    tool = IncidentPublishPreparer()

    output = tool.prepare_publish_batches(
        dynamic_agent_outputs_structured={
            "AGENT_OS_2": [
                {
                    "incident_id": "INC1",
                    "recommended_priority": "P1",
                    "recommended_impact": "1",
                    "recommended_urgency": "1",
                    "justification": "Critical incident.",
                },
                {
                    "incident_id": "INC2",
                    "recommended_priority": "P2",
                    "recommended_impact": "1",
                    "recommended_urgency": "2",
                    "justification": "High impact.",
                },
                {
                    "incident_id": "INC3",
                    "recommended_priority": "P3",
                    "recommended_impact": "2",
                    "recommended_urgency": "2",
                    "justification": "Moderate incident.",
                },
                {
                    "incident_id": "INC4",
                    "recommended_priority": "P4",
                    "recommended_impact": "3",
                    "recommended_urgency": "3",
                    "justification": "Low severity.",
                },
            ],
            "AGENT_OS_3": [
                {
                    "incident_id": "INC1",
                    "root_cause_category": "Infrastructure",
                    "probable_cause": "SMTP outage",
                    "resolution_steps": ["Restart SMTP", "Review logs"],
                },
                {
                    "incident_id": "INC2",
                    "root_cause_category": "Application",
                    "probable_cause": "Gateway timeout",
                    "resolution_steps": ["Inspect API gateway"],
                },
                {
                    "incident_id": "INC3",
                    "root_cause_category": "Network",
                    "probable_cause": "VPN misconfiguration",
                    "resolution_steps": ["Check VPN routes"],
                },
                {
                    "incident_id": "INC4",
                    "root_cause_category": "Hardware",
                    "probable_cause": "Disk nearly full",
                    "resolution_steps": ["Free disk space"],
                },
            ],
        },
    )

    payload = json.loads(output)

    assert payload["status"] == "success"
    assert payload["summary"]["incidents_prepared"] == 4
    assert payload["publish_payload_item_count"] == 4

    publish_payload = json.loads(payload["publish_payload"])
    assert payload["publish_items"] == publish_payload

    assert [item["incident_id"] for item in publish_payload] == ["INC1", "INC2", "INC3", "INC4"]
    assert "Resolution Steps:" in publish_payload[0]["comment"]
    assert "Priority Justification: Critical incident." in publish_payload[0]["comment"]


def test_prepare_publish_batches_falls_back_to_raw_joined_outputs() -> None:
    tool = IncidentPublishPreparer()

    priority_raw = json.dumps([
        {
            "incident_id": "INC10",
            "recommended_priority": "P1",
            "recommended_impact": "1",
            "recommended_urgency": "1",
            "justification": "Critical path.",
        }
    ])
    root_cause_raw = json.dumps([
        {
            "incident_id": "INC10",
            "root_cause_category": "Infrastructure",
            "probable_cause": "Mail service drift",
            "resolution_steps": ["Restart service"],
        }
    ])

    output = tool.prepare_publish_batches(
        dynamic_agent_outputs={
            "AGENT_OS_2": priority_raw + "\n\n---\n\n",
            "AGENT_OS_3": root_cause_raw + "\n\n---\n\n",
        },
    )

    payload = json.loads(output)
    publish_payload = json.loads(payload["publish_payload"])

    assert payload["summary"]["incidents_prepared"] == 1
    assert publish_payload[0]["incident_id"] == "INC10"
    assert "Mail service drift" in publish_payload[0]["comment"]


def test_prepare_publish_batches_loads_current_session_outputs_when_args_omitted() -> None:
    tool = IncidentPublishPreparer()
    priority_raw = json.dumps([
        {
            "incident_id": "INC20",
            "recommended_priority": "P2",
            "recommended_impact": "1",
            "recommended_urgency": "2",
            "justification": "High impact.",
        }
    ])
    root_cause_raw = json.dumps([
        {
            "incident_id": "INC20",
            "root_cause_category": "Application",
            "probable_cause": "Gateway timeout",
            "resolution_steps": ["Inspect gateway"],
        }
    ])

    with patch("daan.native_tools.incident_publish_preparer.daan_session_id.get", return_value="session-123"), patch(
        "daan.native_tools.incident_publish_preparer._load_runtime_dynamic_outputs",
        return_value={"AGENT_OS_2": priority_raw, "AGENT_OS_3": root_cause_raw},
    ):
        output = tool.prepare_publish_batches()

    payload = json.loads(output)
    assert payload["summary"]["session_id"] == "session-123"
    assert payload["summary"]["incidents_prepared"] == 1
    assert json.loads(payload["publish_payload"])[0]["incident_id"] == "INC20"