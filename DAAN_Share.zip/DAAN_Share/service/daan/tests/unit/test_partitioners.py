"""
Comprehensive test suite for FilePartitioner.

Covers:
  - FilePartitioner.partition_file for every content type:
    tabular_data, excel_workbook, code_file, text_file, json_file,
    xml_file, pdf_file, docx_file, tableau_file, unknown
  - Integration: convert sample files with FileToJsonConverter then partition
  - Edge cases: empty content, error fallback, unknown type
  - Validates that partitions are returned as List[FilePartition]

Every test stores outputs and prints success messages.
"""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

# ---------------------------------------------------------------------------
# Fix sys.path
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parents[4]
SERVICE_DIR = PROJECT_ROOT / "service"
if str(SERVICE_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_DIR))

from daan.utils.file_to_json import FileToJsonConverter
from daan.utils.file_partitioner import FilePartitioner
from daan.utils.filepartitions.file_partition import FilePartition

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
SAMPLES_DIR = Path(__file__).resolve().parent / "samples"
POWERBI_DIR = SAMPLES_DIR / "Power BI - Inputs"

# Result collector
ALL_RESULTS: dict = {}


def _store(section: str, name: str, partitions):
    """Store partition results for summary."""
    ALL_RESULTS.setdefault(section, {})[name] = [
        {"id": p.partition_id, "summary": p.summary[:120], "file": p.filename}
        for p in partitions
    ]


def _print_ok(label: str, partitions):
    ids = [p.partition_id for p in partitions]
    print(f"  [OK] {label}: {len(partitions)} partition(s) -> {ids[:5]}")


# ======================================================================
#  Helpers
# ======================================================================
class _PartitionTestBase(unittest.TestCase):
    """Shared setup: one converter + one partitioner instance."""

    @classmethod
    def setUpClass(cls):
        cls.converter = FileToJsonConverter()
        cls.partitioner = FilePartitioner(converter=cls.converter)

    def _convert_and_partition(self, file_path: str):
        """Convert a file then partition, return (file_data, partitions)."""
        file_data = self.converter.convert_file_to_json(file_path)
        partitions = self.partitioner.partition_file(file_path, file_data)
        self.assertIsInstance(partitions, list)
        for p in partitions:
            self.assertIsInstance(p, FilePartition)
            self.assertTrue(p.partition_id)
            self.assertTrue(p.summary)
        return file_data, partitions


# ======================================================================
#  1. Tabular data (CSV)
# ======================================================================
class TestPartitionTabularData(_PartitionTestBase):

    def test_sample_csv(self):
        fp = str(SAMPLES_DIR / "sample.csv")
        _, partitions = self._convert_and_partition(fp)
        self.assertGreater(len(partitions), 0)
        _store("TabularData", "sample.csv", partitions)
        _print_ok("CSV partition -> sample.csv", partitions)

    def test_databricks_sttm_csv(self):
        fp = str(SAMPLES_DIR / "Databricks_STTM_SourceToTarget.csv")
        _, partitions = self._convert_and_partition(fp)
        self.assertGreater(len(partitions), 0)
        _store("TabularData", "Databricks_STTM.csv", partitions)
        _print_ok("CSV partition -> Databricks_STTM", partitions)

    def test_powerbi_csvs(self):
        for csv_file in sorted(POWERBI_DIR.glob("*.csv")):
            _, partitions = self._convert_and_partition(str(csv_file))
            self.assertGreater(len(partitions), 0)
            _store("TabularData", csv_file.name, partitions)
            _print_ok(f"CSV partition -> {csv_file.name}", partitions)


# ======================================================================
#  2. Excel workbook
# ======================================================================
class TestPartitionExcelWorkbook(_PartitionTestBase):

    def _run_excel(self, filename: str):
        fp = str(SAMPLES_DIR / filename)
        _, partitions = self._convert_and_partition(fp)
        self.assertGreater(len(partitions), 0)
        _store("ExcelWorkbook", filename, partitions)
        _print_ok(f"Excel partition -> {filename}", partitions)
        return partitions

    def test_adf_sttm(self):
        self._run_excel("ADF_STTM.xlsx")

    def test_bquery_sttm(self):
        self._run_excel("BQuery_STTM.xlsx")

    def test_brd_questionnaire(self):
        self._run_excel("BRD-User story Datalake_Source_System_Questionnaire_Template_v3.0 3 2.xlsx")

    def test_dbt_sttm(self):
        self._run_excel("DBT_STTM.xlsx")

    def test_medium_l2_sttm(self):
        self._run_excel("Medium_L2_STTM_ADF_Input_Template.xlsx")

    def test_simple_sttm(self):
        self._run_excel("simple_STTM_Data Engineer 7.xlsx")

    def test_snowflake_sttm(self):
        self._run_excel("Snowflake_STTM.xlsx")

    def test_sample_xls(self):
        self._run_excel("sample.xls")


# ======================================================================
#  3. Text files (txt, md, log)
# ======================================================================
class TestPartitionTextFile(_PartitionTestBase):

    def _run_text(self, filename: str):
        fp = str(SAMPLES_DIR / filename)
        _, partitions = self._convert_and_partition(fp)
        self.assertGreater(len(partitions), 0)
        _store("TextFile", filename, partitions)
        _print_ok(f"Text partition -> {filename}", partitions)
        return partitions

    def test_sample_txt(self):
        self._run_text("sample.txt")

    def test_sample_md(self):
        self._run_text("sample.md")

    def test_sample_log(self):
        self._run_text("sample.log")

    def test_sttm_prompt(self):
        self._run_text("STTM_to_BigQuery_Enterprise_Prompt.txt")


# ======================================================================
#  4. Code files (py, sql)
# ======================================================================
class TestPartitionCodeFile(_PartitionTestBase):

    def _run_code(self, filename: str):
        fp = str(SAMPLES_DIR / filename)
        _, partitions = self._convert_and_partition(fp)
        self.assertGreater(len(partitions), 0)
        _store("CodeFile", filename, partitions)
        _print_ok(f"Code partition -> {filename}", partitions)
        return partitions

    def test_sample_py(self):
        self._run_code("sample.py")

    def test_sample_sql(self):
        self._run_code("sample.sql")


# ======================================================================
#  5. JSON file
# ======================================================================
class TestPartitionJsonFile(_PartitionTestBase):

    def test_sample_json(self):
        fp = str(SAMPLES_DIR / "sample.json")
        _, partitions = self._convert_and_partition(fp)
        self.assertGreater(len(partitions), 0)
        _store("JsonFile", "sample.json", partitions)
        _print_ok("JSON partition -> sample.json", partitions)


# ======================================================================
#  6. XML file
# ======================================================================
class TestPartitionXmlFile(_PartitionTestBase):

    def test_sample_xml(self):
        fp = str(SAMPLES_DIR / "sample.xml")
        _, partitions = self._convert_and_partition(fp)
        self.assertGreater(len(partitions), 0)
        _store("XmlFile", "sample.xml", partitions)
        _print_ok("XML partition -> sample.xml", partitions)


# ======================================================================
#  7. PDF file (mocked conversion)
# ======================================================================
class TestPartitionPdfFile(unittest.TestCase):

    def test_pdf_partition_from_mock_data(self):
        """Supply pre-built pdf_file data to the partitioner."""
        partitioner = FilePartitioner()
        file_data = {
            "filename": "sample.pdf",
            "file_type": ".pdf",
            "content": {
                "type": "pdf_file",
                "summary": {"total_pages": 2, "total_chars": 500},
                "structured_content": {
                    "Introduction": {"content": "Intro text here", "type": "section_content"},
                    "Body": {"content": "Body paragraph with details", "type": "section_content"},
                },
                "pages": [
                    {"page_number": 1, "text": "Intro text here", "tables": []},
                    {"page_number": 2, "text": "Body paragraph with details", "tables": []},
                ],
            },
        }
        partitions = partitioner.partition_file(str(SAMPLES_DIR / "sample.pdf"), file_data)
        self.assertIsInstance(partitions, list)
        self.assertGreater(len(partitions), 0)
        for p in partitions:
            self.assertIsInstance(p, FilePartition)
        _store("PdfFile", "sample.pdf", partitions)
        _print_ok("PDF partition (mock data)", partitions)


# ======================================================================
#  8. DOCX file (mocked conversion)
# ======================================================================
class TestPartitionDocxFile(unittest.TestCase):

    def test_docx_partition_from_mock_data(self):
        """Supply pre-built docx_file data to the partitioner."""
        partitioner = FilePartitioner()
        file_data = {
            "filename": "sample.docx",
            "file_type": ".docx",
            "content": {
                "type": "docx_file",
                "structured_sections": {
                    "Heading1": {"content": "First section content paragraph.", "header_type": "heading"},
                    "Heading2": {"content": "Second section with more detail.", "header_type": "heading"},
                },
                "tables": [],
                "embedded_files": {"files": [], "embedded_content": "", "count": 0, "file_types": []},
            },
        }
        partitions = partitioner.partition_file(str(SAMPLES_DIR / "sample.docx"), file_data)
        self.assertIsInstance(partitions, list)
        self.assertGreater(len(partitions), 0)
        _store("DocxFile", "sample.docx", partitions)
        _print_ok("DOCX partition (mock data)", partitions)


# ======================================================================
#  9. Tableau file
# ======================================================================
class TestPartitionTableauFile(_PartitionTestBase):

    def test_twb(self):
        fp = str(SAMPLES_DIR / "sample.twb")
        _, partitions = self._convert_and_partition(fp)
        self.assertGreater(len(partitions), 0)
        _store("TableauFile", "sample.twb", partitions)
        _print_ok("Tableau partition -> sample.twb", partitions)

    def test_twbx(self):
        fp = str(SAMPLES_DIR / "sample.twbx")
        _, partitions = self._convert_and_partition(fp)
        self.assertGreater(len(partitions), 0)
        _store("TableauFile", "sample.twbx", partitions)
        _print_ok("Tableau partition -> sample.twbx", partitions)


# ======================================================================
# 10. Synthetic / edge-case partitions
# ======================================================================
class TestPartitionEdgeCases(unittest.TestCase):

    def setUp(self):
        self.partitioner = FilePartitioner()

    def test_unknown_type_fallback(self):
        """Unknown type should produce a single 'full_file' partition."""
        file_data = {
            "content": {"type": "unknown", "text": "raw content here"},
        }
        partitions = self.partitioner.partition_file("/fake/unknown.dat", file_data)
        self.assertGreater(len(partitions), 0)
        _store("EdgeCases", "unknown_type", partitions)
        _print_ok("Unknown type fallback", partitions)

    def test_empty_content(self):
        """Empty content dict should still return at least one partition."""
        file_data = {"content": {"type": "text_file"}}
        partitions = self.partitioner.partition_file("/fake/empty.txt", file_data)
        self.assertGreater(len(partitions), 0)
        _store("EdgeCases", "empty_content", partitions)
        _print_ok("Empty content", partitions)

    def test_missing_type_defaults_unknown(self):
        """Missing 'type' key should default to 'unknown'."""
        file_data = {"content": {"data": "some data"}}
        partitions = self.partitioner.partition_file("/fake/nodata.bin", file_data)
        self.assertGreater(len(partitions), 0)
        _store("EdgeCases", "missing_type", partitions)
        _print_ok("Missing type -> unknown", partitions)

    def test_excel_workbook_synthetic(self):
        """Synthetic excel_workbook content with known structure."""
        file_data = {
            "content": {
                "type": "excel_workbook",
                "sheets": {
                    "Sheet1": {
                        "tables": [
                            {
                                "table_name": "MainTable",
                                "table_type": "data",
                                "columns": ["ID", "Name", "Value"],
                                "rows": [
                                    {"ID": 1, "Name": "Alpha", "Value": 100},
                                    {"ID": 2, "Name": "Beta", "Value": 200},
                                    {"ID": 3, "Name": "Gamma", "Value": 300},
                                ],
                            }
                        ]
                    }
                },
            }
        }
        partitions = self.partitioner.partition_file("/fake/test.xlsx", file_data)
        self.assertGreater(len(partitions), 0)
        _store("EdgeCases", "synthetic_excel", partitions)
        _print_ok("Synthetic excel workbook", partitions)

    def test_tabular_data_synthetic(self):
        """Synthetic tabular_data with columns and rows."""
        file_data = {
            "content": {
                "type": "tabular_data",
                "columns": ["col_a", "col_b", "col_c"],
                "rows": [{"col_a": i, "col_b": f"val_{i}", "col_c": i * 10} for i in range(5)],
                "summary": {"total_rows": 5, "total_columns": 3},
            }
        }
        partitions = self.partitioner.partition_file("/fake/test.csv", file_data)
        self.assertGreater(len(partitions), 0)
        _store("EdgeCases", "synthetic_tabular", partitions)
        _print_ok("Synthetic tabular data", partitions)

    def test_code_file_synthetic(self):
        """Synthetic code_file with structure blocks."""
        file_data = {
            "content": {
                "type": "code_file",
                "language": "python",
                "content": "def hello():\n    print('hello')\n\ndef world():\n    print('world')\n",
                "structure": [
                    {"type": "function", "name": "hello", "content": "def hello():\n    print('hello')\n",
                     "lineno": 1, "end_lineno": 2},
                    {"type": "function", "name": "world", "content": "def world():\n    print('world')\n",
                     "lineno": 4, "end_lineno": 5},
                ],
            }
        }
        partitions = self.partitioner.partition_file("/fake/test.py", file_data)
        # Should have full_code + 2 function blocks
        self.assertGreaterEqual(len(partitions), 3)
        _store("EdgeCases", "synthetic_code", partitions)
        _print_ok("Synthetic code file", partitions)


# ======================================================================
# 11. Full integration: convert + partition all samples
# ======================================================================
class TestPartitionIntegrationAll(_PartitionTestBase):
    """Convert + partition every non-binary sample file end-to-end."""

    def test_all_text_and_data_samples(self):
        """Run convert_file_to_json + partition_file for all convertible samples."""
        results = {}
        errors = []

        for sample_file in sorted(SAMPLES_DIR.iterdir()):
            if sample_file.is_dir():
                continue
            # Skip files that need mocked dependencies (pdf, docx, pbi)
            if sample_file.suffix in (".pdf", ".docx", ".pbit", ".pbix"):
                continue
            try:
                file_data = self.converter.convert_file_to_json(str(sample_file))
                partitions = self.partitioner.partition_file(str(sample_file), file_data)
                self.assertIsInstance(partitions, list)
                self.assertGreater(len(partitions), 0, f"No partitions for {sample_file.name}")
                results[sample_file.name] = len(partitions)
                _print_ok(f"Integration -> {sample_file.name}", partitions)
            except Exception as e:
                errors.append(f"{sample_file.name}: {e}")

        print(f"\n  Integration results: {len(results)} files partitioned successfully")
        for fname, count in sorted(results.items()):
            print(f"    {fname}: {count} partition(s)")
        if errors:
            print(f"  Errors ({len(errors)}):")
            for err in errors:
                print(f"    - {err}")

        # Most files should succeed
        self.assertGreater(len(results), 5, "Too few files partitioned")


# ======================================================================
# 12. Partition output storage
# ======================================================================
class TestPartitionOutputStorage(_PartitionTestBase):
    """Write partition outputs to temp dir for inspection."""

    def test_store_partition_outputs(self):
        output_dir = Path(__file__).resolve().parent / "results" / "partitioner_outputs"
        output_dir.mkdir(parents=True, exist_ok=True)
        count = 0
        for sample_file in sorted(SAMPLES_DIR.iterdir()):
            if sample_file.is_dir() or sample_file.suffix in (".pdf", ".docx", ".pbit", ".pbix"):
                continue
            try:
                file_data = self.converter.convert_file_to_json(str(sample_file))
                partitions = self.partitioner.partition_file(str(sample_file), file_data)
                out = {
                    "file": sample_file.name,
                    "partition_count": len(partitions),
                    "partitions": [p.to_dict() for p in partitions],
                }
                out_path = output_dir / f"{sample_file.stem}.partitions.json"
                out_path.write_text(json.dumps(out, default=str, indent=2), encoding="utf-8")
                count += 1
            except Exception:
                pass

        print(f"\n  Partition outputs stored: {count} files -> {output_dir}")
        self.assertGreater(count, 0)


# ======================================================================
# Summary
# ======================================================================
class TestZZZPartitionSummary(unittest.TestCase):
    """Print summary of all partition test results."""

    def test_print_summary(self):
        print("\n" + "=" * 70)
        print("PARTITIONER TEST RESULTS SUMMARY")
        print("=" * 70)
        for section, tests in sorted(ALL_RESULTS.items()):
            print(f"\n  {section} ({len(tests)} tests):")
            for name, parts in sorted(tests.items()):
                ids = [p["id"] for p in parts[:3]]
                print(f"    - {name}: {len(parts)} partitions -> {ids}")
        total_tests = sum(len(v) for v in ALL_RESULTS.values())
        total_parts = sum(len(p) for tests in ALL_RESULTS.values() for p in tests.values())
        print(f"\n  Total: {total_tests} test cases, {total_parts} partitions generated")
        print("=" * 70)


if __name__ == "__main__":
    unittest.main(verbosity=2)
