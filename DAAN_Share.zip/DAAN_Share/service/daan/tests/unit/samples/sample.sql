-- DAAN Test Suite - Sample SQL File

CREATE TABLE Sales (
    OrderID INT PRIMARY KEY,
    Product VARCHAR(255),
    Amount DECIMAL(10, 2),
    OrderDate DATE
);

CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    Name VARCHAR(255),
    Region VARCHAR(100)
);

INSERT INTO Sales (OrderID, Product, Amount, OrderDate)
VALUES (1, 'Widget A', 99.99, '2026-01-15');

SELECT s.OrderID, s.Product, s.Amount, c.Name, c.Region
FROM Sales s
JOIN Customers c ON s.CustomerID = c.CustomerID
WHERE s.Amount > 50.00
ORDER BY s.OrderDate DESC;
