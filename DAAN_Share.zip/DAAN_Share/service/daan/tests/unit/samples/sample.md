# DAAN Test Suite - Sample Markdown

## Overview
This is a sample Markdown file for testing the text converter.

## Data Pipeline
- Extract from source systems
- Transform using mapping rules
- Load into target warehouse

## Schema
| Column | Type | Description |
|--------|------|-------------|
| OrderID | INT | Primary key |
| Product | VARCHAR | Product name |
| Amount | DECIMAL | Order amount |

## Notes
All data should be validated before loading.
