"""DAAN Test Suite - Sample Python File"""


class DataProcessor:
    """Processes data from source to target."""

    def __init__(self, source: str):
        self.source = source
        self.data = []

    def load(self) -> list:
        """Load data from source."""
        return self.data

    def transform(self, data: list) -> list:
        """Apply transformation rules."""
        return [row.strip() for row in data if row]


def calculate_total(amounts: list) -> float:
    """Calculate total from a list of amounts."""
    return sum(amounts)


if __name__ == "__main__":
    processor = DataProcessor("sample")
    result = processor.load()
    print(f"Loaded {len(result)} records")
