from __future__ import annotations

from unittest.mock import patch

from daan.native_tools.rag_tool import RagTool
from daan.vector_stores.providers.postgres_vector_store import PostgresVectorStore
from daan.vector_stores.document import RagDocument


def test_clone_stats_returns_detached_payload() -> None:
    payload = {"kb1": {"chunks": 2, "documents": ["a.txt"]}}

    cloned = PostgresVectorStore._clone_stats(payload)
    cloned["kb1"]["documents"].append("b.txt")

    assert payload == {"kb1": {"chunks": 2, "documents": ["a.txt"]}}


def test_pgvector_list_uses_config_as_source_of_truth() -> None:
    tool = RagTool(
        {
            "vector_store_type": "pgvector",
            "knowledge_bases": [
                {"id": "configured_only", "enabled": True, "name": "Configured Only"},
                {"id": "live_kb", "enabled": True, "name": "Live KB"},
            ],
        }
    )

    tool._get_kb_stats = lambda: {"live_kb": {"chunks": 3, "documents": ["a.txt"]}}  # type: ignore[method-assign]
    tool._load_registered_kbs = lambda: []  # type: ignore[method-assign]
    tool._load_registered_kb_stats = lambda: {}  # type: ignore[method-assign]

    result = tool.list_knowledge_bases()

    assert result == [
        {
            "id": "configured_only",
            "name": "Configured Only",
            "enabled": True,
            "chunks_indexed": 0,
            "documents": [],
        },
        {
            "id": "live_kb",
            "name": "Live KB",
            "enabled": True,
            "chunks_indexed": 3,
            "documents": ["a.txt"],
        }
    ]


def test_vector_search_does_not_create_graph_store() -> None:
    tool = RagTool(
        {
            "embedding_provider": "demo",
            "vector_store_type": "pgvector",
            "graph_store_type": "cosmos",
            "chunker_type": "fixed_size",
            "chunk_size": 64,
            "chunk_overlap": 8,
            "reranker_type": None,
            "knowledge_bases": [{"id": "claims", "enabled": True, "collection": "claims"}],
            "vector_store_config": {"embedding_dimension": 3},
        }
    )

    fake_doc = RagDocument(
        id="doc-1",
        content="Claims content",
        metadata={"source": "claims.txt", "query_link": "ql-1"},
        source="claims.txt",
        chunk_index=0,
        embedding=[0.1, 0.2, 0.3],
    )

    class FakeVectorStore:
        def similarity_search(self, query_embedding, k, where=None):
            return [fake_doc]

    class FakeEmbeddingProvider:
        def embed_text(self, text):
            return [0.1, 0.2, 0.3]

    with patch("daan.native_tools.rag_tool.VectorStoreFactory.create_store", return_value=FakeVectorStore()):
        with patch(
            "daan.native_tools.rag_tool.EmbeddingProviderFactory.create_provider",
            return_value=FakeEmbeddingProvider(),
        ):
            with patch("daan.native_tools.rag_tool.GraphStoreFactory.create_store") as graph_factory:
                results = tool.search_documents(
                    query="claims question",
                    k=1,
                    retriever_type="vector",
                    kb_id="claims",
                    query_link="ql-1",
                )

    assert results == [
        {
            "id": "doc-1",
            "content": "Claims content",
            "source": "claims.txt",
            "chunk_index": 0,
            "query_link": "ql-1",
        }
    ]
    graph_factory.assert_not_called()