"""Focused regression tests for MCP preload metadata and fallback classification."""

import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
from unittest.mock import AsyncMock

PROJECT_ROOT = Path(__file__).resolve().parents[4]
SERVICE_DIR = PROJECT_ROOT / "service"
if str(SERVICE_DIR) not in sys.path:
    sys.path.insert(0, str(SERVICE_DIR))

from daan.mcp_servers.core.mcp_toolset_provider import (  # noqa: E402
    _get_repo_local_mcp_toolset,
    initialize_mcp_for_agents,
)
from daan.agents.dynamic_builders.dynamic_adk_agent import (  # noqa: E402
    create_adk_agent,
    _resolve_preloaded_mcp_entry,
)
from daan.flow.agent_runner import (  # noqa: E402
    _run_pipeline_async,
    _is_llm_failure,
    _is_mcp_tool_failure,
    _load_credentials_from_mcp_config,
    _extract_tool_error_from_response,
    _should_retry_with_fallback_provider,
    _build_action_input_payload,
    run_action_agents_async,
)


class TestMcpRetryClassification(unittest.TestCase):
    def test_mcp_clientrequest_timeout_does_not_trigger_provider_fallback(self):
        exc = RuntimeError(
            "Timed out while waiting for response to ClientRequest. Waited 5.0 seconds."
        )

        self.assertTrue(_is_mcp_tool_failure(exc))
        self.assertFalse(_is_llm_failure(exc))
        self.assertFalse(_should_retry_with_fallback_provider(exc))

    def test_mcp_tool_retrieval_failure_does_not_trigger_provider_fallback(self):
        exc = RuntimeError("Failed to get tools from MCP server")

        self.assertTrue(_is_mcp_tool_failure(exc))
        self.assertFalse(_should_retry_with_fallback_provider(exc))

    def test_provider_failure_still_triggers_provider_fallback(self):
        exc = RuntimeError("LiteLLM Azure OpenAI service unavailable")

        self.assertTrue(_is_llm_failure(exc))
        self.assertFalse(_is_mcp_tool_failure(exc))
        self.assertTrue(_should_retry_with_fallback_provider(exc))

    def test_tool_error_is_extracted_from_json_string_payload(self):
        response = '{"status":"error","error":"publish failed"}'

        self.assertEqual("publish failed", _extract_tool_error_from_response(response))


class TestPreloadedMcpEntryResolution(unittest.TestCase):
    def test_metadata_wrapped_entry_preserves_requested_and_resolved_names(self):
        toolset = object()
        entry = {
            "atlassian-mcp": {
                "requested_server": "atlassian-mcp",
                "resolved_server": "jira-mcp-server",
                "toolsets": [toolset],
                "source": "fallback",
            }
        }

        resolved = _resolve_preloaded_mcp_entry(entry, "atlassian-mcp")

        self.assertIsNotNone(resolved)
        toolsets, requested_name, resolved_name, source = resolved
        self.assertEqual([toolset], toolsets)
        self.assertEqual("atlassian-mcp", requested_name)
        self.assertEqual("jira-mcp-server", resolved_name)
        self.assertEqual("fallback", source)

    def test_legacy_entry_shape_is_still_supported(self):
        toolset = object()
        entry = {"jira-mcp-server": [toolset]}

        resolved = _resolve_preloaded_mcp_entry(entry, "jira-mcp-server")

        self.assertIsNotNone(resolved)
        toolsets, requested_name, resolved_name, source = resolved
        self.assertEqual([toolset], toolsets)
        self.assertEqual("jira-mcp-server", requested_name)
        self.assertEqual("jira-mcp-server", resolved_name)
        self.assertEqual("workflow", source)


class TestFallbackCredentialResolution(unittest.TestCase):
    @patch("daan.mcp_servers.core.mcp_toolset_provider.load_mcp_config_by_name")
    def test_resolved_fallback_server_credentials_override_requested_server(self, mock_load_config):
        def _config_for(name: str):
            configs = {
                "atlassian-mcp": {"credentials": {"jira_api_token": "primary-token"}},
                "jira-mcp-server": {
                    "credentials": {
                        "jira_base_url": "https://jira.example.com",
                        "jira_username": "fallback-user",
                        "jira_api_token": "fallback-token",
                        "jira_verify_ssl": "true",
                    }
                },
            }
            return configs.get(name)

        mock_load_config.side_effect = _config_for

        credentials = _load_credentials_from_mcp_config(
            [{"mcp_tools": "atlassian-mcp"}],
            {
                "atlassian-mcp": {
                    "requested_server": "atlassian-mcp",
                    "resolved_server": "jira-mcp-server",
                    "toolsets": [object()],
                    "source": "fallback",
                }
            },
        )

        self.assertEqual(
            {
                "jira_base_url": "https://jira.example.com",
                "jira_username": "fallback-user",
                "jira_api_token": "fallback-token",
                "jira_verify_ssl": "true",
            },
            credentials,
        )


class TestFallbackMcpLoading(unittest.IsolatedAsyncioTestCase):
    @patch("daan.mcp_servers.core.mcp_toolset_provider._get_repo_local_mcp_toolset")
    @patch("daan.mcp_servers.core.mcp_toolset_provider.load_mcp_config_by_name")
    @patch("daan.mcp_servers.core.mcp_toolset_provider.initialize_mcp_toolset", new_callable=AsyncMock)
    async def test_fallback_prefers_configured_server_path_before_repo_local_loader(
        self,
        mock_initialize,
        mock_load_config,
        mock_repo_local,
    ):
        fallback_toolset = object()

        async def _initialize_side_effect(server_name: str, session_id=None, extra_env=None):
            if server_name == "atlassian-mcp":
                return []
            if server_name == "jira-mcp-server":
                return [fallback_toolset]
            return []

        mock_initialize.side_effect = _initialize_side_effect
        mock_load_config.side_effect = lambda name, session_id=None: {
            "fallback_local_mcp": "jira-mcp-server"
        } if name == "atlassian-mcp" else None

        result = await initialize_mcp_for_agents([
            {"mcp_tools": "[atlassian-mcp]"}
        ])

        self.assertIn("atlassian-mcp", result)
        self.assertEqual("jira-mcp-server", result["atlassian-mcp"]["resolved_server"])
        self.assertEqual([fallback_toolset], result["atlassian-mcp"]["toolsets"])
        self.assertEqual("fallback", result["atlassian-mcp"]["source"])
        mock_repo_local.assert_not_called()


class TestRepoLocalMcpToolsetDefaults(unittest.TestCase):
    @patch("daan.mcp_servers.core.mcp_toolset_provider.importlib.util.find_spec")
    @patch("daan.mcp_servers.core.mcp_toolset_provider.McpToolset")
    def test_repo_local_loader_uses_extended_stdio_timeout(self, mock_toolset, mock_find_spec):
        mock_find_spec.return_value = object()
        mock_toolset.return_value = object()

        toolsets = _get_repo_local_mcp_toolset("jira-mcp-server")

        self.assertEqual(1, len(toolsets))
        connection_params = mock_toolset.call_args.kwargs["connection_params"]
        self.assertEqual(60.0, connection_params.timeout)
        self.assertIn("PYTHONPATH", connection_params.server_params.env)
        self.assertEqual("utf-8", connection_params.server_params.env["PYTHONIOENCODING"])

    @patch("daan.mcp_servers.core.mcp_toolset_provider.load_mcp_config_by_name")
    @patch("daan.mcp_servers.core.mcp_toolset_provider.importlib.util.find_spec")
    @patch("daan.mcp_servers.core.mcp_toolset_provider.McpToolset")
    def test_repo_local_loader_uses_configured_timeout(
        self,
        mock_toolset,
        mock_find_spec,
        mock_load_config,
    ):
        mock_find_spec.return_value = object()
        mock_toolset.return_value = object()
        mock_load_config.return_value = {"timeout_seconds": 180}

        toolsets = _get_repo_local_mcp_toolset("servicenow-mcp")

        self.assertEqual(1, len(toolsets))
        connection_params = mock_toolset.call_args.kwargs["connection_params"]
        self.assertEqual(180.0, connection_params.timeout)


class TestRetryExecutionBehavior(unittest.IsolatedAsyncioTestCase):
    @patch("daan.flow.agent_runner._run_pipeline_async", new_callable=AsyncMock)
    async def test_action_agent_mcp_failure_is_raised_without_retry(
        self,
        mock_run_pipeline_async,
    ):
        preloaded_toolset = object()
        mock_run_pipeline_async.side_effect = RuntimeError("Failed to get tools from MCP server")

        with self.assertRaises(RuntimeError):
            await run_action_agents_async(
                agents=[
                    {
                        "agent_id": "AGENT_ACTION",
                        "agent_name": "Post To Jira",
                        "agent_type": "action_agent",
                        "prompt": "Publish the reviewed output.",
                        "mcp_tools": "[atlassian-mcp]",
                    }
                ],
                session_id="session-mcp-retry",
                dynamic_agent_outputs={"AGENT_UPSTREAM": '{"stories": []}'},
                pre_loaded_mcp_toolsets={"atlassian-mcp": {"toolsets": [preloaded_toolset]}},
            )

        first_call = mock_run_pipeline_async.await_args_list[0]
        first_agents = first_call.args[0]
        self.assertEqual("[atlassian-mcp]", first_agents[0]["mcp_tools"])
        self.assertEqual("action_agents_pipeline", first_call.args[3])
        self.assertEqual(
            {"atlassian-mcp": {"toolsets": [preloaded_toolset]}},
            first_call.kwargs["pre_loaded_mcp_toolsets"],
        )

    @patch("daan.flow.agent_runner.extract_usage_from_event", return_value={})
    @patch("daan.flow.agent_runner._close_mcp_toolsets")
    @patch("daan.flow.agent_runner.create_pipeline_agent", return_value=object())
    @patch("daan.flow.agent_runner.InMemoryRunner")
    async def test_action_agent_prefers_meaningful_tool_response_over_zero_result_text(
        self,
        mock_runner_cls,
        _mock_create_pipeline,
        _mock_close_mcp_toolsets,
        _mock_extract_usage,
    ):
        class _FunctionResponse:
            def __init__(self, name, response):
                self.name = name
                self.response = response

        class _Event:
            def __init__(self, text, responses=None):
                self.author = "IncidentDecisionPublisher"
                self.content = type(
                    "Content",
                    (),
                    {"parts": [type("Part", (), {"text": text})()]},
                )()
                self._responses = responses or []

            def get_function_responses(self):
                return self._responses

        publish_payload = {
            "status": "success",
            "summary": {"incidents_total": 23, "incidents_succeeded": 23, "incidents_failed": 0},
            "results": [{"incident_id": "INC1", "incident_status": "success"}],
        }

        class _FakeRunner:
            def __init__(self, agent, app_name):
                self.agent = agent
                self.app_name = app_name
                self.auto_create_session = False

            async def run_async(self, user_id, session_id, new_message):
                yield _Event(
                    text="",
                    responses=[_FunctionResponse("publish_triage_decision", {"result": json.dumps(publish_payload)})],
                )
                yield _Event(
                    text='{"status":"error","summary":{"incidents_total":0,"incidents_succeeded":0,"incidents_failed":0},"results":[]}',
                )

        mock_runner_cls.side_effect = _FakeRunner

        outputs, usage, model_by_agent, provider_by_agent = await _run_pipeline_async(
            agents=[
                {
                    "agent_id": "AGENT_OS_4",
                    "agent_name": "IncidentDecisionPublisher",
                    "agent_type": "action_agent",
                    "prompt": "Publish decisions",
                    "mcp_tools": "servicenow-mcp",
                }
            ],
            input_message="hello",
            session_id="session-action-tool-output",
            pipeline_name="action_agents_pipeline",
            pre_loaded_mcp_toolsets={"servicenow-mcp": {"toolsets": [object()]}},
        )

        self.assertEqual(json.dumps(publish_payload, ensure_ascii=False), outputs["AGENT_OS_4"])
        self.assertEqual({}, usage)
        self.assertEqual({}, model_by_agent)
        self.assertEqual({}, provider_by_agent)

    @patch("daan.flow.agent_runner._run_pipeline_async", new_callable=AsyncMock)
    async def test_action_input_does_not_reinject_reviewed_output_when_structured_outputs_exist(
        self,
        mock_run_pipeline_async,
    ):
        mock_run_pipeline_async.return_value = ({"AGENT_ACTION": "ok"}, {}, {}, {})

        dynamic_outputs = {
            "AGENT_OS_2": '[{"incident_id":"INC1","recommended_priority":"P1"}]',
            "AGENT_OS_3": '[{"incident_id":"INC1","root_cause_category":"Infrastructure"}]',
        }

        payload, _structured = _build_action_input_payload(
            "session-structured-only",
            [{
                "agent_id": "AGENT_ACTION",
                "agent_name": "Publish",
                "agent_type": "action_agent",
                "prompt": "Publish",
                "mcp_tools": "[servicenow-mcp]",
            }],
            dynamic_outputs,
        )
        self.assertNotIn("reviewed_output", payload)

        _outputs, _usage, _model_by_agent, _provider_by_agent, input_message = await run_action_agents_async(
            agents=[
                {
                    "agent_id": "AGENT_ACTION",
                    "agent_name": "Publish",
                    "agent_type": "action_agent",
                    "prompt": "Publish",
                    "mcp_tools": "[servicenow-mcp]",
                }
            ],
            session_id="session-structured-only",
            dynamic_agent_outputs=dynamic_outputs,
        )

        self.assertNotIn('"reviewed_output"', input_message)

    @patch("daan.flow.agent_runner.extract_usage_from_event", return_value={})
    @patch("daan.flow.agent_runner._close_mcp_toolsets")
    @patch("daan.flow.agent_runner.create_pipeline_agent")
    @patch("daan.flow.agent_runner.InMemoryRunner")
    @patch("daan.llm.llm_provider.get_fallback_provider_name", return_value="fallback-provider")
    async def test_provider_fallback_drops_preloaded_mcp_state_on_retry(
        self,
        _mock_get_fallback_provider,
        mock_runner_cls,
        mock_create_pipeline,
        _mock_close_mcp_toolsets,
        _mock_extract_usage,
    ):
        preloaded_toolset = object()

        class _FakePipeline:
            def __init__(self, agents, preloaded):
                self.agents = agents
                self.preloaded = preloaded

        def _pipeline_factory(*, session_id, agents, pipeline_name, pre_loaded_mcp_toolsets, tool_kwargs):
            return _FakePipeline(agents=agents, preloaded=pre_loaded_mcp_toolsets)

        mock_create_pipeline.side_effect = _pipeline_factory

        class _FakeRunner:
            def __init__(self, agent, app_name):
                self.agent = agent
                self.app_name = app_name
                self.auto_create_session = False

            async def run_async(self, user_id, session_id, new_message):
                provider = self.agent.agents[0].get("provider")
                if provider != "fallback-provider":
                    raise RuntimeError("LiteLLM Azure OpenAI service unavailable")

                event = type("Event", (), {})()
                event.author = "Dynamic_Agent"
                event.content = type("Content", (), {"parts": [type("Part", (), {"text": "fallback-ok"})()]})()
                yield event

        mock_runner_cls.side_effect = _FakeRunner

        outputs, usage, model_by_agent, provider_by_agent = await _run_pipeline_async(
            agents=[
                {
                    "agent_id": "AGENT_DYNAMIC",
                    "agent_name": "Dynamic Agent",
                    "prompt": "Do work",
                    "provider": "azure_openai",
                    "mcp_tools": "[atlassian-mcp]",
                }
            ],
            input_message="hello",
            session_id="session-provider-retry",
            pipeline_name="dynamic_agents_pipeline",
            pre_loaded_mcp_toolsets={"atlassian-mcp": {"toolsets": [preloaded_toolset]}},
        )

        self.assertEqual({"AGENT_DYNAMIC": "fallback-ok"}, outputs)
        self.assertEqual({}, usage)
        self.assertEqual({}, model_by_agent)
        self.assertEqual({}, provider_by_agent)
        self.assertEqual(2, mock_create_pipeline.call_count)

        first_call = mock_create_pipeline.call_args_list[0]
        self.assertEqual(
            {"atlassian-mcp": {"toolsets": [preloaded_toolset]}},
            first_call.kwargs["pre_loaded_mcp_toolsets"],
        )
        self.assertEqual("azure_openai", first_call.kwargs["agents"][0]["provider"])

        second_call = mock_create_pipeline.call_args_list[1]
        self.assertIsNone(second_call.kwargs["pre_loaded_mcp_toolsets"])
        self.assertEqual("fallback-provider", second_call.kwargs["agents"][0]["provider"])
        self.assertTrue(second_call.kwargs["agents"][0]["_fallback_retry"])


class _DummyAgent:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


class TestExplicitLocalToolLoading(unittest.TestCase):
    @patch("daan.agents.dynamic_builders.dynamic_adk_agent.build_adk_guardrail_callbacks", return_value={})
    @patch("daan.agents.dynamic_builders.dynamic_adk_agent.create_litellm_model")
    @patch("daan.agents.dynamic_builders.dynamic_adk_agent.get_local_tools")
    @patch("daan.agents.dynamic_builders.dynamic_adk_agent.Agent", side_effect=_DummyAgent)
    def test_explicit_local_tools_are_still_loaded_for_agent_execution(
        self,
        _mock_agent,
        mock_get_local_tools,
        mock_create_model,
        _mock_callbacks,
    ):
        sentinel_tool = object()
        mock_get_local_tools.return_value = sentinel_tool
        mock_create_model.return_value = (
            "mock-model",
            {"provider": "mock", "model": "mock-model", "config": {}},
        )

        agent = create_adk_agent(
            session_id="session-1",
            agent_json={
                "agent_name": "Native Tool Agent",
                "agent_type": "dynamic_agent",
                "prompt": "Run the configured native tool.",
                "provider": "mock-provider",
                "local_tools": "PowerBIReportGenerator.run",
            },
            tool_kwargs={"data_dir": "test-data"},
        )

        mock_get_local_tools.assert_called_once_with(
            "PowerBIReportGenerator.run",
            tool_kwargs={"data_dir": "test-data"},
        )
        self.assertIn(sentinel_tool, agent.tools)
        self.assertEqual("dynamic_agent", agent._agent_type)

    @patch("daan.agents.dynamic_builders.dynamic_adk_agent.build_adk_guardrail_callbacks", return_value={})
    @patch("daan.agents.dynamic_builders.dynamic_adk_agent.create_litellm_model")
    @patch("daan.agents.dynamic_builders.dynamic_adk_agent.get_local_tools")
    @patch("daan.agents.dynamic_builders.dynamic_adk_agent.Agent", side_effect=_DummyAgent)
    def test_missing_local_tools_does_not_inject_implicit_native_tool_defaults(
        self,
        _mock_agent,
        mock_get_local_tools,
        mock_create_model,
        _mock_callbacks,
    ):
        mock_create_model.return_value = (
            "mock-model",
            {"provider": "mock", "model": "mock-model", "config": {}},
        )

        agent = create_adk_agent(
            session_id="session-2",
            agent_json={
                "agent_name": "No Local Tool Agent",
                "agent_type": "dynamic_agent",
                "prompt": "Run without local tools.",
                "provider": "mock-provider",
            },
            tool_kwargs={"data_dir": "test-data"},
        )

        mock_get_local_tools.assert_not_called()
        self.assertEqual([], agent.tools)


if __name__ == "__main__":
    unittest.main()