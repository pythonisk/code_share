import asyncio
import logging
from types import SimpleNamespace

from google.adk.models.llm_request import LlmRequest
from google.genai import types

from daan.guardrails.adk_callbacks import build_adk_guardrail_callbacks, parse_guardrail_specs


class _ListHandler(logging.Handler):
    def __init__(self) -> None:
        super().__init__()
        self.records: list[logging.LogRecord] = []

    def emit(self, record: logging.LogRecord) -> None:
        self.records.append(record)


def test_parse_guardrail_specs_groups_by_hook() -> None:
    parsed = parse_guardrail_specs(
        "before_model:pii_masking|after_model:pii_masking|before_agent:pii_masking|after_agent:pii_masking"
    )

    assert parsed == {
        "before_model": ["pii_masking"],
        "after_model": ["pii_masking"],
        "before_agent": ["pii_masking"],
        "after_agent": ["pii_masking"],
    }


def test_build_adk_guardrail_callbacks_exposes_all_supported_hooks() -> None:
    callbacks = build_adk_guardrail_callbacks(
        {
            "guardrails": (
                "before_model:pii_masking|after_model:pii_masking|"
                "before_agent:pii_masking|after_agent:pii_masking"
            )
        }
    )

    assert set(callbacks) == {
        "before_model_callback",
        "after_model_callback",
        "before_agent_callback",
        "after_agent_callback",
    }


def test_before_model_callback_masks_pii() -> None:
    callbacks = build_adk_guardrail_callbacks(
        {"guardrails": "before_model:pii_masking"}
    )
    before_model_callback = callbacks["before_model_callback"]

    llm_request = LlmRequest(
        model="mock-model",
        contents=[
            types.Content(
                role="user",
                parts=[types.Part.from_text(text="Reach me at shreya@gmail.com")],
            )
        ],
        config=types.GenerateContentConfig(
            system_instruction="User email is shreya@gmail.com"
        ),
    )

    result = asyncio.run(
        before_model_callback(
            SimpleNamespace(agent_name="test_agent", session=SimpleNamespace(id="session-1")),
            llm_request,
        )
    )

    assert result is None
    assert "shreya@gmail.com" not in llm_request.contents[0].parts[0].text
    assert "[EMAIL:" in llm_request.contents[0].parts[0].text
    assert "shreya@gmail.com" not in llm_request.config.system_instruction
    assert "[EMAIL:" in llm_request.config.system_instruction


def test_before_model_callback_logs_executed_guardrail_without_change() -> None:
    callbacks = build_adk_guardrail_callbacks(
        {"guardrails": "before_model:pii_masking"}
    )
    before_model_callback = callbacks["before_model_callback"]

    llm_request = LlmRequest(
        model="mock-model",
        contents=[
            types.Content(
                role="user",
                parts=[types.Part.from_text(text="No sensitive data here")],
            )
        ],
        config=types.GenerateContentConfig(
            system_instruction="General instructions only"
        ),
    )

    log_handler = _ListHandler()
    logger = logging.getLogger("daan.guardrails.adk_callbacks")
    previous_level = logger.level
    logger.setLevel(logging.INFO)
    logger.addHandler(log_handler)

    try:
        result = asyncio.run(
            before_model_callback(
                SimpleNamespace(agent_name="test_agent", session=SimpleNamespace(id="session-2")),
                llm_request,
            )
        )
    finally:
        logger.removeHandler(log_handler)
        logger.setLevel(previous_level)

    assert result is None
    assert len(log_handler.records) == 1

    record = log_handler.records[0]
    assert record.session_id == "session-2"
    assert record.agent_name == "test_agent"
    assert record.hook == "before_model"
    assert record.guardrails == ["pii_masking"]
    assert record.guardrail_result == "no_change"