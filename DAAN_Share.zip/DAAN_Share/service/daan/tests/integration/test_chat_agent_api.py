from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from fastapi.testclient import TestClient

from daan.core.database import get_db
from daan.core.dependencies import get_current_active_user, get_current_user
from daan.flow.session_service import (
    read_context_map_output,
    read_chat_session_manifest,
    read_chat_session_messages,
    write_context_map_output,
)
from daan.main import app


class _QueryStub:
    def filter(self, *args, **kwargs):
        return self

    def order_by(self, *args, **kwargs):
        return self

    def all(self):
        return []


class _DbStub:
    def query(self, *args, **kwargs):
        return _QueryStub()

    def get(self, *args, **kwargs):
        return None

    def add(self, *args, **kwargs):
        return None

    def commit(self):
        return None

    def delete(self, *args, **kwargs):
        return None


def test_chat_agent_workflow_backed_lifecycle(tmp_path: Path) -> None:
    current_user = SimpleNamespace(id=7, username="tester", is_active=True)
    session_settings = SimpleNamespace(SESSION_STORAGE_DIR=str(tmp_path), load_rag_config=lambda: {})
    rag_settings = SimpleNamespace(
        load_rag_config=lambda: {
            "knowledge_bases": [
                {"id": "claims", "enabled": True, "system_prompt": "Claims persona"},
            ]
        }
    )
    usecase_details = {
        "agents": [
            {
                "agent_id": "chat1",
                "agent_name": "Claims Chat",
                "agent_type": "chat_agent",
                "prompt": "Answer only from the supplied context.",
            }
        ],
        "usecase_details": {"dag": "chat1", "name": "Claims QA"},
    }
    refreshed_context = {
        "agents": usecase_details["agents"],
        "usecase_details": usecase_details["usecase_details"],
        "context_map": {"chat1": {"notes": "Uploaded claims document context"}},
        "dag": "chat1",
        "token_usage": {"prompt_tokens": 10},
    }
    captured: dict[str, str] = {}

    def _override_db():
        yield _DbStub()

    def _fake_synthesize(query, docs, system_prompt, chat_history_text="", uploaded_context_text=""):
        captured["uploaded_context_text"] = uploaded_context_text
        captured["chat_history_text"] = chat_history_text
        return "Grounded answer from uploaded context"

    def _fake_context_refresh(*args, **kwargs):
        session_id = str(kwargs.get("session_id") or "")
        write_context_map_output(session_id, refreshed_context)
        return refreshed_context

    app.dependency_overrides[get_current_user] = lambda: current_user
    app.dependency_overrides[get_current_active_user] = lambda: current_user
    app.dependency_overrides[get_db] = _override_db

    try:
        with patch("daan.flow.session_service.get_settings", return_value=session_settings), \
            patch("daan.flow.session_service.init_rag_session", return_value=None), \
            patch("daan.flow.session_service.cleanup_rag_session", return_value=None), \
            patch("daan.main.init_db", return_value=None), \
            patch("daan.api.v1.endpoints.chat.get_settings", return_value=rag_settings), \
            patch("daan.api.v1.endpoints.chat.resolve_archetype_for_usecase", return_value="Data Pipeline"), \
            patch("daan.api.v1.endpoints.chat.get_usecase_details", return_value=usecase_details), \
            patch("daan.api.v1.endpoints.chat.RagTool") as mock_rag_tool, \
            patch("daan.api.v1.endpoints.chat._synthesize", side_effect=_fake_synthesize), \
            patch("daan.usecases.usecase_service.get_usecase_details", return_value=usecase_details), \
            patch("daan.flow.supervisor.ContextMapper.run_detailed", side_effect=_fake_context_refresh):
            mock_rag_tool.return_value.search_documents.return_value = [
                {"id": "doc-1", "content": "Claims KB answer context"},
            ]

            with TestClient(app) as client:
                create_response = client.post(
                    "/api/sessions",
                    json={
                        "userid": "tester",
                        "archetype": "Data Pipeline",
                        "usecase_id": "UC_CP_006",
                        "mode": "chat_agent",
                        "kb_id": "claims",
                    },
                )
                assert create_response.status_code == 200
                session_id = create_response.json()["session_id"]

                manifest = read_chat_session_manifest(session_id)
                assert manifest["mode"] == "chat_agent"
                assert manifest["usecase_id"] == "UC_CP_006"
                assert manifest["kb_id"] == "claims"

                upload_response = client.post(
                    f"/api/sessions/{session_id}/upload-files",
                    files={"files": ("claims.txt", b"claim content", "text/plain")},
                )
                assert upload_response.status_code == 200
                assert upload_response.json()["uploaded_files"] == ["claims.txt"]

                stored_context = read_context_map_output(session_id)
                assert stored_context["context_map"] == refreshed_context["context_map"]

                message_response = client.post(
                    "/api/chat/message",
                    data={
                        "message": "What does the uploaded claims document say?",
                        "session_id": session_id,
                    },
                )
                assert message_response.status_code == 200
                assert message_response.json()["mode"] == "chat_agent"
                assert message_response.json()["references"] == ["doc-1"]
                assert "Uploaded claims document context" in captured["uploaded_context_text"]

                list_response = client.get("/api/chat/sessions")
                assert list_response.status_code == 200
                sessions = list_response.json()
                assert any(item["id"] == session_id and item["messageCount"] == 2 for item in sessions)

                messages_response = client.get(f"/api/chat/sessions/{session_id}/messages")
                assert messages_response.status_code == 200
                messages = messages_response.json()
                assert [item["role"] for item in messages] == ["user", "assistant"]

                stored_messages = read_chat_session_messages(session_id, limit=0)
                assert len(stored_messages) == 2

                delete_response = client.delete(f"/api/chat/sessions/{session_id}")
                assert delete_response.status_code == 200
                assert delete_response.json() == {"deleted": True, "id": session_id}
                assert not (tmp_path / session_id).exists()
    finally:
        app.dependency_overrides.clear()


def test_chat_agent_session_can_be_created_with_kb_only(tmp_path: Path) -> None:
    current_user = SimpleNamespace(id=7, username="tester", is_active=True)
    session_settings = SimpleNamespace(SESSION_STORAGE_DIR=str(tmp_path), load_rag_config=lambda: {})

    def _override_db():
        yield _DbStub()

    app.dependency_overrides[get_current_active_user] = lambda: current_user
    app.dependency_overrides[get_db] = _override_db

    try:
        with patch("daan.flow.session_service.get_settings", return_value=session_settings), \
            patch("daan.flow.session_service.init_rag_session", return_value=None), \
            patch("daan.flow.session_service.cleanup_rag_session", return_value=None), \
            patch("daan.main.init_db", return_value=None):
            with TestClient(app) as client:
                create_response = client.post(
                    "/api/sessions",
                    json={
                        "userid": "tester",
                        "mode": "chat_agent",
                        "kb_id": "claims_scenarios",
                    },
                )

                assert create_response.status_code == 200
                session_id = create_response.json()["session_id"]
                manifest = read_chat_session_manifest(session_id)
                assert manifest["mode"] == "chat_agent"
                assert manifest["kb_id"] == "claims_scenarios"
                assert manifest["usecase_id"] == ""
                assert manifest["archetype"] == ""
    finally:
        app.dependency_overrides.clear()