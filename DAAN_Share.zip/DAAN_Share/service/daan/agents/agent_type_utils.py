from __future__ import annotations

from typing import Any


def normalize_agent_type(value: Any) -> str:
    """Return a canonical DAAN agent type.

    The catalog currently contains multiple spellings for action agents
    (for example: actionagent, action_agent, Custom_Action_Agent) and chat agents
    (for example: chatagent, chat_agent).
    Normalize them so workflow routing is deterministic.
    """
    text = str(value or "").strip()
    compact = "".join(ch for ch in text.casefold() if ch.isalnum())

    if compact in ("", "subagent", "subagents", "dynamicagent"):
        return "dynamic_agent"

    if compact in ("actionagent", "customactionagent"):
        return "action_agent"

    if compact in ("chatagent", "chatbotagent", "customchatagent"):
        return "chat_agent"

    return text


def is_action_agent(value: Any) -> bool:
    return normalize_agent_type(value) == "action_agent"


def is_dynamic_agent(value: Any) -> bool:
    return normalize_agent_type(value) == "dynamic_agent"


def is_chat_agent(value: Any) -> bool:
    return normalize_agent_type(value) == "chat_agent"