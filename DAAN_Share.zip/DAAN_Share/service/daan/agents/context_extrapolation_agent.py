from __future__ import annotations

import hashlib
import json
import logging
import multiprocessing as mp
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
from difflib import SequenceMatcher
from pathlib import Path
from queue import Empty
from typing import Any

from dotenv import dotenv_values
from daan.models.context_extrapolation_models import (
    ContextExtrapolationResult,
    KnowledgeAreaProbe,
    MissingContextItem,
    ProbeType,
    ProbeValidationResult,
    QueryNormalizationResult,
    QueryType,
    StructuredContextExtrapolationOutput,
)
from daan.llm.providers.provider_factory import ProviderFactory
from daan.rag.observability.context_extrapolation_telemetry import get_context_extrapolation_telemetry
from openai import AzureOpenAI, OpenAI
from pydantic import BaseModel, ConfigDict, Field, model_validator
import yaml

logger = logging.getLogger(__name__)


_ce_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="context-extrapolation")
_provider_runtime_spec_cache: dict[tuple[str, int], dict[str, Any]] = {}


class ContextExtrapolationPolicy(BaseModel):
    model_config = ConfigDict(extra="ignore")

    enabled: bool = True
    # Lowered from 0.7 after removing structure bonuses for expanded_queries, technologies,
    # industries, metadata_hints in _compute_overall_confidence; 0.55 preserves prior acceptance rate.
    confidence_threshold: float = Field(default=0.55, ge=0.0, le=1.0)
    max_retrieval_probes: int = Field(default=5, ge=0, le=10)
    timeout_ms: int | None = Field(default=None, ge=100, le=60000)
    timeout_ms_by_environment: dict[str, int] = Field(default_factory=dict)
    enable_fallback: bool = True
    telemetry_enabled: bool = True
    max_missing_context: int = Field(default=5, ge=0, le=10)
    max_query_characters: int = Field(default=4000, ge=256, le=20000)

    @model_validator(mode="after")
    def _resolve_timeout(self) -> "ContextExtrapolationPolicy":
        if self.timeout_ms is not None:
            return self

        environment = str(os.getenv("ENVIRONMENT", "development") or "development").strip().casefold()
        timeout_lookup = {str(key).strip().casefold(): int(value) for key, value in self.timeout_ms_by_environment.items()}
        if environment == "staging" and "staging" not in timeout_lookup and "uat" in timeout_lookup:
            environment = "uat"
        self.timeout_ms = timeout_lookup.get(environment, 40000)
        return self


def build_context_extrapolation_prompt(
    *,
    query: str,
    kb_id: str,
    retriever_type: str,
    max_retrieval_probes: int,
    max_missing_context: int,
    chat_context: str | None = None,
) -> str:
    chat_context_block = f"\nRecent chat context:\n{chat_context.strip()}\n" if chat_context and chat_context.strip() else ""
    return f"""You are ContextExtrapolationAgent for DAAN.

Infer retrieval planning context from the user query.
When recent chat context is provided, use it only to resolve references and omitted subjects in the current query.
Do not answer the user. Do not cite sources. Do not explain your reasoning.

Knowledge base: {kb_id}
Retriever: {retriever_type}

Rules:
- Return exactly one JSON object.
- Output JSON only. Do not add markdown fences, prose, commentary, or headings.
- Use these top-level JSON keys: schema_version, intent, intent_confidence, persona, persona_confidence, retrieval_probes, probe_exploration_questions, missing_context, overall_confidence, use_plan, fallback_reason.
- Use numbers between 0 and 1 for all confidence fields.
- Generate at most {max_retrieval_probes} retrieval_probes.
- Generate each retrieval_probes item as a single string formatted exactly as:
    Concept:\nShort explanation
- For each retrieval_probes concept, also generate 3 to 5 short probe_exploration_questions.
- Each probe_exploration_questions item must contain a label field with the same label as the retrieval probe plus an exploration_questions array.
- exploration_questions must be reviewer-facing reasoning questions, not query rewrites, search rewrites, keyword lists, or retrieval instructions.
- exploration_questions are explainability only and must not imply extra retrieval branches, extra retrieval, or extra graph traversal.
- retrieval_probes must be broad retrieval concepts, domains, capabilities, workflow stages, artifact classes, platform components, ontology entities, or knowledge areas that help graph exploration.
- Keep retrieval_probes business readable, graph-friendly, and concise.
- Do not restate, paraphrase, or rewrite the user query as a retrieval_probes item.
- Do not turn retrieval_probes into keyword lists, search rewrites, or expanded user questions.
- Prefer adjacent concepts such as requirements management, onboarding, governance, migration planning, upload inputs, use case setup, workflow orchestration, platform capabilities, artifact classes, and integration surfaces when supported by the query.
- Use noun phrases, not sentence fragments or questions.
- Generate at most {max_missing_context} missing_context items.
- Keep missing_context.reason concise.
- Use recent chat context only to resolve pronouns, shorthand, or omitted entities from the current query.
- If the query lacks evidence, lower confidence and set use_plan to false.
- Use empty strings, empty arrays, or null values when unknown.

User query:
{query.strip()}
{chat_context_block}"""


class TruncatedOutputError(RuntimeError):
    """Raised when the provider reports truncated structured output."""


def _project_config_dir() -> Path:
    return Path(__file__).resolve().parents[3] / "config"


def _resolve_env_backed_value(
    config: dict[str, Any],
    direct_key: str,
    env_key: str,
    env_values: dict[str, str],
    *fallback_env_names: str,
    default: str | None = None,
) -> str | None:
    direct_value = config.get(direct_key)
    if direct_value not in (None, ""):
        return str(direct_value)

    configured_env_name = str(config.get(env_key) or "").strip()
    candidate_names = [name for name in [configured_env_name, *fallback_env_names] if name]
    for env_name in candidate_names:
        value = os.getenv(env_name)
        if value not in (None, ""):
            return value
        if env_name in env_values and env_values[env_name] not in (None, ""):
            return str(env_values[env_name])
    return default


def _resolve_provider_runtime_config(
    provider_name: str,
    provider_config: dict[str, Any],
    env_values: dict[str, str],
) -> dict[str, Any]:
    resolved = dict(provider_config)
    normalized_provider = str(provider_name or "").strip().lower()

    if normalized_provider == "azure_openai":
        resolved["api_key"] = _resolve_env_backed_value(
            resolved,
            "api_key",
            "api_key_env",
            env_values,
            "AZURE_OPENAI_API_KEY",
            "AZURE_API_KEY",
        )
        resolved["endpoint"] = _resolve_env_backed_value(
            resolved,
            "endpoint",
            "endpoint_env",
            env_values,
            "AZURE_OPENAI_ENDPOINT",
            "AZURE_API_BASE",
            "AZURE_OPENAI_API_BASE",
        )
        resolved["deployment_name"] = _resolve_env_backed_value(
            resolved,
            "deployment_name",
            "deployment_env",
            env_values,
            "AZURE_OPENAI_DEPLOYMENT_NAME",
        )
        resolved["api_version"] = _resolve_env_backed_value(
            resolved,
            "api_version",
            "api_version_env",
            env_values,
            "AZURE_OPENAI_API_VERSION",
            "AZURE_API_VERSION",
            default="2024-08-01-preview",
        )
    elif normalized_provider == "openai":
        resolved["api_key"] = _resolve_env_backed_value(
            resolved,
            "api_key",
            "api_key_env",
            env_values,
            "OPENAI_API_KEY",
        )
    elif normalized_provider == "google":
        resolved["api_key"] = _resolve_env_backed_value(
            resolved,
            "api_key",
            "api_key_env",
            env_values,
            "GOOGLE_API_KEY",
            "GOOGLE_GEMINI_KEY",
        )

    return resolved


def _load_context_extrapolation_provider_spec(provider_name: str | None = None) -> dict[str, Any]:
    config_dir = _project_config_dir()
    config_path = config_dir / "llm_config.yml"
    if not config_path.exists():
        raise RuntimeError(f"LLM config file not found: {config_path}")

    cache_key = (str(provider_name or "").strip().casefold(), int(config_path.stat().st_mtime_ns))
    cached = _provider_runtime_spec_cache.get(cache_key)
    if cached is not None:
        return {
            "provider": str(cached.get("provider") or ""),
            "config": dict(cached.get("config") or {}),
        }

    with open(config_path, "r", encoding="utf-8") as handle:
        llm_config = yaml.safe_load(handle) or {}

    selected_provider = str(
        provider_name
        or llm_config.get("default_provider")
        or llm_config.get("provider")
        or ""
    ).strip()
    if not selected_provider:
        raise RuntimeError("No default provider configured for Context Extrapolation Agent")

    provider_config = dict((llm_config.get("providers") or {}).get(selected_provider) or {})
    if not provider_config:
        raise RuntimeError(f"Provider '{selected_provider}' not configured for Context Extrapolation Agent")

    override_config = dict(((llm_config.get("model_overrides") or {}).get(selected_provider)) or {})
    merged_config = {**provider_config, **override_config}
    env_values = {
        str(key): str(value)
        for key, value in (dotenv_values(config_dir / ".env") or {}).items()
        if key and value is not None
    }
    resolved_config = _resolve_provider_runtime_config(selected_provider, merged_config, env_values)
    resolved_spec = {
        "provider": selected_provider,
        "config": resolved_config,
    }
    _provider_runtime_spec_cache[cache_key] = {
        "provider": str(resolved_spec.get("provider") or ""),
        "config": dict(resolved_spec.get("config") or {}),
    }
    return {
        "provider": str(resolved_spec.get("provider") or ""),
        "config": dict(resolved_spec.get("config") or {}),
    }


def _structured_completion_from_sdk(provider_spec: dict[str, Any], prompt: str, timeout_seconds: float) -> dict[str, Any]:
    provider_name = str(provider_spec.get("provider") or "").strip().lower()
    config = dict(provider_spec.get("config") or {})

    if provider_name == "azure_openai":
        api_key = str(config.get("api_key") or "").strip()
        endpoint = str(config.get("endpoint") or "").strip()
        deployment_name = str(config.get("deployment_name") or "").strip()
        api_version = str(config.get("api_version") or "2024-08-01-preview").strip()
        if not api_key or not endpoint or not deployment_name:
            raise ValueError("Azure OpenAI API key, endpoint, and deployment name are required")
        client = AzureOpenAI(api_key=api_key, azure_endpoint=endpoint, api_version=api_version)
        response = client.beta.chat.completions.parse(
            model=deployment_name,
            messages=[{"role": "user", "content": prompt}],
            response_format=StructuredContextExtrapolationOutput,
            timeout=timeout_seconds,
            temperature=config.get("temperature", 0.3),
            max_completion_tokens=config.get("max_tokens") or config.get("max_output_tokens") or 640,
        )
    elif provider_name == "openai":
        api_key = str(config.get("api_key") or "").strip()
        if not api_key:
            raise ValueError("OpenAI API key not found")
        client = OpenAI(api_key=api_key, base_url=config.get("base_url", "https://api.openai.com/v1/"))
        response = client.beta.chat.completions.parse(
            model=str(config.get("model") or "").strip(),
            messages=[{"role": "user", "content": prompt}],
            response_format=StructuredContextExtrapolationOutput,
            timeout=timeout_seconds,
            temperature=config.get("temperature", 0.7),
            max_completion_tokens=config.get("max_tokens") or config.get("max_output_tokens") or 640,
        )
    else:
        raise ValueError(f"Structured SDK completion unsupported for provider '{provider_name}'")

    parsed = response.choices[0].message.parsed
    parsed_payload = parsed.model_dump() if hasattr(parsed, "model_dump") else parsed
    return {
        "id": getattr(response, "id", None),
        "model": getattr(response, "model", None),
        "choices": [
            {
                "finish_reason": getattr(response.choices[0], "finish_reason", None),
                "message": {
                    "parsed": parsed_payload,
                    "content": getattr(response.choices[0].message, "content", None),
                },
            }
        ],
        "usage": getattr(response, "usage", None).model_dump() if getattr(response, "usage", None) is not None and hasattr(response.usage, "model_dump") else getattr(response, "usage", None),
    }


def _call_agent_internal_completion(provider_spec: dict[str, Any], prompt: str, timeout_seconds: float) -> Any:
    provider_name = str(provider_spec.get("provider") or "").strip().lower()
    if provider_name in {"azure_openai", "openai"}:
        return _structured_completion_from_sdk(provider_spec, prompt, timeout_seconds)

    provider = ProviderFactory.create_provider(provider_name, dict(provider_spec.get("config") or {}))
    provider.setup_environment()
    return _call_provider_completion(provider, prompt, timeout_seconds)


def _provider_name(llm_provider: Any) -> str:
    getter = getattr(llm_provider, "get_provider_name", None)
    if callable(getter):
        try:
            resolved = str(getter() or "").strip().lower()
        except Exception:  # noqa: BLE001
            resolved = ""
        if resolved:
            return resolved
    return type(llm_provider).__name__.replace("Provider", "").strip().lower()


def _normalize_completion_response(raw: Any) -> Any:
    if isinstance(raw, dict):
        return raw

    choices = getattr(raw, "choices", None)
    if not choices:
        return raw

    choice = choices[0]
    message = getattr(choice, "message", None)
    parsed = getattr(message, "parsed", None) if message is not None else None
    if parsed is not None and hasattr(parsed, "model_dump"):
        parsed = parsed.model_dump()
    content = getattr(message, "content", None) if message is not None else None

    usage = getattr(raw, "usage", None)
    if usage is not None and hasattr(usage, "model_dump"):
        usage = usage.model_dump()

    return {
        "id": getattr(raw, "id", None),
        "model": getattr(raw, "model", None),
        "choices": [
            {
                "finish_reason": getattr(choice, "finish_reason", None),
                "message": {
                    "parsed": parsed,
                    "content": content,
                },
            }
        ],
        "usage": usage,
    }


def _completion_worker(llm_provider: Any, provider_spec: dict[str, Any] | None, prompt: str, timeout_seconds: float, result_queue: Any) -> None:
    try:
        if llm_provider is not None:
            result_queue.put(("ok", _call_provider_completion(llm_provider, prompt, timeout_seconds)))
        else:
            result_queue.put(("ok", _call_agent_internal_completion(provider_spec or {}, prompt, timeout_seconds)))
    except Exception as exc:  # noqa: BLE001
        result_queue.put(("error", {"type": type(exc).__name__, "message": str(exc)}))


def _call_provider_completion(llm_provider: Any, prompt: str, timeout_seconds: float) -> Any:
    provider_name = _provider_name(llm_provider)
    structured_kwargs: dict[str, Any] = {"return_metadata": True}
    if provider_name == "litellm":
        # LiteLLM proxy can't serialize a Pydantic model class passed through
        # response_model, but it can reliably return JSON mode content.
        structured_kwargs["response_format"] = {"type": "json_object"}
    else:
        structured_kwargs["response_model"] = StructuredContextExtrapolationOutput
    try:
        return _normalize_completion_response(
            llm_provider.completion(
                prompt=prompt,
                timeout=timeout_seconds,
                **structured_kwargs,
            )
        )
    except TypeError as exc:
        if "unexpected keyword argument 'timeout'" not in str(exc):
            try:
                return _normalize_completion_response(
                    llm_provider.completion(
                        prompt=prompt,
                        **structured_kwargs,
                    )
                )
            except TypeError:
                raise
        try:
            return _normalize_completion_response(
                llm_provider.completion(
                    prompt=prompt,
                    **structured_kwargs,
                )
            )
        except TypeError:
            try:
                return _normalize_completion_response(
                    llm_provider.completion(prompt=prompt, timeout=timeout_seconds, return_metadata=True)
                )
            except TypeError:
                return _normalize_completion_response(llm_provider.completion(prompt=prompt))


def _raise_worker_error(payload: dict[str, str]) -> None:
    error_type = str(payload.get("type") or "RuntimeError")
    message = str(payload.get("message") or "ContextExtrapolationAgent worker failed")
    if error_type == "TimeoutError":
        raise TimeoutError(message)
    raise RuntimeError(f"{error_type}: {message}")


class ContextExtrapolationAgent:
    """Pre-retrieval planning agent for DAAN RAG searches."""

    def __init__(self, llm_provider: Any | None, config: dict[str, Any] | None = None) -> None:
        self.llm_provider = llm_provider
        raw_config = dict(config or {})
        self._provider_name_override = str(raw_config.get("provider_name") or "").strip() or None
        self.policy = ContextExtrapolationPolicy.model_validate(raw_config)
        self._provider_runtime_spec: dict[str, Any] | None = None
        self._last_runtime_trace: dict[str, Any] = {}

    def build_plan(
        self,
        *,
        query: str,
        kb_id: str,
        retriever_type: str,
        chat_context: str | None = None,
    ) -> ContextExtrapolationResult:
        normalized_query = str(query or "").strip()
        query_hash = self._query_hash(normalized_query)
        query_normalization = self._normalize_query(normalized_query)
        telemetry = get_context_extrapolation_telemetry()
        if self.policy.telemetry_enabled:
            telemetry.record_request()
        if not self.policy.enabled:
            result = self._build_fallback_result(normalized_query, "agent_disabled", query_normalization=query_normalization)
            self._record_outcome(result=result, kb_id=kb_id, query_hash=query_hash, latency_ms=0.0, error=None)
            return result
        if not normalized_query:
            result = self._build_fallback_result(normalized_query, "empty_query", query_normalization=query_normalization)
            self._record_outcome(result=result, kb_id=kb_id, query_hash=query_hash, latency_ms=0.0, error=None)
            return result
        if self.llm_provider is None:
            try:
                self._ensure_provider_runtime_spec()
            except Exception as exc:  # noqa: BLE001
                logger.warning("ContextExtrapolationAgent provider initialization failed: %s", exc)
                result = self._build_fallback_result(normalized_query, "llm_provider_unavailable", query_normalization=query_normalization)
                self._record_outcome(result=result, kb_id=kb_id, query_hash=query_hash, latency_ms=0.0, error=type(exc).__name__)
                return result
        elif not hasattr(self.llm_provider, "completion"):
            result = self._build_fallback_result(normalized_query, "llm_provider_unavailable", query_normalization=query_normalization)
            self._record_outcome(result=result, kb_id=kb_id, query_hash=query_hash, latency_ms=0.0, error=None)
            return result

        prompt = build_context_extrapolation_prompt(
            query=normalized_query[: self.policy.max_query_characters],
            kb_id=kb_id,
            retriever_type=retriever_type,
            max_retrieval_probes=self.policy.max_retrieval_probes,
            max_missing_context=self.policy.max_missing_context,
            chat_context=chat_context,
        )

        t_start = time.perf_counter()
        error_name: str | None = None
        try:
            raw = self._invoke_completion(prompt)
            finish_reason = self._finish_reason(raw)
            if finish_reason == "length":
                raise TruncatedOutputError("provider returned truncated output")
            parsed = self._parse_payload(raw)
        except Exception as exc:  # noqa: BLE001
            error_name = type(exc).__name__
            logger.warning("ContextExtrapolationAgent failed to build plan: %s", exc)
            if isinstance(exc, TruncatedOutputError):
                fallback_reason = "truncated_output"
            else:
                fallback_reason = "agent_timeout" if self._looks_like_timeout(exc) else "agent_execution_failed"
            result = self._build_fallback_result(normalized_query, fallback_reason, query_normalization=query_normalization)
            latency_ms = (time.perf_counter() - t_start) * 1000.0
            self._record_outcome(
                result=result,
                kb_id=kb_id,
                query_hash=query_hash,
                latency_ms=latency_ms,
                error=error_name,
            )
            return result

        result = self._normalize_result(parsed, normalized_query)
        result.query_normalization = query_normalization
        result.overall_confidence = self._compute_overall_confidence(result)
        if self.policy.enable_fallback and result.overall_confidence < self.policy.confidence_threshold:
            result.use_plan = False
            result.fallback_reason = result.fallback_reason or "confidence_below_threshold"
        else:
            result.use_plan = True
            result.fallback_reason = None
        latency_ms = (time.perf_counter() - t_start) * 1000.0
        self._record_outcome(
            result=result,
            kb_id=kb_id,
            query_hash=query_hash,
            latency_ms=latency_ms,
            error=error_name,
        )
        return result

    def get_last_runtime_trace(self) -> dict[str, Any]:
        return dict(self._last_runtime_trace)

    def _parse_payload(self, raw: Any) -> dict[str, Any]:
        if isinstance(raw, dict):
            choices = raw.get("choices") or []
            if choices:
                message = choices[0].get("message") or {}
                parsed = message.get("parsed")
                if isinstance(parsed, dict):
                    return parsed
                if parsed is not None and hasattr(parsed, "model_dump"):
                    return parsed.model_dump()
                content = message.get("content")
                if isinstance(content, str) and content.strip():
                    text = content.strip()
                    try:
                        return json.loads(text)
                    except json.JSONDecodeError:
                        match = re.search(r"\{.*\}", text, flags=re.DOTALL)
                        if match:
                            return json.loads(match.group(0))
        if isinstance(raw, dict):
            return raw
        text = str(raw or "").strip()
        if not text:
            return {}
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", text, flags=re.DOTALL)
            if not match:
                return {}
            return json.loads(match.group(0))

    def _normalize_result(self, payload: dict[str, Any], query_text: str = "") -> ContextExtrapolationResult:
        normalized_probe_strings = self._normalize_retrieval_probes(
            payload.get("retrieval_probes"),
            query_text=query_text,
        )
        exploration_question_map = self._normalize_probe_exploration_questions(payload.get("probe_exploration_questions"))
        probes, probe_validation = self._build_knowledge_area_probes(
            normalized_probe_strings,
            query_text=query_text,
            expanded_queries=[],
            exploration_question_map=exploration_question_map,
        )
        normalized = ContextExtrapolationResult(
            schema_version=str(payload.get("schema_version") or "1.0"),
            intent=self._clean_text(payload.get("intent")),
            intent_confidence=self._bounded_float(payload.get("intent_confidence")),
            persona=self._clean_text(payload.get("persona")),
            persona_confidence=self._bounded_float(payload.get("persona_confidence")),
            retrieval_probes=[probe.to_legacy_string() for probe in probes],
            probes=probes,
            probe_validation=probe_validation,
            missing_context=self._clean_missing_context(payload.get("missing_context")),
            overall_confidence=self._bounded_float(payload.get("overall_confidence")),
            use_plan=bool(payload.get("use_plan", True)),
            fallback_reason=self._clean_text(payload.get("fallback_reason")) or None,
        )
        return normalized

    def _build_fallback_result(
        self,
        query_text: str,
        fallback_reason: str,
        *,
        query_normalization: QueryNormalizationResult | None,
    ) -> ContextExtrapolationResult:
        probes = self._fallback_probes_from_query(query_text, query_normalization)
        return ContextExtrapolationResult(
            use_plan=False,
            fallback_reason=fallback_reason,
            overall_confidence=0.0,
            retrieval_probes=[probe.to_legacy_string() for probe in probes],
            probes=probes,
            probe_validation=[
                ProbeValidationResult(probe_id=probe.probe_id, accepted=True, diversity_group=probe.probe_type.value)
                for probe in probes
            ],
            query_normalization=query_normalization,
        )

    def _compute_overall_confidence(self, result: ContextExtrapolationResult) -> float:
        if result.overall_confidence > 0.0:
            return self._bounded_float(result.overall_confidence)

        primary = [result.intent_confidence]
        if result.persona:
            primary.append(result.persona_confidence)

        structure_bonus = 0.0
        if result.retrieval_probes:
            structure_bonus += 0.08

        missing_penalty = min(len(result.missing_context) * 0.04, 0.16)
        base = sum(primary) / len(primary) if primary else 0.0
        return self._bounded_float(base + structure_bonus - missing_penalty)

    def _normalize_query(self, query_text: str) -> QueryNormalizationResult:
        normalized_query = str(query_text or "").strip()
        lowered = normalized_query.casefold()
        query_type = QueryType.GENERAL
        if any(token in lowered for token in ("integrate", "integration", "connector", "connect to", "jira", "api")):
            query_type = QueryType.INTEGRATION
        elif any(token in lowered for token in ("workflow", "process", "steps", "lifecycle")):
            query_type = QueryType.WORKFLOW
        elif any(token in lowered for token in ("requirement", "required", "files", "document", "upload", "artifact", "brd")):
            query_type = QueryType.REQUIREMENTS
        elif any(token in lowered for token in ("governance", "policy", "compliance", "audit")):
            query_type = QueryType.GOVERNANCE
        elif normalized_query.endswith("?") and len(normalized_query.split()) <= 6:
            query_type = QueryType.FACTOID
        elif lowered.startswith("what is ") or lowered.startswith("who is "):
            query_type = QueryType.DEFINITION
        simple_query = query_type in {QueryType.FACTOID, QueryType.DEFINITION} and len(normalized_query.split()) <= 8
        detected_entities = [
            token.strip(" ,.:;")
            for token in re.findall(r"\b[A-Z][A-Za-z0-9&._-]*\b", normalized_query)
            if token.strip(" ,.:;")
        ]
        return QueryNormalizationResult(
            original_query=normalized_query,
            normalized_query=normalized_query,
            query_type=query_type,
            simple_query=simple_query,
            detected_entities=list(dict.fromkeys(detected_entities)),
        )

    def _fallback_probes_from_query(
        self,
        query_text: str,
        query_normalization: QueryNormalizationResult | None,
    ) -> list[KnowledgeAreaProbe]:
        query_type = query_normalization.query_type if query_normalization else QueryType.GENERAL
        default_templates: dict[QueryType, list[tuple[ProbeType, str, str]]] = {
            QueryType.INTEGRATION: [
                (ProbeType.CAPABILITY, "Integration capabilities", "Covers connector capabilities, supported systems, and integration surfaces"),
                (ProbeType.WORKFLOW_STAGE, "Workflow orchestration", "Explores workflow stages, handoffs, and automation steps relevant to the integration"),
                (ProbeType.PLATFORM_COMPONENT, "Platform components", "Highlights DAAN components, services, and extension points involved in the request"),
            ],
            QueryType.WORKFLOW: [
                (ProbeType.WORKFLOW_STAGE, "Workflow stages", "Covers the major workflow stages, decision points, and delivery steps"),
                (ProbeType.ARTIFACT_CLASS, "Supporting artifacts", "Identifies artifacts, inputs, and outputs involved in the workflow"),
                (ProbeType.CAPABILITY, "Automation capabilities", "Explores capabilities that support or automate the workflow"),
            ],
            QueryType.REQUIREMENTS: [
                (ProbeType.ARTIFACT_CLASS, "Requirements artifacts", "Covers required files, templates, and supporting documentation"),
                (ProbeType.WORKFLOW_STAGE, "Intake and onboarding", "Explores intake workflows, onboarding steps, and prerequisite inputs"),
                (ProbeType.DOMAIN, "Delivery standards", "Captures documentation standards, governance, and delivery expectations"),
            ],
            QueryType.GOVERNANCE: [
                (ProbeType.DOMAIN, "Governance controls", "Covers policy, compliance, and governance concepts relevant to the request"),
                (ProbeType.CAPABILITY, "Observability and audit", "Explores observability, audit trails, and compliance evidence"),
                (ProbeType.WORKFLOW_STAGE, "Approval workflow", "Highlights approval, review, and control points"),
            ],
            QueryType.FACTOID: [
                (ProbeType.PLATFORM_COMPONENT, "Platform overview", "Summarizes the primary platform components and responsibilities"),
                (ProbeType.CAPABILITY, "Core capabilities", "Highlights the main capabilities and supported user outcomes"),
            ],
            QueryType.DEFINITION: [
                (ProbeType.PLATFORM_COMPONENT, "Platform overview", "Summarizes the primary platform components and responsibilities"),
                (ProbeType.CAPABILITY, "Core capabilities", "Highlights the main capabilities and supported user outcomes"),
            ],
            QueryType.GENERAL: [
                (ProbeType.DOMAIN, "Platform concepts", "Covers broader domains, platform concepts, and adjacent knowledge areas relevant to the query"),
                (ProbeType.CAPABILITY, "Core capabilities", "Highlights the main capabilities and workflows related to the request"),
            ],
            QueryType.MULTI_ENTITY: [
                (ProbeType.DOMAIN, "Platform concepts", "Covers broader domains, platform concepts, and adjacent knowledge areas relevant to the query"),
                (ProbeType.CAPABILITY, "Core capabilities", "Highlights the main capabilities and workflows related to the request"),
            ],
        }
        selected = default_templates.get(query_type, default_templates[QueryType.GENERAL])
        probes: list[KnowledgeAreaProbe] = []
        for index, (probe_type, label, rationale) in enumerate(selected, start=1):
            probe_id = f"fallback-{index}-{self._query_hash(label)}"
            probes.append(
                KnowledgeAreaProbe(
                    probe_id=probe_id,
                    probe_type=probe_type,
                    label=label,
                    rationale=rationale,
                    exploration_questions=self._fallback_exploration_questions(label, probe_type),
                    confidence=0.35,
                )
            )
        return probes[: self.policy.max_retrieval_probes]

    def _build_knowledge_area_probes(
        self,
        probe_strings: list[str],
        *,
        query_text: str,
        expanded_queries: list[str],
        exploration_question_map: dict[str, list[str]],
    ) -> tuple[list[KnowledgeAreaProbe], list[ProbeValidationResult]]:
        probes: list[KnowledgeAreaProbe] = []
        validations: list[ProbeValidationResult] = []
        for raw_probe in probe_strings:
            label, rationale = self._split_probe_label_and_explanation(raw_probe)
            clean_label = re.sub(r"\s+", " ", label).strip(" :-")
            if not clean_label:
                continue
            rewrite_score = self._probe_rewrite_score(clean_label, [query_text, *expanded_queries])
            accepted = rewrite_score < 0.72 and not clean_label.endswith("?")
            probe_type = self._classify_probe_type(clean_label)
            probe_id = f"probe-{self._query_hash(clean_label)}"
            validations.append(
                ProbeValidationResult(
                    probe_id=probe_id,
                    accepted=accepted,
                    rejection_reason=None if accepted else "query_rewrite_detected",
                    rewrite_score=rewrite_score,
                    diversity_group=probe_type.value,
                )
            )
            if not accepted:
                continue
            probes.append(
                KnowledgeAreaProbe(
                    probe_id=probe_id,
                    probe_type=probe_type,
                    label=clean_label,
                    rationale=rationale or self._default_probe_explanation(clean_label),
                    exploration_questions=exploration_question_map.get(clean_label.casefold()) or self._fallback_exploration_questions(clean_label, probe_type),
                    retrieval_terms=[clean_label],
                    confidence=max(0.4, 1.0 - rewrite_score),
                )
            )
        diversified = self._enforce_probe_diversity(probes)
        selected_ids = {probe.probe_id for probe in diversified}
        validations = [
            item if item.probe_id in selected_ids else item.model_copy(update={"accepted": False, "rejection_reason": item.rejection_reason or "duplicate_probe_type"})
            for item in validations
        ]
        return diversified, validations

    def _enforce_probe_diversity(self, probes: list[KnowledgeAreaProbe]) -> list[KnowledgeAreaProbe]:
        selected: list[KnowledgeAreaProbe] = []
        seen_types: set[str] = set()
        for probe in probes:
            probe_type = probe.probe_type.value
            if probe_type in seen_types:
                continue
            selected.append(probe)
            seen_types.add(probe_type)
            if len(selected) >= self.policy.max_retrieval_probes:
                break
        if selected:
            return selected
        return probes[: self.policy.max_retrieval_probes]

    def _normalize_probe_exploration_questions(self, value: Any) -> dict[str, list[str]]:
        if not isinstance(value, list):
            return {}

        normalized: dict[str, list[str]] = {}
        for item in value:
            if not isinstance(item, dict):
                continue
            label = re.sub(r"\s+", " ", str(item.get("label") or item.get("Concept") or item.get("concept") or "")).strip(" :-")
            if not label:
                continue
            questions: list[str] = []
            for raw_question in item.get("exploration_questions") or []:
                question = re.sub(r"\s+", " ", str(raw_question or "")).strip()
                if not question:
                    continue
                if not question.endswith("?"):
                    question = f"{question.rstrip('.')}?"
                if question.casefold() in {existing.casefold() for existing in questions}:
                    continue
                questions.append(question)
                if len(questions) >= 5:
                    break
            if questions:
                normalized[label.casefold()] = questions[:5]
        return normalized

    def _fallback_exploration_questions(self, label: str, probe_type: ProbeType) -> list[str]:
        clean_label = str(label or "").strip()
        if not clean_label:
            return []

        direct_templates = {
            "integration capabilities": [
                "How does DAAN support enterprise integrations?",
                "What systems can DAAN connect to?",
                "What integration patterns are supported?",
                "How does DAAN exchange information with external platforms?",
            ],
            "workflow orchestration": [
                "How are workflows coordinated across systems?",
                "How does DAAN automate business processes?",
                "What workflow stages participate in delivery activities?",
                "How are work items managed through their lifecycle?",
            ],
            "platform components": [
                "What platform capabilities enable external integrations?",
                "How does DAAN support extensibility across enterprise systems?",
                "What architectural capabilities enable integration scenarios?",
                "What platform building blocks support workflow automation?",
            ],
        }
        matched_template = direct_templates.get(clean_label.casefold())
        if matched_template:
            return matched_template

        if probe_type == ProbeType.CAPABILITY:
            return [
                f"How does DAAN support {clean_label}?",
                f"What mechanisms or services enable {clean_label}?",
                f"Which systems or interfaces participate in {clean_label}?",
            ]
        if probe_type == ProbeType.WORKFLOW_STAGE:
            return [
                f"How is {clean_label} performed in DAAN?",
                f"Which steps or handoffs shape {clean_label}?",
                f"Which components or agents participate in {clean_label}?",
            ]
        if probe_type == ProbeType.PLATFORM_COMPONENT:
            return [
                f"Which DAAN components are involved in {clean_label}?",
                f"How do platform services contribute to {clean_label}?",
                f"Which agents or modules support {clean_label}?",
            ]
        if probe_type == ProbeType.ARTIFACT_CLASS:
            return [
                f"Which artifacts are needed for {clean_label}?",
                f"How are documents or inputs used in {clean_label}?",
                f"What outputs or deliverables are produced by {clean_label}?",
            ]
        if probe_type == ProbeType.ONTOLOGY_CONCEPT:
            return [
                f"Which entities or concepts define {clean_label}?",
                f"How does {clean_label} connect to adjacent graph concepts?",
                f"Which related ontology nodes matter for {clean_label}?",
            ]
        return [
            f"What does {clean_label} cover in DAAN?",
            f"How does {clean_label} influence the answer path?",
            f"Which capabilities, workflows, or components relate to {clean_label}?",
        ]

    def _classify_probe_type(self, label: str) -> ProbeType:
        lowered = str(label or "").casefold()
        if any(token in lowered for token in ("workflow", "process", "stage", "lifecycle", "onboarding")):
            return ProbeType.WORKFLOW_STAGE
        if any(token in lowered for token in ("artifact", "document", "requirements", "template", "file")):
            return ProbeType.ARTIFACT_CLASS
        if any(token in lowered for token in ("integration", "connector", "api", "sync")):
            return ProbeType.CAPABILITY
        if any(token in lowered for token in ("component", "platform", "agent", "service", "module")):
            return ProbeType.PLATFORM_COMPONENT
        if any(token in lowered for token in ("ontology", "entity", "concept", "knowledge base")):
            return ProbeType.ONTOLOGY_CONCEPT
        return ProbeType.DOMAIN

    def _probe_rewrite_score(self, candidate: str, blocked_texts: list[str]) -> float:
        candidate_folded = re.sub(r"\s+", " ", str(candidate or "").casefold()).strip()
        if not candidate_folded:
            return 1.0
        max_similarity = 0.0
        candidate_tokens = self._tokenize_probe_text(candidate_folded)
        for blocked in blocked_texts:
            blocked_folded = re.sub(r"\s+", " ", str(blocked or "").casefold()).strip()
            if not blocked_folded:
                continue
            similarity = SequenceMatcher(None, candidate_folded, blocked_folded).ratio()
            blocked_tokens = self._tokenize_probe_text(blocked_folded)
            overlap = 0.0
            if candidate_tokens and blocked_tokens:
                overlap = len(candidate_tokens & blocked_tokens) / max(1, len(candidate_tokens))
            max_similarity = max(max_similarity, similarity, overlap)
        return max_similarity

    @staticmethod
    def _clean_text(value: Any) -> str:
        return str(value or "").strip()

    @staticmethod
    def _bounded_float(value: Any) -> float:
        try:
            number = float(value)
        except (TypeError, ValueError):
            return 0.0
        return max(0.0, min(1.0, number))

    @staticmethod
    def _clean_list(value: Any, *, limit: int) -> list[str]:
        if limit <= 0 or not isinstance(value, list):
            return []
        normalized: list[str] = []
        for item in value:
            text = str(item or "").strip()
            if not text or text in normalized:
                continue
            normalized.append(text)
            if len(normalized) >= limit:
                break
        return normalized

    def _normalize_retrieval_probes(
        self,
        value: Any,
        *,
        query_text: str,
    ) -> list[str]:
        if self.policy.max_retrieval_probes <= 0:
            return []
        raw_probes = self._coerce_retrieval_probe_list(value, limit=self.policy.max_retrieval_probes * 2)
        blocked_texts = [query_text]

        normalized: list[str] = []
        for probe in raw_probes:
            if self._is_probe_query_rewrite(probe, blocked_texts):
                continue
            formatted_probe = self._format_retrieval_probe(probe)
            if formatted_probe and formatted_probe not in normalized:
                normalized.append(formatted_probe)
            if len(normalized) >= self.policy.max_retrieval_probes:
                break
        return normalized

    def _coerce_retrieval_probe_list(self, value: Any, *, limit: int) -> list[str]:
        if limit <= 0 or not isinstance(value, list):
            return []

        normalized: list[str] = []
        for item in value:
            text = ""
            if isinstance(item, dict):
                label = re.sub(r"\s+", " ", str(item.get("label") or item.get("Concept") or item.get("concept") or "")).strip(" :-")
                explanation = re.sub(
                    r"\s+",
                    " ",
                    str(
                        item.get("Short explanation")
                        or item.get("short_explanation")
                        or item.get("explanation")
                        or item.get("rationale")
                        or item.get("reason")
                        or ""
                    ),
                ).strip()
                if label:
                    text = f"{label}:\n{explanation}" if explanation else label
            else:
                text = str(item or "").strip()

            if not text or text in normalized:
                continue
            normalized.append(text)
            if len(normalized) >= limit:
                break
        return normalized

    def _format_retrieval_probe(self, probe: str) -> str:
        raw_probe = str(probe or "").strip()
        if not raw_probe:
            return ""

        label, explanation = self._split_probe_label_and_explanation(raw_probe)
        clean_label = re.sub(r"\s+", " ", label).strip(" :-")
        if not clean_label:
            return ""

        clean_explanation = re.sub(r"\s+", " ", explanation).strip()
        if not clean_explanation:
            clean_explanation = self._default_probe_explanation(clean_label)

        if clean_explanation and clean_explanation[-1] not in ".!?":
            clean_explanation += "."

        return f"{clean_label}:\n{clean_explanation}"

    @staticmethod
    def _split_probe_label_and_explanation(probe: str) -> tuple[str, str]:
        text = str(probe or "").strip()
        for delimiter in (":\n", ":", " - "):
            if delimiter not in text:
                continue
            label, explanation = text.split(delimiter, 1)
            if explanation.strip():
                return label.strip(), explanation.strip()
        return text, ""

    @staticmethod
    def _default_probe_explanation(label: str) -> str:
        label_lower = str(label or "").casefold()
        keyword_templates = [
            (("user story", "stories"), "Explores backlog decomposition, acceptance criteria, and delivery-ready story structure"),
            (("jira", "backlog", "sprint"), "Covers ticket workflows, acceptance criteria, status tracking, and delivery planning artifacts"),
            (("upload", "input", "onboarding"), "Identifies required source files, supporting inputs, templates, and onboarding artifacts needed to start the workflow"),
            (("requirement", "requirements"), "Focuses on business requirements, stakeholder expectations, and solution scope"),
            (("databricks", "notebook"), "Examines notebook assets, code generation patterns, workspace setup, and execution workflows relevant to Databricks delivery"),
            (("integration", "connector", "api"), "Focuses on system connections, authentication dependencies, workflow handoffs, and operational touchpoints"),
            (("migration", "modernization"), "Explores target architecture, transition planning, implementation dependencies, and delivery guidance"),
            (("analytics", "reporting", "dashboard"), "Covers analytical use cases, supporting data assets, and decision-making workflows tied to the request"),
        ]

        for keywords, template in keyword_templates:
            if any(keyword in label_lower for keyword in keywords):
                return template

        if len(label.split()) == 1:
            return "Represents related knowledge, supporting assets, and workflow context used for retrieval and graph exploration"
        return "Explores related workflows, entities, supporting assets, and business context relevant to the request"

    @staticmethod
    def _tokenize_probe_text(value: str) -> set[str]:
        stop_words = {
            "a", "an", "and", "are", "for", "from", "how", "i", "in", "is", "me", "my", "of", "on", "or", "should", "tell", "the", "this", "to", "use", "what", "with", "you", "your",
        }
        return {
            token
            for token in re.findall(r"[a-z0-9]+", str(value or "").lower())
            if len(token) > 2 and token not in stop_words
        }

    def _is_probe_query_rewrite(self, candidate: str, blocked_texts: list[str]) -> bool:
        normalized_candidate = str(candidate or "").strip()
        if not normalized_candidate:
            return True

        candidate_tokens = self._tokenize_probe_text(normalized_candidate)
        candidate_folded = re.sub(r"\s+", " ", normalized_candidate.casefold())
        for blocked in blocked_texts:
            normalized_blocked = str(blocked or "").strip()
            if not normalized_blocked:
                continue
            blocked_folded = re.sub(r"\s+", " ", normalized_blocked.casefold())
            if candidate_folded == blocked_folded:
                return True

            similarity = SequenceMatcher(None, candidate_folded, blocked_folded).ratio()
            if len(candidate_tokens) >= 3 and similarity >= 0.78:
                return True

            blocked_tokens = self._tokenize_probe_text(normalized_blocked)
            if len(candidate_tokens) >= 3 and blocked_tokens:
                overlap = len(candidate_tokens & blocked_tokens) / max(1, len(candidate_tokens))
                if overlap >= 0.8:
                    return True
        return False

    @staticmethod
    def _clean_metadata(value: Any) -> dict[str, Any]:
        if not isinstance(value, dict):
            return {}
        normalized: dict[str, Any] = {}
        for key, raw in value.items():
            clean_key = str(key or "").strip()
            if not clean_key:
                continue
            if isinstance(raw, (str, int, float, bool)):
                normalized[clean_key] = raw
        return normalized

    def _clean_missing_context(self, value: Any) -> list[MissingContextItem]:
        if not isinstance(value, list):
            return []
        items: list[MissingContextItem] = []
        for raw_item in value:
            if isinstance(raw_item, dict):
                item = MissingContextItem.model_validate(raw_item)
            else:
                item = MissingContextItem(field=str(raw_item or "").strip())
            if not item.field:
                continue
            items.append(item)
            if len(items) >= self.policy.max_missing_context:
                break
        return items

    def _record_outcome(
        self,
        *,
        result: ContextExtrapolationResult,
        kb_id: str,
        query_hash: str,
        latency_ms: float,
        error: str | None,
    ) -> None:
        telemetry = get_context_extrapolation_telemetry()
        self._last_runtime_trace = {
            "plan_generated": True,
            "plan_accepted": bool(result.use_plan),
            "plan_rejected": not bool(result.use_plan),
            "fallback_used": not bool(result.use_plan),
            "fallback_reason": result.fallback_reason,
            "confidence": round(result.overall_confidence, 4),
            "latency_ms": int(latency_ms),
            "intent": result.intent,
            "query_hash": query_hash,
            "error": error,
        }
        if self.policy.telemetry_enabled:
            telemetry.record_latency(latency_ms)
            telemetry.record_confidence(result.overall_confidence)
            if result.intent:
                telemetry.record_intent(result.intent)
            if result.use_plan:
                telemetry.record_accepted()
            else:
                telemetry.record_fallback()
            if error:
                telemetry.record_error()

        logger.info(
            "ContextExtrapolationAgent completed",
            extra={
                "query_hash": query_hash,
                "kb_id": kb_id,
                "intent": result.intent,
                "persona": result.persona,
                "confidence": round(result.overall_confidence, 4),
                "fallback_used": not result.use_plan,
                "latency_ms": int(latency_ms),
                "error": error,
            },
        )

    @staticmethod
    def _query_hash(query: str) -> str:
        return hashlib.sha1(query.strip().lower().encode("utf-8")).hexdigest()[:16] if query.strip() else ""

    @staticmethod
    def _looks_like_timeout(exc: Exception) -> bool:
        text = str(exc).casefold()
        return "timeout" in text or "timed out" in text

    @staticmethod
    def _finish_reason(raw: Any) -> str | None:
        if isinstance(raw, dict):
            choices = raw.get("choices") or []
            if choices:
                return choices[0].get("finish_reason")
        choices = getattr(raw, "choices", None)
        if choices:
            return getattr(choices[0], "finish_reason", None)
        return None

    def _invoke_completion(self, prompt: str) -> Any:
        timeout_seconds = self.policy.timeout_ms / 1000.0
        provider_runtime_spec = None if self.llm_provider is not None else self._ensure_provider_runtime_spec()
        if self._should_use_in_process_timeout(provider_runtime_spec):
            return self._invoke_completion_in_process(prompt, timeout_seconds, provider_runtime_spec)
        main_module = sys.modules.get("__main__")
        main_path = getattr(main_module, "__file__", None)
        if not main_path or str(main_path).endswith("<stdin>"):
            if self.llm_provider is not None:
                return _call_provider_completion(self.llm_provider, prompt, timeout_seconds)
            return _call_agent_internal_completion(provider_runtime_spec, prompt, timeout_seconds)
        context = mp.get_context("spawn")
        result_queue = context.Queue(maxsize=1)
        process = context.Process(
            target=_completion_worker,
            args=(self.llm_provider, provider_runtime_spec, prompt, timeout_seconds, result_queue),
            daemon=True,
        )
        try:
            process.start()
        except Exception as exc:  # noqa: BLE001
            raise RuntimeError(f"ContextExtrapolationAgent timeout isolation unavailable: {exc}") from exc

        process.join(timeout_seconds)
        if process.is_alive():
            process.terminate()
            process.join()
            raise TimeoutError(f"ContextExtrapolationAgent timed out after {timeout_seconds:.3f}s")

        try:
            status, payload = result_queue.get_nowait()
        except Empty as exc:
            raise RuntimeError(
                f"ContextExtrapolationAgent worker exited without a result (exitcode={process.exitcode})"
            ) from exc

        if status == "ok":
            return payload
        _raise_worker_error(payload)

    def _invoke_completion_in_process(self, prompt: str, timeout_seconds: float, provider_runtime_spec: dict[str, Any] | None) -> Any:
        def run_completion() -> Any:
            if self.llm_provider is not None:
                return _call_provider_completion(self.llm_provider, prompt, timeout_seconds)
            return _call_agent_internal_completion(provider_runtime_spec or {}, prompt, timeout_seconds)

        future = _ce_executor.submit(run_completion)
        try:
            return future.result(timeout=timeout_seconds + 0.25)
        except FutureTimeoutError as exc:
            future.cancel()
            raise TimeoutError(f"ContextExtrapolationAgent timed out after {timeout_seconds:.3f}s") from exc

    def _should_use_in_process_timeout(self, provider_runtime_spec: dict[str, Any] | None) -> bool:
        if self.llm_provider is not None:
            provider_name = str(getattr(self.llm_provider, "provider_name", "") or getattr(self.llm_provider, "provider", "")).strip().lower()
            return provider_name in {"azure_openai", "openai"}
        provider_name = str((provider_runtime_spec or {}).get("provider") or "").strip().lower()
        return provider_name in {"azure_openai", "openai"}

    def _ensure_provider_runtime_spec(self) -> dict[str, Any]:
        if self._provider_runtime_spec is None:
            self._provider_runtime_spec = _load_context_extrapolation_provider_spec(self._provider_name_override)
        return dict(self._provider_runtime_spec)
