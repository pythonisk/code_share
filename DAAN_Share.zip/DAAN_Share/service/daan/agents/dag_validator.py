"""DAG validation for the workflow builder.

Rules enforced:
1. All dynamic agents must precede all action agents.
2. Each action agent must receive input from at least one upstream agent.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def _parse_dependency_values(value: str | None) -> list[str]:
    normalized = str(value or "").strip().strip("[]")
    if not normalized or normalized == "—":
        return []
    return [item.strip().strip("[]") for item in normalized.split(",") if item.strip()]


def validate_dag(agents: list[dict]) -> None:
    """Validate a flat agent list. Structural checks only — no agent-type ordering.

    Agent type (dynamic vs action) no longer constrains position; the only
    difference between them is that dynamic agents accept feedback. Here we just
    ensure agent ids are present and unique.
    """
    if not agents:
        return

    seen: set[str] = set()
    for i, agent in enumerate(agents):
        agent_id = str(agent.get("agent_id") or "").strip() or f"agent_at_index_{i}"
        if agent_id in seen:
            raise ValueError(f"Agent '{agent_id}' appears more than once.")
        seen.add(agent_id)

    logger.debug("DAG validation passed for %d agents", len(agents))


# ---------------------------------------------------------------------------
# Extended DAG parser — supports parallel and loop notation
# ---------------------------------------------------------------------------

def _split_dag_tokens(dag_str: str) -> list[str]:
    """Split a dag string on '>' but only at depth 0 (outside brackets).

    Examples:
        'A>B>C'          → ['A', 'B', 'C']
        '[{A},{B}]>C'    → ['[{A},{B}]', 'C']
    """
    tokens: list[str] = []
    depth = 0
    current: list[str] = []
    for ch in dag_str:
        if ch in "([{":
            depth += 1
            current.append(ch)
        elif ch in ")]}":
            depth -= 1
            current.append(ch)
        elif ch == ">" and depth == 0:
            token = "".join(current).strip()
            if token:
                tokens.append(token)
            current = []
        else:
            current.append(ch)
    last = "".join(current).strip()
    if last:
        tokens.append(last)
    return tokens


def parse_dag_stages(dag_str: str) -> list[dict]:
    """Parse an extended DAG notation string into a list of stage descriptors.

    Supported notation
    ------------------
    ``A>B>C``          Sequential stages — existing behaviour, unchanged.
    ``[A,B]>C``        Parallel stage (A and B run concurrently), then C.
    ``{A}>C``          Loop stage  (A loops over batches independently), then C.
    ``[{A},{B}]>C``    Parallel-loop stage (A and B each loop independently
                       and simultaneously), then C.
    ``[A,{B}]>C``      Mixed parallel stage where A runs once and B loops.

    Each stage descriptor is a dict with:
        ``type``   — one of ``'sequential'``, ``'parallel'``,
                     ``'loop'``, ``'parallel_loop'``
        ``agents`` — list of agent_id strings

    Args:
        dag_str: Raw DAG string from the ``UseCase.dag`` column.

    Returns:
        Ordered list of stage dicts.  Returns ``[]`` for empty input.
    """
    if not dag_str or not dag_str.strip():
        return []

    stages: list[dict] = []
    for token in _split_dag_tokens(dag_str.strip()):
        token = token.strip()
        if not token:
            continue

        # ── Outer square bracket → parallel or parallel_loop ──────────────
        if token.startswith("[") and token.endswith("]"):
            inner = token[1:-1]  # strip outer []
            # Split inner by comma (agent IDs never contain commas)
            items = [x.strip() for x in inner.split(",") if x.strip()]
            loop_agents: list[str] = []
            plain_agents: list[str] = []
            for item in items:
                if item.startswith("{") and item.endswith("}"):
                    loop_agents.append(item[1:-1].strip())
                else:
                    plain_agents.append(item)

            if loop_agents and not plain_agents:
                # [{A},{B}] — every item wrapped in {} → parallel_loop
                stages.append({"type": "parallel_loop", "agents": loop_agents})
            elif plain_agents and not loop_agents:
                # [A,B] — plain parallel
                stages.append({"type": "parallel", "agents": plain_agents})
            else:
                # [A,{B}] — mixed stage: preserve loop membership in metadata
                agents = [
                    (x[1:-1].strip() if x.startswith("{") and x.endswith("}") else x)
                    for x in items
                ]
                stages.append({"type": "parallel", "agents": agents, "loop_agents": loop_agents})

        # ── Curly brace → single-agent loop ───────────────────────────────
        elif token.startswith("{") and token.endswith("}"):
            agent_id = token[1:-1].strip()
            stages.append({"type": "loop", "agents": [agent_id]})

        # ── Plain token → sequential ───────────────────────────────────────
        else:
            stages.append({"type": "sequential", "agents": [token]})

    return stages


def _build_stage_token(stage_type: str, agent_ids: list[str], loop_agent_ids: list[str] | None = None) -> str:
    loop_agent_set = {agent_id for agent_id in (loop_agent_ids or []) if agent_id}
    if stage_type == "loop":
        return f"{{{agent_ids[0]}}}"
    if stage_type == "parallel_loop":
        return "[" + ",".join(f"{{{agent_id}}}" for agent_id in agent_ids) + "]"
    if stage_type == "parallel":
        tokens = [
            (f"{{{agent_id}}}" if agent_id in loop_agent_set else agent_id)
            for agent_id in agent_ids
        ]
        return "[" + ",".join(tokens) + "]"
    return agent_ids[0]


def remap_dag_agent_ids(dag_str: str, agent_id_mapping: dict[str, str]) -> str:
    stages = parse_dag_stages(dag_str)
    if not stages:
        return ""

    tokens: list[str] = []
    for stage in stages:
        mapped_agents = [agent_id_mapping.get(agent_id, agent_id) for agent_id in stage["agents"]]
        mapped_loop_agents = [
            agent_id_mapping.get(agent_id, agent_id)
            for agent_id in stage.get("loop_agents", [])
        ]
        tokens.append(_build_stage_token(stage["type"], mapped_agents, mapped_loop_agents))
    return ">".join(tokens)


def flatten_dag_agent_order(dag_str: str) -> list[str]:
    ordered_agent_ids: list[str] = []
    for stage in parse_dag_stages(dag_str):
        ordered_agent_ids.extend(stage["agents"])
    return ordered_agent_ids


def remove_agent_from_dag(dag_str: str | None, agent_id: str) -> str:
    stages = parse_dag_stages(dag_str or "")
    if not stages:
        return ""

    tokens: list[str] = []
    for stage in stages:
        remaining_agents = [candidate for candidate in stage["agents"] if candidate != agent_id]
        if not remaining_agents:
            continue

        next_stage_type = stage["type"]
        remaining_loop_agents = [
            candidate for candidate in stage.get("loop_agents", []) if candidate in remaining_agents
        ]

        if next_stage_type == "parallel_loop" and len(remaining_agents) == 1:
            next_stage_type = "loop"
        elif next_stage_type == "parallel" and len(remaining_agents) == 1:
            next_stage_type = "loop" if remaining_loop_agents else "sequential"

        tokens.append(_build_stage_token(next_stage_type, remaining_agents, remaining_loop_agents))

    return ">".join(tokens)


def validate_stage_dag(dag_str: str, agents: list[dict]) -> None:
    stages = parse_dag_stages(dag_str)
    if not stages:
        raise ValueError("DAG is required for flow validation.")

    agent_map: dict[str, dict] = {}
    for agent in agents:
        agent_id = str(agent.get("agent_id") or "").strip()
        if not agent_id:
            raise ValueError("Each agent must include a non-empty agent_id.")
        if agent_id in agent_map:
            raise ValueError(f"Agent '{agent_id}' appears more than once in the submitted payload.")
        agent_map[agent_id] = agent

    ordered_stage_types: list[str] = []
    for stage_index, stage in enumerate(stages):
        stage_type = str(stage.get("type") or "sequential")
        stage_agents = [str(agent_id).strip() for agent_id in stage.get("agents") or [] if str(agent_id).strip()]
        if not stage_agents:
            raise ValueError(f"Stage {stage_index + 1} in the DAG is empty.")

        ordered_stage_types.append(stage_type)
        for agent_id in stage_agents:
            if agent_id not in agent_map:
                raise ValueError(f"Agent '{agent_id}' is referenced in the DAG but missing from the submitted payload.")
            if any(agent_id in existing_stage.get("agents", []) for existing_stage in stages[:stage_index]):
                raise ValueError(f"Agent '{agent_id}' appears more than once in the DAG.")

    dag_agent_ids = {agent_id for stage in stages for agent_id in stage.get("agents", [])}
    payload_only_agents = sorted(set(agent_map) - dag_agent_ids)
    if payload_only_agents:
        raise ValueError(
            "These submitted agents are missing from the DAG: " + ", ".join(payload_only_agents)
        )

    stage_index_by_agent: dict[str, int] = {}
    for stage_index, stage in enumerate(stages):
        for agent_id in stage["agents"]:
            stage_index_by_agent[agent_id] = stage_index

    def _deps(cfg: dict) -> list[str]:
        raw = cfg.get("depends_on")
        if raw is None:
            raw = cfg.get("depend_on")
        if isinstance(raw, list):
            raw = ",".join(str(x) for x in raw)
        return _parse_dependency_values(raw)

    # Structural stage-shape checks only (parallelism); no agent-type ordering.
    for stage_index, stage in enumerate(stages):
        stage_type = ordered_stage_types[stage_index]
        stage_agents = stage["agents"]

        if len(stage_agents) > 1 and stage_type not in {"parallel", "parallel_loop"}:
            raise ValueError(f"Stage {stage_index + 1} contains multiple agents but is not marked as parallel.")

        if stage_type == "parallel_loop" and len(stage_agents) < 2:
            raise ValueError(f"Stage {stage_index + 1} uses parallel_loop but contains fewer than two agents.")

        if stage_type == "parallel":
            stage_loop_agents = [
                str(agent_id).strip()
                for agent_id in stage.get("loop_agents", [])
                if str(agent_id).strip()
            ]
            if any(agent_id not in stage_agents for agent_id in stage_loop_agents):
                raise ValueError(
                    f"Stage {stage_index + 1} has loop_agents that are not part of the stage agents list."
                )

        # An agent cannot depend on a sibling running in its own stage.
        stage_agent_set = set(stage_agents)
        for agent_id in stage_agents:
            for dep in _deps(agent_map[agent_id]):
                if dep in stage_agent_set:
                    raise ValueError(
                        f"Agent '{agent_id}' depends on '{dep}', which runs in the same stage "
                        f"(stage {stage_index + 1}). Move it to a later stage."
                    )

    # Dependencies must point to earlier stages; this also rejects cycles.
    for agent_id, cfg in agent_map.items():
        for dep in _deps(cfg):
            if dep not in agent_map:
                continue
            if stage_index_by_agent.get(dep, -1) >= stage_index_by_agent.get(agent_id, 0):
                raise ValueError(
                    f"Agent '{agent_id}' depends on '{dep}', which does not run before it. "
                    "Dependencies must point to earlier stages (no cycles)."
                )

    logger.debug("Stage-aware DAG validation passed for %d agents", len(agents))
