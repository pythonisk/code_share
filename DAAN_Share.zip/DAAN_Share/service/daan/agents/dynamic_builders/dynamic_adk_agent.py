"""
Dynamic ADK Agent using Google ADK.
Accepts agent configuration JSON directly from API (no YAML file dependency).
"""

import logging
import re
from typing import Any, Optional

logger = logging.getLogger(__name__)

from google.adk.agents import Agent
from daan.agents.agent_type_utils import is_action_agent
from daan.core.observers.reasoning_observer import (
    build_reasoning_callbacks,
    compose_callback_kwargs,
)
from daan.guardrails.adk_callbacks import build_adk_guardrail_callbacks
from daan.llm.llm_provider import build_llm_tags, create_litellm_model, get_default_provider_name
from daan.mcp_servers.core.mcp_toolset_provider import get_mcp_toolset
from daan.native_tools.tools_loader import get_local_tools
from daan.rag.rag_context_builder import build_rag_runtime_components, load_rag_config
from daan.rag.rag_context_injector import RagContextInjector
from daan.rag.retrieval.retriever_factory import RetrieverFactory


def _safe_name(value: str) -> str:
    """Convert a string to a safe identifier name."""
    candidate = re.sub(r'\W+', '_', value or "dynamic_agent")
    if not candidate:
        candidate = "dynamic_agent"
    if not candidate[0].isalpha() and candidate[0] != '_':
        candidate = '_' + candidate
    return candidate


def _parse_list_string(value: str | list | None) -> list[str]:
    """
    Parse a list from string format used in CSV/API.
    Handles formats like: "[item1,item2]", "item1,item2", "[item1]", or actual lists.
    """
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if v]
    
    value_str = str(value).strip()
    if not value_str or value_str in ('[]', ''):
        return []
    
    # Remove surrounding brackets if present
    if value_str.startswith('[') and value_str.endswith(']'):
        value_str = value_str[1:-1]
    
    # Split by comma and clean up
    items = [item.strip() for item in value_str.split(',') if item.strip()]
    return items


def _resolve_preloaded_mcp_entry(
    pre_loaded_mcp_toolsets: dict[str, Any] | None,
    requested_server: str,
) -> tuple[list[Any], str, str, str] | None:
    """Return normalized preloaded MCP metadata for a requested server."""
    if not pre_loaded_mcp_toolsets or requested_server not in pre_loaded_mcp_toolsets:
        return None

    cached = pre_loaded_mcp_toolsets[requested_server]
    requested_name = requested_server
    resolved_name = requested_server
    source = "workflow"

    if isinstance(cached, dict) and "toolsets" in cached:
        requested_name = str(cached.get("requested_server") or requested_server)
        resolved_name = str(cached.get("resolved_server") or requested_name)
        source = str(cached.get("source") or source)
        cached = cached.get("toolsets") or []

    toolsets: list[Any] = []
    if isinstance(cached, list):
        for item in cached:
            if isinstance(item, list):
                toolsets.extend(item)
            else:
                toolsets.append(item)
    elif cached:
        toolsets.append(cached)

    return toolsets, requested_name, resolved_name, source


def get_provider_name(agent_config: dict) -> str:
    """Extract provider name from agent config with fallback to default."""
    default_provider_name = get_default_provider_name()

    if not isinstance(agent_config, dict):
        return default_provider_name

    provider_name = (
        agent_config.get("provider")
        or agent_config.get("llm_provider")
        or agent_config.get("model_provider")
    )

    if provider_name is None:
        return default_provider_name

    provider_text = str(provider_name).strip()
    return provider_text or default_provider_name


def get_agent_model(agent_config: dict) -> Optional[str]:
    """Return the per-agent LiteLLM model id if set, else None (use default)."""
    if not isinstance(agent_config, dict):
        return None
    raw = (
        agent_config.get("model")
        or agent_config.get("llm_model")
        or agent_config.get("model_id")
    )
    if raw is None:
        return None
    value = str(raw).strip()
    return value or None


def _neutralize_instruction_placeholders(text: str) -> str:
    """Replace brace-delimited doc placeholders with literal labels.

    Google ADK treats brace-wrapped segments in instructions as session-state
    template variables at runtime. Prompts in this repo use placeholders like
    {databricks_pyspark_markdown} only as human-readable documentation, so they
    must be converted to a non-template form before the Agent is created.
    """
    return re.sub(r'\{+\s*([a-zA-Z_][a-zA-Z0-9_()\-. ]*)\s*\}+', r'[\1]', text)


def _inject_rag_context_if_configured(instruction: str, agent_json: dict[str, Any]) -> str:
    """Inject retrieved RAG context into the agent instruction when rag block is present."""
    rag_block = agent_json.get("rag")
    if not isinstance(rag_block, dict):
        return instruction

    query = str(agent_json.get("query") or agent_json.get("user_prompt") or "").strip()
    if not query:
        return instruction

    try:
        rag_config = load_rag_config()
        base_retriever_config = build_rag_runtime_components(rag_config)
        # Validate configured retriever early for clearer errors.
        RetrieverFactory.get_available_retrievers()
        injector = RagContextInjector(base_retriever_config=base_retriever_config)
        return injector.inject(system_prompt=instruction, query=query, rag_config=rag_block)
    except Exception as exc:
        print(f"Warning: RAG context injection skipped for agent '{agent_json.get('agent_name', 'dynamic_agent')}': {exc}")
        return instruction


def add_rag_search_tool(tools: list[Any], agent_json: dict[str, Any]) -> None:
    """Add RagTool.search as an additional local callable when rag block is present."""
    rag_block = agent_json.get("rag")
    if not isinstance(rag_block, dict):
        return

    try:
        from daan.native_tools.rag_tool import RagTool

        rag_config = load_rag_config()
        rag_tool = RagTool(rag_config)
        tools.append(rag_tool.search)
        print("Added local tool: RagTool.search")
    except Exception as exc:
        print(f"Warning: failed to add RagTool.search: {exc}")


def create_adk_agent(
    session_id: str,
    agent_json: dict[str, Any],
    pre_loaded_mcp_toolsets: dict[str, Any] | None = None,
    tool_kwargs: dict[str, Any] | None = None,
) -> Agent:
    """
    Create an ADK Agent from JSON configuration (from API).
    
    Args:
        session_id: Current workflow session ID.
        agent_json: Agent configuration dict with fields:
            - agent_name: str (required)
            - agent_id: str (optional)
            - role: str (optional)
            - agent_type: str (optional, e.g., "dynamic_agent", "action_agent")
            - prompt: str (required, the actual prompt content)
            - actions: str (optional, agent actions description)
            - output: str (optional, expected output format)
            - mcp_tools: str | list (optional, e.g., "[jira-mcp-server]")
            - local_tools: str | list (optional, e.g., "JiraStoryPublisher.post_stories_to_jira")
            - guardrails: str | list (optional, e.g., "before_model:pii_masking")
            - provider: str (optional, LLM provider name)
            - depends_on: str | list (optional, agent dependencies)
        pre_loaded_mcp_toolsets: Dictionary of already-initialized MCP server connections.
            Comes from initialize_mcp_for_agents() and contains authenticated connections
            to external services (Jira, Trello, etc) keyed by requested MCP server name.
            Entries may also include resolved-server metadata when workflow preload used
            an MCP fallback.
    
    Returns:
        Configured ADK Agent instance
    """
    # Extract agent name (required)
    agent_name = agent_json.get("agent_name") or agent_json.get("name") or "dynamic_agent"
    
    # Extract prompt/instruction (required)
    instruction = (
        agent_json.get("prompt")
        or agent_json.get("instruction")
        or ""
    )
    if not instruction:
        raise ValueError(f"Agent '{agent_name}' must have 'prompt' or 'instruction' field")

    # Google ADK resolves brace-wrapped text in agent instructions against
    # session state at runtime. Prompt markdown files use these placeholders
    # only as documentation, so convert them to a neutral literal form.
    instruction = _neutralize_instruction_placeholders(instruction)
    instruction = _inject_rag_context_if_configured(instruction, agent_json)

    applied_lessons = [
        str(item.get("comment") or "").strip()
        for item in (agent_json.get("applied_learning_history") or [])
        if isinstance(item, dict) and str(item.get("comment") or "").strip()
    ]
    if applied_lessons:
        lesson_lines = "\n".join(
            f"{index}. {lesson}" for index, lesson in enumerate(applied_lessons, start=1)
        )
        instruction += (
            "\n\n### Applied lessons learned\n"
            "Apply each of these user-selected lessons while completing this workflow task:\n"
            f"{lesson_lines}"
        )

    # For action agents, DAAN passes a JSON payload as the user message containing
    # the approved output to publish. Make this explicit so the model consistently
    # supplies required tool parameters like `reviewed_output`.
    if is_action_agent(agent_json.get("agent_type")):
        instruction_prefix = (
            "You are an Action Agent that MUST execute a publishing or upload task using the provided tools.\n"
            "The latest user message is a JSON string. Extract the following fields from it:\n"
            "- dynamic_agent_outputs_structured: object (preferred structured upstream outputs when present)\n"
            "- dynamic_agent_outputs: object (fallback raw upstream outputs when structured data is unavailable)\n"
            "- reviewed_output: string (optional compatibility fallback for publishers that require combined text)\n"
            "- Any additional credential or config fields present in the JSON\n"
            "  (e.g. databricks_workspace_url, databricks_token,\n"
            "   jira_project_key, trello_board_id, etc.) — extract and pass them to tools.\n\n"
            "Before calling any tool, parse the JSON and extract ALL required parameters.\n"
            "Pass the correct parameters to the tool — do NOT hardcode or invent any values.\n"
            "ALWAYS extract the parameter values from the JSON before calling any tool.\n\n"
            "IDEMPOTENCY AND RE-RUN RULES:\n"
            "- The JSON may include an 'existing_resources' field: an object keyed by agent id, "
            "whose value is a list of resources you created in a previous run. Each resource has "
            "a 'local_key' (a stable key you assigned to that item), a 'resource_key' or 'id' "
            "(the external id returned by the tool, e.g. an Azure DevOps work item id or a Jira "
            "issue key), a 'resource_type', an optional 'resource_kind', and an 'external_url'.\n"
            "- If 'existing_resources' is present and non-empty, you MUST UPDATE those existing "
            "resources by their external id/key using the appropriate UPDATE tool (for example "
            "wit_update_work_item for Azure DevOps, or JIRAUpdateIssueTool for Jira) instead of "
            "creating new ones. Do NOT create a duplicate epic, work item, issue, or page.\n"
            "- Match items by 'local_key': update the resource that has the same local_key, and "
            "only create genuinely new items that have no matching local_key.\n\n"
            "STABLE CHILD RECONCILIATION (add / update / remove):\n"
            "- The JSON may include a 'desired_child_items' field describing the CURRENT desired "
            "state parsed deterministically from the approved content: an optional 'epic' object "
            "and a 'children' array. Every item carries a STABLE 'local_key' derived from the "
            "item's own content (its Story ID or title), plus a 'title' and 'kind'. These "
            "local_keys are stable across re-runs — you MUST use them verbatim; do not invent "
            "positional keys like ITEM_001.\n"
            "- Reconcile 'desired_child_items' against 'existing_resources' strictly by local_key:\n"
            "  * local_key in desired AND in existing → UPDATE that external resource by its id.\n"
            "  * local_key in desired but NOT in existing → CREATE it via the create tool and use "
            "the new id the tool returns.\n"
            "  * local_key in existing but NOT in desired → the item was removed: DELETE or close "
            "that external resource by its id.\n"
            "- IMPORTANT transition rule: an existing resource may have been recorded under an "
            "older local_key naming scheme. Before treating a desired item as new (create) or an "
            "existing item as removed (delete), also compare by 'title' (case-insensitive): if a "
            "desired item's title matches an existing resource's title, treat them as the SAME "
            "item and UPDATE it (adopting the new stable local_key) rather than creating a "
            "duplicate or deleting it. Only DELETE an existing resource when its title matches no "
            "desired item.\n"
            "- When 'desired_child_items' is present, the manifest you emit MUST contain exactly "
            "one entry per desired item (epic + children), using the desired local_keys, and no "
            "entries for items you deleted.\n\n"
            "RESOURCE MANIFEST (REQUIRED OUTPUT):\n"
            "- After you finish all tool calls, append at the very end of your response a fenced "
            "code block using three backticks with the language tag daan-resources.\n"
            "- Inside that block output a single JSON object whose only key is \"resources\" and "
            "whose value is an array. Each array element is a JSON object with these string "
            "fields: local_key (the stable key for the item, reused across runs), title (the "
            "item's title/summary, used to match items across runs), type (the resource type such "
            "as ado_work_item or jira_issue), kind (optional, e.g. epic or user_story), id (the "
            "external id or key returned by the tool), and url (a link to the resource).\n"
            "- Emit exactly one array element per external resource you created or updated, and "
            "always emit this block — including on updates. Reuse the same local_key values that "
            "were provided in 'existing_resources' so the resources stay linked across re-runs.\n"
            "- Each external id must appear at most once in the manifest. NEVER list the same "
            "external id under two different local_keys, and NEVER assign an id that already "
            "exists in 'existing_resources' to a new local_key. A genuinely new item must be "
            "created through the create tool and use the NEW id that tool returns; if you did "
            "not actually create a new external item, do not add a new manifest entry for it.\n\n"
            "APPLYING USER FEEDBACK:\n"
            "- The JSON may include a 'feedback_instruction' field: a natural-language request "
            "from the user to modify what was previously published (for example 'add one more "
            "task in the epic', 'rename the second story', or 'remove the last item').\n"
            "- When 'feedback_instruction' is present, apply exactly that change to the external "
            "system using the tools: UPDATE existing resources listed in 'existing_resources' by "
            "their id/key, CREATE only the genuinely new items the instruction asks for, and "
            "DELETE/close items the instruction says to remove. Do not re-create items that "
            "already exist. Then emit the resource manifest reflecting the final state.\n"
            "Prefer structured fields over raw text when both are available.\n"
            "Keep tool-call arguments minimal; do not copy large upstream payloads into tool parameters unless the tool explicitly requires them.\n"
            "ALWAYS extract the parameter values from the JSON before calling any tool.\n"
        )
        instruction = instruction_prefix + "\n" + instruction
    
    # Get LLM model
    provider_name = get_provider_name(agent_json)
    # Attach LiteLLM tracking tags (app, user, session, agent) so every call this
    # agent makes is attributable in the LiteLLM Admin UI (Logs view).
    llm_tags = build_llm_tags(
        agent_name=agent_name,
        agent_type=str(agent_json.get("agent_type") or "dynamic_agent"),
    )
    # Per-agent reasoning override: {"enabled": bool, "budget_tokens": int}. Falls
    # back to litellm.reasoning in llm_config.yml when the agent JSON omits it.
    agent_reasoning = agent_json.get("reasoning") if isinstance(agent_json.get("reasoning"), dict) else None
    model, provider_info = create_litellm_model(
        provider_name, tags=llm_tags, model_name=get_agent_model(agent_json)
    , reasoning=agent_reasoning)
    logger.info("Using provider '%s' for agent '%s'", provider_name, agent_name, extra={"session_id": session_id})
    # Load MCP tools for this agent.
    # MCP servers provide access to external tools (Jira tasks, Trello cards, etc).
    mcp_tools_list = _parse_list_string(agent_json.get("mcp_tools"))
    mcp_toolsets = []
    
    for mcp_server_name in mcp_tools_list:
        # Check if this MCP server's connection was already established by initialize_mcp_for_agents()
        preload_entry = _resolve_preloaded_mcp_entry(pre_loaded_mcp_toolsets, mcp_server_name)
        if preload_entry is not None:
            cached_toolsets, requested_name, resolved_name, preload_source = preload_entry
            mcp_toolsets.extend(cached_toolsets)
            logger.info(
                "Loaded MCP tools from requested server '%s' resolved as '%s' (%s preload) for agent '%s'",
                requested_name,
                resolved_name,
                preload_source,
                agent_name,
                extra={"session_id": session_id},
            )
        else:
            # Fallback: If MCP server wasn't pre-initialized (unexpected), try loading it now.
            # This handles edge cases where an agent's MCP server was missed during initialization.
            # Pass session_id as extra_env so MCP subprocess has context. Credentials are expected
            # to already be in the parent process environment from the initial credential resolution.
            try:
                runtime_env = {"DAAN_SESSION_ID": session_id} if session_id else None
                loaded = get_mcp_toolset(mcp_server_name, extra_env=runtime_env)
                loaded_list = loaded if isinstance(loaded, list) else [loaded]
                loaded_list = [ts for ts in loaded_list if ts is not None]
                if loaded_list:
                    mcp_toolsets.extend(loaded_list)
                    logger.info(
                        "Loaded MCP tools from requested server '%s' resolved as '%s' (just-in-time load) for agent '%s'",
                        mcp_server_name,
                        mcp_server_name,
                        agent_name,
                        extra={"session_id": session_id},
                    )
                else:
                    logger.warning(
                        "MCP server '%s' produced no tools (not found in YAML/DB registry) for agent '%s'",
                        mcp_server_name,
                        agent_name,
                        extra={"session_id": session_id},
                    )
            except Exception as e:
                logger.warning("MCP server '%s' unavailable for '%s': %s", mcp_server_name, agent_name, e, extra={"session_id": session_id})

    # Parse and load local (native) tools
    local_tools_list = _parse_list_string(agent_json.get("local_tools"))
    local_tool_fns = []
    for tool_ref in local_tools_list:
        fn = get_local_tools(tool_ref, tool_kwargs=tool_kwargs)
        if fn is not None:
            local_tool_fns.append(fn)
            logger.info("Loaded local tool '%s' for agent '%s'", tool_ref, agent_name, extra={"session_id": session_id})
        else:
            logger.warning("Failed to load local tool '%s' for agent '%s'", tool_ref, agent_name)

    # Combine: MCP tools first, then local tools; optionally augment with RagTool.search
    tools = mcp_toolsets + local_tool_fns
    add_rag_search_tool(tools, agent_json)

    # Log tool status
    if tools:
        logger.debug("Agent '%s': %d MCP tool(s), %d local tool(s)", agent_name, len(mcp_toolsets), len(local_tool_fns))
    else:
        logger.warning("Agent '%s': No tools configured.", agent_name)
    
    # Build description from available fields
    description = (
        agent_json.get("description")
        or agent_json.get("actions")
        or agent_json.get("task")
        or agent_name
    )
    
    # Create the agent
    safe_name = _safe_name(agent_name)
    callback_kwargs = build_adk_guardrail_callbacks(agent_json)
    observer_kwargs = build_reasoning_callbacks(
        session_id=session_id,
        agent_id=str(agent_json.get("agent_id") or ""),
        agent_name=agent_name,
    )
    callback_kwargs = compose_callback_kwargs(callback_kwargs, observer_kwargs)
    agent = Agent(
        name=safe_name,
        model=model,
        description=description,
        instruction=instruction,
        tools=tools,
        **callback_kwargs,
    )
    
    # Attach provider metadata
    agent._provider_name = provider_info['provider']
    agent._model_name = provider_info['model']
    agent._provider_config = provider_info['config']
    
    # Attach additional metadata for orchestration
    agent._agent_id = agent_json.get("agent_id", "")
    agent._agent_type = agent_json.get("agent_type", "dynamic_agent")
    agent._depends_on = _parse_list_string(agent_json.get("depends_on"))
    agent._output_format = agent_json.get("output") or agent_json.get("output_format", "")
    agent._output_validators = _parse_list_string(agent_json.get("output_validators"))
    agent._guardrails = agent_json.get("guardrails") or ""
    
    return agent
