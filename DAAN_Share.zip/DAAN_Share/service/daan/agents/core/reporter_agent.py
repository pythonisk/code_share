"""
Reporter Agent - Generates a summary report from all agent outputs.

This is a Google ADK agent that:
1. Takes all agent outputs (dynamic_agents + ActionAgents)
2. Generates a comprehensive markdown report
"""

import asyncio
import json

from google.adk.agents import Agent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from daan.llm.cost_tracking import extract_model_provider_from_event, extract_usage_from_event
from daan.llm.llm_provider import (
    build_llm_tags,
    create_litellm_model,
    get_core_agent_model,
    get_default_provider_name,
)
from daan.prompt_catalog.prompt_service import get_core_prompt


def _load_reporter_prompt() -> str:
    """Load the reporter agent prompt from data/core/prompts/reporter_agent.prompt.md."""
    return get_core_prompt("reporter_agent")["prompt"]


def create_reporter_agent(provider: str | None = None) -> Agent:
    """
    Create the Reporter ADK agent.

    Args:
        provider: Optional LLM provider name. Uses default if not specified.

    Returns:
        Configured ADK Agent for report generation
    """
    provider_name = provider or get_default_provider_name()
    model, provider_info = create_litellm_model(
        provider_name,
        tags=build_llm_tags(component="reporter_agent"),
        model_name=get_core_agent_model("reporter_agent"),
    )

    agent = Agent(
        name="reporter_agent",
        model=model,
        description="Generates comprehensive reports from agent execution outputs",
        instruction=_load_reporter_prompt(),
        tools=[],
    )

    # Attach provider metadata
    agent._provider_name = provider_info['provider']
    agent._model_name = provider_info['model']
    agent._provider_config = provider_info['config']

    return agent


async def _run_agent_async(agent: Agent, message: str) -> tuple[str, dict[str, int], str, str]:
    """Execute an ADK agent with a text message and return response text plus runtime metadata."""
    app_name = "reporter"
    user_id = "reporter_user"

    session_service = InMemorySessionService()
    session = await session_service.create_session(app_name=app_name, user_id=user_id)

    runner = Runner(agent=agent, app_name=app_name, session_service=session_service)

    content = types.Content(role="user", parts=[types.Part(text=message)])

    final_response = ""
    usage_totals = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    model_name = ""
    provider_name = ""
    async for event in runner.run_async(
        user_id=user_id,
        session_id=session.id,
        new_message=content,
    ):
        usage = extract_usage_from_event(event)
        usage_totals["prompt_tokens"] += int(usage.get("prompt_tokens") or 0)
        usage_totals["completion_tokens"] += int(usage.get("completion_tokens") or 0)
        usage_totals["total_tokens"] += int(usage.get("total_tokens") or 0)

        event_model, event_provider = extract_model_provider_from_event(event)
        if event_model:
            model_name = event_model
        if event_provider:
            provider_name = event_provider

        if event.is_final_response() and event.content and event.content.parts:
            # Skip thinking/reasoning parts so the answer text is picked correctly.
            final_response = next(
                (p.text for p in event.content.parts
                 if getattr(p, "text", None) and not getattr(p, "thought", False)),
                "",
            ) or ""

    return final_response, usage_totals, model_name, provider_name


def run_reporter_agent(
    agent_outputs: dict,
    metadata: dict | None = None,
    role: str | None = None,
    provider: str | None = None,
) -> str:
    """Run the reporter agent with agent outputs and return the generated report."""
    result = asyncio.run(
        run_reporter_agent_async(
            agent_outputs=agent_outputs,
            metadata=metadata,
            role=role,
            provider=provider,
        )
    )
    return result[0]


async def run_reporter_agent_async(
    agent_outputs: dict,
    metadata: dict | None = None,
    role: str | None = None,
    provider: str | None = None,
) -> tuple[str, dict[str, int], str, str]:
    """Async reporter runner (preferred for server usage)."""
    # Sanitize provider — ignore placeholder/empty values
    clean_provider = (provider or "").strip() if provider else None
    if clean_provider and clean_provider.lower() in ("string", ""):
        clean_provider = None

    agent = create_reporter_agent(provider=clean_provider)

    # Build the input message for the agent
    input_parts = [
        f"**agent_outputs**:\n```json\n{json.dumps(agent_outputs, indent=2)}\n```",
    ]
    if metadata:
        input_parts.append(f"**metadata**:\n```json\n{json.dumps(metadata, indent=2)}\n```")
    if role:
        input_parts.append(f"**role**: {role}")

    message = "\n\n".join(input_parts)

    return await _run_agent_async(agent, message)
