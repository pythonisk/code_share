"""
Refinement Agent - Post-processes the combined agent output using lessons
learned from the last few executions of the same use case.

This is a Google ADK agent that runs AFTER the dynamic and action agents. It
receives:
1. The combined output produced by the dynamic + action agents.
2. A system prompt assembled at runtime from the knowledge graph, containing the
   last 5 executions' user feedback and issues for this use case.

Its job is to revise the provided output so it incorporates the prior feedback
and avoids the previously reported issues, returning the improved output only.

The base instruction lives in code (not the prompt DB) because this agent has no
DB-stored core prompt; the effective instruction = base instruction + the
runtime KG-derived guidance.
"""

from google.adk.agents import Agent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
from daan.llm.llm_provider import (
    build_llm_tags,
    create_litellm_model,
    get_core_agent_model,
    get_default_provider_name,
)


_BASE_INSTRUCTION = (
    "You are the Refinement Agent. You receive an output produced by earlier "
    "agents, plus lessons learned from the last few executions of this same use "
    "case (prior user feedback and previously reported issues).\n\n"
    "Revise the output so it fully applies every piece of prior feedback and "
    "avoids every previously reported issue. Apply additive instructions (e.g. "
    "'add an explanation per item') to every item they pertain to, and apply "
    "subtractive instructions (e.g. 'remove the comments') by removing every "
    "occurrence — a removal instruction overrides the default to preserve "
    "content. If two instructions conflict (e.g. add explanations but remove "
    "comments), satisfy both by placing the required content in a form the other "
    "instruction does not strip.\n\n"
    "Keep every item from the original output — never drop, merge, summarise, "
    "truncate, or replace any item with a placeholder or 'remaining items "
    "similar' note. If the original has N items, output all N in full. Preserve "
    "correct content and structure that no feedback changes, and do not invent "
    "facts.\n\n"
    "Return ONLY the improved deliverable in the same format as the original, "
    "with no changelog or commentary about what you changed."
)


def build_refinement_instruction(guidance_text: str) -> str:
    """Compose the full agent instruction from the base instruction plus the
    runtime knowledge-graph guidance (last-5 feedback/issues)."""
    guidance_text = (guidance_text or "").strip()
    if not guidance_text:
        return _BASE_INSTRUCTION
    return f"{_BASE_INSTRUCTION}\n\n{guidance_text}"


def create_refinement_agent(
    guidance_text: str,
    provider: str | None = None,
) -> Agent:
    """
    Create the Refinement ADK agent.

    Args:
        guidance_text: Markdown block built from the last 5 executions' feedback
            and issues. Becomes part of the agent's system instruction.
        provider: Optional LLM provider name. Uses default if not specified.

    Returns:
        Configured ADK Agent for output refinement.
    """
    provider_name = provider or get_default_provider_name()
    model, provider_info = create_litellm_model(
        provider_name,
        tags=build_llm_tags(component="refinement_agent"),
        model_name=get_core_agent_model("refinement_agent"),
    )
    agent = Agent(
        name="refinement_agent",
        model=model,
        description=(
            "Refines combined agent output using prior feedback and issues from "
            "previous executions of the same use case"
        ),
        instruction=build_refinement_instruction(guidance_text),
        tools=[],
    )
    agent._provider_name = provider_info["provider"]
    agent._model_name = provider_info["model"]
    agent._provider_config = provider_info["config"]
    return agent


async def _run_refinement_agent_async(agent: Agent, message: str) -> str:
    """Execute the Refinement ADK agent and return the final response text."""
    app_name = "refinement_agent"
    user_id = "refinement_user"
    session_service = InMemorySessionService()
    session = await session_service.create_session(app_name=app_name, user_id=user_id)
    runner = Runner(agent=agent, app_name=app_name, session_service=session_service)
    content = types.Content(role="user", parts=[types.Part(text=message)])
    final_response = ""
    async for event in runner.run_async(
        user_id=user_id,
        session_id=session.id,
        new_message=content,
    ):
        if event.is_final_response() and event.content and event.content.parts:
            # Skip thinking/reasoning parts so the answer text is picked correctly.
            final_response = next(
                (p.text for p in event.content.parts
                 if getattr(p, "text", None) and not getattr(p, "thought", False)),
                "",
            ) or ""
    return final_response


async def run_refinement_agent_async(
    current_output: str,
    guidance_text: str,
    role: str | None = None,
    provider: str | None = None,
) -> str:
    """Run the refinement agent over the current output and return the refined
    output (async version).

    Args:
        current_output: Combined dynamic + action agent output to refine.
        guidance_text: KG-derived last-5 feedback/issues block (system prompt).
        role: Optional role hint.
        provider: Optional LLM provider name.
    """
    clean_provider = (provider or "").strip() if provider else None
    if clean_provider and clean_provider.lower() in ("string", ""):
        clean_provider = None
    agent = create_refinement_agent(guidance_text, provider=clean_provider)
    input_parts = [
        "### Current output to refine:\n",
        current_output or "",
    ]
    if role:
        input_parts.append(f"\n\n**role**: {role}")
    message = "".join(input_parts)
    return await _run_refinement_agent_async(agent, message)


# ── Block-preserving refinement (for review-based edits) ─────────────────────

_BLOCK_REFINEMENT_INSTRUCTION = (
    "You are the Suggested-Changes Refinement Agent. You receive a current "
    "output and a single user feedback instruction. Produce a revised version "
    "of the SAME output that applies the feedback with the smallest possible "
    "change.\n\n"
    "Rules:\n"
    "1. Identify only the blocks/lines the feedback affects (a block = a "
    "heading section, list item, table row, code block, or paragraph). "
    "Rewrite ONLY those blocks.\n"
    "2. Every block the feedback does NOT affect must be copied character-for-"
    "character from the input — same wording, same punctuation, same "
    "whitespace, same order.\n"
    "3. Do not reorder unaffected blocks. Do not renumber items unless the "
    "feedback explicitly asks for it.\n"
    "4. Keep the original format (markdown, headings, lists, tables, code "
    "fences) exactly as-is.\n"
    "5. If the feedback is additive (e.g. 'add an explanation'), add the new "
    "content inline in the affected blocks; do not touch other blocks.\n"
    "6. If the feedback is subtractive (e.g. 'remove all comments'), remove "
    "only the specified content and leave the rest untouched.\n"
    "7. Never truncate, summarise, or leave placeholders like '…rest similar'. "
    "Return the full deliverable so it can replace the original file.\n"
    "8. Return ONLY the revised deliverable. No changelog, no commentary, no "
    "wrapping code fences beyond what the original already had."
)


def _create_block_refinement_agent(provider: str | None = None) -> Agent:
    """Build an ADK agent tuned for block-preserving edits."""
    provider_name = provider or get_default_provider_name()
    model, provider_info = create_litellm_model(
        provider_name,
        tags=build_llm_tags(component="block_refinement_agent"),
        model_name=get_core_agent_model("block_refinement_agent"),
    )
    agent = Agent(
        name="block_refinement_agent",
        model=model,
        description=(
            "Applies a single feedback instruction to an existing output with "
            "the smallest possible change, preserving all unaffected blocks "
            "verbatim."
        ),
        instruction=_BLOCK_REFINEMENT_INSTRUCTION,
        tools=[],
    )
    agent._provider_name = provider_info["provider"]
    agent._model_name = provider_info["model"]
    agent._provider_config = provider_info["config"]
    return agent


async def run_block_refinement_async(
    current_output: str,
    feedback_text: str,
    role: str | None = None,
    history_text: str | None = None,
    provider: str | None = None,
) -> str:
    """Apply a single feedback instruction to ``current_output`` with the
    smallest possible change (only affected blocks are rewritten).

    This is used by the review-based ("Suggested Changes") flow so the diff
    between the current output and the proposed output is minimal.
    """
    clean_provider = (provider or "").strip() if provider else None
    if clean_provider and clean_provider.lower() in ("string", ""):
        clean_provider = None
    agent = _create_block_refinement_agent(provider=clean_provider)
    message_parts: list[str] = []
    cleaned_history = (history_text or "").strip()
    if cleaned_history:
        message_parts.extend([
            "### Relevant feedback history for this agent\n",
            cleaned_history,
            "\n\n",
        ])
    message_parts.extend([
        "### User feedback (apply only this, with the smallest possible change)\n",
        (feedback_text or "").strip(),
        "\n\n### Current output (rewrite only affected blocks; copy everything else verbatim)\n",
        current_output or "",
    ])
    if role:
        message_parts.append(f"\n\n**role**: {role}")
    message = "".join(message_parts)
    return await _run_refinement_agent_async(agent, message)
