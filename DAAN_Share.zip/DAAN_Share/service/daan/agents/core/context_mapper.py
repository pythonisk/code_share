"""Context Mapper — extracts context from input files and maps it to agents.

Inputs are expected to already exist in the session storage directory:
        session_storage/{session_id}/inputs/

The API layer (or UI) is responsible for placing/uploading input files into the
session inputs folder before context mapping is executed.
"""

import logging
from typing import Any

from daan.agents.agent_type_utils import normalize_agent_type
from daan.core.config import get_settings
from daan.utils.smart_context_manager import SmartContextManager

logger = logging.getLogger(__name__)
settings = get_settings()


# ── Sub-task A: Input Folder Validation ──────────────────────────────────

def prepare_session_dir(session_id: str, *, require_files: bool = True) -> str:
    """Return session inputs directory.

    When ``require_files`` is True, the session inputs folder must contain at
    least one file. Loop-driven use cases can set it to False so context
    mapping still succeeds with an empty input directory.
    """
    from daan.flow.session_service import create_session_dir, get_inputs_dir

    create_session_dir(session_id)
    inputs_dir = get_inputs_dir(session_id)

    has_files = any(p.is_file() for p in inputs_dir.iterdir())
    if require_files and not has_files:
        raise FileNotFoundError(
            f"No input files found for session '{session_id}'. Expected files in: {inputs_dir}"
        )

    return str(inputs_dir)


# ── Sub-task B: Context Mapping ────────────────────────────────────────────

def context_map(
    usecase_details: dict[str, Any],
    agents: list[dict[str, Any]],
    session_id: str,
    uploaded_file_count: int | None = None,
) -> dict[str, Any]:
    """
    Extract context from input files and map it to each agent.

    Args:
        usecase_details: Use case metadata (name, task, dag, etc.)
        agents: List of agent configs from use case.
        session_id: Unique session identifier.

    Returns:
        {
            "agents": [...],       # Agent configs with context added
            "dag": "A1>A2>A3",     # Execution order
            "context_map": {...}   # agent_id -> context mapping
        }
    """
    # Upload is optional: build context from whatever input files are present.
    # When the session has no input files, agents proceed with empty
    # file-derived context (e.g. entry agents that fetch their data via MCP).
    from pathlib import Path

    session_dir = prepare_session_dir(session_id, require_files=False)
    has_input_files = any(p.is_file() for p in Path(session_dir).iterdir())

    # Sub-task B: run SmartContextManager on staged files
    scm_agents = [
        {
            "id": agent.get("agent_id", ""),
            "name": agent.get("agent_name", ""),
            "inputs": agent.get("inputs", ""),
            "full_context_mode": True if any(x in agent.get("agent_name", "").casefold() for x in ["unit test", "unittest", "testcase", "test case"]) or agent.get("full_context_mode") else False,
        }
        for agent in agents
    ]

    if has_input_files:
        try:
            scm = SmartContextManager(session_dir)
            context_mapping = scm.get_context_for_multiple_agents(scm_agents)
            token_usage = scm.get_mapping_token_usage()
        except FileNotFoundError:
            # Inputs present but none are text/table-extractable (e.g. images);
            # such files are read by agents via their own tools (vision extractor),
            # so proceed with empty file-context instead of failing the run.
            logger.info(
                "Input files present but not text-extractable (e.g. images); "
                "proceeding with empty file-context so agents self-read via tools."
            )
            context_mapping = {agent.get("agent_id", ""): "" for agent in agents}
            token_usage = {}
    elif uploaded_file_count and uploaded_file_count > 0:
        # User attached files but none reached disk — upload race or failure.
        raise FileNotFoundError(
            f"{uploaded_file_count} file(s) were attached but none were found "
            f"for session '{session_id}'. The upload may not have completed."
        )
    else:
        # No files by choice — tool-sourced / hybrid / free-text run.
        context_mapping = {agent.get("agent_id", ""): "" for agent in agents}
        token_usage = {}

    enriched_agents = []
    for agent in agents:
        agent_id = agent.get("agent_id", "")
        enriched_agent = {
            **agent,
            "agent_type": normalize_agent_type(agent.get("agent_type")),
            "context": context_mapping.get(agent_id, ""),
        }
        enriched_agents.append(enriched_agent)

    dag = usecase_details.get("dag", "") or ">".join(
        a.get("agent_id", "") for a in enriched_agents
    )

    # Write context map output to session storage
    from daan.flow.session_service import write_context_map_output as _write_ctx
    try:
        _write_ctx(session_id, {
            "agents": enriched_agents,
            "usecase_details": usecase_details or {},
            "dag": dag,
            "context_map": context_mapping,
            "token_usage": token_usage,
        })
    except Exception:
        logger.warning("Failed to write context_map_output.json for session '%s'", session_id)

    return {
        "agents": enriched_agents,
        "dag": dag,
        "context_map": context_mapping,
        "token_usage": token_usage,
    }


# Backward-compatible alias
plan = context_map
