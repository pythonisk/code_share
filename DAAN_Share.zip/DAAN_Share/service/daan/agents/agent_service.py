"""Agent-related file-backed data access using DATA_DIR as root."""

from __future__ import annotations

import csv
from pathlib import Path

from daan.core.config import get_settings

WORKSPACE_ROOT = Path(__file__).resolve().parents[3]


def _normalize(value: str) -> str:
    return value.strip().casefold()


def _normalize_key(value: str) -> str:
    return "".join(ch for ch in value.strip().casefold() if ch.isalnum())


def _data_root() -> Path:
    configured = get_settings().DATA_DIR.strip()
    if configured:
        configured_path = Path(configured)
        if configured_path.is_absolute():
            return configured_path
        return (WORKSPACE_ROOT / configured_path).resolve()
    return WORKSPACE_ROOT / "data"


def _archetypes_root() -> Path:
    return _data_root() / "Archetypes"


def _find_archetype_dir(archetype: str) -> Path:
    root = _archetypes_root()
    if not root.exists() or not root.is_dir():
        raise FileNotFoundError("Archetypes root folder not found")

    for candidate in root.iterdir():
        if candidate.is_dir() and _normalize(candidate.name) == _normalize(archetype):
            return candidate

    raise FileNotFoundError(f"Archetype '{archetype}' not found")


def _read_csv_rows(csv_path: Path) -> list[dict[str, str]]:
    if not csv_path.exists() or not csv_path.is_file():
        return []

    with csv_path.open("r", encoding="utf-8-sig", newline="") as csv_file:
        reader = csv.DictReader(csv_file)
        rows: list[dict[str, str]] = []
        for row in reader:
            normalized_row: dict[str, str] = {}
            for key, value in row.items():
                if key is None:
                    continue
                normalized_row[_normalize_key(str(key))] = str(value).strip()
            rows.append(normalized_row)
        return rows


def _usecases_rows(archetype_dir: Path) -> list[dict[str, str]]:
    return _read_csv_rows(archetype_dir / "UseCases.csv")


def _agents_rows(archetype_dir: Path) -> list[dict[str, str]]:
    return _read_csv_rows(archetype_dir / "Agents.csv")


def _get_value(row: dict[str, str], *aliases: str) -> str:
    for alias in aliases:
        value = row.get(_normalize_key(alias), "").strip()
        if value:
            return value
    return ""


def _find_usecase_row(archetype_dir: Path, usecase: str) -> dict[str, str]:
    target = _normalize(usecase)
    for row in _usecases_rows(archetype_dir):
        usecase_id = _get_value(row, "usecaseid", "usecase id", "id")
        name = _get_value(row, "name", "usecase", "use case")
        if _normalize(usecase_id) == target or _normalize(name) == target:
            return row

    raise FileNotFoundError(f"Usecase '{usecase}' not found")


from sqlalchemy.orm import Session
from sqlalchemy import text
from daan.core.database import SessionLocal
from daan.models.archetype import Agent, UseCaseAgentMapping

def list_agents_for_usecase(archetype: str, usecase: str) -> list[dict]:
    """List all involved agents for a use case from the database."""
    with SessionLocal() as db:
        # Get mapping to agents
        agent_mappings = db.query(UseCaseAgentMapping).filter(
            UseCaseAgentMapping.usecase_id == usecase
        ).order_by(UseCaseAgentMapping.execution_order).all()
        
        agents_data = []
        for mapping in agent_mappings:
            agent = mapping.agent
            if not agent:
                continue
                
            prompt_text = agent.prompt_ref.prompt_text if agent.prompt_ref else None
            
            agents_data.append({
                "archetype": archetype,
                "usecase": usecase,
                "agent_id": agent.agent_id,
                "agent_name": agent.agent_name,
                "role": agent.role,
                "agent_type": agent.agent_type,
                "prompt_file_path": None,
                "prompt": prompt_text,
                "inputs": agent.input_context or "",
                "output": agent.output_format or "",
                "actions": agent.agent_actions or "",
                "output_validators": agent.output_validators or "",
                "guardrails": agent.guardrails or "",
                "mcp_tools": agent.mcp_server or "",
                "local_tools": agent.local_tools or "",
                "depends_on": agent.depend_on or "",
            })
        return agents_data


def get_agent_details(archetype: str, usecase: str, agent_id: str) -> dict:
    """Get one agent details from the database."""
    with SessionLocal() as db:
        agent = db.query(Agent).filter(Agent.agent_id == agent_id).first()
        if not agent:
            raise FileNotFoundError(f"Agent '{agent_id}' not found")
            
        prompt_text = agent.prompt_ref.prompt_text if agent.prompt_ref else None
        
        return {
            "archetype": archetype,
            "usecase": usecase,
            "agent_id": agent.agent_id,
            "agent_name": agent.agent_name,
            "role": agent.role,
            "agent_type": agent.agent_type,
            "prompt_file_path": None,
            "prompt": prompt_text,
            "inputs": agent.input_context or "",
            "output": agent.output_format or "",
            "actions": agent.agent_actions or "",
            "output_validators": agent.output_validators or "",
            "guardrails": agent.guardrails or "",
            "mcp_tools": agent.mcp_server or "",
            "local_tools": agent.local_tools or "",
            "depends_on": agent.depend_on or "",
        }
