"""Audit logging service.

Provides a single ``write_audit`` helper used by every service layer that
performs a meaningful mutation.  All action-label constants are defined here
so callers never hard-code free-form strings.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

# ---------------------------------------------------------------------------
# Action constants — stored verbatim in audit_log.action
# ---------------------------------------------------------------------------
USE_CASE_CREATED = "Use Case Created"
USE_CASE_DELETED = "Use Case Deleted"

AGENT_CREATED = "Agent Created"
AGENT_EDITED = "Agent Edited"
AGENT_DELETED = "Agent Deleted"
AGENT_MAPPED = "Agent Mapped to Use Case"
AGENT_UNMAPPED = "Agent Removed from Use Case"

PROMPT_ADDED = "Prompt Added"
PROMPT_UPDATED = "Prompt Updated"
PROMPT_DELETED = "Prompt Deleted"


# ---------------------------------------------------------------------------
# Public helper
# ---------------------------------------------------------------------------

def write_audit(
    db: Session,
    action: str,
    *,
    changed_by_user=None,
    usecase_id: str | None = None,
    usecase_name: str | None = None,
    agent_id: str | None = None,
    agent_name: str | None = None,
    prompt_id: int | None = None,
    prompt_version: int | None = None,
    prompt_preview: str | None = None,
    changes: dict | None = None,
) -> None:
    """Insert one row into ``audit_log``.

    ``changes`` is an optional dict of the form::

        {"field_name": {"before": <old_value>, "after": <new_value>}, ...}

    It is stored as JSON and surfaced in the UI so reviewers can see exactly
    what was modified without having to diff snapshots manually.
    """
    from daan.models.archetype import AuditLog

    # Store the full prompt text — the UI handles display in an expandable row
    truncated_preview = prompt_preview if prompt_preview else None

    db.add(
        AuditLog(
            action=action,
            usecase_id=usecase_id,
            usecase_name=usecase_name,
            agent_id=agent_id,
            agent_name=agent_name,
            prompt_id=prompt_id,
            prompt_version=prompt_version,
            changed_by_user_id=getattr(changed_by_user, "id", None),
            changed_by_username=getattr(changed_by_user, "username", None),
            prompt_preview=truncated_preview,
            changes=changes,
        )
    )
