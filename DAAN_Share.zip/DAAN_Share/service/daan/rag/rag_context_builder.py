from typing import Any

from daan.core.config import get_settings
from daan.llm.llm_provider import load_llm_config
from daan.graph_stores.graph_store_factory import GraphStoreFactory
from daan.llm.embedding_provider import EmbeddingProviderFactory
from daan.rag.chunking.chunker_factory import ChunkerFactory
from daan.vector_stores.vector_store_factory import VectorStoreFactory


def load_rag_config() -> dict[str, Any]:
    """Load RAG config from application settings."""
    settings = get_settings()
    return settings.load_rag_config()


def resolve_embedding_config(rag_config: dict[str, Any]) -> dict[str, Any]:
    """Resolve embedding config from RAG config, with fallback to llm_config.yml."""
    provider_name = rag_config.get("embedding_provider", "azure_openai")
    explicit_embedding_config = rag_config.get("embedding_config") or {}

    llm_embedding_config: dict[str, Any] = {}
    try:
        llm_config = load_llm_config() or {}
        embedding_section = llm_config.get("embeddings") or {}
        embedding_providers = embedding_section.get("providers") or {}
        top_level_providers = llm_config.get("providers") or {}

        llm_embedding_config = (
            embedding_providers.get(provider_name)
            or top_level_providers.get(provider_name)
            or {}
        )
    except Exception:
        # Keep startup resilient if llm config is unavailable/malformed.
        llm_embedding_config = {}

    return {**llm_embedding_config, **explicit_embedding_config}


def build_rag_runtime_components(rag_config: dict[str, Any]) -> dict[str, Any]:
    """Build runtime components required by retrievers and context injector."""
    embedding_provider_name = rag_config.get("embedding_provider", "azure_openai")
    embedding_config = resolve_embedding_config(rag_config)

    embedding_provider = EmbeddingProviderFactory.create_provider(
        provider_name=embedding_provider_name,
        config=embedding_config,
    )
    vector_store = VectorStoreFactory.create_store(
        store_name=rag_config.get("vector_store_type", "chroma"),
        config=rag_config.get("vector_store_config", {}),
    )
    graph_store = GraphStoreFactory.create_store(
        store_name=rag_config.get("graph_store_type", "kuzu"),
        config=rag_config.get("graph_store_config", {}),
    )
    chunker = ChunkerFactory.create_chunker(
        chunker_type=rag_config.get("chunker_type", "recursive_text"),
        config={
            "chunk_size": rag_config.get("chunk_size", 512),
            "chunk_overlap": rag_config.get("chunk_overlap", 64),
            "embedding_provider": embedding_provider,
        },
    )
    return {
        "embedding_provider": embedding_provider,
        "vector_store": vector_store,
        "graph_store": graph_store,
        "chunker": chunker,
        "llm_provider": None,
        "use_hybrid": bool(rag_config.get("use_hybrid", False)),
    }
