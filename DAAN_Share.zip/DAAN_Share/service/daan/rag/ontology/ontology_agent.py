"""Core Ontology Agent (human-in-the-loop).

Purpose
-------
Given the plain text of an uploaded document, use an LLM to extract a
DOCUMENT-LEVEL ontology (entities + typed relationships) that a human can
review, correct via feedback, and then publish into a knowledge base's graph.

This agent produces a clean, reviewable, document-level ontology as JSON,
supports a feedback/revision loop, and only writes to the graph on publish
(unlike the retired per-chunk auto-extractor, which produced noisy entities
with no review). Retrieval then grounds chunks into these curated concepts via
``OntologyLinker`` (concept-id metadata tags), not per-chunk graph vertices.

Design notes
------------
- Open vocabulary by default: the LLM infers ``type`` values from the document,
  so a brand-new KB needs zero configuration. An optional ``allowed_types``
  argument can constrain the vocabulary once a KB wants consistency.
- Output is a single JSON object (the ontology contract) shared with the UI
  graph-render component and the publish step. See ``_normalize_ontology`` for
  the guaranteed shape.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from daan.llm.llm_provider import get_llm_response_with_fallback

logger = logging.getLogger(__name__)

# Guard against oversized prompts; documents are pre-loaded as text by the caller.
# Generous enough to combine several related documents into one ontology while
# staying well within a large-context model's window (~= a few tens of k tokens).
_MAX_DOCUMENT_CHARS = 120000

# Per-request timeout (seconds) for ontology LLM calls. Ontology generation and
# especially revision re-emit a large JSON document, which can exceed the default
# router timeout (30s); allow more time so the primary model can finish instead of
# timing out into an exhausted fallback provider.
_LLM_TIMEOUT_SECONDS = 180


_ONTOLOGY_EXTRACTION_PROMPT = """You are an Ontology Learning Agent.

Your task is to construct a CANDIDATE domain ontology from the provided document
content. You are NOT performing ordinary entity extraction.

CONCEPTS / CLASSES:

Create concepts only when they represent meaningful reusable domain abstractions.

Examples: Vehicle, Car, Engine, Employee, Organization, Application, API, Service, Database

Do NOT create a concept merely because a word appears in the document.

Avoid generic concepts (Thing, Object, Item, Information, Data, System, Technology, Process)
unless the document clearly establishes them as meaningful domain concepts.

Prefer a smaller number of meaningful concepts over a large number of weak concepts.

CLASS VS INSTANCE:

Distinguish concepts/classes from individual instances.

Example: "Alice is an employee of Google."
Reusable concepts: Employee, Organization
Do NOT create: Alice (person instance), Google (organization instance)

Do not create ontology concepts for individual people, products, transactions, document
records, IDs, serial numbers, timestamps, or numerical values unless the document
explicitly establishes them as reusable conceptual classes.

The ontology represents the conceptual/domain level, not individual data records.

CANONICAL NAMES AND ALIASES:

Use clear canonical names for each concept. Prefer consistent singular names.
Examples: Employee (not Employees), Vehicle (not Vehicles), API Gateway (not API_Gateway)

If the document uses multiple names that clearly refer to the same concept, capture
them in the "aliases" field as an array of strings.

Example: {{"name": "Car", "aliases": ["Automobile", "Auto", "Motorcar"]}}

Do not create separate concepts merely because of capitalization, punctuation,
singular/plural differences, or formatting differences. Do not merge concepts solely
because their names look similar—semantic meaning and context must support the equivalence.

TAXONOMY:

Taxonomy represents genuine IS-A / SUBCLASS-OF / EXTENDS relationships.

Examples:
- Car IS_A Vehicle
- ElectricCar IS_A Car
- GraphOntologyAgent EXTENDS OntologyAgent (code inheritance)

Use relationship type "IS_A", "SUBCLASS_OF", or "EXTENDS" for taxonomy.

Do NOT treat ordinary relationships as taxonomy:
- Car HAS_ENGINE Engine (NOT taxonomy - use relationships)
- Application USES API (NOT taxonomy - use relationships)

Do not create self-taxonomy (A IS_A A) or circular taxonomy.

SEMANTIC RELATIONSHIPS:

Represent meaningful non-taxonomic relationships separately.

Supported types: USES, DEPENDS_ON, HAS, PART_OF, IMPLEMENTS, PRODUCES, CONSUMES,
SUPPORTS, MANAGES, CONNECTED_TO, CONTAINS, REQUIRES, IMPORTS, HAS_METHOD, HAS_PROPERTY,
CALLS, RETURNS, DEFINES, INSTANTIATES

Use UPPER_SNAKE_CASE for relationship types.

Relationships must be supported by the document content. Maintain correct source and
target direction (e.g., Application USES API → source=Application, target=API, type=USES).

Do not create relationships simply because two concepts occur in the same document
or paragraph.

SOURCE CODE FILES HANDLING:

When processing source code files (Python, JavaScript, Java, TypeScript, C#, Go, Rust, etc.),
extract programming concepts and their relationships:

**PROGRAMMING CONCEPTS TO EXTRACT:**

1. **Classes and Interfaces:**
   Type: "Class", "Interface", "AbstractClass", "Enum", "Trait"
   ID: Use the class name (e.g., CustomerRepository, IUserService, OrderStatus)
   Description: Include docstrings/comments
   Inheritance: Capture via EXTENDS in taxonomy array

2. **Functions and Methods:**
   Type: "Function", "Method", "Constructor", "StaticMethod"
   ID: Standalone functions use function_name; methods use ClassName.method_name
   Description: Include parameters, return type, purpose
   Link methods to parent class via HAS_METHOD relationship

3. **Modules and Packages:**
   Type: "Module", "Package", "Namespace", "Library"
   ID: Use dot-separated path (e.g., daan.rag.ontology.ontology_agent)
   Link to defined classes/functions via DEFINES relationship

4. **Data Structures and Models:**
   Type: "Model", "Schema", "DTO", "Entity", "DataClass", "Struct"
   These represent reusable data structures, not instances

**CODE-SPECIFIC RELATIONSHIPS:**

| Relationship Type | Meaning | In Array | Example |
|-------------------|---------|----------|---------|
| EXTENDS | Class inheritance | taxonomy | GraphAgent EXTENDS BaseAgent |
| IMPLEMENTS | Interface implementation | relationships | UserService IMPLEMENTS IService |
| IMPORTS | Module/package dependency | relationships | ontology_agent IMPORTS llm_provider |
| DEPENDS_ON | Composition, dependency injection | relationships | OrderService DEPENDS_ON OrderRepository |
| HAS_METHOD | Class contains method | relationships | CustomerRepository HAS_METHOD get_customer |
| HAS_PROPERTY | Class contains property/field | relationships | Customer HAS_PROPERTY email_address |
| CALLS | Function/method invocation | relationships | process_order CALLS validate_order |
| RETURNS | Return type relationship | relationships | get_customer RETURNS Customer |
| DEFINES | Module defines classes/functions | relationships | ontology_agent DEFINES OntologyAgent |
| INSTANTIATES | Object creation | relationships | OrderService INSTANTIATES OrderValidator |

**CODE-SPECIFIC ID CONVENTIONS:**

- Classes/Interfaces: PascalCase (CustomerRepository, IOrderService)
- Methods: ClassName.method_name (CustomerRepository.get_customer)
- Functions: snake_case or camelCase as in source (get_customer, getCustomer)
- Modules: dot.separated.path (daan.rag.ontology.ontology_agent)

Keep original naming from source code.

**WHAT NOT TO EXTRACT FROM CODE:**

Do NOT create concepts for: local variables, loop counters, temporary variables, string
literals, numeric constants, primitive types, import statements themselves (capture via
IMPORTS relationship), comments, annotations (unless they define a decorator/annotation
class), function parameters (describe in method description instead).

**CODE TAXONOMY:**

Code inheritance goes in the taxonomy array as EXTENDS or SUBCLASS_OF (child is the
derived class, parent is the base class).

Interface implementation goes in relationships as IMPLEMENTS (not taxonomy).

**BALANCING CODE AND DOMAIN CONCEPTS:**

For code files that also contain domain logic, extract BOTH programming structure
(classes, methods, modules) AND domain concepts (business entities, processes).

Example: A file defining class "CustomerOrderProcessor" that processes "Orders" should
extract both the code structure (CustomerOrderProcessor class, its methods) AND the
domain concepts (Customer, Order, OrderProcessing as domain concept).

**CODE EXTRACTION EXAMPLE:**

```python
from llm_provider import get_llm_response

class OntologyAgent:
    def extract(self, text: str) -> dict:
        return get_llm_response(text)

class GraphOntologyAgent(OntologyAgent):
    pass
```

Extract:
- Concepts: OntologyAgent (Class), OntologyAgent.extract (Method), GraphOntologyAgent (Class), get_llm_response (Function)
- Taxonomy: GraphOntologyAgent EXTENDS OntologyAgent
- Relationships: OntologyAgent HAS_METHOD OntologyAgent.extract, OntologyAgent.extract CALLS get_llm_response

PROPERTIES:

Properties may describe meaningful characteristics of a concept.
Example: "Car has four wheels" → Car may have property: wheel_count=4

Do not turn every value mentioned in the document into a concept.

DUPLICATES:

Do not create duplicate concepts within the same candidate ontology. If the document
clearly refers to the same concept using different names, represent one concept and
capture alternate names as aliases.

Do not create duplicate relationships with the same source, target, and type.

EXISTING ONTOLOGY CONTEXT:

If existing ontology context is supplied below, use it as reference information only.

DO NOT perform database lookup. DO NOT decide whether a concept is already published.
The application will later compare your generated candidate concepts against the
existing concepts in the current Knowledge Base.

Your job is ONLY to produce the candidate ontology. The application handles concept
identity, merge, and validation.

GROUNDING:

Every concept and relationship must be supported by the supplied document content
or explicitly supplied ontology context.

Do not introduce concepts based only on general LLM knowledge.
Do not hallucinate missing relationships.
Do not invent values from the example above or general programming knowledge.

If the document does not provide sufficient evidence, do not create the concept
or relationship.

CONCEPT IDS:

Generate stable, human-readable concept IDs using PascalCase names or canonical
identifiers from the document.

Examples: Vehicle, DuplicateDetectionService, ClaimProcessor, v001, ACTIVE_STATUS

Do NOT generate: C001, C002, C003 (auto-increment IDs)

The ID you generate is temporary. The downstream Concept Identity Layer will determine
whether your candidate concept matches an existing concept and will assign/reuse the
canonical KB concept ID.

OUTPUT FORMAT:

Return ONLY valid JSON. No markdown fences. No extra prose.

Before returning, internally verify:
1. Concepts are meaningful domain abstractions (or code structures for source files)
2. Instances have not been incorrectly modeled as classes
3. Duplicate concepts within the candidate are avoided
4. Canonical names are consistent
5. Aliases are captured as arrays
6. Taxonomy relationships (IS_A/SUBCLASS_OF/EXTENDS) are in the taxonomy array
7. Domain relationships (USES/DEPENDS_ON/IMPLEMENTS/HAS_METHOD/etc) are in the relationships array
8. Relationship direction is correct
9. Concepts and relationships are grounded in the document
10. No unsupported knowledge is introduced
11. The output is a CANDIDATE ontology (not yet validated/published)
12. For code files: classes/methods/functions extracted, inheritance in taxonomy, structure in relationships
{allowed_types_block}{existing_entities_block}
JSON SHAPE (illustrative example only - DO NOT copy these values; infer real values from YOUR document):
{{
    "ontology_version": 2,
    "concepts": [
        {{"id": "Vehicle", "name": "Vehicle", "type": "Asset", "description": "Transportation device", "aliases": ["Transport"]}},
        {{"id": "Car", "name": "Car", "type": "Asset", "description": "Four-wheeled motor vehicle", "aliases": ["Automobile"]}},
        {{"id": "Engine", "name": "Engine", "type": "Component", "description": "Power source", "aliases": []}},
        {{"id": "OntologyAgent", "name": "OntologyAgent", "type": "Class", "description": "Extracts ontologies", "aliases": []}},
        {{"id": "OntologyAgent.extract", "name": "extract", "type": "Method", "description": "Extraction method", "aliases": []}}
    ],
    "taxonomy": [
        {{"child_id": "Car", "parent_id": "Vehicle", "relationship_type": "IS_A"}}
    ],
    "relationships": [
        {{"source_id": "Car", "target_id": "Engine", "type": "HAS"}},
        {{"source_id": "OntologyAgent", "target_id": "OntologyAgent.extract", "type": "HAS_METHOD"}}
    ],
    "notes": "Extracted from supplied document"
}}

--- DOCUMENT (may be truncated) ---
{document_text}
--- END DOCUMENT ---

Now output ONLY the JSON candidate ontology object:"""


_ONTOLOGY_REVISION_PROMPT = """You are an Ontology Revision Agent.

You are given an EXISTING V2 ontology (JSON) and a human's FEEDBACK describing the
changes they want. Do NOT re-output the whole ontology. Output ONLY the CHANGES
to apply, as a JSON "diff" object. Everything you do not mention is preserved
exactly as-is (all existing concepts, taxonomy, and relationships are kept).

BEFORE GENERATING THE DIFF:

1. Review the CURRENT ONTOLOGY to understand all existing concept IDs
2. Parse the FEEDBACK to determine requested changes
3. Validate that all referenced concept IDs exist or will be created
4. Ensure changes are grounded in the original document context (if provided)

STRICT RULES:

OUTPUT FORMAT:
- Output MUST be valid JSON only. No markdown fences. No extra prose.
- Output ONLY this diff shape (include only the keys you actually need; omit
  the ones that are empty):
  {{
    "add_concepts": [
      {{"id": "ConceptID", "name": "Concept Name", "type": "ConceptType",
        "description": "Brief description", "aliases": ["Synonym1"]}}
    ],
    "add_taxonomy": [
      {{"child_id": "ChildConcept", "parent_id": "ParentConcept",
        "relationship_type": "IS_A"}}
    ],
    "add_relationships": [
      {{"source_id": "SourceConcept", "target_id": "TargetConcept",
        "type": "USES"}}
    ],
    "remove_concept_ids": ["ConceptID"],
    "remove_taxonomy": [
      {{"child_id": "ChildConcept", "parent_id": "ParentConcept",
        "relationship_type": "IS_A"}}
    ],
    "remove_relationships": [
      {{"source_id": "SourceConcept", "target_id": "TargetConcept",
        "type": "USES"}}
    ]
  }}

ADDING CONCEPTS AND RELATIONSHIPS:
- To ADD a concept, put it in "add_concepts". To connect concepts, add edges in
  "add_taxonomy" (for IS_A/SUBCLASS_OF/EXTENDS) or "add_relationships" (for
  USES/DEPENDS_ON/IMPLEMENTS/HAS_METHOD/CALLS).
- Relationship types must be UPPER_SNAKE_CASE (e.g. USES, DEPENDS_ON, PART_OF,
  IMPLEMENTS, EXTENDS, IMPORTS, HAS_METHOD, CALLS).
- For code ontologies: Use EXTENDS for class inheritance (in taxonomy), IMPLEMENTS
  for interfaces (in relationships), HAS_METHOD for class-method structure, CALLS
  for method invocations, DEPENDS_ON for composition.

REFERENTIAL INTEGRITY (CRITICAL):
- EVERY concept ID referenced in "add_taxonomy" (both child_id and parent_id) MUST
  either exist in the CURRENT ONTOLOGY or be included in "add_concepts" in this
  same diff.
- EVERY concept ID referenced in "add_relationships" (both source_id and target_id)
  MUST either exist in the CURRENT ONTOLOGY or be included in "add_concepts" in
  this same diff.
- If feedback requests adding a relationship with a non-existent concept, you MUST
  add that concept to "add_concepts" first. Do NOT create relationships to concepts
  that don't exist.

MODIFYING EXISTING CONCEPTS:
- To change a concept's description, type, or aliases: remove the old concept and
  add the updated version.
- To add aliases to an existing concept: remove it and re-add with the complete
  aliases array (old + new aliases).
- To merge concepts: remove the duplicate and update all relationships that referenced
  it to point to the canonical concept.

REMOVING ITEMS:
- Do NOT remove anything unless the feedback explicitly asks for removal.
- Do NOT restate unchanged concepts.
- When removing a concept, also remove any taxonomy or relationships that reference it.

GROUNDING:
- New concepts must be supported by the original document context (if provided below).
- Do not invent concepts based solely on general knowledge or the feedback wording
  unless the feedback explicitly requests creating a new concept.
{allowed_types_block}
--- CURRENT ONTOLOGY (V2 JSON) ---
{current_ontology}
--- END CURRENT ONTOLOGY ---
{document_block}
--- HUMAN FEEDBACK ---
{feedback}
--- END HUMAN FEEDBACK ---

Now output ONLY the JSON diff object:"""


# Placeholder string used by build_extraction_prompt_preview (and recognised here
# when a user-edited session prompt is submitted from the UI).
_DOCUMENT_PLACEHOLDER = "<the uploaded document text is inserted here>"


def generate_ontology(
    *,
    document_text: str,
    kb_id: str,
    allowed_types: dict[str, list[str]] | None = None,
    existing_entities: list[dict[str, Any]] | None = None,
    custom_prompt: str | None = None,
    provider_name: str | None = None,
    max_tokens: int = 16384,
    temperature: float = 0.0,
    max_retries: int = 2,
) -> dict[str, Any]:
    """Extract a document-level ontology from ``document_text`` with automatic retries.

    Args:
        document_text: Plain text of the uploaded document (loaded by caller).
        kb_id: Target knowledge base id (stamped into the result for traceability).
        allowed_types: Optional {"entity_types": [...], "relationship_types": [...]}
            to constrain the vocabulary. When omitted the LLM infers types freely.
        existing_entities: Optional list of entities already in the KB's graph
            ({"id", "type", "name"}). Passed so the agent reuses their exact ids
            and links new entities to them (incremental/graph-aware extraction).
        custom_prompt: Optional session-scoped prompt override supplied by the UI.
            When provided it replaces the default extraction template for this
            request only and is never persisted to the database.
        provider_name: Optional LLM provider override.
        max_tokens / temperature: LLM generation controls.
        max_retries: Maximum number of retry attempts for LLM failures (default 2).

    Returns:
        The ontology as a normalized dict (see ``_normalize_ontology``).
        
    Raises:
        ValueError: If all retry attempts fail or document is empty.
        JSONDecodeError: If LLM consistently returns malformed JSON.
    """
    last_error = None
    
    for attempt in range(max_retries + 1):
        try:
            ontology, _, raw_response = generate_ontology_with_io(
                document_text=document_text,
                kb_id=kb_id,
                allowed_types=allowed_types,
                existing_entities=existing_entities,
                custom_prompt=custom_prompt,
                provider_name=provider_name,
                max_tokens=max_tokens,
                temperature=temperature,
            )
            
            # Check for retry-worthy conditions (structural failures)
            # V2 ontology validation
            concepts = ontology.get("concepts", [])
            if not concepts:
                if attempt < max_retries:
                    logger.warning(
                        f"⚠️  Retry attempt {attempt + 1}/{max_retries}: Empty concepts array in V2 ontology"
                    )
                    last_error = ValueError("LLM returned empty concepts array")
                    continue
                else:
                    raise ValueError("LLM consistently returns empty concepts after retries")
                    
            # Check if too many concepts were dropped during normalization
            # This would indicate the LLM is producing low-quality output
            if len(concepts) < 3 and len(document_text) > 1000:
                logger.warning(
                    f"⚠️  Warning: Only {len(concepts)} concepts extracted from large document "
                    f"({len(document_text)} chars) - may indicate LLM extraction quality issues"
                )
            
            # Success - return the ontology
            if attempt > 0:
                logger.info(f"✅ Ontology extraction succeeded on retry attempt {attempt + 1}")
            return ontology
            
        except json.JSONDecodeError as e:
            # Malformed JSON - retry
            last_error = e
            if attempt < max_retries:
                logger.warning(
                    f"⚠️  Retry attempt {attempt + 1}/{max_retries}: Malformed JSON from LLM - {e}"
                )
                continue
            else:
                logger.error(f"❌ LLM consistently returns malformed JSON after {max_retries} retries")
                raise ValueError(f"LLM returned malformed JSON after {max_retries} retries: {e}") from e
                
        except ValueError as e:
            # Empty content or other structural validation failure
            if "Empty document" in str(e):
                # Don't retry empty documents
                raise
            last_error = e
            if attempt < max_retries:
                logger.warning(f"⚠️  Retry attempt {attempt + 1}/{max_retries}: {e}")
                continue
            else:
                logger.error(f"❌ Ontology extraction failed after {max_retries} retries: {e}")
                raise
                
        except Exception as e:
            # Infrastructure errors (network, database, etc.) - do NOT retry
            # These need external intervention
            logger.error(f"❌ Infrastructure error during ontology extraction (not retrying): {e}")
            raise
    
    # Should not reach here, but just in case
    if last_error:
        raise last_error
    raise ValueError("Ontology extraction failed after all retry attempts")


def generate_ontology_with_io(
    *,
    document_text: str,
    kb_id: str,
    allowed_types: dict[str, list[str]] | None = None,
    existing_entities: list[dict[str, Any]] | None = None,
    custom_prompt: str | None = None,
    provider_name: str | None = None,
    max_tokens: int = 16384,
    temperature: float = 0.0,
) -> tuple[dict[str, Any], str, str]:
    """Like ``generate_ontology`` but also returns (llm_prompt, llm_raw_response)."""
    content = (document_text or "").strip()
    if not content:
        raise ValueError("Empty document content")
    if len(content) > _MAX_DOCUMENT_CHARS:
        content = content[:_MAX_DOCUMENT_CHARS] + "\n[...truncated for ontology extraction...]"

    if custom_prompt and custom_prompt.strip():
        # Session-scoped override from the UI: inject the document text at the
        # well-known placeholder position, or append it if the placeholder is absent.
        if _DOCUMENT_PLACEHOLDER in custom_prompt:
            prompt = custom_prompt.replace(_DOCUMENT_PLACEHOLDER, content)
        else:
            prompt = (
                f"{custom_prompt.rstrip()}\n\n"
                f"--- DOCUMENT (may be truncated) ---\n{content}\n--- END DOCUMENT ---\n\n"
                "Now output ONLY the JSON ontology object:"
            )
    else:
        prompt = _ONTOLOGY_EXTRACTION_PROMPT.format(
            allowed_types_block=_allowed_types_block(allowed_types),
            existing_entities_block=_existing_entities_block(existing_entities),
            document_text=content,
        )
    raw = get_llm_response_with_fallback(
        prompt=prompt,
        provider_name=provider_name,
        max_tokens=max_tokens,
        temperature=temperature,
        timeout=_LLM_TIMEOUT_SECONDS,
    )

    ontology = _normalize_ontology(_parse_json_object(raw), kb_id=kb_id)
    logger.debug(
        "Ontology generated for kb=%s (concepts=%d, taxonomy=%d, relationships=%d)",
        kb_id,
        len(ontology["concepts"]),
        len(ontology["taxonomy"]),
        len(ontology["relationships"]),
    )
    return ontology, prompt, str(raw or "")


def build_extraction_prompt_preview(
    *,
    allowed_types: dict[str, list[str]] | None = None,
    existing_entities: list[dict[str, Any]] | None = None,
) -> str:
    """Return the ontology-extraction prompt as sent to the LLM, for UI display.

    The document text is replaced with a short placeholder so the preview shows
    the agent's instructions (and any per-KB vocabulary / existing-entity context)
    without embedding a whole document.
    """
    return _ONTOLOGY_EXTRACTION_PROMPT.format(
        allowed_types_block=_allowed_types_block(allowed_types),
        existing_entities_block=_existing_entities_block(existing_entities),
        document_text="<the uploaded document text is inserted here>",
    )



def revise_ontology(
    *,
    current_ontology: dict[str, Any],
    feedback: str,
    kb_id: str,
    document_text: str | None = None,
    allowed_types: dict[str, list[str]] | None = None,
    provider_name: str | None = None,
    max_tokens: int = 16384,
    temperature: float = 0.0,
) -> dict[str, Any]:
    """Apply human ``feedback`` to ``current_ontology`` and return the revision.

    The agent returns only a small "diff" (entities/relationships to add or
    remove) which is applied to ``current_ontology`` here in code. This keeps the
    LLM output small and, crucially, preserves every existing entity and
    relationship that the feedback does not explicitly change - re-emitting the
    whole ontology on each edit is both fragile (truncation drops the tail) and
    slow on large graphs.

    Args:
        current_ontology: The ontology the user reviewed (from a prior generate/revise).
        feedback: Free-text change request (e.g. "merge X and Y", "add REL a->b").
        kb_id: Target knowledge base id (stamped into the result).
        document_text: Optional source text for grounding; when provided the agent
            can validate feedback against the original document.
        allowed_types: Optional vocabulary constraint (see ``generate_ontology``).
    """
    if not (feedback or "").strip():
        raise ValueError("Empty feedback")

    normalized_current = _normalize_ontology(current_ontology, kb_id=kb_id)

    document_block = ""
    if document_text and document_text.strip():
        doc = document_text.strip()
        if len(doc) > _MAX_DOCUMENT_CHARS:
            doc = doc[:_MAX_DOCUMENT_CHARS] + "\n[...truncated...]"
        document_block = f"\n--- SOURCE DOCUMENT (for reference) ---\n{doc}\n--- END SOURCE DOCUMENT ---\n"

    prompt = _ONTOLOGY_REVISION_PROMPT.format(
        allowed_types_block=_allowed_types_block(allowed_types),
        current_ontology=json.dumps(normalized_current, indent=2),
        document_block=document_block,
        feedback=feedback.strip(),
    )
    raw = get_llm_response_with_fallback(
        prompt=prompt,
        provider_name=provider_name,
        max_tokens=max_tokens,
        temperature=temperature,
        timeout=_LLM_TIMEOUT_SECONDS,
    )

    parsed = _parse_json_object(raw)
    if _is_ontology_diff(parsed):
        ontology = _apply_ontology_diff(normalized_current, parsed, kb_id=kb_id)
    else:
        # Backward-compatible fallback: the model returned a full ontology object
        # instead of a diff. Merge it with the current one.
        ontology = _apply_ontology_diff(
            normalized_current,
            {
                "add_concepts": parsed.get("concepts") or [],
                "add_relationships": parsed.get("relationships") or [],
                "add_taxonomy": parsed.get("taxonomy") or [],
            },
            kb_id=kb_id,
        )
    logger.debug(
        "Ontology revised for kb=%s (concepts=%d, taxonomy=%d, relationships=%d)",
        kb_id,
        len(ontology["concepts"]),
        len(ontology["taxonomy"]),
        len(ontology["relationships"]),
    )
    return ontology


def merge_ontologies(ontologies: list[dict[str, Any]], *, kb_id: str) -> dict[str, Any]:
    """Merge multiple per-document ontologies into a single combined ontology.

    CANDIDATE MERGE (V2): This merges candidate ontologies from the current
    ontology-building operation ONLY. It happens AFTER structural validation
    and BEFORE identity resolution.
    
    This is the \"reduce\" step of the map-reduce generation strategy: each
    document is extracted independently (the \"map\"), then all results are
    combined here. Concepts are de-duplicated by candidate ID, taxonomy by
    (child, parent, type), and relationships by (source, target, type).
    
    Does NOT merge with existing KB ontology - that happens later in the
    KB MERGE phase after identity resolution.
    """
    if not ontologies:
        return {
            "ontology_version": 2,
            "kb_id": kb_id,
            "concepts": [],
            "taxonomy": [],
            "relationships": [],
            "notes": "",
        }
    
    if len(ontologies) == 1:
        return ontologies[0]
    
    # Pool all concepts, taxonomy, relationships
    combined_concepts: list[dict[str, Any]] = []
    combined_taxonomy: list[dict[str, Any]] = []
    combined_relationships: list[dict[str, Any]] = []
    notes: list[str] = []
    
    for ontology in ontologies:
        if not isinstance(ontology, dict):
            continue
        combined_concepts.extend(ontology.get("concepts") or [])
        combined_taxonomy.extend(ontology.get("taxonomy") or [])
        combined_relationships.extend(ontology.get("relationships") or [])
        note = str(ontology.get("notes") or "").strip()
        if note:
            notes.append(note)

    # Re-normalize to deduplicate
    return _normalize_ontology(
        {
            "concepts": combined_concepts,
            "taxonomy": combined_taxonomy,
            "relationships": combined_relationships,
            "notes": " | ".join(notes),
        },
        kb_id=kb_id,
    )


_DIFF_KEYS = (
    "add_concepts",
    "update_concepts",
    "remove_concept_ids",
    "add_taxonomy",
    "remove_taxonomy",
    "add_relationships",
    "remove_relationships",
)


def _is_ontology_diff(payload: dict[str, Any]) -> bool:
    """True when the payload looks like a revision diff rather than a full ontology."""
    return any(key in payload for key in _DIFF_KEYS)


def _apply_ontology_diff(
    current: dict[str, Any], diff: dict[str, Any], *, kb_id: str
) -> dict[str, Any]:
    """Apply a revision ``diff`` to the ``current`` V2 ontology and return the result.

    The diff may contain:
    - add_concepts/update_concepts (new or changed concepts)
    - remove_concept_ids (concepts to delete)
    - add_taxonomy/remove_taxonomy (taxonomy relationships)
    - add_relationships/remove_relationships (domain relationships)
    
    Everything not referenced by the diff is carried over unchanged.
    """
    concepts = list(current.get("concepts") or [])
    taxonomy = list(current.get("taxonomy") or [])
    relationships = list(current.get("relationships") or [])

    # Remove concepts by ID
    remove_ids = {
        str(x).strip()
        for x in (diff.get("remove_concept_ids") or [])
        if str(x).strip()
    }
    if remove_ids:
        concepts = [c for c in concepts if str(c.get("id")) not in remove_ids]
        # Also remove taxonomy/relationships referencing removed concepts
        taxonomy = [
            t for t in taxonomy
            if str(t.get("child_id")) not in remove_ids
            and str(t.get("parent_id")) not in remove_ids
        ]
        relationships = [
            r for r in relationships
            if str(r.get("source_id")) not in remove_ids
            and str(r.get("target_id")) not in remove_ids
        ]

    # Remove specific taxonomy relationships
    remove_tax = {
        (
            str(t.get("child_id") or "").strip(),
            str(t.get("parent_id") or "").strip(),
            str(t.get("relationship_type") or "").strip(),
        )
        for t in (diff.get("remove_taxonomy") or [])
        if isinstance(t, dict)
    }
    if remove_tax:
        taxonomy = [
            t for t in taxonomy
            if (
                str(t.get("child_id") or "").strip(),
                str(t.get("parent_id") or "").strip(),
                str(t.get("relationship_type") or "").strip(),
            ) not in remove_tax
        ]

    # Remove specific domain relationships
    remove_edges = {
        (
            str(r.get("source_id") or "").strip(),
            str(r.get("target_id") or "").strip(),
            str(r.get("type") or "").strip(),
        )
        for r in (diff.get("remove_relationships") or [])
        if isinstance(r, dict)
    }
    if remove_edges:
        relationships = [
            r for r in relationships
            if (
                str(r.get("source_id") or "").strip(),
                str(r.get("target_id") or "").strip(),
                str(r.get("type") or "").strip(),
            ) not in remove_edges
        ]

    # Add/update concepts
    for item in (diff.get("add_concepts") or []) + (diff.get("update_concepts") or []):
        if isinstance(item, dict):
            concepts.append(item)
    
    # Add taxonomy
    for item in diff.get("add_taxonomy") or []:
        if isinstance(item, dict):
            taxonomy.append(item)
    
    # Add relationships
    for item in diff.get("add_relationships") or []:
        if isinstance(item, dict):
            relationships.append(item)

    return _normalize_ontology(
        {
            "ontology_version": 2,
            "concepts": concepts,
            "taxonomy": taxonomy,
            "relationships": relationships,
            "notes": current.get("notes") or "",
        },
        kb_id=kb_id,
    )

# ----------------------------------------------------------------------


def _allowed_types_block(allowed_types: dict[str, list[str]] | None) -> str:
    """Render an optional vocabulary constraint into the prompt (empty when open)."""
    if not allowed_types:
        return ""
    entity_types = allowed_types.get("entity_types") or []
    relationship_types = allowed_types.get("relationship_types") or []
    lines: list[str] = []
    if entity_types:
        lines.append(f"- Use ONLY these entity types: {', '.join(entity_types)}.")
    if relationship_types:
        lines.append(f"- Use ONLY these relationship types: {', '.join(relationship_types)}.")
    if not lines:
        return ""
    return "\n" + "\n".join(lines) + "\n"


def _existing_entities_block(existing_entities: list[dict[str, Any]] | None) -> str:
    """Render the KB's already-known entities so the agent reuses ids and links to them.

    Empty when the KB has no graph yet (first upload), which keeps first-time
    generation fully open. On later uploads this makes extraction graph-aware:
    the agent reuses existing ids (preventing duplicate nodes) and can create
    relationships that connect new entities to ones already in the graph.
    """
    if not existing_entities:
        return ""
    lines = [
        f"  - {e.get('id')} ({e.get('type') or 'Entity'}): {e.get('name') or e.get('id')}"
        for e in existing_entities
        if e.get("id")
    ]
    if not lines:
        return ""
    listing = "\n".join(lines)
    return (
        "\nThe knowledge base ALREADY contains these entities:\n"
        f"{listing}\n"
        "- When the document refers to any of the above, reuse its EXACT id (do "
        "not create a near-duplicate).\n"
        "- Add relationships linking NEW entities to these existing ones wherever "
        "the document supports it.\n"
        "- IMPORTANT: if you create a relationship to one of the existing entities "
        "above, you MUST also include that entity in your \"entities\" list (same id "
        "and type) so the relationship is valid.\n"
    )


def _parse_json_object(raw: str) -> dict[str, Any]:
    """Parse an LLM response into a JSON object, tolerating code fences.

    Also salvages responses that were truncated because the model hit its output
    token limit (a common failure on large ontologies): the trailing incomplete
    element is dropped and any still-open brackets are closed so a valid object
    is still returned instead of raising a cryptic JSON delimiter error.
    """
    text = (raw or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        text = text.strip()

    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        # Best-effort: grab the outermost {...} block if the model added stray text.
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try:
                obj = json.loads(match.group(0))
            except json.JSONDecodeError:
                obj = _repair_truncated_json(text)
        else:
            # No closing brace at all -> likely truncated mid-output.
            obj = _repair_truncated_json(text)

    if not isinstance(obj, dict):
        raise ValueError("LLM did not return a JSON object")
    return obj


def _repair_truncated_json(text: str) -> dict[str, Any] | None:
    """Salvage a JSON object truncated mid-output (e.g. the model hit max_tokens).

    Rebuilds a valid object by rewinding to the last structurally complete point
    (the end of the most recent closed ``{...}`` / ``[...]``) and closing every
    still-open bracket. This preserves all complete entities/relationships while
    discarding only the trailing element that was cut off. Returns ``None`` when
    the response cannot be salvaged.
    """
    start = text.find("{")
    if start == -1:
        return None

    stack: list[str] = []
    in_string = False
    escape = False
    # (index after the boundary, snapshot of the still-open bracket stack)
    last_safe: tuple[int, list[str]] | None = None

    for i in range(start, len(text)):
        ch = text[i]
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch == "{":
            stack.append("}")
        elif ch == "[":
            stack.append("]")
        elif ch in "}]":
            if not stack:
                break
            stack.pop()
            last_safe = (i + 1, list(stack))

    if last_safe is None:
        return None

    boundary, open_stack = last_safe
    repaired = text[start:boundary] + "".join(reversed(open_stack))
    try:
        obj = json.loads(repaired)
    except json.JSONDecodeError:
        return None
    logger.warning(
        "Salvaged a truncated LLM ontology response (%d chars dropped from the tail)",
        len(text) - boundary,
    )
    return obj if isinstance(obj, dict) else None


def _normalize_aliases(aliases: Any) -> list[str]:
    """Normalize aliases field to a list of strings.
    
    Accepts:
    - list of strings: ["Car", "Automobile"]
    - comma-separated string: "Car, Automobile"
    - single string: "Car"
    - None, empty, or invalid: returns []
    """
    if isinstance(aliases, list):
        return [str(a).strip() for a in aliases if a and str(a).strip()]
    elif isinstance(aliases, str) and aliases.strip():
        return [a.strip() for a in aliases.split(",") if a.strip()]
    else:
        return []


def _normalize_ontology(raw: dict[str, Any], *, kb_id: str) -> dict[str, Any]:
    """Coerce LLM V2 output into the guaranteed V2 ontology contract.

    Validates and normalizes V2 schema. Does NOT convert V1 to V2.

    V2 Schema Guarantees:
    - Top-level keys: ontology_version, kb_id, concepts, taxonomy, relationships, notes.
    - Each concept has: id, name, type, description, aliases, properties.
    - Each taxonomy has: child_id, parent_id, relationship_type, properties.
    - Each relationship has: source_id, target_id, type, properties.
    
    STRUCTURAL VALIDATION (Phase A):
    - Drops concepts without ID
    - Drops taxonomy without child_id or parent_id
    - Drops relationships without source_id or target_id
    - Normalizes aliases to array
    - Coerces types to strings
    - Does NOT check if IDs reference real concepts (that's Phase B)
    """
    # VALIDATION: Concepts must have ID
    concepts_raw = raw.get("concepts") if isinstance(raw.get("concepts"), list) else []
    taxonomy_raw = raw.get("taxonomy") if isinstance(raw.get("taxonomy"), list) else []
    relationships_raw = (
        raw.get("relationships") if isinstance(raw.get("relationships"), list) else []
    )

    concepts: list[dict[str, Any]] = []
    concepts_by_id: dict[str, dict[str, Any]] = {}
    
    for item in concepts_raw:
        if not isinstance(item, dict):
            continue
        
        # RULE 1.1 & 1.2: Concept must have non-empty ID
        concept_id = str(item.get("id") or "").strip()
        if not concept_id:
            logger.warning("❌ STRUCTURAL VALIDATION: Dropping concept with missing/empty ID")
            continue
        
        concept_name = str(item.get("name") or concept_id).strip()
        concept_type = str(item.get("type") or "").strip()
        concept_desc = str(item.get("description") or "").strip()
        
        # RULE 1.3: Normalize aliases to array
        concept_aliases = _normalize_aliases(item.get("aliases"))
        
        # RULE 1.4: Properties must be dict
        concept_props = item.get("properties") if isinstance(item.get("properties"), dict) else {}

        existing = concepts_by_id.get(concept_id)
        if existing is None:
            # New concept
            concept = {
                "id": concept_id,
                "name": concept_name,
                "type": concept_type,
                "description": concept_desc,
                "aliases": concept_aliases,
                "properties": dict(concept_props),
            }
            concepts_by_id[concept_id] = concept
            concepts.append(concept)
            continue

        # Duplicate ID: merge to keep richest version
        if concept_type and not existing["type"]:
            existing["type"] = concept_type
        if concept_name and existing["name"] == existing["id"]:
            existing["name"] = concept_name
        if concept_desc and len(concept_desc) > len(existing["description"]):
            existing["description"] = concept_desc
        # Combine aliases
        existing["aliases"] = list(set(existing["aliases"] + concept_aliases))
        # Merge properties
        for key, value in concept_props.items():
            if value not in (None, "", {}, []):
                if not existing["properties"].get(key):
                    existing["properties"][key] = value

    # VALIDATION: Taxonomy must have child_id AND parent_id
    taxonomy: list[dict[str, Any]] = []
    seen_taxonomy: set[tuple[str, str, str]] = set()
    
    for item in taxonomy_raw:
        if not isinstance(item, dict):
            continue
        
        # RULE 1.5: Taxonomy must have both child_id and parent_id
        child_id = str(item.get("child_id") or "").strip()
        parent_id = str(item.get("parent_id") or "").strip()
        
        if not child_id or not parent_id:
            logger.warning("❌ STRUCTURAL VALIDATION: Dropping taxonomy without child_id or parent_id")
            continue
        
        # RULE 1.6: Taxonomy must have valid relationship_type
        rel_type = str(item.get("relationship_type") or "IS_A").strip()
        if not rel_type:
            rel_type = "IS_A"
        
        # De-duplicate by (child, parent, type)
        tax_key = (child_id, parent_id, rel_type)
        if tax_key in seen_taxonomy:
            continue
        seen_taxonomy.add(tax_key)
        
        taxonomy.append({
            "child_id": child_id,
            "parent_id": parent_id,
            "relationship_type": rel_type,
            "properties": item.get("properties") if isinstance(item.get("properties"), dict) else {},
        })

    # VALIDATION: Relationships must have source_id AND target_id
    relationships: list[dict[str, Any]] = []
    seen_relationships: set[tuple[str, str, str]] = set()
    
    for item in relationships_raw:
        if not isinstance(item, dict):
            continue
        
        # RULE 1.7: Relationship must have both source_id and target_id
        source_id = str(item.get("source_id") or item.get("source") or "").strip()
        target_id = str(item.get("target_id") or item.get("target") or "").strip()
        
        if not source_id or not target_id:
            logger.warning("❌ STRUCTURAL VALIDATION: Dropping relationship without source_id or target_id")
            continue
        
        # RULE 1.8: Relationship must have type
        rel_type = str(item.get("type") or "RELATED_TO").strip()
        if not rel_type:
            rel_type = "RELATED_TO"
        
        # De-duplicate by (source, target, type)
        rel_key = (source_id, target_id, rel_type)
        if rel_key in seen_relationships:
            continue
        seen_relationships.add(rel_key)
        
        relationships.append({
            "source_id": source_id,
            "target_id": target_id,
            "type": rel_type,
            "properties": item.get("properties") if isinstance(item.get("properties"), dict) else {},
        })

    return {
        "ontology_version": 2,
        "kb_id": kb_id,
        "concepts": concepts,
        "taxonomy": taxonomy,
        "relationships": relationships,
        "notes": str(raw.get("notes") or ""),
    }
