"""Human-in-the-loop ontology generation for knowledge bases."""
