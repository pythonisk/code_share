"""Load an uploaded document into plain text for ontology extraction.

Uses the shared DAAN document loaders (``daan.utils.documentloaders``) so all
file-type handling (PDF, DOCX, PPTX, XLSX, CSV, JSON, plain-text) is in one
place and ontology extraction automatically benefits from any improvements made
to those loaders.
"""

from __future__ import annotations

import json
import logging

from daan.rag.indexing.rag_document_loader import RagDocumentLoaderAdapter
from daan.utils.documentloaders.load_documents import DocumentLoaderRegistry

logger = logging.getLogger(__name__)


def load_document_text(file_path: str) -> str:
    """Convert a file on disk into a single normalized text string.

    Delegates to ``DocumentLoaderRegistry`` which selects the correct
    LangChain-backed loader based on file extension and returns a structured
    payload.  This function extracts all text from that payload and joins it
    into one string suitable for the ontology LLM prompt.
    """
    try:
        payload = DocumentLoaderRegistry.load_document(file_path)
    except ValueError as exc:
        # Unsupported extension — return empty string so the caller can skip.
        logger.warning("Unsupported file type for ontology loading (%s): %s", file_path, exc)
        return ""
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to load document for ontology (%s): %s", file_path, exc)
        if str(file_path).lower().endswith(".pdf"):
            return _extract_pdf_with_pdfplumber(file_path)
        return ""

    text = _extract_text(payload.get("content") or {})

    # PDF-specific fallback: if the standard loader returned nothing (e.g. the
    # PDF uses a non-standard text layer), retry with pdfplumber which handles
    # more encoding variants and table-heavy layouts.
    if not text.strip() and str(file_path).lower().endswith(".pdf"):
        text = _extract_pdf_with_pdfplumber(file_path)

    return text


def _extract_text(content: dict) -> str:
    """Extract a flat text string from a loader's content dict.

    All DAAN loaders store the main text in ``content["content"]``.
    For structured loaders (PDF, PPTX) we also append per-page/per-slide text
    in case the top-level ``content`` field is empty or shorter.
    """
    parts: list[str] = []

    # Primary text field — present in all loaders
    top = content.get("content") or ""
    if isinstance(top, str) and top.strip():
        parts.append(top.strip())

    content_type = str(content.get("type") or "").strip().lower()
    if content_type == "excel_workbook":
        excel_text = RagDocumentLoaderAdapter._extract_excel_text(content)
        if excel_text.strip():
            parts.append(excel_text.strip())

    # PDF → pages list
    for page in content.get("pages") or []:
        text = (page.get("text") or "").strip()
        if text and text not in parts:
            parts.append(text)

    # PPTX → slides list
    for slide in content.get("slides") or []:
        text = (slide.get("text") or "").strip()
        if text and text not in parts:
            parts.append(text)

    # Excel / CSV → rows stored as JSON when no plain text
    if not parts:
        rows = content.get("rows") or content.get("data")
        if rows:
            parts.append(json.dumps(rows, ensure_ascii=False, default=str))

    return "\n\n".join(parts)


def _extract_pdf_with_pdfplumber(file_path: str) -> str:
    """Fallback PDF text extraction using pdfplumber.

    pdfplumber handles more encoding variants than PyPDFLoader/pypdf and can
    extract text from table-heavy or non-standard PDFs that other loaders
    return empty for.
    """
    try:
        import pdfplumber  # type: ignore[import-untyped]
    except ImportError:
        logger.debug("pdfplumber not installed; skipping PDF fallback for %s", file_path)
        return ""

    try:
        texts: list[str] = []
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text = page.extract_text() or ""
                if text.strip():
                    texts.append(text.strip())
        result = "\n\n".join(texts)
        if result.strip():
            logger.debug("pdfplumber fallback extracted %d chars from %s", len(result), file_path)
        return result
    except Exception as exc:  # noqa: BLE001
        logger.warning("pdfplumber fallback failed for %s: %s", file_path, exc)
        return ""
