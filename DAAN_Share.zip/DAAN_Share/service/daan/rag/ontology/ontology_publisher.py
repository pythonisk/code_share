"""Publish a reviewed ontology into a knowledge base's graph store.

This is the final step of the human-in-the-loop ontology flow:
``generate_ontology`` -> (review + ``revise_ontology``) -> ``publish_ontology``.

It maps the ontology JSON contract onto the graph primitives:
- entity      -> GraphNode(id, label=<entity type>, properties)
- relationship -> GraphEdge(source_id, target_id, type, properties)

The target graph (Cosmos graph/database, or in_memory) is resolved per-KB from
``rag_config.yml`` using the SAME rules as
``RagTool._build_runtime_components`` so published nodes land in the exact graph
that RAG retrieval reads from.
"""

from __future__ import annotations

import os
import logging
from typing import Any
from urllib.parse import unquote

from daan.core.config import get_settings
from daan.graph_stores.graph_document import GraphEdge, GraphNode
from daan.graph_stores.graph_store_factory import GraphStoreFactory

logger = logging.getLogger(__name__)


def resolve_graph_store(kb_id: str, rag_config: dict[str, Any]):
    """Resolve the graph store for ``kb_id`` (mirrors RagTool's resolution).

    Per-KB ``graph``/``database`` overrides win over the global defaults, and a
    per-KB ``graph_store_type`` lets a vector-only KB opt out of a real graph.
    """
    kb_config = _resolve_kb_config(kb_id, rag_config)

    graph_store_config = dict(rag_config.get("graph_store_config", {}))
    if kb_config.get("graph"):
        graph_store_config["graph"] = kb_config["graph"]
    if kb_config.get("database"):
        graph_store_config["database"] = kb_config["database"]

    # If the KB is not declared in rag_config.yml, fall back to the shared
    # Cosmos env values so the graph endpoint still resolves the same storage
    # that the colleague system uses.
    if not graph_store_config.get("graph") or not graph_store_config.get("database"):
        fallback_graph, fallback_database = _resolve_graph_env_fallback(kb_id)
        graph_store_config.setdefault("graph", fallback_graph)
        graph_store_config.setdefault("database", fallback_database)

    graph_store_type = kb_config.get("graph_store_type") or rag_config.get(
        "graph_store_type", "kuzu"
    )
    return graph_store_type, GraphStoreFactory.create_store(
        store_name=graph_store_type,
        config=graph_store_config,
    )


def _resolve_and_validate_taxonomy_v2(
    candidate_taxonomy: list[dict[str, Any]],
    id_mapping: dict[str, str],
    existing_concept_ids: set[str],
    resolved_concept_ids: set[str],
) -> list[dict[str, Any]]:
    """Resolve taxonomy endpoint IDs and validate referential integrity.
    
    REFERENTIAL VALIDATION (Phase B): Check that all taxonomy child_id and
    parent_id reference real concepts (either from current document or existing KB).
    
    Rules:
    - child_id must be in id_mapping OR in existing_concept_ids
    - parent_id must be in id_mapping OR in existing_concept_ids
    - No self-loops (child_id == parent_id)
    - Drop invalid taxonomy entries (log warnings)
    
    This allows cross-document references: new concept → existing KB concept.
    """
    resolved_taxonomy: list[dict[str, Any]] = []
    
    for tax in candidate_taxonomy:
        child_candidate = tax["child_id"]
        parent_candidate = tax["parent_id"]
        
        # Resolve child_id
        if child_candidate in id_mapping:
            child_final = id_mapping[child_candidate]
        elif child_candidate in existing_concept_ids:
            child_final = child_candidate
        else:
            logger.warning(
                f"❌ REFERENTIAL VALIDATION: Dropping taxonomy - child '{child_candidate}' not found "
                f"(not in id_mapping or existing Cosmos concepts)"
            )
            continue
        
        # Resolve parent_id
        if parent_candidate in id_mapping:
            parent_final = id_mapping[parent_candidate]
        elif parent_candidate in existing_concept_ids:
            parent_final = parent_candidate
        else:
            logger.warning(
                f"❌ REFERENTIAL VALIDATION: Dropping taxonomy - parent '{parent_candidate}' not found "
                f"(not in id_mapping or existing Cosmos concepts)"
            )
            continue
        
        # Check for self-loops
        if child_final == parent_final:
            logger.warning(
                f"❌ REFERENTIAL VALIDATION: Dropping taxonomy - self-loop detected: "
                f"{child_final} IS_A {parent_final}"
            )
            continue
        
        # Warn if unusual taxonomy type
        valid_taxonomy_types = {"IS_A", "SUBCLASS_OF", "INSTANCE_OF", "TYPE_OF"}
        if tax["relationship_type"] not in valid_taxonomy_types:
            logger.warning(
                f"⚠️  WARNING: Unusual taxonomy type '{tax['relationship_type']}' "
                f"(expected one of {valid_taxonomy_types})"
            )
        
        # All validations passed
        resolved_taxonomy.append({
            "child_id": child_final,
            "parent_id": parent_final,
            "relationship_type": tax["relationship_type"],
            "properties": tax.get("properties", {}),
        })
    
    logger.info(
        f"✅ Taxonomy validation: {len(resolved_taxonomy)} valid out of {len(candidate_taxonomy)} candidates"
    )
    return resolved_taxonomy


def _resolve_and_validate_relationships_v2(
    candidate_relationships: list[dict[str, Any]],
    id_mapping: dict[str, str],
    existing_concept_ids: set[str],
    resolved_concept_ids: set[str],
) -> list[dict[str, Any]]:
    """Resolve relationship endpoint IDs and validate referential integrity.
    
    REFERENTIAL VALIDATION (Phase B): Check that all relationship source_id and
    target_id reference real concepts (either from current document or existing KB).
    
    Rules:
    - source_id must be in id_mapping OR in existing_concept_ids
    - target_id must be in id_mapping OR in existing_concept_ids
    - Warn on self-loops (not necessarily invalid)
    - Warn if taxonomy type used in relationships
    - Drop invalid relationships (log warnings)
    
    This allows cross-document references: new concept → existing KB concept.
    """
    resolved_relationships: list[dict[str, Any]] = []
    
    for rel in candidate_relationships:
        source_candidate = rel["source_id"]
        target_candidate = rel["target_id"]
        
        # Resolve source_id
        if source_candidate in id_mapping:
            source_final = id_mapping[source_candidate]
        elif source_candidate in existing_concept_ids:
            source_final = source_candidate
        else:
            logger.warning(
                f"❌ REFERENTIAL VALIDATION: Dropping relationship - source '{source_candidate}' not found "
                f"(not in id_mapping or existing Cosmos concepts)"
            )
            continue
        
        # Resolve target_id
        if target_candidate in id_mapping:
            target_final = id_mapping[target_candidate]
        elif target_candidate in existing_concept_ids:
            target_final = target_candidate
        else:
            logger.warning(
                f"❌ REFERENTIAL VALIDATION: Dropping relationship - target '{target_candidate}' not found "
                f"(not in id_mapping or existing Cosmos concepts)"
            )
            continue
        
        # Warn on self-loops (not necessarily invalid for domain relationships)
        if source_final == target_final:
            logger.warning(
                f"⚠️  WARNING: Self-loop in relationship: "
                f"{source_final} -[{rel['type']}]-> {target_final}"
            )
        
        # Warn if taxonomy type used in relationships
        taxonomy_types = {"IS_A", "SUBCLASS_OF", "INSTANCE_OF", "TYPE_OF"}
        if rel["type"] in taxonomy_types:
            logger.warning(
                f"⚠️  WARNING: Taxonomy type '{rel['type']}' used in relationships "
                f"(should be in taxonomy array instead)"
            )
        
        # All validations passed
        resolved_relationships.append({
            "source_id": source_final,
            "target_id": target_final,
            "type": rel["type"],
            "properties": rel.get("properties", {}),
        })
    
    logger.info(
        f"✅ Relationship validation: {len(resolved_relationships)} valid out of {len(candidate_relationships)} candidates"
    )
    return resolved_relationships


def publish_ontology(
    *,
    ontology: dict[str, Any],
    kb_id: str,
    rag_config: dict[str, Any],
) -> dict[str, Any]:
    """Write the V2 ontology into the KB's graph, then update PostgreSQL.

    V2 PUBLISHING FLOW:
    1. Ontology is already resolved (identity resolution happened in generation)
    2. Publish concepts → Cosmos vertices
    3. Publish taxonomy → Cosmos edges (IS_A, SUBCLASS_OF, etc.)
    4. Publish relationships → Cosmos edges (USES, DEPENDS_ON, etc.)
    5. AFTER successful Cosmos → Update PostgreSQL (sequential, not parallel)

    Args:
        ontology: The reviewed and resolved V2 ontology with final IDs.
        kb_id: Target knowledge base id.
        rag_config: Loaded RAG config (``get_settings().load_rag_config()``).

    Returns:
        {"status", "kb_id", "graph_store_type", "nodes_written", "edges_written",
         "postgres_indexed"}.
    """
    # V2 schema validation
    ontology_version = ontology.get("ontology_version")
    if ontology_version != 2:
        raise ValueError(
            f"Only V2 ontology schema is supported. Got ontology_version={ontology_version}. "
            "Use the latest ontology extraction endpoint to generate V2 ontologies."
        )
    
    concepts = ontology.get("concepts", [])
    taxonomy = ontology.get("taxonomy", [])
    relationships = ontology.get("relationships", [])
    
    if not concepts:
        raise ValueError("V2 ontology has no concepts to publish.")

    graph_store_type, graph_store = resolve_graph_store(kb_id, rag_config)

    if graph_store_type == "in_memory":
        logger.warning(
            "KB %r uses graph_store_type=in_memory; published ontology will not persist.",
            kb_id,
        )

    # ============================================================
    # PHASE 1: Publish to Cosmos
    # ============================================================
    
    # 1a. Publish concepts as vertices
    nodes_written = 0
    for concept in concepts:
        concept_id = concept.get("id")
        if not concept_id:
            logger.warning(
                f"⚠️  Skipping concept with missing ID: name={concept.get('name')}, "
                f"type={concept.get('type')}, concept_data={concept}"
            )
            continue
            
        properties = dict(concept.get("properties") or {})
        properties.setdefault("name", concept.get("name", concept_id))
        properties["ontology_type"] = concept.get("type", "")
        properties["description"] = concept.get("description", "")
        
        # Store aliases as comma-separated string
        aliases = concept.get("aliases", [])
        if aliases:
            properties["aliases"] = ",".join(aliases)
        
        try:
            graph_store.upsert_node(
                GraphNode(
                    id=concept_id,
                    label=concept.get("type") or "Concept",
                    properties=properties,
                )
            )
            nodes_written += 1
        except Exception as exc:
            logger.error(
                f"❌ Failed to publish concept '{concept_id}' (type={concept.get('type')}): {exc}"
            )
            # Continue processing remaining concepts

    # 1b. Publish taxonomy edges
    edges_written = 0
    for tax in taxonomy:
        graph_store.upsert_edge(
            GraphEdge(
                source_id=tax["child_id"],
                target_id=tax["parent_id"],
                type=tax["relationship_type"],
                properties=dict(tax.get("properties") or {}),
            )
        )
        edges_written += 1
    
    # 1c. Publish relationship edges
    for rel in relationships:
        graph_store.upsert_edge(
            GraphEdge(
                source_id=rel["source_id"],
                target_id=rel["target_id"],
                type=rel["type"],
                properties=dict(rel.get("properties") or {}),
            )
        )
        edges_written += 1

    # Verify write success and fail fast if nothing was written
    expected_nodes = len(concepts)
    if nodes_written < expected_nodes:
        logger.error(
            f"❌ Ontology publish PARTIAL FAILURE for kb={kb_id}: "
            f"Only {nodes_written}/{expected_nodes} nodes written successfully. "
            f"{expected_nodes - nodes_written} nodes failed."
        )
        if nodes_written == 0:
            raise RuntimeError(
                f"Failed to write ANY concepts to Cosmos for kb={kb_id}. "
                f"Verify graph store connectivity and configuration."
            )
    
    logger.info(
        "✅ Published ontology to Cosmos for kb=%s (%d nodes, %d edges) into %s graph.",
        kb_id,
        nodes_written,
        edges_written,
        graph_store_type,
    )

    # ============================================================
    # PHASE 2: Update PostgreSQL (SEQUENTIAL, after Cosmos success)
    # ============================================================
    
    postgres_indexed = 0
    try:
        # Import here to avoid circular dependencies
        from daan.native_tools.rag_tool import RagTool
        
        # Index ontology concepts for RAG
        # This reads concepts FROM Cosmos (not from JSON) and embeds them
        rag_tool = RagTool(rag_config=rag_config)
        result = rag_tool.index_ontology_concepts(kb_id=kb_id)
        postgres_indexed = result.get("concepts_indexed", 0)
        
        logger.info(
            f"✅ Indexed {postgres_indexed} concepts in PostgreSQL for kb={kb_id}"
        )
        
    except Exception as e:
        # PostgreSQL failure does NOT rollback Cosmos
        # Cosmos is source of truth, PostgreSQL is derived
        logger.warning(
            f"⚠️  PostgreSQL indexing failed for kb={kb_id} (Cosmos publication was successful): {e}"
        )
        # Continue - ontology is published successfully to Cosmos

    return {
        "status": "ok",
        "kb_id": kb_id,
        "graph_store_type": graph_store_type,
        "nodes_written": nodes_written,
        "edges_written": edges_written,
        "postgres_indexed": postgres_indexed,
    }


def _resolve_kb_config(kb_id: str, rag_config: dict[str, Any]) -> dict[str, Any]:
    """Return the knowledge_bases[] entry for kb_id (graph/database overrides)."""
    for entry in rag_config.get("knowledge_bases", []) or []:
        if str(entry.get("id")) == str(unquote(kb_id)):
            return dict(entry)

    # Known alias used by the UI and legacy knowledge-base routes.
    alias_map = {
        "claims": "claims_scenarios",
    }
    aliased_id = alias_map.get(str(kb_id))
    if aliased_id:
        for entry in rag_config.get("knowledge_bases", []) or []:
            if str(entry.get("id")) == aliased_id:
                return dict(entry)
    return {}


def _resolve_graph_env_fallback(kb_id: str) -> tuple[str, str]:
    """Pick the most appropriate graph/database env vars when rag_config has no KB entry."""
    kb = str(kb_id).strip().lower()

    # Prefer KB-specific env values when available.
    if kb in {"claims", "claims_scenarios", "claims-scenarios"}:
        graph = os.getenv("GREMLIN_SCENARIOS_GRAPH") or os.getenv("GREMLIN_KB_GRAPH") or os.getenv("GREMLIN_GRAPH")
        database = os.getenv("GREMLIN_SCENARIOS_DATABASE") or os.getenv("GREMLIN_KB_DATABASE") or os.getenv("GREMLIN_DATABASE")
        return str(graph or ""), str(database or "")

    # Generic KB fallback used by the claims route and similar KBs.
    graph = os.getenv("GREMLIN_KB_GRAPH") or os.getenv("GREMLIN_GRAPH")
    database = os.getenv("GREMLIN_KB_DATABASE") or os.getenv("GREMLIN_DATABASE")
    return str(graph or ""), str(database or "")


def fetch_existing_entities(
    kb_id: str,
    rag_config: dict[str, Any],
    *,
    limit: int = 200,
) -> list[dict[str, Any]]:
    """Return entities already present in the KB's graph ({id, type, name}).

    Used to make ontology generation graph-aware on incremental uploads: the
    agent is told what already exists so it reuses ids and links new entities to
    them instead of creating duplicates. Chunk nodes (written by vector ingestion)
    are excluded, and the result is bounded by ``limit`` to keep prompts small.
    Returns an empty list for in-memory graphs or on any error (best-effort).

    Note: this deliberately does NOT use ``get_subgraph(ids)`` because Cosmos DB
    rejects ``g.V(<list-of-ids>)`` ("composite key requires [partition_key, id]").
    Instead it projects over all vertices, which Cosmos accepts.
    """
    graph_store_type, graph_store = resolve_graph_store(kb_id, rag_config)
    if graph_store_type == "in_memory":
        logger.debug("KB %s uses in_memory graph store - no existing entities to fetch", kb_id)
        return []

    # Project id/label/name over the graph's vertices (Cosmos-safe: no id list).
    query = (
        f"g.V().limit({max(limit * 5, limit)})"
        ".project('id','label','name')"
        ".by(id()).by(label())"
        ".by(coalesce(values('label_name','name'), constant('')))"
    )
    try:
        rows = graph_store.query(query)
    except Exception:  # noqa: BLE001
        logger.exception("Could not read existing entities for kb=%s", kb_id)
        logger.error(
            "Failed to fetch existing entities for kb=%s - ontology prompt will NOT include "
            "existing entities section, which may cause duplicate nodes on incremental uploads",
            kb_id
        )
        return []

    entities: list[dict[str, Any]] = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        label = str(row.get("label") or "")
        if label == "Chunk":  # exclude vector-ingestion chunk nodes
            continue
        entity_id = row.get("id")
        if not entity_id:
            continue
        entities.append(
            {
                "id": entity_id,
                "type": label or "Entity",
                "name": row.get("name") or entity_id,
            }
        )
        if len(entities) >= limit:
            break
    
    logger.info(
        "Fetched %d existing entities for kb=%s (will be included in ontology extraction prompt)",
        len(entities),
        kb_id
    )
    return entities


def resolve_concept_identities(
    candidate_concepts: list[dict[str, Any]],
    existing_concepts: list[dict[str, Any]],
    kb_id: str,
) -> tuple[list[dict[str, Any]], dict[str, str]]:
    """Resolve candidate concept IDs to final Cosmos IDs via identity resolution.
    
    IDENTITY RESOLUTION (V2): This is the critical step that determines whether
    each candidate concept from the LLM matches an existing KB concept.
    
    Matching strategies (in order):
    1. Exact ID match: candidate_id == existing_id
    2. Normalized name match: normalize(candidate_name) == normalize(existing_name)
    3. Alias match: normalize(candidate_alias) in normalize(existing_aliases)
    
    Returns:
        (resolved_concepts, id_mapping)
        - resolved_concepts: Concepts with final Cosmos IDs
        - id_mapping: {candidate_id: final_cosmos_id}
    
    If match found:
        - Reuse existing Cosmos ID
        - Merge properties (candidate enriches existing)
    
    If no match:
        - Use candidate ID as final ID (new concept)
    """
    from daan.rag.graph.ontology_linker import TextNormalizer
    
    # Build indexes of existing concepts for fast lookup
    existing_by_id = {c["id"]: c for c in existing_concepts}
    existing_by_norm_name: dict[str, dict[str, Any]] = {}
    existing_by_alias: dict[str, dict[str, Any]] = {}
    
    for existing in existing_concepts:
        # Index by normalized name
        norm_name = TextNormalizer.normalize(existing.get("name", ""))
        if norm_name and norm_name not in existing_by_norm_name:
            existing_by_norm_name[norm_name] = existing
        
        # Index by aliases (from properties if present)
        aliases_str = existing.get("properties", {}).get("aliases", "")
        if isinstance(aliases_str, str) and aliases_str:
            for alias in aliases_str.split(","):
                norm_alias = TextNormalizer.normalize(alias.strip())
                if norm_alias and norm_alias not in existing_by_alias:
                    existing_by_alias[norm_alias] = existing
    
    resolved_concepts: list[dict[str, Any]] = []
    id_mapping: dict[str, str] = {}
    
    for candidate in candidate_concepts:
        candidate_id = candidate["id"]
        candidate_name = candidate.get("name", "")
        candidate_aliases = candidate.get("aliases", [])
        
        matched_existing = None
        match_reason = None
        
        # Strategy 1: Exact ID match
        if candidate_id in existing_by_id:
            matched_existing = existing_by_id[candidate_id]
            match_reason = "exact_id"
            logger.debug(f"✅ Matched concept '{candidate_id}' by exact ID")
        
        # Strategy 2: Normalized name match
        if not matched_existing and candidate_name:
            norm_name = TextNormalizer.normalize(candidate_name)
            if norm_name in existing_by_norm_name:
                matched_existing = existing_by_norm_name[norm_name]
                match_reason = "normalized_name"
                logger.debug(f"✅ Matched concept '{candidate_id}' to '{matched_existing['id']}' by normalized name '{norm_name}'")
        
        # Strategy 3: Alias match
        if not matched_existing:
            for alias in candidate_aliases:
                norm_alias = TextNormalizer.normalize(alias)
                if norm_alias in existing_by_alias:
                    matched_existing = existing_by_alias[norm_alias]
                    match_reason = "alias"
                    logger.debug(f"✅ Matched concept '{candidate_id}' to '{matched_existing['id']}' by alias '{norm_alias}'")
                    break
        
        # Determine final ID and build resolved concept
        if matched_existing:
            # MATCH FOUND: Reuse existing Cosmos ID
            final_id = matched_existing["id"]
            id_mapping[candidate_id] = final_id
            
            # Merge properties (candidate enriches existing)
            resolved = dict(matched_existing)
            resolved.update({
                "id": final_id,
                "name": candidate_name or matched_existing.get("name", final_id),
                "type": candidate.get("type") or matched_existing.get("type", ""),
                "description": candidate.get("description") or matched_existing.get("description", ""),
                "aliases": candidate.get("aliases", []),
                "properties": {
                    **matched_existing.get("properties", {}),
                    **candidate.get("properties", {}),
                },
            })
            resolved_concepts.append(resolved)
            logger.debug(f"🔄 Concept resolution: '{candidate_id}' → '{final_id}' (EXISTING, matched via {match_reason})")
        else:
            # NO MATCH: New concept, use candidate ID as final ID
            final_id = candidate_id
            id_mapping[candidate_id] = final_id
            resolved_concepts.append(candidate)
            logger.debug(f"🆕 Concept resolution: '{candidate_id}' → '{final_id}' (NEW)")
    
    return resolved_concepts, id_mapping


def resolve_and_enrich_ontology(
    candidate_ontology: dict[str, Any],
    existing_entities: list[dict[str, Any]],
    kb_id: str,
    *,
    rag_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Resolve a candidate (merged) ontology's concept identities against the KB
    graph and enrich it with ``_status`` tags, ready for review/publish.

    V2 ontologies get identity resolution (``resolve_concept_identities``) plus
    taxonomy/relationship id-remapping and NEW/EXISTING concept status tags.
    V1 ontologies (legacy) pass through unchanged. Shared by both the
    interactive ``/ontology/generate`` endpoint and batch ontology-building
    scripts so the enrichment logic lives in one place.

    When ``rag_config`` is provided, fetches ALL entities from the graph for
    identity resolution (not just the LLM-prompt subset).
    """
    ontology_version = candidate_ontology.get("ontology_version", 1)
    if ontology_version != 2:
        return candidate_ontology

    # Use full entity set for resolution if rag_config is available
    if rag_config is not None:
        resolution_entities = fetch_existing_entities(kb_id, rag_config, limit=50000)
        logger.info(
            "Fetched %d entities for identity resolution (full set)", len(resolution_entities)
        )
    else:
        resolution_entities = existing_entities

    candidate_concepts = candidate_ontology.get("concepts", [])
    resolved_concepts, id_mapping = resolve_concept_identities(
        candidate_concepts=candidate_concepts,
        existing_concepts=resolution_entities,
        kb_id=kb_id,
    )

    enriched_taxonomy = [
        {
            "child_id": id_mapping.get(tax["child_id"], tax["child_id"]),
            "parent_id": id_mapping.get(tax["parent_id"], tax["parent_id"]),
            "relationship_type": tax["relationship_type"],
            "properties": tax.get("properties", {}),
        }
        for tax in candidate_ontology.get("taxonomy", [])
    ]

    enriched_relationships = [
        {
            "source_id": id_mapping.get(rel["source_id"], rel["source_id"]),
            "target_id": id_mapping.get(rel["target_id"], rel["target_id"]),
            "type": rel["type"],
            "properties": rel.get("properties", {}),
        }
        for rel in candidate_ontology.get("relationships", [])
    ]

    existing_concept_ids = {e["id"] for e in resolution_entities}
    for concept in resolved_concepts:
        concept["_status"] = "EXISTING" if concept["id"] in existing_concept_ids else "NEW"

    logger.info(
        f"✅ V2 ontology enriched for kb={kb_id}: {len(resolved_concepts)} concepts "
        f"({sum(1 for c in resolved_concepts if c.get('_status') == 'NEW')} NEW, "
        f"{sum(1 for c in resolved_concepts if c.get('_status') == 'EXISTING')} EXISTING)"
    )

    return {
        "ontology_version": 2,
        "concepts": resolved_concepts,
        "taxonomy": enriched_taxonomy,
        "relationships": enriched_relationships,
        "metadata": candidate_ontology.get("metadata", {}),
    }


# Vertices that are not part of the curated ontology: ``Chunk`` vertices written
# by vector ingestion and ``Entity`` vertices left over from the deprecated
# per-chunk entity extractor. Applied inside the traversal (not after the fact)
# so ``limit`` counts ontology vertices only — a KB with thousands of chunks
# would otherwise consume the whole limit before any concept is reached.
# Mirrors CosmosGraphStore.list_concept_nodes so the graph view and the concept
# embeddings stay in sync.
_ONTOLOGY_VERTEX_FILTER = ".not(hasLabel('Chunk')).not(hasLabel('Entity'))"


def fetch_full_graph(
    kb_id: str,
    rag_config: dict[str, Any],
    *,
    limit: int = 1000,
) -> dict[str, list[dict[str, Any]]]:
    """Return the entire published graph for ``kb_id`` as ``{nodes, edges}``.

    Each node is ``{id, type, name, description}`` and each edge is
    ``{source, target, type}``. Chunk nodes (written by vector ingestion) and
    legacy ``Entity`` nodes are excluded so the result is the ontology/knowledge
    graph only. Returns empty lists for in-memory graphs (no persistence) or on
    any error (best-effort).

    Like ``fetch_existing_entities`` this avoids ``g.V(<list-of-ids>)`` because
    Cosmos DB rejects id-list lookups; it projects over all vertices/edges,
    which Cosmos accepts.
    """
    graph_store_type, graph_store = resolve_graph_store(kb_id, rag_config)

    if graph_store_type == "in_memory":
        # In-memory graphs do not persist; return whatever is currently loaded.
        try:
            node_ids = list(getattr(graph_store, "_nodes", {}).keys())
            sub = graph_store.get_subgraph(node_ids)
            nodes = [
                {
                    "id": n.id,
                    "type": n.label or "Entity",
                    "name": (n.properties or {}).get("name", n.id),
                    "description": (n.properties or {}).get("description", ""),
                }
                for n in sub.get("nodes", [])
            ]
            edges = [
                {"source": e.source_id, "target": e.target_id, "type": e.type}
                for e in sub.get("edges", [])
            ]
            return {"nodes": nodes, "edges": edges}
        except Exception:  # noqa: BLE001
            logger.exception("Could not read in-memory graph for kb=%s", kb_id)
            return {"nodes": [], "edges": []}

    node_query = (
        f"g.V(){_ONTOLOGY_VERTEX_FILTER}.limit({limit})"
        ".project('id','label','name','description')"
        ".by(id()).by(label())"
        ".by(coalesce(values('label_name','name'), constant('')))"
        ".by(coalesce(values('description'), constant('')))"
    )
    # Only concept->concept edges: the chunk -MENTIONS-> concept edges vastly
    # outnumber them and would otherwise exhaust the limit.
    edge_query = (
        f"g.V(){_ONTOLOGY_VERTEX_FILTER}.outE()"
        f".where(inV(){_ONTOLOGY_VERTEX_FILTER})"
        f".limit({limit * 5})"
        ".project('source','target','type')"
        ".by(outV().id()).by(inV().id()).by(label())"
    )
    try:
        node_rows = graph_store.query(node_query)
        edge_rows = graph_store.query(edge_query)
    except Exception:  # noqa: BLE001
        logger.exception("Could not read full graph for kb=%s", kb_id)
        return {"nodes": [], "edges": []}

    nodes: list[dict[str, Any]] = []
    valid_ids: set[str] = set()
    for row in node_rows or []:
        if not isinstance(row, dict):
            continue
        label = str(row.get("label") or "")
        if label in ("Chunk", "Entity"):
            continue
        node_id = row.get("id")
        if not node_id:
            continue
        node_id = str(node_id)
        if node_id.startswith("ent:"):  # deprecated per-chunk extractor id scheme
            continue
        valid_ids.add(node_id)
        nodes.append(
            {
                "id": node_id,
                "type": label or "Entity",
                "name": row.get("name") or node_id,
                "description": row.get("description") or "",
            }
        )

    edges: list[dict[str, Any]] = []
    for row in edge_rows or []:
        if not isinstance(row, dict):
            continue
        source = row.get("source")
        target = row.get("target")
        if source is None or target is None:
            continue
        source, target = str(source), str(target)
        # Only keep edges whose endpoints are real (non-Chunk) ontology nodes.
        if source not in valid_ids or target not in valid_ids:
            continue
        edges.append(
            {
                "source": source,
                "target": target,
                "type": str(row.get("type") or "RELATION"),
            }
        )

    return {"nodes": nodes, "edges": edges}


def fetch_node_neighborhood(
    kb_id: str,
    rag_config: dict[str, Any],
    node_id: str,
    *,
    depth: int = 1,
) -> dict[str, list[dict[str, Any]]]:
    """Return one node plus its neighborhood (within ``depth`` hops) as ``{nodes, edges}``.

    Used for click-to-expand graph exploration: the UI starts from a node and
    expands outward one request at a time. The shape matches ``fetch_full_graph``
    (nodes: ``{id, type, name, description}``, edges: ``{source, target, type}``)
    so the caller can map both through the same visualization formatter.

    ``depth`` is clamped to 1..5. Chunk nodes are excluded. Returns empty lists on
    any error (best-effort).
    """
    try:
        safe_depth = int(depth)
    except (TypeError, ValueError):
        safe_depth = 1
    safe_depth = max(1, min(safe_depth, 5))

    graph_store_type, graph_store = resolve_graph_store(kb_id, rag_config)

    if graph_store_type == "in_memory":
        try:
            neighbors = graph_store.get_neighbors(node_id, safe_depth)
            nodes_by_id: dict[str, Any] = {}
            start = getattr(graph_store, "_nodes", {}).get(node_id)
            if start is not None:
                nodes_by_id[start.id] = start
            for n in neighbors:
                nodes_by_id[n.id] = n
            nodes = [
                {
                    "id": n.id,
                    "type": n.label or "Entity",
                    "name": (n.properties or {}).get("name", n.id),
                    "description": (n.properties or {}).get("description", ""),
                }
                for n in nodes_by_id.values()
            ]
            ids = set(nodes_by_id)
            edges = [
                {"source": e.source_id, "target": e.target_id, "type": e.type}
                for e in getattr(graph_store, "_edges", [])
                if e.source_id in ids and e.target_id in ids
            ]
            return {"nodes": nodes, "edges": edges}
        except Exception:  # noqa: BLE001
            logger.exception("Could not read in-memory neighborhood for kb=%s", kb_id)
            return {"nodes": [], "edges": []}

    nid = str(node_id)
    # The neighborhood = the start node plus everything within depth hops.
    # times() must be an inline literal for Cosmos; safe_depth is a clamped int.
    # Hops stay inside ontology vertices so expansion never detours via chunks.
    neighborhood = (
        f"g.V('{nid}')"
        f".union(identity(), repeat(both(){_ONTOLOGY_VERTEX_FILTER}.simplePath()).times({safe_depth}).emit())"
        ".dedup()"
    )
    node_query = (
        neighborhood
        + ".project('id','label','name','description')"
        ".by(id()).by(label())"
        ".by(coalesce(values('label_name','name'), constant('')))"
        ".by(coalesce(values('description'), constant('')))"
    )
    # Edges incident to the neighborhood; filtered to internal edges below.
    edge_query = (
        neighborhood
        + f".outE().where(inV(){_ONTOLOGY_VERTEX_FILTER})"
        ".project('source','target','type')"
        ".by(outV().id()).by(inV().id()).by(label())"
    )
    try:
        node_rows = graph_store.query(node_query)
        edge_rows = graph_store.query(edge_query)
    except Exception:  # noqa: BLE001
        logger.exception("Could not read neighborhood for kb=%s node=%s", kb_id, node_id)
        return {"nodes": [], "edges": []}

    nodes: list[dict[str, Any]] = []
    valid_ids: set[str] = set()
    for row in node_rows or []:
        if not isinstance(row, dict):
            continue
        label = str(row.get("label") or "")
        if label in ("Chunk", "Entity"):
            continue
        row_id = row.get("id")
        if not row_id:
            continue
        row_id = str(row_id)
        if row_id.startswith("ent:"):  # deprecated per-chunk extractor id scheme
            continue
        valid_ids.add(row_id)
        nodes.append(
            {
                "id": row_id,
                "type": label or "Entity",
                "name": row.get("name") or row_id,
                "description": row.get("description") or "",
            }
        )

    edges: list[dict[str, Any]] = []
    for row in edge_rows or []:
        if not isinstance(row, dict):
            continue
        source = row.get("source")
        target = row.get("target")
        if source is None or target is None:
            continue
        source, target = str(source), str(target)
        # Keep only edges whose endpoints are both inside the returned neighborhood.
        if source not in valid_ids or target not in valid_ids:
            continue
        edges.append(
            {
                "source": source,
                "target": target,
                "type": str(row.get("type") or "RELATION"),
            }
        )

    return {"nodes": nodes, "edges": edges}
