"""Ground chunks into the curated ontology (ontology-only design).

Chunks live only in the vector store; the graph holds only the curated ontology
concepts (e.g. ``v001`` / "DAAN", ``v020`` / "Planner Agent"). Instead of writing
a ``Chunk`` vertex + ``MENTIONS`` edges per chunk into Cosmos (slow and
duplicative), ``OntologyLinker`` tags each chunk with the ids of the ontology
concepts it mentions. That tag is stored as a ``concept_ids`` JSONB array on the
chunk's vector-store metadata.

Retrieval (GraphRAG local search) then maps concept -> chunk via this array and
expands relationships over the curated concept-only graph, instead of traversing
ad-hoc per-chunk vertices.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from daan.graph_stores.providers.base_graph_store import BaseGraphStore
from daan.vector_stores.document import RagDocument

logger = logging.getLogger(__name__)


class TextNormalizer:
    """Normalize text for robust concept matching across different text formats.
    
    Handles variations in whitespace, punctuation, and case to match concepts
    even when parsers extract text differently (e.g., LangChain vs custom parsers).
    """
    
    @staticmethod
    def normalize(text: str) -> str:
        """Normalize text for matching.
        
        Args:
            text: Raw text to normalize
            
        Returns:
            Normalized text (lowercase, no punctuation, collapsed whitespace)
        """
        # Lowercase
        text = text.lower()
        # Remove punctuation (but keep spaces and alphanumeric)
        text = re.sub(r"[^\w\s]", " ", text)
        # Collapse multiple spaces
        text = re.sub(r"\s+", " ", text)
        return text.strip()
    
    @staticmethod
    def create_variations(text: str) -> set[str]:
        """Create text variations for matching.
        
        Generates multiple forms of the same concept to handle different
        text extraction formats:
        - Original normalized form: "duplicate detection service"
        - No spaces form: "duplicatedetectionservice"
        - Single word parts: ["duplicate", "detection", "service"]
        
        Args:
            text: Text to create variations for
            
        Returns:
            Set of normalized variations
        """
        normalized = TextNormalizer.normalize(text)
        if not normalized:
            return set()
        
        variations = {normalized}
        
        # Add no-spaces version (handles "DuplicateDetectionService")
        no_spaces = normalized.replace(" ", "")
        if no_spaces and no_spaces != normalized:
            variations.add(no_spaces)
        
        return variations

# Concept names shorter than this (after normalization) are ignored to avoid
# matching common English fragments (e.g. "API" is kept, "AI" would be dropped).
_MIN_NAME_LEN = 3

# Generic words that appear as concept names but are far too common to link on
# their own without producing noise. Includes common English words so that stray
# non-curated vertices (e.g. leftovers from the deprecated entity extractor:
# "has", "more") never get linked even if they reach the concept list.
_STOPWORD_NAMES = {
    "core",
    "data",
    "agent",
    "component",
    "system",
    "service",
    "report",
    "session",
    "state",
    "artifact",
    "storage",
    "has",
    "have",
    "had",
    "more",
    "most",
    "the",
    "and",
    "for",
    "with",
    "from",
    "this",
    "that",
    "these",
    "those",
    "into",
    "your",
    "you",
    "use",
    "used",
    "using",
    "based",
    "each",
    "then",
    "than",
    "other",
    "also",
    "will",
    "can",
    "may",
    "are",
    "was",
    "were",
    "not",
    "any",
    "all",
    "one",
    "two",
    "new",
    "via",
}


class OntologyLinker:
    """Tag chunks with the curated ontology concept ids they mention."""

    def __init__(self, graph_store: BaseGraphStore, config: dict[str, Any] | None = None) -> None:
        self.graph_store = graph_store
        config = config or {}
        self.min_name_len = int(config.get("min_name_len", _MIN_NAME_LEN))
        self.max_links_per_chunk = int(config.get("max_links_per_chunk", 12))
        # Extra names to ignore, merged with the built-in stopword set.
        self.stopword_names = {
            str(name).strip().lower()
            for name in config.get("stopword_names", [])
        } | _STOPWORD_NAMES
        # normalized alias -> concept vertex id
        self._alias_to_id: dict[str, str] = {}
        self._pattern: re.Pattern[str] | None = None
        self._loaded = False

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def load_concepts(self) -> int:
        """Load curated concept vertices and build the mention matcher.

        Returns the number of distinct aliases indexed. Safe to call repeatedly;
        only the first successful call does the work.
        """
        if self._loaded:
            return len(self._alias_to_id)

        list_concepts = getattr(self.graph_store, "list_concept_nodes", None)
        if not callable(list_concepts):
            logger.info(
                "Graph store %s does not expose list_concept_nodes; ontology linking disabled.",
                type(self.graph_store).__name__,
            )
            self._loaded = True
            return 0

        try:
            concepts = list_concepts()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to load ontology concepts for linking: %s", exc)
            self._loaded = True
            return 0

        alias_to_id: dict[str, str] = {}
        for concept in concepts:
            concept_id = str(concept.get("id") or "").strip()
            if not concept_id:
                continue
            for alias in self._concept_aliases(concept):
                # Create variations for each alias to handle different text formats
                variations = TextNormalizer.create_variations(alias)
                for normalized in variations:
                    if not self._is_linkable_alias(normalized):
                        continue
                    # First writer wins so longer, more specific names are not
                    # clobbered by a later generic collision.
                    alias_to_id.setdefault(normalized, concept_id)

        self._alias_to_id = alias_to_id
        self._pattern = self._build_pattern(alias_to_id.keys())
        self._loaded = True
        logger.info("OntologyLinker indexed %d concept aliases for grounding.", len(alias_to_id))
        return len(alias_to_id)

    # ------------------------------------------------------------------
    # Linking
    # ------------------------------------------------------------------

    def link_chunk(self, chunk: RagDocument) -> list[str]:
        """Return the ontology concept ids mentioned in a chunk's text.
        
        Uses robust text normalization to match concepts even when text is
        extracted differently by different parsers.
        """
        if not self._loaded:
            self.load_concepts()
        if not self._pattern:
            return []

        text = TextNormalizer.normalize(chunk.content or "")
        if not text:
            return []

        matched_ids: list[str] = []
        seen: set[str] = set()
        for match in self._pattern.finditer(text):
            concept_id = self._alias_to_id.get(match.group(0))
            if concept_id and concept_id not in seen:
                seen.add(concept_id)
                matched_ids.append(concept_id)
                if len(matched_ids) >= self.max_links_per_chunk:
                    break
        return matched_ids

    def backfill_existing_chunks(self, vector_store: Any, batch_size: int = 500) -> dict[str, int]:
        """Tag already-indexed chunks with ``concept_ids`` metadata.

        Migrates chunks indexed before the ontology-only design: it re-scans chunk
        text from the vector store, computes the mentioned concept ids, and writes
        them back into each chunk's ``metadata['concept_ids']``. Requires the
        vector store to expose ``iter_all_documents`` and ``add_documents``.

        Returns counts: chunks scanned, chunks tagged.
        """
        if not self._loaded:
            self.load_concepts()
        if not self._alias_to_id:
            return {"scanned": 0, "tagged": 0}

        iter_docs = getattr(vector_store, "iter_all_documents", None)
        if not callable(iter_docs):
            raise AttributeError(
                "Vector store does not support iter_all_documents; cannot backfill ontology tags."
            )

        scanned = 0
        tagged = 0
        pending: list[RagDocument] = []
        for chunk in iter_docs(batch_size):
            scanned += 1
            concept_ids = self.link_chunk(chunk)
            if not concept_ids:
                continue
            chunk.metadata = {**(chunk.metadata or {}), "concept_ids": concept_ids}
            pending.append(chunk)
            tagged += 1
            if len(pending) >= batch_size:
                vector_store.add_documents(pending)
                pending = []
        if pending:
            vector_store.add_documents(pending)
        logger.info("OntologyLinker backfill: scanned=%d tagged=%d.", scanned, tagged)
        return {"scanned": scanned, "tagged": tagged}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _concept_aliases(concept: dict[str, Any]) -> list[str]:
        """Collect the candidate surface forms for a concept vertex."""
        aliases: list[str] = []
        name = concept.get("name")
        if name:
            aliases.append(str(name))
        raw_aliases = concept.get("aliases")
        if isinstance(raw_aliases, str):
            aliases.extend(part for part in re.split(r"[|;,]", raw_aliases) if part.strip())
        elif isinstance(raw_aliases, (list, tuple)):
            aliases.extend(str(part) for part in raw_aliases if str(part).strip())
        return aliases

    def _is_linkable_alias(self, normalized: str) -> bool:
        if len(normalized) < self.min_name_len:
            return False
        if normalized in self.stopword_names:
            return False
        return True

    @staticmethod
    def _normalize(value: str) -> str:
        """Normalize text using TextNormalizer.
        
        Kept for backward compatibility and internal use.
        """
        return TextNormalizer.normalize(value)

    @staticmethod
    def _build_pattern(aliases: Any) -> re.Pattern[str] | None:
        # Longest aliases first so "power bi report generator agent" wins over the
        # shorter "report" fragment when both would otherwise match.
        ordered = sorted({a for a in aliases if a}, key=len, reverse=True)
        if not ordered:
            return None
        alternation = "|".join(re.escape(alias) for alias in ordered)
        # \b boundaries keep matches to whole words/phrases.
        return re.compile(rf"\b(?:{alternation})\b")
