"""Session-scoped RAG store lifecycle manager."""

from __future__ import annotations

from typing import Any

from daan.graph_stores.providers.base_graph_store import BaseGraphStore
from daan.graph_stores.graph_store_factory import GraphStoreFactory
from daan.vector_stores.providers.base_vector_store import BaseVectorStore
from daan.vector_stores.vector_store_factory import VectorStoreFactory


class RagSessionManager:
    """Provision and cleanup per-session RAG stores."""

    def __init__(self, rag_config: dict[str, Any]) -> None:
        self.rag_config = rag_config
        self._sessions: dict[str, dict[str, Any]] = {}

    def create_session_store(self, session_id: str) -> dict[str, Any]:
        vector_store: BaseVectorStore = VectorStoreFactory.create_store(
            store_name=self.rag_config.get("vector_store_type", "chroma"),
            config=self.rag_config.get("vector_store_config", {}),
        )
        graph_store: BaseGraphStore = GraphStoreFactory.create_store(
            store_name=self.rag_config.get("graph_store_type", "kuzu"),
            config=self.rag_config.get("graph_store_config", {}),
        )
        self._sessions[session_id] = {
            "vector_store": vector_store,
            "graph_store": graph_store,
        }
        return self._sessions[session_id]

    def get_session_store(self, session_id: str) -> dict[str, Any] | None:
        return self._sessions.get(session_id)

    def destroy_session_store(self, session_id: str) -> None:
        resources = self._sessions.pop(session_id, None)
        if not resources:
            return
        graph_store = resources.get("graph_store")
        if graph_store is not None:
            graph_store.close()
