"""Recursive text chunking strategy."""

from typing import Any

try:
    import tiktoken
    TIKTOKEN_AVAILABLE = True
except ImportError:
    TIKTOKEN_AVAILABLE = False

from daan.vector_stores.document import RagDocument

from .base_chunker import BaseChunker


class RecursiveTextChunker(BaseChunker):
    """Chunk by larger separators first, then fallback to fixed windows."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.chunk_size = int(config.get("chunk_size", 512))
        self.chunk_overlap = int(config.get("chunk_overlap", 64))
        self.separators = config.get("separators", ["\n\n", "\n", ". ", " "])
        self._max_tokenize_chars = 100_000

        # Initialize tokenizer for accurate token counting
        if TIKTOKEN_AVAILABLE:
            try:
                self.tokenizer = tiktoken.get_encoding("cl100k_base")  # GPT-4/GPT-3.5-turbo
            except Exception:
                self.tokenizer = None
        else:
            self.tokenizer = None
    
    def _get_length(self, text: str) -> int:
        """Get the length of text in tokens (or characters as fallback).
        
        Args:
            text: The text to measure
            
        Returns:
            Length in tokens if tiktoken is available, otherwise character count
        """
        if self.tokenizer is not None and len(text) <= self._max_tokenize_chars:
            try:
                return len(self.tokenizer.encode_ordinary(text))
            except Exception:
                pass
        # Fallback to character count with approximate token conversion
        # Average: 1 token ≈ 4 characters for English text
        return len(text) // 4

    def _exceeds_chunk_size(self, text: str) -> bool:
        # A token is never shorter than one character, so this skips most encodes.
        if len(text) <= self.chunk_size:
            return False
        return self._get_length(text) > self.chunk_size

    def chunk(self, doc: RagDocument) -> list[RagDocument]:
        text = (doc.content or "").strip()
        if not text:
            return []

        pieces = [text]
        for separator in self.separators:
            next_pieces: list[str] = []
            for piece in pieces:
                if not self._exceeds_chunk_size(piece):
                    next_pieces.append(piece)
                    continue
                split_parts = [part.strip() for part in piece.split(separator) if part.strip()]
                if split_parts:
                    next_pieces.extend(split_parts)
                else:
                    next_pieces.append(piece)
            pieces = next_pieces

        # A binary or malformed document may contain a large separator-free
        # string. Keep it from reaching the tokenizer or becoming one huge chunk.
        max_piece_chars = max(self.chunk_size * 4, 1)
        bounded_pieces: list[str] = []
        for piece in pieces:
            if len(piece) <= max_piece_chars:
                bounded_pieces.append(piece)
                continue
            bounded_pieces.extend(
                piece[start : start + max_piece_chars]
                for start in range(0, len(piece), max_piece_chars)
            )
        pieces = bounded_pieces

        # Each piece is measured once and lengths are summed; re-encoding the growing
        # accumulator here is quadratic and stalls on large spreadsheet-derived text.
        merged: list[str] = []
        current_parts: list[str] = []
        current_length = 0
        for piece in pieces:
            piece_length = self._get_length(piece)
            added_length = piece_length + (1 if current_parts else 0)
            if current_parts and current_length + added_length > self.chunk_size:
                merged.append(" ".join(current_parts))
                current_parts = [piece]
                current_length = piece_length
                continue
            current_parts.append(piece)
            current_length += added_length
        if current_parts:
            merged.append(" ".join(current_parts))

        chunks: list[RagDocument] = []
        for index, content in enumerate(merged):
            chunks.append(
                RagDocument(
                    id=f"{doc.id}:{index}",
                    content=content,
                    metadata={**doc.metadata, "parent_id": doc.id},
                    source=doc.source,
                    chunk_index=index,
                )
            )
        return chunks
