"""Factory for chunker strategies."""

import importlib
from typing import Any

from .base_chunker import BaseChunker


class ChunkerFactory:
    """Create chunkers using registry + importlib pattern."""

    CHUNKER_MAP = {
        "fixed_size": {
            "module": "daan.rag.chunking.fixed_size_chunker",
            "class": "FixedSizeChunker",
        },
        "recursive_text": {
            "module": "daan.rag.chunking.recursive_text_chunker",
            "class": "RecursiveTextChunker",
        },
        "semantic": {
            "module": "daan.rag.chunking.semantic_chunker",
            "class": "SemanticChunker",
        },
        "sentence": {
            "module": "daan.rag.chunking.sentence_chunker",
            "class": "SentenceChunker",
        },
        "sliding_window": {
            "module": "daan.rag.chunking.sliding_window_chunker",
            "class": "SlidingWindowChunker",
        },
        "hierarchical": {
            "module": "daan.rag.chunking.hierarchical_chunker",
            "class": "HierarchicalChunker",
        },
    }

    @classmethod
    def create_chunker(cls, chunker_type: str, config: dict[str, Any]) -> BaseChunker:
        """Create and return a chunker instance."""
        if chunker_type not in cls.CHUNKER_MAP:
            available = ", ".join(cls.CHUNKER_MAP.keys())
            raise ValueError(f"Unsupported chunker '{chunker_type}'. Available: {available}")

        chunker_info = cls.CHUNKER_MAP[chunker_type]
        module = importlib.import_module(chunker_info["module"])
        chunker_class = getattr(module, chunker_info["class"])
        return chunker_class(config)

    @classmethod
    def get_available_chunkers(cls) -> list[str]:
        """List registered chunkers."""
        return list(cls.CHUNKER_MAP.keys())
