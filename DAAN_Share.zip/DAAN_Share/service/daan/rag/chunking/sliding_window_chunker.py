"""Sliding-window text chunking strategy.

Each window is ``chunk_size`` characters wide. The window advances by
``step_size`` characters on every iteration, producing heavily overlapping
chunks when ``step_size < chunk_size``.  This preserves context at chunk
boundaries better than fixed-size chunking because every sentence (or phrase)
that straddles a boundary appears fully inside at least one window.

Config keys
-----------
chunk_size   : int  (default 512)  – size of each window in characters.
step_size    : int  (default 256)  – how far to advance the window each step.
               Set step_size == chunk_size to get non-overlapping windows
               identical to FixedSizeChunker.
min_chunk_len: int  (default 10)   – discard windows shorter than this (e.g.
               trailing whitespace-only fragments at the end of a document).
"""

from typing import Any

from daan.vector_stores.document import RagDocument

from .base_chunker import BaseChunker


class SlidingWindowChunker(BaseChunker):
    """Chunk text with a sliding window of fixed size and configurable step."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.chunk_size = int(config.get("chunk_size", 512))
        self.step_size = int(config.get("step_size", self.chunk_size // 2))
        self.min_chunk_len = int(config.get("min_chunk_len", 10))

        if self.step_size <= 0:
            raise ValueError("step_size must be a positive integer.")
        if self.chunk_size <= 0:
            raise ValueError("chunk_size must be a positive integer.")

    def chunk(self, doc: RagDocument) -> list[RagDocument]:
        text = (doc.content or "").strip()
        if not text:
            return []

        chunks: list[RagDocument] = []
        index = 0
        start = 0
        text_len = len(text)

        while start < text_len:
            end = min(start + self.chunk_size, text_len)
            window_text = text[start:end].strip()

            if len(window_text) >= self.min_chunk_len:
                chunks.append(
                    RagDocument(
                        id=f"{doc.id}:{index}",
                        content=window_text,
                        metadata={
                            **doc.metadata,
                            "parent_id": doc.id,
                            "window_start": start,
                            "window_end": end,
                        },
                        source=doc.source,
                        chunk_index=index,
                    )
                )
                index += 1

            if end >= text_len:
                break

            start += self.step_size

        return chunks
