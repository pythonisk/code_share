"""Base interface for chunking strategies."""

from abc import ABC, abstractmethod

from daan.vector_stores.document import RagDocument


class BaseChunker(ABC):
    """Contract for turning a document into chunks."""

    @abstractmethod
    def chunk(self, doc: RagDocument) -> list[RagDocument]:
        """Split a document into chunk documents."""
