"""Semantic chunking strategy using embedding-distance breakpoints."""

from __future__ import annotations

import re
from typing import Any

from daan.llm.embeddings.base_embedding_provider import BaseEmbeddingProvider
from daan.vector_stores.document import RagDocument

from .base_chunker import BaseChunker


class SemanticChunker(BaseChunker):
    """Split by sentence and break chunks when semantic drift exceeds threshold."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.chunk_size = int(config.get("chunk_size", 512))
        self.breakpoint_threshold = float(config.get("semantic_breakpoint_threshold", 0.35))
        self.embedding_provider = config.get("embedding_provider")

    def chunk(self, doc: RagDocument) -> list[RagDocument]:
        if not isinstance(self.embedding_provider, BaseEmbeddingProvider):
            raise ValueError("SemanticChunker requires 'embedding_provider' in config")

        sentences = [piece.strip() for piece in re.split(r"(?<=[.!?])\s+", doc.content or "") if piece.strip()]
        if not sentences:
            return []

        sentence_vectors = self.embedding_provider.embed_batch(sentences)

        chunks: list[str] = []
        current = sentences[0]
        current_vec = sentence_vectors[0]

        for index in range(1, len(sentences)):
            sentence = sentences[index]
            vector = sentence_vectors[index]

            similarity = _cosine_similarity(current_vec, vector)
            candidate = f"{current} {sentence}".strip()
            if similarity < self.breakpoint_threshold or len(candidate) > self.chunk_size:
                chunks.append(current)
                current = sentence
                current_vec = vector
            else:
                current = candidate

        if current:
            chunks.append(current)

        return [
            RagDocument(
                id=f"{doc.id}:{index}",
                content=content,
                metadata={**doc.metadata, "parent_id": doc.id},
                source=doc.source,
                chunk_index=index,
            )
            for index, content in enumerate(chunks)
        ]


def _cosine_similarity(vector_a: list[float], vector_b: list[float]) -> float:
    if len(vector_a) != len(vector_b) or not vector_a:
        return 0.0
    dot = sum(a * b for a, b in zip(vector_a, vector_b))
    norm_a = sum(a * a for a in vector_a) ** 0.5
    norm_b = sum(b * b for b in vector_b) ** 0.5
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return dot / (norm_a * norm_b)
