"""Hierarchical text chunking strategy.

Produces chunks at two granularity levels from a single document:

  Level 0 – *parent* chunks: large, semantically coherent segments obtained
             by splitting on ``parent_separators`` (default: double-newlines /
             blank lines, then single newlines).  Each parent chunk represents
             a top-level section or paragraph.

  Level 1 – *child* chunks: each parent is further split into smaller pieces
             using ``child_separators`` (default: sentence-ending punctuation
             then spaces).  Child chunks are sized to fit ``child_chunk_size``
             characters with ``child_chunk_overlap`` overlap.

The relationship between levels is captured in chunk metadata:

  parent chunk → ``metadata["level"] = 0``,
                 ``metadata["parent_id"] = <doc.id>``

  child chunk  → ``metadata["level"] = 1``,
                 ``metadata["parent_id"] = <parent_chunk.id>``,
                 ``metadata["parent_index"] = <index of parent>``

This mirrors the "parent-document retriever" pattern common in LangChain /
LlamaIndex: embed and retrieve *child* chunks for precision, then expand to
the *parent* for full context before passing to the LLM.

Config keys
-----------
parent_chunk_size    : int  (default 1024) – max characters in a parent chunk.
child_chunk_size     : int  (default 256)  – max characters in a child chunk.
child_chunk_overlap  : int  (default 32)   – overlap between child chunks.
parent_separators    : list (default ["\n\n", "\n"]) – split hierarchy for parents.
child_separators     : list (default [". ", "! ", "? ", " "]) – split for children.
include_parents      : bool (default True) – whether to include parent-level
                       chunks in the returned list alongside child chunks.
                       Set False to return only leaf (child) chunks.
"""

from typing import Any

from daan.vector_stores.document import RagDocument

from .base_chunker import BaseChunker


class HierarchicalChunker(BaseChunker):
    """Two-level hierarchical chunker: parent paragraphs → child sentences."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.parent_chunk_size = int(config.get("parent_chunk_size", 1024))
        self.child_chunk_size = int(config.get("child_chunk_size", 256))
        self.child_chunk_overlap = int(config.get("child_chunk_overlap", 32))
        self.parent_separators: list[str] = config.get("parent_separators", ["\n\n", "\n"])
        self.child_separators: list[str] = config.get("child_separators", [". ", "! ", "? ", " "])
        self.include_parents: bool = bool(config.get("include_parents", True))

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def chunk(self, doc: RagDocument) -> list[RagDocument]:
        text = (doc.content or "").strip()
        if not text:
            return []

        parent_texts = self._split_text(text, self.parent_separators, self.parent_chunk_size)
        result: list[RagDocument] = []
        parent_index = 0

        for p_text in parent_texts:
            if not p_text.strip():
                continue

            parent_id = f"{doc.id}:p{parent_index}"
            parent_chunk = RagDocument(
                id=parent_id,
                content=p_text,
                metadata={
                    **doc.metadata,
                    "parent_id": doc.id,
                    "level": 0,
                    "chunk_type": "parent",
                },
                source=doc.source,
                chunk_index=parent_index,
            )

            if self.include_parents:
                result.append(parent_chunk)

            child_texts = self._split_with_overlap(
                p_text,
                self.child_separators,
                self.child_chunk_size,
                self.child_chunk_overlap,
            )

            for child_index, c_text in enumerate(child_texts):
                if not c_text.strip():
                    continue
                result.append(
                    RagDocument(
                        id=f"{parent_id}:c{child_index}",
                        content=c_text,
                        metadata={
                            **doc.metadata,
                            "parent_id": parent_id,
                            "root_id": doc.id,
                            "level": 1,
                            "chunk_type": "child",
                            "parent_index": parent_index,
                        },
                        source=doc.source,
                        chunk_index=child_index,
                    )
                )

            parent_index += 1

        return result

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _split_text(self, text: str, separators: list[str], max_size: int) -> list[str]:
        """Recursively split *text* using *separators* until pieces fit *max_size*."""
        pieces = [text]
        for sep in separators:
            next_pieces: list[str] = []
            for piece in pieces:
                if len(piece) <= max_size:
                    next_pieces.append(piece)
                    continue
                parts = [p.strip() for p in piece.split(sep) if p.strip()]
                next_pieces.extend(parts if parts else [piece])
            pieces = next_pieces

        # Merge short pieces back up to max_size to avoid tiny slivers.
        merged: list[str] = []
        current = ""
        for piece in pieces:
            candidate = f"{current} {piece}".strip() if current else piece
            if len(candidate) <= max_size:
                current = candidate
            else:
                if current:
                    merged.append(current)
                current = piece
        if current:
            merged.append(current)

        return merged

    def _split_with_overlap(
        self, text: str, separators: list[str], size: int, overlap: int
    ) -> list[str]:
        """Split *text* into chunks of *size* chars with *overlap* character overlap."""
        pieces = self._split_text(text, separators, size)

        # Re-join and re-window with overlap so children respect the overlap setting.
        chunks: list[str] = []
        start = 0
        step = max(1, size - overlap)

        # If pieces already fit the size budget use them directly (fast path).
        if all(len(p) <= size for p in pieces):
            # Apply sliding window over the pieces list to honour overlap.
            current = ""
            for piece in pieces:
                candidate = f"{current} {piece}".strip() if current else piece
                if len(candidate) <= size:
                    current = candidate
                else:
                    if current:
                        chunks.append(current)
                    # Carry the overlap portion of current into the next window.
                    overlap_text = current[-overlap:].strip() if overlap and current else ""
                    current = f"{overlap_text} {piece}".strip() if overlap_text else piece
            if current:
                chunks.append(current)
            return chunks

        # Fallback: character-level sliding window.
        flat = text
        text_len = len(flat)
        while start < text_len:
            end = min(start + size, text_len)
            chunks.append(flat[start:end].strip())
            if end >= text_len:
                break
            start += step

        return [c for c in chunks if c]
