"""Fixed-size text chunking strategy."""

from typing import Any

from daan.vector_stores.document import RagDocument

from .base_chunker import BaseChunker


class FixedSizeChunker(BaseChunker):
    """Split content by fixed character windows and overlap."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.chunk_size = int(config.get("chunk_size", 512))
        self.chunk_overlap = int(config.get("chunk_overlap", 64))

    def chunk(self, doc: RagDocument) -> list[RagDocument]:
        text = doc.content or ""
        if not text:
            return []

        chunks: list[RagDocument] = []
        start = 0
        index = 0
        while start < len(text):
            end = min(start + self.chunk_size, len(text))
            chunk_text = text[start:end].strip()
            if chunk_text:
                chunks.append(
                    RagDocument(
                        id=f"{doc.id}:{index}",
                        content=chunk_text,
                        metadata={**doc.metadata, "parent_id": doc.id},
                        source=doc.source,
                        chunk_index=index,
                    )
                )
                index += 1
            if end >= len(text):
                break
            start = max(0, end - self.chunk_overlap)
        return chunks
