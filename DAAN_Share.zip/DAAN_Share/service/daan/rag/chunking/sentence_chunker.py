"""Sentence-aware chunking strategy."""

import re
from typing import Any

from daan.vector_stores.document import RagDocument

from .base_chunker import BaseChunker


class SentenceChunker(BaseChunker):
    """Split document by sentence boundaries and pack to chunk size."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.chunk_size = int(config.get("chunk_size", 512))

    def chunk(self, doc: RagDocument) -> list[RagDocument]:
        sentences = [piece.strip() for piece in re.split(r"(?<=[.!?])\s+", doc.content or "") if piece.strip()]
        if not sentences:
            return []

        chunks: list[RagDocument] = []
        current: list[str] = []
        current_len = 0
        chunk_index = 0

        for sentence in sentences:
            sentence_len = len(sentence)
            if current and current_len + sentence_len > self.chunk_size:
                chunks.append(
                    RagDocument(
                        id=f"{doc.id}:{chunk_index}",
                        content=" ".join(current),
                        metadata={**doc.metadata, "parent_id": doc.id},
                        source=doc.source,
                        chunk_index=chunk_index,
                    )
                )
                chunk_index += 1
                current = []
                current_len = 0

            current.append(sentence)
            current_len += sentence_len

        if current:
            chunks.append(
                RagDocument(
                    id=f"{doc.id}:{chunk_index}",
                    content=" ".join(current),
                    metadata={**doc.metadata, "parent_id": doc.id},
                    source=doc.source,
                    chunk_index=chunk_index,
                )
            )

        return chunks
