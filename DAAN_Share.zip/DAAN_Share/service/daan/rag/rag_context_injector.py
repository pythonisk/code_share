﻿"""Context injector that enriches agent prompt with retrieved RAG context."""

from __future__ import annotations

import hashlib
from typing import Any

from daan.rag.retrieval.retriever_factory import RetrieverFactory


class RagContextInjector:
    """Resolve retriever and append retrieved context to system prompt."""

    def __init__(self, base_retriever_config: dict[str, Any]) -> None:
        self.base_retriever_config = base_retriever_config

    def inject(
        self,
        system_prompt: str,
        query: str,
        rag_config: dict[str, Any],
    ) -> str:
        retriever_type = rag_config.get("retriever_type", "graph_rag")
        top_k = int(rag_config.get("top_k", 5))
        query_link = rag_config.get("query_link") or self._query_link(query)

        retriever_config = dict(self.base_retriever_config)
        retriever_config["query_link_key"] = query_link

        retriever = RetrieverFactory.create_retriever(
            retriever_type=retriever_type,
            config=retriever_config,
        )
        docs = retriever.retrieve(query=query, k=top_k)
        context = "\n\n".join([doc.content for doc in docs if doc.content])
        if not context:
            return system_prompt

        return (
            f"{system_prompt}\n\n"
            f"[RAG QUERY LINK: {query_link}]\n"
            "[RAG CONTEXT]\n"
            f"{context}\n"
            "[/RAG CONTEXT]"
        )

    @staticmethod
    def _query_link(query: str) -> str:
        return hashlib.sha1(query.strip().lower().encode("utf-8")).hexdigest()[:16]
