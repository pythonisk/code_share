"""RAG-specific adapter over documentloaders registry outputs."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from daan.utils.documentloaders import load_document as registry_load_document


class RagDocumentLoaderAdapter:
    """Normalize documentloader payloads into partitioner-friendly text payloads."""

    def load_payload(
        self,
        file_path: str,
        source_type: str = "upload",
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        resolved_config = config or {}
        loader_type = self._resolve_loader_type(source_type=source_type, config=resolved_config)
        loader_config = self._resolve_loader_config(loader_type=loader_type, config=resolved_config)

        payload = registry_load_document(
            file_path=file_path,
            loader_type=loader_type,
            config=loader_config,
        )

        normalized_content = self._normalize_content(payload.get("content"))
        normalized_payload = {
            **payload,
            "filename": payload.get("filename") or (Path(file_path).name if file_path else "sharepoint"),
            "file_type": payload.get("file_type") or self._fallback_file_type(file_path=file_path, loader_type=loader_type),
            "file_path": payload.get("file_path") or file_path,
            "content": normalized_content,
        }

        metadata = dict(normalized_payload.get("metadata") or {})
        metadata["ingestion_path"] = "document_loader"
        normalized_payload["metadata"] = metadata
        return normalized_payload

    def load_payload_batches(
        self,
        file_path: str,
        source_type: str,
        config: dict[str, Any] | None = None,
    ):
        resolved_config = config or {}
        loader_type = self._resolve_loader_type(source_type=source_type, config=resolved_config)
        if loader_type != "sharepoint":
            yield self.load_payload(file_path=file_path, source_type=source_type, config=resolved_config)
            return

        loader_config = self._resolve_loader_config(loader_type=loader_type, config=resolved_config)
        if resolved_config.get("skip_sources"):
            loader_config["skip_sources"] = resolved_config["skip_sources"]
        from daan.utils.documentloaders.sharepoint_loader import SharePointDocumentLoader

        batch_size = int(resolved_config.get("sharepoint_batch_size", 25) or 25)
        loader = SharePointDocumentLoader(config=loader_config)
        for payload in loader.iter_document_batches(file_path=file_path, batch_size=batch_size):
            yield self._normalize_payload(payload, file_path=file_path, loader_type=loader_type)

    def _normalize_payload(self, payload: dict[str, Any], file_path: str, loader_type: str | None) -> dict[str, Any]:
        normalized_content = self._normalize_content(payload.get("content"))
        normalized_payload = {
            **payload,
            "filename": payload.get("filename") or (Path(file_path).name or "sharepoint"),
            "file_type": payload.get("file_type") or self._fallback_file_type(file_path=file_path, loader_type=loader_type),
            "file_path": payload.get("file_path") or file_path,
            "content": normalized_content,
        }
        metadata = dict(normalized_payload.get("metadata") or {})
        metadata["ingestion_path"] = "document_loader"
        normalized_payload["metadata"] = metadata
        return normalized_payload

    @staticmethod
    def _resolve_loader_type(source_type: str, config: dict[str, Any]) -> str | None:
        configured = str(config.get("loader_type") or "").strip()
        if configured:
            return configured
        source_map = config.get("source_type_loader_map") or {}
        if isinstance(source_map, dict):
            mapped = source_map.get(str(source_type).strip().lower())
            if mapped:
                return str(mapped).strip() or None
        return None

    @staticmethod
    def _resolve_loader_config(loader_type: str | None, config: dict[str, Any]) -> dict[str, Any]:
        default_config = dict(config.get("default_loader_config") or {})
        per_loader = dict(config.get("loader_config") or {})
        resolved = dict(default_config)

        if loader_type and isinstance(per_loader.get(loader_type), dict):
            resolved.update(per_loader[loader_type])

        sharepoint_loader_name = str(config.get("sharepoint_loader_name") or "sharepoint").strip().lower()
        if loader_type and loader_type.lower() == sharepoint_loader_name:
            sharepoint_loader_kwargs = dict(config.get("sharepoint_loader_kwargs") or {})
            if sharepoint_loader_kwargs:
                existing_loader_kwargs = dict(resolved.get("loader_kwargs") or {})
                resolved["loader_kwargs"] = {**existing_loader_kwargs, **sharepoint_loader_kwargs}

        return resolved

    @classmethod
    def _normalize_content(cls, content: Any) -> dict[str, Any]:
        content_dict = content if isinstance(content, dict) else {"type": "unknown", "content": str(content or "")}
        raw_type = str(content_dict.get("type") or "unknown")
        text = cls._extract_text(content_dict)

        return {
            "type": "text_file",
            "content": text,
            "structured_sections": {},
            "summary": {
                "normalized_from": raw_type,
                "total_characters": len(text),
            },
            "original_content": content_dict,
        }

    @classmethod
    def _extract_text(cls, content: dict[str, Any]) -> str:
        content_type = str(content.get("type") or "").strip().lower()

        if content_type == "pdf_file":
            pages = content.get("pages") or []
            return "\n".join(str(page.get("text") or "") for page in pages if isinstance(page, dict) and page.get("text"))

        if content_type == "csv_file":
            rows = content.get("rows") or []
            return "\n".join(str(row.get("content") or "") for row in rows if isinstance(row, dict) and row.get("content"))

        if content_type == "excel_workbook":
            return cls._extract_excel_text(content)

        if content_type == "json_file":
            data = content.get("data")
            try:
                return json.dumps(data, ensure_ascii=True, default=str)
            except TypeError:
                return str(data)

        if content_type == "sharepoint_documents":
            documents = content.get("documents") or []
            return "\n\n".join(
                str(document.get("content") or "")
                for document in documents
                if isinstance(document, dict) and document.get("content")
            )

        return str(content.get("content") or "")

    @staticmethod
    def _extract_excel_text(content: dict[str, Any]) -> str:
        sheets = content.get("sheets") or {}
        segments: list[str] = []

        if isinstance(sheets, dict):
            for sheet_name, sheet_data in sheets.items():
                segments.append(f"Sheet: {sheet_name}")
                tables = sheet_data.get("tables") if isinstance(sheet_data, dict) else []
                for table in tables or []:
                    rows = table.get("rows") if isinstance(table, dict) else []
                    for row in rows or []:
                        if isinstance(row, dict):
                            row_text = row.get("content")
                            if row_text:
                                segments.append(str(row_text))

        return "\n".join(segment for segment in segments if segment)

    @staticmethod
    def _fallback_file_type(file_path: str, loader_type: str | None) -> str:
        suffix = Path(file_path).suffix.lower() if file_path else ""
        return suffix or (str(loader_type or "").strip().lower())
