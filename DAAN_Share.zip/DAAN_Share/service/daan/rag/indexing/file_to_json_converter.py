"""Adapter over DAAN's shared FileToJsonConverter utility."""

from daan.utils.file_to_json import FileToJsonConverter as CoreFileToJsonConverter


class FileToJsonConverter:
    """Convert files using the shared DAAN converter stack."""

    def __init__(self) -> None:
        self._core_converter = CoreFileToJsonConverter()

    def convert_file(self, file_path: str) -> dict:
        return self._core_converter.convert_file_to_json(file_path)
