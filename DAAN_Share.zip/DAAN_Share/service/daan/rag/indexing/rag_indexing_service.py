﻿"""RAG indexing orchestration service."""

from __future__ import annotations

import hashlib
import json
import logging
import time
from pathlib import Path
from typing import Any

from daan.graph_stores.providers.base_graph_store import BaseGraphStore
from daan.llm.embeddings.base_embedding_provider import BaseEmbeddingProvider
from daan.rag.chunking.base_chunker import BaseChunker
from daan.rag.graph.ontology_linker import OntologyLinker
from daan.vector_stores.providers.base_vector_store import BaseVectorStore
from daan.vector_stores.document import RagDocument

from .file_partitioner import FilePartitioner
from .file_to_json_converter import FileToJsonConverter
from .rag_document_loader import RagDocumentLoaderAdapter

logger = logging.getLogger(__name__)
class RagIndexingService:
    """Coordinates convert -> partition -> chunk -> embed -> store pipeline."""

    def __init__(self) -> None:
        self.converter = FileToJsonConverter()
        self.partitioner = FilePartitioner()
        self.document_loader_adapter = RagDocumentLoaderAdapter()


    async def index_documents(
        self,
        session_id: str,
        files: list[str],
        vector_store: BaseVectorStore,
        graph_store: BaseGraphStore,
        embedding_provider: BaseEmbeddingProvider,
        chunker: BaseChunker,
        query: str | None = None,
        query_link: str | None = None,
        source_type: str = "upload",
        use_document_loaders: bool = False,
        document_loader_config: dict[str, Any] | None = None,
        link_ontology: bool = False,
        ontology_link_config: dict[str, Any] | None = None,
        extra_metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Index a list of files into vector and graph stores."""
        all_chunks: list[RagDocument] = []
        indexed_count = 0
        processed_files = 0
        resolved_query_link = self._resolve_query_link(query=query, query_link=query_link)
        resolved_loader_config = document_loader_config or {}
        fallback_to_converter = bool(resolved_loader_config.get("fallback_to_converter", True))

        # Ground chunks into the curated ontology so graph traversal can hop
        # chunk -> concept -> chunk. Loaded once up front; disabled gracefully if
        # the graph store exposes no curated concepts.
        ontology_linker: OntologyLinker | None = None
        ontology_link_count = 0
        if link_ontology and graph_store is not None:
            ontology_linker = OntologyLinker(graph_store, ontology_link_config)
            if ontology_linker.load_concepts() == 0:
                ontology_linker = None

        resolved_extra_metadata = extra_metadata or {}
        # Buffer chunks across payloads so embedding stays batched even when each
        # source file is emitted as its own payload.
        embed_buffer: list[RagDocument] = []
        embed_buffer_size = max(1, int(resolved_loader_config.get("embed_buffer_size", 64) or 64))

        def flush_embed_buffer() -> None:
            nonlocal indexed_count, ontology_link_count
            if not embed_buffer:
                return
            embeddings = self._embed_with_retry(embedding_provider, [c.content for c in embed_buffer])
            for chunk, embedding in zip(embed_buffer, embeddings):
                chunk.embedding = embedding
                metadata = self._sanitize_scalar_mapping(
                    {
                        **resolved_extra_metadata,
                        **(chunk.metadata or {}),
                        "chunk_index": chunk.chunk_index,
                        "source": chunk.source,
                        "source_type": source_type,
                        "query_link": resolved_query_link,
                        "query": query,
                    }
                )
                if ontology_linker is not None:
                    concept_ids = ontology_linker.link_chunk(chunk)
                    if concept_ids:
                        metadata["concept_ids"] = concept_ids
                        ontology_link_count += len(concept_ids)
                chunk.metadata = metadata

            vector_store.add_documents(embed_buffer)
            all_chunks.extend(embed_buffer)
            indexed_count += len(embed_buffer)
            embed_buffer.clear()

        for file_path in files:
            if source_type == "sharepoint" and use_document_loaders:
                batch_loader_config = dict(resolved_loader_config)
                skip_sources = self._existing_sources(vector_store, source_type)
                if skip_sources:
                    batch_loader_config["skip_sources"] = skip_sources
                    logger.info(
                        "Resuming SharePoint ingestion: skipping %d already-indexed files",
                        len(skip_sources),
                    )
                payloads = (
                    (str(payload.get("file_path") or file_path), payload)
                    for payload in self.document_loader_adapter.load_payload_batches(
                        file_path=file_path,
                        source_type=source_type,
                        config=batch_loader_config,
                    )
                )
            else:
                payloads = iter(
                    [
                        (
                            file_path,
                            self._load_payload(
                                file_path=file_path,
                                source_type=source_type,
                                use_document_loaders=use_document_loaders,
                                document_loader_config=resolved_loader_config,
                                fallback_to_converter=fallback_to_converter,
                            ),
                        )
                    ]
                )

            for payload_file_path, payload in payloads:
                processed_files += int(
                    ((payload.get("content") or {}).get("original_content") or {}).get("summary", {}).get("total_documents", 1)
                    or 1
                )
                parts = self.partitioner.partition(payload_file_path, payload)

                # Collect all pre-chunk docs for this file in one pass so we can
                # embed every chunk in a single batched API call instead of one call
                # per partition (avoids N serial round-trips to the embedding service).
                pre_chunks: list[RagDocument] = []
                for part_index, part in enumerate(parts):
                    part_text = self._partition_to_text(part)
                    if not part_text.strip():
                        continue

                    source = str(getattr(part, "file_path", None) or payload.get("file_path") or payload_file_path)
                    if resolved_extra_metadata.get("source"):
                        source = str(resolved_extra_metadata["source"])
                    payload_id = payload.get("filename") or Path(payload_file_path).stem
                    doc = RagDocument(
                        id=f"{payload_id}:{part_index}",
                        content=part_text,
                        metadata=self._sanitize_scalar_mapping(
                            {
                                **resolved_extra_metadata,
                                "session_id": session_id,
                                "source": source,
                                "source_type": source_type,
                                "query_link": resolved_query_link,
                                "query": query,
                                "partition_id": getattr(part, "partition_id", str(part_index)),
                                "loader": (payload.get("metadata") or {}).get("loader"),
                                "ingestion_path": (payload.get("metadata") or {}).get("ingestion_path"),
                            }
                        ),
                        source=source,
                        chunk_index=0,
                    )
                    chunks = chunker.chunk(doc)
                    pre_chunks.extend(chunks)

                if not pre_chunks:
                    continue

                embed_buffer.extend(pre_chunks)
                if len(embed_buffer) >= embed_buffer_size:
                    flush_embed_buffer()
                    logger.info(
                        "RAG indexing progress: source_type=%s files_processed=%d chunks_indexed=%d",
                        source_type,
                        processed_files,
                        indexed_count,
                    )

        flush_embed_buffer()
        logger.info(
            "RAG indexing complete: source_type=%s files_processed=%d chunks_indexed=%d",
            source_type,
            processed_files,
            indexed_count,
        )

        return {
            "session_id": session_id,
            "files_indexed": processed_files,
            "chunks_indexed": indexed_count,
            "query_link": resolved_query_link,
            "chunk_ids": [chunk.id for chunk in all_chunks],
            "ontology_links": ontology_link_count,
        }

    async def index_knowledge_base(
        self,
        kb_id: str,
        source_dir: str,
        config: dict[str, Any],
        query: str | None = None,
        query_link: str | None = None,
    ) -> dict[str, Any]:
        """Index all files from a knowledge-base source directory."""
        files = [
            str(path)
            for path in Path(source_dir).glob("**/*")
            if path.is_file() and path.suffix.lower() in {".txt", ".md"}
        ]

        vector_store: BaseVectorStore = config["vector_store"]
        graph_store: BaseGraphStore = config["graph_store"]
        embedding_provider: BaseEmbeddingProvider = config["embedding_provider"]
        chunker: BaseChunker = config["chunker"]

        result = await self.index_documents(
            session_id=kb_id,
            files=files,
            vector_store=vector_store,
            graph_store=graph_store,
            embedding_provider=embedding_provider,
            chunker=chunker,
            query=query,
            query_link=query_link,
            link_ontology=bool(config.get("link_ontology", False)),
            ontology_link_config=config.get("ontology_link_config"),
        )
        result["kb_id"] = kb_id
        return result

    @staticmethod
    def _existing_sources(vector_store: BaseVectorStore, source_type: str) -> set[str]:
        """Sources already present in the collection; empty when the store cannot report them."""
        list_sources = getattr(vector_store, "list_sources", None)
        if not callable(list_sources):
            return set()
        try:
            return set(list_sources(source_type) or set())
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not read existing sources for resume; reprocessing all files: %s", exc)
            return set()

    @staticmethod
    def _is_rate_limit_error(exc: Exception) -> bool:
        # Match by name/message rather than importing litellm/openai exception types directly.
        haystack = f"{type(exc).__name__} {exc}".lower()
        return "ratelimit" in haystack or "429" in haystack or "too many requests" in haystack

    @classmethod
    def _embed_with_retry(
        cls,
        embedding_provider: BaseEmbeddingProvider,
        texts: list[str],
        max_retries: int = 5,
        base_delay_seconds: int = 30,
    ) -> list[list[float]]:
        """Retry embed_batch with backoff on rate-limit errors so one 429 doesn't abort the whole run."""
        attempt = 0
        while True:
            try:
                return embedding_provider.embed_batch(texts)
            except Exception as exc:  # noqa: BLE001
                attempt += 1
                if attempt > max_retries or not cls._is_rate_limit_error(exc):
                    raise
                delay = base_delay_seconds * attempt
                logger.warning(
                    "Embedding rate-limited (attempt %d/%d): %s. Retrying in %ds.",
                    attempt, max_retries, exc, delay,
                )
                time.sleep(delay)

    @staticmethod
    def _resolve_query_link(query: str | None, query_link: str | None) -> str:
        if query_link:
            return query_link
        if not query:
            return "global"
        return hashlib.sha1(query.strip().lower().encode("utf-8")).hexdigest()[:16]

    @staticmethod
    def _partition_to_text(part: Any) -> str:
        """Convert partition payloads from shared partitioners into normalized text."""
        content = getattr(part, "content", part)
        if isinstance(content, str):
            return content
        if isinstance(content, (dict, list)):
            return json.dumps(content, ensure_ascii=True, default=str)
        return str(content or "")

    def _load_payload(
        self,
        file_path: str,
        source_type: str,
        use_document_loaders: bool,
        document_loader_config: dict[str, Any],
        fallback_to_converter: bool,
    ) -> dict[str, Any]:
        if not use_document_loaders:
            return self.converter.convert_file(file_path)

        try:
            return self.document_loader_adapter.load_payload(
                file_path=file_path,
                source_type=source_type,
                config=document_loader_config,
            )
        except Exception as exc:
            if not fallback_to_converter:
                raise
            logger.warning(
                "Document loader path failed for '%s'; falling back to converter. Error: %s",
                file_path,
                exc,
            )
            return self.converter.convert_file(file_path)

    @staticmethod
    def _sanitize_scalar_mapping(values: dict[str, Any]) -> dict[str, str | int | float | bool]:
        """Drop None values and coerce unsupported metadata types into strings."""
        sanitized: dict[str, str | int | float | bool] = {}
        for key, value in values.items():
            if value is None:
                continue
            if isinstance(value, (str, int, float, bool)):
                sanitized[key] = value
            else:
                sanitized[key] = str(value)
        return sanitized
