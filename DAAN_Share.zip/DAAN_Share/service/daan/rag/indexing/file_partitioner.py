"""Adapter over DAAN's shared FilePartitioner utility."""

from daan.utils.file_partitioner import FilePartitioner as CoreFilePartitioner


class FilePartitioner:
    """Partition converted payloads using DAAN's partitioning framework."""

    def __init__(self) -> None:
        self._core_partitioner = CoreFilePartitioner()

    def partition(self, file_path: str, payload: dict) -> list:
        return self._core_partitioner.partition_file(file_path, payload)
