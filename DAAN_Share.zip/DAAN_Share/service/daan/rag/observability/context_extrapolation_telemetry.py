from __future__ import annotations

import threading
from collections import Counter, deque
from typing import Any


class ContextExtrapolationTelemetry:
    """In-process telemetry collector for ContextExtrapolationAgent runtime health."""

    def __init__(self, max_samples: int = 2048) -> None:
        self._lock = threading.Lock()
        self._max_samples = max(128, int(max_samples))
        self._counters: Counter[str] = Counter()
        self._latencies_ms: deque[float] = deque(maxlen=self._max_samples)
        self._confidences: deque[float] = deque(maxlen=self._max_samples)
        self._intent_counts: Counter[str] = Counter()
        self._technology_counts: Counter[str] = Counter()

    def record_request(self) -> None:
        self._increment("context_extrapolation_requests_total")

    def record_accepted(self) -> None:
        self._increment("context_extrapolation_accepted_total")

    def record_fallback(self) -> None:
        self._increment("context_extrapolation_fallback_total")

    def record_error(self) -> None:
        self._increment("context_extrapolation_errors_total")

    def record_latency(self, latency_ms: float) -> None:
        with self._lock:
            self._latencies_ms.append(float(latency_ms))

    def record_confidence(self, confidence: float) -> None:
        with self._lock:
            self._confidences.append(float(confidence))

    def record_intent(self, intent: str) -> None:
        key = str(intent or "").strip()
        if not key:
            return
        with self._lock:
            self._intent_counts[key] += 1

    def record_technologies(self, technologies: list[str]) -> None:
        with self._lock:
            for technology in technologies:
                key = str(technology or "").strip()
                if key:
                    self._technology_counts[key] += 1

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            latencies = sorted(self._latencies_ms)
            confidences = list(self._confidences)
            counters = dict(self._counters)
            intents = dict(self._intent_counts)
            technologies = dict(self._technology_counts)

        return {
            **counters,
            "context_extrapolation_latency_ms": {
                "count": len(latencies),
                "p50": self._percentile(latencies, 0.50),
                "p95": self._percentile(latencies, 0.95),
                "p99": self._percentile(latencies, 0.99),
            },
            "context_extrapolation_confidence_avg": (
                sum(confidences) / len(confidences) if confidences else 0.0
            ),
            "context_extrapolation_intent_distribution": intents,
            "context_extrapolation_technology_distribution": technologies,
        }

    def reset(self) -> None:
        with self._lock:
            self._counters.clear()
            self._latencies_ms.clear()
            self._confidences.clear()
            self._intent_counts.clear()
            self._technology_counts.clear()

    def _increment(self, name: str) -> None:
        with self._lock:
            self._counters[name] += 1

    @staticmethod
    def _percentile(values: list[float], ratio: float) -> float:
        if not values:
            return 0.0
        index = int(round((len(values) - 1) * ratio))
        index = max(0, min(len(values) - 1, index))
        return float(values[index])


_TELEMETRY = ContextExtrapolationTelemetry()


def get_context_extrapolation_telemetry() -> ContextExtrapolationTelemetry:
    return _TELEMETRY
