"""RAG trace capture utilities."""

from __future__ import annotations

import hashlib
import json
import re
import threading
from uuid import uuid4
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from daan.models.context_extrapolation_models import ContextExtrapolationResult
from daan.models.evidence_models import (
    EvidenceEnvelope,
    EvidenceSource,
    compact_evidence_mapping,
)


class RagTrace(BaseModel):
    """Trace payload for retrieval and reranking."""

    model_config = ConfigDict(extra="forbid")

    trace_id: str = Field(default_factory=lambda: uuid4().hex)
    session_id: str
    owner_user_id: int | None = None
    origin_session_id: str | None = None
    evidence: EvidenceEnvelope | None = None
    query: str = ""
    query_link: str = ""
    retrieved_docs: list[str] = Field(default_factory=list)
    reranked_docs: list[str] = Field(default_factory=list)
    final_context: str = ""
    retriever_type: str = ""
    latency_ms: int = 0
    seed_chunk_ids: list[str] = Field(default_factory=list)
    traversal_hops: list[dict[str, Any]] = Field(default_factory=list)
    visited_node_ids: list[str] = Field(default_factory=list)
    edge_list: list[dict[str, Any]] = Field(default_factory=list)
    final_selected_chunk_ids: list[str] = Field(default_factory=list)
    explainability: dict[str, Any] = Field(default_factory=dict)
    branches: list[dict[str, Any]] = Field(default_factory=list)
    graph_summary: dict[str, Any] = Field(default_factory=dict)
    timing_breakdown: dict[str, int] = Field(default_factory=dict)
    query_normalization: dict[str, Any] = Field(default_factory=dict)
    graph_nodes: list[dict[str, Any]] = Field(default_factory=list)
    graph_edges: list[dict[str, Any]] = Field(default_factory=list)
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


def _normalize_string(value: Any) -> str:
    return str(value or "").strip()


def _coerce_int(value: Any) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _coerce_float(value: Any) -> float:
    try:
        return float(value or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _refresh_graph_fields_from_branches(trace: dict[str, Any]) -> dict[str, Any]:
    payload = dict(trace or {})
    branches = [branch for branch in (payload.get("branches") or []) if isinstance(branch, dict)]
    if not branches:
        return payload

    explainability = dict(payload.get("explainability") or {})
    selected_ids = {
        _normalize_string(item)
        for item in (payload.get("final_selected_chunk_ids") or explainability.get("final_selected_chunk_ids") or [])
        if _normalize_string(item)
    }
    if not selected_ids:
        selected_ids = {
            _normalize_string(item.get("id"))
            for item in (explainability.get("selected_references") or [])
            if isinstance(item, dict) and _normalize_string(item.get("id"))
        }

    visited_node_ids: list[str] = []
    traversal_hops: list[dict[str, Any]] = []
    seed_chunk_ids: set[str] = set()
    expanded_chunk_ids: set[str] = set()
    graph_only_chunk_ids: set[str] = set()
    candidate_chunk_ids: set[str] = set()

    for branch in branches:
        visited_node_ids.extend(_normalize_string(item) for item in (branch.get("visited_node_ids") or []) if _normalize_string(item))
        traversal_hops.extend(item for item in (branch.get("traversal_hops") or []) if isinstance(item, dict))
        seed_chunk_ids.update(_normalize_string(item) for item in (branch.get("seed_chunk_ids") or []) if _normalize_string(item))
        expanded_chunk_ids.update(_normalize_string(item) for item in (branch.get("expanded_chunk_ids") or []) if _normalize_string(item))
        graph_only_chunk_ids.update(_normalize_string(item) for item in (branch.get("graph_only_chunk_ids") or []) if _normalize_string(item))
        candidate_chunk_ids.update(_normalize_string(item) for item in (branch.get("candidate_chunk_ids") or []) if _normalize_string(item))

    deduped_visited_node_ids = list(dict.fromkeys(visited_node_ids))
    existing_seed_chunk_ids = [
        _normalize_string(item)
        for item in (payload.get("seed_chunk_ids") or [])
        if _normalize_string(item)
    ]
    deduped_seed_chunk_ids = list(dict.fromkeys([*existing_seed_chunk_ids, *seed_chunk_ids]))
    recomputed_summary = {
        "visited_nodes": len(set(deduped_visited_node_ids)),
        "expanded_chunks": len(expanded_chunk_ids),
        "graph_only_candidates": len(graph_only_chunk_ids),
        "graph_selected_chunks": len(graph_only_chunk_ids & selected_ids),
        "graph_contribution_rate": round(len(graph_only_chunk_ids & selected_ids) / max(1, len(selected_ids)), 4),
        "non_seed_survival_rate": round(len({chunk_id for chunk_id in selected_ids if chunk_id not in seed_chunk_ids}) / max(1, len(selected_ids)), 4),
    }

    existing_summary = dict(payload.get("graph_summary", {}) or {})
    if recomputed_summary["visited_nodes"] > _coerce_int(existing_summary.get("visited_nodes")):
        graph_summary = recomputed_summary
    else:
        graph_summary = {**recomputed_summary, **existing_summary}

    payload["visited_node_ids"] = deduped_visited_node_ids
    payload["traversal_hops"] = traversal_hops
    payload["seed_chunk_ids"] = deduped_seed_chunk_ids
    payload["graph_summary"] = graph_summary

    existing_explainability_visited_node_ids = [
        _normalize_string(item)
        for item in (explainability.get("visited_node_ids") or [])
        if _normalize_string(item)
    ]
    explainability["visited_node_ids"] = list(
        dict.fromkeys([*existing_explainability_visited_node_ids, *deduped_visited_node_ids])
    )
    explainability["traversal_hops"] = list(explainability.get("traversal_hops") or []) or traversal_hops
    existing_explainability_seed_chunk_ids = [
        _normalize_string(item)
        for item in (explainability.get("seed_chunk_ids") or [])
        if _normalize_string(item)
    ]
    explainability["seed_chunk_ids"] = list(
        dict.fromkeys([*existing_explainability_seed_chunk_ids, *deduped_seed_chunk_ids])
    )
    if not explainability.get("candidate_chunk_ids") and candidate_chunk_ids:
        explainability["candidate_chunk_ids"] = list(candidate_chunk_ids)
    explainability["graph_contribution"] = graph_summary
    payload["explainability"] = explainability
    return payload


def _build_evidence_sources(
    selected_references: list[dict[str, Any]] | None,
    selected_source_ids: list[str] | None,
) -> list[EvidenceSource]:
    sources: list[EvidenceSource] = []
    seen_ids: set[str] = set()

    for entry in selected_references or []:
        if not isinstance(entry, dict):
            continue
        source_id = _normalize_string(entry.get("id"))
        if not source_id or source_id in seen_ids:
            continue
        locator = _normalize_string(entry.get("source")) or None
        label = Path(locator).name if locator else source_id
        metadata = compact_evidence_mapping(
            {
                "chunk_index": entry.get("chunk_index") if isinstance(entry.get("chunk_index"), int) else None,
                "score": entry.get("score") if isinstance(entry.get("score"), (int, float)) else None,
            }
        )
        sources.append(
            EvidenceSource(
                id=source_id,
                kind="chunk",
                label=label,
                locator=locator,
                snippet=_normalize_string(entry.get("snippet")) or None,
                metadata=metadata,
            )
        )
        seen_ids.add(source_id)

    for source_id in selected_source_ids or []:
        normalized_source_id = _normalize_string(source_id)
        if not normalized_source_id or normalized_source_id in seen_ids:
            continue
        sources.append(
            EvidenceSource(
                id=normalized_source_id,
                kind="chunk",
                label=normalized_source_id,
            )
        )
        seen_ids.add(normalized_source_id)

    return sources


def build_trace_evidence_envelope(
    envelope: EvidenceEnvelope,
    *,
    session_id: str,
    query: str = "",
    query_link: str = "",
    retriever_type: str = "",
    latency_ms: int = 0,
    timestamp: str | None = None,
    selected_references: list[dict[str, Any]] | None = None,
    selected_source_ids: list[str] | None = None,
) -> EvidenceEnvelope:
    existing_sources = list(envelope.sources or [])
    merged_sources = list(existing_sources)
    seen_ids = {source.id for source in existing_sources}

    for source in _build_evidence_sources(selected_references, selected_source_ids):
        if source.id in seen_ids:
            continue
        merged_sources.append(source)
        seen_ids.add(source.id)

    selected_ids = [source.id for source in merged_sources]
    subject_metadata = compact_evidence_mapping(
        {
            **dict(envelope.subject.metadata or {}),
            "session_id": _normalize_string(session_id) or None,
            "query": _normalize_string(query) or None,
        }
    )
    updated_subject = envelope.subject.model_copy(
        update={
            "title": envelope.subject.title or (_normalize_string(query) or None),
            "metadata": subject_metadata,
        }
    )

    runtime_metadata = compact_evidence_mapping(
        {
            **dict(envelope.runtime.metadata or {}),
            "query_link": _normalize_string(query_link) or None,
            "retriever_type": _normalize_string(retriever_type) or None,
        }
    )
    updated_runtime = envelope.runtime.model_copy(
        update={
            "timestamp": envelope.runtime.timestamp or (_normalize_string(timestamp) or None),
            "latency_ms": envelope.runtime.latency_ms if envelope.runtime.latency_ms is not None else _coerce_int(latency_ms),
            "metadata": runtime_metadata,
        }
    )

    updated_artifacts = compact_evidence_mapping(
        {
            **dict(envelope.artifacts or {}),
            "selected_source_ids": selected_ids or None,
        }
    )

    return envelope.model_copy(
        update={
            "subject": updated_subject,
            "artifacts": updated_artifacts,
            "sources": merged_sources,
            "runtime": updated_runtime,
        }
    )


def _legacy_context_extrapolation_to_envelope(trace: dict[str, Any], *, session_id: str) -> EvidenceEnvelope | None:
    legacy = dict(trace.get("context_extrapolation") or {})
    if not legacy:
        return None

    plan = ContextExtrapolationResult(
        schema_version=_normalize_string(legacy.get("schema_version")) or "1.0",
        intent=_normalize_string(legacy.get("intent")),
        intent_confidence=_coerce_float(legacy.get("intent_confidence")),
        persona=_normalize_string(legacy.get("persona")),
        persona_confidence=_coerce_float(legacy.get("persona_confidence")),
        task=_normalize_string(legacy.get("task")),
        task_confidence=_coerce_float(legacy.get("task_confidence")),
        technologies=[_normalize_string(item) for item in legacy.get("technologies", []) or [] if _normalize_string(item)],
        industries=[_normalize_string(item) for item in legacy.get("industries", []) or [] if _normalize_string(item)],
        expanded_queries=[_normalize_string(item) for item in legacy.get("expanded_queries", []) or [] if _normalize_string(item)],
        retrieval_probes=[_normalize_string(item) for item in legacy.get("retrieval_probes", []) or [] if _normalize_string(item)],
        metadata_hints=dict(legacy.get("metadata_hints") or {}),
        missing_context=list(legacy.get("missing_context") or []),
        assumptions=[_normalize_string(item) for item in legacy.get("assumptions", []) or [] if _normalize_string(item)],
        overall_confidence=_coerce_float(legacy.get("confidence")),
        use_plan=bool(legacy.get("use_plan")),
        fallback_reason=_normalize_string(legacy.get("fallback_reason")) or None,
    )
    envelope = plan.to_evidence_envelope(
        original_query=_normalize_string(trace.get("query")) or _normalize_string(legacy.get("original_query")),
        final_retrieval_query=_normalize_string(legacy.get("final_retrieval_query")),
        runtime_trace=dict(legacy.get("runtime_trace") or {}),
    )
    explainability = dict(trace.get("explainability") or {})
    return build_trace_evidence_envelope(
        envelope,
        session_id=session_id,
        query=_normalize_string(trace.get("query")) or _normalize_string(legacy.get("original_query")),
        query_link=_normalize_string(trace.get("query_link")),
        retriever_type=_normalize_string(trace.get("retriever_type")),
        latency_ms=_coerce_int(trace.get("latency_ms")),
        timestamp=_normalize_string(trace.get("timestamp")) or None,
        selected_references=list(explainability.get("selected_references", []) or []),
        selected_source_ids=[
            _normalize_string(item)
            for item in trace.get("final_selected_chunk_ids", []) or []
            if _normalize_string(item)
        ],
    )


def _normalize_trace_evidence(trace: dict[str, Any], *, session_id: str) -> EvidenceEnvelope | None:
    raw_evidence = trace.get("evidence")
    if raw_evidence:
        try:
            envelope = raw_evidence if isinstance(raw_evidence, EvidenceEnvelope) else EvidenceEnvelope.model_validate(raw_evidence)
        except Exception:
            envelope = None
        if envelope is not None:
            explainability = dict(trace.get("explainability") or {})
            return build_trace_evidence_envelope(
                envelope,
                session_id=session_id,
                query=_normalize_string(trace.get("query")),
                query_link=_normalize_string(trace.get("query_link")),
                retriever_type=_normalize_string(trace.get("retriever_type")),
                latency_ms=_coerce_int(trace.get("latency_ms")),
                timestamp=_normalize_string(trace.get("timestamp")) or None,
                selected_references=list(explainability.get("selected_references", []) or []),
                selected_source_ids=[
                    _normalize_string(item)
                    for item in trace.get("final_selected_chunk_ids", []) or []
                    if _normalize_string(item)
                ],
            )

    return _legacy_context_extrapolation_to_envelope(trace, session_id=session_id)


class RagTracer:
    """Persist JSONL traces under session rag directory."""

    _PARTITION_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")

    def __init__(self, base_dir: str = "session_storage") -> None:
        self.base_dir = Path(base_dir)
        # Per-session file locks so concurrent async requests don't interleave writes.
        self._locks: dict[str, threading.Lock] = {}
        self._meta_lock = threading.Lock()

    def _get_lock(self, session_id: str) -> threading.Lock:
        with self._meta_lock:
            if session_id not in self._locks:
                self._locks[session_id] = threading.Lock()
            return self._locks[session_id]

    @classmethod
    def normalize_partition_id(cls, partition_id: str) -> str:
        normalized = str(partition_id or "").strip()
        if not normalized:
            raise ValueError("Trace partition identifier is required.")
        if not cls._PARTITION_PATTERN.fullmatch(normalized):
            raise ValueError(f"Invalid trace partition identifier '{normalized}'.")
        return normalized

    def _resolve_partition_dir(self, session_id: str) -> Path:
        partition_id = self.normalize_partition_id(session_id)
        resolved_base = self.base_dir.resolve()
        resolved_partition = (resolved_base / partition_id).resolve()
        if not resolved_partition.is_relative_to(resolved_base):
            raise ValueError("Invalid trace partition path.")
        return resolved_partition

    @staticmethod
    def _is_trace_visible(
        trace: dict[str, Any],
        *,
        owner_user_id: int | None,
        allow_all: bool,
    ) -> bool:
        if allow_all or owner_user_id is None:
            return True
        stored_owner = trace.get("owner_user_id")
        try:
            return stored_owner is not None and int(stored_owner) == int(owner_user_id)
        except (TypeError, ValueError):
            return False

    def record(self, trace: RagTrace) -> None:
        trace_dir = self._resolve_partition_dir(trace.session_id)
        trace_dir.mkdir(parents=True, exist_ok=True)
        trace_file = trace_dir / "rag_traces.jsonl"
        line = json.dumps(trace.model_dump(exclude_none=True), ensure_ascii=True) + "\n"
        with self._get_lock(trace.session_id):
            with trace_file.open("a", encoding="utf-8") as handle:
                handle.write(line)

    def read_traces(
        self,
        session_id: str,
        *,
        owner_user_id: int | None = None,
        allow_all: bool = False,
    ) -> list[dict]:
        trace_file = self._resolve_partition_dir(session_id) / "rag_traces.jsonl"
        if not trace_file.exists():
            return []
        with self._get_lock(session_id):
            lines = trace_file.read_text(encoding="utf-8").splitlines()
        result = []
        for line in lines:
            if not line.strip():
                continue
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                continue  # skip any line corrupted by a previous partial write
            normalized_trace = self._normalize_trace(payload, session_id=session_id)
            if self._is_trace_visible(normalized_trace, owner_user_id=owner_user_id, allow_all=allow_all):
                result.append(normalized_trace)
        return result

    def read_trace_by_id(
        self,
        session_id: str,
        trace_id: str,
        *,
        owner_user_id: int | None = None,
        allow_all: bool = False,
    ) -> dict[str, Any] | None:
        normalized_trace_id = str(trace_id or "").strip()
        if not normalized_trace_id:
            return None
        traces = self.read_traces(session_id, owner_user_id=owner_user_id, allow_all=allow_all)
        for trace in reversed(traces):
            if str(trace.get("trace_id", "")) == normalized_trace_id:
                return trace
        return None

    @staticmethod
    def _normalize_trace(trace: Any, *, session_id: str) -> dict[str, Any]:
        payload = dict(trace) if isinstance(trace, dict) else {}
        trace_id = str(payload.get("trace_id") or "").strip()
        if not trace_id:
            trace_id = hashlib.sha1(
                "|".join(
                    [
                        str(session_id or "").strip(),
                        str(payload.get("query_link") or "").strip(),
                        str(payload.get("timestamp") or "").strip(),
                        str(payload.get("query") or "").strip(),
                    ]
                ).encode("utf-8")
            ).hexdigest()[:24]
        payload["trace_id"] = trace_id
        evidence = _normalize_trace_evidence(payload, session_id=session_id)
        if evidence is not None:
            payload["evidence"] = evidence.model_dump(exclude_none=True)
        payload["branches"] = list(payload.get("branches", []) or [])
        payload["graph_summary"] = dict(payload.get("graph_summary", {}) or {})
        payload["timing_breakdown"] = dict(payload.get("timing_breakdown", {}) or {})
        payload["query_normalization"] = dict(payload.get("query_normalization", {}) or {})
        payload = _refresh_graph_fields_from_branches(payload)
        payload.pop("context_extrapolation", None)
        return payload
