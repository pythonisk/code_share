"""Multi-query retriever implementation."""

from typing import Any

from daan.vector_stores.document import RagDocument

from .base_retriever import BaseRetriever
from .vector_retriever import VectorRetriever


class MultiQueryRetriever(BaseRetriever):
    """Expand query to variants and merge deduplicated results."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.llm_provider = config.get("llm_provider")
        self.num_queries = int(config.get("num_queries", 3))
        self.vector_retriever = VectorRetriever(config)

    def retrieve(self, query: str, k: int) -> list[RagDocument]:
        queries = self._generate_queries(query)
        merged: dict[str, RagDocument] = {}
        for variant in queries:
            docs = self.vector_retriever.retrieve(variant, k)
            for doc in docs:
                merged[doc.id] = doc
            if len(merged) >= k:
                break
        return list(merged.values())[:k]

    def _generate_queries(self, query: str) -> list[str]:
        if self.llm_provider is not None and hasattr(self.llm_provider, "completion"):
            try:
                prompt = (
                    f"Generate {self.num_queries} alternative search queries for: {query}. "
                    "Return one query per line."
                )
                raw = self.llm_provider.completion(prompt=prompt)
                if isinstance(raw, str):
                    variants = [line.strip() for line in raw.splitlines() if line.strip()]
                    if variants:
                        return [query, *variants][: self.num_queries]
            except Exception:
                pass
        return [query]
