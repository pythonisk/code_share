"""Retriever implementations."""
