"""Base retriever contract."""

from abc import ABC, abstractmethod
from typing import Any

from daan.vector_stores.document import RagDocument


class BaseRetriever(ABC):
    """Contract for retrieval strategies."""

    @abstractmethod
    def retrieve(self, query: str, k: int) -> list[RagDocument]:
        """Return top-k documents for a query."""

    def get_last_trace(self) -> dict[str, Any]:
        """Return structured explainability metadata for the last retrieval."""
        return {}
