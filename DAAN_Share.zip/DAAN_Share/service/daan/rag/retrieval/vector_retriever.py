﻿"""Vector retriever implementation."""

import hashlib
from typing import Any

from daan.llm.embeddings.base_embedding_provider import BaseEmbeddingProvider
from daan.vector_stores.providers.base_vector_store import BaseVectorStore
from daan.vector_stores.document import RagDocument

from .base_retriever import BaseRetriever


class VectorRetriever(BaseRetriever):
    """Embed query and run vector similarity search."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.vector_store: BaseVectorStore = config["vector_store"]
        self.embedding_provider: BaseEmbeddingProvider = config["embedding_provider"]
        self.query_link_key = config.get("query_link_key")
        # When True, use dense+sparse (BM25) hybrid search instead of pure cosine.
        self.use_hybrid = bool(config.get("use_hybrid", False))
        # Optional metadata filter (e.g. {"usecase_id": "UC_X"}) to scope results.
        self.metadata_filter = config.get("metadata_filter") or None
        self._last_trace: dict[str, Any] = {}

    def retrieve(self, query: str, k: int) -> list[RagDocument]:
        query_embedding = self.embedding_provider.embed_text(query)
        where = self.metadata_filter
        if self.use_hybrid and hasattr(self.vector_store, "hybrid_search"):
            docs = (
                self.vector_store.hybrid_search(query, query_embedding, max(2 * k, k), where=where)
                if where else
                self.vector_store.hybrid_search(query, query_embedding, max(2 * k, k))
            )
        else:
            docs = (
                self.vector_store.similarity_search(query_embedding, max(2 * k, k), where=where)
                if where else
                self.vector_store.similarity_search(query_embedding, max(2 * k, k))
            )
        query_link = self._resolve_query_link(query)
        query_node_id = f"query:{query_link}"

        if not self.query_link_key:
            selected = docs[:k]
            self._last_trace = self._build_trace(query_node_id, docs[: max(k, min(len(docs), 8))], selected)
            return selected

        filtered = [doc for doc in docs if str(doc.metadata.get("query_link", "")) == query_link]
        if filtered:
            selected = filtered[:k]
            self._last_trace = self._build_trace(query_node_id, filtered[: max(k, min(len(filtered), 8))], selected)
            return selected

        selected = docs[:k]
        self._last_trace = self._build_trace(query_node_id, docs[: max(k, min(len(docs), 8))], selected)
        return selected

    def get_last_trace(self) -> dict[str, Any]:
        return dict(self._last_trace)

    def _resolve_query_link(self, query: str) -> str:
        if self.query_link_key:
            return str(self.query_link_key)
        return hashlib.sha1(query.strip().lower().encode("utf-8")).hexdigest()[:16]

    @staticmethod
    def _build_trace(query_node_id: str, seed_docs: list[RagDocument], selected_docs: list[RagDocument]) -> dict[str, Any]:
        graph_nodes = [
            {
                "id": query_node_id,
                "label": "Query",
                "properties": {"name": "Query"},
            }
        ]
        graph_edges: list[dict[str, Any]] = []

        for rank, doc in enumerate(seed_docs, start=1):
            graph_nodes.append(
                {
                    "id": doc.id,
                    "label": "Chunk",
                    "properties": {
                        "source": doc.metadata.get("source") if doc.metadata else doc.source,
                        "chunk_index": doc.metadata.get("chunk_index", getattr(doc, "chunk_index", 0)) if getattr(doc, "metadata", None) else getattr(doc, "chunk_index", 0),
                        "text": doc.content,
                    },
                }
            )
            graph_edges.append(
                {
                    "source_id": query_node_id,
                    "target_id": doc.id,
                    "type": "seed",
                    "properties": {"rank": rank},
                }
            )

        return {
            "seed_chunk_ids": [doc.id for doc in seed_docs],
            "seed_chunks": [doc.id for doc in seed_docs],
            "traversal_hops": [],
            "visited_node_ids": [doc.id for doc in seed_docs],
            "edge_list": list(graph_edges),
            "final_selected_chunk_ids": [doc.id for doc in selected_docs],
            "graph_nodes": graph_nodes,
            "graph_edges": graph_edges,
        }
