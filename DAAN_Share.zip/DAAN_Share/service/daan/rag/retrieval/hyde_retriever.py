"""HyDE retriever implementation."""

from typing import Any

from daan.llm.embeddings.base_embedding_provider import BaseEmbeddingProvider
from daan.vector_stores.providers.base_vector_store import BaseVectorStore
from daan.vector_stores.document import RagDocument

from .base_retriever import BaseRetriever


class HyDERetriever(BaseRetriever):
    """Generate hypothetical answer then retrieve against corpus."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.vector_store: BaseVectorStore = config["vector_store"]
        self.embedding_provider: BaseEmbeddingProvider = config["embedding_provider"]
        self.llm_provider = config.get("llm_provider")

    def retrieve(self, query: str, k: int) -> list[RagDocument]:
        hypothetical = self._generate_hypothetical_answer(query)
        query_embedding = self.embedding_provider.embed_text(hypothetical)
        return self.vector_store.similarity_search(query_embedding=query_embedding, k=k)

    def _generate_hypothetical_answer(self, query: str) -> str:
        if self.llm_provider is not None and hasattr(self.llm_provider, "completion"):
            try:
                prompt = f"Write a concise high-quality answer for retrieval seeding: {query}"
                response = self.llm_provider.completion(prompt=prompt)
                if isinstance(response, str) and response.strip():
                    return response.strip()
            except Exception:
                pass
        return query
