"""Parent-document retriever."""

from typing import Any

from daan.vector_stores.document import RagDocument

from .base_retriever import BaseRetriever
from .vector_retriever import VectorRetriever


class ParentDocumentRetriever(BaseRetriever):
    """Retrieve child chunks then return parent-level merged documents."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.vector_retriever = VectorRetriever(config)

    def retrieve(self, query: str, k: int) -> list[RagDocument]:
        children = self.vector_retriever.retrieve(query, max(k * 2, k))
        parents: dict[str, RagDocument] = {}

        for child in children:
            parent_id = str(child.metadata.get("parent_id", child.id))
            if parent_id not in parents:
                parents[parent_id] = RagDocument(
                    id=parent_id,
                    content=child.metadata.get("parent_content", child.content),
                    metadata=child.metadata,
                    source=child.source,
                    chunk_index=0,
                )

        return list(parents.values())[:k]
