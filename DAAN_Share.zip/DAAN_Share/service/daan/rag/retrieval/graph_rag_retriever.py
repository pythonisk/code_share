"""GraphRAG retriever combining vector and graph results with RRF."""

from __future__ import annotations

import re
from difflib import SequenceMatcher
from typing import Any

from daan.vector_stores.document import RagDocument

from .base_retriever import BaseRetriever
from .graph_retriever import GraphRetriever
from .vector_retriever import VectorRetriever


class GraphRagRetriever(BaseRetriever):
    """Fuse vector and graph retriever output using reciprocal rank fusion."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.k_constant = int(config.get("rrf_k", 60))
        configured_boost = config.get("graph_expansion_boost")
        self.graph_expansion_boost = max(0.0, float(0.10 if configured_boost is None else configured_boost))
        self.vector_retriever = VectorRetriever(config)
        self.graph_retriever = GraphRetriever(config)
        self._last_trace: dict[str, Any] = {}

    def retrieve(self, query: str, k: int) -> list[RagDocument]:
        vector_docs = self.vector_retriever.retrieve(query, k)
        graph_docs = self.graph_retriever.retrieve(query, k)
        vector_trace = self.vector_retriever.get_last_trace()
        graph_trace = self.graph_retriever.get_last_trace()
        graph_expanded_chunk_ids = self._graph_expanded_chunk_ids(graph_docs, graph_trace)

        scores: dict[str, float] = {}
        merged: dict[str, RagDocument] = {}

        self._accumulate_rrf(scores, merged, vector_docs)
        self._accumulate_rrf(
            scores,
            merged,
            graph_docs,
            boost_ids=graph_expanded_chunk_ids,
            boost_factor=self.graph_expansion_boost,
        )

        ranked_ids = sorted(scores, key=scores.get, reverse=True)
        selected_docs = self._deduplicate_ranked_docs(ranked_ids, merged, k)

        combined_seed_ids = list(
            dict.fromkeys(
                [*vector_trace.get("seed_chunk_ids", []), *graph_trace.get("seed_chunk_ids", [])]
            )
        )

        graph_nodes = graph_trace.get("graph_nodes") or vector_trace.get("graph_nodes") or []
        graph_edges = graph_trace.get("graph_edges") or vector_trace.get("graph_edges") or []
        self._last_trace = {
            "seed_chunk_ids": combined_seed_ids,
            "seed_chunks": combined_seed_ids,
            "ontology_seed_ids": graph_trace.get("ontology_seed_ids", []),
            "traversal_hops": graph_trace.get("traversal_hops", []),
            "visited_node_ids": graph_trace.get("visited_node_ids", vector_trace.get("visited_node_ids", [])),
            "edge_list": graph_trace.get("edge_list", vector_trace.get("edge_list", [])),
            "final_selected_chunk_ids": [doc.id for doc in selected_docs],
            "graph_expanded_chunk_ids": sorted(graph_expanded_chunk_ids),
            "graph_nodes": graph_nodes,
            "graph_edges": graph_edges,
            "candidate_scores": [{"id": doc_id, "score": scores[doc_id]} for doc_id in ranked_ids],
        }
        return selected_docs

    def get_last_trace(self) -> dict[str, Any]:
        return dict(self._last_trace)

    def _deduplicate_ranked_docs(
        self,
        ranked_ids: list[str],
        merged: dict[str, RagDocument],
        k: int,
    ) -> list[RagDocument]:
        """Keep top-ranked unique/near-unique docs based on normalized content."""
        unique_docs: list[RagDocument] = []
        seen_prefixes: set[str] = set()
        kept_normalized: list[str] = []

        for doc_id in ranked_ids:
            doc = merged[doc_id]
            content_key = self._normalize_content(doc.content)
            if not content_key:
                continue

            content_prefix = content_key[:220]
            if content_prefix in seen_prefixes:
                continue

            if self._is_near_duplicate(content_key, kept_normalized):
                continue

            seen_prefixes.add(content_prefix)
            kept_normalized.append(content_key)
            unique_docs.append(doc)
            if len(unique_docs) >= k:
                break

        return unique_docs

    def _accumulate_rrf(
        self,
        scores: dict[str, float],
        merged: dict[str, RagDocument],
        docs: list[RagDocument],
        *,
        boost_ids: set[str] | None = None,
        boost_factor: float = 0.0,
    ) -> None:
        boosted_ids = boost_ids or set()
        for rank, doc in enumerate(docs, start=1):
            merged[doc.id] = doc
            contribution = 1.0 / (self.k_constant + rank)
            if doc.id in boosted_ids and boost_factor > 0.0:
                contribution *= 1.0 + boost_factor
            scores[doc.id] = scores.get(doc.id, 0.0) + contribution

    @staticmethod
    def _graph_expanded_chunk_ids(graph_docs: list[RagDocument], graph_trace: dict[str, Any]) -> set[str]:
        seed_chunk_ids = {str(chunk_id) for chunk_id in graph_trace.get("seed_chunk_ids", []) if str(chunk_id)}
        return {
            doc.id
            for doc in graph_docs
            if doc.id and doc.id not in seed_chunk_ids
        }

    @staticmethod
    def _normalize_content(text: str) -> str:
        """Normalize content for stable duplicate detection across retriever sources."""
        normalized = " ".join((text or "").split()).lower()
        return re.sub(r"[^\w\s]", "", normalized)

    @staticmethod
    def _is_near_duplicate(content: str, candidates: list[str], threshold: float = 0.92) -> bool:
        """Detect near-duplicate content using sequence similarity."""
        for existing in candidates:
            if SequenceMatcher(None, content, existing).ratio() >= threshold:
                return True
        return False
