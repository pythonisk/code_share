"""Graph retriever implementation."""

from __future__ import annotations

import hashlib
import logging
import re
import time
from collections import defaultdict
from threading import Event, Lock
from typing import Any

from daan.graph_stores.providers.base_graph_store import BaseGraphStore
from daan.llm.embeddings.base_embedding_provider import BaseEmbeddingProvider
from daan.vector_stores.providers.base_vector_store import BaseVectorStore
from daan.vector_stores.document import RagDocument

from .base_retriever import BaseRetriever


logger = logging.getLogger(__name__)


class GraphRetriever(BaseRetriever):
    """Retrieve vector seed chunks, then expand through the graph via MENTIONS edges.

    Flow: vector finds seed chunks -> for each seed, traverse the graph
    (chunk -MENTIONS-> entity -MENTIONS-> related chunks) -> resolve those
    neighbor chunk ids back to real text from the vector store. Entity nodes
    (no text) are skipped automatically because they are not in the vector store.
    """

    _ontology_node_cache: dict[str, list[str]] = {}
    _ontology_embedding_cache: dict[tuple[str, str], list[list[float]]] = {}
    _chunk_alias_cache: dict[tuple[str, str, str, str, str, int], tuple[float, tuple[str, ...]]] = {}
    _chunk_alias_inflight: dict[tuple[str, str, str, str, str, int], Event] = {}
    _chunk_alias_cache_lock = Lock()
    _chunk_alias_cache_ttl_seconds = 300.0

    def __init__(self, config: dict[str, Any]) -> None:
        self.vector_store: BaseVectorStore = config["vector_store"]
        self.graph_store: BaseGraphStore = config["graph_store"]
        self.embedding_provider: BaseEmbeddingProvider = config["embedding_provider"]
        # depth 2 = chunk -> entity -> related chunk (the useful hop).
        self.depth = int(config.get("graph_depth", 2))
        # Cap how many seed chunks are expanded through the graph. Each seed is a
        # multi-hop traversal; expanding every vector hit (up to 2*k) makes Cosmos
        # round-trips explode and triggers retrieval timeouts.
        self.graph_seed_limit = int(config.get("graph_seed_limit", 3))
        self.use_hybrid = bool(config.get("use_hybrid", False))
        self.query_link_key = config.get("query_link_key")
        # Option C (query-time entity linking): in addition to vector-found chunk
        # seeds, also start graph traversal from ontology nodes whose id matches the
        # query (e.g. "Integration", "Platform"). This makes the structural ontology
        # (HAS_PILLAR, IMPLEMENTS, ...) reachable even when no chunk mentions it.
        self.use_ontology_seeds = bool(config.get("use_ontology_seeds", True))
        self.ontology_seed_limit = int(config.get("ontology_seed_limit", 5))
        self.use_lexical_chunk_resolution = bool(config.get("use_lexical_chunk_resolution", True))
        # "semantic" ranks ontology nodes by embedding similarity to the query
        # (meaning-aware); "keyword" falls back to substring word overlap.
        self.ontology_seed_mode = str(config.get("ontology_seed_mode", "semantic")).lower()
        # Minimum cosine similarity for a semantic match (0..1). Below this the
        # node is considered unrelated and dropped.
        self.ontology_seed_min_score = float(config.get("ontology_seed_min_score", 0.30))
        # Cached per retriever instance so repeated calls don't re-hit the graph.
        self._ontology_node_ids: list[str] | None = None
        # Cached embeddings for ontology node names (parallel to _ontology_node_ids).
        self._ontology_embeddings: list[list[float]] | None = None
        self._last_trace: dict[str, Any] = {}

    def retrieve(
        self,
        query: str,
        k: int,
        *,
        branch_plan: Any | None = None,
        concept_ids: list[str] | None = None,
        ontology_seed_ids: list[str] | None = None,
        seed_docs: list[RagDocument] | None = None,
    ) -> list[RagDocument]:
        query_link = self._resolve_query_link(query)
        precomputed_seeds = [doc for doc in (seed_docs or []) if getattr(doc, "id", None)]
        query_embedding = self.embedding_provider.embed_text(query)
        if precomputed_seeds:
            seeds = precomputed_seeds
        else:
            # Hybrid seeds (dense + BM25) catch chunks that match by exact keyword
            # (e.g. code identifiers, domain codes) but not by dense meaning alone.
            hybrid_search = getattr(self.vector_store, "hybrid_search", None)
            if self.use_hybrid and callable(hybrid_search):
                seeds = hybrid_search(query, query_embedding, max(2 * k, k))
            else:
                seeds = self.vector_store.similarity_search(query_embedding, max(2 * k, k))
        if not seeds:
            return []

        if self.query_link_key:
            matched = [doc for doc in seeds if str(doc.metadata.get("query_link", "")) == query_link]
            if matched:
                seeds = matched

        seed_docs = seeds[: max(k, min(len(seeds), 8))]

        scores: dict[str, float] = defaultdict(float)
        docs: dict[str, RagDocument] = {doc.id: doc for doc in seeds}
        traversal_hops: list[dict[str, Any]] = []
        visited_node_ids: list[str] = []
        visited_nodes: list[Any] = []
        resolved_chunk_ids: list[str] = []
        lexical_terms: list[str] = []

        # Reciprocal-rank score for every vector seed (cheap, no graph call).
        for rank, seed in enumerate(seeds):
            scores[seed.id] += 1.0 / (rank + 1)

        # Only expand the strongest seeds through the graph. Traversal is the
        # expensive part, so bound the number of seeds we fan out from.
        expand_seeds = seeds[: max(1, min(self.graph_seed_limit, len(seeds)))]
        expand_ids = self._resolve_seed_graph_ids(expand_seeds)

        # Option C: add ontology nodes whose id matches the query as extra seeds,
        # so traversal can walk the structural ontology (pillars, categories, ...).
        matched_ontology_seed_ids = list(ontology_seed_ids or []) or self._match_ontology_seeds(
            query,
            query_embedding,
            self.ontology_seed_limit,
            concept_ids=concept_ids,
        )
        expand_ids = list(dict.fromkeys(expand_ids + matched_ontology_seed_ids))

        batch = getattr(self.graph_store, "get_neighbors_batch", None)
        if callable(batch):
            # Single round-trip for all seeds (avoids N Cosmos queries).
            neighbors = batch(expand_ids, self.depth)
            visited_nodes.extend(neighbors)
            neighbor_ids = [n.id for n in neighbors]
            visited_node_ids.extend(neighbor_ids)
            traversal_hops.append(
                {
                    "seed_chunk_id": expand_ids,
                    "depth": self.depth,
                    "neighbor_ids": neighbor_ids[:25],
                    "neighbor_count": len(neighbor_ids),
                }
            )
            related_docs, resolution_trace = self._resolve_chunks(neighbor_ids, nodes=neighbors)
            lexical_terms.extend(resolution_trace.get("lexical_terms", []))
            resolved_chunk_ids.extend(resolution_trace.get("resolved_chunk_ids", []))
            for related in related_docs:
                if related.id not in docs:
                    docs[related.id] = related
                scores[related.id] += 0.5
        else:
            for rank, seed in enumerate(expand_seeds):
                neighbors = self.graph_store.get_neighbors(seed.id, self.depth)
                visited_nodes.extend(neighbors)
                neighbor_ids = [n.id for n in neighbors]
                visited_node_ids.extend(neighbor_ids)
                traversal_hops.append(
                    {
                        "seed_chunk_id": seed.id,
                        "depth": self.depth,
                        "neighbor_ids": neighbor_ids[:25],
                        "neighbor_count": len(neighbor_ids),
                    }
                )
                related_docs, resolution_trace = self._resolve_chunks(neighbor_ids, nodes=neighbors)
                lexical_terms.extend(resolution_trace.get("lexical_terms", []))
                resolved_chunk_ids.extend(resolution_trace.get("resolved_chunk_ids", []))
                for related in related_docs:
                    if related.id not in docs:
                        docs[related.id] = related
                    scores[related.id] += 0.5 / (rank + 1)

            # Expand ontology seeds too (per-seed path has no chunk RagDocument).
            for onto_id in matched_ontology_seed_ids:
                neighbors = self.graph_store.get_neighbors(onto_id, self.depth)
                visited_nodes.extend(neighbors)
                neighbor_ids = [n.id for n in neighbors]
                visited_node_ids.extend(neighbor_ids)
                related_docs, resolution_trace = self._resolve_chunks(neighbor_ids, nodes=neighbors)
                lexical_terms.extend(resolution_trace.get("lexical_terms", []))
                resolved_chunk_ids.extend(resolution_trace.get("resolved_chunk_ids", []))
                for related in related_docs:
                    if related.id not in docs:
                        docs[related.id] = related
                    scores[related.id] += 0.5

        ranked_ids = sorted(scores.keys(), key=lambda doc_id: scores[doc_id], reverse=True)
        selected_docs = [docs[doc_id] for doc_id in ranked_ids[:k] if doc_id in docs]

        subgraph_ids = list(dict.fromkeys([doc.id for doc in seed_docs] + visited_node_ids + [doc.id for doc in selected_docs]))
        subgraph = self.graph_store.get_subgraph(subgraph_ids) if subgraph_ids else {"nodes": [], "edges": []}
        query_node_id = f"query:{query_link}"
        graph_nodes = [
            {
                "id": query_node_id,
                "label": "Query",
                "properties": {"name": "Query"},
            }
        ]
        graph_nodes.extend(node.model_dump() if hasattr(node, "model_dump") else node for node in subgraph.get("nodes", []))
        graph_edges = [
            {
                "source_id": query_node_id,
                "target_id": seed.id,
                "type": "seed",
                "properties": {"rank": rank + 1},
            }
            for rank, seed in enumerate(seed_docs)
        ]
        graph_edges.extend(edge.model_dump() if hasattr(edge, "model_dump") else edge for edge in subgraph.get("edges", []))

        visited_chunk_node_ids = [
            str(getattr(node, "id", "") or "")
            for node in visited_nodes
            if str(getattr(node, "label", "") or "") == "Chunk" and str(getattr(node, "id", "") or "")
        ]

        self._last_trace = {
            "seed_chunk_ids": [doc.id for doc in seed_docs],
            "seed_chunks": [doc.id for doc in seed_docs],
            "ontology_seed_ids": matched_ontology_seed_ids,
            "traversal_hops": traversal_hops,
            "visited_node_ids": list(dict.fromkeys(visited_node_ids)),
            "visited_chunk_node_ids": list(dict.fromkeys(visited_chunk_node_ids)),
            "resolved_chunk_ids": list(dict.fromkeys(resolved_chunk_ids)),
            "lexical_terms": list(dict.fromkeys(term for term in lexical_terms if term)),
            "edge_list": list(graph_edges),
            "final_selected_chunk_ids": [doc.id for doc in selected_docs],
            "graph_nodes": graph_nodes,
            "graph_edges": graph_edges,
            "candidate_scores": [{"id": doc_id, "score": scores[doc_id]} for doc_id in ranked_ids],
        }
        return selected_docs

    def get_last_trace(self) -> dict[str, Any]:
        return dict(self._last_trace)

    def _match_ontology_seeds(
        self,
        query: str,
        query_embedding: list[float],
        limit: int = 5,
        *,
        concept_ids: list[str] | None = None,
    ) -> list[str]:
        """Query-time entity linking: pick ontology nodes most relevant to the query.

        Two modes:
        - "semantic" (default): rank nodes by cosine similarity between the query
          embedding and each node-name embedding (meaning-aware, e.g. matches
          "workflow engine" to "OrchestrationEngine").
        - "keyword": substring word overlap between query and node id (fast, exact).

        Chunk nodes are excluded. Node ids and embeddings are cached per retriever
        instance so the graph is listed and embedded only once.
        """
        if not self.use_ontology_seeds:
            return []
        lister = getattr(self.graph_store, "list_node_ids", None)
        if not callable(lister):
            return []
        if self._ontology_node_ids is None or not self._ontology_node_ids:
            self._ontology_node_ids = self._load_ontology_node_ids(lister)
        if not self._ontology_node_ids:
            return []

        if self.ontology_seed_mode == "semantic":
            semantic = self._match_ontology_semantic(query_embedding, limit, concept_ids=concept_ids)
            # If embedding failed for any reason, fall back to keyword matching.
            if semantic:
                return semantic
        keyword_matches = self._match_ontology_keyword(query, limit, concept_ids=concept_ids)
        return keyword_matches

    def _match_ontology_semantic(
        self,
        query_embedding: list[float],
        limit: int,
        *,
        concept_ids: list[str] | None = None,
    ) -> list[str] | None:
        """Rank ontology nodes by cosine similarity to the query embedding.

        Returns None (not []) if embeddings are unavailable, so the caller can
        fall back to keyword matching. Node-name embeddings are computed once.
        """
        if not query_embedding:
            return None
        if self._ontology_embeddings is None:
            texts = [self._humanize_id(nid) for nid in (self._ontology_node_ids or [])]
            try:
                cache_key = (self._ontology_cache_key(), self._embedding_cache_key())
                cached_embeddings = self._ontology_embedding_cache.get(cache_key)
                if cached_embeddings is None:
                    cached_embeddings = self.embedding_provider.embed_batch(texts)
                    self._ontology_embedding_cache[cache_key] = cached_embeddings
                self._ontology_embeddings = list(cached_embeddings)
            except Exception:  # noqa: BLE001
                self._ontology_embeddings = []
        embeddings = self._ontology_embeddings
        if not embeddings:
            return None
        scored: list[tuple[float, str]] = []
        for nid, emb in zip(self._ontology_node_ids or [], embeddings):
            score = self._cosine(query_embedding, emb)
            if score >= self.ontology_seed_min_score:
                scored.append((score, nid))
        scored.sort(key=lambda x: x[0], reverse=True)
        ranked = [nid for _, nid in scored]
        return self._blend_concept_matches(ranked, limit, concept_ids)

    def _match_ontology_keyword(self, query: str, limit: int, *, concept_ids: list[str] | None = None) -> list[str]:
        """Substring word-overlap ranking between query and ontology node ids."""
        query_words = [w for w in re.findall(r"[a-z0-9]{4,}", query.lower())]
        if not query_words:
            return []
        scored: list[tuple[int, str]] = []
        for nid in self._ontology_node_ids or []:
            normalized = re.sub(r"[^a-z0-9]+", "", str(nid).lower())
            if not normalized:
                continue
            hits = sum(
                1 for word in query_words
                if word in normalized or normalized in word
            )
            if hits > 0:
                scored.append((hits, nid))
        scored.sort(key=lambda x: x[0], reverse=True)
        ranked = [nid for _, nid in scored]
        return self._blend_concept_matches(ranked, limit, concept_ids)

    def _blend_concept_matches(self, ranked: list[str], limit: int, concept_ids: list[str] | None) -> list[str]:
        if not concept_ids:
            return ranked[:limit]
        concept_terms = [re.sub(r"[^a-z0-9]+", "", str(term).casefold()) for term in concept_ids if str(term).strip()]
        if not concept_terms:
            return ranked[:limit]
        prioritized: list[str] = []
        for node_id in self._ontology_node_ids or []:
            normalized = re.sub(r"[^a-z0-9]+", "", str(node_id).casefold())
            if normalized and any(term and (term in normalized or normalized in term) for term in concept_terms):
                prioritized.append(node_id)
        return list(dict.fromkeys([*prioritized, *ranked]))[:limit]

    @staticmethod
    def _humanize_id(node_id: Any) -> str:
        """Turn a node id into readable text for embedding.

        'DataIntegration' -> 'Data Integration'; 'ent:data_pillar' -> 'data pillar'.
        """
        raw = str(node_id)
        if ":" in raw:
            raw = raw.split(":", 1)[1]
        raw = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", raw)
        raw = re.sub(r"[_\-.]+", " ", raw)
        return raw.strip() or str(node_id)

    @staticmethod
    def _cosine(a: list[float], b: list[float]) -> float:
        """Cosine similarity between two equal-length vectors (0 if degenerate)."""
        if not a or not b or len(a) != len(b):
            return 0.0
        dot = 0.0
        norm_a = 0.0
        norm_b = 0.0
        for x, y in zip(a, b):
            dot += x * y
            norm_a += x * x
            norm_b += y * y
        if norm_a <= 0.0 or norm_b <= 0.0:
            return 0.0
        return dot / ((norm_a ** 0.5) * (norm_b ** 0.5))

    def _resolve_chunks(self, node_ids: list[str], *, nodes: list[Any] | None = None) -> tuple[list[RagDocument], dict[str, Any]]:
        """Resolve graph-neighbor ids back to real chunks in the vector store.

        Entity-node ids are not in the vector store, so they are filtered out.
        """
        fetch = getattr(self.vector_store, "get_documents_by_ids", None)
        if not callable(fetch) or not node_ids:
            return [], {"resolved_chunk_ids": [], "lexical_terms": []}
        clean_ids = [str(node_id) for node_id in node_ids if node_id]
        resolved: list[RagDocument] = []
        seen_doc_ids: set[str] = set()
        lexical_terms: list[str] = []

        def add_docs(docs: list[RagDocument]) -> None:
            for doc in docs:
                if not getattr(doc, "id", None) or doc.id in seen_doc_ids:
                    continue
                resolved.append(doc)
                seen_doc_ids.add(doc.id)

        try:
            add_docs(fetch(clean_ids))
        except Exception:  # noqa: BLE001
            return [], {"resolved_chunk_ids": [], "lexical_terms": []}

        unresolved_ids = [node_id for node_id in clean_ids if node_id not in seen_doc_ids]
        if unresolved_ids:
            add_docs(self._resolve_chunk_docs_by_metadata(nodes))
            add_docs(self._resolve_neighbor_chunk_docs(unresolved_ids))
            if self.use_lexical_chunk_resolution:
                lexical_terms = self._collect_resolution_terms(unresolved_ids, nodes=nodes)
                add_docs(self._resolve_lexical_chunk_docs(lexical_terms))

        return resolved, {
            "resolved_chunk_ids": [doc.id for doc in resolved],
            "lexical_terms": lexical_terms,
        }

    def _resolve_neighbor_chunk_docs(self, node_ids: list[str]) -> list[RagDocument]:
        fetch = getattr(self.vector_store, "get_documents_by_ids", None)
        if not callable(fetch) or not node_ids:
            return []

        neighbor_nodes: list[Any] = []
        batch = getattr(self.graph_store, "get_neighbors_batch", None)
        if callable(batch):
            try:
                neighbor_nodes = list(batch(node_ids, 1))
            except Exception:  # noqa: BLE001
                neighbor_nodes = []
        else:
            getter = getattr(self.graph_store, "get_neighbors", None)
            if callable(getter):
                for node_id in node_ids:
                    try:
                        neighbor_nodes.extend(getter(node_id, 1))
                    except Exception:  # noqa: BLE001
                        continue

        chunk_ids: list[str] = []
        chunk_nodes: list[Any] = []
        for node in neighbor_nodes:
            label = str(getattr(node, "label", "") or "")
            node_id = str(getattr(node, "id", "") or "")
            if label == "Chunk" and node_id:
                chunk_ids.append(node_id)
                chunk_nodes.append(node)

        if not chunk_ids:
            return []

        resolved: list[RagDocument] = []
        seen_doc_ids: set[str] = set()

        def add_docs(docs: list[RagDocument]) -> None:
            for doc in docs:
                if not getattr(doc, "id", None) or doc.id in seen_doc_ids:
                    continue
                resolved.append(doc)
                seen_doc_ids.add(doc.id)

        try:
            add_docs(fetch(list(dict.fromkeys(chunk_ids))))
        except Exception:  # noqa: BLE001
            return []

        unresolved_chunk_nodes = [node for node in chunk_nodes if str(getattr(node, "id", "") or "") not in seen_doc_ids]
        if unresolved_chunk_nodes:
            add_docs(self._resolve_chunk_docs_by_metadata(unresolved_chunk_nodes))

        return resolved

    def _resolve_lexical_chunk_docs(self, terms: list[str]) -> list[RagDocument]:
        finder = getattr(self.vector_store, "documents_containing", None)
        bulk_finder = getattr(self.vector_store, "documents_containing_any", None)
        if not callable(finder) and not callable(bulk_finder):
            return []

        candidate_terms: list[str] = []
        term_scores: dict[str, float] = {}
        seen_terms: set[str] = set()
        for term in terms[:12]:
            normalized_term = str(term or "").strip()
            if len(normalized_term) < 4:
                continue
            folded = normalized_term.casefold()
            if folded in seen_terms:
                continue
            seen_terms.add(folded)
            candidate_terms.append(normalized_term)
            term_scores[normalized_term] = 1.0 + min(0.5, len(normalized_term.split()) * 0.1)

        scored_docs: dict[str, tuple[float, RagDocument]] = {}

        if callable(bulk_finder) and candidate_terms:
            try:
                matches = bulk_finder(candidate_terms, limit_per_term=3)
            except Exception:  # noqa: BLE001
                matches = []
            for doc in matches:
                if not getattr(doc, "id", None):
                    continue
                content_folded = (doc.content or "").casefold()
                best_score = 0.0
                for normalized_term in candidate_terms:
                    if normalized_term.casefold() not in content_folded:
                        continue
                    best_score = max(best_score, term_scores.get(normalized_term, 1.0))
                if best_score <= 0.0:
                    continue
                current = scored_docs.get(doc.id)
                if current is None or best_score > current[0]:
                    scored_docs[doc.id] = (best_score, doc)
        elif callable(finder):
            for normalized_term in candidate_terms:
                try:
                    matches = finder(normalized_term, limit=3)
                except Exception:  # noqa: BLE001
                    continue
                term_score = term_scores.get(normalized_term, 1.0)
                for doc in matches:
                    if not getattr(doc, "id", None):
                        continue
                    current = scored_docs.get(doc.id)
                    if current is None or term_score > current[0]:
                        scored_docs[doc.id] = (term_score, doc)
        ranked = sorted(scored_docs.values(), key=lambda item: item[0], reverse=True)
        return [doc for _, doc in ranked]

    def _resolve_seed_graph_ids(self, seed_docs: list[RagDocument]) -> list[str]:
        graph_ids: list[str] = []
        for doc in seed_docs:
            graph_ids.append(doc.id)
            metadata = dict(getattr(doc, "metadata", {}) or {})
            source_name = str(metadata.get("source_name") or metadata.get("source") or doc.source or "").strip() or None
            partition_id = str(metadata.get("partition_id") or "").strip() or None
            chunk_index_raw = metadata.get("chunk_index", getattr(doc, "chunk_index", None))
            try:
                chunk_index = int(chunk_index_raw) if chunk_index_raw is not None else None
            except (TypeError, ValueError):
                chunk_index = None
            aliases, _cache_hit = self._find_chunk_aliases(
                canonical_chunk_id=str(metadata.get("canonical_chunk_id") or doc.id),
                source_name=source_name,
                chunk_index=chunk_index,
                partition_id=partition_id,
                limit=3,
            )
            graph_ids.extend(str(alias) for alias in aliases if alias)
        return list(dict.fromkeys(graph_ids))

    def _resolve_chunk_docs_by_metadata(self, nodes: list[Any] | None) -> list[RagDocument]:
        bulk_finder = getattr(self.vector_store, "find_documents_by_metadata_bulk", None)
        if not callable(bulk_finder):
            return []

        keys, _skipped_nodes = self._build_metadata_resolution_keys(nodes)
        if not keys:
            return []

        try:
            matches = bulk_finder(keys, limit=2)
        except Exception:  # noqa: BLE001
            return []

        docs: list[RagDocument] = []
        seen_doc_ids: set[str] = set()
        for doc in matches:
            if not getattr(doc, "id", None) or doc.id in seen_doc_ids:
                continue
            docs.append(doc)
            seen_doc_ids.add(doc.id)
        return docs

    def _find_chunk_aliases(
        self,
        *,
        canonical_chunk_id: str,
        source_name: str | None,
        chunk_index: int | None,
        partition_id: str | None,
        limit: int,
    ) -> tuple[list[str], bool]:
        finder = getattr(self.graph_store, "find_chunk_node_ids", None)
        if not callable(finder):
            return [], False

        cache_key = self._chunk_alias_cache_key(
            canonical_chunk_id=canonical_chunk_id,
            source_name=source_name,
            chunk_index=chunk_index,
            partition_id=partition_id,
            limit=limit,
        )
        owner = False
        wait_event: Event | None = None
        cache_lock = type(self)._chunk_alias_cache_lock

        while True:
            with cache_lock:
                cached_entry = type(self)._chunk_alias_cache.get(cache_key)
                if cached_entry is not None:
                    cached_at, cached_aliases = cached_entry
                    if (time.monotonic() - cached_at) <= type(self)._chunk_alias_cache_ttl_seconds:
                        return list(cached_aliases), True
                    type(self)._chunk_alias_cache.pop(cache_key, None)

                wait_event = type(self)._chunk_alias_inflight.get(cache_key)
                if wait_event is None:
                    wait_event = Event()
                    type(self)._chunk_alias_inflight[cache_key] = wait_event
                    owner = True
                    break
            if wait_event is not None:
                wait_event.wait()

        aliases: tuple[str, ...] = ()
        try:
            try:
                rows = finder(
                    canonical_chunk_id=canonical_chunk_id,
                    source_name=source_name,
                    chunk_index=chunk_index,
                    partition_id=partition_id,
                    limit=limit,
                )
            except Exception:  # noqa: BLE001
                rows = []
            aliases = tuple(dict.fromkeys(str(row) for row in rows if row))
        finally:
            with cache_lock:
                type(self)._chunk_alias_cache[cache_key] = (time.monotonic(), aliases)
                inflight = type(self)._chunk_alias_inflight.pop(cache_key, None)
                if inflight is not None:
                    inflight.set()
        return list(aliases), False

    def _chunk_alias_cache_key(
        self,
        *,
        canonical_chunk_id: str,
        source_name: str | None,
        chunk_index: int | None,
        partition_id: str | None,
        limit: int,
    ) -> tuple[str, str, str, str, str, int]:
        return (
            self._ontology_cache_key(),
            str(canonical_chunk_id or "").strip(),
            str(source_name or "").strip(),
            "" if chunk_index is None else str(int(chunk_index)),
            str(partition_id or "").strip(),
            int(limit),
        )

    def _build_metadata_resolution_keys(self, nodes: list[Any] | None) -> tuple[list[dict[str, Any]], int]:
        keys: list[dict[str, Any]] = []
        seen_keys: set[tuple[str, str, int | None, str | None]] = set()
        skipped_nodes = 0

        for node in nodes or []:
            properties = getattr(node, "properties", {}) or {}
            canonical_chunk_id = str(properties.get("canonical_chunk_id") or "").strip() or None
            source_name = str(properties.get("source_name") or properties.get("source") or "").strip() or None
            partition_id = str(properties.get("partition_id") or "").strip() or None
            chunk_index_raw = properties.get("chunk_index")
            try:
                chunk_index = int(chunk_index_raw) if chunk_index_raw not in (None, "", -1) else None
            except (TypeError, ValueError):
                chunk_index = None

            if canonical_chunk_id:
                cache_key = ("canonical", canonical_chunk_id, None, None)
                if cache_key in seen_keys:
                    continue
                seen_keys.add(cache_key)
                keys.append({"canonical_chunk_id": canonical_chunk_id})
                continue

            if source_name and chunk_index is not None:
                cache_key = ("source_chunk", source_name, chunk_index, partition_id)
                if cache_key in seen_keys:
                    continue
                seen_keys.add(cache_key)
                payload: dict[str, Any] = {"source_name": source_name, "chunk_index": chunk_index}
                if partition_id:
                    payload["partition_id"] = partition_id
                keys.append(payload)
                continue

            skipped_nodes += 1

        return keys, skipped_nodes

    def _collect_resolution_terms(self, node_ids: list[str], *, nodes: list[Any] | None = None) -> list[str]:
        terms: list[str] = []
        seen_terms: set[str] = set()

        def add_term(term: str) -> None:
            normalized = re.sub(r"\s+", " ", str(term or "").strip())
            folded = normalized.casefold()
            if len(normalized) < 4 or folded in seen_terms:
                return
            seen_terms.add(folded)
            terms.append(normalized)

        for node in nodes or []:
            node_id = str(getattr(node, "id", "") or "")
            label = str(getattr(node, "label", "") or "")
            properties = getattr(node, "properties", {}) or {}
            name = str(properties.get("name") or properties.get("text") or "").strip()
            for variant in self._candidate_terms_for_node(node_id=node_id, node_name=name, node_label=label):
                add_term(variant)

        for node_id in node_ids:
            for variant in self._candidate_terms_for_node(node_id=node_id, node_name="", node_label=""):
                add_term(variant)

        return terms

    def _candidate_terms_for_node(self, *, node_id: str, node_name: str, node_label: str) -> list[str]:
        variants: list[str] = []

        def push(value: str) -> None:
            cleaned = re.sub(r"\s+", " ", str(value or "").strip())
            if cleaned:
                variants.append(cleaned)

        if node_name and node_name.casefold() not in {"chunk", "entity", "query"}:
            push(node_name)

        humanized = self._humanize_id(node_id)
        push(humanized)

        id_tail = str(node_id or "")
        if ":" in id_tail:
            id_tail = id_tail.split(":", 1)[1]
        id_tokens = [token for token in re.split(r"[_\-.\s]+", id_tail) if token]
        if len(id_tokens) > 1 and len(id_tokens[0]) <= 4:
            push(" ".join(id_tokens[1:]))
            push(id_tokens[-1])
        elif id_tokens:
            push(" ".join(id_tokens))
            push(id_tokens[-1])

        if node_label and node_name:
            push(f"{node_label} {node_name}")

        return list(dict.fromkeys(variant for variant in variants if variant))

    def _resolve_query_link(self, query: str) -> str:
        if self.query_link_key:
            return str(self.query_link_key)
        return hashlib.sha1(query.strip().lower().encode("utf-8")).hexdigest()[:16]

    def _ontology_cache_key(self) -> str:
        config = getattr(self.graph_store, "config", {}) or {}
        return ":".join([type(self.graph_store).__name__, str(config.get("database") or ""), str(config.get("graph") or "")])

    def _embedding_cache_key(self) -> str:
        return ":".join(
            [
                type(self.embedding_provider).__name__,
                str(getattr(self.embedding_provider, "model_name", "") or getattr(self.embedding_provider, "model", "")),
                str(getattr(self.embedding_provider, "deployment", "")),
            ]
        )

    def _load_ontology_node_ids(self, lister: Any) -> list[str]:
        try:
            cache_key = self._ontology_cache_key()
            cached_ids = self._ontology_node_cache.get(cache_key)
            if cached_ids:
                return list(cached_ids)

            live_ids = [nid for nid in lister() if nid and not str(nid).startswith("chunk:")]
            if live_ids:
                self._ontology_node_cache[cache_key] = live_ids
            else:
                self._ontology_node_cache.pop(cache_key, None)
            return list(live_ids)
        except Exception:  # noqa: BLE001
            return []
