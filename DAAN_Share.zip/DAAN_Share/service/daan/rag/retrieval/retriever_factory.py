"""Factory for retrieval strategies."""

import importlib
from typing import Any

from .base_retriever import BaseRetriever


class RetrieverFactory:
    """Create retrievers from registry definitions."""

    RETRIEVER_MAP = {
        "vector": {
            "module": "daan.rag.retrieval.vector_retriever",
            "class": "VectorRetriever",
        },
        "graph": {
            "module": "daan.rag.retrieval.graph_retriever",
            "class": "GraphRetriever",
        },
        "graph_rag": {
            "module": "daan.rag.retrieval.graph_rag_retriever",
            "class": "GraphRagRetriever",
        },
        "hybrid": {
            "module": "daan.rag.retrieval.hybrid_retriever",
            "class": "HybridRetriever",
        },
        "hyde": {
            "module": "daan.rag.retrieval.hyde_retriever",
            "class": "HyDERetriever",
        },
        "multi_query": {
            "module": "daan.rag.retrieval.multi_query_retriever",
            "class": "MultiQueryRetriever",
        },
        "contextual_compression": {
            "module": "daan.rag.retrieval.contextual_compression_retriever",
            "class": "ContextualCompressionRetriever",
        },
        "parent_document": {
            "module": "daan.rag.retrieval.parent_document_retriever",
            "class": "ParentDocumentRetriever",
        },
    }

    @classmethod
    def create_retriever(cls, retriever_type: str, config: dict[str, Any]) -> BaseRetriever:
        """Create and return retriever instance."""
        if retriever_type not in cls.RETRIEVER_MAP:
            available = ", ".join(cls.RETRIEVER_MAP.keys())
            raise ValueError(f"Unsupported retriever '{retriever_type}'. Available: {available}")

        retriever_info = cls.RETRIEVER_MAP[retriever_type]
        module = importlib.import_module(retriever_info["module"])
        retriever_class = getattr(module, retriever_info["class"])
        return retriever_class(config)

    @classmethod
    def get_available_retrievers(cls) -> list[str]:
        """List registered retrievers."""
        return list(cls.RETRIEVER_MAP.keys())
