"""Contextual compression retriever."""

from typing import Any

from daan.vector_stores.document import RagDocument

from .base_retriever import BaseRetriever


class ContextualCompressionRetriever(BaseRetriever):
    """Wrap another retriever and compress each document to relevant lines."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.base_retriever: BaseRetriever = config["base_retriever"]
        self.llm_provider = config.get("llm_provider")

    def retrieve(self, query: str, k: int) -> list[RagDocument]:
        docs = self.base_retriever.retrieve(query, k)
        return [self._compress(doc, query) for doc in docs]

    def _compress(self, doc: RagDocument, query: str) -> RagDocument:
        if self.llm_provider is not None and hasattr(self.llm_provider, "completion"):
            try:
                prompt = (
                    "Extract only sentences relevant to the query.\n"
                    f"Query: {query}\n"
                    f"Text: {doc.content}"
                )
                compressed = self.llm_provider.completion(prompt=prompt)
                if isinstance(compressed, str) and compressed.strip():
                    doc.content = compressed.strip()
                    return doc
            except Exception:
                pass

        query_terms = [term.lower() for term in query.split() if term.strip()]
        lines = [line for line in doc.content.splitlines() if any(term in line.lower() for term in query_terms)]
        if lines:
            doc.content = "\n".join(lines)
        return doc
