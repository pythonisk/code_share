"""Hybrid retriever combining vector and lexical signals."""

from typing import Any

from daan.llm.embeddings.base_embedding_provider import BaseEmbeddingProvider
from daan.vector_stores.providers.base_vector_store import BaseVectorStore
from daan.vector_stores.document import RagDocument

from .base_retriever import BaseRetriever


class HybridRetriever(BaseRetriever):
    """Use vector store hybrid search if available."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.vector_store: BaseVectorStore = config["vector_store"]
        self.embedding_provider: BaseEmbeddingProvider = config["embedding_provider"]

    def retrieve(self, query: str, k: int) -> list[RagDocument]:
        query_embedding = self.embedding_provider.embed_text(query)
        return self.vector_store.hybrid_search(query=query, query_embedding=query_embedding, k=k)
