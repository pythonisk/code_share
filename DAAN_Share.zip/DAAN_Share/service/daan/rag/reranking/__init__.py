"""Reranking implementations."""
