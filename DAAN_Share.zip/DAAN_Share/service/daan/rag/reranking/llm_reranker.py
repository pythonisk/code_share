"""LLM-as-judge reranker — batched single-call scoring."""

from __future__ import annotations

import json
import logging
from typing import Any

from daan.vector_stores.document import RagDocument

from .base_reranker import BaseReranker

logger = logging.getLogger(__name__)

_MAX_CONTENT_CHARS = 300


class LLMReranker(BaseReranker):
    """Score all docs in one batched LLM call; fallback to lexical overlap."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.llm_provider = config.get("llm_provider")

    def rerank(self, query: str, docs: list[RagDocument]) -> list[RagDocument]:
        if not docs:
            return []

        scores = self._batch_score(query, docs)
        paired = list(zip(scores, docs))
        paired.sort(key=lambda item: item[0], reverse=True)
        return [doc for _, doc in paired]

    def _batch_score(self, query: str, docs: list[RagDocument]) -> list[float]:
        if self.llm_provider is None or not hasattr(self.llm_provider, "completion"):
            return self._lexical_scores(query, docs)

        # Build a single prompt with all documents numbered
        doc_entries = []
        for i, doc in enumerate(docs):
            truncated = (doc.content or "")[:_MAX_CONTENT_CHARS]
            doc_entries.append(f"[{i}] {truncated}")

        prompt = (
            "You are a relevance judge. Rate each document's relevance to the query.\n"
            "Return ONLY a JSON array of floats (0.0 to 1.0), one per document, in order.\n"
            "Example: [0.9, 0.2, 0.7]\n\n"
            f"Query: {query}\n\n"
            "Documents:\n" + "\n".join(doc_entries)
        )

        try:
            raw = str(self.llm_provider.completion(prompt=prompt)).strip()
            # Extract JSON array from response
            start = raw.find("[")
            end = raw.rfind("]") + 1
            if start >= 0 and end > start:
                scores = json.loads(raw[start:end])
                if isinstance(scores, list):
                    # Pad or truncate to match doc count
                    float_scores = [float(s) for s in scores]
                    while len(float_scores) < len(docs):
                        float_scores.append(0.0)
                    return float_scores[: len(docs)]
            logger.warning("LLM reranker: no JSON array in response (raw=%s), falling back to lexical.", raw[:200])
        except Exception as e:
            logger.warning("LLM reranker batch call failed: %s", e)

        return self._lexical_scores(query, docs)

    def _lexical_scores(self, query: str, docs: list[RagDocument]) -> list[float]:
        query_terms = [term.lower() for term in query.split() if term.strip()]
        if not query_terms:
            return [0.0] * len(docs)
        return [
            sum(1 for term in query_terms if term in (doc.content or "").lower()) / len(query_terms)
            for doc in docs
        ]
