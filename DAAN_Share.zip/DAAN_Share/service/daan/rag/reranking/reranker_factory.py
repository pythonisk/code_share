"""Factory for reranker strategies."""

import importlib
from typing import Any

from .base_reranker import BaseReranker


class RerankerFactory:
    """Create rerankers from registry definitions."""

    RERANKER_MAP = {
        "cross_encoder": {
            "module": "daan.rag.reranking.cross_encoder_reranker",
            "class": "CrossEncoderReranker",
        },
        "llm": {
            "module": "daan.rag.reranking.llm_reranker",
            "class": "LLMReranker",
        },
        "cohere": {
            "module": "daan.rag.reranking.cohere_reranker",
            "class": "CohereReranker",
        },
    }

    @classmethod
    def create_reranker(cls, reranker_type: str, config: dict[str, Any]) -> BaseReranker:
        """Create and return reranker instance."""
        if reranker_type not in cls.RERANKER_MAP:
            available = ", ".join(cls.RERANKER_MAP.keys())
            raise ValueError(f"Unsupported reranker '{reranker_type}'. Available: {available}")

        info = cls.RERANKER_MAP[reranker_type]
        module = importlib.import_module(info["module"])
        reranker_class = getattr(module, info["class"])
        return reranker_class(config)

    @classmethod
    def get_available_rerankers(cls) -> list[str]:
        """List registered rerankers."""
        return list(cls.RERANKER_MAP.keys())
