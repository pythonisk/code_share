"""Cross-encoder reranker with lexical fallback."""

from __future__ import annotations

import logging
from typing import Any

from daan.vector_stores.document import RagDocument

from .base_reranker import BaseReranker

logger = logging.getLogger(__name__)


class CrossEncoderReranker(BaseReranker):
    """Rerank docs with sentence-transformers CrossEncoder if available."""

    _model_cache: dict[str, Any] = {}
    _failed_models: set[str] = set()

    def __init__(self, config: dict[str, Any]) -> None:
        self.model_name = config.get("cross_encoder_model", "cross-encoder/ms-marco-MiniLM-L-6-v2")
        self._model = None

        if self.model_name in self._model_cache:
            self._model = self._model_cache[self.model_name]
            return

        if self.model_name in self._failed_models:
            return

        try:
            from sentence_transformers import CrossEncoder  # pylint: disable=import-outside-toplevel

            self._model = CrossEncoder(self.model_name)
            self._model_cache[self.model_name] = self._model
        except Exception as exc:  # noqa: BLE001
            self._failed_models.add(self.model_name)
            logger.warning(
                "Cross-encoder reranker unavailable for %s; falling back to lexical reranking: %s",
                self.model_name,
                exc,
            )
            self._model = None

    def rerank(self, query: str, docs: list[RagDocument]) -> list[RagDocument]:
        if not docs:
            return []

        if self._model is not None:
            pairs = [(query, doc.content) for doc in docs]
            scores = self._model.predict(pairs)
            ranked = sorted(zip(scores, docs), key=lambda item: item[0], reverse=True)
            return [doc for _, doc in ranked]

        query_terms = [term.lower() for term in query.split() if term.strip()]
        ranked = sorted(
            docs,
            key=lambda doc: sum(1 for term in query_terms if term in doc.content.lower()),
            reverse=True,
        )
        return ranked
