"""Base reranker contract."""

from abc import ABC, abstractmethod

from daan.vector_stores.document import RagDocument


class BaseReranker(ABC):
    """Contract for reranking retrieved documents."""

    @abstractmethod
    def rerank(self, query: str, docs: list[RagDocument]) -> list[RagDocument]:
        """Return reranked list of documents."""
