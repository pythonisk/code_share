"""Cohere reranker implementation with lexical fallback."""

from __future__ import annotations

import os
from typing import Any

from daan.vector_stores.document import RagDocument

from .base_reranker import BaseReranker


class CohereReranker(BaseReranker):
    """Cohere API reranker with optional client fallback."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.model = config.get("model", "rerank-v3.5")
        self.api_key = config.get("api_key") or os.getenv(config.get("api_key_env", "COHERE_API_KEY"))
        self._client = None

        if self.api_key:
            try:
                import cohere  # pylint: disable=import-outside-toplevel

                self._client = cohere.Client(self.api_key)
            except Exception:
                self._client = None

    def rerank(self, query: str, docs: list[RagDocument]) -> list[RagDocument]:
        if not docs:
            return []

        if self._client is not None:
            try:
                response = self._client.rerank(
                    model=self.model,
                    query=query,
                    documents=[doc.content for doc in docs],
                    top_n=len(docs),
                )
                scored = sorted(
                    [(result.index, float(result.relevance_score)) for result in response.results],
                    key=lambda item: item[1],
                    reverse=True,
                )
                return [docs[index] for index, _ in scored]
            except Exception:
                pass

        query_terms = [term.lower() for term in query.split() if term.strip()]
        ranked = sorted(
            docs,
            key=lambda doc: sum(1 for term in query_terms if term in doc.content.lower()),
            reverse=True,
        )
        return ranked
