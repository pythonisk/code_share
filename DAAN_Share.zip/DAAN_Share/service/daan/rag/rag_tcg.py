"""
RAG for TCG — Semantic retrieval for Test Cases Generator.

Uses ChromaDB with its built-in ONNX embedding model (all-MiniLM-L6-v2).
No Azure OpenAI embedding deployment required.

Usage::

    from rag.rag_tcg import RAG_TCG

    rag = RAG_TCG()
    rag.build_index(["chunk1 text", "chunk2 text", ...])
    results = rag.retrieve("query about mappings", k=5)
"""

import os
import hashlib
import logging
import shutil
from typing import List

from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

_DB_PATH = os.getenv("RAG_DB_PATH", ".chroma_db_tcg")
_COLLECTION = "tcg_rag"


class RAG_TCG:
    """RAG store for TCG using ChromaDB with built-in ONNX embeddings."""

    def __init__(self, db_path: str = _DB_PATH):
        self._db_path = db_path
        self._collection = None
        self._client = None
        self._ready = False

    @property
    def is_ready(self) -> bool:
        return self._ready

    def build_index(self, chunks: List[str]) -> None:
        """Embed *chunks* into ChromaDB using built-in ONNX embedding."""
        if self._ready:
            return
        if not chunks:
            return

        # Deduplicate
        seen = set()
        unique_chunks = []
        for text in chunks:
            t = text.strip()
            if not t:
                continue
            h = hashlib.md5(t.encode()).hexdigest()
            if h in seen:
                continue
            seen.add(h)
            unique_chunks.append(t)

        if not unique_chunks:
            return

        try:
            import chromadb

            # Clean previous DB
            if os.path.isdir(self._db_path):
                shutil.rmtree(self._db_path, ignore_errors=True)

            self._client = chromadb.PersistentClient(path=self._db_path)

            # Uses ChromaDB's built-in default embedding function
            # (all-MiniLM-L6-v2 via ONNX — no external API needed)
            self._collection = self._client.get_or_create_collection(
                name=_COLLECTION,
            )

            # Add documents in batches (ChromaDB limit ~41666 per batch)
            batch_size = 5000
            for start in range(0, len(unique_chunks), batch_size):
                batch = unique_chunks[start:start + batch_size]
                ids = [hashlib.md5(t.encode()).hexdigest() for t in batch]
                self._collection.add(
                    ids=ids,
                    documents=batch,
                )

            self._ready = True
            logger.info("RAG_TCG: ChromaDB indexed %d chunks (built-in ONNX embedding)", len(unique_chunks))

        except Exception as exc:
            logger.error("RAG_TCG: build_index failed: %s", exc, exc_info=True)
            self._ready = False

    def retrieve(self, query: str, k: int = 5) -> List[str]:
        """Return up to *k* most-relevant chunks for *query*."""
        if not self._ready or self._collection is None:
            return []

        try:
            count = self._collection.count()
            if count == 0:
                return []
            results = self._collection.query(
                query_texts=[query],
                n_results=min(k, count),
            )
            docs = results.get("documents", [[]])[0]
            return docs
        except Exception as exc:
            logger.warning("RAG_TCG: retrieve failed: %s", exc)
            return []

    def reset(self) -> None:
        self._collection = None
        self._client = None
        self._ready = False
        if os.path.isdir(self._db_path):
            shutil.rmtree(self._db_path, ignore_errors=True)
