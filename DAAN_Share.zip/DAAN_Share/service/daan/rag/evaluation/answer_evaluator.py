"""LLM-as-judge answer evaluator (expected-answer based).

Scores a RAG-generated answer against a known-correct expected answer on four
metrics, using the configured LLM (Azure GPT-4o + fallback). Unlike
`rag_evaluator.RagEvaluator` (which scores an answer against its retrieval
*context*), this judge compares the answer against a ground-truth expected
answer — the contract needed by the `/rag/evaluate` API and offline eval sets.

Metrics (all 0.0-1.0, higher is better):
  - correctness   : does the answer match the facts in the expected answer (no contradictions)?
  - completeness  : does it cover all the key points the expected answer has (nothing important missing)?
  - relevance     : does it actually answer the question asked, without drifting?
  - faithfulness  : does it avoid adding unsupported / hallucinated claims beyond the expected answer?
"""

from __future__ import annotations

import json
import re
from typing import Any

METRIC_KEYS = ("correctness", "completeness", "relevance", "faithfulness")

_JUDGE_INSTRUCTIONS = (
    "You are a strict, impartial evaluation judge for a retrieval-augmented "
    "question-answering system. You are given a QUESTION, an EXPECTED_ANSWER "
    "(the ground truth), and a GENERATED_ANSWER produced by the system. Score the "
    "GENERATED_ANSWER against the EXPECTED_ANSWER on four metrics, each a number "
    "between 0.0 and 1.0 (two decimals):\n"
    "- correctness: do the facts in the generated answer agree with the expected answer? "
    "Penalize contradictions and wrong values.\n"
    "- completeness: does the generated answer cover all key points present in the expected "
    "answer? Penalize missing important facts.\n"
    "- relevance: does the generated answer actually address the question, without drifting "
    "to unrelated content?\n"
    "- faithfulness: does the generated answer avoid adding claims not supported by the "
    "expected answer (no hallucinations / fabrications)?\n\n"
    "Respond with ONLY a JSON object, no markdown, no prose, in exactly this shape:\n"
    '{"correctness": 0.0, "completeness": 0.0, "relevance": 0.0, "faithfulness": 0.0, '
    '"rationale": "one or two sentences explaining the scores"}'
)


def _clamp_unit(value: Any) -> float:
    """Coerce a value to a float clamped to [0.0, 1.0], rounded to 2 decimals."""
    try:
        num = float(value)
    except (TypeError, ValueError):
        return 0.0
    if num != num:  # NaN guard
        return 0.0
    return round(min(1.0, max(0.0, num)), 2)


def _parse_judge_json(raw: str) -> dict[str, Any]:
    """Extract the JSON object from the LLM response, tolerant of code fences/prose."""
    if not raw:
        raise ValueError("empty judge response")
    text = raw.strip()
    # Strip ```json ... ``` fences if present.
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\s*", "", text)
        text = re.sub(r"\s*```$", "", text).strip()
    # Grab the first balanced-looking {...} block.
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        raise ValueError(f"no JSON object found in judge response: {raw[:200]}")
    return json.loads(match.group(0))


def evaluate_answer(
    question: str,
    expected_answer: str,
    generated_answer: str,
) -> dict[str, Any]:
    """Judge a single generated answer against the expected answer.

    Returns a dict with the four metric scores (0.0-1.0), an `overall` average,
    and a short `rationale`. Falls back to a zero-scored result with an error
    note if the LLM/judge fails, so batch runs never crash on one bad row.
    """
    prompt = (
        f"{_JUDGE_INSTRUCTIONS}\n\n"
        f"QUESTION:\n{question}\n\n"
        f"EXPECTED_ANSWER:\n{expected_answer}\n\n"
        f"GENERATED_ANSWER:\n{generated_answer}\n"
    )

    from daan.llm.llm_provider import get_llm_response_with_fallback  # lazy import

    try:
        raw = get_llm_response_with_fallback(prompt)
        parsed = _parse_judge_json(raw)
    except Exception as exc:  # noqa: BLE001 - never let one row break a batch
        return {
            **{key: 0.0 for key in METRIC_KEYS},
            "overall": 0.0,
            "rationale": f"evaluation failed: {exc}",
        }

    scores = {key: _clamp_unit(parsed.get(key)) for key in METRIC_KEYS}
    overall = round(sum(scores.values()) / len(METRIC_KEYS), 2)
    rationale = str(parsed.get("rationale") or "").strip()
    return {**scores, "overall": overall, "rationale": rationale}
