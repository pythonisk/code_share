"""RAG answer evaluation service."""

from __future__ import annotations

from typing import Any


class RagEvaluator:
    """Evaluate answer quality metrics with LLM fallback heuristics."""

    def __init__(self, llm_provider: Any = None) -> None:
        self.llm_provider = llm_provider

    def evaluate(self, query: str, answer: str, context: str) -> dict[str, float]:
        if self.llm_provider is not None and hasattr(self.llm_provider, "completion"):
            try:
                prompt = (
                    "Score the answer quality as JSON with keys: "
                    "faithfulness, answer_relevance, context_precision, context_recall between 0 and 1.\n"
                    f"Query: {query}\n"
                    f"Answer: {answer}\n"
                    f"Context: {context}"
                )
                raw = self.llm_provider.completion(prompt=prompt)
                if isinstance(raw, dict):
                    return {k: float(v) for k, v in raw.items()}
            except Exception:
                pass

        # Fallback lexical overlap heuristics.
        query_terms = {term.lower() for term in query.split() if term.strip()}
        answer_terms = {term.lower() for term in answer.split() if term.strip()}
        context_terms = {term.lower() for term in context.split() if term.strip()}

        relevance = _jaccard(query_terms, answer_terms)
        precision = _jaccard(answer_terms, context_terms)
        recall = _jaccard(query_terms, context_terms)
        faithfulness = precision

        return {
            "faithfulness": faithfulness,
            "answer_relevance": relevance,
            "context_precision": precision,
            "context_recall": recall,
        }


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a.intersection(b)) / len(a.union(b))
