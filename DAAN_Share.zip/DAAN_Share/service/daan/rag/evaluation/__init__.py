"""RAG evaluation package."""
