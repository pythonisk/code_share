"""Persist and aggregate final workflow quality scores in PostgreSQL."""

from __future__ import annotations

import logging
import re
from collections import OrderedDict, defaultdict
from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Float, Integer, String, UniqueConstraint, func
from sqlalchemy.orm import Mapped, Session, mapped_column, sessionmaker

from daan.observability.postgres import ObservabilityBase, get_observability_session_factory, init_observability_db

logger = logging.getLogger(__name__)


class FinalQualityScoreMetric(ObservabilityBase):
    """One row per finalized session for observability dashboards."""

    __tablename__ = "final_quality_score_metrics"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    session_id: Mapped[str] = mapped_column(String(100), nullable=False, unique=True, index=True)
    usecase_id: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    archetype: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    username: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    completeness_avg: Mapped[float | None] = mapped_column(Float, nullable=True)
    relevance_avg: Mapped[float | None] = mapped_column(Float, nullable=True)
    context_avg: Mapped[float | None] = mapped_column(Float, nullable=True)
    overall_avg: Mapped[float | None] = mapped_column(Float, nullable=True)
    reporter_output_path: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    quality_output_path: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False, index=True
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False, index=True
    )


class AgentQualityScoreMetric(ObservabilityBase):
    """One row per agent per finalized session (full per-dimension scores)."""

    __tablename__ = "agent_quality_score_metrics"
    __table_args__ = (UniqueConstraint("session_id", "agent_id", name="uq_agent_quality_session_agent"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    session_id: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    usecase_id: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    archetype: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    agent_id: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    agent_name: Mapped[str] = mapped_column(String(255), nullable=False)
    completeness_score: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    answer_relevance_score: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    context_score: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    overall_score: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    passed: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False, index=True
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )


def parse_average_score(text: str) -> float | None:
    """Best-effort extraction of the first numeric score from quality output."""
    match = re.search(r"\d+(?:\.\d+)?", str(text or ""))
    if not match:
        return None
    try:
        return float(match.group(0))
    except ValueError:
        return None


def _session_factory() -> sessionmaker[Session]:
    init_observability_db()
    return get_observability_session_factory()


def _avg(values: list[float]) -> float | None:
    """Mean of a list of floats, or None when empty."""
    return round(sum(values) / len(values), 2) if values else None


def collect_agent_scores(session_id: str) -> list[dict[str, object]]:
    """Read the latest persisted score for every agent in a session from disk.

    Uses the newest feedback revision's score when present, otherwise the base
    score. Returns a normalized list of dicts with all score dimensions.
    """
    # Local import to avoid importing the flow layer at module load time.
    from daan.flow.session_service import read_agent_score, read_run_deliverables

    scores: list[dict[str, object]] = []
    try:
        deliverables = read_run_deliverables(session_id)
    except Exception:
        logger.warning("Failed to read deliverables for session %s", session_id, exc_info=True)
        return scores

    for deliverable in deliverables:
        agent_id = str(deliverable.get("agent_id") or "").strip()
        if not agent_id:
            continue
        # Only capture agents that actually produced a final report / output.
        has_output = bool(
            str(deliverable.get("final_output") or "").strip()
            or str(deliverable.get("base_output") or "").strip()
        )
        if not has_output:
            continue
        feedback_seqs = [int(f.get("seq") or 0) for f in (deliverable.get("feedback") or [])]
        score: dict[str, object] | None = None
        try:
            if feedback_seqs:
                score = read_agent_score(session_id, agent_id, feedback_seq=max(feedback_seqs))
            if not score:
                score = read_agent_score(session_id, agent_id)
        except Exception:
            score = None
        if not score:
            continue

        scores.append(
            {
                "agent_id": agent_id,
                "agent_name": str(score.get("agent_name") or deliverable.get("agent_name") or agent_id),
                "completeness_score": float(score.get("completeness_score") or 0.0),
                "answer_relevance_score": float(score.get("answer_relevance_score") or 0.0),
                "context_score": float(score.get("context_score") or 0.0),
                "overall_score": float(score.get("overall_score") or 0.0),
                "passed": bool(score.get("passed", False)),
            }
        )
    return scores


def store_session_quality_scores(
    *,
    session_id: str,
    usecase_id: str,
    archetype: str,
    username: str | None = None,
    agent_scores: list[dict[str, object]] | None = None,
    reporter_output_path: str | None = None,
    quality_output_path: str | None = None,
) -> FinalQualityScoreMetric:
    """Upsert the session-level score and replace its per-agent score rows."""
    normalized_session_id = str(session_id or "").strip()
    normalized_usecase_id = str(usecase_id or "").strip()
    normalized_archetype = str(archetype or "").strip()
    if not normalized_session_id:
        raise ValueError("session_id is required")
    if not normalized_usecase_id:
        raise ValueError("usecase_id is required")
    if not normalized_archetype:
        raise ValueError("archetype is required")

    agent_scores = agent_scores or []
    completeness_avg = _avg([float(a.get("completeness_score") or 0.0) for a in agent_scores])
    relevance_avg = _avg([float(a.get("answer_relevance_score") or 0.0) for a in agent_scores])
    context_avg = _avg([float(a.get("context_score") or 0.0) for a in agent_scores])
    overall_avg = _avg([float(a.get("overall_score") or 0.0) for a in agent_scores])

    with _session_factory()() as db:
        row = (
            db.query(FinalQualityScoreMetric)
            .filter(FinalQualityScoreMetric.session_id == normalized_session_id)
            .first()
        )
        if row is None:
            row = FinalQualityScoreMetric(session_id=normalized_session_id)
            db.add(row)

        row.usecase_id = normalized_usecase_id
        row.archetype = normalized_archetype
        row.username = str(username or "").strip() or None
        row.completeness_avg = completeness_avg
        row.relevance_avg = relevance_avg
        row.context_avg = context_avg
        row.overall_avg = overall_avg
        row.reporter_output_path = str(reporter_output_path or "").strip() or None
        row.quality_output_path = str(quality_output_path or "").strip() or None
        row.updated_at = datetime.now(timezone.utc)

        # Replace per-agent rows for this session.
        db.query(AgentQualityScoreMetric).filter(
            AgentQualityScoreMetric.session_id == normalized_session_id
        ).delete(synchronize_session=False)
        for agent in agent_scores:
            agent_id = str(agent.get("agent_id") or "").strip()
            if not agent_id:
                continue
            db.add(
                AgentQualityScoreMetric(
                    session_id=normalized_session_id,
                    usecase_id=normalized_usecase_id,
                    archetype=normalized_archetype,
                    agent_id=agent_id,
                    agent_name=str(agent.get("agent_name") or agent_id),
                    completeness_score=float(agent.get("completeness_score") or 0.0),
                    answer_relevance_score=float(agent.get("answer_relevance_score") or 0.0),
                    context_score=float(agent.get("context_score") or 0.0),
                    overall_score=float(agent.get("overall_score") or 0.0),
                    passed=bool(agent.get("passed", False)),
                )
            )

        db.commit()
        db.refresh(row)
        return row


def get_average_for_usecase(usecase_id: str) -> dict[str, object]:
    """Return aggregate quality metrics for one use case."""
    normalized_usecase_id = str(usecase_id or "").strip()
    if not normalized_usecase_id:
        raise ValueError("usecase_id is required")

    with _session_factory()() as db:
        aggregate = (
            db.query(
                func.avg(FinalQualityScoreMetric.overall_avg),
                func.count(FinalQualityScoreMetric.id),
            )
            .filter(FinalQualityScoreMetric.usecase_id == normalized_usecase_id)
            .one()
        )
        latest = (
            db.query(FinalQualityScoreMetric)
            .filter(FinalQualityScoreMetric.usecase_id == normalized_usecase_id)
            .order_by(FinalQualityScoreMetric.updated_at.desc(), FinalQualityScoreMetric.id.desc())
            .first()
        )
        return {
            "scope_type": "usecase",
            "scope_value": normalized_usecase_id,
            "average_score": float(aggregate[0]) if aggregate[0] is not None else None,
            "sample_count": int(aggregate[1] or 0),
            "latest_score": float(latest.overall_avg) if latest is not None and latest.overall_avg is not None else None,
            "latest_session_id": latest.session_id if latest is not None else None,
            "updated_at": latest.updated_at if latest is not None else None,
        }


def get_average_for_archetype(archetype: str) -> dict[str, object]:
    """Return aggregate quality metrics for one archetype."""
    normalized_archetype = str(archetype or "").strip()
    if not normalized_archetype:
        raise ValueError("archetype is required")

    lowered_archetype = normalized_archetype.casefold()
    with _session_factory()() as db:
        aggregate = (
            db.query(
                func.avg(FinalQualityScoreMetric.overall_avg),
                func.count(FinalQualityScoreMetric.id),
            )
            .filter(func.lower(FinalQualityScoreMetric.archetype) == lowered_archetype)
            .one()
        )
        latest = (
            db.query(FinalQualityScoreMetric)
            .filter(func.lower(FinalQualityScoreMetric.archetype) == lowered_archetype)
            .order_by(FinalQualityScoreMetric.updated_at.desc(), FinalQualityScoreMetric.id.desc())
            .first()
        )
        return {
            "scope_type": "archetype",
            "scope_value": normalized_archetype,
            "average_score": float(aggregate[0]) if aggregate[0] is not None else None,
            "sample_count": int(aggregate[1] or 0),
            "latest_score": float(latest.overall_avg) if latest is not None and latest.overall_avg is not None else None,
            "latest_session_id": latest.session_id if latest is not None else None,
            "updated_at": latest.updated_at if latest is not None else None,
        }


def get_dq_indicators_overview(archetype: str | None = None) -> list[dict[str, object]]:
    """Return the full usecase -> sessions -> agents score hierarchy (all users).

    Optionally filtered to a single archetype (case-insensitive). Usecases are
    ordered by id; sessions within a usecase are ordered newest first.
    """
    with _session_factory()() as db:
        session_query = db.query(FinalQualityScoreMetric)
        if archetype and str(archetype).strip():
            session_query = session_query.filter(
                func.lower(FinalQualityScoreMetric.archetype) == str(archetype).strip().casefold()
            )
        sessions = session_query.order_by(
            FinalQualityScoreMetric.usecase_id.asc(),
            FinalQualityScoreMetric.updated_at.desc(),
            FinalQualityScoreMetric.id.desc(),
        ).all()

        session_ids = [s.session_id for s in sessions]
        agents_by_session: dict[str, list[AgentQualityScoreMetric]] = defaultdict(list)
        if session_ids:
            agent_rows = (
                db.query(AgentQualityScoreMetric)
                .filter(AgentQualityScoreMetric.session_id.in_(session_ids))
                .order_by(AgentQualityScoreMetric.agent_id.asc())
                .all()
            )
            for agent_row in agent_rows:
                agents_by_session[agent_row.session_id].append(agent_row)

        groups: "OrderedDict[str, dict[str, object]]" = OrderedDict()
        for session_row in sessions:
            group = groups.get(session_row.usecase_id)
            if group is None:
                group = {
                    "usecase_id": session_row.usecase_id,
                    "usecase_name": None,
                    "archetype": session_row.archetype,
                    "session_count": 0,
                    "completeness_avg": None,
                    "relevance_avg": None,
                    "context_avg": None,
                    "overall_avg": None,
                    "sessions": [],
                }
                groups[session_row.usecase_id] = group

            agents = [
                {
                    "agent_id": a.agent_id,
                    "agent_name": a.agent_name,
                    "completeness_score": a.completeness_score,
                    "answer_relevance_score": a.answer_relevance_score,
                    "context_score": a.context_score,
                    "overall_score": a.overall_score,
                    "passed": a.passed,
                }
                for a in agents_by_session.get(session_row.session_id, [])
            ]
            group["sessions"].append(  # type: ignore[union-attr]
                {
                    "session_id": session_row.session_id,
                    "username": session_row.username,
                    "run_timestamp": session_row.updated_at,
                    "completeness_avg": session_row.completeness_avg,
                    "relevance_avg": session_row.relevance_avg,
                    "context_avg": session_row.context_avg,
                    "overall_avg": session_row.overall_avg,
                    "agents": agents,
                }
            )

        # Compute usecase-level averages across its sessions.
        for group in groups.values():
            session_items = group["sessions"]  # type: ignore[index]
            group["session_count"] = len(session_items)
            group["completeness_avg"] = _avg(
                [float(s["completeness_avg"]) for s in session_items if s["completeness_avg"] is not None]
            )
            group["relevance_avg"] = _avg(
                [float(s["relevance_avg"]) for s in session_items if s["relevance_avg"] is not None]
            )
            group["context_avg"] = _avg(
                [float(s["context_avg"]) for s in session_items if s["context_avg"] is not None]
            )
            group["overall_avg"] = _avg(
                [float(s["overall_avg"]) for s in session_items if s["overall_avg"] is not None]
            )

        return list(groups.values())
