"""PostgreSQL connection helpers for observability persistence."""

from __future__ import annotations

from threading import Lock

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, declarative_base, sessionmaker

from daan.core.config import get_settings
from daan.core.database import engine as app_engine

ObservabilityBase = declarative_base()

_ENGINE: Engine | None = None
_SESSION_FACTORY: sessionmaker[Session] | None = None
_INIT_LOCK = Lock()
_TABLES_READY = False


def _resolve_observability_postgres_url() -> str | None:
    settings = get_settings()
    app_url = str(settings.DATABASE_URL or "").strip()
    if app_url.startswith("postgresql"):
        return app_url

    vector_url = settings.get_vector_database_url()
    vector_url = str(vector_url or "").strip()
    if vector_url.startswith("postgresql"):
        return vector_url
    return None


def _build_vector_connect_args() -> dict[str, str]:
    settings = get_settings()
    ssl_ca = str(settings.VECTOR_DB_SSL_CA or "").strip()
    if ssl_ca and "ca-cert.pem" not in ssl_ca:
        return {"sslmode": "verify-full", "sslrootcert": ssl_ca}
    return {"sslmode": "require"}


def get_observability_engine() -> Engine:
    global _ENGINE

    settings = get_settings()
    app_url = str(settings.DATABASE_URL or "").strip()
    if app_url.startswith("postgresql"):
        return app_engine

    if _ENGINE is None:
        db_url = _resolve_observability_postgres_url()
        if not db_url:
            raise RuntimeError("No PostgreSQL database configured for quality observability")
        _ENGINE = create_engine(
            db_url,
            future=True,
            pool_pre_ping=True,
            connect_args=_build_vector_connect_args(),
        )
    return _ENGINE


def get_observability_session_factory() -> sessionmaker[Session]:
    global _SESSION_FACTORY

    if _SESSION_FACTORY is None:
        _SESSION_FACTORY = sessionmaker(bind=get_observability_engine(), autoflush=False, autocommit=False)
    return _SESSION_FACTORY


# Idempotent column additions for tables that predate newer score fields.
# PostgreSQL-only (uses ADD COLUMN IF NOT EXISTS); safe to run on every init.
_COLUMN_MIGRATIONS: tuple[str, ...] = (
    "ALTER TABLE final_quality_score_metrics ADD COLUMN IF NOT EXISTS username VARCHAR(255)",
    "ALTER TABLE final_quality_score_metrics ADD COLUMN IF NOT EXISTS completeness_avg DOUBLE PRECISION",
    "ALTER TABLE final_quality_score_metrics ADD COLUMN IF NOT EXISTS relevance_avg DOUBLE PRECISION",
    "ALTER TABLE final_quality_score_metrics ADD COLUMN IF NOT EXISTS context_avg DOUBLE PRECISION",
    "ALTER TABLE final_quality_score_metrics ADD COLUMN IF NOT EXISTS overall_avg DOUBLE PRECISION",
    "ALTER TABLE final_quality_score_metrics DROP COLUMN IF EXISTS average_score",
)


def _run_column_migrations(engine: Engine) -> None:
    if engine.dialect.name != "postgresql":
        return
    with engine.begin() as conn:
        for statement in _COLUMN_MIGRATIONS:
            conn.execute(text(statement))


def init_observability_db() -> None:
    global _TABLES_READY

    if _TABLES_READY:
        return
    with _INIT_LOCK:
        if _TABLES_READY:
            return
        # Ensure all observability models are registered on ObservabilityBase
        # before create_all runs (imported here to avoid a circular import).
        from daan.observability import quality_store  # noqa: F401

        engine = get_observability_engine()
        ObservabilityBase.metadata.create_all(bind=engine)
        _run_column_migrations(engine)
        _TABLES_READY = True
