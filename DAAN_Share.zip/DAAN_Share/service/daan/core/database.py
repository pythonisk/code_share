"""Database setup and session management for DAAN service."""

from collections.abc import AsyncGenerator, Generator
import os
from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import Session, declarative_base, sessionmaker
from sqlalchemy.pool import NullPool, QueuePool

from daan.core.config import DEFAULT_SQLITE_DB_PATH, get_settings

settings = get_settings()



def _build_engine(database_url: str):
    is_sqlite = database_url.startswith("sqlite")
    is_postgresql = database_url.startswith("postgresql")
    pool_class = NullPool if is_sqlite else QueuePool
    connect_args = {}

    if is_sqlite:
        connect_args = {"check_same_thread": False, "timeout": 15}
    elif is_postgresql:
        if settings.APP_DATABASE_SSL_CA and str(settings.APP_DATABASE_SSL_CA).strip() and "ca-cert.pem" not in str(settings.APP_DATABASE_SSL_CA):
            connect_args["sslmode"] = "verify-full"
            connect_args["sslrootcert"] = settings.APP_DATABASE_SSL_CA
        else:
            connect_args["sslmode"] = "require"
        if settings.APP_DB_SCHEMA and str(settings.APP_DB_SCHEMA).strip():
            connect_args["options"] = f'-c search_path="{settings.APP_DB_SCHEMA.strip()}"'
    else:
        if settings.APP_DATABASE_SSL_CA and str(settings.APP_DATABASE_SSL_CA).strip() and "ca-cert.pem" not in str(settings.APP_DATABASE_SSL_CA):
            # Only add SSL check if a valid certificate path was provided
            connect_args["ssl"] = {"ca": settings.APP_DATABASE_SSL_CA}
        else:
            # Enable SSL but skip certificate verification (Azure MySQL flexible server)
            connect_args["ssl"] = {"check_hostname": False, "verify_mode": 0}

    engine = create_engine(
        database_url,
        connect_args=connect_args,
        poolclass=pool_class,
        future=True,
        pool_pre_ping=not is_sqlite,
    )
    return engine, is_sqlite, is_postgresql


engine, is_sqlite, is_postgresql = _build_engine(settings.DATABASE_URL)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


def _build_async_engine(database_url: str):
    """Build async engine for async operations."""
    # Convert sync URL to async URL
    if database_url.startswith("postgresql://"):
        async_url = database_url.replace("postgresql://", "postgresql+asyncpg://")
    elif database_url.startswith("sqlite://"):
        async_url = database_url.replace("sqlite://", "sqlite+aiosqlite://")
    else:
        # For MySQL, use aiomysql
        async_url = database_url.replace("mysql://", "mysql+aiomysql://")
    
    is_sqlite = async_url.startswith("sqlite")
    is_postgresql = async_url.startswith("postgresql")
    connect_args = {}

    if is_sqlite:
        connect_args = {"check_same_thread": False}
    elif is_postgresql:
        # asyncpg uses different SSL parameters than psycopg
        # For Azure PostgreSQL, we need to enable SSL but not provide certificate path in connect_args
        # asyncpg will use the system's CA certificates automatically
        connect_args = {}  # asyncpg handles SSL via connection string parameters or defaults
    
    # Async engines manage their own pooling, don't specify poolclass
    async_engine = create_async_engine(
        async_url,
        connect_args=connect_args,
        future=True,
        pool_pre_ping=not is_sqlite,
    )
    return async_engine


async_engine = _build_async_engine(settings.DATABASE_URL)
AsyncSessionLocal = async_sessionmaker(
    async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
    autocommit=False,
)


def activate_sqlite_fallback() -> str:
    """Rebind the ORM to the default local SQLite database for development."""
    global settings, engine, is_sqlite, is_postgresql

    sqlite_url = f"sqlite:///{DEFAULT_SQLITE_DB_PATH.as_posix()}"
    os.environ["APP_DATABASE_URL"] = sqlite_url
    get_settings.cache_clear()
    settings = get_settings()

    try:
        engine.dispose()
    except Exception:
        pass

    engine, is_sqlite, is_postgresql = _build_engine(settings.DATABASE_URL)
    SessionLocal.configure(bind=engine)
    return settings.DATABASE_URL


def get_db() -> Generator[Session, None, None]:
    """Provide a transactional database session per request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


async def get_async_db() -> AsyncGenerator[AsyncSession, None]:
    """Provide an async transactional database session per request."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


def _add_missing_columns() -> None:
    """Add new columns to existing tables without dropping data.

    ``create_all`` only creates missing *tables*; it never alters existing
    ones.  This function handles forward migrations for columns added after
    the initial schema was deployed.
    """
    from sqlalchemy import inspect, text

    insp = inspect(engine)
    with engine.begin() as conn:
        # audit_log.changes — stores JSON diff of what changed per action
        audit_cols = {c["name"] for c in insp.get_columns("audit_log")}
        if "changes" not in audit_cols:
            # SQLite uses TEXT; PostgreSQL will store it as JSONB via SQLAlchemy JSON type.
            col_type = "JSONB" if is_postgresql else "TEXT"
            conn.execute(text(f"ALTER TABLE audit_log ADD COLUMN changes {col_type}"))


def init_db() -> None:
    """Create database tables for MVP/local usage."""
    # Import models here so metadata is fully registered before create_all.
    from daan.models.archetype import Archetype, Category, Prompt, PromptVersion, AuditLog
    from daan.models.role import Role, Permission, role_permission
    from daan.models.token_usage import TokenUsageEvent
    from daan.models.user import User
    from daan.models.archetype_assignment import UserArchetypeAssignment
    from daan.models.chat import ChatSession, ChatMessage
    from daan.archetypes.archetypes_service import create_default_archetypes
    from daan.models.user_mcp import UserMcpConfig, UserMcpSecret
    from daan.models.mcp_registry import McpServerRegistry, McpDiscoveryLog
    from daan.models.team import Team, TeamMember
    from daan.admin.team_service import ensure_global_team

    _ = (
        Archetype,
        Category,
        Prompt,
        PromptVersion,
        AuditLog,
        Role,
        User,
        Permission,
        role_permission,
        UserArchetypeAssignment,
        TokenUsageEvent,
        ChatSession,
        ChatMessage,
        UserMcpConfig,
        UserMcpSecret,
        McpServerRegistry,
        McpDiscoveryLog,
        Team,
        TeamMember,
    )
    Base.metadata.create_all(bind=engine)

    # Incremental migration: add columns that didn't exist in earlier versions.
    _add_missing_columns()

    db = SessionLocal()
    try:
        create_default_archetypes(db)
        ensure_global_team(db)
    finally:
        db.close()

    from daan.usecases.usecase_service import backfill_categories_from_usecases
    backfill_categories_from_usecases()
