"""Core configuration management for DAAN Framework."""
 
import os
import tempfile
from functools import lru_cache
from pathlib import Path
from threading import Lock
from typing import Any, List
 
import yaml
from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
 
 
ENV_FILE_PATH = Path(__file__).resolve().parents[3] / "config" / ".env"
DEFAULT_SQLITE_DB_PATH = Path(__file__).resolve().parents[1] / "daan.db"

# Serializes read-modify-write of the user KB sidecar across uvicorn worker threads.
_USER_KB_WRITE_LOCK = Lock()
 
 
class Settings(BaseSettings):
    """Application settings."""
 
    model_config = SettingsConfigDict(
        env_file=ENV_FILE_PATH,
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra='ignore'
    )
   
    # Application
    ENVIRONMENT: str = Field(default="development", pattern="^(development|staging|production)$")
    HOST: str = Field(default="0.0.0.0")
    PORT: int = Field(default=8000, ge=1, le=65535)
   
    # Security
    SECRET_KEY: str = Field(default="change-this-in-production")
    ALGORITHM: str = Field(default="HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(default=1140, ge=1)
    ALLOWED_HOSTS: List[str] = Field(default=["*"])
    
    # App DB
    # Primary app DB config names.
    APP_DB_TYPE: str = Field(default="sqlite")
    APP_DB_HOST: str | None = Field(default=None)
    APP_DB_PORT: int = Field(default=3306)
    APP_DB_NAME: str | None = Field(default=None)
    APP_DB_USER: str | None = Field(default=None)
    APP_DB_PASSWORD: str | None = Field(default=None)
    APP_DB_SSL_CA: str | None = Field(default=None)
    APP_DB_SCHEMA: str | None = Field(default=None)
    APP_DB_ENABLE_STARTUP_SQLITE_FALLBACK: bool = Field(default=True)

    # Legacy app DB config names kept for migration compatibility.
    LEGACY_DB_TYPE: str | None = Field(default=None, alias="DB_TYPE")
    LEGACY_DB_HOST: str | None = Field(default=None, alias="DB_HOST")
    LEGACY_DB_PORT: int | None = Field(default=None, alias="DB_PORT")
    LEGACY_DB_NAME: str | None = Field(default=None, alias="DB_NAME")
    LEGACY_DB_USER: str | None = Field(default=None, alias="DB_USER")
    LEGACY_DB_PASSWORD: str | None = Field(default=None, alias="DB_PASSWORD")

    # Older two-database layouts used DB1 for the app DB and DB2 for vector DB.
    LEGACY_DB1_TYPE: str | None = Field(default=None, alias="DB1_TYPE")
    LEGACY_DB1_HOST: str | None = Field(default=None, alias="DB1_HOST")
    LEGACY_DB1_PORT: int | None = Field(default=None, alias="DB1_PORT")
    LEGACY_DB1_NAME: str | None = Field(default=None, alias="DB1_NAME")
    LEGACY_DB1_USER: str | None = Field(default=None, alias="DB1_USER")
    LEGACY_DB1_PASSWORD: str | None = Field(default=None, alias="DB1_PASSWORD")

    LEGACY_DB2_TYPE: str | None = Field(default=None, alias="DB2_TYPE")
    LEGACY_DB2_HOST: str | None = Field(default=None, alias="DB2_HOST")
    LEGACY_DB2_PORT: int | None = Field(default=None, alias="DB2_PORT")
    LEGACY_DB2_NAME: str | None = Field(default=None, alias="DB2_NAME")
    LEGACY_DB2_USER: str | None = Field(default=None, alias="DB2_USER")
    LEGACY_DB2_PASSWORD: str | None = Field(default=None, alias="DB2_PASSWORD")
   

    # Vector DB

    # Primary vector DB config names.
    VECTOR_DB_TYPE: str = Field(default="postgresql")
    VECTOR_DB_HOST: str | None = Field(default=None)
    VECTOR_DB_PORT: int = Field(default=5432)
    VECTOR_DB_NAME: str | None = Field(default=None)
    VECTOR_DB_USER: str | None = Field(default=None)
    VECTOR_DB_PASSWORD: str | None = Field(default=None)
    VECTOR_DB_SSL_CA: str | None = Field(default=None)

    # URL-level overrides.
    APP_DATABASE_URL_OVERRIDE: str | None = Field(
        default=None,
        validation_alias=AliasChoices("APP_DATABASE_URL", "DATABASE_URL"),
    )
    VECTOR_DATABASE_URL_OVERRIDE: str | None = Field(default=None, alias="VECTOR_DATABASE_URL")

    @staticmethod
    def _has_any_database_parts(
        user: str | None,
        password: str | None,
        host: str | None,
        name: str | None,
    ) -> bool:
        return any(value is not None and str(value).strip() for value in (user, password, host, name))

    def _resolve_app_database_parts(self) -> tuple[str, str | None, str | None, str | None, int, str | None]:
        if self._has_any_database_parts(
            self.APP_DB_USER,
            self.APP_DB_PASSWORD,
            self.APP_DB_HOST,
            self.APP_DB_NAME,
        ):
            db_type = self.APP_DB_TYPE if str(self.APP_DB_TYPE or "").strip() else "mysql"
            if str(db_type).strip().lower() == "sqlite":
                db_type = "mysql"
            return (
                db_type,
                self.APP_DB_USER,
                self.APP_DB_PASSWORD,
                self.APP_DB_HOST,
                self.APP_DB_PORT,
                self.APP_DB_NAME,
            )

        if self._has_any_database_parts(
            self.LEGACY_DB_USER,
            self.LEGACY_DB_PASSWORD,
            self.LEGACY_DB_HOST,
            self.LEGACY_DB_NAME,
        ):
            return (
                self.LEGACY_DB_TYPE or "mysql",
                self.LEGACY_DB_USER,
                self.LEGACY_DB_PASSWORD,
                self.LEGACY_DB_HOST,
                self.LEGACY_DB_PORT or 3306,
                self.LEGACY_DB_NAME,
            )

        if str(self.LEGACY_DB1_TYPE or "").strip().lower() in {"mysql", "sqlite"}:
            return (
                self.LEGACY_DB1_TYPE,
                self.LEGACY_DB1_USER,
                self.LEGACY_DB1_PASSWORD,
                self.LEGACY_DB1_HOST,
                self.LEGACY_DB1_PORT or 3306,
                self.LEGACY_DB1_NAME,
            )

        return (
            self.APP_DB_TYPE,
            self.APP_DB_USER,
            self.APP_DB_PASSWORD,
            self.APP_DB_HOST,
            self.APP_DB_PORT,
            self.APP_DB_NAME,
        )
 
    def _resolve_vector_database_parts(self) -> tuple[str, str | None, str | None, str | None, int, str | None]:
        if self._has_any_database_parts(
            self.VECTOR_DB_USER,
            self.VECTOR_DB_PASSWORD,
            self.VECTOR_DB_HOST,
            self.VECTOR_DB_NAME,
        ):
            return (
                self.VECTOR_DB_TYPE,
                self.VECTOR_DB_USER,
                self.VECTOR_DB_PASSWORD,
                self.VECTOR_DB_HOST,
                self.VECTOR_DB_PORT,
                self.VECTOR_DB_NAME,
            )

        if str(self.LEGACY_DB1_TYPE or "").strip().lower() == "postgresql":
            return (
                self.LEGACY_DB1_TYPE,
                self.LEGACY_DB1_USER,
                self.LEGACY_DB1_PASSWORD,
                self.LEGACY_DB1_HOST,
                self.LEGACY_DB1_PORT or 5432,
                self.LEGACY_DB1_NAME,
            )

        if str(self.LEGACY_DB2_TYPE or "").strip().lower() == "postgresql":
            return (
                self.LEGACY_DB2_TYPE,
                self.LEGACY_DB2_USER,
                self.LEGACY_DB2_PASSWORD,
                self.LEGACY_DB2_HOST,
                self.LEGACY_DB2_PORT or 5432,
                self.LEGACY_DB2_NAME,
            )

        return (
            self.VECTOR_DB_TYPE,
            self.VECTOR_DB_USER,
            self.VECTOR_DB_PASSWORD,
            self.VECTOR_DB_HOST,
            self.VECTOR_DB_PORT,
            self.VECTOR_DB_NAME,
        )
 
    @property
    def APP_DATABASE_SSL_CA(self) -> str | None:
        return self.APP_DB_SSL_CA
    
    def _build_database_url(
        self,
        db_type: str,
        user: str | None,
        password: str | None,
        host: str | None,
        port: int,
        name: str | None,
    ) -> str:
        import urllib.parse
 
        normalized_type = str(db_type or "").strip().lower()
        if normalized_type not in {"mysql", "postgresql"}:
            return f"sqlite:///{DEFAULT_SQLITE_DB_PATH.as_posix()}"

        if not self._has_any_database_parts(user, password, host, name):
            return f"sqlite:///{DEFAULT_SQLITE_DB_PATH.as_posix()}"
 
        if not all([user, password, host, name]):
            raise ValueError(
                f"Database variables (user, password, host, name) are required when DB_TYPE={normalized_type}"
            )
 
        encoded_pwd = urllib.parse.quote_plus(str(password))
        scheme = "mysql+pymysql" if normalized_type == "mysql" else "postgresql+psycopg"
        return f"{scheme}://{user}:{encoded_pwd}@{host}:{int(port)}/{name}"
 
    @property
    def DATABASE_URL(self) -> str:
        """Application database URL used by the current MySQL-backed runtime."""
        if self.APP_DATABASE_URL_OVERRIDE and str(self.APP_DATABASE_URL_OVERRIDE).strip():
            return str(self.APP_DATABASE_URL_OVERRIDE).strip()
        db_type, user, password, host, port, name = self._resolve_app_database_parts()
        return self._build_database_url(
            db_type,
            user,
            password,
            host,
            port,
            name,
        )
 
    @property
    def VECTOR_DATABASE_URL(self) -> str:
        """Vector-store database URL used by pgvector."""
        if self.VECTOR_DATABASE_URL_OVERRIDE and str(self.VECTOR_DATABASE_URL_OVERRIDE).strip():
            return str(self.VECTOR_DATABASE_URL_OVERRIDE).strip()
        db_type, user, password, host, port, name = self._resolve_vector_database_parts()
        return self._build_database_url(
            db_type,
            user,
            password,
            host,
            port,
            name,
        )
 
    def get_vector_database_url(self) -> str | None:
        """Return the configured vector-store database URL when available.

        Unlike ``VECTOR_DATABASE_URL``, this helper is tolerant of missing VECTOR_DB_*
        configuration and returns ``None`` instead of raising. Use it in code paths
        that should remain startup-safe until a PostgreSQL vector store is actually needed.
        """
        if self.VECTOR_DATABASE_URL_OVERRIDE and str(self.VECTOR_DATABASE_URL_OVERRIDE).strip():
            return str(self.VECTOR_DATABASE_URL_OVERRIDE).strip()
 
        try:
            db_type, user, password, host, port, name = self._resolve_vector_database_parts()
            if str(db_type or "").strip().lower() != "postgresql":
                return None
            if not self._has_any_database_parts(user, password, host, name):
                return None
            return self._build_database_url(
                db_type,
                user,
                password,
                host,
                port,
                name,
            )
        except ValueError:
            return None
 
    # Data root directory
    DATA_DIR: str = Field(default="data")
   
    # CosmosDB Gremlin account connection (key + endpoint) — loaded from config/.env.
    # Per-knowledge-base graph/database are configured in config/rag_config.yml, not here.
    GREMLIN_KEY: str = Field(default="")
    GREMLIN_ENDPOINT: str = Field(default="")

    # Cosmos graph auto-provisioning. Uses the same account key as Gremlin against
    # the HTTPS documents endpoint, so no Azure AD service principal is needed.
    COSMOS_GRAPH_AUTO_CREATE: bool = Field(default=False)
    # Database that new per-KB graphs are created in (shared by all KBs).
    COSMOS_DEFAULT_DATABASE: str = Field(default="")
    # 0 leaves throughput unset, which is required for serverless accounts and for
    # databases that provide shared throughput to their containers.
    COSMOS_GRAPH_THROUGHPUT: int = Field(default=0)
 

    # KuzuDB knowledge-graph store path (optional override; defaults to data/knowledge_graph_db)
    KUZU_DB_PATH: str | None = Field(default=None)

    # Session storage directory (disk-backed session artifacts)
    SESSION_STORAGE_DIR: str = Field(default="session_storage")
 
    # RAG config
    rag_config_path: str = Field(default="config/rag_config.yml")
    # KBs created at runtime from the UI live here, not in the hand-maintained rag_config.yml.
    user_kb_config_path: str = Field(default="config/rag_config_user_kbs.yml")
 
 
    # Legacy planner temp directory (kept for backward compatibility)
    PLANNER_TEMP_DIR: str = Field(default=os.path.join(tempfile.gettempdir(), "daan_planner"))
   
    # MCP Credential encryption
    MCP_ENCRYPTION_KEY: str | None = Field(default=None)
    MCP_DECRYPT_RATE_LIMIT: int = Field(default=60)
    MCP_DECRYPT_RATE_WINDOW: int = Field(default=60)
 
    # Logging
    LOG_LEVEL: str = Field(default="INFO", pattern="^(DEBUG|INFO|WARNING|ERROR|CRITICAL)$")
    ENABLE_API_DOCS: bool = Field(default=False)
   
    def load_yaml_config(self, config_path: str) -> dict[str, Any]:
        """Load YAML config relative to project root if needed."""
        path = Path(config_path)
        if not path.is_absolute():
            path = Path(__file__).resolve().parents[3] / path
        if not path.exists():
            return {}
        with path.open("r", encoding="utf-8") as handle:
            return yaml.safe_load(handle) or {}

    def resolve_config_path(self, config_path: str) -> Path:
        """Resolve a config path the same way load_yaml_config does."""
        path = Path(config_path)
        if not path.is_absolute():
            path = Path(__file__).resolve().parents[3] / path
        return path

    def cosmos_provisioning_ready(self) -> tuple[bool, list[str]]:
        """Return whether Cosmos auto-provisioning is configured, plus any missing settings."""
        required = {
            "COSMOS_DEFAULT_DATABASE": self.COSMOS_DEFAULT_DATABASE,
            "GREMLIN_ENDPOINT": self.GREMLIN_ENDPOINT,
            "GREMLIN_KEY": self.GREMLIN_KEY,
        }
        missing = [name for name, value in required.items() if not str(value).strip()]
        return (not missing and self.COSMOS_GRAPH_AUTO_CREATE), missing

    def load_user_knowledge_bases(self) -> list[dict[str, Any]]:
        """Return KB entries created at runtime from the UI."""
        payload = self.load_yaml_config(self.user_kb_config_path)
        entries = payload.get("knowledge_bases") if isinstance(payload, dict) else None
        if not isinstance(entries, list):
            return []
        return [dict(entry) for entry in entries if isinstance(entry, dict) and entry.get("id")]

    def append_user_knowledge_base(self, entry: dict[str, Any]) -> dict[str, Any]:
        """Append a runtime-created KB to the sidecar file, rejecting duplicate ids.

        Raises:
            ValueError: If a KB with the same id already exists.
        """
        kb_id = str(entry.get("id") or "").strip()
        if not kb_id:
            raise ValueError("Knowledge base id is required.")

        with _USER_KB_WRITE_LOCK:
            existing = self.load_user_knowledge_bases()
            if any(str(item.get("id") or "").strip().casefold() == kb_id.casefold() for item in existing):
                raise ValueError(f"Knowledge base '{kb_id}' already exists.")
            existing.append(dict(entry))
            self._write_user_knowledge_bases(existing)
        return dict(entry)

    def remove_user_knowledge_base(self, kb_id: str) -> bool:
        """Remove a runtime-created KB from the sidecar file. Returns True if removed."""
        normalized = str(kb_id or "").strip()
        if not normalized:
            return False

        with _USER_KB_WRITE_LOCK:
            existing = self.load_user_knowledge_bases()
            remaining = [
                item
                for item in existing
                if str(item.get("id") or "").strip().casefold() != normalized.casefold()
            ]
            if len(remaining) == len(existing):
                return False
            self._write_user_knowledge_bases(remaining)
        return True

    def set_user_knowledge_base_enabled(self, kb_id: str, enabled: bool) -> bool:
        """Soft-delete/restore: flip a runtime-created KB's `enabled` flag in place.

        Unlike `remove_user_knowledge_base`, this never touches indexed data — it only
        hides (enabled=False) or restores (enabled=True) the config entry. Returns True
        if a matching entry was found and updated.
        """
        normalized = str(kb_id or "").strip()
        if not normalized:
            return False

        with _USER_KB_WRITE_LOCK:
            existing = self.load_user_knowledge_bases()
            updated = False
            for item in existing:
                if str(item.get("id") or "").strip().casefold() == normalized.casefold():
                    item["enabled"] = enabled
                    updated = True
                    break
            if not updated:
                return False
            self._write_user_knowledge_bases(existing)
        return True

    def _write_user_knowledge_bases(self, entries: list[dict[str, Any]]) -> None:
        """Write the sidecar file atomically so a partial write is never read back."""
        path = self.resolve_config_path(self.user_kb_config_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(
            "w", encoding="utf-8", dir=str(path.parent), delete=False, suffix=".tmp"
        ) as handle:
            yaml.safe_dump(
                {"knowledge_bases": entries},
                handle,
                sort_keys=False,
                allow_unicode=True,
                default_flow_style=False,
                width=4096,
            )
            temp_path = Path(handle.name)
        os.replace(temp_path, path)
 
    def load_rag_config(self) -> dict[str, Any]:
        """Load RAG config, merged with any KBs created at runtime from the UI."""
        config = self.load_yaml_config(self.rag_config_path)
        user_kbs = self.load_user_knowledge_bases()
        if not user_kbs:
            return config

        configured = list(config.get("knowledge_bases") or [])
        known_ids = {str(kb.get("id") or "").strip().casefold() for kb in configured if isinstance(kb, dict)}
        configured.extend(
            kb for kb in user_kbs if str(kb.get("id") or "").strip().casefold() not in known_ids
        )
        config["knowledge_bases"] = configured
        return config
 
@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()
 