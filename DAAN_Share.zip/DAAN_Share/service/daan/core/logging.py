"""Structured logging configuration for DAAN Framework.

Implements:
- System logs: plaintext logs to terminal + timestamped plaintext logfile under
    `system logs/` at the repo root.
- Session logs: plaintext logs to `session_storage/<session_id>/session.log`.
    Only log records that carry a `session_id` attribute are written there.
- Print capture: tee stdout/stderr so existing print() output is also written
    to the system logfile, without changing call sites.
"""

from __future__ import annotations

import io
import logging
import re
import sys
import threading
from collections import OrderedDict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional, TextIO

from daan.core.config import get_settings


_DATEFMT = "%Y-%m-%d %H:%M:%S"


_STANDARD_LOG_RECORD_ATTRS = set(
    logging.LogRecord(name="", level=0, pathname="", lineno=0, msg="", args=(), exc_info=None).__dict__.keys()
)
_STANDARD_LOG_RECORD_ATTRS.update({"asctime", "message"})


def _project_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _system_logs_root() -> Path:
    # Folder name as requested.
    return _project_root() / "system logs"


def _session_storage_root() -> Path:
    """Get session storage root path using the same logic as session_service."""
    settings = get_settings()
    path = Path(settings.SESSION_STORAGE_DIR)
    if not path.is_absolute():
        project_root = _project_root()
        path = project_root / path
    return path


def _local_now_str() -> str:
    return datetime.now().strftime(_DATEFMT)


def _timestamp_filename() -> str:
    return datetime.now().strftime("%m_%d_%Y_%H_%M_%S") + ".log"


def _sanitize_session_id(session_id: str) -> str:
    value = (session_id or "").strip()
    if not value:
        return "unknown_session"

    # Strict allowlist to prevent path traversal / special chars.
    value = re.sub(r"[^A-Za-z0-9_-]+", "_", value)
    value = value.strip("._")
    return value or "unknown_session"


class PlainTextFormatter(logging.Formatter):
    def __init__(self) -> None:
        super().__init__(datefmt=_DATEFMT)

    def format(self, record: logging.LogRecord) -> str:
        asctime = self.formatTime(record, self.datefmt)
        base = f"{asctime} | {record.levelname} | {record.name} | {record.getMessage()}"

        extras: list[str] = []
        for key, value in record.__dict__.items():
            if key in _STANDARD_LOG_RECORD_ATTRS:
                continue
            if value is None:
                continue
            extras.append(f"{key}={value!r}")

        if extras:
            return base + " | " + " ".join(extras)
        return base


class SessionLogHandler(logging.Handler):
    """Writes records that contain `session_id` to session_storage/<session_id>/session.log."""

    def __init__(self, max_open_files: int = 64) -> None:
        super().__init__()
        self._max_open_files = max(8, int(max_open_files))
        self._streams: "OrderedDict[str, TextIO]" = OrderedDict()
        self._streams_lock = threading.Lock()

    def _extract_session_id(self, record: logging.LogRecord) -> str | None:
        sid = getattr(record, "session_id", None)
        if sid is None:
            return None
        value = str(sid).strip()
        if not value or value == "unknown_session":
            return None
        return value

    def _get_stream(self, session_id: str) -> TextIO:
        safe = _sanitize_session_id(session_id)
        with self._streams_lock:
            existing = self._streams.get(safe)
            if existing is not None:
                self._streams.move_to_end(safe)
                return existing

            # Sub-sessions have the form "{base}__{agent}__{iter}" (loops) or
            # "{base}__{agent}" (stage per-agent runs). Nest them inside the parent
            # session folder instead of creating siblings.
            parts = safe.split("__", 2)
            if len(parts) == 3:
                base, agent, iteration = parts
                session_dir = _session_storage_root() / base / "agents" / agent / iteration
            elif len(parts) == 2:
                base, agent = parts
                session_dir = _session_storage_root() / base / "agents" / agent
            else:
                session_dir = _session_storage_root() / safe
            session_dir.mkdir(parents=True, exist_ok=True)
            path = session_dir / "session.log"
            stream = open(path, mode="a", encoding="utf-8", buffering=1)
            self._streams[safe] = stream

            while len(self._streams) > self._max_open_files:
                _, old_stream = self._streams.popitem(last=False)
                try:
                    old_stream.close()
                except Exception:
                    pass
            return stream

    def emit(self, record: logging.LogRecord) -> None:
        try:
            session_id = self._extract_session_id(record)
            if not session_id:
                return
            stream = self._get_stream(session_id)
            payload = self.format(record)
            stream.write(payload + "\n")
            stream.flush()
        except Exception:
            self.handleError(record)


@dataclass
class _PrintCaptureConfig:
    system_file_handler: logging.Handler
    original_stream: TextIO
    stream_name: str  # "stdout" | "stderr"


class _PrintCaptureStream(io.TextIOBase):
    """Tee sys.stdout/sys.stderr to terminal + system log file.

    Writes plaintext events into the system logfile, using the *same* file stream
    and lock as the system file handler to avoid line interleaving.
    """

    def __init__(self, cfg: _PrintCaptureConfig) -> None:
        super().__init__()
        self._cfg = cfg
        self._buffer = ""

    def __getattr__(self, name: str):  # pragma: no cover
        # Delegate stream capabilities (e.g., fileno/isatty/buffer/encoding).
        return getattr(self._cfg.original_stream, name)

    def writable(self) -> bool:  # pragma: no cover
        return True

    def write(self, s: str) -> int:
        text = str(s)
        # Always write through to the original stream first.
        self._cfg.original_stream.write(text)
        self._cfg.original_stream.flush()

        self._buffer += text
        if "\n" not in self._buffer:
            return len(text)

        lines = self._buffer.split("\n")
        self._buffer = lines.pop()  # keep partial tail

        for line in lines:
            self._write_plain_event(line)

        return len(text)

    def flush(self) -> None:
        try:
            self._cfg.original_stream.flush()
        except Exception:
            pass

    def _write_plain_event(self, line: str) -> None:
        # Skip empty lines to reduce noise.
        if line is None:
            return
        stripped = str(line).rstrip("\r")
        if stripped == "":
            return

        event = "STDOUT" if self._cfg.stream_name == "stdout" else "STDERR"
        rendered = f"{_local_now_str()} | {event} | {stripped}"

        handler = self._cfg.system_file_handler
        # Use the same lock as the handler to reduce interleaving.
        lock = getattr(handler, "lock", None)
        stream = getattr(handler, "stream", None)

        if lock is None or stream is None:
            return

        try:
            lock.acquire()
            stream.write(rendered + "\n")
            stream.flush()
        finally:
            try:
                lock.release()
            except Exception:
                pass


def setup_structured_logging(
    *,
    log_level: str = "INFO",
) -> logging.Logger:
    """Configure system + session logging and stdout/stderr capture.

    Must be called exactly once at service startup.
    Returns a stdlib logger named "daan".
    """

    system_dir = _system_logs_root()
    system_dir.mkdir(parents=True, exist_ok=True)

    system_log_path = system_dir / _timestamp_filename()

    # Keep original streams to avoid recursion when we later wrap sys.stdout.
    original_stdout = sys.stdout
    original_stderr = sys.stderr

    # Shared system log stream (used by both system logs and print capture).
    system_stream = open(system_log_path, mode="a", encoding="utf-8", buffering=1)

    formatter = PlainTextFormatter()

    system_console_handler = logging.StreamHandler(stream=original_stdout)
    system_console_handler.setFormatter(formatter)

    system_file_handler = logging.StreamHandler(stream=system_stream)
    system_file_handler.setFormatter(formatter)

    session_handler = SessionLogHandler()
    session_handler.setFormatter(formatter)

    logging.basicConfig(
        level=getattr(logging, str(log_level or "INFO").upper(), logging.INFO),
        handlers=[system_console_handler, system_file_handler, session_handler],
        force=True,
    )

    # Ensure common framework loggers flow into the root handlers.
    for logger_name in ("uvicorn", "uvicorn.error", "uvicorn.access", "fastapi"):
        try:
            lg = logging.getLogger(logger_name)
            lg.handlers.clear()
            lg.propagate = True
        except Exception:
            pass

    # Capture print() output into the system logfile without editing print call sites.
    sys.stdout = _PrintCaptureStream(
        _PrintCaptureConfig(
            system_file_handler=system_file_handler,
            original_stream=original_stdout,
            stream_name="stdout",
        )
    )
    sys.stderr = _PrintCaptureStream(
        _PrintCaptureConfig(
            system_file_handler=system_file_handler,
            original_stream=original_stderr,
            stream_name="stderr",
        )
    )

    return logging.getLogger("daan")


# Public API functions
def setup_logging() -> logging.Logger:
    """Setup application logging configuration (system + audit + print capture)."""
    settings = get_settings()
    return setup_structured_logging(log_level=settings.LOG_LEVEL)


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """Get a logger instance."""
    return logging.getLogger(name or "daan")


class LoggingMixin:
    """Mixin class to add logging capability to any class."""

    @property
    def logger(self) -> logging.Logger:
        """Get logger for this class."""
        return get_logger(self.__class__.__name__)