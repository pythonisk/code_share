"""Observer helpers for ADK agents (reasoning stream, etc.)."""
