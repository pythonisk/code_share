"""
Reasoning observer — captures a Claude/LLM agent's Thought / Action / Observation
events via ADK model + tool callbacks and pushes them onto a per-session
asyncio bus. A future SSE endpoint drains the bus and streams events to the UI.

This module is pure plumbing: it never mutates LlmResponse / tool responses and
never raises out of the callbacks (all failures are logged and swallowed) so it
cannot break the agent's normal execution.

Event schema (v1):
    { "v": 1, "type": <event_type>, "seq": <int>, "ts": <epoch_float>,
      "session_id": <str>, "agent_id": <str>, "agent_name": <str>, ... }

Event types emitted here:
    - thought          Model's internal reasoning (text redacted unless expose_thoughts=True).
    - action           Model called a tool (function_call).
    - token            Model produced (partial) answer text.
    - observation      Tool returned a result.
    - agent_complete   A single ADK Agent's run finished.
Additional lifecycle events (stage_complete, final, error) are emitted by the
runner / SSE endpoint, not by these callbacks.
"""

from __future__ import annotations

import asyncio
import dataclasses
import logging
import time
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)

_SCHEMA_VERSION = 1
# Bus is auto-closed if never touched for this many seconds (lazy sweep on
# get_or_create_bus). Safety net; not a substitute for endpoint-level cleanup.
_DEFAULT_TTL_SECONDS = 900
_TOOL_RESULT_CAP = 2000


# ── Module metrics (lightweight counters; no external dep). ─────────────────────
_METRICS: dict[str, int] = {
    "observer_errors": 0,
    "buses_active": 0,
    "buses_swept": 0,
    "subscribers_total": 0,
    "subscribers_active": 0,
}

# Idle wait between scans of the append-only event log inside subscribe().
# List append is atomic under CPython's GIL, so scanning is thread-safe even
# when emit() is called from a LiteLLM callback running in a threadpool.
_SUBSCRIBE_POLL_SECONDS = 0.05
# Emitted by subscribe() when the log has been idle long enough that the
# SSE caller should send a heartbeat frame to keep proxies alive.
_SUBSCRIBE_HEARTBEAT_SECONDS = 10.0
HEARTBEAT_SENTINEL: dict[str, Any] = {"__heartbeat__": True}


def get_reasoning_metrics() -> dict[str, int]:
    """Snapshot of module-level counters for observability / debugging."""
    return dict(_METRICS)


# ── JSON normalization ─────────────────────────────────────────────────────────


def _to_jsonable(value: Any, _depth: int = 0) -> Any:
    """Recursively convert google.genai / pydantic / dataclass / arbitrary objects
    into JSON-safe primitives so the SSE endpoint can serialize the event."""
    if _depth > 6:
        return "…[depth-cap]"
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (list, tuple, set)):
        return [_to_jsonable(v, _depth + 1) for v in value]
    if isinstance(value, dict):
        return {str(k): _to_jsonable(v, _depth + 1) for k, v in value.items()}
    if dataclasses.is_dataclass(value):
        return _to_jsonable(dataclasses.asdict(value), _depth + 1)
    # pydantic v2 / v1 model
    dump = getattr(value, "model_dump", None) or getattr(value, "dict", None)
    if callable(dump):
        try:
            return _to_jsonable(dump(), _depth + 1)
        except Exception:
            pass
    # google.genai proto-lite objects usually expose a `to_dict` / `to_json_dict`.
    for meth in ("to_json_dict", "to_dict"):
        fn = getattr(value, meth, None)
        if callable(fn):
            try:
                return _to_jsonable(fn(), _depth + 1)
            except Exception:
                pass
    try:
        return str(value)
    except Exception:
        return repr(value)


def _cap_str(value: Any, limit: int) -> str:
    if value is None:
        return ""
    text = value if isinstance(value, str) else str(value)
    return text if len(text) <= limit else text[:limit] + "…[truncated]"


def _cap_jsonable(value: Any, limit: int) -> Any:
    """Normalize then size-cap by encoded length (rough)."""
    norm = _to_jsonable(value)
    try:
        import json as _json

        encoded = _json.dumps(norm, default=str)
    except Exception:
        return _cap_str(norm, limit)
    if len(encoded) <= limit:
        return norm
    return _cap_str(encoded, limit)


# ── The bus ────────────────────────────────────────────────────────────────────


class ReasoningEventBus:
    """Per-session append-only event log with a monotonic cursor.

    Producers (ADK callbacks + agent_runner loop) call ``emit()`` to append.
    Consumers call ``events_since(after_seq)`` to fetch events with seq > cursor.
    """

    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        self._events: list[dict[str, Any]] = []
        self._closed = False
        self._seq = 0
        self._created_at = time.time()
        self._last_touch = self._created_at
        self._active_subscribers = 0

    def emit(self, event_type: str, payload: dict[str, Any] | None = None) -> None:
        """Append an event to the log. Safe to call from any thread."""
        if self._closed:
            return
        self._last_touch = time.time()
        event: dict[str, Any] = {
            "v": _SCHEMA_VERSION,
            "type": event_type,
            "seq": self._seq,
            "ts": self._last_touch,
            "session_id": self.session_id,
        }
        if payload:
            event.update(payload)
        self._seq += 1
        # list.append is atomic under CPython's GIL — this is the only sync
        # primitive we need for cross-thread producers.
        self._events.append(event)

    def events_since(self, after_seq: int = -1) -> list[dict[str, Any]]:
        """Return all events with seq > after_seq (polling cursor)."""
        self._last_touch = time.time()
        if after_seq < 0:
            return list(self._events)
        # Events are ordered by insertion so linear scan is fine at N ~ thousands.
        return [e for e in self._events if e["seq"] > after_seq]

    async def subscribe(self, after_seq: int = -1):
        """Async iterator: replay events since ``after_seq``, then live-tail.

        Implementation scans the append-only ``_events`` list on a short idle
        wait. This is thread-safe regardless of which thread called ``emit()``
        because ``list.append`` is atomic under CPython's GIL. No per-subscriber
        queue → no cross-thread ``put_nowait`` race, no queue-overflow drops.

        Yields ``HEARTBEAT_SENTINEL`` when the log has been idle for
        ``_SUBSCRIBE_HEARTBEAT_SECONDS`` so the SSE endpoint can drive its
        keep-alive without wrapping ``__anext__`` in ``asyncio.wait_for`` —
        which would cancel and invalidate this generator on every timeout.
        """
        last_seq = after_seq
        last_yield_ts = time.time()
        self._active_subscribers += 1
        _METRICS["subscribers_total"] += 1
        _METRICS["subscribers_active"] = sum(
            b._active_subscribers for b in _BUSES.values()
        )
        try:
            while True:
                pending = self.events_since(last_seq)
                if pending:
                    for event in pending:
                        yield event
                        last_seq = event["seq"]
                    last_yield_ts = time.time()
                    continue
                if self._closed:
                    return
                if (time.time() - last_yield_ts) >= _SUBSCRIBE_HEARTBEAT_SECONDS:
                    yield HEARTBEAT_SENTINEL
                    last_yield_ts = time.time()
                    continue
                await asyncio.sleep(_SUBSCRIBE_POLL_SECONDS)
        finally:
            self._active_subscribers = max(0, self._active_subscribers - 1)
            _METRICS["subscribers_active"] = sum(
                b._active_subscribers for b in _BUSES.values()
            )

    def close(self) -> None:
        """Mark closed; live subscribers exit on their next idle tick."""
        self._closed = True


# ── Registry keyed by session_id (in-memory). ──────────────────────────────────
_BUSES: dict[str, ReasoningEventBus] = {}


def _sweep_stale_buses(now: float, ttl_seconds: int) -> None:
    """Lazy TTL sweep. Closes buses untouched for `ttl_seconds`."""
    stale = [
        sid
        for sid, bus in _BUSES.items()
        if (now - bus._last_touch) > ttl_seconds
    ]
    for sid in stale:
        bus = _BUSES.pop(sid, None)
        if bus is not None:
            bus.close()
            _METRICS["buses_swept"] += 1
    if stale:
        logger.info("Swept %d stale reasoning bus(es)", len(stale))


def get_or_create_bus(
    session_id: str, *, ttl_seconds: int = _DEFAULT_TTL_SECONDS
) -> ReasoningEventBus:
    now = time.time()
    _sweep_stale_buses(now, ttl_seconds)
    bus = _BUSES.get(session_id)
    if bus is None or bus._closed:
        bus = ReasoningEventBus(session_id)
        _BUSES[session_id] = bus
        _METRICS["buses_active"] = len(_BUSES)
    return bus


def get_bus(session_id: str) -> Optional[ReasoningEventBus]:
    return _BUSES.get(session_id)


def discard_bus(session_id: str) -> None:
    bus = _BUSES.pop(session_id, None)
    if bus is not None:
        bus.close()
    _METRICS["buses_active"] = len(_BUSES)


# ── Part inspection helpers ────────────────────────────────────────────────────


# ── Callback factory ───────────────────────────────────────────────────────────


def build_reasoning_callbacks(
    session_id: str,
    agent_id: str = "",
    agent_name: str = "",
    *,
    redactor: Optional[Callable[[str, dict[str, Any]], dict[str, Any]]] = None,
) -> dict[str, Any]:
    """Build ADK callback kwargs that emit reasoning lifecycle events to the session bus."""
    bus = get_or_create_bus(session_id)
    meta = {"agent_id": agent_id, "agent_name": agent_name}
    apply_redactor = redactor or (lambda _t, p: p)

    def _emit(event_type: str, payload: dict[str, Any]) -> None:
        try:
            bus.emit(event_type, apply_redactor(event_type, payload))
        except Exception as exc:
            _METRICS["observer_errors"] += 1
            logger.debug("reasoning emit failed for %s: %s", event_type, exc)

    async def before_agent_callback(callback_context):  # type: ignore[no-untyped-def]
        try:
            _emit("agent_start", meta)
        except Exception as exc:
            _METRICS["observer_errors"] += 1
            logger.debug("reasoning before_agent observer failed: %s", exc)
        return None

    async def before_model_callback(callback_context, llm_request):  # type: ignore[no-untyped-def]
        try:
            _emit("model_call_start", {**meta, "text": "calling model…"})
        except Exception as exc:
            _METRICS["observer_errors"] += 1
            logger.debug("reasoning before_model observer failed: %s", exc)
        return None

    async def after_model_callback(callback_context, llm_response):  # type: ignore[no-untyped-def]
        # Streaming thoughts/actions are emitted by agent_runner._emit_partial_event_to_bus
        # to avoid duplicate rows; `model_call_end` is emitted by the LiteLLM
        # CustomLogger's success hook.
        return None

    async def after_tool_callback(tool, args, tool_context, tool_response):  # type: ignore[no-untyped-def]
        try:
            tool_name = getattr(tool, "name", None) or str(tool)
            _emit("observation", {
                **meta,
                "tool": str(tool_name),
                "result": _cap_jsonable(tool_response, _TOOL_RESULT_CAP),
            })
        except Exception as exc:
            _METRICS["observer_errors"] += 1
            logger.debug("reasoning after_tool observer failed: %s", exc)
        return None

    async def after_agent_callback(callback_context):  # type: ignore[no-untyped-def]
        # agent_complete is emitted by the workflow endpoint per ran_agent to
        # avoid duplicates. Kept as a stub so the composition path is preserved.
        return None

    return {
        "before_agent_callback": before_agent_callback,
        "before_model_callback": before_model_callback,
        "after_model_callback": after_model_callback,
        "after_tool_callback": after_tool_callback,
        "after_agent_callback": after_agent_callback,
    }


# ─────────────────────────── Callback composition ───────────────────────────────


def _wrap_after_model(observer_cb, existing_cb):
    """Run observer first (side-effect only), then delegate to existing callback."""

    async def combined(callback_context, llm_response):  # type: ignore[no-untyped-def]
        try:
            await observer_cb(callback_context, llm_response)
        except Exception as exc:
            logger.debug("reasoning after_model observer chain failed: %s", exc)
        return await existing_cb(callback_context, llm_response)

    return combined


def _wrap_after_agent(observer_cb, existing_cb):
    async def combined(callback_context):  # type: ignore[no-untyped-def]
        try:
            await observer_cb(callback_context)
        except Exception as exc:
            logger.debug("reasoning after_agent observer chain failed: %s", exc)
        return await existing_cb(callback_context)

    return combined


def _wrap_after_tool(observer_cb, existing_cb):
    async def combined(tool, args, tool_context, tool_response):  # type: ignore[no-untyped-def]
        try:
            await observer_cb(tool, args, tool_context, tool_response)
        except Exception as exc:
            logger.debug("reasoning after_tool observer chain failed: %s", exc)
        return await existing_cb(tool, args, tool_context, tool_response)

    return combined


_WRAPPERS = {
    "after_model_callback": _wrap_after_model,
    "after_agent_callback": _wrap_after_agent,
    "after_tool_callback": _wrap_after_tool,
}


def compose_callback_kwargs(
    base_kwargs: dict[str, Any],
    observer_kwargs: dict[str, Any],
) -> dict[str, Any]:
    """Merge observer callbacks with existing (e.g. guardrail) callbacks.

    When a hook key exists in both dicts, the observer runs first (side-effect
    only, return value ignored) and then the base callback runs and its return
    value is honored — so guardrails retain full control over blocking/mutation.
    """
    if not observer_kwargs:
        return dict(base_kwargs)
    merged: dict[str, Any] = dict(base_kwargs)
    for key, observer_cb in observer_kwargs.items():
        existing = merged.get(key)
        if existing is None:
            merged[key] = observer_cb
            continue
        wrapper = _WRAPPERS.get(key)
        if wrapper is None:
            # Unknown hook — prefer existing to avoid surprising behavior.
            continue
        merged[key] = wrapper(observer_cb, existing)
    return merged
