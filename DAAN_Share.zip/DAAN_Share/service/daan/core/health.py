"""Health check endpoints for DAAN Framework."""

from datetime import datetime
from typing import Dict

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sqlalchemy import text

from daan.core.database import SessionLocal

health_router = APIRouter(prefix="/health", tags=["Health"])


class HealthResponse(BaseModel):
    """Simple health response for service monitoring."""

    status: str
    timestamp: datetime
    database: str


def check_database() -> str:
    """Run a lightweight DB ping query and return status."""
    try:
        with SessionLocal() as session:
            session.execute(text("SELECT 1"))
        return "healthy"
    except Exception:
        return "unhealthy"


@health_router.get("/", response_model=HealthResponse)
def health_check() -> HealthResponse:
    """General health endpoint used by humans and monitors."""
    db_status = check_database()
    overall = "healthy" if db_status == "healthy" else "degraded"
    return HealthResponse(status=overall, timestamp=datetime.utcnow(), database=db_status)



