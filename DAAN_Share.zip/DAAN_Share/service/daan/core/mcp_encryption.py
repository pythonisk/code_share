"""Fernet-based encryption and rate-limited decryption for MCP credentials."""

import hashlib
import json
import logging
import time
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Any

from cryptography.fernet import Fernet, InvalidToken

from daan.core.exceptions import DAANException

logger = logging.getLogger(__name__)


class RateLimiter:
    """Simple in-memory rate limiter for decryption operations."""

    def __init__(self, max_requests: int, time_window: int):
        """Initialize rate limiter.

        Args:
            max_requests: Maximum number of requests allowed in time window
            time_window: Time window in seconds
        """
        self.max_requests = max_requests
        self.time_window = time_window
        self._requests: defaultdict[str, list[float]] = defaultdict(list)

    def check_rate_limit(self, key: str) -> bool:
        """Check if rate limit is exceeded.

        Args:
            key: Identifier for rate limiting (e.g., user_id)

        Returns:
            True if within rate limit, False if exceeded
        """
        now = time.time()
        cutoff = now - self.time_window

        # Remove old entries
        self._requests[key] = [req_time for req_time in self._requests[key] if req_time > cutoff]

        # Check if limit exceeded
        if len(self._requests[key]) >= self.max_requests:
            return False

        # Add new request
        self._requests[key].append(now)
        return True

    def get_remaining(self, key: str) -> int:
        """Get remaining requests allowed."""
        now = time.time()
        cutoff = now - self.time_window
        self._requests[key] = [req_time for req_time in self._requests[key] if req_time > cutoff]
        return max(0, self.max_requests - len(self._requests[key]))

    def get_retry_after(self, key: str) -> int:
        """Get seconds until rate limit resets."""
        if not self._requests[key]:
            return 0
        oldest = min(self._requests[key])
        reset_time = oldest + self.time_window
        return max(0, int(reset_time - time.time()))


class CredentialCipher:
    """Service for encrypting and decrypting MCP credentials.

    Uses Fernet symmetric encryption with keys from Azure Key Vault.
    Supports key rotation and rate limiting.
    """

    def __init__(
        self,
        encryption_key: str | None = None,
        rate_limit_requests: int = 60,
        rate_limit_window: int = 60,
    ):
        """Initialize credential cipher.

        Args:
            encryption_key: Base64-encoded Fernet key (from MCP_ENCRYPTION_KEY env var)
            rate_limit_requests: Max decryption requests per window
            rate_limit_window: Rate limit time window in seconds
        """
        self.encryption_key = encryption_key
        self._key_cache: dict[int, bytes] = {}

        # Rate limiter for decryption operations
        self.rate_limiter = RateLimiter(rate_limit_requests, rate_limit_window)

        logger.info(
            f"CredentialCipher initialized (RateLimit: {rate_limit_requests}/{rate_limit_window}s)"
        )

    def _get_encryption_key(self, version: int = 1) -> bytes:
        """Get encryption key for the specified version.

        Args:
            version: Key version number

        Returns:
            Encryption key as bytes

        Raises:
            EncryptionFailedException: If key cannot be retrieved
        """
        # Check cache first
        if version in self._key_cache:
            return self._key_cache[version]

        try:
            if not self.encryption_key:
                raise DAANException.encryption_failed(
                    "No encryption key available. Set MCP_ENCRYPTION_KEY in your .env file."
                )

            import base64
            key = self.encryption_key.strip().encode("utf-8")

            self._key_cache[version] = key
            return key

        except DAANException:
            raise
        except Exception as e:
            logger.error(f"Failed to retrieve encryption key version {version}: {e}")
            raise DAANException.encryption_failed(f"Failed to retrieve encryption key: {str(e)}") from e

    def encrypt(self, credentials: dict[str, Any], key_version: int = 1) -> tuple[str, str]:
        """Encrypt credentials dictionary.

        Args:
            credentials: Dictionary of credential fields
            key_version: Version of encryption key to use

        Returns:
            Tuple of (encrypted_data, credential_hash)

        Raises:
            EncryptionFailedException: If encryption fails
        """
        try:
            # Serialize credentials to JSON
            credential_json = json.dumps(credentials, sort_keys=True)
            credential_bytes = credential_json.encode("utf-8")

            # Get encryption key
            key = self._get_encryption_key(key_version)

            # Encrypt using Fernet
            fernet = Fernet(key)
            encrypted_data = fernet.encrypt(credential_bytes)

            # Generate credential hash for breach detection
            credential_hash = hashlib.sha256(credential_bytes).hexdigest()

            logger.info(f"Encrypted credentials (key_version={key_version})")
            return encrypted_data.decode("utf-8"), credential_hash

        except Exception as e:
            logger.error(f"Encryption failed: {e}")
            raise DAANException.encryption_failed(f"Failed to encrypt credentials: {str(e)}") from e

    def decrypt(
        self,
        encrypted_data: str,
        key_version: int = 1,
        user_id: int | None = None,
        check_rate_limit: bool = True,
    ) -> dict[str, Any]:
        """Decrypt credentials.

        Args:
            encrypted_data: Encrypted credential data (base64 string)
            key_version: Version of encryption key used
            user_id: User ID for rate limiting
            check_rate_limit: Enable rate limit checking

        Returns:
            Decrypted credentials as dictionary

        Raises:
            DecryptionFailedException: If decryption fails
            RateLimitExceededException: If rate limit exceeded
        """
        # Check rate limit
        if check_rate_limit and user_id is not None:
            rate_key = f"decrypt_{user_id}"
            if not self.rate_limiter.check_rate_limit(rate_key):
                retry_after = self.rate_limiter.get_retry_after(rate_key)
                logger.warning(f"Rate limit exceeded for user {user_id}")
                raise DAANException.rate_limit_exceeded(
                    operation="credential_decryption",
                    limit=self.rate_limiter.max_requests,
                    retry_after=retry_after,
                )

        try:
            # Get decryption key
            key = self._get_encryption_key(key_version)

            # Decrypt using Fernet
            fernet = Fernet(key)
            encrypted_bytes = encrypted_data.encode("utf-8")
            decrypted_bytes = fernet.decrypt(encrypted_bytes)

            # Deserialize JSON
            credential_json = decrypted_bytes.decode("utf-8")
            credentials = json.loads(credential_json)

            logger.info(f"Decrypted credentials (key_version={key_version}, user_id={user_id})")
            return credentials

        except InvalidToken as e:
            logger.error(f"Invalid token during decryption: {e}")
            raise DAANException.decryption_failed("Invalid encryption token - credential may be corrupted") from e
        except Exception as e:
            logger.error(f"Decryption failed: {e}")
            raise DAANException.decryption_failed(f"Failed to decrypt credentials: {str(e)}") from e

    def verify_hash(self, credentials: dict[str, Any], expected_hash: str) -> bool:
        """Verify credential hash matches expected value.

        Used for breach detection - check if credentials have been modified.

        Args:
            credentials: Credentials dictionary
            expected_hash: Expected SHA256 hash

        Returns:
            True if hash matches, False otherwise
        """
        try:
            credential_json = json.dumps(credentials, sort_keys=True)
            credential_bytes = credential_json.encode("utf-8")
            actual_hash = hashlib.sha256(credential_bytes).hexdigest()
            return actual_hash == expected_hash
        except Exception as e:
            logger.error(f"Hash verification failed: {e}")
            return False

    def rotate_key(
        self,
        encrypted_data: str,
        old_version: int,
        new_version: int,
    ) -> tuple[str, str]:
        """Re-encrypt credentials with a new key version.

        Args:
            encrypted_data: Data encrypted with old key
            old_version: Old key version
            new_version: New key version

        Returns:
            Tuple of (new_encrypted_data, credential_hash)

        Raises:
            DecryptionFailedException, EncryptionFailedException: If rotation fails
        """
        # Decrypt with old key
        credentials = self.decrypt(encrypted_data, key_version=old_version, check_rate_limit=False)

        # Re-encrypt with new key
        new_encrypted_data, credential_hash = self.encrypt(credentials, key_version=new_version)

        logger.info(f"Rotated encryption key from v{old_version} to v{new_version}")
        return new_encrypted_data, credential_hash

    def clear_key_cache(self):
        """Clear the encryption key cache."""
        self._key_cache.clear()
        logger.info("Encryption key cache cleared")


# Global instance
_cipher_service: CredentialCipher | None = None


def get_cipher_service() -> CredentialCipher:
    """Get or create the global credential cipher service.

    Reads MCP_ENCRYPTION_KEY, MCP_DECRYPT_RATE_LIMIT, and MCP_DECRYPT_RATE_WINDOW
    from environment variables.

    Returns:
        CredentialCipher instance
    """
    global _cipher_service

    if _cipher_service is None:
        from daan.core.config import get_settings
        settings = get_settings()

        _cipher_service = CredentialCipher(
            encryption_key=settings.MCP_ENCRYPTION_KEY,
            rate_limit_requests=settings.MCP_DECRYPT_RATE_LIMIT,
            rate_limit_window=settings.MCP_DECRYPT_RATE_WINDOW,
        )

    return _cipher_service
