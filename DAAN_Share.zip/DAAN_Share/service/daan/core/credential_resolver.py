"""Credential resolver with user → global fallback chain for MCP servers."""

import logging
from pathlib import Path
from typing import Any

import yaml
from sqlalchemy import and_
from sqlalchemy.orm import Session, joinedload

from daan.core.exceptions import DAANException
from daan.core.mcp_encryption import get_cipher_service
from daan.models.user_mcp import UserMcpConfig, UserMcpSecret

logger = logging.getLogger(__name__)

_REGISTRY_PATH = Path(__file__).resolve().parents[3] / "config" / "mcp_servers_registry.yml"
_registry_cache: dict[str, Any] | None = None


def _load_registry() -> dict[str, Any]:
    """Load and cache the MCP server registry."""
    global _registry_cache
    if _registry_cache is not None:
        return _registry_cache

    if not _REGISTRY_PATH.exists():
        logger.error(f"MCP registry not found: {_REGISTRY_PATH}")
        return {}

    with open(_REGISTRY_PATH, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}

    _registry_cache = data.get("servers", {})
    return _registry_cache


def get_server_registry_config(server_name: str) -> dict[str, Any] | None:
    """Get a server's full definition from the registry (no secrets)."""
    registry = _load_registry()
    return registry.get(server_name)


def get_env_mapping(server_name: str) -> dict[str, str]:
    """Get the env_mapping for a server: {credential_key → ENV_VAR_NAME}."""
    config = get_server_registry_config(server_name)
    if not config:
        return {}
    return config.get("env_mapping", {})


def list_registry_servers() -> list[str]:
    """Return all server names from the registry."""
    return list(_load_registry().keys())


def invalidate_registry_cache():
    """Force reload on next access."""
    global _registry_cache
    _registry_cache = None


class CredentialResolver:
    """Resolves MCP credentials per-user with global default fallback.

    Resolution order:
      1. User's own config (is_global_default=False, is_active=True)
      2. Global default config (is_global_default=True, is_active=True)
      3. Raise CredentialNotFound
    """

    def __init__(self, db: Session, user_id: int):
        self._db = db
        self._user_id = user_id
        self._cipher = get_cipher_service()
        self._cache: dict[str, dict[str, Any]] = {}

    def resolve(self, server_name: str) -> dict[str, Any]:
        """Resolve credentials for a server, user-first then global fallback.

        Returns:
            Decrypted credentials dict.

        Raises:
            DAANException: If no credentials found.
        """
        if server_name in self._cache:
            return self._cache[server_name]

        # 1. Try user's own credential
        user_config = self._db.query(UserMcpConfig).options(
            joinedload(UserMcpConfig.secret)
        ).filter(
            and_(
                UserMcpConfig.user_id == self._user_id,
                UserMcpConfig.mcp_server_name == server_name,
                UserMcpConfig.is_global_default == False,
                UserMcpConfig.is_active == True,
                UserMcpConfig.deleted_at == None,
            )
        ).first()

        if user_config and user_config.secret:
            creds = self._decrypt(user_config)
            self._cache[server_name] = creds
            return creds

        # 2. Try global default
        global_config = self._db.query(UserMcpConfig).options(
            joinedload(UserMcpConfig.secret)
        ).filter(
            and_(
                UserMcpConfig.mcp_server_name == server_name,
                UserMcpConfig.is_global_default == True,
                UserMcpConfig.is_active == True,
                UserMcpConfig.deleted_at == None,
            )
        ).first()

        if global_config and global_config.secret:
            creds = self._decrypt(global_config)
            self._cache[server_name] = creds
            return creds

        raise DAANException.credential_not_found(server_name, self._user_id)

    def resolve_as_env(self, server_name: str) -> dict[str, str]:
        """Resolve credentials and map to env var names using the registry env_mapping.

        Returns:
            Dict of {ENV_VAR_NAME: value} ready to inject into subprocess env.
        """
        credentials = self.resolve(server_name)
        mapping = get_env_mapping(server_name)
        # DB-registered servers store credentials keyed by the literal env var name
        # (required_credentials keys, e.g. SLACK_BOT_TOKEN), so map them as-is instead
        # of forcing .upper() which would corrupt non-uppercase names.
        is_db_server = get_server_registry_config(server_name) is None

        env_vars: dict[str, str] = {}
        for cred_key, value in credentials.items():
            if cred_key in mapping:
                env_name = mapping[cred_key]
            elif is_db_server:
                env_name = cred_key
            else:
                env_name = cred_key.upper()
            env_vars[env_name] = str(value)

        return env_vars

    def has_credentials(self, server_name: str) -> bool:
        """Check if credentials exist without decrypting."""
        try:
            self.resolve(server_name)
            return True
        except DAANException:
            return False

    def is_using_global(self, server_name: str) -> bool:
        """Check if the user is using global defaults for this server."""
        user_config = self._db.query(UserMcpConfig).filter(
            and_(
                UserMcpConfig.user_id == self._user_id,
                UserMcpConfig.mcp_server_name == server_name,
                UserMcpConfig.is_global_default == False,
                UserMcpConfig.is_active == True,
                UserMcpConfig.deleted_at == None,
            )
        ).first()
        return user_config is None

    def _decrypt(self, config: UserMcpConfig) -> dict[str, Any]:
        """Decrypt a config's secret."""
        return self._cipher.decrypt(
            encrypted_data=config.secret.encrypted_credentials,
            key_version=config.credential_version,
            user_id=self._user_id,
            check_rate_limit=True,
        )
