"""Application exception classes.

DAANException — single exception class for all DAAN application errors.
  General usage:  raise DAANException("Operation failed", e)
  MCP usage:      raise DAANException.credential_not_found("jira-mcp-server")
"""

from __future__ import annotations

import sys
import traceback
from enum import Enum
from typing import Optional, cast


class DAANException(Exception):

    class ErrorCode(str, Enum):
        # Credential errors
        CREDENTIAL_NOT_FOUND = "credential_not_found"
        CREDENTIAL_EXPIRED = "credential_expired"
        CREDENTIAL_INVALID = "credential_invalid"
        CREDENTIAL_ALREADY_EXISTS = "credential_already_exists"

        # Encryption/Decryption errors
        DECRYPTION_FAILED = "decryption_failed"
        ENCRYPTION_FAILED = "encryption_failed"
        KEY_NOT_FOUND = "key_not_found"
        KEY_VERSION_MISMATCH = "key_version_mismatch"

        # Validation errors
        VALIDATION_FAILED = "validation_failed"
        INVALID_SERVER_NAME = "invalid_server_name"
        INVALID_CREDENTIAL_FORMAT = "invalid_credential_format"
        MISSING_REQUIRED_FIELD = "missing_required_field"

        # Connection/Server errors
        SERVER_UNREACHABLE = "server_unreachable"
        CONNECTION_TIMEOUT = "connection_timeout"
        SERVER_NOT_CONFIGURED = "server_not_configured"
        SERVER_PROCESS_FAILED = "server_process_failed"

        # Process management errors
        PROCESS_START_FAILED = "process_start_failed"
        PROCESS_LIMIT_REACHED = "process_limit_reached"
        PROCESS_ALREADY_RUNNING = "process_already_running"
        PROCESS_NOT_FOUND = "process_not_found"
        PROCESS_TIMEOUT = "process_timeout"

        # Rate limiting
        RATE_LIMIT_EXCEEDED = "rate_limit_exceeded"
        TOO_MANY_CONNECTIONS = "too_many_connections"

        # General errors
        INTERNAL_ERROR = "internal_error"
        UNAUTHORIZED = "unauthorized"
        FORBIDDEN = "forbidden"

    def __init__(
        self,
        error_message: object,
        error_details: Optional[object] = None,
        *,
        error_code: ErrorCode | None = None,
        details: dict | None = None,
    ):
        norm_msg = str(error_message)
        self.error_code = error_code
        self.details = details or {}
        self.message = norm_msg

        exc_type = exc_value = exc_tb = None
        if error_details is None:
            exc_type, exc_value, exc_tb = sys.exc_info()
        else:
            if hasattr(error_details, "exc_info"):
                exc_info_obj = cast(sys, error_details)
                exc_type, exc_value, exc_tb = exc_info_obj.exc_info()
            elif isinstance(error_details, BaseException):
                exc_type, exc_value, exc_tb = (
                    type(error_details),
                    error_details,
                    error_details.__traceback__,
                )
            else:
                exc_type, exc_value, exc_tb = sys.exc_info()

        last_tb = exc_tb
        while last_tb and last_tb.tb_next:
            last_tb = last_tb.tb_next

        self.file_name = last_tb.tb_frame.f_code.co_filename if last_tb else "<unknown>"
        self.lineno = last_tb.tb_lineno if last_tb else -1
        self.error_message = norm_msg

        if exc_type and exc_tb:
            self.traceback_str = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        else:
            self.traceback_str = ""

        super().__init__(self.__str__())

    def to_dict(self) -> dict:
        if self.error_code is None:
            return {"message": self.error_message}
        return {
            "error_code": self.error_code.value,
            "message": self.error_message,
            "details": self.details,
        }

    def __str__(self) -> str:
        base = f"Error in [{self.file_name}] at line [{self.lineno}] | Message: {self.error_message}"
        if self.traceback_str:
            return f"{base}\nTraceback:\n{self.traceback_str}"
        return base

    def __repr__(self) -> str:
        if self.error_code:
            return (
                "DAANException("
                f"error_code={self.error_code.value!r}, message={self.error_message!r}"
                ")"
            )
        return (
            "DAANException(" +
            f"file={self.file_name!r}, line={self.lineno}, message={self.error_message!r}" +
            ")"
        )

    # ── MCP factory class methods ─────────────────────────────────────────

    @classmethod
    def credential_not_found(cls, server_name: str, user_id: int | None = None) -> DAANException:
        message = f"Credential not found for server '{server_name}'"
        if user_id:
            message += f" and user {user_id}"
        return cls(
            message,
            error_code=cls.ErrorCode.CREDENTIAL_NOT_FOUND,
            details={"server_name": server_name, "user_id": user_id},
        )

    @classmethod
    def credential_already_exists(cls, server_name: str, soft_deleted: bool = False) -> DAANException:
        if soft_deleted:
            message = f"Credential for '{server_name}' already exists (soft deleted). Hard delete it first before recreating."
        else:
            message = f"Credential for '{server_name}' already exists."
        return cls(
            message,
            error_code=cls.ErrorCode.CREDENTIAL_ALREADY_EXISTS,
            details={"server_name": server_name},
        )

    @classmethod
    def credential_expired(cls, server_name: str, expired_at: str) -> DAANException:
        return cls(
            f"Credential for server '{server_name}' expired at {expired_at}",
            error_code=cls.ErrorCode.CREDENTIAL_EXPIRED,
            details={"server_name": server_name, "expired_at": expired_at},
        )

    @classmethod
    def decryption_failed(cls, reason: str = "Failed to decrypt credentials") -> DAANException:
        return cls(reason, error_code=cls.ErrorCode.DECRYPTION_FAILED)

    @classmethod
    def encryption_failed(cls, reason: str = "Failed to encrypt credentials") -> DAANException:
        return cls(reason, error_code=cls.ErrorCode.ENCRYPTION_FAILED)

    @classmethod
    def validation_failed(cls, server_name: str, reason: str) -> DAANException:
        return cls(
            f"Validation failed for server '{server_name}': {reason}",
            error_code=cls.ErrorCode.VALIDATION_FAILED,
            details={"server_name": server_name, "reason": reason},
        )

    @classmethod
    def server_unreachable(cls, server_name: str, reason: str | None = None) -> DAANException:
        message = f"Server '{server_name}' is unreachable"
        if reason:
            message += f": {reason}"
        return cls(message, error_code=cls.ErrorCode.SERVER_UNREACHABLE, details={"server_name": server_name})

    @classmethod
    def process_limit_reached(cls, limit: int, current: int) -> DAANException:
        return cls(
            f"Process limit reached: {current}/{limit}",
            error_code=cls.ErrorCode.PROCESS_LIMIT_REACHED,
            details={"limit": limit, "current": current},
        )

    @classmethod
    def rate_limit_exceeded(cls, operation: str, limit: int, retry_after: int | None = None) -> DAANException:
        message = f"Rate limit exceeded for operation '{operation}': {limit} requests"
        if retry_after:
            message += f". Retry after {retry_after} seconds"
        return cls(
            message,
            error_code=cls.ErrorCode.RATE_LIMIT_EXCEEDED,
            details={"operation": operation, "limit": limit, "retry_after": retry_after},
        )

    @classmethod
    def invalid_credential_format(cls, server_name: str, missing_fields: list[str] | None = None) -> DAANException:
        message = f"Invalid credential format for server '{server_name}'"
        if missing_fields:
            message += f". Missing required fields: {', '.join(missing_fields)}"
        return cls(
            message,
            error_code=cls.ErrorCode.INVALID_CREDENTIAL_FORMAT,
            details={"server_name": server_name, "missing_fields": missing_fields},
        )


# Backward-compatible aliases
DocumentPortalException = DAANException
McpErrorCode = DAANException.ErrorCode

