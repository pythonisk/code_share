"""Business logic for Team management."""

import logging

from sqlalchemy.orm import Session

from daan.core.mcp_encryption import CredentialCipher, get_cipher_service
from daan.models.team import Team, TeamMember
from daan.models.user import User
from daan.schemas.team import TeamCreate, TeamMemberResponse, TeamUpdate

logger = logging.getLogger(__name__)


def _get_cipher() -> CredentialCipher:
    """Return the shared CredentialCipher singleton."""
    return get_cipher_service()


# ---------------------------------------------------------------------------
# Virtual key helpers
# ---------------------------------------------------------------------------

def _encrypt_virtual_key(plain: str) -> str:
    """Encrypt a plain-text virtual key."""
    cipher = _get_cipher()
    encrypted, _ = cipher.encrypt({"virtual_key": plain})
    return encrypted


def _decrypt_virtual_key(encrypted: str) -> str:
    """Decrypt a stored virtual key. Returns empty string on failure."""
    try:
        cipher = _get_cipher()
        data = cipher.decrypt(encrypted, check_rate_limit=False)
        return data.get("virtual_key", "")
    except Exception as exc:
        logger.error("Failed to decrypt virtual key: %s", exc)
        return ""


# ---------------------------------------------------------------------------
# Seed helper
# ---------------------------------------------------------------------------

def ensure_global_team(db: Session) -> Team:
    """Create the global default team if it does not already exist."""
    team = db.query(Team).filter(Team.is_default == True).first()  # noqa: E712
    if team is None:
        team = Team(
            name="global",
            description="Default team — every user is a member",
            is_default=True,
        )
        db.add(team)
        db.commit()
        db.refresh(team)
        logger.info("Global team created (id=%s)", team.id)
    return team


# ---------------------------------------------------------------------------
# Team CRUD  (admin only)
# ---------------------------------------------------------------------------

def list_teams(db: Session) -> list[dict]:
    """Return all teams with member counts."""
    teams = db.query(Team).order_by(Team.is_default.desc(), Team.name).all()
    result = []
    for t in teams:
        result.append({
            "id": t.id,
            "name": t.name,
            "description": t.description,
            "is_default": t.is_default,
            "has_virtual_key": bool(t.virtual_key),
            "member_count": len(t.members),
            "created_at": t.created_at,
            "updated_at": t.updated_at,
        })
    return result


def get_team_by_id(db: Session, team_id: int) -> Team | None:
    return db.query(Team).filter(Team.id == team_id).first()


def create_team(db: Session, payload: TeamCreate) -> Team:
    existing = db.query(Team).filter(Team.name.ilike(payload.name)).first()
    if existing:
        raise ValueError(f"Team name '{payload.name}' already exists")

    encrypted_key = _encrypt_virtual_key(payload.virtual_key) if payload.virtual_key else None

    team = Team(
        name=payload.name.strip(),
        description=payload.description,
        virtual_key=encrypted_key,
        is_default=False,
    )
    db.add(team)
    db.commit()
    db.refresh(team)
    return team


def update_team(db: Session, team_id: int, payload: TeamUpdate) -> Team:
    """Update team details."""
    team = get_team_by_id(db, team_id)
    if team is None:
        raise ValueError("Team not found")

    if payload.name is not None:
        conflict = db.query(Team).filter(
            Team.name.ilike(payload.name), Team.id != team_id
        ).first()
        if conflict:
            raise ValueError(f"Team name '{payload.name}' already exists")
        team.name = payload.name.strip()

    if payload.description is not None:
        team.description = payload.description

    if payload.virtual_key is not None:
        team.virtual_key = _encrypt_virtual_key(payload.virtual_key) if payload.virtual_key else None

    db.commit()
    db.refresh(team)
    return team


def delete_team(db: Session, team_id: int) -> None:
    """Delete a team."""
    team = get_team_by_id(db, team_id)
    if team is None:
        raise ValueError("Team not found")
    if team.is_default:
        raise PermissionError("The global default team cannot be deleted")
    db.delete(team)
    db.commit()


# ---------------------------------------------------------------------------
# Member management  (admin only)
# ---------------------------------------------------------------------------

def get_team_members(db: Session, team_id: int) -> list[TeamMemberResponse]:
    team = get_team_by_id(db, team_id)
    if team is None:
        raise ValueError("Team not found")

    result = []
    for tm in team.members:
        user: User = tm.user
        result.append(TeamMemberResponse(
            user_id=user.id,
            username=user.username,
            email=user.email,
            joined_at=tm.joined_at,
        ))
    return result


def add_member(db: Session, team_id: int, user_id: int) -> TeamMember:
    team = get_team_by_id(db, team_id)
    if team is None:
        raise ValueError("Team not found")

    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise ValueError("User not found")

    existing = db.query(TeamMember).filter(
        TeamMember.team_id == team_id, TeamMember.user_id == user_id
    ).first()
    if existing:
        raise ValueError("User is already a member of this team")

    member = TeamMember(team_id=team_id, user_id=user_id)
    db.add(member)
    db.commit()
    db.refresh(member)

    # If added to a non-global team, sync global membership (removes from global)
    if not team.is_default:
        sync_global_team_membership(db, user_id)

    return member


def remove_member(db: Session, team_id: int, user_id: int) -> None:
    team = get_team_by_id(db, team_id)
    if team is None:
        raise ValueError("Team not found")

    member = db.query(TeamMember).filter(
        TeamMember.team_id == team_id, TeamMember.user_id == user_id
    ).first()
    if member is None:
        raise ValueError("User is not a member of this team")

    db.delete(member)
    db.commit()

    # After removing from a non-global team, sync global membership (adds back if no other teams)
    if not team.is_default:
        sync_global_team_membership(db, user_id)


def get_global_team(db: Session) -> Team | None:
    """Return the global default team if it exists."""
    return db.query(Team).filter(Team.is_default == True).first()  # noqa: E712


def sync_global_team_membership(db: Session, user_id: int) -> None:
    """Add user to global team only if they have no other team memberships.
    
    - If user is in any non-global team → remove from global team
    - If user has no other teams → add to global team
    """
    global_team = get_global_team(db)
    if global_team is None:
        logger.warning("Global team not found — skipping sync for user %s", user_id)
        return

    # Check if user is in any non-global team
    other_membership = db.query(TeamMember).join(Team).filter(
        TeamMember.user_id == user_id,
        Team.is_default == False  # noqa: E712
    ).first()

    global_membership = db.query(TeamMember).filter(
        TeamMember.team_id == global_team.id,
        TeamMember.user_id == user_id
    ).first()

    if other_membership:
        # User has other teams - remove from global if present
        if global_membership:
            db.delete(global_membership)
            db.commit()
    else:
        # User has no other teams - add to global if not present
        if not global_membership:
            db.add(TeamMember(team_id=global_team.id, user_id=user_id))
            db.commit()


def add_user_to_global_team(db: Session, user_id: int) -> None:
    """Add a user to the global default team. Safe to call multiple times."""
    global_team = get_global_team(db)
    if global_team is None:
        logger.warning("Global team not found — skipping auto-add for user %s", user_id)
        return

    existing = db.query(TeamMember).filter(
        TeamMember.team_id == global_team.id, TeamMember.user_id == user_id
    ).first()
    if existing:
        return

    member = TeamMember(team_id=global_team.id, user_id=user_id)
    db.add(member)
    db.commit()


def get_user_teams(db: Session, user_id: int) -> list[dict]:
    """Return all teams a user belongs to."""
    memberships = db.query(TeamMember).filter(TeamMember.user_id == user_id).all()
    result = []
    for tm in memberships:
        t: Team = tm.team
        result.append({
            "id": t.id,
            "name": t.name,
            "description": t.description,
            "is_default": t.is_default,
            "joined_at": tm.joined_at,
        })
    return result


def get_team_detail(db: Session, team_id: int, include_virtual_key: bool = False) -> dict:
    """Return full team detail with members and optionally decrypted virtual key."""
    team = get_team_by_id(db, team_id)
    if team is None:
        raise ValueError("Team not found")

    members = get_team_members(db, team_id)

    virtual_key_value = None
    if include_virtual_key and team.virtual_key:
        virtual_key_value = _decrypt_virtual_key(team.virtual_key)

    return {
        "id": team.id,
        "name": team.name,
        "description": team.description,
        "is_default": team.is_default,
        "has_virtual_key": bool(team.virtual_key),
        "virtual_key": virtual_key_value,
        "member_count": len(members),
        "members": members,
        "created_at": team.created_at,
        "updated_at": team.updated_at,
    }


# ---------------------------------------------------------------------------
# Virtual key LLM override
# ---------------------------------------------------------------------------

def get_active_api_key_for_user(db: Session, user_id: int) -> str | None:
    """
    Return the decrypted virtual key of the first non-default team
    this user belongs to that has a virtual_key set.
    Returns None if no such team exists (fall back to global key).
    """
    memberships = (
        db.query(TeamMember)
        .join(Team, Team.id == TeamMember.team_id)
        .filter(
            TeamMember.user_id == user_id,
            Team.is_default == False,  # noqa: E712
            Team.virtual_key.isnot(None),
        )
        .order_by(TeamMember.joined_at)
        .all()
    )
    for tm in memberships:
        decrypted = _decrypt_virtual_key(tm.team.virtual_key)
        if decrypted:
            return decrypted
    return None


# ---------------------------------------------------------------------------
# Virtual key context (request-scoped)
# ---------------------------------------------------------------------------

from contextvars import ContextVar

_team_api_key: ContextVar[str | None] = ContextVar("team_api_key", default=None)


def set_team_api_key(key: str | None) -> None:
    """Set the virtual API key for the current async/thread context."""
    _team_api_key.set(key)


def get_team_api_key() -> str | None:
    """Return the virtual API key override, or None to use the global key."""
    return _team_api_key.get()
