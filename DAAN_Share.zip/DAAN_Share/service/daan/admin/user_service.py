"""Combined authentication and user business logic service."""

from datetime import UTC, datetime
from sqlalchemy import or_
from sqlalchemy.orm import Session

from daan.core.security import create_access_token, get_password_hash, verify_password
from daan.models.user import User
from daan.models.role import Role, Permission
from daan.models.archetype_assignment import UserArchetypeAssignment
from daan.models.archetype import Archetype
from daan.models.chat import ChatMessage, ChatSession
from daan.models.user_mcp import UserMcpConfig
from daan.models.team import TeamMember
from daan.schemas.user import UserCreate, UserUpdate, UserArchetypeAssignmentCreate

# --- User CRUD ---
def get_user_by_id(db: Session, user_id: int) -> User | None:
    return db.query(User).filter(User.id == user_id).first()

def get_user_by_username(db: Session, username: str) -> User | None:
    return db.query(User).filter(User.username == username).first()

def get_user_by_email(db: Session, email: str) -> User | None:
    return db.query(User).filter(User.email == email).first()

def get_user_by_username_or_email(db: Session, username_or_email: str) -> User | None:
    return (
        db.query(User)
        .filter(
            or_(
                User.username == username_or_email,
                User.email == username_or_email,
            )
        )
        .first()
    )

def list_users(db: Session, skip: int = 0, limit: int = 100) -> list[User]:
    return db.query(User).offset(skip).limit(limit).all()

def create_user(db: Session, payload: UserCreate) -> User:
    if get_user_by_username(db, payload.username):
        raise ValueError("Username already exists")
    if get_user_by_email(db, payload.email):
        raise ValueError("Email already exists")
    
    # Handle Role by exact or case-insensitive string name
    if payload.role:
        assigned_role = db.query(Role).filter(Role.name.ilike(payload.role)).first()
        if not assigned_role:
            raise ValueError(f"Role '{payload.role}' not found")
        role_id_val = assigned_role.id
    else:
        assigned_role = db.query(Role).filter(Role.name.ilike("Viewer")).first()
        role_id_val = assigned_role.id if assigned_role else 3

    # Calculate access based on assigned role name
    access_level = "read"
    if assigned_role and assigned_role.name.lower() in ["developer", "admin"]:
        access_level = "edit"

    db_user = User(
        username=payload.username,
        email=payload.email,
        firstname=payload.firstname,
        lastname=payload.lastname,
        hashed_password=get_password_hash(payload.password),
        role_id=role_id_val,
    )
    db.add(db_user)
    db.flush()  # Flush so db_user gets an ID

    # Handle Archetypes by string names
    archetype_names = getattr(payload, "archetypes", [])
    
    # If the UI passes "Full Access", assign all archetypes
    if any(name.lower() == "full access" for name in archetype_names):
        archetypes_to_assign = db.query(Archetype).all()
    else:
        archetypes_to_assign = []
        for arch_name in archetype_names:
            arch = db.query(Archetype).filter(Archetype.name.ilike(arch_name)).first()
            if not arch:
                raise ValueError(f"Archetype '{arch_name}' not found")
            archetypes_to_assign.append(arch)

    for arch in archetypes_to_assign:
        assignment = UserArchetypeAssignment(
            user_id=db_user.id,
            archetype_id=arch.id,
            access_level=access_level
        )
        db.add(assignment)

    db.commit()
    db.refresh(db_user)

    # Add to specified teams first, then sync global membership
    from daan.admin.team_service import add_member, get_team_by_id, sync_global_team_membership
    team_ids = getattr(payload, "team_ids", [])
    
    for team_id in team_ids:
        team = get_team_by_id(db, team_id)
        if team and not team.is_default:
            try:
                add_member(db, team_id, db_user.id)
            except ValueError:
                pass  # already a member — safe to skip

    # Sync global team: adds to global only if user has no other teams
    sync_global_team_membership(db, db_user.id)

    return db_user

def update_user_by_username(db: Session, username: str, payload: UserUpdate) -> User | None:
    user = get_user_by_username(db, username)
    if user is None:
        return None
    
    updates = payload.model_dump(exclude_unset=True)
    
    # Handle role custom string logic
    if "role" in updates:
        role_name = updates.pop("role")
        if role_name:
            assigned_role = db.query(Role).filter(Role.name.ilike(role_name)).first()
            if not assigned_role:
                raise ValueError(f"Role '{role_name}' not found")
            user.role_id = assigned_role.id
            user.role = assigned_role

    # Handle archetypes string array list wipe-and-replace
    if "archetypes" in updates:
        archetype_names = updates.pop("archetypes")
        
        # Clear existing archetypes
        db.query(UserArchetypeAssignment).filter(UserArchetypeAssignment.user_id == user.id).delete()
        
        if archetype_names is not None:
            # Check for "Full Access"
            if any(name.lower() == "full access" for name in archetype_names):
                archetypes_to_assign = db.query(Archetype).all()
            else:
                archetypes_to_assign = []
                for arch_name in archetype_names:
                    arch = db.query(Archetype).filter(Archetype.name.ilike(arch_name)).first()
                    if not arch:
                        raise ValueError(f"Archetype '{arch_name}' not found")
                    archetypes_to_assign.append(arch)

            # Determine access level dynamically based on new or current role
            current_role = user.role  # Relationship might need refreshing, safer to re-query:
            if not current_role and user.role_id:
                current_role = db.query(Role).filter(Role.id == user.role_id).first()
                
            access_level = "read"
            if current_role and current_role.name.lower() in ["developer", "admin"]:
                access_level = "edit"

            for arch in archetypes_to_assign:
                assignment = UserArchetypeAssignment(
                    user_id=user.id,
                    archetype_id=arch.id,
                    access_level=access_level
                )
                db.add(assignment)

    # Handle standard fields
    for field, value in updates.items():
        setattr(user, field, value)
        
    db.commit()
    db.refresh(user)
    return user

def delete_user_by_username(db: Session, username: str) -> bool:
    user = get_user_by_username(db, username)
    if user is None:
        return False
    
    try:
        # Delete dependent rows that have FK references to users.id
        session_ids = [s.id for s in db.query(ChatSession).filter(ChatSession.user_id == user.id).all()]
        if session_ids:
            db.query(ChatMessage).filter(ChatMessage.session_id.in_(session_ids)).delete(synchronize_session=False)
            db.query(ChatSession).filter(ChatSession.user_id == user.id).delete(synchronize_session=False)
        db.query(UserMcpConfig).filter(UserMcpConfig.user_id == user.id).delete(synchronize_session=False)
        db.query(UserArchetypeAssignment).filter(UserArchetypeAssignment.user_id == user.id).delete(synchronize_session=False)
        db.query(TeamMember).filter(TeamMember.user_id == user.id).delete(synchronize_session=False)
        
        db.delete(user)
        db.commit()
        return True
    except Exception as e:
        db.rollback()
        import logging
        logging.error(f"Failed to delete user {username}: {e}")
        raise

# --- Auth logic ---
def authenticate_user(db: Session, username_or_email: str, password: str) -> User | None:
    user = get_user_by_username_or_email(db, username_or_email)
    if user is None:
        return None
    if not verify_password(password, user.hashed_password):
        return None
    return user

def login_user(db: Session, username_or_email: str, password: str) -> tuple[str, User]:
    user = authenticate_user(db, username_or_email, password)
    if user is None:
        raise ValueError("Invalid username/email or password")
    user.last_login = datetime.now(UTC)
    db.commit()
    token_payload = {
        "sub": user.username,
        "role": user.role.name if user.role else "User",
    }
    return create_access_token(token_payload), user

def get_all_users_with_roles(db: Session, skip: int = 0, limit: int = 100) -> list[User]:
    return list_users(db, skip=skip, limit=limit)

def get_all_roles(db: Session) -> list[Role]:
    return db.query(Role).all()

def get_all_permissions(db: Session) -> list[Permission]:
    return db.query(Permission).all()


def can_edit_archetype_by_id(db: Session, user: User, arch_id: int) -> bool:
    """Check if a user has 'edit' access to a specific archetype by ID."""
    return True


def can_edit_archetype(db: Session, user: User, archetype_name: str) -> bool:
    """Check if a user has 'edit' access to a specific archetype."""
    return True


def assign_role_to_user(db: Session, username: str, role_id: int) -> User | None:
    user = get_user_by_username(db, username)
    if user is None:
        return None
    role = db.query(Role).filter(Role.id == role_id).first()
    if role:
        user.role_id = role.id
        db.commit()
        db.refresh(user)
    return user

def get_user_archetype_assignments(db: Session, target_user: User) -> list[dict]:
    all_archetypes = db.query(Archetype).all()
    return [
        {
            "archetype_id": arch.id,
            "archetype_name": arch.name,
            "access_level": "edit"
        }
        for arch in all_archetypes
    ]

def assign_archetype_to_user(db: Session, user_id: int, payload: UserArchetypeAssignmentCreate) -> dict:
    # Check if assignment already exists
    existing = db.query(UserArchetypeAssignment).filter(
        UserArchetypeAssignment.user_id == user_id,
        UserArchetypeAssignment.archetype_id == payload.archetype_id
    ).first()
    
    archetype = db.query(Archetype).filter(Archetype.id == payload.archetype_id).first()
    if not archetype:
        raise ValueError("Archetype not found")

    if existing:
        existing.access_level = payload.access_level
        db.commit()
        db.refresh(existing)
        return {
            "archetype_id": existing.archetype_id,
            "archetype_name": archetype.name,
            "access_level": existing.access_level
        }

    new_assignment = UserArchetypeAssignment(
        user_id=user_id,
        archetype_id=payload.archetype_id,
        access_level=payload.access_level
    )
    db.add(new_assignment)
    db.commit()
    db.refresh(new_assignment)
    return {
        "archetype_id": new_assignment.archetype_id,
        "archetype_name": archetype.name,
        "access_level": new_assignment.access_level
    }

def revoke_archetype_from_user(db: Session, user_id: int, archetype_id: int) -> bool:
    """Remove an archetype assignment from a user."""
    assignment = db.query(UserArchetypeAssignment).filter(
        UserArchetypeAssignment.user_id == user_id,
        UserArchetypeAssignment.archetype_id == archetype_id
    ).first()
    
    if not assignment:
        return False
        
    db.delete(assignment)
    db.commit()
    return True

def has_edit_access_to_archetype(db: Session, user: User, archetype_id: int) -> bool:
    # 1. Admin Override (The "God Mode" check)
    if user.role.name == "Admin":
        return True
        
    # 2. Developer/Selective check
    assignment = db.query(UserArchetypeAssignment).filter(
        UserArchetypeAssignment.user_id == user.id,
        UserArchetypeAssignment.archetype_id == archetype_id,
        UserArchetypeAssignment.access_level == "edit"
    ).first()
    
    return assignment is not None

def bootstrap_first_admin(db: Session, payload: UserCreate) -> tuple[str, User]:
    """Create the very first system user as Admin and return JWT token.
    
    This endpoint is intended for one-time initialization.
    It is blocked as soon as an admin already exists.
    """
    admin_role = db.query(Role).filter(Role.name == "Admin").first()
    if not admin_role:
        admin_role = Role(name="Admin", description="Administrator")
        db.add(admin_role)
        db.commit()
        db.refresh(admin_role)
    
    existing_admin = db.query(User).filter(User.role_id == admin_role.id).first()
    if existing_admin:
        raise PermissionError("Admin already exists")
    
    if get_user_by_username(db, payload.username):
        raise ValueError("Username already exists")
    if get_user_by_email(db, payload.email):
        raise ValueError("Email already exists")
    
    first_user = User(
        username=payload.username,
        email=payload.email,
        firstname=payload.firstname,
        lastname=payload.lastname,
        hashed_password=get_password_hash(payload.password),
        role_id=admin_role.id,
    )
    db.add(first_user)
    db.commit()
    db.refresh(first_user)
    
    return login_user(db, payload.username, payload.password)

