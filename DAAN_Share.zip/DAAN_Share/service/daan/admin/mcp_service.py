"""CRUD service for user MCP server credentials with encryption and validation."""

import json
import logging
from datetime import datetime
from typing import Any

from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session, joinedload

from daan.core.mcp_encryption import get_cipher_service
from daan.mcp_servers.core.credential_validator import get_credential_validator
from daan.core.exceptions import DAANException
from daan.models.user_mcp import (
    UserMcpConfig,
    UserMcpSecret,
    ValidationStatus,
)

logger = logging.getLogger(__name__)


class McpCredentialsService:
    """Service for managing MCP credentials with encryption and validation."""

    def __init__(self):
        """Initialize MCP credentials service."""
        self.cipher = get_cipher_service()
        self.validator = get_credential_validator()

    def create_credential(
        self,
        db: Session,
        user_id: int,
        server_name: str,
        credentials: dict[str, Any],
        expires_at: datetime | None = None,
        server_metadata: dict[str, Any] | None = None,
        validate_credentials: bool = True,
        ip_address: str | None = None,
        correlation_id: str | None = None,
        is_global_default: bool = False,
    ) -> UserMcpConfig:
        """Create new MCP credentials for a user.

        Args:
            db: Database session
            user_id: User ID
            server_name: MCP server name
            credentials: Credentials dictionary
            expires_at: Expiration timestamp
            server_metadata: Non-sensitive server metadata
            validate_credentials: Validate credentials against registry
            ip_address: Client IP address
            correlation_id: Correlation ID for tracing

        Returns:
            Created UserMcpConfig

        Raises:
            InvalidCredentialFormatException: If validation fails
        """
        try:
            # Validate credentials if enabled
            if validate_credentials:
                self.validator.validate_credentials(
                    server_name=server_name,
                    credentials=credentials,
                    strict=True,
                )

            # Check if config already exists (active or soft-deleted)
            existing = db.query(UserMcpConfig).options(
                joinedload(UserMcpConfig.secret)
            ).filter(
                and_(
                    UserMcpConfig.user_id == user_id,
                    UserMcpConfig.mcp_server_name == server_name,
                )
            ).first()

            if existing:
                # If soft-deleted, restore and update it
                if existing.deleted_at is not None:
                    logger.info(f"Restoring soft-deleted MCP credential for user {user_id}, server {server_name}")
                    
                    # Restore the credential
                    existing.deleted_at = None
                    existing.is_active = True
                    existing.is_global_default = is_global_default
                    existing.validation_status = ValidationStatus.NOT_TESTED
                    existing.updated_at = datetime.now()
                    
                    # Update metadata if provided
                    if server_metadata is not None:
                        existing.server_metadata = json.dumps(server_metadata)
                    if expires_at is not None:
                        existing.expires_at = expires_at
                    
                    # Re-encrypt credentials with incremented version
                    existing.credential_version += 1
                    encrypted_data, credential_hash = self.cipher.encrypt(
                        credentials, 
                        key_version=existing.credential_version
                    )
                    
                    # Update secret
                    if existing.secret:
                        existing.secret.encrypted_credentials = encrypted_data
                        existing.secret.credential_hash = credential_hash
                        existing.secret.updated_at = datetime.now()
                    else:
                        # Create new secret if it doesn't exist
                        secret = UserMcpSecret(
                            config_id=existing.id,
                            encrypted_credentials=encrypted_data,
                            credential_hash=credential_hash,
                        )
                        db.add(secret)
                    
                    db.commit()
                    db.refresh(existing)
                    logger.info(f"Restored and updated MCP credentials for user {user_id}, server {server_name}")
                    return existing
                else:
                    # Active credential already exists
                    raise DAANException.credential_already_exists(
                        server_name=server_name,
                        soft_deleted=False,
                    )

            # Encrypt credentials
            encrypted_data, credential_hash = self.cipher.encrypt(credentials, key_version=1)

            # Create config
            config = UserMcpConfig(
                user_id=user_id,
                mcp_server_name=server_name,
                is_global_default=is_global_default,
                is_active=True,
                validation_status=ValidationStatus.NOT_TESTED,
                expires_at=expires_at,
                credential_version=1,
                server_metadata=json.dumps(server_metadata) if server_metadata else None,
            )

            db.add(config)
            db.flush()

            # Create secret
            secret = UserMcpSecret(
                config_id=config.id,
                encrypted_credentials=encrypted_data,
                credential_hash=credential_hash,
            )

            db.add(secret)
            db.commit()
            db.refresh(config)

            logger.info(f"Created MCP credentials for user {user_id}, server {server_name}")
            return config

        except Exception as e:
            db.rollback()
            logger.error(f"Failed to create credentials: {e}")
            raise

    def get_credential(
        self,
        db: Session,
        user_id: int,
        server_name: str,
        decrypt: bool = False,
        check_expiry: bool = True,
    ) -> tuple[UserMcpConfig, dict[str, Any] | None]:
        """Get MCP credentials for a user.

        Args:
            db: Database session
            user_id: User ID
            server_name: MCP server name
            decrypt: Whether to decrypt credentials
            check_expiry: Check if credentials are expired

        Returns:
            Tuple of (UserMcpConfig, decrypted_credentials or None)

        Raises:
            CredentialNotFoundException: If credentials not found
            CredentialExpiredException: If credentials expired
        """
        # Query with joined secret
        config = db.query(UserMcpConfig).options(
            joinedload(UserMcpConfig.secret)
        ).filter(
            and_(
                UserMcpConfig.user_id == user_id,
                UserMcpConfig.mcp_server_name == server_name,
                UserMcpConfig.deleted_at.is_(None),
            )
        ).first()

        if not config:
            raise DAANException.credential_not_found(server_name=server_name, user_id=user_id)

        # Check expiry
        if check_expiry and config.expires_at and config.expires_at < datetime.now():
            raise DAANException.credential_expired(
                server_name=server_name,
                expired_at=config.expires_at.isoformat(),
            )

        # Decrypt if requested
        decrypted_credentials = None
        if decrypt and config.secret:
            try:
                decrypted_credentials = self.cipher.decrypt(
                    encrypted_data=config.secret.encrypted_credentials,
                    key_version=config.credential_version,
                    user_id=user_id,
                )

                # Update access tracking
                config.last_accessed_at = datetime.now()
                config.access_count += 1
                db.commit()

            except Exception as e:
                raise

        return config, decrypted_credentials

    def list_credentials(
        self,
        db: Session,
        user_id: int,
        include_inactive: bool = False,
    ) -> list[UserMcpConfig]:
        """List all MCP credentials for a user.

        Args:
            db: Database session
            user_id: User ID
            include_inactive: Include inactive credentials

        Returns:
            List of UserMcpConfig (excluding global defaults)
        """
        query = db.query(UserMcpConfig).filter(
            and_(
                UserMcpConfig.user_id == user_id,
                UserMcpConfig.deleted_at.is_(None),
                UserMcpConfig.is_global_default == False,  # Exclude global defaults
            )
        )

        if not include_inactive:
            query = query.filter(UserMcpConfig.is_active == True)

        return query.all()

    def update_credential(
        self,
        db: Session,
        user_id: int,
        server_name: str,
        credentials: dict[str, Any] | None = None,
        expires_at: datetime | None = None,
        server_metadata: dict[str, Any] | None = None,
        is_active: bool | None = None,
        validate_credentials: bool = True,
        ip_address: str | None = None,
        correlation_id: str | None = None,
    ) -> UserMcpConfig:
        """Update MCP credentials.

        Args:
            db: Database session
            user_id: User ID
            server_name: MCP server name
            credentials: New credentials (optional)
            expires_at: New expiration (optional)
            server_metadata: New metadata (optional)
            is_active: New active status (optional)
            validate_credentials: Validate credentials if provided
            ip_address: Client IP address
            correlation_id: Correlation ID

        Returns:
            Updated UserMcpConfig

        Raises:
            CredentialNotFoundException: If credentials not found
        """
        try:
            # Get existing config (including soft-deleted ones for restoration)
            config = db.query(UserMcpConfig).options(
                joinedload(UserMcpConfig.secret)
            ).filter(
                and_(
                    UserMcpConfig.user_id == user_id,
                    UserMcpConfig.mcp_server_name == server_name,
                )
            ).first()

            if not config:
                raise DAANException.credential_not_found(server_name=server_name, user_id=user_id)

            # If credential was soft-deleted, restore it
            if config.deleted_at is not None:
                config.deleted_at = None
                logger.info(f"Restoring soft-deleted MCP credential for user {user_id}, server {server_name}")

            # Update credentials if provided
            if credentials is not None:
                # Validate
                if validate_credentials:
                    self.validator.validate_credentials(
                        server_name=server_name,
                        credentials=credentials,
                        strict=True,
                    )

                # Re-encrypt with same key version
                encrypted_data, credential_hash = self.cipher.encrypt(
                    credentials,
                    key_version=config.credential_version,
                )

                # Update secret
                if config.secret:
                    config.secret.encrypted_credentials = encrypted_data
                    config.secret.credential_hash = credential_hash
                    config.secret.updated_at = datetime.now()
                else:
                    # Secret was deleted or never existed — create a new one
                    from daan.models.user_mcp import UserMcpSecret
                    new_secret = UserMcpSecret(
                        config_id=config.id,
                        encrypted_credentials=encrypted_data,
                        credential_hash=credential_hash,
                    )
                    db.add(new_secret)

            # Update other fields
            if expires_at is not None:
                config.expires_at = expires_at

            if server_metadata is not None:
                config.server_metadata = json.dumps(server_metadata)

            if is_active is not None:
                config.is_active = is_active

            config.updated_at = datetime.now()

            db.commit()
            db.refresh(config)

            logger.info(f"Updated MCP credentials for user {user_id}, server {server_name}")
            return config

        except Exception as e:
            db.rollback()
            logger.error(f"Failed to update credentials: {e}")
            raise

    def delete_credential(
        self,
        db: Session,
        user_id: int,
        server_name: str,
        soft_delete: bool = True,
        ip_address: str | None = None,
        correlation_id: str | None = None,
    ) -> bool:
        """Delete MCP credentials.

        Args:
            db: Database session
            user_id: User ID
            server_name: MCP server name
            soft_delete: Use soft delete (set deleted_at) vs hard delete
            ip_address: Client IP address
            correlation_id: Correlation ID

        Returns:
            True if deleted

        Raises:
            CredentialNotFoundException: If credentials not found
        """
        try:
            # Query without deleted_at filter so both active and soft-deleted records are found
            config = db.query(UserMcpConfig).filter(
                and_(
                    UserMcpConfig.user_id == user_id,
                    UserMcpConfig.mcp_server_name == server_name,
                )
            ).first()

            if not config:
                raise DAANException.credential_not_found(server_name=server_name, user_id=user_id)

            if soft_delete:
                # Soft delete
                config.deleted_at = datetime.now()
                config.is_active = False
            else:
                # Hard delete (cascade will delete secret)
                db.delete(config)

            db.commit()

            logger.info(f"Deleted MCP credentials for user {user_id}, server {server_name}")
            return True

        except Exception as e:
            db.rollback()
            logger.error(f"Failed to delete credentials: {e}")
            raise


# Global instance
_credentials_service: McpCredentialsService | None = None


def get_credentials_service() -> McpCredentialsService:
    """Get or create the global MCP credentials service.

    Returns:
        McpCredentialsService instance
    """
    global _credentials_service

    if _credentials_service is None:
        _credentials_service = McpCredentialsService()

    return _credentials_service
