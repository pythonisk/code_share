"""DAAN Framework FastAPI service entry point."""

import asyncio
import sys
import time
from contextlib import asynccontextmanager

import logging

# Patch certifi to trust system CA certificates (corp proxies, custom root CAs)
try:
    import pip_system_certs.wrapt_requests  # noqa: F401
except ImportError:
    pass

# On Windows, asyncio subprocess support requires ProactorEventLoop.
# Ensure it is set before uvicorn or any other library changes the policy.
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

from fastapi import FastAPI
from fastapi.exception_handlers import http_exception_handler
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
from sqlalchemy.exc import DBAPIError
from daan.api.router import api_router
from daan.core.config import get_settings
from daan.core.database import activate_sqlite_fallback, engine, init_db
from daan.core.exceptions import DAANException
from daan.core.health import health_router
from daan.core.logging import setup_logging
from daan.llm.reasoning_kwargs import install_litellm_safety_flags
from daan.native_tools.rag_tool import RagTool


class _SseAwareGZipMiddleware(GZipMiddleware):
    """GZipMiddleware that bypasses SSE requests to keep the stream flushing."""

    async def __call__(self, scope, receive, send):
        if scope.get("type") == "http":
            # Reasoning-stream path or an explicit SSE Accept header bypasses gzip.
            path = scope.get("path", "")
            if "/reasoning-stream" in path:
                await self.app(scope, receive, send)
                return
            for name, value in scope.get("headers", []):
                if name == b"accept" and b"text/event-stream" in value:
                    await self.app(scope, receive, send)
                    return
        await super().__call__(scope, receive, send)


def _should_use_sqlite_startup_fallback() -> bool:
    settings = get_settings()
    return (
        settings.ENVIRONMENT == "development"
        and settings.APP_DB_ENABLE_STARTUP_SQLITE_FALLBACK
        and not settings.DATABASE_URL.startswith("sqlite")
    )


def _init_db_with_retry(logger, attempts: int = 5, delay: float = 1.5) -> None:
    """Initialise the database, retrying transient MySQL connection errors.

    Azure MySQL occasionally desynchronises the first TLS handshake — surfacing
    as ``pymysql.err.InternalError: Packet sequence number wrong - got 1
    expected 0`` — or hands back a stale pooled connection. Disposing the engine
    pool between attempts forces a fresh connection so startup can recover
    instead of crashing.
    """
    last_exc: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            init_db()
            return
        except DBAPIError as exc:
            last_exc = exc
            logger.warning(
                "Database init attempt %s/%s failed (%s); disposing pool and retrying",
                attempt, attempts, exc.__class__.__name__,
            )
            try:
                engine.dispose()
            except Exception:
                logger.debug("Engine dispose failed", exc_info=True)
            if attempt < attempts:
                time.sleep(delay)
    assert last_exc is not None

    if _should_use_sqlite_startup_fallback():
        sqlite_url = activate_sqlite_fallback()
        logger.warning(
            "Primary database unavailable after %s attempts; falling back to local SQLite for development startup (%s)",
            attempts,
            sqlite_url,
        )
        init_db()
        return

    raise last_exc


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup/shutdown lifecycle handlers."""
    logger = setup_logging()
    logger.info("Starting DAAN Framework API Service")

    # Safety net: drop unsupported provider params (e.g. `thinking` on azure/gpt-4o)
    # instead of raising UnsupportedParamsError mid-workflow.
    install_litellm_safety_flags()

    # Ensure all tables exist for local development and MVP flows.
    # Wrapped in a retry/dispose guard so a transient Azure MySQL handshake
    # error on the first connection doesn't abort startup.
    _init_db_with_retry(logger)

    # Warm retrieval runtime state so the first KB query does not pay
    # reranker/model initialization and failure-discovery costs. Run it off the
    # startup path in a worker thread — the heavy litellm import and vector/graph
    # store connections would otherwise block "startup complete" for seconds.
    def _warm_rag_runtime() -> None:
        try:
            RagTool(get_settings().load_rag_config()).warm_runtime_components()
        except Exception as exc:  # noqa: BLE001
            logger.warning("RAG runtime warmup skipped: %s", exc)

    asyncio.get_running_loop().run_in_executor(None, _warm_rag_runtime)

    logger.info("DAAN Framework API Service started successfully")
    yield

    # Release the KuzuDB knowledge-graph handle (no-op if it was never opened).
    try:
        from daan.knowledge_graph import close_kg_connection
        close_kg_connection()
    except Exception:
        logger.debug("KG connection close skipped", exc_info=True)

    logger.info("DAAN Framework API Service stopped")


def create_application() -> FastAPI:
    """Create and configure the FastAPI application instance."""
    settings = get_settings()
    docs_enabled = settings.ENVIRONMENT != "production" or bool(settings.ENABLE_API_DOCS)

    app = FastAPI(
        title="DAAN Framework API",
        description="DAAN framework backend APIs",
        version="1.0.0",
        docs_url="/api/docs" if docs_enabled else None,
        redoc_url="/api/redoc" if docs_enabled else None,
        openapi_url="/api/openapi.json" if docs_enabled else None,
        lifespan=lifespan,
    )
    origins = [
        "http://localhost:3000",  # allow localhost frontend
        "http://localhost:3001",
        "https://mcp.atlassian.com/v1/sse",  # allow next dev when 3000 is taken
        # "https://yourfrontend.com",  # allow your deployed frontend
        # Add other frontends or URLs if needed
    ]
    # Compression and CORS are enough for the current iteration.
    # NOTE: SSE (text/event-stream) requests must NOT be gzip-wrapped —
    # GZipMiddleware would buffer the stream and defeat live pushes.
    app.add_middleware(_SseAwareGZipMiddleware, minimum_size=1000)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Include routers
    app.include_router(health_router)
    app.include_router(api_router, prefix="/api")

    @app.get("/")
    async def root() -> dict[str, str]:
        """Root endpoint used as a quick service smoke test."""
        return {"message": "DAAN API is running"}

    @app.exception_handler(404)
    async def not_found_handler(request, exc):
        detail = getattr(exc, "detail", None)
        # Preserve meaningful application 404s; only normalize the default routing 404.
        if detail and str(detail) not in ("Not Found", "Resource not found"):
            return JSONResponse(status_code=404, content={"detail": detail})
        return JSONResponse(
            status_code=404,
            content={"detail": "Resource not found"},
        )

    @app.exception_handler(StarletteHTTPException)
    async def http_exception_logging_handler(request, exc: StarletteHTTPException):
        """Log HTTPExceptions but keep FastAPI's native response behavior.

        - 4xx: warning
        - 5xx: error
        - Response: delegated to FastAPI's built-in `http_exception_handler`
        """

        logger = logging.getLogger("daan.http")
        session_id = None
        try:
            session_id = request.headers.get("X-Session-Id")
        except Exception:
            session_id = None

        extra = {
            "method": getattr(request, "method", None),
            "path": str(getattr(getattr(request, "url", None), "path", "")),
            "status_code": getattr(exc, "status_code", None),
        }
        if session_id:
            extra["session_id"] = session_id

        code = int(getattr(exc, "status_code", 500) or 500)
        if 400 <= code < 500:
            logger.warning(str(getattr(exc, "detail", "HTTP error")), extra=extra)
        else:
            logger.error(str(getattr(exc, "detail", "HTTP error")), extra=extra)

        # Preserve existing custom 404 normalization behavior.
        if code == 404:
            return await not_found_handler(request, exc)

        # Delegate response rendering to FastAPI.
        return await http_exception_handler(request, exc)

    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(request, exc: RequestValidationError):
        # These errors happen before endpoint code runs, so we log here.
        # Keep it safe: log only path/method + pydantic error summary.
        logger = logging.getLogger("daan.validation")
        try:
            errors = exc.errors()
        except Exception:
            errors = [{"msg": str(exc)}]

        logger.warning(
            "Request validation failed",
            extra={
                "method": getattr(request, "method", None),
                "path": str(getattr(getattr(request, "url", None), "path", "")),
                "errors": errors,
            },
        )

        return JSONResponse(
            status_code=422,
            content={"detail": errors},
        )

    @app.exception_handler(DAANException)
    async def daan_exception_handler(request, exc: DAANException):
        """Sanitize DAANException for clients while logging full details server-side."""

        logger = logging.getLogger("daan.exceptions")
        session_id = None
        try:
            session_id = request.headers.get("X-Session-Id")
        except Exception:
            session_id = None

        extra = {
            "method": getattr(request, "method", None),
            "path": str(getattr(getattr(request, "url", None), "path", "")),
        }
        if session_id:
            extra["session_id"] = session_id

        # `str(exc)` includes Sandip-style traceback context.
        logger.error(str(exc), extra=extra)

        return JSONResponse(
            status_code=500,
            content={"detail": str(getattr(exc, "error_message", "Request failed"))},
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(request, exc: Exception):
        """Catch-all handler for unexpected errors.

        Logs full details server-side and returns a stable safe message to clients.
        """

        wrapped = DAANException("Request failed", exc)
        logger = logging.getLogger("daan.exceptions")

        session_id = None
        try:
            session_id = request.headers.get("X-Session-Id")
        except Exception:
            session_id = None

        extra = {
            "method": getattr(request, "method", None),
            "path": str(getattr(getattr(request, "url", None), "path", "")),
        }
        if session_id:
            extra["session_id"] = session_id

        logger.error(str(wrapped), extra=extra)

        return JSONResponse(
            status_code=500,
            content={"detail": "Request failed"},
        )

    @app.exception_handler(500)
    async def internal_error_handler(request, exc):
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error"},
        )

    return app


app = create_application()


if __name__ == "__main__":
    import uvicorn

    settings = get_settings()
    uvicorn.run(
        "daan.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.ENVIRONMENT == "development",
    )