"""Feedback enhancements: schema extraction/application and output scoring."""
