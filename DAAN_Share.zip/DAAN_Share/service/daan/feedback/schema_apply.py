"""Apply an extracted JSON schema/skeleton to an agent output.

Takes:
- draft_output: agent output text from rerun
- sample_schema: JSON schema object extracted from the user-provided sample

Returns:
- json_text: a valid JSON string matching the skeleton as closely as possible.
"""

from __future__ import annotations

import json
import re
from typing import Any

from daan.llm.llm_provider import get_llm_response_with_fallback


_SCHEMA_APPLY_PROMPT = """You are a formatting transformer.

You will be given:
1) A JSON schema/skeleton (structure only)
2) A draft output text (content)

Your job:
- Produce VALID JSON ONLY.
- The JSON MUST match the schema/skeleton structure as closely as possible:
  - Use the same keys/sections/arrays.
  - Preserve ordering of sections if represented as arrays.
- Populate values using information from the draft output.
- If some values are missing in the draft output, use null or empty string.
- Do not invent new keys outside the schema unless absolutely necessary; if you must, put them under a top-level key named "extra".

SCHEMA (JSON):
{schema_json}

DRAFT OUTPUT:
{draft_output}

Return ONLY the final JSON object:"""


def apply_schema_to_output_with_llm(
    *,
    draft_output: str,
    sample_schema: dict[str, Any],
    provider_name: str | None = None,
    max_tokens: int = 2048,
    temperature: float = 0.0,
) -> str:
    json_text, _, _ = apply_schema_to_output_with_io(
        draft_output=draft_output,
        sample_schema=sample_schema,
        provider_name=provider_name,
        max_tokens=max_tokens,
        temperature=temperature,
    )
    return json_text


def apply_schema_to_output_with_io(
    *,
    draft_output: str,
    sample_schema: dict[str, Any],
    provider_name: str | None = None,
    max_tokens: int = 2048,
    temperature: float = 0.0,
) -> tuple[str, str, str]:
    """Like apply_schema_to_output_with_llm(), but also returns (llm_prompt, llm_raw_response)."""
    schema_json = json.dumps(sample_schema or {}, ensure_ascii=False, indent=2, default=str)
    prompt = _SCHEMA_APPLY_PROMPT.format(
        schema_json=schema_json,
        draft_output=(draft_output or "")[:12000],
    )

    raw = get_llm_response_with_fallback(
        prompt=prompt,
        provider_name=provider_name,
        max_tokens=max_tokens,
        temperature=temperature,
    )

    obj = _parse_json_object(raw)
    return json.dumps(obj, ensure_ascii=False, indent=2, default=str), prompt, str(raw or "")


def _parse_json_object(raw: str) -> dict[str, Any]:
    text = (raw or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        text = text.strip()

    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass

    match = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if match:
        obj = json.loads(match.group(0))
        if isinstance(obj, dict):
            return obj

    raise ValueError("Schema application returned invalid JSON")
