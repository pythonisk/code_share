"""Schema Extractor Agent (DAAN5).

Mandatory behavior:
- Accept raw sample output file text (best-effort extracted by caller).
- Use LLM to return VALID JSON ONLY describing the document schema/skeleton.
- Never include actual sample values.

The JSON format is intentionally generic so it can represent markdown/text/tables.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from daan.llm.llm_provider import get_llm_response_with_fallback

logger = logging.getLogger(__name__)


_SCHEMA_EXTRACTION_PROMPT = """You are a Schema Extraction Agent.

Your ONLY job is to extract the STRUCTURE/SCHEMA of the document below.
Return a JSON object describing the output schema/skeleton that another agent can follow.

STRICT RULES:
- Output MUST be valid JSON only. No markdown fences. No extra text.
- Extract headings/sections hierarchy (if present).
- Extract table column headers (if present).
- Extract field labels (e.g. 'Risk ID', 'Owner', etc.).
- Extract list patterns (bulleted/numbered) as structural nodes.
- Preserve order.
- Do NOT include any actual data values, numbers, dates, names, IDs.
- Use placeholders only where needed; prefer describing keys/labels.

JSON SHAPE (example):
{{
    "schema_version": 1,
    "document_type": "unknown|markdown|table|json|xml|text",
    "sections": [
        {{"title": "<section title>", "children": [ ... ], "tables": [ ... ], "fields": [ ... ]}}
    ],
    "tables": [
        {{"name": "<table name>", "columns": ["Col1", "Col2"], "notes": ""}}
    ],
    "fields": [
        {{"name": "<field label>", "type": "string|number|object|array|unknown"}}
    ],
    "notes": ""
}}

--- DOCUMENT (may be truncated) ---
{file_content}
--- END DOCUMENT ---

Now output ONLY the JSON schema object:"""


def extract_schema_json_with_llm(
    *,
    file_text: str,
    filename: str = "",
    provider_name: str | None = None,
    max_tokens: int = 2048,
    temperature: float = 0.0,
) -> dict[str, Any]:
    if not (file_text or "").strip():
        raise ValueError("Empty file content")

    max_chars = 30000
    content = file_text.strip()
    if len(content) > max_chars:
        content = content[:max_chars] + "\n[...truncated for schema extraction...]"

    schema, _, _ = extract_schema_json_with_io(
        file_text=content,
        filename=filename,
        provider_name=provider_name,
        max_tokens=max_tokens,
        temperature=temperature,
    )

    # Ensure minimal required keys exist
    schema.setdefault("schema_version", 1)
    schema.setdefault("document_type", "unknown")
    schema.setdefault("sections", [])
    schema.setdefault("tables", [])
    schema.setdefault("fields", [])
    schema.setdefault("notes", "")

    return schema


def extract_schema_json_with_io(
    *,
    file_text: str,
    filename: str = "",
    provider_name: str | None = None,
    max_tokens: int = 2048,
    temperature: float = 0.0,
) -> tuple[dict[str, Any], str, str]:
    """Like extract_schema_json_with_llm(), but also returns (llm_prompt, llm_raw_response)."""
    if not (file_text or "").strip():
        raise ValueError("Empty file content")

    prompt = _SCHEMA_EXTRACTION_PROMPT.format(file_content=file_text)
    raw = get_llm_response_with_fallback(
        prompt=prompt,
        provider_name=provider_name,
        max_tokens=max_tokens,
        temperature=temperature,
    )

    schema = _parse_json_object(raw)
    schema.setdefault("schema_version", 1)
    schema.setdefault("document_type", "unknown")
    schema.setdefault("sections", [])
    schema.setdefault("tables", [])
    schema.setdefault("fields", [])
    schema.setdefault("notes", "")

    logger.debug(
        "Schema extracted via LLM for '%s' (keys=%s)",
        filename or "(unknown)",
        ",".join(sorted(schema.keys())),
    )
    return schema, prompt, str(raw or "")


def _parse_json_object(raw: str) -> dict[str, Any]:
    text = (raw or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        text = text.strip()

    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass

    match = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if match:
        obj = json.loads(match.group(0))
        if isinstance(obj, dict):
            return obj

    raise ValueError("Schema extractor returned invalid JSON")
