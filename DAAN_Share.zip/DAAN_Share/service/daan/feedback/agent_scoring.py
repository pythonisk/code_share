"""Per-agent output scoring for DAAN5.

This is adapted from the legacy Feedback_API_2 scoring logic, but uses
DAAN5's provider stack (daan.llm.llm_provider) and returns a stable dict
payload suitable for UI rendering + persistence.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, asdict
from typing import Any

from daan.llm.llm_provider import get_core_agent_model, get_llm_completion_with_fallback

logger = logging.getLogger(__name__)


@dataclass
class AgentScore:
    agent_id: str = ""
    agent_name: str = ""

    completeness_score: float = 0.0
    answer_relevance_score: float = 0.0
    context_score: float = 0.0
    overall_score: float = 0.0

    completeness_feedback: str = ""
    relevance_feedback: str = ""
    context_feedback: str = ""
    summary: str = ""

    THRESHOLD: int = 80

    @property
    def passed(self) -> bool:
        return self.overall_score >= self.THRESHOLD

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["passed"] = self.passed
        return data


_SCORING_PROMPT = """\
You are a strict quality-assurance evaluator for an AI agent pipeline.

You will be given these inputs about a single agent:
1) Input Context – what the agent received as context.
2) Input Keywords / Variables – the variables the agent was expected to use (may be empty).
3) Refined Prompt – the instruction/task given to the agent.
4) Agent Output – the text the agent produced.
5) Sample Output Schema (Optional) – a user-provided example of the desired output structure.

**CRITICAL EVALUATION RULE - What Constitutes "Inventing" Data:**
When evaluating if the agent "invented" or "hallucinated" information:
- Data present ANYWHERE in the Input Context is LEGITIMATE - the agent should use it
- This includes: all rows in tables, all items in lists, all objects in arrays, all keys in JSON, all fields in nested structures
- "Inventing" means creating information NOT PRESENT ANYWHERE in the provided Input Context
- Do not penalize the agent for being thorough and processing all provided input data

If a Sample Output Schema is provided:
- Treat it as STRUCTURE ONLY; do not expect identical values.
- Score schema adherence vs the sample schema.
- If the refined prompt contains output-format hints that conflict with the sample schema, IGNORE those hints.

Return ONLY a valid JSON object (no markdown fences, no extra text) with exactly these keys:
{{
    "completeness_score": <int 0-100>,
    "completeness_feedback": "<one-line explanation>",
    "answer_relevance_score": <int 0-100>,
    "relevance_feedback": "<one-line explanation>",
    "context_score": <int 0-100>,
    "context_feedback": "<one-line explanation>",
    "summary": "<2-3 sentence overall assessment>"
}}

---
Input Context:
{context}

Input Keywords / Variables:
{input_keywords}

Refined Prompt:
{prompt}

Agent Output (first 12000 chars):
{output}

Sample Output Schema (Optional):
{sample_output}
"""


def compute_agent_scores(
    *,
    agent_id: str,
    agent_name: str,
    context: str,
    prompt: str,
    output: str,
    input_keywords: str = "",
    sample_output: str = "",
    schema_authoritative: bool = False,
    max_tokens: int | None = None,
    temperature: float | None = None,
    provider_name: str | None = None,
) -> AgentScore:
    """Score a single agent output via the DAAN5 LLM provider stack."""

    max_ctx = 80000  # Handles very large structured inputs like mapping tables
    max_prompt = 5000
    max_output = 12000
    max_keywords = 3000
    max_sample = 10000

    ctx_trunc = (context or "")[:max_ctx]
    prompt_trunc = (prompt or "")[:max_prompt]
    out_trunc = (output or "")[:max_output]
    keywords_trunc = (input_keywords or "")[:max_keywords]
    sample_trunc = (sample_output or "")[:max_sample] if sample_output else "(none provided)"

    # When schema is authoritative, we keep the prompt but instruct evaluator to ignore conflicting
    # output-format hints. (This is included in prompt header text.)
    _ = schema_authoritative

    filled = _SCORING_PROMPT.format(
        context=ctx_trunc,
        input_keywords=keywords_trunc,
        prompt=prompt_trunc,
        output=out_trunc,
        sample_output=sample_trunc,
    )

    score = AgentScore(agent_id=agent_id, agent_name=agent_name)

    try:
        score, _, _, _ = compute_agent_scores_with_io(
            agent_id=agent_id,
            agent_name=agent_name,
            context=context,
            prompt=prompt,
            output=output,
            input_keywords=input_keywords,
            sample_output=sample_output,
            schema_authoritative=schema_authoritative,
            max_tokens=max_tokens,
            temperature=temperature,
            provider_name=provider_name,
        )
        return score
    except Exception as exc:  # noqa: BLE001
        logger.warning("Agent scoring failed for %s (%s): %s", agent_id, agent_name, exc)
        score.summary = f"Scoring failed: {exc}"
        return score


def compute_agent_scores_with_io(
    *,
    agent_id: str,
    agent_name: str,
    context: str,
    prompt: str,
    output: str,
    input_keywords: str = "",
    sample_output: str = "",
    schema_authoritative: bool = False,
    max_tokens: int | None = None,
    temperature: float | None = None,
    provider_name: str | None = None,
) -> tuple[AgentScore, str, str, dict[str, Any]]:
    """Like compute_agent_scores(), but also returns prompt, raw response, and metadata."""

    # max_ctx = 80000  # Handles very large structured inputs like mapping tables
    # max_prompt = 5000
    # max_output = 50000
    # max_keywords = 3000
    # max_sample = 10000

    # ctx_trunc = (context or "")[:max_ctx]
    # prompt_trunc = (prompt or "")[:max_prompt]
    # out_trunc = (output or "")[:max_output]
    # keywords_trunc = (input_keywords or "")[:max_keywords]
    # sample_trunc = (sample_output or "")[:max_sample] if sample_output else "(none provided)"

    _ = schema_authoritative

    llm_prompt = _SCORING_PROMPT.format(
        context=context,
        input_keywords=input_keywords,
        prompt=prompt,
        output=output,
        sample_output=sample_output,
    )

    score = AgentScore(agent_id=agent_id, agent_name=agent_name)

    llm_kwargs: dict[str, Any] = {}
    if max_tokens is not None:
        llm_kwargs["max_tokens"] = max_tokens
    # Scoring must be deterministic — identical output must yield identical scores.
    llm_kwargs["temperature"] = 0 if temperature is None else temperature

    scoring_model = get_core_agent_model("scoring")
    if scoring_model:
        llm_kwargs["model"] = scoring_model

    completion = get_llm_completion_with_fallback(
        prompt=llm_prompt,
        provider_name=provider_name,
        **llm_kwargs,
    )
    raw = str(completion.get("text") or "")

    data = _extract_json_object(raw)

    score.completeness_score = _clamp(data.get("completeness_score"))
    score.answer_relevance_score = _clamp(data.get("answer_relevance_score"))
    score.context_score = _clamp(data.get("context_score"))

    score.completeness_feedback = str(data.get("completeness_feedback") or "")
    score.relevance_feedback = str(data.get("relevance_feedback") or "")
    score.context_feedback = str(data.get("context_feedback") or "")
    score.summary = str(data.get("summary") or "")

    score.overall_score = round(
        (score.completeness_score + score.answer_relevance_score + score.context_score) / 3.0,
        1,
    )

    return score, llm_prompt, raw, completion


def _extract_json_object(raw: str) -> dict[str, Any]:
    """Extract and parse a JSON object from raw LLM text."""
    text = (raw or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        text = text.strip()

    # Fast path
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass

    # Heuristic: find first {...}
    match = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if match:
        candidate = match.group(0)
        obj = json.loads(candidate)
        if isinstance(obj, dict):
            return obj

    raise ValueError("LLM response was not valid JSON")


def _clamp(value: Any, lo: int = 0, hi: int = 100) -> float:
    try:
        v = float(value)
    except Exception:
        return 0.0
    return max(lo, min(hi, v))
