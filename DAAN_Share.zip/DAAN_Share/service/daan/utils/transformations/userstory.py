import re
from typing import Any, Dict, List, Tuple


EPIC_BLOCK_RE = re.compile(
	r'(?:<!--\s*EPIC_START\s*-->|&lt;!--\s*EPIC_START\s*--&gt;)' \
	r'(.*?)' \
	r'(?:<!--\s*EPIC_END\s*-->|&lt;!--\s*EPIC_END\s*--&gt;)',
	re.IGNORECASE | re.DOTALL,
)

STORY_BLOCK_RE = re.compile(
	r'(?:<!--\s*USER_STORY_START\s*-->|&lt;!--\s*USER_STORY_START\s*--&gt;)' \
	r'(.*?)' \
	r'(?:<!--\s*USER_STORY_END\s*-->|&lt;!--\s*USER_STORY_END\s*--&gt;)',
	re.IGNORECASE | re.DOTALL,
)


def extract_markdown_content(reviewed_output: Any) -> str:
	if isinstance(reviewed_output, dict) and isinstance(reviewed_output.get("content"), str):
		return reviewed_output["content"]
	if isinstance(reviewed_output, str):
		return reviewed_output
	return ""


def extract_epic_and_story_blocks(text: str) -> Tuple[str, List[str]]:
	epic_match = EPIC_BLOCK_RE.search(text or "")
	epic_block = epic_match.group(1).strip() if epic_match else ""
	story_blocks = [match.group(1).strip() for match in STORY_BLOCK_RE.finditer(text or "")]
	return epic_block, story_blocks


def extract_epic_summary(block: str, fallback: str) -> str:
	if not block:
		return fallback[:255]

	epic_name_bold = re.search(r'^\s*\*\*Epic Name:\*\*\s*(.+?)\s*$', block, re.IGNORECASE | re.MULTILINE)
	if epic_name_bold:
		return epic_name_bold.group(1).strip()[:255]

	epic_name = re.search(r'^\s*-\s*Epic Name:\s*(.+?)\s*$', block, re.IGNORECASE | re.MULTILINE)
	if epic_name:
		return epic_name.group(1).strip()[:255]

	title_bold = re.search(r'^\s*\*\*Title:\*\*\s*(.+?)\s*$', block, re.IGNORECASE | re.MULTILINE)
	if title_bold:
		return title_bold.group(1).strip()[:255]

	title = re.search(r'^\s*Title:\s*(.+?)\s*$', block, re.IGNORECASE | re.MULTILINE)
	if title:
		return title.group(1).strip()[:255]

	description_match = re.search(r'Epic\s+Description:\s*(.+?)(?:\s*-\s*|$)', block, re.IGNORECASE | re.DOTALL)
	if description_match:
		description = description_match.group(1).strip()
		first_line = description.split('\n')[0].strip() if description else ""
		if first_line:
			return first_line[:255]

	lines = [line.strip() for line in block.split('\n') if line.strip() and not line.strip().startswith('#')]
	for line in lines:
		if not line.startswith('<!--') and not line.startswith('&lt;'):
			return line[:255]

	return fallback[:255]


def extract_story_summary(block: str, fallback: str) -> str:
	if not block:
		return fallback[:255]

	title = re.search(r'^\s*Title:\s*(.+?)\s*$', block, re.IGNORECASE | re.MULTILINE)
	if title:
		return title.group(1).strip()[:255]

	title_bold = re.search(r'^\s*\*\*Title:\*\*\s*(.+?)\s*$', block, re.IGNORECASE | re.MULTILINE)
	if title_bold:
		return title_bold.group(1).strip()[:255]

	want_match = re.search(r'I\s+want\s+to\s+(.+?)(?:\s*So that|\s*$)', block, re.IGNORECASE | re.DOTALL)
	if want_match:
		capability = want_match.group(1).strip()
		first_line = capability.split('\n')[0].strip() if capability else ""
		if first_line:
			return first_line[:255]

	story_id_match = re.search(r'^\s*Story ID:\s*(US-[A-Za-z0-9_.\-]+)\s*$', block, re.IGNORECASE | re.MULTILINE)
	if story_id_match:
		return f"{story_id_match.group(1).strip()} - {fallback}"[:255]

	lines = [line.strip() for line in block.split('\n') if line.strip() and not line.strip().startswith('#')]
	for line in lines:
		if not line.startswith('<!--') and not line.startswith('&lt;'):
			return line[:255]

	return fallback[:255]


def extract_story_id(block: str, fallback: str) -> str:
	story_id_match = re.search(r'^\s*Story ID:\s*(US-[A-Za-z0-9_.\-]+)\s*$', block, re.IGNORECASE | re.MULTILINE)
	return story_id_match.group(1).strip() if story_id_match else fallback


def sanitize_for_jira_adf(text: str) -> str:
	if not text:
		return ""

	text = re.sub(r'\*\*(.+?)\*\*', r'\1', text)
	text = re.sub(r'\s\*([^*]+?)\*\s', r' \1 ', text)
	text = re.sub(r'^\s*\d+\.\s+', '', text, flags=re.MULTILINE)
	text = re.sub(r'^\s*[a-zA-Z]\.\s+', '', text, flags=re.MULTILINE)
	return re.sub(r'\n\s*\n\s*\n+', '\n\n', text).strip()


def validate_adf_document(adf_doc: Dict[str, Any]) -> None:
	assert adf_doc.get("type") == "doc", "Root type must be 'doc'"
	assert adf_doc.get("version") == 1, "ADF version must be 1"
	assert isinstance(adf_doc.get("content"), list), "ADF content must be a list"

	def walk(node: Any) -> None:
		if isinstance(node, dict):
			assert node.get("type") != "orderedList", "orderedList nodes not allowed"
			for value in node.values():
				if isinstance(value, (dict, list)):
					walk(value)
		elif isinstance(node, list):
			for item in node:
				walk(item)

	walk(adf_doc)


def build_adf_description_from_text(raw_text: str) -> Dict[str, Any]:
	sanitized = sanitize_for_jira_adf(raw_text)
	content: List[Dict[str, Any]] = []

	for line in sanitized.split("\n"):
		line = line.rstrip()
		if not line.strip():
			continue
		content.append(
			{
				"type": "paragraph",
				"content": [{"type": "text", "text": line}],
			}
		)

	adf_doc = {"type": "doc", "version": 1, "content": content}
	validate_adf_document(adf_doc)
	return adf_doc


def build_trello_epic_description(epic_block: str) -> str:
	return (epic_block or "").strip()


def build_trello_story_description(story_block: str, epic_summary: str = "") -> str:
	description = (story_block or "").strip()
	if epic_summary:
		description = description + f"\n\nParent Epic: {epic_summary}"
	return description
