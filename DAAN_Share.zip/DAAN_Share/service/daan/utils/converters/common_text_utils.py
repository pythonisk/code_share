import html
import re
from html.parser import HTMLParser
from typing import Any, Dict, List, Optional

import logging

# Share of characters belonging to alphabetic words. Real prose (including slide
# text, spreadsheets and scanned PDFs) measures 0.35-0.85; latin-1-decoded binary
# measures well under 0.10. Do not use a "printable ASCII" test instead - ordinary
# text contains curly quotes, non-breaking spaces and dashes.
MIN_READABILITY = 0.15

_WORD_RE = re.compile(r"[A-Za-z]{2,}")


def readability(text: str, sample_size: int = 20000) -> float:
    sample = text[:sample_size]
    if not sample:
        return 0.0
    return sum(len(word) for word in _WORD_RE.findall(sample)) / len(sample)


def is_probably_text(text: str, threshold: float = MIN_READABILITY) -> bool:
    return readability(text) >= threshold


class _VisibleHtmlExtractor(HTMLParser):
    _BLOCK_TAGS = {
        "address", "article", "aside", "blockquote", "br", "div", "dl", "dt", "dd",
        "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6",
        "header", "hr", "li", "main", "nav", "ol", "p", "pre", "section", "table", "tbody", "td",
        "tfoot", "th", "thead", "tr", "ul",
    }
    _SKIP_TAGS = {"head", "script", "style", "template", "noscript", "svg"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._skip_depth = 0
        self._hidden_depth = 0
        self._parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        normalized_tag = str(tag or "").lower()
        attr_map = {str(key or "").lower(): str(value or "") for key, value in attrs}
        if normalized_tag in self._SKIP_TAGS:
            self._skip_depth += 1
            return
        if self._is_hidden(attr_map):
            self._hidden_depth += 1
            return
        if normalized_tag == "li":
            self._append_break()
            self._parts.append("- ")
        elif normalized_tag in {"td", "th"}:
            if self._parts and not self._parts[-1].endswith(("\n", " ")):
                self._parts.append(" ")
        elif normalized_tag in self._BLOCK_TAGS:
            self._append_break()

    def handle_endtag(self, tag: str) -> None:
        normalized_tag = str(tag or "").lower()
        if normalized_tag in self._SKIP_TAGS and self._skip_depth:
            self._skip_depth -= 1
            return
        if self._hidden_depth and normalized_tag not in self._SKIP_TAGS:
            self._hidden_depth -= 1
            return
        if normalized_tag in {"tr", "table", "p", "div", "section", "article", "ul", "ol"}:
            self._append_break()

    def handle_data(self, data: str) -> None:
        if self._skip_depth or self._hidden_depth:
            return
        text = re.sub(r"\s+", " ", data or "").strip()
        if not text:
            return
        if self._parts and not self._parts[-1].endswith(("\n", " ", "- ")):
            self._parts.append(" ")
        self._parts.append(text)

    def text(self) -> str:
        joined = "".join(self._parts)
        joined = re.sub(r"[ \t]+\n", "\n", joined)
        joined = re.sub(r"\n{3,}", "\n\n", joined)
        return joined.strip()

    @staticmethod
    def _is_hidden(attrs: dict[str, str]) -> bool:
        if "hidden" in attrs:
            return True
        if str(attrs.get("aria-hidden", "")).strip().lower() == "true":
            return True
        style = str(attrs.get("style", "")).replace(" ", "").lower()
        return "display:none" in style or "visibility:hidden" in style

    def _append_break(self) -> None:
        if not self._parts:
            return
        if self._parts[-1].endswith("\n\n"):
            return
        if self._parts[-1].endswith("\n"):
            self._parts.append("\n")
        else:
            self._parts.append("\n\n")


def extract_html_text(content: str) -> str:
    parser = _VisibleHtmlExtractor()
    parser.feed(html.unescape(content or ""))
    parser.close()
    return parser.text()


def extract_structured_records(content: str) -> Dict[str, Any]:
    records = {}
    lines = content.split("\n")
    current_record = None
    current_record_content = []

    record_start_patterns = [
        r"^([A-Z][A-Za-z\s]+ID):\s*(\w+)$",
        r"^(ID|Code|Number):\s*(\w+)$",
        r"^([A-Z][A-Za-z\s]+)\s+(ID|Code|Number):\s*(\w+)$",
    ]

    for line in lines:
        line = line.strip()
        if not line:
            if current_record_content:
                current_record_content.append("")
            continue

        is_record_start = False
        for pattern in record_start_patterns:
            match = re.match(pattern, line)
            if match:
                if current_record and current_record_content:
                    records[current_record] = {
                        "content": "\n".join(current_record_content).strip(),
                        "type": "structured_record",
                    }

                if len(match.groups()) == 2:
                    current_record = f"{match.group(1)}: {match.group(2)}"
                else:
                    current_record = f"{match.group(1)} {match.group(2)}: {match.group(3)}"
                current_record_content = []
                is_record_start = True
                break

        if not is_record_start and current_record:
            current_record_content.append(line)

    if current_record and current_record_content:
        records[current_record] = {
            "content": "\n".join(current_record_content).strip(),
            "type": "structured_record",
        }

    return records if records else None


def extract_paragraph_sections(content: str) -> Dict[str, Any]:
    paragraphs = [paragraph.strip() for paragraph in content.split("\n\n") if paragraph.strip()]
    sections = {}

    for index, paragraph in enumerate(paragraphs):
        lines = paragraph.split("\n")
        first_line = lines[0].strip()

        if (
            len(lines) > 1
            and len(first_line) < 100
            and not first_line.endswith(".")
            and (first_line[0].isupper() or first_line.startswith(("Chapter", "Section", "Part")))
        ):
            header = first_line
            content_text = "\n".join(lines[1:]).strip()
        else:
            header = f"Paragraph {index + 1}"
            content_text = paragraph

        if content_text:
            sections[header] = {
                "content": content_text,
                "type": "paragraph_content",
                "header_type": "auto_generated",
            }

    return sections


def extract_text_sections(content: str, lines: List[str]) -> Dict[str, Any]:
    sections = {}
    current_header = None
    current_content = []

    header_patterns = [
        (r"^#{1,6}\s+(.+)$", "markdown_header"),
        (r"^(.+)\n[=\-]{3,}$", "underlined_header"),
        (r"^(\d+\.?\s+.+)$", "numbered_section"),
        (r"^([A-Z][A-Z\s]{2,})$", "caps_header"),
        (r"^([A-Z][a-zA-Z\s]+):?\s*$", "title_case_header"),
        (r"^\[([^\]]+)\]$", "bracketed_header"),
        (r"^\(([^)]+)\)$", "parenthesized_header"),
    ]

    index = 0
    while index < len(lines):
        line = lines[index].strip()

        if not line:
            if current_content and current_content[-1] != "":
                current_content.append("")
            index += 1
            continue

        is_header = False
        header_text = None
        header_type = None

        for pattern, pattern_type in header_patterns:
            if pattern_type == "underlined_header":
                if index + 1 < len(lines):
                    next_line = lines[index + 1].strip()
                    if re.match(r"^[=\-]{3,}$", next_line):
                        header_text = line.strip()
                        header_type = pattern_type
                        is_header = True
                        index += 1
                        break
            else:
                match = re.match(pattern, line)
                if match:
                    header_text = match.group(1).strip()
                    header_type = pattern_type
                    is_header = True
                    break

        if is_header and header_text:
            if current_header and current_content:
                content_text = "\n".join(current_content).strip()
                if content_text:
                    sections[current_header] = {
                        "content": content_text,
                        "type": "section_content",
                        "header_type": sections.get(current_header, {}).get("header_type", "unknown"),
                    }

            current_header = header_text
            current_content = []
            sections[current_header] = {
                "content": "",
                "type": "section_header",
                "header_type": header_type,
            }
        else:
            if current_header:
                current_content.append(line)
            else:
                if "Preamble" not in sections:
                    sections["Preamble"] = {
                        "content": line,
                        "type": "section_content",
                        "header_type": "default",
                    }
                else:
                    sections["Preamble"]["content"] += f"\n{line}"

        index += 1

    if current_header and current_content:
        content_text = "\n".join(current_content).strip()
        if content_text:
            structured_records = extract_structured_records(content_text)
            sections[current_header]["content"] = content_text
            sections[current_header]["type"] = "section_content"
            if structured_records:
                sections[current_header]["structured_records"] = structured_records

    if not sections:
        sections.update(extract_paragraph_sections(content))

    return sections


def convert_text_file(file_path: str, logger_: Optional[logging.Logger] = None) -> Dict[str, Any]:
    logger = logger_ or logging.getLogger(__name__)
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as file:
            content = file.read()

        file_ext = str(file_path).lower().rsplit('.', 1)[-1] if '.' in str(file_path) else ''
        if file_ext in {"html", "htm"}:
            content = extract_html_text(content)

        lines = content.splitlines()
        structured_content = extract_text_sections(content, lines)

        return {
            "type": "text_file",
            "content": content,
            "lines": lines,
            "structured_sections": structured_content,
            "summary": {
                "total_lines": len(lines),
                "total_characters": len(content),
                "non_empty_lines": len([line for line in lines if line.strip()]),
                "sections_found": len(structured_content),
                "encoding": "utf-8",
            },
        }
    except Exception as exc:
        logger.error(f"Error reading text file {file_path}: {str(exc)}")
        return {"error": f"Failed to read text file: {str(exc)}"}


def convert_binary_file_as_text(file_path: str, logger_: Optional[logging.Logger] = None) -> Dict[str, Any]:
    logger = logger_ or logging.getLogger(__name__)
    try:
        with open(file_path, 'rb') as file:
            raw_content = file.read()

        try:
            content = raw_content.decode('utf-8')
        except UnicodeDecodeError:
            content = raw_content.decode('latin-1', errors='ignore')

        # latin-1 never raises, so a genuinely binary file would otherwise be
        # returned as "text" and indexed as mojibake.
        if not is_probably_text(content):
            message = f"File is binary, not text, and has no registered converter: {file_path}"
            logger.error(message)
            return {"error": message}

        return {
            "type": "binary_file_as_text",
            "content": content,
            "summary": {
                "file_size_bytes": len(raw_content),
                "decoded_as": "utf-8 or latin-1",
                "note": "Unsupported format, converted as text",
            },
        }
    except Exception as exc:
        logger.error(f"Error reading binary file {file_path}: {str(exc)}")
        return {"error": f"Failed to read file: {str(exc)}"}
