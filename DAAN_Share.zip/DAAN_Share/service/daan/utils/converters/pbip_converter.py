import logging
import os
import json
from datetime import datetime
from typing import Any, Dict, Tuple,Optional

from .base_converter import BaseFileConverter
from .common_powerbi_utils import (
    parse_tmdl_relationship,
    parse_tmdl_table,
    validate_powerbi_schema,
)

logger = logging.getLogger(__name__)


class PbipConverter(BaseFileConverter):
    def _parse_pbip_project(self, pbip_folder: str) -> Dict[str, Any]:
        try:
            model_result = self._extract_pbip_model_json(pbip_folder)
            layout_result = self._extract_pbip_layout_json(pbip_folder)

            result = {
                "source": {
                    "fileType": "PBIP",
                    "path": pbip_folder,
                    "extractionMethod": "tmdl_folder",
                    "generatedAt": datetime.now().isoformat(),
                },
                "model": model_result,
                "layout": layout_result,
            }
            validate_powerbi_schema(result, "pbip_project", logger_=logger)
            return result
        except Exception as exc:
            logger.error(f"Error parsing PBIP project: {str(exc)}")
            return {
                "source": {
                    "fileType": "PBIP",
                    "path": pbip_folder,
                    "extractionMethod": "error",
                    "generatedAt": datetime.now().isoformat(),
                },
                "model": {"tables": [], "measures": [], "relationships": []},
                "layout": {"reportFilters": [], "pages": []},
                "error": str(exc),
            }

    def _find_pbip_subfolders(self, pbip_folder: str) -> Tuple[Optional[str], Optional[str]]:
        semantic_model_dir = None
        report_dir = None

        if not os.path.isdir(pbip_folder):
            return None, None

        for entry in os.listdir(pbip_folder):
            full = os.path.join(pbip_folder, entry)
            if not os.path.isdir(full):
                continue
            if entry.endswith(".SemanticModel"):
                semantic_model_dir = full
            elif entry.endswith(".Report"):
                report_dir = full

        return semantic_model_dir, report_dir

    def _extract_pbip_model_json(self, pbip_folder: str) -> Dict[str, Any]:
        semantic_dir, _ = self._find_pbip_subfolders(pbip_folder)

        tables = []
        measures = []
        relationships = []

        if not semantic_dir:
            logger.warning(f"No .SemanticModel folder found in {pbip_folder}")
            return {"tables": [], "measures": [], "relationships": []}

        definition_dir = os.path.join(semantic_dir, "definition")
        tables_dir = os.path.join(definition_dir, "tables")
        if os.path.isdir(tables_dir):
            for filename in sorted(os.listdir(tables_dir)):
                if not filename.endswith(".tmdl"):
                    continue
                file_path = os.path.join(tables_dir, filename)
                try:
                    with open(file_path, "r", encoding="utf-8") as file:
                        parsed = parse_tmdl_table(file.read())

                    for measure in parsed.pop("measures", []):
                        if parsed.get("name") and measure.get("name"):
                            measures.append(
                                {
                                    "table": parsed["name"],
                                    "name": measure["name"],
                                    "expression": measure.get("expression", "") or "",
                                }
                            )

                    if parsed.get("name"):
                        tables.append(
                            {
                                "name": parsed["name"],
                                "columns": parsed.get("columns", []),
                                "hidden": bool(parsed.get("hidden", False)),
                            }
                        )
                except Exception as exc:
                    logger.debug(f"Error parsing TMDL table {filename}: {exc}")

        relationships_dir = os.path.join(definition_dir, "relationships")
        if os.path.isdir(relationships_dir):
            for filename in sorted(os.listdir(relationships_dir)):
                if not filename.endswith(".tmdl"):
                    continue
                file_path = os.path.join(relationships_dir, filename)
                try:
                    with open(file_path, "r", encoding="utf-8") as file:
                        relationship = parse_tmdl_relationship(file.read())
                    if relationship:
                        relationships.append(relationship)
                except Exception as exc:
                    logger.debug(f"Error parsing TMDL relationship {filename}: {exc}")

        tables.sort(key=lambda x: x["name"])
        for table in tables:
            table["columns"].sort(key=lambda c: c["name"])
        measures.sort(key=lambda x: (x["table"], x["name"]))
        relationships.sort(key=lambda x: (x["fromTable"], x["fromColumn"], x["toTable"], x["toColumn"]))

        return {"tables": tables, "measures": measures, "relationships": relationships}

    def _extract_pbip_layout_json(self, pbip_folder: str) -> Dict[str, Any]:
        _, report_dir = self._find_pbip_subfolders(pbip_folder)
        if not report_dir:
            logger.warning(f"No .Report folder found in {pbip_folder}")
            return {"reportFilters": [], "pages": []}

        definition_dir = os.path.join(report_dir, "definition")
        pages_dir = os.path.join(definition_dir, "pages")
        if not os.path.isdir(pages_dir):
            return {"reportFilters": [], "pages": []}

        order_lookup = {}
        pages_meta_file = os.path.join(pages_dir, "pages.json")
        if os.path.isfile(pages_meta_file):
            try:
                with open(pages_meta_file, "r", encoding="utf-8") as file:
                    meta = json.load(file)
                page_order = meta.get("pageOrder", []) or []
                order_lookup = {name: idx for idx, name in enumerate(page_order)}
            except Exception:
                order_lookup = {}

        pages = []
        for page_folder_name in sorted(os.listdir(pages_dir)):
            page_folder = os.path.join(pages_dir, page_folder_name)
            if not os.path.isdir(page_folder):
                continue

            page_json_path = os.path.join(page_folder, "page.json")
            if not os.path.isfile(page_json_path):
                continue

            try:
                with open(page_json_path, "r", encoding="utf-8") as file:
                    page_data = json.load(file)

                page_name = page_data.get("displayName") or page_data.get("name", page_folder_name)
                section_name = page_data.get("name", page_folder_name)
                display_order = order_lookup.get(section_name, 999)

                visuals = []
                visuals_dir = os.path.join(page_folder, "visuals")
                if os.path.isdir(visuals_dir):
                    for vis_folder_name in sorted(os.listdir(visuals_dir)):
                        vis_folder = os.path.join(visuals_dir, vis_folder_name)
                        if not os.path.isdir(vis_folder):
                            continue

                        vis_json_path = os.path.join(vis_folder, "visual.json")
                        if not os.path.isfile(vis_json_path):
                            continue

                        try:
                            with open(vis_json_path, "r", encoding="utf-8") as file:
                                vis_data = json.load(file)

                            visual_id = vis_data.get("name", vis_folder_name)
                            visual_block = vis_data.get("visual", {}) or {}
                            visual_type = visual_block.get("visualType", "unknown")
                            query_intent = self._extract_pbip_query_intent(vis_data)

                            visuals.append(
                                {
                                    "id": str(visual_id),
                                    "type": str(visual_type),
                                    "queryIntent": query_intent,
                                }
                            )
                        except Exception as exc:
                            logger.debug(f"Error parsing PBIP visual {vis_folder_name}: {exc}")

                visuals.sort(key=lambda v: v["id"])
                pages.append({"name": str(page_name), "displayOrder": int(display_order), "visuals": visuals})

            except Exception as exc:
                logger.debug(f"Error parsing PBIP page {page_folder_name}: {exc}")

        pages.sort(key=lambda p: (p.get("displayOrder", 999), p["name"]))
        return {"reportFilters": [], "pages": pages}

    def _extract_pbip_query_intent(self, visual_json: Dict[str, Any]) -> Dict[str, Any]:
        query_intent: Dict[str, Any] = {
            "dimensions": [],
            "measures": [],
            "filters": [],
            "sort": [],
            "limit": None,
        }

        try:
            visual = visual_json.get("visual", {}) or {}
            query_state = (visual.get("query", {}) or {}).get("queryState", {}) or {}

            for _, role_data in query_state.items():
                projections = role_data.get("projections", []) or []
                for proj in projections:
                    field_def = proj.get("field", {}) or {}
                    native_ref = proj.get("nativeQueryRef", "") or ""

                    if "Measure" in field_def:
                        measure_block = field_def.get("Measure", {}) or {}
                        name = native_ref or measure_block.get("Property", "")
                        if name:
                            query_intent["measures"].append({"name": str(name)})

                    elif "Column" in field_def:
                        column_block = field_def.get("Column", {}) or {}
                        entity = ((column_block.get("Expression", {}) or {}).get("SourceRef", {}) or {}).get(
                            "Entity", None
                        )
                        prop = native_ref or column_block.get("Property", "")
                        if prop:
                            query_intent["dimensions"].append({"table": entity, "field": str(prop)})

                    elif "Aggregation" in field_def:
                        agg_block = field_def.get("Aggregation", {}) or {}
                        inner = (agg_block.get("Expression", {}) or {}).get("Column", {}) or {}
                        entity = ((inner.get("Expression", {}) or {}).get("SourceRef", {}) or {}).get(
                            "Entity", None
                        )
                        prop = native_ref or inner.get("Property", "")
                        if prop:
                            query_intent["measures"].append({"name": str(prop)})

        except Exception as exc:
            logger.debug(f"Could not extract PBIP query intent: {exc}")

        query_intent["dimensions"].sort(key=lambda x: (str(x.get("table") or ""), str(x.get("field") or "")))
        query_intent["measures"].sort(key=lambda x: str(x.get("name") or ""))
        return query_intent

    def convert(self, file_path: str) -> Dict[str, Any]:
        try:
            pbip_folder = os.path.dirname(os.path.abspath(file_path))
            result = self._parse_pbip_project(pbip_folder)
            return {
                "type": "pbip_project",
                "model": result.get("model", {}),
                "layout": result.get("layout", {}),
                "source": result.get("source", {}),
            }
        except Exception as exc:
            logger.error(f"Error converting pbip_project file {file_path}: {exc}")
            return {
                "type": "pbip_project",
                "error": f"Failed to convert pbip_project file: {str(exc)}",
            }
