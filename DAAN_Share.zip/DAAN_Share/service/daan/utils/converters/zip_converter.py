"""
Converter for .zip archives.

Extracts contents to a temporary directory, detects project types
(PBIP, PBIT, PBIX, Tableau), converts them via their specialised
converters, and also converts every remaining file individually via
FileToJsonConverter so that downstream partitioners can handle each
file type properly (e.g. TabularPartitioner for CSVs).

The result always has a uniform shape:

    {
        "type": "zip_archive",
        "projects": [ ... ],          # project-level extractions (PBIP, etc.)
        "files": { relpath: data },   # per-file conversions for non-project files
        "source": { ... },
    }

ZipPartitioner knows how to split this into per-file partitions.
"""

import logging
import os
import tempfile
import shutil
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Set

from .base_converter import BaseFileConverter

logger = logging.getLogger(__name__)

# Extensions that are internal to BI projects and should NOT be
# converted as standalone files when a project converter already
# handles them.
_PBIP_INTERNAL_EXTS = {
    ".tmdl", ".pbir", ".platform", ".pbidataset",
}


def _long_path(p: str) -> str:
    """Return a Windows extended-length path (\\\\?\\) when needed."""
    if os.name == "nt":
        p = os.path.normpath(os.path.abspath(p))
        if not p.startswith("\\\\?\\"):
            p = "\\\\?\\" + p
    return p


class ZipConverter(BaseFileConverter):
    """Handles .zip files by extracting and delegating to specialised converters."""

    # ------------------------------------------------------------------
    # Public API (BaseFileConverter contract)
    # ------------------------------------------------------------------

    def convert(self, file_path: str) -> Dict[str, Any]:
        filename = os.path.basename(file_path)
        tmp_dir = None

        try:
            if not zipfile.is_zipfile(file_path):
                return self._error_result(filename, "File is not a valid zip archive")

            tmp_dir = tempfile.mkdtemp(prefix="zip_conv_")
            extract_root = _long_path(os.path.join(tmp_dir, Path(filename).stem))
            os.makedirs(extract_root, exist_ok=True)

            self._safe_extract(file_path, extract_root)

            result = self._convert_all(extract_root, filename)
            return result

        except Exception as exc:
            logger.error("Error converting zip file %s: %s", file_path, exc)
            return self._error_result(filename, str(exc))
        finally:
            if tmp_dir:
                lp = _long_path(tmp_dir)
                if os.path.exists(lp):
                    shutil.rmtree(lp, ignore_errors=True)

    # ------------------------------------------------------------------
    # Extraction
    # ------------------------------------------------------------------

    @staticmethod
    def _safe_extract(zip_path: str, target_dir: str) -> List[str]:
        """Extract zip contents with zip-slip prevention."""
        extracted: List[str] = []

        with zipfile.ZipFile(zip_path, "r") as zf:
            for member in zf.infolist():
                member_path = Path(member.filename)

                # Security: reject absolute and parent-traversal paths
                if member_path.is_absolute() or ".." in member_path.parts:
                    logger.warning("Skipping zip member with unsafe path: %s", member.filename)
                    continue

                # Skip directories and macOS resource forks
                if member.is_dir() or member.filename.startswith("__MACOSX"):
                    continue

                dest = os.path.join(target_dir, member.filename)
                dest = _long_path(dest)
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with zf.open(member) as src, open(dest, "wb") as dst:
                    dst.write(src.read())
                extracted.append(member.filename)

        logger.info("Extracted %d files from zip into %s", len(extracted), target_dir)
        return extracted

    # ------------------------------------------------------------------
    # Core: convert ALL contents
    # ------------------------------------------------------------------

    def _convert_all(self, extract_root: str, zip_filename: str) -> Dict[str, Any]:
        """Walk the extracted tree, convert projects AND individual files."""
        from daan.utils.file_to_json import FileToJsonConverter

        # --- Phase 1: detect project-level artefacts ---
        pbip_files: List[str] = []
        pbit_files: List[str] = []
        pbix_files: List[str] = []
        tableau_files: List[str] = []

        for root, _dirs, filenames in os.walk(extract_root):
            for fname in filenames:
                ext = os.path.splitext(fname)[1].lower()
                full = os.path.join(root, fname)
                if ext == ".pbip":
                    pbip_files.append(full)
                elif ext == ".pbit":
                    pbit_files.append(full)
                elif ext == ".pbix":
                    pbix_files.append(full)
                elif ext in (".twbx", ".twb"):
                    tableau_files.append(full)

        # --- Phase 2: convert project artefacts ---
        projects: List[Dict[str, Any]] = []
        # Collect paths that belong to a project so we skip them in Phase 3
        project_owned_dirs: Set[str] = set()

        if pbip_files:
            self._convert_pbip_projects(pbip_files, projects, project_owned_dirs)

        key_files = pbit_files + pbix_files + tableau_files
        if key_files:
            self._convert_key_files(key_files, projects, project_owned_dirs)

        # --- Phase 3: convert remaining individual files ---
        file_converter = FileToJsonConverter()
        individual_files: Dict[str, Dict[str, Any]] = {}

        for root, _dirs, filenames in os.walk(extract_root):
            # Skip directories owned by a project converter
            if any(root.startswith(d) for d in project_owned_dirs):
                continue
            for fname in filenames:
                ext = os.path.splitext(fname)[1].lower()
                # Skip project anchor files (already handled) and internal BI files
                if ext in (".pbip", ".pbit", ".pbix", ".twbx", ".twb"):
                    continue
                if ext in _PBIP_INTERNAL_EXTS:
                    continue

                full = os.path.join(root, fname)
                rel_path = os.path.relpath(full, extract_root).replace("\\", "/")

                if not file_converter.is_file_supported(full):
                    continue

                try:
                    converted = file_converter.convert_file_to_json(full)
                    individual_files[rel_path] = converted
                except Exception as exc:
                    logger.warning("Failed to convert %s inside zip: %s", rel_path, exc)

        logger.info(
            "Zip '%s': %d project(s), %d individual file(s) converted",
            zip_filename, len(projects), len(individual_files),
        )

        return {
            "type": "zip_archive",
            "projects": projects,
            "files": individual_files,
            "source": {
                "fileType": "ZIP",
                "originalFile": zip_filename,
                "projectsFound": len(projects),
                "individualFiles": len(individual_files),
                "generatedAt": datetime.now().isoformat(),
            },
        }

    # ------------------------------------------------------------------
    # Project converters
    # ------------------------------------------------------------------

    @staticmethod
    def _convert_pbip_projects(
        pbip_files: List[str],
        projects: List[Dict[str, Any]],
        project_owned_dirs: Set[str],
    ) -> None:
        from .pbip_converter import PbipConverter

        converter = PbipConverter()
        for pbip_path in pbip_files:
            try:
                result = converter.convert(pbip_path)
                result["_source_file"] = os.path.basename(pbip_path)
                projects.append(result)
                # Mark the pbip folder and its .SemanticModel / .Report siblings
                project_dir = os.path.dirname(os.path.abspath(pbip_path))
                project_owned_dirs.add(project_dir)
            except Exception as exc:
                logger.error("Error converting PBIP %s: %s", pbip_path, exc)

    @staticmethod
    def _convert_key_files(
        key_files: List[str],
        projects: List[Dict[str, Any]],
        project_owned_dirs: Set[str],
    ) -> None:
        from .pbit_converter import PbitConverter
        from .pbix_converter import PbixConverter
        from .tableau_converter import TableauConverter

        converter_map = {
            ".pbit": PbitConverter,
            ".pbix": PbixConverter,
            ".twbx": TableauConverter,
            ".twb": TableauConverter,
        }

        for fpath in key_files:
            ext = os.path.splitext(fpath)[1].lower()
            conv_cls = converter_map.get(ext)
            if not conv_cls:
                continue
            try:
                result = conv_cls().convert(fpath)
                result["_source_file"] = os.path.basename(fpath)
                projects.append(result)
                project_owned_dirs.add(os.path.dirname(os.path.abspath(fpath)))
            except Exception as exc:
                logger.error("Error converting %s inside zip: %s", fpath, exc)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _error_result(filename: str, error_msg: str) -> Dict[str, Any]:
        return {
            "type": "zip_archive",
            "projects": [],
            "files": {},
            "error": f"Failed to process zip: {error_msg}",
            "source": {
                "fileType": "ZIP",
                "originalFile": filename,
                "extractionMethod": "error",
                "generatedAt": datetime.now().isoformat(),
            },
        }
