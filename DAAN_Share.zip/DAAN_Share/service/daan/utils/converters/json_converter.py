import json
import logging
from typing import Any, Dict, Optional

from .base_converter import BaseFileConverter
from .common_text_utils import convert_text_file


class JsonConverter(BaseFileConverter):
    def __init__(self, logger_: Optional[logging.Logger] = None):
        self._logger = logger_ or logging.getLogger(__name__)

    def convert(self, file_path: str) -> Dict[str, Any]:
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                data = json.load(file)
            return {
                "type": "json_file",
                "content": data,
                "summary": {
                    "structure_type": type(data).__name__,
                    "is_valid_json": True,
                },
            }
        except json.JSONDecodeError as exc:
            self._logger.error(f"Invalid JSON in file {file_path}: {str(exc)}")
            return convert_text_file(file_path, logger_=self._logger)
        except Exception as exc:
            self._logger.error(f"Error reading JSON file {file_path}: {str(exc)}")
            return {"error": f"Failed to read JSON file: {str(exc)}"}
