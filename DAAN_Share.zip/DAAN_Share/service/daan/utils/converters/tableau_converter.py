import logging
import os
import zipfile
from typing import Any, Dict

from .base_converter import BaseFileConverter
from .common_tableau_utils import build_compact_spec

logger = logging.getLogger(__name__)


class TableauConverter(BaseFileConverter):
    def convert(self, file_path: str) -> Dict[str, Any]:
        try:
            file_ext = os.path.splitext(file_path)[1].lower()
            filename = os.path.basename(file_path)

            twb_content: Dict[str, Any] = {}
            embedded_files: Dict[str, Any] = {}

            if file_ext == ".twbx":
                try:
                    with zipfile.ZipFile(file_path, "r") as twbx_zip:
                        twb_file = None
                        for file_info in twbx_zip.filelist:
                            if file_info.filename.endswith(".twb"):
                                twb_file = file_info.filename
                                break

                        if twb_file:
                            with twbx_zip.open(twb_file) as file_obj:
                                twb_content = self._parse_tableau_xml(file_obj, twb_file)

                        for file_info in twbx_zip.filelist:
                            if not file_info.is_dir() and file_info.filename not in [twb_file]:
                                try:
                                    if file_info.filename.endswith((".csv", ".txt", ".xlsx", ".xls", ".xml")):
                                        with twbx_zip.open(file_info) as file_obj:
                                            file_content = file_obj.read()
                                            embedded_files[file_info.filename] = {
                                                "size_bytes": len(file_content),
                                                "type": os.path.splitext(file_info.filename)[1].lower(),
                                            }
                                except Exception as exc:
                                    logger.warning(f"Could not extract {file_info.filename}: {exc}")
                except zipfile.BadZipFile:
                    logger.error(f"Invalid ZIP/TWBX file: {file_path}")
                    return {"error": f"Invalid TWBX file: {file_path}"}

            elif file_ext == ".twb":
                try:
                    with open(file_path, "rb") as file_obj:
                        twb_content = self._parse_tableau_xml(file_obj, filename)
                except Exception as exc:
                    logger.error(f"Error parsing TWB file {file_path}: {exc}")
                    return {"error": f"Failed to parse TWB file: {str(exc)}"}

            metadata = self._extract_tableau_metadata(twb_content)

            try:
                compact_spec = build_compact_spec(twb_content)
            except Exception as exc:
                logger.warning(f"Compact spec generation failed, falling back to raw content: {exc}")
                compact_spec = None

            result = {
                "type": "tableau_file",
                "metadata": metadata,
                "embedded_files": embedded_files,
                "summary": {
                    "file_format": file_ext,
                    "data_sources_count": len(metadata.get("data_sources", [])),
                    "worksheets_count": len(metadata.get("worksheets", [])),
                    "dashboards_count": len(metadata.get("dashboards", [])),
                    "embedded_files_count": len(embedded_files),
                    "measures_count": len(metadata.get("measures", [])),
                    "relationships_count": len(metadata.get("relationships", [])),
                },
            }

            if compact_spec:
                result["spec"] = compact_spec
            else:
                result["content"] = twb_content

            return result

        except Exception as exc:
            logger.error(f"Error processing Tableau file {file_path}: {str(exc)}")
            return {"error": f"Failed to process Tableau file: {str(exc)}"}

    def _parse_tableau_xml(self, file_obj, filename: str) -> Dict[str, Any]:
        try:
            import xml.etree.ElementTree as ET

            tree = ET.parse(file_obj)
            root = tree.getroot()

            def element_to_dict(element):
                result = {}
                if element.attrib:
                    result["@attributes"] = element.attrib
                if element.text and element.text.strip():
                    if len(element) == 0:
                        return element.text.strip()
                    result["#text"] = element.text.strip()

                for child in element:
                    child_data = element_to_dict(child)
                    if child.tag in result:
                        if not isinstance(result[child.tag], list):
                            result[child.tag] = [result[child.tag]]
                        result[child.tag].append(child_data)
                    else:
                        result[child.tag] = child_data

                return result

            return {
                "root_tag": root.tag,
                "content": element_to_dict(root),
                "filename": filename,
            }
        except Exception as exc:
            logger.error(f"Error parsing Tableau XML from {filename}: {exc}")
            return {"error": str(exc)}

    def _extract_tableau_metadata(self, twb_content: Dict[str, Any]) -> Dict[str, Any]:
        metadata = {
            "data_sources": [],
            "measures": [],
            "relationships": [],
            "worksheets": [],
            "dashboards": [],
        }

        try:
            content = twb_content.get("content", {})
            if not isinstance(content, dict):
                return metadata

            def _get_items(parent_dict, container_key, child_key):
                container = parent_dict.get(container_key, {})
                if isinstance(container, list):
                    return container
                if isinstance(container, dict):
                    children = container.get(child_key, [])
                    if isinstance(children, list):
                        return children
                    if isinstance(children, dict):
                        return [children]
                    if child_key not in container and "@attributes" in container:
                        return [container]
                return []

            datasource_items = _get_items(content, "datasources", "datasource")
            for ds in datasource_items:
                if not isinstance(ds, dict):
                    continue
                ds_name = ds.get("@attributes", {}).get("name", "") or ds.get("@attributes", {}).get("caption", "Unknown")
                ds_caption = ds.get("@attributes", {}).get("caption", ds_name)
                tables = []
                fields = []

                connection = ds.get("connection", {})
                if isinstance(connection, dict):
                    relations = connection.get("relation", [])
                    if isinstance(relations, dict):
                        relations = [relations]
                    elif not isinstance(relations, list):
                        relations = []

                    for rel in relations:
                        if not isinstance(rel, dict):
                            continue
                        rel_attrs = rel.get("@attributes", {})
                        rel_name = rel_attrs.get("name", "") or rel_attrs.get("table", "")
                        rel_type = rel_attrs.get("type", "")

                        if rel_name:
                            tables.append(rel_name)

                        if rel_type == "join":
                            join_type = rel_attrs.get("join", "inner")
                            clause = rel.get("clause", {})
                            if isinstance(clause, dict):
                                expression = clause.get("expression", {})
                                if isinstance(expression, dict):
                                    left_expr = expression.get("expression", [])
                                    if isinstance(left_expr, list) and len(left_expr) >= 2:
                                        left_table = left_expr[0].get("@attributes", {}).get("name", "") if isinstance(left_expr[0], dict) else ""
                                        right_table = left_expr[1].get("@attributes", {}).get("name", "") if isinstance(left_expr[1], dict) else ""
                                        if left_table and right_table:
                                            metadata["relationships"].append(
                                                {
                                                    "name": f"{left_table} {join_type} join {right_table}",
                                                    "type": join_type,
                                                    "left_table": left_table,
                                                    "right_table": right_table,
                                                }
                                            )

                            nested_relations = rel.get("relation", [])
                            if isinstance(nested_relations, dict):
                                nested_relations = [nested_relations]
                            for nested_rel in nested_relations:
                                if isinstance(nested_rel, dict):
                                    nested_name = nested_rel.get("@attributes", {}).get("name", "") or nested_rel.get("@attributes", {}).get("table", "")
                                    if nested_name and nested_name not in tables:
                                        tables.append(nested_name)

                columns = ds.get("column", [])
                if isinstance(columns, dict):
                    columns = [columns]
                elif not isinstance(columns, list):
                    columns = []

                for col in columns:
                    if not isinstance(col, dict):
                        continue
                    col_attrs = col.get("@attributes", {})
                    col_name = col_attrs.get("caption", "") or col_attrs.get("name", "")
                    col_name = col_name.strip("[]")

                    calculation = col.get("calculation", {})
                    is_calculated = False
                    if isinstance(calculation, dict):
                        calc_attrs = calculation.get("@attributes", {})
                        formula = calc_attrs.get("formula", "")
                        calc_class = calc_attrs.get("class", "")
                        if formula and col_name:
                            metadata["measures"].append({"name": col_name, "formula": formula, "datasource": ds_caption})
                            is_calculated = True
                        elif calc_class and calc_class != "tableau" and col_name:
                            metadata["measures"].append({"name": col_name, "formula": f"({calc_class})", "datasource": ds_caption})
                            is_calculated = True

                    if col_name and not is_calculated:
                        fields.append(col_name)

                metadata["data_sources"].append(
                    {
                        "name": ds_caption if ds_caption != ds_name else ds_name,
                        "internal_name": ds_name,
                        "tables": tables,
                        "fields": fields[:50],
                    }
                )

            worksheet_items = _get_items(content, "worksheets", "worksheet")
            for ws in worksheet_items:
                if not isinstance(ws, dict):
                    continue
                ws_attrs = ws.get("@attributes", {})
                ws_name = ws_attrs.get("name", "Unknown")

                ws_info = {"name": ws_name}

                table_pane = ws.get("table", {})
                if isinstance(table_pane, dict):
                    view = table_pane.get("view", {})
                    if isinstance(view, dict):
                        datasources_used = view.get("datasources", {})
                        if isinstance(datasources_used, dict):
                            ds_ref = datasources_used.get("datasource", [])
                            if isinstance(ds_ref, dict):
                                ds_ref = [ds_ref]
                            ws_info["datasources_used"] = [
                                d.get("@attributes", {}).get("caption", d.get("@attributes", {}).get("name", ""))
                                for d in ds_ref
                                if isinstance(d, dict)
                            ]

                    panes = table_pane.get("pane", [])
                    if isinstance(panes, dict):
                        panes = [panes]
                    mark_types = set()
                    for pane in panes:
                        if isinstance(pane, dict):
                            mark = pane.get("mark", {})
                            if isinstance(mark, dict):
                                mark_class = mark.get("@attributes", {}).get("class", "")
                                if mark_class:
                                    mark_types.add(mark_class)
                            elif isinstance(mark, list):
                                for mark_item in mark:
                                    if isinstance(mark_item, dict):
                                        mark_class = mark_item.get("@attributes", {}).get("class", "")
                                        if mark_class:
                                            mark_types.add(mark_class)
                    if mark_types:
                        ws_info["mark_types"] = list(mark_types)

                metadata["worksheets"].append(ws_info)

            dashboard_items = _get_items(content, "dashboards", "dashboard")
            for db in dashboard_items:
                if not isinstance(db, dict):
                    continue
                db_attrs = db.get("@attributes", {})
                db_name = db_attrs.get("name", "Unknown")

                db_info = {"name": db_name}
                zones = db.get("zones", {})
                if isinstance(zones, dict):
                    zone_items = zones.get("zone", [])
                    if isinstance(zone_items, dict):
                        zone_items = [zone_items]

                    referenced_sheets = []

                    def _extract_zone_refs(zone_list):
                        for zone in zone_list:
                            if not isinstance(zone, dict):
                                continue
                            zone_attrs = zone.get("@attributes", {})
                            zone_name = zone_attrs.get("name", "")
                            zone_type = zone_attrs.get("type", "")
                            if zone_name and zone_type != "layout-basic":
                                referenced_sheets.append(zone_name)
                            nested_zones = zone.get("zone", [])
                            if isinstance(nested_zones, dict):
                                nested_zones = [nested_zones]
                            if isinstance(nested_zones, list):
                                _extract_zone_refs(nested_zones)

                    _extract_zone_refs(zone_items)
                    if referenced_sheets:
                        db_info["referenced_worksheets"] = referenced_sheets

                metadata["dashboards"].append(db_info)

        except Exception as exc:
            logger.warning(f"Error extracting Tableau metadata: {exc}")

        return metadata
