import logging
from typing import Any, Dict, Optional

import pandas as pd

from .base_converter import BaseFileConverter
from .common_dataframe_utils import clean_dataframe
from .common_text_utils import convert_text_file

logger = logging.getLogger(__name__)


class CsvConverter(BaseFileConverter):
    def __init__(
        self,
        logger_: Optional[logging.Logger] = None,
    ):
        self._logger = logger_ or logger

    def convert(self, file_path: str) -> Dict[str, Any]:
        try:
            df = pd.read_csv(file_path)
            df, cleaning_summary = clean_dataframe(df, logger_=self._logger)

            rows = df.to_dict("records")
            columns = df.columns.tolist()

            response: Dict[str, Any] = {
                "type": "tabular_data",
                "rows": rows,
                "columns": columns,
                "shape": list(df.shape),
                "summary": {
                    "total_rows": len(df),
                    "total_columns": len(columns),
                    "column_info": {col: str(df[col].dtype) for col in columns},
                },
            }

            response["cleaning_summary"] = cleaning_summary

            return response
        except Exception as e:
            self._logger.error(f"Error reading CSV file {file_path}: {str(e)}")
            return convert_text_file(file_path, logger_=self._logger)
