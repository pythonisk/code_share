import logging
import re
from typing import Any, Dict, List, Optional

from .base_converter import BaseFileConverter
from .common_text_utils import extract_text_sections


try:
    import pdfplumber

    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

try:
    import PyPDF2
except ImportError:
    PyPDF2 = None


class PdfConverter(BaseFileConverter):
    def __init__(self, logger_: Optional[logging.Logger] = None):
        self._logger = logger_ or logging.getLogger(__name__)

    def convert(self, file_path: str) -> Dict[str, Any]:
        if not PDF_AVAILABLE:
            return {"error": "PDF processing libraries not available. Please install: pip install PyPDF2 pdfplumber"}

        try:
            pdf_content = self._extract_pdf_with_pdfplumber(file_path)

            if not pdf_content["pages"]:
                pdf_content = self._extract_pdf_with_pypdf2(file_path)

            full_text = "\n".join([page["text"] for page in pdf_content["pages"] if page["text"]])
            lines = full_text.splitlines()
            structured_content = self._extract_pdf_structure(full_text, lines, pdf_content["pages"])

            return {
                "type": "pdf_file",
                "content": full_text,
                "structured_sections": structured_content,
                "pages": pdf_content["pages"],
                "summary": {
                    "total_pages": len(pdf_content["pages"]),
                    "total_sections": len(structured_content),
                    "total_characters": len(full_text),
                    "encoding": "utf-8",
                },
            }
        except Exception as exc:
            self._logger.error(f"Error reading PDF file {file_path}: {str(exc)}")
            return {"error": f"Failed to read PDF file: {str(exc)}"}

    def _extract_pdf_with_pdfplumber(self, file_path: str) -> Dict[str, Any]:
        pages_data = []

        try:
            with pdfplumber.open(file_path) as pdf:
                for page_num, page in enumerate(pdf.pages, 1):
                    text = page.extract_text() or ""

                    tables = []
                    try:
                        page_tables = page.extract_tables()
                        for table_idx, table in enumerate(page_tables or []):
                            if table:
                                tables.append(
                                    {
                                        "table_number": table_idx + 1,
                                        "data": table,
                                        "rows": len(table),
                                        "columns": len(table[0]) if table else 0,
                                    }
                                )
                    except Exception as exc:
                        self._logger.warning(f"Could not extract tables from page {page_num}: {exc}")

                    pages_data.append(
                        {
                            "page_number": page_num,
                            "text": text,
                            "tables": tables,
                            "char_count": len(text),
                        }
                    )
        except Exception as exc:
            self._logger.error(f"pdfplumber extraction failed: {exc}")

        return {"pages": pages_data}

    def _extract_pdf_with_pypdf2(self, file_path: str) -> Dict[str, Any]:
        if PyPDF2 is None:
            return {"pages": []}

        pages_data = []

        try:
            with open(file_path, "rb") as file:
                pdf_reader = PyPDF2.PdfReader(file)

                for page_num, page in enumerate(pdf_reader.pages, 1):
                    try:
                        text = page.extract_text() or ""
                        pages_data.append(
                            {
                                "page_number": page_num,
                                "text": text,
                                "tables": [],
                                "char_count": len(text),
                            }
                        )
                    except Exception as exc:
                        self._logger.warning(f"Could not extract text from page {page_num}: {exc}")
                        pages_data.append(
                            {
                                "page_number": page_num,
                                "text": "",
                                "tables": [],
                                "char_count": 0,
                            }
                        )
        except Exception as exc:
            self._logger.error(f"PyPDF2 extraction failed: {exc}")

        return {"pages": pages_data}

    def _extract_pdf_structure(self, full_text: str, lines: List[str], pages: List[Dict]) -> Dict[str, Any]:
        sections = {}
        current_header = None
        current_content = []
        section_counter = 1

        header_patterns = [
            (r"^(Chapter|Section|Part)\s+(\d+)[\.\:]?\s*(.*)$", "chapter_header"),
            (r"^(\d+\.?\d*\.?\d*)\s+([A-Z][A-Za-z\s]+)$", "numbered_header"),
            (r"^([A-Z][A-Z\s]{3,})$", "caps_header"),
            (r"^([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,5})$", "title_case_header"),
            (r"^([A-Z][A-Za-z\s:]+)(?:\s*\.\.\.|---|===)$", "formatted_header"),
            (r"^([A-Z][A-Za-z\s]{2,50})$", "potential_header"),
        ]

        index = 0
        while index < len(lines):
            line = lines[index].strip()

            if not line:
                if current_content and current_content[-1] != "":
                    current_content.append("")
                index += 1
                continue

            is_header = False
            header_text = None
            header_type = None

            for pattern, pattern_type in header_patterns:
                match = re.match(pattern, line)
                if match:
                    if pattern_type == "chapter_header":
                        header_text = f"{match.group(1)} {match.group(2)}: {match.group(3)}"
                    elif pattern_type == "numbered_header":
                        header_text = f"{match.group(1)} {match.group(2)}"
                    elif pattern_type == "potential_header":
                        if self._is_likely_pdf_header(line, lines, index):
                            header_text = match.group(1)
                        else:
                            continue
                    else:
                        header_text = match.group(1)

                    header_type = pattern_type
                    is_header = True
                    break

            if is_header and header_text:
                if current_header and current_content:
                    content_text = "\n".join(current_content).strip()
                    if content_text:
                        sections[current_header]["content"] = content_text
                        sections[current_header]["type"] = "section_content"

                current_header = header_text
                current_content = []
                sections[current_header] = {
                    "content": "",
                    "type": "section_header",
                    "header_type": header_type,
                    "section_number": section_counter,
                    "page_context": self._find_page_context(line, pages),
                }
                section_counter += 1
            else:
                if current_header:
                    current_content.append(line)
                else:
                    default_key = "Document_Preamble"
                    if default_key not in sections:
                        sections[default_key] = {
                            "content": line,
                            "type": "section_content",
                            "header_type": "document_start",
                        }
                    else:
                        sections[default_key]["content"] += f"\n{line}"

            index += 1

        if current_header and current_content:
            content_text = "\n".join(current_content).strip()
            if content_text:
                sections[current_header]["content"] = content_text
                sections[current_header]["type"] = "section_content"

        if not sections or len(sections) == 1:
            text_sections = extract_text_sections(full_text, lines)
            sections.update(text_sections)

        return sections

    def _is_likely_pdf_header(self, line: str, lines: List[str], index: int) -> bool:
        if len(line) > 100:
            return False

        if index + 1 < len(lines):
            next_line = lines[index + 1].strip()
            if next_line and len(next_line) > 50:
                return True

        if index + 2 < len(lines):
            context_lines = [lines[i].strip() for i in range(index + 1, min(index + 4, len(lines)))]
            content_lines = [line_item for line_item in context_lines if len(line_item) > 20]
            if len(content_lines) >= 2:
                return True

        return False

    def _find_page_context(self, text: str, pages: List[Dict]) -> Dict[str, Any]:
        for page in pages:
            if text in page.get("text", ""):
                return {"page_number": page["page_number"], "found_in_page": True}
        return {"page_number": None, "found_in_page": False}
