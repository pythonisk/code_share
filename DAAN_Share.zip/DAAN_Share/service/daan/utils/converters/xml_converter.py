import logging
import xml.etree.ElementTree as ET
from typing import Any, Dict, Optional

from .base_converter import BaseFileConverter
from .common_text_utils import convert_text_file


class XmlConverter(BaseFileConverter):
    def __init__(self, logger_: Optional[logging.Logger] = None):
        self._logger = logger_ or logging.getLogger(__name__)

    def convert(self, file_path: str) -> Dict[str, Any]:
        try:
            tree = ET.parse(file_path)
            root = tree.getroot()

            def element_to_dict(element):
                result = {}
                if element.attrib:
                    result["@attributes"] = element.attrib
                if element.text and element.text.strip():
                    if len(element) == 0:
                        return element.text.strip()
                    result["#text"] = element.text.strip()

                for child in element:
                    child_data = element_to_dict(child)
                    if child.tag in result:
                        if not isinstance(result[child.tag], list):
                            result[child.tag] = [result[child.tag]]
                        result[child.tag].append(child_data)
                    else:
                        result[child.tag] = child_data

                return result

            return {
                "type": "xml_file",
                "content": element_to_dict(root),
                "root_tag": root.tag,
                "summary": {
                    "root_element": root.tag,
                    "has_attributes": bool(root.attrib),
                    "child_count": len(root),
                },
            }
        except Exception as exc:
            self._logger.error(f"Error parsing XML file {file_path}: {str(exc)}")
            return convert_text_file(file_path, logger_=self._logger)
