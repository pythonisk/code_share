import logging
from typing import Any, Dict,List
import os
import zipfile
from .base_converter import BaseFileConverter
from datetime import datetime
from .common_powerbi_utils import (
    validate_powerbi_schema,
    read_zip_json,
    safe_json_loads,
)
logger = logging.getLogger(__name__)


class PbitConverter(BaseFileConverter):
 
    def _parse_pbit_layout(self, pbit_path: str) -> Dict[str, Any]:
        """
        Parse a PBIT file and extract the report layout in schema-validated format.

        Contract:
        {
          "source": { "fileType":"PBIT","path":..., "extractionMethod":..., "generatedAt":... },
          "reportFilters": [ { "field"?, "operator"?, "values": [] } ],
          "pages": [
            {
              "name": str,
              "displayOrder"?: int,
              "visuals": [
                {
                  "id": str,
                  "type": str,
                  "queryIntent": { "dimensions", "measures", "filters", "sort", "limit" }
                }
              ]
            }
          ]
        }
        """
        try:
            result = self._extract_pbit_layout_json(pbit_path)
            validate_powerbi_schema(result, "pbit_layout", logger_=logger)
            return result
        except Exception as e:
            logger.error(f"Error parsing PBIT layout: {str(e)}")
            return {
                "source": {
                    "fileType": "PBIT",
                    "path": pbit_path,
                    "extractionMethod": "error",
                    "generatedAt": datetime.now().isoformat()
                },
                "reportFilters": [],
                "pages": [],
                "error": str(e)
            }
    
    def _extract_pbit_layout_json(self, pbit_path: str) -> Dict[str, Any]:
        if not os.path.exists(pbit_path):
            raise FileNotFoundError(f"File not found: {pbit_path}")
        if not zipfile.is_zipfile(pbit_path):
            raise ValueError("File is not a valid ZIP/PBIT archive")

        report_filters: List[Dict[str, Any]] = []
        pages: List[Dict[str, Any]] = []

        with zipfile.ZipFile(pbit_path, "r") as zf:
            # Layout
            layout = read_zip_json(zf, "Report/Layout")
            if layout:
                for page_idx, section in enumerate(layout.get("sections", [])):
                    page_name = section.get("displayName", f"Page {page_idx + 1}")
                    display_order = section.get("displayOrder", page_idx)

                    visuals: List[Dict[str, Any]] = []
                    for vis_idx, visual in enumerate(section.get("visualContainers", [])):
                        config = visual.get("config", {})
                        if isinstance(config, str):
                            config = safe_json_loads(config) or {}

                        single_visual = config.get("singleVisual", {}) if isinstance(config, dict) else {}
                        viz_type = single_visual.get("visualType", "unknown")

                        # stable visual id
                        vid = config.get("name") if isinstance(config, dict) and config.get("name") else None
                        if not vid:
                            x = visual.get("x", vis_idx)
                            y = visual.get("y", vis_idx)
                            vid = f"Visual_{x}_{y}" if x is not None and y is not None else f"Visual_{vis_idx}"

                        query_intent = self._extract_normalized_query_intent_from_layout_visual(visual)

                        visuals.append({
                            "id": str(vid),
                            "type": str(viz_type),
                            "queryIntent": query_intent
                        })

                    visuals.sort(key=lambda v: v["id"])
                    pages.append({
                        "name": str(page_name),
                        "displayOrder": int(display_order) if display_order is not None else None,
                        "visuals": visuals
                    })

            # Filters (optional, best-effort)
            # Many PBITs store filters in various places; we keep this conservative.
            # If you have a known path in your org, add it here.
            # For now, we keep reportFilters empty unless you extend.

        # Deterministic page sorting
        pages.sort(key=lambda p: ((p.get("displayOrder") if p.get("displayOrder") is not None else 9999), p["name"]))

        # Remove None displayOrder to keep output clean
        for p in pages:
            if p.get("displayOrder") is None:
                p.pop("displayOrder", None)

        return {
            "source": {
                "fileType": "PBIT",
                "path": pbit_path,
                "extractionMethod": "report_layout",
                "generatedAt": datetime.now().isoformat()
            },
            "reportFilters": report_filters,
            "pages": pages
        }

    def _extract_normalized_query_intent_from_layout_visual(self, visual: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract normalized query intent for PBIT/PBIX Layout visualContainers
        using dataTransforms (best-effort).
        """
        qi: Dict[str, Any] = {"dimensions": [], "measures": [], "filters": [], "sort": [], "limit": None}
        try:
            data_transforms = visual.get("dataTransforms", "")
            if isinstance(data_transforms, str):
                data_transforms = safe_json_loads(data_transforms) or {}
            if not isinstance(data_transforms, dict):
                return qi

            selects = data_transforms.get("selects", []) or []
            for sel in selects:
                display_name = sel.get("displayName", "")
                roles = sel.get("roles", {}) or {}

                if roles.get("Y") or roles.get("Measure") or roles.get("Value"):
                    if display_name:
                        qi["measures"].append({"name": display_name})
                elif roles.get("Category") or roles.get("Axis") or roles.get("X"):
                    if display_name:
                        qi["dimensions"].append({"table": None, "field": display_name})

                if sel.get("sort") and display_name:
                    qi["sort"].append({"field": display_name, "direction": "asc"})

        except Exception as e:
            logger.debug(f"Could not extract query intent: {e}")

        # deterministic
        qi["dimensions"].sort(key=lambda x: (str(x.get("table") or ""), str(x.get("field") or "")))
        qi["measures"].sort(key=lambda x: str(x.get("name") or ""))
        qi["sort"].sort(key=lambda x: (str(x.get("field") or ""), str(x.get("direction") or "")))
        return qi

    def convert(self, file_path: str) -> Dict[str, Any]:
        try:
            result = self._parse_pbit_layout(file_path)
            return {"type": "pbit_file", "layout": result}
        except Exception as exc:
            logger.error(f"Error converting pbit_file file {file_path}: {exc}")
            return {
                "type": "pbit_file",
                "error": f"Failed to convert pbit_file file: {str(exc)}",
            }
