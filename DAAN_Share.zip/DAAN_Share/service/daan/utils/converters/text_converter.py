import logging
import re
from typing import Any, Dict, List, Optional

from .base_converter import BaseFileConverter
from .common_text_utils import convert_text_file


class TextConverter(BaseFileConverter):
    def __init__(self, logger_: Optional[logging.Logger] = None):
        self._logger = logger_ or logging.getLogger(__name__)

    def convert(self, file_path: str) -> Dict[str, Any]:
        # Detect SQL files and use SQL converter instead of text converter
        file_ext = file_path.lower().split('.')[-1]
        
        if file_ext == 'sql':
            return self._convert_sql(file_path)
        
        # For .txt files, check if content is SQL
        if file_ext == 'txt':
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    first_lines = f.read(500)  # Read first 500 chars
                
                if re.search(r'^\s*(SELECT|INSERT|UPDATE|DELETE|CREATE|DROP|ALTER|WITH|DECLARE)\s+', 
                            first_lines, re.IGNORECASE | re.MULTILINE):
                    return self._convert_sql(file_path)
            except:
                pass
        
        # For other files, use standard text conversion
        return convert_text_file(file_path, logger_=self._logger)

    def _convert_sql(self, file_path: str) -> Dict[str, Any]:
        """
        Convert SQL file to structured format preserving UNION queries as single statements.
        
        Args:
            file_path: Path to the SQL file
            
        Returns:
            Dictionary with structure containing SQL statement blocks
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Parse SQL preserving UNION queries
            structure = self._parse_sql_statements(content)
            
            return {
                "type": "sql_file",
                "content": content,
                "structure": structure,
                "language": "sql",
                "summary": {
                    "total_lines": len(content.splitlines()),
                    "total_characters": len(content),
                    "statements_found": len(structure)
                }
            }
        except Exception as e:
            self._logger.error(f"Error converting SQL file {file_path}: {str(e)}")
            return {"error": f"Failed to convert SQL file: {str(e)}"}

    def _parse_sql_statements(self, content: str) -> List[Dict[str, Any]]:
        """
        Parse SQL file universally for ANY SQL query type.
        Preserves complete queries: UNION, multi-line, complex joins, etc.
        Key: Keeps entire SQL query as single unit, splits only on statement terminators (;/GO).
        
        Args:
            content: SQL file content
            
        Returns:
            List of complete statement blocks with metadata
        """
        statements = []
        
        # Remove leading/trailing whitespace
        content = content.strip()
        if not content:
            return statements
        
        # Split by statement terminators (semicolon or GO on own line)
        # This preserves multi-line queries and UNION statements together
        statement_blocks = re.split(r';\s*\n|;\s*$|^\s*GO\s*$', content, flags=re.MULTILINE | re.IGNORECASE)
        
        line_num = 1
        for block in statement_blocks:
            block = block.strip()
            
            # Skip empty blocks or comment-only blocks
            if not block:
                line_num += block.count('\n') + 1
                continue
            
            # Remove SQL comments (-- and /* */)
            block_cleaned = re.sub(r'--.*$', '', block, flags=re.MULTILINE)
            block_cleaned = re.sub(r'/\*.*?\*/', '', block_cleaned, flags=re.DOTALL)
            block_cleaned = block_cleaned.strip()
            
            if not block_cleaned:
                line_num += block.count('\n') + 1
                continue
            
            # Determine statement type from first keyword
            stmt_type = self._get_sql_statement_type(block_cleaned)
            
            # For naming: use keyword + brief description
            # For UNION queries: clearly mark as such
            if 'UNION' in block_cleaned.upper():
                stmt_name = "QUERY_WITH_UNION"
            else:
                stmt_name = f"{stmt_type}_QUERY"
            
            statements.append({
                "type": stmt_type,
                "name": stmt_name,
                "content": block_cleaned,  # Full query content, no truncation
                "lineno": line_num,
                "is_complete": True
            })
            
            line_num += block.count('\n') + 1
        
        return statements

    def _get_sql_statement_type(self, statement: str) -> str:
        """Determine SQL statement type (SELECT, INSERT, UPDATE, DELETE, etc.) from first keyword."""
        match = re.match(r'^\s*(SELECT|INSERT|UPDATE|DELETE|CREATE|DROP|ALTER|WITH|DECLARE)\s+', 
                         statement, re.IGNORECASE | re.MULTILINE)
        if match:
            return match.group(1).upper()
        return "SQL"
