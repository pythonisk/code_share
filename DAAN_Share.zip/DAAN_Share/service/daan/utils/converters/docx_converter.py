import io
import logging
import re
import zipfile
from typing import Any, Dict, List, Optional

import pandas as pd

from .base_converter import BaseFileConverter


logger = logging.getLogger(__name__)

try:
    from docx import Document

    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False

try:
    import pdfplumber

    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False


class DocxConverter(BaseFileConverter):
    def __init__(self, logger_: Optional[logging.Logger] = None):
        self._logger = logger_ or logging.getLogger(__name__)
    def convert(self, file_path: str) -> Dict[str, Any]:
        if not DOCX_AVAILABLE:
            return {"error": "python-docx library not available. Please install: pip install python-docx"}

        try:
            doc = Document(file_path)

            structured_content = self._extract_docx_structure(doc)
            full_text = "\n".join([paragraph.text for paragraph in doc.paragraphs if paragraph.text.strip()])
            tables_data = self._extract_docx_tables(doc)
            embedded_files_data = self._extract_docx_embedded_files(file_path)

            combined_content = full_text
            if embedded_files_data.get("embedded_content"):
                combined_content += "\n\n=== EMBEDDED FILES ===\n" + embedded_files_data.get("embedded_content", "")

            return {
                "type": "docx_file",
                "content": combined_content,
                "main_document_content": full_text,
                "structured_sections": structured_content,
                "tables": tables_data,
                "embedded_files": embedded_files_data.get("files", []),
                "summary": {
                    "total_paragraphs": len(doc.paragraphs),
                    "total_sections": len(structured_content),
                    "total_tables": len(tables_data),
                    "total_embedded_files": embedded_files_data.get("count", 0),
                    "embedded_file_types": embedded_files_data.get("file_types", []),
                    "document_has_headers": any(
                        section["header_type"] != "paragraph" for section in structured_content.values()
                    ),
                    "encoding": "utf-8",
                },
            }
        except Exception as exc:
            logger.error(f"Error reading DOCX file {file_path}: {str(exc)}")
            return {"error": f"Failed to read DOCX file: {str(exc)}"}

    def _extract_docx_embedded_files(self, file_path: str) -> Dict[str, Any]:
        embedded_files = []
        embedded_content_parts = []
        file_types_found = set()

        try:
            with zipfile.ZipFile(file_path, "r") as docx_zip:
                embed_locations = ["word/embeddings/", "word/media/"]

                for file_info in docx_zip.filelist:
                    is_embedded = any(file_info.filename.startswith(location) for location in embed_locations)

                    if is_embedded and not file_info.is_dir():
                        embedded_filename = file_info.filename
                        base_name = embedded_filename.split("/")[-1]
                        file_ext = ("." + base_name.split(".")[-1].lower()) if "." in base_name else ""
                        file_types_found.add(file_ext if file_ext else "unknown")

                        try:
                            with docx_zip.open(embedded_filename) as embedded_file:
                                embedded_data = embedded_file.read()

                                extracted_info = {
                                    "filename": base_name,
                                    "path_in_archive": embedded_filename,
                                    "extension": file_ext,
                                    "size_bytes": len(embedded_data),
                                    "content": None,
                                    "extraction_status": "success",
                                }

                                if file_ext == ".xlsx":
                                    extracted_text = self._extract_embedded_excel(embedded_data, base_name)
                                elif file_ext == ".docx":
                                    extracted_text = self._extract_embedded_docx(embedded_data, base_name)
                                elif file_ext == ".msg":
                                    extracted_text = self._extract_embedded_msg(embedded_data, base_name)
                                elif file_ext == ".pdf":
                                    extracted_text = self._extract_embedded_pdf(embedded_data, base_name)
                                elif file_ext in [".txt", ".csv", ".xml", ".json", ".sql", ".py", ".md"]:
                                    extracted_text = self._extract_embedded_text(embedded_data, base_name, file_ext)
                                elif file_ext in [".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".emf", ".wmf"]:
                                    extracted_text = f"\n--- Embedded Image: {base_name} ---\n[Image file - {len(embedded_data)} bytes]"
                                    extracted_info["extraction_status"] = "image_noted"
                                else:
                                    extracted_text = (
                                        f"\n--- Embedded File: {base_name} ---\n"
                                        f"[Binary/unsupported file type: {file_ext} - {len(embedded_data)} bytes]"
                                    )
                                    extracted_info["extraction_status"] = "unsupported_type"

                                extracted_info["content"] = extracted_text
                                embedded_files.append(extracted_info)

                                if extracted_text:
                                    embedded_content_parts.append(extracted_text)

                        except Exception as exc:
                            error_msg = f"\n--- Embedded File: {base_name} ---\n[Error extracting: {str(exc)}]"
                            embedded_files.append(
                                {
                                    "filename": base_name,
                                    "path_in_archive": embedded_filename,
                                    "extension": file_ext,
                                    "content": error_msg,
                                    "extraction_status": "error",
                                    "error": str(exc),
                                }
                            )
                            embedded_content_parts.append(error_msg)
                            logger.warning(f"Error extracting embedded file {embedded_filename}: {exc}")

        except zipfile.BadZipFile:
            logger.warning(f"File {file_path} is not a valid ZIP/DOCX archive")
            return {"files": [], "embedded_content": "", "count": 0, "file_types": []}
        except Exception as exc:
            logger.error(f"Error processing DOCX archive {file_path}: {exc}")
            return {"files": [], "embedded_content": "", "count": 0, "file_types": [], "error": str(exc)}

        return {
            "files": embedded_files,
            "embedded_content": "\n".join(embedded_content_parts),
            "count": len(embedded_files),
            "file_types": list(file_types_found),
        }

    def _extract_embedded_excel(self, data: bytes, filename: str) -> str:
        try:
            df_dict = pd.read_excel(io.BytesIO(data), sheet_name=None, engine="openpyxl")
            content_parts = [f"\n--- Embedded Excel File: {filename} ---"]

            for sheet_name, df in df_dict.items():
                content_parts.append(f"\n### Sheet: {sheet_name}")

                if df.empty:
                    content_parts.append("(Empty sheet)")
                    continue

                df = df.dropna(how="all").dropna(axis=1, how="all")

                if df.empty:
                    content_parts.append("(Sheet contains only empty cells)")
                    continue

                columns = df.columns.tolist()
                header = "| " + " | ".join(str(col) for col in columns) + " |"
                separator = "|" + "|".join("---" for _ in columns) + "|"
                rows = []
                for _, row in df.iterrows():
                    row_str = "| " + " | ".join(
                        str(val) if pd.notna(val) and str(val).lower() != "nan" else "" for val in row
                    ) + " |"
                    rows.append(row_str)

                table_md = "\n".join([header, separator] + rows)
                content_parts.append(table_md)

            return "\n".join(content_parts)

        except ImportError as exc:
            return (
                f"\n--- Embedded Excel File: {filename} ---\n"
                f"[Excel content not extractable - required packages not available: {exc}]"
            )
        except Exception as exc:
            return f"\n--- Embedded Excel File: {filename} ---\n[Error extracting Excel content: {exc}]"

    def _extract_embedded_docx(self, data: bytes, filename: str) -> str:
        try:
            doc = Document(io.BytesIO(data))
            text_content = []

            for paragraph in doc.paragraphs:
                if paragraph.text.strip():
                    text_content.append(paragraph.text)

            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        if cell.text.strip():
                            text_content.append(cell.text)

            content = "\n".join(text_content)
            if content:
                return f"\n--- Embedded Word Document: {filename} ---\n{content}"
            return f"\n--- Embedded Word Document: {filename} ---\n(No text content found)"

        except Exception as exc:
            return f"\n--- Embedded Word Document: {filename} ---\n[Error extracting content: {exc}]"

    def _extract_embedded_msg(self, data: bytes, filename: str) -> str:
        try:
            try:
                import extract_msg

                msg = extract_msg.Message(io.BytesIO(data))
                content_parts = [
                    f"\n--- Embedded Email: {filename} ---",
                    f"Subject: {msg.subject or '(No subject)'}",
                    f"From: {msg.sender or '(Unknown sender)'}",
                    f"To: {msg.to or '(No recipients)'}",
                    f"Date: {msg.date or '(No date)'}",
                    f"\nBody:\n{msg.body or '(No body content)'}",
                ]
                return "\n".join(content_parts)
            except ImportError:
                text_content = []
                try:
                    decoded = data.decode("utf-16-le", errors="ignore")
                    printable_chars = "".join(
                        character if character.isprintable() or character in "\n\r\t" else " "
                        for character in decoded
                    )
                    cleaned = " ".join(printable_chars.split())
                    if len(cleaned) > 50:
                        text_content.append(cleaned[:5000])
                except Exception:
                    pass

                if text_content:
                    return (
                        f"\n--- Embedded Email: {filename} ---\n"
                        "[Partial extraction - install 'extract-msg' for full support]\n"
                        f"{''.join(text_content)}"
                    )
                return (
                    f"\n--- Embedded Email: {filename} ---\n"
                    "[MSG file detected - install 'extract-msg' package for content extraction]"
                )
        except Exception as exc:
            return f"\n--- Embedded Email: {filename} ---\n[Error extracting email content: {exc}]"

    def _extract_embedded_pdf(self, data: bytes, filename: str) -> str:
        try:
            if not PDF_AVAILABLE:
                return f"\n--- Embedded PDF: {filename} ---\n[PDF extraction not available - install pdfplumber]"

            pdf_content = []

            with pdfplumber.open(io.BytesIO(data)) as pdf:
                for page_num, page in enumerate(pdf.pages, 1):
                    text = page.extract_text()
                    if text:
                        pdf_content.append(f"[Page {page_num}]\n{text}")

            if pdf_content:
                return f"\n--- Embedded PDF: {filename} ---\n" + "\n\n".join(pdf_content)
            return f"\n--- Embedded PDF: {filename} ---\n[No extractable text found]"

        except Exception as exc:
            return f"\n--- Embedded PDF: {filename} ---\n[Error extracting PDF content: {exc}]"

    def _extract_embedded_text(self, data: bytes, filename: str, file_ext: str) -> str:
        try:
            for encoding in ["utf-8", "utf-16", "latin-1", "cp1252"]:
                try:
                    text_content = data.decode(encoding)
                    return f"\n--- Embedded {file_ext.upper()} File: {filename} ---\n{text_content}"
                except UnicodeDecodeError:
                    continue

            return f"\n--- Embedded File: {filename} ---\n[Could not decode text content]"

        except Exception as exc:
            return f"\n--- Embedded File: {filename} ---\n[Error reading file: {exc}]"

    def _extract_docx_structure(self, doc) -> Dict[str, Any]:
        sections = {}
        current_header = None
        current_content = []
        section_counter = 1

        for paragraph in doc.paragraphs:
            text = paragraph.text.strip()
            if not text:
                if current_content:
                    current_content.append("")
                continue

            is_header = self._is_docx_header(paragraph)
            header_level = self._get_docx_header_level(paragraph)

            if is_header:
                if current_header and current_content:
                    content_text = "\n".join(current_content).strip()
                    if content_text:
                        sections[current_header]["content"] = content_text
                        sections[current_header]["type"] = "section_content"

                current_header = text if text else f"Section {section_counter}"
                current_content = []
                sections[current_header] = {
                    "content": "",
                    "type": "section_header",
                    "header_type": f"heading_level_{header_level}" if header_level else "formatted_header",
                    "style_name": paragraph.style.name,
                    "font_size": self._get_font_size(paragraph),
                    "is_bold": self._is_bold(paragraph),
                    "section_number": section_counter,
                }
                section_counter += 1
            else:
                if current_header:
                    current_content.append(text)
                else:
                    default_key = "Document_Introduction"
                    if default_key not in sections:
                        sections[default_key] = {
                            "content": text,
                            "type": "section_content",
                            "header_type": "document_start",
                            "style_name": paragraph.style.name,
                        }
                    else:
                        sections[default_key]["content"] += f"\n{text}"

        if current_header and current_content:
            content_text = "\n".join(current_content).strip()
            if content_text:
                sections[current_header]["content"] = content_text
                sections[current_header]["type"] = "section_content"

        return sections

    def _is_docx_header(self, paragraph) -> bool:
        style_name = paragraph.style.name.lower()

        if "heading" in style_name or "title" in style_name:
            return True

        if self._is_bold(paragraph) and len(paragraph.text.strip()) < 100:
            font_size = self._get_font_size(paragraph)
            if font_size and font_size > 12:
                return True

        return False

    def _get_docx_header_level(self, paragraph) -> int:
        style_name = paragraph.style.name.lower()

        if "heading" in style_name:
            match = re.search(r"heading\s*(\d+)", style_name)
            if match:
                return int(match.group(1))

        if "title" in style_name:
            return 1

        return 0

    def _get_font_size(self, paragraph) -> Optional[int]:
        try:
            if paragraph.runs:
                for run in paragraph.runs:
                    if run.font.size:
                        return int(run.font.size.pt)
        except Exception:
            pass
        return None

    def _is_bold(self, paragraph) -> bool:
        try:
            if paragraph.runs:
                return any(run.bold for run in paragraph.runs if run.bold is not None)
        except Exception:
            pass
        return False

    def _extract_docx_tables(self, doc) -> List[Dict[str, Any]]:
        tables_data = []

        for table_idx, table in enumerate(doc.tables):
            table_content = []
            headers = []

            for row_idx, row in enumerate(table.rows):
                row_data = []
                for cell in row.cells:
                    cell_text = cell.text.strip()
                    row_data.append(cell_text)

                if row_idx == 0:
                    headers = row_data
                else:
                    table_content.append(row_data)

            if table_content:
                tables_data.append(
                    {
                        "table_number": table_idx + 1,
                        "headers": headers,
                        "data": table_content,
                        "rows": len(table_content),
                        "columns": len(headers) if headers else 0,
                    }
                )

        return tables_data
