import json
import logging
import os
from typing import Any, Callable, Dict, Optional

import pandas as pd


class DirectoryConverter:
    """Handles directory-level conversion workflows using a file conversion callback."""

    def __init__(
        self,
        convert_file_to_json: Callable[[str], Dict[str, Any]],
        supported_formats: Dict[str, Callable[[], Any]],
        json_serializer: Callable[[Any], Any],
        logger_: Optional[logging.Logger] = None,
    ):
        self._convert_file_to_json = convert_file_to_json
        self._supported_formats = supported_formats
        self._json_serializer = json_serializer
        self._logger = logger_ or logging.getLogger(__name__)

    def _save_json_output(self, output_file: str, payload: Dict[str, Any], context: str) -> None:
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(payload, f, indent=2, ensure_ascii=False, default=self._json_serializer)
            self._logger.info(f"{context} data saved to {output_file}")
        except Exception as e:
            self._logger.error(f"Error saving {context.lower()} JSON file: {e}")
            try:
                with open(output_file, 'w', encoding='utf-8') as f:
                    json.dump(payload, f, indent=2, ensure_ascii=False, default=str)
                self._logger.info(f"{context} data saved to {output_file} with fallback serialization")
            except Exception as e2:
                self._logger.error(f"Failed to save {context.lower()} conversion even with fallback: {e2}")

    def _add_content_summary_to_detail(self, processing_detail: Dict[str, Any], converted_data: Dict[str, Any]) -> None:
        summary = converted_data.get("content", {}).get("summary", {})
        detail_key_map = {
            "total_lines": "lines",
            "total_rows": "rows",
            "total_columns": "columns",
            "sections_found": "sections",
        }
        for summary_key, detail_key in detail_key_map.items():
            if summary_key in summary:
                processing_detail[detail_key] = summary[summary_key]

    def _build_status_file_lists(self, processing_details: Any) -> Dict[str, Any]:
        return {
            "successful_files": [
                detail["filename"] for detail in processing_details if detail["status"] == "success"
            ],
            "failed_files": [
                detail["filename"] for detail in processing_details if detail["status"] in ["failed", "error"]
            ],
            "skipped_files": [
                detail["filename"] for detail in processing_details if detail["status"] == "skipped"
            ],
        }

    def _merge_conversion_summary(
        self,
        combined_summary: Dict[str, Any],
        summary: Dict[str, Any],
        dir_path: str,
        relative_path: str,
    ) -> None:
        combined_summary["total_files"] += summary["total_files"]
        combined_summary["successful_conversions"] += summary["successful_conversions"]
        combined_summary["failed_conversions"] += summary["failed_conversions"]
        combined_summary["skipped_files"] += summary["skipped_files"]
        combined_summary["directories_processed"].append(dir_path)

        for file_type, count in summary.get("file_types_processed", {}).items():
            if file_type not in combined_summary["file_types_processed"]:
                combined_summary["file_types_processed"][file_type] = 0
            combined_summary["file_types_processed"][file_type] += count

        for detail in summary.get("processing_details", []):
            detail_copy = detail.copy()
            detail_copy["directory"] = dir_path
            detail_copy["relative_path"] = relative_path
            combined_summary["processing_details"].append(detail_copy)

    def convert_directory_to_json(
        self,
        directory_path: str,
        output_file: Optional[str] = None,
        recursive: bool = False,
    ) -> Dict[str, Any]:
        """
        Convert files in a directory to a JSON structure.
        Enhanced to handle multiple files of different types more effectively.

        Args:
            directory_path: Path to the directory containing files
            output_file: Optional path to save the JSON output
            recursive: Whether to include subdirectories recursively

        Returns:
            Dictionary containing converted files with metadata
        """
        if recursive:
            return self._convert_directory_recursive(directory_path, output_file)

        if not os.path.exists(directory_path):
            raise FileNotFoundError(f"Directory not found: {directory_path}")

        converted_files: Dict[str, Any] = {}
        conversion_summary = {
            "total_files": 0,
            "successful_conversions": 0,
            "failed_conversions": 0,
            "skipped_files": 0,
            "file_types_processed": {},
            "processing_details": [],
        }

        all_files = []
        for filename in os.listdir(directory_path):
            file_path = os.path.join(directory_path, filename)
            if os.path.isfile(file_path):
                all_files.append((filename, file_path))

        self._logger.info(f"Processing directory '{directory_path}' with {len(all_files)} files")

        for filename, file_path in all_files:
            conversion_summary["total_files"] += 1
            file_ext = os.path.splitext(filename)[1].lower()

            if file_ext not in conversion_summary["file_types_processed"]:
                conversion_summary["file_types_processed"][file_ext] = 0
            conversion_summary["file_types_processed"][file_ext] += 1

            processing_detail = {
                "filename": filename,
                "file_type": file_ext,
                "file_size": os.path.getsize(file_path),
                "status": "processing",
            }

            if filename.startswith('.') or filename.startswith('~'):
                conversion_summary["skipped_files"] += 1
                processing_detail["status"] = "skipped"
                processing_detail["reason"] = "Hidden or system file"
                conversion_summary["processing_details"].append(processing_detail)
                self._logger.info(f"Skipping hidden/system file: {filename}")
                continue

            if file_ext not in self._supported_formats and file_ext != '':
                self._logger.warning(
                    f"File type '{file_ext}' not directly supported, will attempt generic text conversion: {filename}"
                )

            try:
                self._logger.info(f"Converting file: {filename} (type: {file_ext})")
                converted_data = self._convert_file_to_json(file_path)
                converted_files[filename] = converted_data

                if "error" in converted_data.get("content", {}):
                    conversion_summary["failed_conversions"] += 1
                    processing_detail["status"] = "failed"
                    processing_detail["error"] = converted_data.get("content", {}).get("error", "Unknown error")
                    self._logger.error(f"Conversion failed for {filename}: {processing_detail['error']}")
                else:
                    conversion_summary["successful_conversions"] += 1
                    processing_detail["status"] = "success"
                    processing_detail["content_type"] = converted_data.get("content", {}).get("type", "unknown")
                    self._add_content_summary_to_detail(processing_detail, converted_data)

                    self._logger.info(
                        f"Successfully converted {filename} -> {processing_detail.get('content_type', 'unknown type')}"
                    )

            except Exception as e:
                self._logger.error(f"Failed to convert {filename}: {str(e)}")
                conversion_summary["failed_conversions"] += 1
                processing_detail["status"] = "error"
                processing_detail["error"] = str(e)
                converted_files[filename] = {
                    "filename": filename,
                    "file_type": file_ext,
                    "file_path": file_path,
                    "content": {"error": f"Conversion failed: {str(e)}"},
                    "metadata": {"conversion_error": True},
                }

            conversion_summary["processing_details"].append(processing_detail)

        status_file_lists = self._build_status_file_lists(conversion_summary["processing_details"])

        result = {
            "directory_path": directory_path,
            "conversion_summary": conversion_summary,
            "files": converted_files,
            "converted_at": pd.Timestamp.now().isoformat(),
            "total_files_found": len(all_files),
            **status_file_lists,
        }

        self._logger.info(
            f"Directory conversion completed: {conversion_summary['successful_conversions']} successful, "
            f"{conversion_summary['failed_conversions']} failed, {conversion_summary['skipped_files']} skipped"
        )

        if output_file:
            self._save_json_output(output_file, result, context="Converted")

        return result

    def _convert_directory_recursive(
        self,
        directory_path: str,
        output_file: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Convert all supported files in a directory recursively (optionally including subdirectories).

        Args:
            directory_path: Path to the directory containing files
            output_file: Optional path to save the JSON output
            include_subdirs: Whether to process subdirectories recursively

        Returns:
            Dictionary containing all converted files from directory and subdirectories
        """
        if not os.path.exists(directory_path):
            raise FileNotFoundError(f"Directory not found: {directory_path}")

        all_converted_files: Dict[str, Any] = {}
        combined_summary = {
            "total_files": 0,
            "successful_conversions": 0,
            "failed_conversions": 0,
            "skipped_files": 0,
            "directories_processed": [],
            "file_types_processed": {},
            "processing_details": [],
        }

        def process_directory(dir_path: str, relative_path: str = "") -> None:
            self._logger.info(f"Processing directory: {dir_path}")

            dir_result = self.convert_directory_to_json(dir_path)

            for filename, file_data in dir_result["files"].items():
                full_key = os.path.join(relative_path, filename) if relative_path else filename
                all_converted_files[full_key] = file_data

            summary = dir_result["conversion_summary"]
            self._merge_conversion_summary(combined_summary, summary, dir_path, relative_path)

            try:
                for item in os.listdir(dir_path):
                    item_path = os.path.join(dir_path, item)
                    if os.path.isdir(item_path) and not item.startswith('.'):
                        sub_relative_path = os.path.join(relative_path, item) if relative_path else item
                        process_directory(item_path, sub_relative_path)
            except PermissionError as e:
                self._logger.warning(f"Permission denied accessing subdirectory: {dir_path} - {e}")

        process_directory(directory_path)

        status_file_lists = self._build_status_file_lists(combined_summary["processing_details"])

        result = {
            "root_directory": directory_path,
            "conversion_summary": combined_summary,
            "files": all_converted_files,
            "converted_at": pd.Timestamp.now().isoformat(),
            "recursive_processing": True,
            "directories_processed": combined_summary["directories_processed"],
            "total_files_found": combined_summary["total_files"],
            **status_file_lists,
        }

        self._logger.info(
            f"Recursive directory conversion completed: {combined_summary['successful_conversions']} successful, "
            f"{combined_summary['failed_conversions']} failed, {combined_summary['skipped_files']} skipped "
            f"across {len(combined_summary['directories_processed'])} directories"
        )

        if output_file:
            self._save_json_output(output_file, result, context="Recursive conversion")

        return result

