import json
import logging
import os
import zipfile
from typing import Any, Dict, List, Optional, Tuple

try:
    import jsonschema  # type: ignore

    JSONSCHEMA_AVAILABLE = True
except Exception:
    JSONSCHEMA_AVAILABLE = False


def safe_json_loads(value: str) -> Optional[Any]:
    try:
        return json.loads(value)
    except Exception:
        return None


def read_zip_json(zf: zipfile.ZipFile, member: str) -> Optional[Dict[str, Any]]:
    try:
        raw = zf.read(member)
    except Exception:
        return None

    for encoding in ("utf-16-le", "utf-8", "cp1252", "latin-1"):
        try:
            content = raw.decode(encoding, errors="strict")
            if content and content[0] == "\ufeff":
                content = content[1:]

            content = (
                content.replace(chr(0), "")
                .replace(chr(28), "")
                .replace(chr(29), "")
                .replace(chr(25), "")
            )

            obj = json.loads(content.strip())
            if isinstance(obj, dict):
                return obj
            return None
        except Exception:
            continue

    return None


def validate_powerbi_schema(data: Dict[str, Any], schema_type: str, logger_: Optional[logging.Logger] = None) -> None:
    if not JSONSCHEMA_AVAILABLE:
        return

    logger = logger_ or logging.getLogger(__name__)

    if schema_type == "pbix_model":
        schema = {
            "type": "object",
            "properties": {
                "source": {"type": "object"},
                "tables": {"type": "array"},
                "measures": {"type": "array"},
                "relationships": {"type": "array"},
            },
            "required": ["source", "tables", "measures", "relationships"],
        }
    elif schema_type == "pbit_layout":
        schema = {
            "type": "object",
            "properties": {
                "source": {"type": "object"},
                "reportFilters": {"type": "array"},
                "pages": {"type": "array"},
            },
            "required": ["source", "reportFilters", "pages"],
        }
    elif schema_type == "pbip_project":
        schema = {
            "type": "object",
            "properties": {
                "source": {"type": "object"},
                "model": {"type": "object"},
                "layout": {"type": "object"},
            },
            "required": ["source", "model", "layout"],
        }
    else:
        return

    try:
        jsonschema.validate(data, schema)
    except Exception as exc:
        logger.warning(f"Schema validation failed: {str(exc)}")


def tmdl_indent_level(line: str) -> int:
    tabs = 0
    for character in line:
        if character == "\t":
            tabs += 1
        else:
            break
    if tabs:
        return tabs

    spaces = 0
    for character in line:
        if character == " ":
            spaces += 1
        else:
            break

    return spaces // 4 if spaces else 0


def parse_tmdl_table(tmdl_text: str) -> Dict[str, Any]:
    lines = tmdl_text.splitlines()

    table_name = ""
    hidden = False
    columns: List[Dict[str, Any]] = []
    measures: List[Dict[str, Any]] = []

    index = 0
    while index < len(lines):
        line = lines[index].rstrip("\n")
        stripped = line.strip()
        level = tmdl_indent_level(line)

        if stripped.startswith("table ") and not table_name:
            raw = stripped[len("table ") :].strip()
            table_name = raw.strip("'\"")

        elif stripped == "isHidden":
            hidden = True

        elif stripped.startswith("column ") and level <= 1:
            col_name = stripped[len("column ") :].strip().strip("'\"")
            col_type = None
            is_key = None

            sub_index = index + 1
            while sub_index < len(lines):
                sub_line = lines[sub_index].rstrip("\n")
                sub_stripped = sub_line.strip()
                sub_level = tmdl_indent_level(sub_line)

                if not sub_stripped:
                    sub_index += 1
                    continue
                if sub_level <= level:
                    break

                if sub_stripped.startswith("dataType:"):
                    col_type = sub_stripped.split(":", 1)[1].strip() or None
                elif sub_stripped == "isKey":
                    is_key = True
                sub_index += 1

            if col_name:
                columns.append({"name": col_name, "dataType": col_type, "isKey": is_key})
            index = sub_index - 1

        elif stripped.startswith("measure ") and level <= 1:
            rest = stripped[len("measure ") :].strip()
            eq = rest.find("=")
            if eq > 0:
                m_name = rest[:eq].strip().strip("'\"")
                m_expr = rest[eq + 1 :].strip()

                meta_prefixes = ("lineageTag:", "annotation ", "formatString:", "displayFolder:")
                sub_index = index + 1
                while sub_index < len(lines):
                    sub_line = lines[sub_index].rstrip("\n")
                    sub_stripped = sub_line.strip()
                    sub_level = tmdl_indent_level(sub_line)

                    if not sub_stripped:
                        sub_index += 1
                        continue
                    if sub_level <= level:
                        break
                    if any(sub_stripped.startswith(prefix) for prefix in meta_prefixes):
                        sub_index += 1
                        continue
                    m_expr += " " + sub_stripped
                    sub_index += 1

                if m_name:
                    measures.append({"name": m_name, "expression": (m_expr[:500] if m_expr else "")})
                index = sub_index - 1

        index += 1

    columns.sort(key=lambda x: x["name"])
    measures.sort(key=lambda x: x["name"])

    return {
        "name": table_name,
        "columns": columns,
        "hidden": hidden,
        "measures": measures,
    }


def parse_tmdl_relationship(tmdl_text: str) -> Optional[Dict[str, Any]]:
    from_table = from_col = to_table = to_col = None
    is_active = True

    for line in tmdl_text.splitlines():
        stripped = line.strip()

        if stripped.startswith("fromColumn:"):
            val = stripped.split(":", 1)[1].strip()
            parts = val.split(".")
            if len(parts) == 2:
                from_table = parts[0].strip().strip("'\"")
                from_col = parts[1].strip().strip("'\"")

        elif stripped.startswith("toColumn:"):
            val = stripped.split(":", 1)[1].strip()
            parts = val.split(".")
            if len(parts) == 2:
                to_table = parts[0].strip().strip("'\"")
                to_col = parts[1].strip().strip("'\"")

        elif stripped.startswith("isActive:"):
            is_active = stripped.split(":", 1)[1].strip().lower() != "false"

    if from_table and from_col and to_table and to_col:
        return {
            "fromTable": from_table,
            "fromColumn": from_col,
            "toTable": to_table,
            "toColumn": to_col,
            "active": is_active,
        }

    return None
