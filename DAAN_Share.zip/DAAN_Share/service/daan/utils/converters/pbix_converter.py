import logging
from typing import Any, Dict, List
import os
import zipfile
from .base_converter import BaseFileConverter
from .common_powerbi_utils import (
    validate_powerbi_schema,
)
from datetime import datetime
logger = logging.getLogger(__name__)


try:
    from pbixray import PBIXRay  # type: ignore
    PBIXRAY_AVAILABLE = True
except Exception:
    PBIXRAY_AVAILABLE = False


class PbixConverter(BaseFileConverter):
    
    def _extract_pbix_model_json(self, pbix_path: str) -> Dict[str, Any]:
        if not os.path.exists(pbix_path):
            raise FileNotFoundError(f"File not found: {pbix_path}")
        if not zipfile.is_zipfile(pbix_path):
            raise ValueError("File is not a valid ZIP/PBIX archive")

        if not PBIXRAY_AVAILABLE:
            raise RuntimeError("pbixray is required to extract PBIX model reliably")

        model = PBIXRay(pbix_path)

        tables: List[Dict[str, Any]] = []
        measures: List[Dict[str, Any]] = []
        relationships: List[Dict[str, Any]] = []
        calculated_columns: List[Dict[str, Any]] = []
        power_query: List[Dict[str, Any]] = []

        # ---- Tables + columns via schema dataframe (fast, doesn't load full data)
        try:
            schema_df = getattr(model, "schema", None)
            if schema_df is not None and not schema_df.empty:
                # Expected columns in pbixray schema df: TableName, ColumnName, PandasDataType (may vary)
                # We'll tolerate variants by checking multiple possible column names.
                table_col = "TableName" if "TableName" in schema_df.columns else ("Table" if "Table" in schema_df.columns else None)
                col_col = "ColumnName" if "ColumnName" in schema_df.columns else ("Column" if "Column" in schema_df.columns else None)
                type_col = "PandasDataType" if "PandasDataType" in schema_df.columns else ("DataType" if "DataType" in schema_df.columns else None)

                if table_col and col_col:
                    for tname, grp in schema_df.groupby(table_col):
                        cols = []
                        for _, row in grp.iterrows():
                            cname = str(row.get(col_col, "")).strip()
                            if not cname:
                                continue
                            dtype = None
                            if type_col:
                                raw_dtype = row.get(type_col, None)
                                dtype = str(raw_dtype) if raw_dtype is not None and str(raw_dtype).strip() else None
                            cols.append({"name": cname, "dataType": dtype, "isKey": None})
                        cols.sort(key=lambda x: x["name"])
                        tables.append({"name": str(tname), "columns": cols, "hidden": False})
        except Exception as e:
            logger.debug(f"Could not extract tables via schema df: {e}")

        # Fallback: table listing (names only)
        if not tables:
            try:
                table_list = list(getattr(model, "tables", []) or [])
                for t in table_list:
                    tables.append({"name": str(t), "columns": [], "hidden": False})
            except Exception:
                pass

        # ---- Measures
        try:
            measures_df = getattr(model, "dax_measures", None)
            if measures_df is not None and not measures_df.empty:
                for _, row in measures_df.iterrows():
                    table_name = str(row.get("TableName", "")).strip() if row.get("TableName") is not None else ""
                    measure_name = str(row.get("Name", "")).strip() if row.get("Name") is not None else ""
                    expr = str(row.get("Expression", "")).strip() if row.get("Expression") is not None else ""
                    if table_name and measure_name:
                        measures.append({"table": table_name, "name": measure_name, "expression": expr[:500] if expr else ""})
        except Exception as e:
            logger.debug(f"Could not extract measures: {e}")

        # ---- Relationships
        try:
            rel_df = getattr(model, "relationships", None)
            if rel_df is not None and not rel_df.empty:
                for _, row in rel_df.iterrows():
                    ft = str(row.get("FromTableName", "")).strip() if row.get("FromTableName") is not None else ""
                    fc = str(row.get("FromColumnName", "")).strip() if row.get("FromColumnName") is not None else ""
                    tt = str(row.get("ToTableName", "")).strip() if row.get("ToTableName") is not None else ""
                    tc = str(row.get("ToColumnName", "")).strip() if row.get("ToColumnName") is not None else ""
                    if not (ft and fc and tt and tc):
                        continue
                    active = bool(row.get("IsActive", True)) if row.get("IsActive") is not None else True
                    relationships.append({
                        "fromTable": ft,
                        "fromColumn": fc,
                        "toTable": tt,
                        "toColumn": tc,
                        "active": active
                    })
        except Exception as e:
            logger.debug(f"Could not extract relationships: {e}")

        # ---- Calculated columns
        try:
            dax_cols = getattr(model, "dax_columns", None)
            if dax_cols is not None and not dax_cols.empty:
                for _, row in dax_cols.iterrows():
                    table_name = str(row.get("TableName", "")).strip() if row.get("TableName") is not None else ""
                    col_name = str(row.get("ColumnName", "")).strip() if row.get("ColumnName") is not None else ""
                    expr = str(row.get("Expression", "")).strip() if row.get("Expression") is not None else ""
                    if table_name and col_name:
                        calculated_columns.append({
                            "table": table_name,
                            "name": col_name,
                            "expression": expr[:300] if expr else None
                        })
        except Exception as e:
            logger.debug(f"Could not extract calculated columns: {e}")

        # ---- Power Query (M)
        try:
            pq_df = getattr(model, "power_query", None)
            if pq_df is not None and not pq_df.empty:
                for _, row in pq_df.iterrows():
                    tname = str(row.get("TableName", "")).strip() if row.get("TableName") is not None else ""
                    expr = str(row.get("Expression", "")).strip() if row.get("Expression") is not None else ""
                    if tname:
                        power_query.append({"table": tname, "expression": expr[:1500] if expr else ""})
        except Exception as e:
            logger.debug(f"Could not extract power query: {e}")

        # ---- Deterministic sorting
        tables.sort(key=lambda x: x["name"])
        for t in tables:
            t["columns"].sort(key=lambda c: c["name"])
        measures.sort(key=lambda x: (x["table"], x["name"]))
        relationships.sort(key=lambda x: (x["fromTable"], x["fromColumn"], x["toTable"], x["toColumn"]))
        calculated_columns.sort(key=lambda x: (x["table"], x["name"]))
        power_query.sort(key=lambda x: x["table"])

        result: Dict[str, Any] = {
            "source": {
                "fileType": "PBIX",
                "path": pbix_path,
                "extractionMethod": "pbixray",
                "generatedAt": datetime.now().isoformat()
            },
            "tables": tables,
            "measures": measures,
            "relationships": relationships
        }
        if calculated_columns:
            result["calculatedColumns"] = calculated_columns
        if power_query:
            result["powerQuery"] = power_query
        return result

    
    def _parse_pbix_model(self, pbix_path: str) -> Dict[str, Any]:
        """
        Parse a PBIX file and extract the data model in schema-validated format.

        Contract:
        {
          "source": { "fileType":"PBIX","path":..., "extractionMethod":..., "generatedAt":... },
          "tables": [ { "name", "columns": [ { "name","dataType"?,"isKey"? } ], "hidden"? } ],
          "measures": [ { "table", "name", "expression"? } ],
          "relationships": [ { "fromTable","fromColumn","toTable","toColumn","active"? } ],
          "calculatedColumns"?: [ { "table","name","expression"? } ],
          "powerQuery"?: [ { "table","expression" } ]
        }
        """
        try:
            result = self._extract_pbix_model_json(pbix_path)
            validate_powerbi_schema(result, "pbix_model", logger_=logger)
            return result
        except Exception as e:
            logger.error(f"Error parsing PBIX model: {str(e)}")
            return {
                "source": {
                    "fileType": "PBIX",
                    "path": pbix_path,
                    "extractionMethod": "error",
                    "generatedAt": datetime.now().isoformat()
                },
                "tables": [],
                "measures": [],
                "relationships": [],
                "error": str(e)
            }

    
    def convert(self, file_path: str) -> Dict[str, Any]:
        try:
            result = self._parse_pbix_model(file_path)
            return {"type": "pbix_file", "model": result}
        except Exception as exc:
            logger.error(f"Error converting pbix_file file {file_path}: {exc}")
            return {
                "type": "pbix_file",
                "error": f"Failed to convert pbix_file file: {str(exc)}",
            }
