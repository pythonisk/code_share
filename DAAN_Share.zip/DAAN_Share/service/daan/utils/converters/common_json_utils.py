import logging
from typing import Any, Optional

import numpy as np
import pandas as pd


def json_serializer(obj: Any, logger_: Optional[logging.Logger] = None) -> Any:
    logger = logger_ or logging.getLogger(__name__)

    if isinstance(obj, pd.DataFrame):
        logger.warning("DataFrame found during JSON serialization, converting to dict")
        return obj.to_dict('records')
    if isinstance(obj, (np.integer, pd.Int64Dtype)):
        return int(obj)
    if isinstance(obj, (np.floating, pd.Float64Dtype)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, pd.Timestamp):
        return obj.isoformat()
    if isinstance(obj, (pd.Series, pd.Index)):
        return obj.tolist()
    if hasattr(obj, 'item'):
        return obj.item()
    if isinstance(obj, tuple):
        return list(obj)
    return str(obj)


def is_problematic_value(value: Any) -> bool:
    if value is None:
        return True

    try:
        if pd.isna(value):
            return True
    except (TypeError, ValueError):
        pass

    if hasattr(value, 'size') and hasattr(value, 'shape'):
        return True

    try:
        str_val = str(value).strip().lower()
        problematic_values = {'nan', 'none', 'null', '', '<na>', 'n/a', '#n/a', '#na', 'nat'}
        return str_val in problematic_values
    except Exception:
        return True


def final_json_cleanup(obj: Any) -> Any:
    if isinstance(obj, dict):
        cleaned = {}
        for key, value in obj.items():
            if value is not None:
                cleaned_value = final_json_cleanup(value)
                if cleaned_value is not None and not is_problematic_value(cleaned_value):
                    cleaned[key] = cleaned_value
                elif isinstance(value, dict) and cleaned_value is None:
                    cleaned[key] = {}
        return cleaned if cleaned else None

    if isinstance(obj, list):
        cleaned = []
        for item in obj:
            if item is not None:
                cleaned_item = final_json_cleanup(item)
                if cleaned_item is not None and not is_problematic_value(cleaned_item):
                    cleaned.append(cleaned_item)
        return cleaned if cleaned else None

    if pd.isna(obj) or obj is None:
        return None

    if isinstance(obj, (int, float)):
        if pd.isna(obj) or np.isnan(obj) or np.isinf(obj):
            return None
        return obj

    if isinstance(obj, pd.Timestamp):
        return obj.isoformat()

    if is_problematic_value(obj):
        return None

    return obj
