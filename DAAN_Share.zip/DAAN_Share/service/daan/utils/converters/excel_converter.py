import logging
from typing import Any, Dict, Optional

import pandas as pd

from .base_converter import BaseFileConverter
from .common_dataframe_utils import clean_dataframe, detect_embedded_header_row, split_metadata_and_data


class ExcelConverter(BaseFileConverter):
    def __init__(
        self,
        logger_: Optional[logging.Logger] = None,
    ):
        self._logger = logger_ or logging.getLogger(__name__)

    def convert(self, file_path: str) -> Dict[str, Any]:
        try:
            excel_file = pd.ExcelFile(file_path)
            sheets_data: Dict[str, Any] = {}
            total_cleaning_summary: Dict[str, Any] = {}

            for sheet_name in excel_file.sheet_names:
                try:
                    df = pd.read_excel(file_path, sheet_name=sheet_name)
                    embedded_header_idx = detect_embedded_header_row(df, logger_=self._logger)
                    tables = []

                    if embedded_header_idx is not None:
                        metadata_df, data_df = split_metadata_and_data(df, embedded_header_idx, logger_=self._logger)

                        if not metadata_df.empty:
                            cleaned_metadata, metadata_summary = clean_dataframe(metadata_df, logger_=self._logger)
                            metadata_kv = self._create_key_value_structure(cleaned_metadata, {"table_type": "metadata"})
                            tables.append(
                                {
                                    "table_name": "Metadata",
                                    "table_type": "metadata",
                                    "rows": cleaned_metadata.to_dict("records"),
                                    "columns": cleaned_metadata.columns.tolist(),
                                    "shape": list(cleaned_metadata.shape),
                                    "cleaning_summary": metadata_summary,
                                    "key_value_pairs": metadata_kv["key_value_pairs"],
                                    "column_headers": metadata_kv["column_headers"],
                                    "row_values": metadata_kv["row_values"],
                                }
                            )

                        cleaned_data, data_summary = clean_dataframe(data_df, logger_=self._logger)
                        data_kv = self._create_key_value_structure(cleaned_data, {"table_type": "mapping_data"})
                        tables.append(
                            {
                                "table_name": "Mapping_Data",
                                "table_type": "mapping_data",
                                "rows": cleaned_data.to_dict("records"),
                                "columns": cleaned_data.columns.tolist(),
                                "shape": list(cleaned_data.shape),
                                "cleaning_summary": data_summary,
                                "key_value_pairs": data_kv["key_value_pairs"],
                                "column_headers": data_kv["column_headers"],
                                "row_values": data_kv["row_values"],
                            }
                        )

                        sheets_data[sheet_name] = {
                            "sheet_name": sheet_name,
                            "tables": tables,
                            "sheet_analysis": {"note": "Detected embedded header - split into metadata and mapping data"},
                            "total_tables": len(tables),
                            "sheet_summary": {"total_key_value_pairs": sum(len(t["key_value_pairs"]) for t in tables)},
                        }

                        total_cleaning_summary[sheet_name] = {
                            "metadata": metadata_summary if not metadata_df.empty else {},
                            "data": data_summary,
                        }
                    else:
                        cleaned_df, cleaning_summary = clean_dataframe(df, logger_=self._logger)
                        fallback_key_value = self._create_key_value_structure(cleaned_df, {"table_type": "standard_table"})
                        sheets_data[sheet_name] = {
                            "sheet_name": sheet_name,
                            "tables": [
                                {
                                    "table_name": "Main_Data",
                                    "table_type": "standard_table",
                                    "rows": cleaned_df.to_dict("records"),
                                    "columns": cleaned_df.columns.tolist(),
                                    "shape": list(cleaned_df.shape),
                                    "cleaning_summary": cleaning_summary,
                                    "key_value_pairs": fallback_key_value["key_value_pairs"],
                                    "column_headers": fallback_key_value["column_headers"],
                                    "row_values": fallback_key_value["row_values"],
                                }
                            ],
                            "sheet_analysis": {"note": "Standard table processing used for stability"},
                            "total_tables": 1,
                            "sheet_summary": {"total_key_value_pairs": len(fallback_key_value["key_value_pairs"])},
                        }
                        total_cleaning_summary[sheet_name] = cleaning_summary
                except Exception as exc:
                    self._logger.error(f"Error processing sheet '{sheet_name}': {exc}")
                    continue

            return {
                "type": "excel_workbook",
                "sheets": sheets_data,
                "sheet_names": excel_file.sheet_names,
                "cleaning_summary": total_cleaning_summary,
                "workbook_summary": self._create_workbook_summary(sheets_data),
                "summary": {
                    "total_sheets": len(excel_file.sheet_names),
                    "sheet_info": {
                        name: {
                            "total_tables": sheets_data[name]["total_tables"],
                            "analysis_type": "standard_key_value_structure",
                            "key_value_pairs": sheets_data[name].get("sheet_summary", {}).get("total_key_value_pairs", 0),
                        }
                        for name in excel_file.sheet_names
                        if name in sheets_data
                    },
                },
            }
        except Exception as exc:
            self._logger.error(f"Error reading Excel file {file_path}: {str(exc)}")
            return {"error": f"Failed to read Excel file: {str(exc)}"}

    def _create_key_value_structure(self, df: pd.DataFrame, table_info: Dict) -> Dict[str, Any]:
        structure = {
            "key_value_pairs": {},
            "column_headers": df.columns.tolist(),
            "row_values": [],
        }

        table_type = table_info.get("table_type", "unknown")

        if table_type in {"vertical_table", "fallback_vertical"} and "Key" in df.columns:
            value_columns = [col for col in df.columns if col != "Key"]

            for _, row in df.iterrows():
                key = str(row["Key"]).strip() if pd.notna(row["Key"]) else ""
                if not key:
                    continue

                if len(value_columns) == 1:
                    value = row[value_columns[0]]
                    structure["key_value_pairs"][key] = str(value).strip() if pd.notna(value) else ""
                else:
                    value_map = {}
                    for value_column in value_columns:
                        value = row[value_column]
                        value_map[value_column] = str(value).strip() if pd.notna(value) else ""
                    structure["key_value_pairs"][key] = value_map
        else:
            for row_idx, row in df.iterrows():
                row_dict = {}
                row_key_parts = []

                for column in df.columns:
                    value = row[column]
                    value_str = str(value).strip() if pd.notna(value) else ""
                    row_dict[column] = value_str

                    if value_str and len(row_key_parts) < 2:
                        row_key_parts.append(value_str)

                if row_key_parts:
                    row_key = " | ".join(row_key_parts[:2])
                else:
                    row_key = f"Row_{row_idx + 1}"

                structure["key_value_pairs"][row_key] = row_dict
                structure["row_values"].append(row_dict)

        return structure

    def _create_workbook_summary(self, sheets_data: Dict[str, Any]) -> Dict[str, Any]:
        summary = {
            "total_sheets": len(sheets_data),
            "total_tables": 0,
            "total_key_value_pairs": 0,
            "sheet_types": {},
            "total_columns": 0,
            "total_rows": 0,
        }

        for sheet_name, sheet_data in sheets_data.items():
            tables = sheet_data.get("tables", [])
            summary["total_tables"] += len(tables)

            sheet_key_value_pairs = 0
            for table in tables:
                key_value_pairs = table.get("key_value_pairs", {})
                if isinstance(key_value_pairs, dict):
                    count = len(key_value_pairs)
                elif isinstance(key_value_pairs, list):
                    count = len(key_value_pairs)
                else:
                    count = 0

                sheet_key_value_pairs += count
                summary["total_columns"] += len(table.get("columns", []))
                shape = table.get("shape", [0, 0])
                if isinstance(shape, list) and shape:
                    summary["total_rows"] += shape[0]

            summary["total_key_value_pairs"] += sheet_key_value_pairs
            summary["sheet_types"][sheet_name] = {
                "tables": len(tables),
                "key_value_pairs": sheet_key_value_pairs,
            }

        return summary
