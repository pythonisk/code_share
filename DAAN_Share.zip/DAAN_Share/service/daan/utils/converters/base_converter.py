from abc import ABC, abstractmethod
from typing import Any, Dict

class BaseFileConverter(ABC):
    @abstractmethod
    def convert(self, file_path: str) -> Dict[str, Any]:
        """
        Convert the file at the given path to a desired format.
        Args:
            file_path (str): Path to the input file.
        Returns:
            Dict[str, Any]: The result of the conversion process.
        """
        raise NotImplementedError
