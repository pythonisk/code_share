from __future__ import annotations

import logging
import shutil
import subprocess
import tempfile
from typing import Any, Dict, List, Optional
from pathlib import Path

from .base_converter import BaseFileConverter


class PptConverter(BaseFileConverter):
    # PowerPoint converter backed by python-pptx.

    def __init__(self, logger_: Optional[logging.Logger] = None) -> None:
        self.logger = logger_ or logging.getLogger(__name__)

    def convert(self, file_path: str) -> Dict[str, Any]:
        source_path = Path(file_path)
        converted_path: Optional[Path] = None
        if source_path.suffix.lower() == ".ppt":
            converted_path = self._convert_legacy_ppt(source_path)
            file_path = str(converted_path)

        try:
            from pptx import Presentation
        except ImportError as exc:
            raise ImportError("PptConverter requires python-pptx. Install with: pip install python-pptx") from exc

        try:
            presentation = Presentation(file_path)
            slides: List[Dict[str, Any]] = []
            for index, slide in enumerate(presentation.slides, start=1):
                segments = [
                    str(shape.text)
                    for shape in slide.shapes
                    if getattr(shape, "has_text_frame", False) and shape.text
                ]

                notes_text = ""
                notes_slide = getattr(slide, "notes_slide", None)
                if notes_slide is not None and getattr(notes_slide, "notes_text_frame", None) is not None:
                    notes_text = str(notes_slide.notes_text_frame.text or "")

                text = "\n".join(segments)
                slides.append(
                    {
                        "slide_number": index,
                        "text": text,
                        "char_count": len(text),
                        "has_speaker_notes": bool(notes_text.strip()),
                        "speaker_notes": notes_text,
                        "layout_type": str(getattr(slide.slide_layout, "name", "unknown") or "unknown"),
                        "shapes_count": len(slide.shapes),
                    }
                )

            full_text = "\n".join(
                "\n".join(part for part in (slide["text"], slide["speaker_notes"]) if part.strip())
                for slide in slides
            ).strip()

            if not full_text:
                raise ValueError(f"No extractable text found in presentation: {file_path}")

            return {
                "type": "text_file",
                "content": full_text,
                "structured_sections": {},
                "slides": slides,
                "summary": {
                    "total_slides": len(slides),
                    "total_characters": len(full_text),
                    "source_format": "powerpoint",
                },
            }
        finally:
            if converted_path is not None:
                shutil.rmtree(converted_path.parent, ignore_errors=True)

    @staticmethod
    def _convert_legacy_ppt(source_path: Path) -> Path:
        soffice = shutil.which("soffice") or shutil.which("libreoffice")
        if not soffice:
            raise RuntimeError(
                "Legacy .ppt requires LibreOffice (soffice) for conversion to .pptx; "
                "install LibreOffice or provide a .pptx file"
            )

        output_dir = Path(tempfile.mkdtemp(prefix="daan_ppt_"))
        result = subprocess.run(
            [soffice, "--headless", "--convert-to", "pptx", "--outdir", str(output_dir), str(source_path)],
            capture_output=True,
            text=True,
            check=False,
        )
        converted_path = output_dir / f"{source_path.stem}.pptx"
        if result.returncode != 0 or not converted_path.exists():
            shutil.rmtree(output_dir, ignore_errors=True)
            detail = (result.stderr or result.stdout).strip()
            raise RuntimeError(f"Could not convert legacy .ppt '{source_path}': {detail}")
        return converted_path
