import logging
import re
from typing import Any, Dict, Optional, Tuple

import pandas as pd


def clean_dataframe(df: pd.DataFrame, logger_: Optional[logging.Logger] = None) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    logger = logger_ or logging.getLogger(__name__)

    cleaned_df = df.copy()
    original_shape = df.shape

    cleaning_summary = {
        "original_shape": [int(original_shape[0]), int(original_shape[1])],
        "unnamed_columns_removed": 0,
        "auto_generated_columns_removed": 0,
        "nan_columns_removed": 0,
        "empty_columns_removed": 0,
        "empty_rows_removed": 0,
        "final_empty_rows_removed": 0,
        "nan_values_cleaned": 0,
        "null_strings_cleaned": 0,
    }

    unnamed_columns = [col for col in cleaned_df.columns if "unnamed" in str(col).lower()]
    if unnamed_columns:
        cleaning_summary["unnamed_columns_removed"] = len(unnamed_columns)
        logger.info(f"Removing {len(unnamed_columns)} unnamed columns: {unnamed_columns}")
        cleaned_df = cleaned_df.drop(columns=unnamed_columns)

    auto_generated_columns = [col for col in cleaned_df.columns if re.match(r"^Column_\d+$", str(col))]
    if auto_generated_columns:
        cleaning_summary["auto_generated_columns_removed"] = len(auto_generated_columns)
        logger.info(f"Removing {len(auto_generated_columns)} auto-generated columns: {auto_generated_columns}")
        cleaned_df = cleaned_df.drop(columns=auto_generated_columns)

    new_column_names = []
    columns_to_drop = []
    for i, col in enumerate(cleaned_df.columns):
        col_str = str(col).strip().lower()
        if col_str in ["nan", "none", "", "null"]:
            if cleaned_df[col].fillna("").astype(str).str.strip().eq("").all():
                columns_to_drop.append(col)
            else:
                new_column_names.append(f"Data_Column_{i + 1}")
        else:
            new_column_names.append(str(col).strip())

    if columns_to_drop:
        cleaning_summary["nan_columns_removed"] = len(columns_to_drop)
        logger.info(f"Removing {len(columns_to_drop)} nan/empty columns: {columns_to_drop}")
        cleaned_df = cleaned_df.drop(columns=columns_to_drop)
        remaining_cols = [col for col in cleaned_df.columns]
        new_column_names = []
        for i, col in enumerate(remaining_cols):
            col_str = str(col).strip().lower()
            if col_str in ["nan", "none", "", "null"]:
                new_column_names.append(f"Data_Column_{i + 1}")
            else:
                new_column_names.append(str(col).strip())

    if len(new_column_names) == len(cleaned_df.columns):
        cleaned_df.columns = new_column_names

    empty_columns = cleaned_df.columns[cleaned_df.isnull().all()].tolist()
    if empty_columns:
        cleaning_summary["empty_columns_removed"] = len(empty_columns)
        logger.info(f"Removing {len(empty_columns)} empty columns: {empty_columns}")
        cleaned_df = cleaned_df.drop(columns=empty_columns)

    initial_rows = len(cleaned_df)
    cleaned_df = cleaned_df.dropna(how="all")
    removed_rows = initial_rows - len(cleaned_df)
    if removed_rows > 0:
        cleaning_summary["empty_rows_removed"] = int(removed_rows)
        logger.info(f"Removed {removed_rows} completely empty rows")

    nan_count = int(cleaned_df.isnull().sum().sum())
    if nan_count > 0:
        cleaning_summary["nan_values_cleaned"] = nan_count
        logger.info(f"Cleaning {nan_count} NaN values")
    cleaned_df = cleaned_df.fillna("")

    cleaned_df.columns = [str(col).strip() for col in cleaned_df.columns]

    null_strings_cleaned = 0
    for col in cleaned_df.columns:
        try:
            column_series = cleaned_df[col]
            if isinstance(column_series, pd.DataFrame):
                logger.warning(f"Column '{col}' returned DataFrame instead of Series. Skipping cleanup.")
                continue

            if column_series.dtype == "object":
                cleaned_series = column_series.astype(str).str.strip()
                cleaned_df[col] = cleaned_series

                null_values = [
                    r"\bnan\b",
                    r"\bnull\b",
                    r"\bnone\b",
                    r"\bn/a\b",
                    r"\bna\b",
                    "#n/a",
                    "#null!",
                    "#ref!",
                ]
                for null_val in null_values:
                    before_count = (
                        (cleaned_df[col].str.lower() == null_val.lower().replace(r"\b", "")).sum()
                        if r"\b" in null_val
                        else (cleaned_df[col].str.lower() == null_val.lower()).sum()
                    )
                    if r"\b" in null_val:
                        cleaned_df[col] = cleaned_df[col].str.replace(null_val, "", case=False, regex=True)
                    else:
                        cleaned_df[col] = cleaned_df[col].str.replace(null_val, "", case=False, regex=False)
                    null_strings_cleaned += before_count
        except (AttributeError, TypeError) as exc:
            logger.warning(f"Error processing column '{col}': {exc}")
            continue

    if null_strings_cleaned > 0:
        cleaning_summary["null_strings_cleaned"] = int(null_strings_cleaned)
        logger.info(f"Cleaned {null_strings_cleaned} null string values")

    empty_after_cleanup = []
    for col in cleaned_df.columns:
        col_values = cleaned_df[col].fillna("").astype(str).str.strip()
        if col_values.isin(["", "nan", "none", "null", "na"]).all() or col_values.eq("").all():
            empty_after_cleanup.append(col)
            logger.info(f"Removing column '{col}' as it contains only empty/null values")

    if empty_after_cleanup:
        cleaned_df = cleaned_df.drop(columns=empty_after_cleanup)

    if not cleaned_df.empty:
        initial_rows_final = len(cleaned_df)
        cleaned_df = cleaned_df.dropna(how="all")
        final_rows_removed = initial_rows_final - len(cleaned_df)
        if final_rows_removed > 0:
            cleaning_summary["final_empty_rows_removed"] = int(final_rows_removed)
            logger.info(f"Removed {final_rows_removed} completely empty rows in final cleanup")

    cleaning_summary["final_shape"] = [int(cleaned_df.shape[0]), int(cleaned_df.shape[1])]
    cleaning_summary["columns_removed_after_cleanup"] = len(empty_after_cleanup)

    return cleaned_df, cleaning_summary


def detect_embedded_header_row(df: pd.DataFrame, logger_: Optional[logging.Logger] = None) -> Optional[int]:
    logger = logger_ or logging.getLogger(__name__)

    header_keywords = [
        "source object",
        "target object",
        "source field",
        "target field",
        "source column",
        "target column",
        "source table",
        "target table",
        "source attribute",
        "target attribute",
        "transformation",
        "mapping",
        "column name",
        "field name",
        "attribute name",
        "table name",
        "schema name",
        "datatype",
        "data type",
        "field type",
        "field description",
        "max length",
        "position",
    ]

    for idx, row in df.iterrows():
        row_values_lower = [str(v).lower().strip() for v in row.values if pd.notna(v) and str(v).strip()]

        header_matches = sum(1 for val in row_values_lower for keyword in header_keywords if keyword in val)

        if header_matches >= 3:
            logger.info(
                f"Detected embedded header row at index {idx} with {header_matches} header keywords: {row_values_lower}"
            )
            return idx

    return None


def split_metadata_and_data(
    df: pd.DataFrame,
    header_row_idx: int,
    logger_: Optional[logging.Logger] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    logger = logger_ or logging.getLogger(__name__)

    metadata_df = df.iloc[:header_row_idx].copy() if header_row_idx > 0 else pd.DataFrame()

    header_row = df.iloc[header_row_idx]
    new_columns = [
        str(v).strip() if pd.notna(v) and str(v).strip() else f"Column_{i}"
        for i, v in enumerate(header_row.values)
    ]

    data_df = df.iloc[header_row_idx + 1 :].copy()
    data_df.columns = new_columns[: len(data_df.columns)]
    data_df = data_df.reset_index(drop=True)

    logger.info(f"Split into metadata ({len(metadata_df)} rows) and data ({len(data_df)} rows)")
    logger.info(f"New column headers: {new_columns}")

    return metadata_df, data_df
