"""
Tableau Specification Builder
=============================
Transforms Tableau XML into a comprehensive Power BI schema.

Uses enhanced metadata extraction to get exact visual specifications:
  - Column roles (dimension vs measure) with default aggregations
  - Visual marks, shelves (Rows, Columns, Color, Size, Label, Tooltip)
  - Field aggregations and encodings
  - Filters, sorts, reference lines
  - Dual-axis configurations

Output: PowerBI-compatible schema with complete field mappings and aggregations
"""

from __future__ import annotations

import re
import logging
from typing import Any, Dict, List, Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Field-reference parsing
# ---------------------------------------------------------------------------

# Matches:  [datasource].[prefix:Field:role]  or  [ds].[obj_id].[prefix:Field:role]
_FIELD_REF_RE = re.compile(
    r"\[([^\]]+)\]"          # datasource id
    r"(?:\.\[([^\]]+)\])?"   # optional intermediate (e.g. __tableau_internal_object_id__)
    r"\.\[([^\]]+)\]"        # column-instance name
)

# Parses a column-instance token like "sum:Salary:qk" or "none:Job Title:nk"
_COL_INST_RE = re.compile(
    r"^(?:(none|sum|avg|cnt|min|max|med|attr|cntd|pcto|cum|tyr|yr|bin|mn|qr|dy|wk|hr|mns|sec)"
    r"(?::(?:none|sum|avg|cnt|min|max|med|attr|cntd))*)?"  # nested agg prefix
    r":?([^:]+)"            # field name
    r":(nk|qk|ok)"         # role suffix
    r"(?::(\d+))?$"         # optional index
)

_AGG_MAP = {
    "none": None,
    "sum": "SUM",
    "avg": "AVG",
    "cnt": "COUNT",
    "min": "MIN",
    "max": "MAX",
    "med": "MEDIAN",
    "attr": "ATTR",
    "cntd": "COUNTD",
    "pcto": "PCT_TOTAL",
    "cum": "RUNNING_TOTAL",
    "tyr": "YEAR",
    "yr": "YEAR",
    "bin": "BIN",
    "mn": "MONTH",
    "qr": "QUARTER",
    "dy": "DAY",
    "wk": "WEEK",
    "hr": "HOUR",
    "mns": "MINUTE",
    "sec": "SECOND",
    "stdev": "STDEV",
    "stdevp": "STDEVP",
    "var": "VAR",
    "varp": "VARP",
}

_ROLE_MAP = {"nk": "dimension", "qk": "measure", "ok": "ordinal"}


# Tableau internal auto-generated record-count column pattern
_INTERNAL_ID_RE = re.compile(r"^data_[0-9A-Fa-f]{20,}$")


def _clean_field_name(name: str, calc_name_map: Optional[Dict[str, str]] = None) -> str:
    """Replace Tableau internal IDs with human-readable names.

    Uses *calc_name_map* (internal-name → caption) built from the
    datasource <column> elements to resolve Calculation_XXXX IDs.
    """
    if _INTERNAL_ID_RE.match(name):
        return "Record Count"
    # Resolve Calculation_XXXX and other internal names via lookup
    if calc_name_map and name in calc_name_map:
        return calc_name_map[name]
    return name


def _parse_field_ref(ref: str, calc_name_map: Optional[Dict[str, str]] = None) -> Optional[Dict[str, Any]]:
    """Parse a single Tableau field reference into {field, aggregation, role}."""
    # Handle special fields
    if "[:Measure Names]" in ref:
        return {"field": "Measure Names", "aggregation": None, "role": "dimension", "special": True}
    if "[Multiple Values]" in ref:
        return {"field": "Multiple Values", "aggregation": None, "role": "measure", "special": True}

    m = _FIELD_REF_RE.search(ref)
    if not m:
        return None

    inst_token = m.group(3) or m.group(2)
    if not inst_token:
        return None

    cm = _COL_INST_RE.match(inst_token)
    if cm:
        agg_prefix = cm.group(1) or "none"
        field_name = _clean_field_name(cm.group(2), calc_name_map)
        role_suffix = cm.group(3)
        # Tableau bin references use prefix "bin:Field:qk" — resolve to
        # the calculated-field convention "Field (bin)"
        if agg_prefix == "bin":
            field_name = f"{field_name} (bin)"
        return {
            "field": field_name,
            "aggregation": _AGG_MAP.get(agg_prefix),
            "role": _ROLE_MAP.get(role_suffix, "dimension"),
        }

    # Fallback: treat the whole token as a field name
    return {"field": _clean_field_name(inst_token, calc_name_map), "aggregation": None, "role": "dimension"}


def _parse_shelf(shelf_str: str, calc_name_map: Optional[Dict[str, str]] = None) -> List[Dict[str, Any]]:
    """Parse a rows/cols shelf string into a list of field references.

    Handles compound shelves like:
      ([ds].[none:Emp ID:nk] / [ds].[none:Name:nk])
    """
    if not shelf_str or not isinstance(shelf_str, str):
        return []

    # Split on ' / ' (the Tableau compound separator)
    # Only strip grouping parentheses (those NOT inside bracket field refs)
    # Approach: remove parens that are outside [...] blocks
    cleaned_chars = []
    bracket_depth = 0
    for ch in shelf_str:
        if ch == '[':
            bracket_depth += 1
            cleaned_chars.append(ch)
        elif ch == ']':
            bracket_depth -= 1
            cleaned_chars.append(ch)
        elif ch in '()' and bracket_depth == 0:
            # Skip grouping parens outside brackets
            continue
        else:
            cleaned_chars.append(ch)
    cleaned = ''.join(cleaned_chars)
    parts = cleaned.split(" / ")

    results = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        parsed = _parse_field_ref(part, calc_name_map)
        if parsed:
            results.append(parsed)
    return results


# ---------------------------------------------------------------------------
# Mark-type to visual-type mapping
# ---------------------------------------------------------------------------

_MARK_TO_VISUAL: Dict[str, str] = {
    "Automatic": "bar",       # resolved later using context
    "Bar": "bar",
    "Line": "line",
    "Area": "area",
    "Circle": "scatter",
    "Square": "treemap",
    "Shape": "shape",
    "Text": "text_table",
    "Map": "map",
    "Pie": "pie",
    "Gantt Bar": "gantt",
    "Polygon": "polygon",
}


def _infer_visual_type(mark_class: str, rows: list, cols: list, encodings: dict) -> str:
    """Infer the effective visual type from mark + shelf + encoding context."""
    base = _MARK_TO_VISUAL.get(mark_class, "bar")

    if base != "bar":
        return base

    # "Automatic" heuristics:
    has_dim_rows = any(f.get("role") == "dimension" for f in rows)
    has_dim_cols = any(f.get("role") == "dimension" for f in cols)
    has_meas_rows = any(f.get("role") == "measure" for f in rows)
    has_meas_cols = any(f.get("role") == "measure" for f in cols)

    # Text table: Measure Names on cols, multiple dimensions on rows
    if any(f.get("field") == "Measure Names" for f in cols):
        return "text_table"
    if any(f.get("field") == "Measure Names" for f in rows):
        return "text_table"

    # No shelves at all → card / KPI
    if not rows and not cols:
        if encodings.get("text"):
            return "text_table"
        return "card"

    # Date on an axis → line chart
    for f in (rows + cols):
        if f.get("aggregation") in ("YEAR", "RUNNING_TOTAL"):
            return "line"

    # --- Stacked bar/column detection ---
    # In Tableau, a dimension on the Color encoding creates stacked segments.
    # Detect this and emit "stacked bar" / "stacked column" so Power BI uses
    # stackedBarChart / stackedColumnChart instead of clustered variants.
    has_color_dimension = False
    color_enc = encodings.get("color")
    if color_enc:
        # color_enc can be a string (field name) or dict with {"field": ...}
        if isinstance(color_enc, str):
            has_color_dimension = True  # dimension field on color shelf
        elif isinstance(color_enc, dict):
            # If it has an aggregation like SUM/COUNT, it's a measure-on-color (gradient),
            # not a dimension-on-color (stacking). Only treat it as stacking if there is
            # no aggregation, or aggregation is a dimension-type (BIN, YEAR, etc.)
            agg = color_enc.get("aggregation", "")
            if not agg or agg in ("BIN", "YEAR", "MONTH", "QUARTER", "DAY"):
                has_color_dimension = True
        elif isinstance(color_enc, list):
            # Multiple fields on color — at least one dimension → stacked
            for item in color_enc:
                if isinstance(item, str):
                    has_color_dimension = True
                    break
                elif isinstance(item, dict):
                    agg = item.get("aggregation", "")
                    if not agg or agg in ("BIN", "YEAR", "MONTH", "QUARTER", "DAY"):
                        has_color_dimension = True
                        break

    # Dimension on rows, measure on cols → horizontal bar
    if has_dim_rows and has_meas_cols and not has_dim_cols:
        return "stacked bar" if has_color_dimension else "bar"
    # Measure on rows, dimension on cols → vertical column chart
    if has_meas_rows and has_dim_cols and not has_dim_rows:
        return "stacked column" if has_color_dimension else "column"
    # Measures on BOTH axes (no dimension axis) → scatter plot
    if has_meas_rows and has_meas_cols and not has_dim_rows and not has_dim_cols:
        return "scatter"
    # Both dims on both → crosstab / text table
    if has_dim_rows and has_dim_cols:
        return "text_table"

    return "stacked bar" if has_color_dimension else "bar"


# ---------------------------------------------------------------------------
# Filter extraction
# ---------------------------------------------------------------------------

def _extract_filters(view: dict, calc_name_map: Optional[Dict[str, str]] = None) -> List[Dict[str, Any]]:
    """Extract human-readable filter definitions from a worksheet view."""
    raw = view.get("filter", [])
    if isinstance(raw, dict):
        raw = [raw]
    if not isinstance(raw, list):
        return []

    filters = []
    for f in raw:
        if not isinstance(f, dict):
            continue
        attrs = f.get("@attributes", {})
        col_ref = attrs.get("column", "")
        is_context = attrs.get("context", "") == "true"

        # Skip internal action filters
        if "Action (" in col_ref:
            continue

        parsed = _parse_field_ref(col_ref, calc_name_map)
        field_name = _clean_field_name(parsed["field"], calc_name_map) if parsed else _clean_field_name(col_ref, calc_name_map)

        filt: Dict[str, Any] = {"field": field_name}
        if is_context:
            filt["context_filter"] = True

        # Parse groupfilter for filter details
        gf = f.get("groupfilter", {})
        filt_details = _parse_groupfilter(gf, calc_name_map)
        filt.update(filt_details)

        filters.append(filt)

    return filters


def _parse_groupfilter(gf: dict, calc_name_map: Optional[Dict[str, str]] = None) -> dict:
    """Parse a groupfilter element into a human-readable dict."""
    if not isinstance(gf, dict):
        return {}

    attrs = gf.get("@attributes", {})
    func = attrs.get("function", "")

    if func == "end":
        # Top-N filter
        count = attrs.get("count", "")
        end = attrs.get("end", "top")
        nested = gf.get("groupfilter", {})
        order_gf = nested if isinstance(nested, dict) else {}
        order_attrs = order_gf.get("@attributes", {})
        direction = order_attrs.get("direction", "DESC")
        expr = order_attrs.get("expression", "")
        # Clean expression: SUM([Salary]) → SUM(Salary)
        expr_clean = re.sub(r"\[([^\]]+)\]", r"\1", expr) if expr else ""
        return {"type": "top_n", "n": int(count) if count.isdigit() else count,
                "direction": direction, "order_by": expr_clean}

    if func == "union":
        # Manual member inclusion
        members = []
        children = gf.get("groupfilter", [])
        if isinstance(children, dict):
            children = [children]
        for child in children:
            if isinstance(child, dict):
                ca = child.get("@attributes", {})
                member = ca.get("member", "").strip('"')
                # Clean up the fully-qualified member name
                p = _parse_field_ref(member, calc_name_map)
                members.append(_clean_field_name(p["field"], calc_name_map) if p else _clean_field_name(member, calc_name_map))
        return {"type": "include_members", "members": members}

    if func == "member":
        member = attrs.get("member", "").strip('"')
        # Resolve internal name if it's a Calculation_ ID
        resolved = _clean_field_name(member, calc_name_map) if calc_name_map else member
        return {"type": "equals", "value": resolved}

    if func == "level-members":
        return {"type": "all_members"}

    return {}


# ---------------------------------------------------------------------------
# Encoding extraction
# ---------------------------------------------------------------------------

def _extract_encodings(pane: dict, calc_name_map: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """Extract encoding info (color, size, text, tooltip, label, detail, etc.) from a pane.

    Now preserves field aggregation for each encoding channel.
    """
    enc_node = pane.get("encodings", {})
    if not isinstance(enc_node, dict):
        return {}

    result: Dict[str, Any] = {}
    for key in ("color", "size", "text", "tooltip", "lod", "wedge-size", "label", "detail", "shape", "path"):
        val = enc_node.get(key)
        if val is None:
            continue
        if isinstance(val, dict):
            val = [val]
        if isinstance(val, list):
            fields = []
            for item in val:
                if isinstance(item, dict):
                    col = item.get("@attributes", {}).get("column", "") or item.get("column", "")
                    if col:
                        p = _parse_field_ref(col, calc_name_map)
                        if p:
                            field_info = _clean_field_name(p["field"], calc_name_map)
                            agg = p.get("aggregation")
                            if agg:
                                fields.append({"field": field_info, "aggregation": agg})
                            else:
                                fields.append(field_info)
                        else:
                            fields.append(_clean_field_name(col, calc_name_map))
            if fields:
                canonical = key.replace("-", "_")
                result[canonical] = fields if len(fields) > 1 else fields[0]

    return result


# ---------------------------------------------------------------------------
# Reference lines / bands / trend lines extraction
# ---------------------------------------------------------------------------

def _extract_reference_lines(view: dict, calc_name_map: Optional[Dict[str, str]] = None) -> List[Dict[str, Any]]:
    """Extract reference lines, bands, and trend lines from a worksheet view."""
    ref_lines: List[Dict[str, Any]] = []

    # Reference lines live under view > style > style-rule or under view > reference-line
    for key in ("reference-line", "reference-lines"):
        node = view.get(key, {})
        items = node if isinstance(node, list) else [node] if isinstance(node, dict) else []
        for item in items:
            if not isinstance(item, dict):
                continue
            attrs = item.get("@attributes", {})
            rl: Dict[str, Any] = {}
            scope = attrs.get("scope", "")
            if scope:
                rl["scope"] = scope
            value = attrs.get("value", "")
            if value:
                rl["value"] = value
            label = attrs.get("label", "")
            if label:
                rl["label"] = label
            line_type = attrs.get("type", "")
            if line_type:
                rl["type"] = line_type
            if rl:
                ref_lines.append(rl)

    # Trend lines
    for key in ("trend-line", "trend-lines"):
        node = view.get(key, {})
        items = node if isinstance(node, list) else [node] if isinstance(node, dict) else []
        for item in items:
            if not isinstance(item, dict):
                continue
            attrs = item.get("@attributes", {})
            tl: Dict[str, Any] = {"type": "trend_line"}
            model = attrs.get("regression-type", attrs.get("type", ""))
            if model:
                tl["model"] = model
            if tl:
                ref_lines.append(tl)

    return ref_lines


# ---------------------------------------------------------------------------
# Sort extraction
# ---------------------------------------------------------------------------

def _extract_sorts(view: dict, calc_name_map: Optional[Dict[str, str]] = None) -> List[Dict[str, Any]]:
    """Extract shelf-sort definitions."""
    sorts_node = view.get("shelf-sorts", {})
    if not isinstance(sorts_node, dict):
        return []

    items = sorts_node.get("shelf-sort-v2", [])
    if isinstance(items, dict):
        items = [items]
    if not isinstance(items, list):
        return []

    sorts = []
    for item in items:
        if not isinstance(item, dict):
            continue
        attrs = item.get("@attributes", {})
        dim_ref = attrs.get("dimension-to-sort", "")
        meas_ref = attrs.get("measure-to-sort-by", "")
        direction = attrs.get("direction", "ASC")
        shelf = attrs.get("shelf", "")

        dim_parsed = _parse_field_ref(dim_ref, calc_name_map)
        meas_parsed = _parse_field_ref(meas_ref, calc_name_map)

        sorts.append({
            "field": _clean_field_name(dim_parsed["field"], calc_name_map) if dim_parsed else _clean_field_name(dim_ref, calc_name_map),
            "direction": direction,
            "order_by": _clean_field_name(meas_parsed["field"], calc_name_map) if meas_parsed else _clean_field_name(meas_ref, calc_name_map),
            "shelf": shelf,
        })
    return sorts


# ---------------------------------------------------------------------------
# Action extraction
# ---------------------------------------------------------------------------

def _extract_actions(content: dict) -> List[Dict[str, Any]]:
    """Extract dashboard actions (cross-filter, highlight, URL)."""
    actions_node = content.get("actions", {})
    if not isinstance(actions_node, dict):
        return []
    items = actions_node.get("action", [])
    if isinstance(items, dict):
        items = [items]
    if not isinstance(items, list):
        return []

    results = []
    for act in items:
        if not isinstance(act, dict):
            continue
        attrs = act.get("@attributes", {})
        caption = attrs.get("caption", "")

        activation = act.get("activation", {})
        act_type = activation.get("@attributes", {}).get("type", "") if isinstance(activation, dict) else ""

        source = act.get("source", {})
        src_attrs = source.get("@attributes", {}) if isinstance(source, dict) else {}

        cmd = act.get("command", {})
        cmd_attrs = cmd.get("@attributes", {}) if isinstance(cmd, dict) else {}
        command_name = cmd_attrs.get("command", "")

        # Parse params
        params_raw = cmd.get("param", []) if isinstance(cmd, dict) else []
        if isinstance(params_raw, dict):
            params_raw = [params_raw]

        exclude_sheets = []
        target = ""
        for p in params_raw:
            if not isinstance(p, dict):
                continue
            pa = p.get("@attributes", {})
            if pa.get("name") == "exclude":
                exclude_sheets = [s.strip() for s in pa.get("value", "").split(",") if s.strip()]
            if pa.get("name") == "target":
                target = pa.get("value", "")

        action_info: Dict[str, Any] = {"caption": caption}
        if "filter" in command_name:
            action_info["type"] = "cross_filter"
        elif "highlight" in command_name:
            action_info["type"] = "highlight"
        else:
            action_info["type"] = command_name

        action_info["trigger"] = act_type
        action_info["source_sheet"] = src_attrs.get("worksheet", "")
        if target:
            action_info["target"] = target
        if exclude_sheets:
            action_info["excluded_sheets"] = exclude_sheets

        results.append(action_info)

    return results


# ---------------------------------------------------------------------------
# Column metadata extraction
# ---------------------------------------------------------------------------

def _extract_column_metadata(ds: dict, calc_name_map: Optional[Dict[str, str]] = None) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Extract clean column and measure definitions from a datasource.

    Returns (columns, measures).
    """
    columns: List[Dict[str, Any]] = []
    measures: List[Dict[str, Any]] = []

    # Physical columns from metadata-records
    connection = ds.get("connection", {})
    if isinstance(connection, dict):
        meta_recs = connection.get("metadata-records", {})
        if isinstance(meta_recs, dict):
            records = meta_recs.get("metadata-record", [])
            if isinstance(records, dict):
                records = [records]

            for rec in records:
                if not isinstance(rec, dict):
                    continue
                cls = rec.get("@attributes", {}).get("class", "")
                if cls != "column":
                    continue
                col_name = rec.get("remote-name", "")
                col_type_raw = rec.get("local-type", "string")
                agg = rec.get("aggregation", "")
                parent_name = rec.get("parent-name", "")
                contains_null = rec.get("contains-null", "")

                dtype = {
                    "string": "string",
                    "integer": "int64",
                    "real": "double",
                    "date": "dateTime",
                    "datetime": "dateTime",
                    "boolean": "boolean",
                }.get(col_type_raw, "string")

                col_info: Dict[str, Any] = {
                    "name": col_name,
                    "data_type": dtype,
                }
                if agg and agg != "Count":
                    col_info["default_aggregation"] = agg
                if contains_null == "true":
                    col_info["nullable"] = True
                if parent_name:
                    # Clean bracket-quoted parent name like [Table]
                    col_info["source_table"] = parent_name.strip("[]")
                columns.append(col_info)

    # Build a set of physical column names (lower) for distinguishing calc fields
    physical_names_lower = {c["name"].lower() for c in columns}

    # Column-level overrides: role, format, caption from <column> elements
    ds_columns = ds.get("column", [])
    if isinstance(ds_columns, dict):
        ds_columns = [ds_columns]

    for col in ds_columns:
        if not isinstance(col, dict):
            continue
        attrs = col.get("@attributes", {})
        name = attrs.get("caption", "") or attrs.get("name", "")
        name = name.strip("[]")
        internal_name = attrs.get("name", "").strip("[]")
        role = attrs.get("role", "")          # "dimension" or "measure"
        role_type = attrs.get("type", "")      # "nominal", "ordinal", "quantitative"
        datatype = attrs.get("datatype", "")
        default_format = attrs.get("default-format", "")
        semantic_role = attrs.get("semantic-role", "")   # e.g. "[Country].[ISO3166_2]"

        calc = col.get("calculation", {})
        if not isinstance(calc, dict):
            calc = {}

        calc_attrs = calc.get("@attributes", {}) if isinstance(calc, dict) else {}
        formula = calc_attrs.get("formula", "")
        calc_class = calc_attrs.get("class", "")

        # --- Distinguish: physical column override vs calculated field ---
        has_formula = bool(formula)
        is_bin = calc_class == "bin"
        is_calc = has_formula or is_bin

        if is_calc:
            measure_info: Dict[str, Any] = {"name": name}
            if formula:
                measure_info["formula"] = formula
            if is_bin:
                measure_info["type"] = "bin"
                measure_info["bin_size"] = calc_attrs.get("size", "")
                measure_info["source_field"] = formula
                # NEW: Bins should be calculated columns in Power BI, not measures
                measure_info["should_be_column"] = True
                measure_info["conversion_hint"] = (
                    "BIN FIELD: In Tableau, this bins a continuous field into discrete ranges. "
                    "In Power BI, create a Calculated Column that uses INT() and multiplication to create bins. "
                    f"Example: INT([Age]/{measure_info['bin_size']}) * {measure_info['bin_size']} to create {measure_info['bin_size']}-unit bins."
                )
            else:
                measure_info["type"] = "calculated_field"
                # Flag LOD expressions
                if formula and any(kw in formula.upper() for kw in ["{FIXED", "{INCLUDE", "{EXCLUDE"]):
                    measure_info["is_lod"] = True
                # Flag table calculations
                if formula and any(kw in formula.upper() for kw in ["RUNNING_", "WINDOW_", "LOOKUP(", "INDEX(", "FIRST(", "LAST(", "SIZE(", "RANK("]):
                    measure_info["is_table_calc"] = True
                # NEW: Analyze formula safety for Power BI conversion
                if formula:
                    analysis = _analyze_formula_safety(formula, calc_name_map)
                    if analysis.get("dimension_only"):
                        measure_info["is_dimension_only"] = True
                        measure_info["needs_aggregation_wrap"] = True
                        measure_info["conversion_hint"] = analysis["conversion_hint"]
                    if analysis.get("column_formula_likely"):
                        measure_info["should_be_column"] = True
                        measure_info["conversion_hint"] = (
                            "STRING MANIPULATION: This formula should likely be a Calculated Column in Power BI, "
                            "not a measure. Move it to the column definition section."
                        )
            if role:
                measure_info["role"] = role
            measures.append(measure_info)
        else:
            # This is a column override (role, format, etc.)
            # Try to find matching physical column and enrich it
            matched = False
            for pc in columns:
                if pc["name"].lower() == internal_name.lower() or pc["name"].lower() == name.lower():
                    if role:
                        pc["role"] = role
                    if role_type:
                        pc["role_type"] = role_type
                    if default_format:
                        pc["format"] = default_format
                    if name and name != pc["name"]:
                        pc["display_name"] = name
                    if semantic_role:
                        pc["semantic_role"] = semantic_role
                    if datatype:
                        dtype_map = {"string": "string", "integer": "int64", "real": "double",
                                     "date": "dateTime", "datetime": "dateTime", "boolean": "boolean"}
                        if datatype in dtype_map:
                            pc["data_type"] = dtype_map[datatype]
                    matched = True
                    break
            # If no physical match and it's a meaningful column with role info, add it
            if not matched and name and internal_name.lower() not in physical_names_lower:
                extra: Dict[str, Any] = {"name": name}
                if role:
                    extra["role"] = role
                if role_type:
                    extra["role_type"] = role_type
                if default_format:
                    extra["format"] = default_format
                if datatype:
                    dtype_map2 = {"string": "string", "integer": "int64", "real": "double",
                                  "date": "dateTime", "datetime": "dateTime", "boolean": "boolean"}
                    extra["data_type"] = dtype_map2.get(datatype, "string")
                else:
                    extra["data_type"] = "string"
                columns.append(extra)

    return columns, measures


# ---------------------------------------------------------------------------
# Formula analysis for Power BI conversion hints
# ---------------------------------------------------------------------------

def _analyze_formula_safety(formula: str, calc_name_map: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """Analyze a Tableau formula to detect conversion issues for Power BI.
    
    Returns a dict with flags like:
    - needs_column_form: bool - should be a calculated column, not measure
    - dimension_only: bool - references only dimension columns (no aggregations)
    - string_functions: list - string functions like LEFT, RIGHT, UPPER, etc.
    - uses_aggregation: bool - has COUNT, SUM, AVG, MIN, MAX, etc.
    - conversion_hint: str - human-readable hint for LLM
    """
    if not formula:
        return {"dimension_only": False, "uses_aggregation": False}
    
    result: Dict[str, Any] = {
        "dimension_only": False,
        "uses_aggregation": False,
        "string_functions": [],
        "date_functions": [],
        "conversion_hint": None,
    }
    
    formula_upper = formula.upper()
    
    # Detect string manipulation functions
    string_funcs = ["LEFT", "RIGHT", "MID", "UPPER", "LOWER", "LEN", "TRIM", 
                    "LTRIM", "RTRIM", "FIND", "CONTAINS", "STARTSWITH", "ENDSWITH",
                    "REPLACE", "CONCAT", "CONCATENATE"]
    for func in string_funcs:
        if func + "(" in formula_upper:
            result["string_functions"].append(func)
    
    # Detect date functions
    date_funcs = ["YEAR", "MONTH", "DAY", "HOUR", "MINUTE", "SECOND",
                  "DATENAME", "DATEPART", "DATE", "DATEADD", "DATEDIFF",
                  "TODAY", "NOW"]
    for func in date_funcs:
        if func + "(" in formula_upper:
            result["date_functions"].append(func)
    
    # Detect aggregation functions
    agg_funcs = ["SUM", "COUNT", "AVG", "MIN", "MAX", "STDEV", "VAR",
                 "RUNNING_", "WINDOW_", "LOOKUP", "INDEX", "FIRST", "LAST",
                 "RANK", "PERCENTILE", "MEDIAN", "MODE"]
    for func in agg_funcs:
        if func + "(" in formula_upper or func + "_" in formula_upper:
            result["uses_aggregation"] = True
            break
    
    # If has string/date functions but NO aggregation, it's dimension-only
    if (result["string_functions"] or result["date_functions"]) and not result["uses_aggregation"]:
        result["dimension_only"] = True
        result["conversion_hint"] = (
            "STRING/DATE MANIPULATION ON DIMENSION: This formula manipulates a dimension string/date "
            "without aggregation. In Power BI, use either: (1) a Calculated Column if referencing a table column directly, "
            "or (2) wrap dimension references with aggregation like MIN([Name]) for measure context. "
            f"Example: {', '.join(result['string_functions'] + result['date_functions'])}(...)"
        )
    
    # If purely string manipulation, it's likely a column formula
    if result["string_functions"] and not result["uses_aggregation"]:
        result["column_formula_likely"] = True
    
    return result


# ---------------------------------------------------------------------------
# Column extraction
# ---------------------------------------------------------------------------

def _extract_parameters(datasource_items: list) -> List[Dict[str, Any]]:
    """Extract Tableau parameters from the special 'Parameters' datasource."""
    params: List[Dict[str, Any]] = []
    for ds in datasource_items:
        if not isinstance(ds, dict):
            continue
        attrs = ds.get("@attributes", {})
        ds_name = attrs.get("name", "")
        if ds_name != "Parameters":
            continue

        cols = ds.get("column", [])
        if isinstance(cols, dict):
            cols = [cols]

        for col in cols:
            if not isinstance(col, dict):
                continue
            col_attrs = col.get("@attributes", {})
            param_name = col_attrs.get("caption", col_attrs.get("name", "")).strip("[]")
            param_type = col_attrs.get("datatype", "string")
            param_role = col_attrs.get("role", "")
            param_value = col_attrs.get("value", "")

            param_info: Dict[str, Any] = {"name": param_name, "datatype": param_type}
            if param_value:
                param_info["current_value"] = param_value

            # Extract allowable values from <range> or <members>
            calc = col.get("calculation", {})
            if isinstance(calc, dict):
                calc_attrs_p = calc.get("@attributes", {})
                formula = calc_attrs_p.get("formula", "")
                if formula:
                    param_info["formula"] = formula

            # Check for range element
            range_elem = col.get("range", {})
            if isinstance(range_elem, dict):
                ra = range_elem.get("@attributes", {})
                if ra.get("min") or ra.get("max"):
                    param_info["range"] = {
                        "min": ra.get("min", ""),
                        "max": ra.get("max", ""),
                        "granularity": ra.get("granularity", ""),
                    }

            # Check for members (list of values)
            members_elem = col.get("members", {})
            if isinstance(members_elem, dict):
                member_list = members_elem.get("member", [])
                if isinstance(member_list, dict):
                    member_list = [member_list]
                if isinstance(member_list, list):
                    vals = []
                    for mem in member_list:
                        if isinstance(mem, dict):
                            vals.append(mem.get("@attributes", {}).get("value", ""))
                        elif isinstance(mem, str):
                            vals.append(mem)
                    if vals:
                        param_info["allowed_values"] = vals

            if param_name:
                params.append(param_info)

    return params


# ---------------------------------------------------------------------------
# Sets & Groups extraction
# ---------------------------------------------------------------------------

def _extract_sets_and_groups(ds: dict, calc_name_map: Optional[Dict[str, str]] = None) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Extract set and group definitions from a datasource."""
    sets: List[Dict[str, Any]] = []
    groups: List[Dict[str, Any]] = []

    ds_columns = ds.get("column", [])
    if isinstance(ds_columns, dict):
        ds_columns = [ds_columns]

    for col in ds_columns:
        if not isinstance(col, dict):
            continue
        attrs = col.get("@attributes", {})
        name = attrs.get("caption", attrs.get("name", "")).strip("[]")

        # Groups have <group> child element
        group_elem = col.get("group", {})
        if isinstance(group_elem, dict) and group_elem:
            group_info: Dict[str, Any] = {"name": name}
            groupfilter = group_elem.get("groupfilter", [])
            if isinstance(groupfilter, dict):
                groupfilter = [groupfilter]
            members_map: Dict[str, List[str]] = {}
            for gf in groupfilter:
                if not isinstance(gf, dict):
                    continue
                gf_attrs = gf.get("@attributes", {})
                gf_func = gf_attrs.get("function", "")
                gf_level = gf_attrs.get("level", "")
                # Members
                if gf_func == "union":
                    children = gf.get("groupfilter", [])
                    if isinstance(children, dict):
                        children = [children]
                    for child in children:
                        if isinstance(child, dict):
                            ca = child.get("@attributes", {})
                            members_map.setdefault(gf_level, []).append(
                                ca.get("member", "").strip('"'))
            if members_map:
                group_info["bins"] = members_map
            groups.append(group_info)
            continue

        # Sets have role="set" attribute
        if attrs.get("role", "") == "set":
            set_info: Dict[str, Any] = {"name": name}
            calc_elem = col.get("calculation", {})
            if isinstance(calc_elem, dict):
                ca = calc_elem.get("@attributes", {})
                formula = ca.get("formula", "")
                if formula:
                    set_info["formula"] = formula
            sets.append(set_info)

    return sets, groups


# ---------------------------------------------------------------------------
# Hierarchy extraction
# ---------------------------------------------------------------------------

def _extract_hierarchies(ds: dict, calc_name_map: Optional[Dict[str, str]] = None) -> List[Dict[str, Any]]:
    """Extract drill-down hierarchies from a datasource."""
    hierarchies: List[Dict[str, Any]] = []

    drill_paths = ds.get("drill-paths", {})
    if not isinstance(drill_paths, dict):
        return hierarchies

    paths = drill_paths.get("drill-path", [])
    if isinstance(paths, dict):
        paths = [paths]

    for path in paths:
        if not isinstance(path, dict):
            continue
        path_attrs = path.get("@attributes", {})
        h_name = path_attrs.get("name", "")

        fields = path.get("field", [])
        if isinstance(fields, str):
            fields = [fields]
        elif isinstance(fields, dict):
            fields = [fields]

        field_names = []
        for f in fields:
            if isinstance(f, str):
                parsed = _parse_field_ref(f, calc_name_map)
                field_names.append(parsed["field"] if parsed else f.strip("[]"))
            elif isinstance(f, dict):
                field_names.append(f.get("#text", f.get("@attributes", {}).get("name", "")))

        if h_name and field_names:
            hierarchies.append({"name": h_name, "levels": field_names})

    return hierarchies


# ---------------------------------------------------------------------------
# Relationship extraction
# ---------------------------------------------------------------------------

def _extract_relationships(ds: dict) -> List[Dict[str, Any]]:
    """Extract join relationships from a datasource's connection, including join columns."""
    connection = ds.get("connection", {})
    if not isinstance(connection, dict):
        return []

    relations = connection.get("relation", [])
    if isinstance(relations, dict):
        relations = [relations]

    rels = []

    def _parse_relation(rel: dict, depth: int = 0):
        """Recursively parse join relations, extracting join columns."""
        if not isinstance(rel, dict):
            return
        attrs = rel.get("@attributes", {})
        if attrs.get("type") != "join":
            return

        join_type = attrs.get("join", "inner")

        # Parse clause(s) for join column pairs
        join_columns: List[Dict[str, str]] = []
        clauses = rel.get("clause", [])
        if isinstance(clauses, dict):
            clauses = [clauses]
        for clause in clauses:
            if not isinstance(clause, dict):
                continue
            clause_type = clause.get("@attributes", {}).get("type", "")
            expr = clause.get("expression", {})
            if isinstance(expr, dict):
                sub_exprs = expr.get("expression", [])
                if isinstance(sub_exprs, list) and len(sub_exprs) >= 2:
                    left_col_attr = sub_exprs[0].get("@attributes", {}) if isinstance(sub_exprs[0], dict) else {}
                    right_col_attr = sub_exprs[1].get("@attributes", {}) if isinstance(sub_exprs[1], dict) else {}
                    join_columns.append({
                        "left_column": left_col_attr.get("name", ""),
                        "right_column": right_col_attr.get("name", ""),
                    })

        # Extract table names from nested relations
        nested = rel.get("relation", [])
        if isinstance(nested, dict):
            nested = [nested]
        tables = []
        for nr in nested:
            if isinstance(nr, dict):
                nr_attrs = nr.get("@attributes", {})
                t = nr_attrs.get("name", "")
                if t:
                    tables.append(t)
                # Recurse for multi-level joins
                if nr_attrs.get("type") == "join":
                    _parse_relation(nr, depth + 1)

        left_table = tables[0] if len(tables) > 0 else ""
        right_table = tables[1] if len(tables) > 1 else ""

        if left_table or right_table:
            rel_info: Dict[str, Any] = {
                "join_type": join_type,
                "left_table": left_table,
                "right_table": right_table,
            }
            if join_columns:
                rel_info["join_columns"] = join_columns
            rels.append(rel_info)

    for rel in relations:
        _parse_relation(rel)

    return rels


# ---------------------------------------------------------------------------
# Dashboard zone extraction
# ---------------------------------------------------------------------------

def _extract_dashboard_layout(db: dict) -> Dict[str, Any]:
    """Extract compact dashboard layout information including zone positions."""
    size_node = db.get("size", {})
    size = {}
    if isinstance(size_node, dict):
        sa = size_node.get("@attributes", {})
        w = sa.get("maxwidth", sa.get("minwidth", ""))
        h = sa.get("maxheight", sa.get("minheight", ""))
        if w and h:
            size = {"width": int(w), "height": int(h)}

    zones_node = db.get("zones", {})
    zone_items = zones_node.get("zone", []) if isinstance(zones_node, dict) else []
    if isinstance(zone_items, dict):
        zone_items = [zone_items]

    tiles: List[Dict[str, Any]] = []
    filter_zones: List[Dict[str, Any]] = []

    def _collect_zones(zone_list):
        for z in zone_list:
            if not isinstance(z, dict):
                continue
            za = z.get("@attributes", {})
            name = za.get("name", "")
            type_v2 = za.get("type-v2", "")
            param = za.get("param", "")

            # Extract position if available
            pos = {}
            for dim_key in ("x", "y", "w", "h"):
                val = za.get(dim_key, "")
                if val:
                    try:
                        pos[dim_key] = int(val)
                    except ValueError:
                        pass

            if name and not type_v2:
                # Worksheet zone
                tile: Dict[str, Any] = {"type": "worksheet", "name": name}
                if pos:
                    tile["position"] = pos
                tiles.append(tile)
            elif type_v2 == "text":
                text = ""
                ft = z.get("formatted-text", {})
                if isinstance(ft, dict):
                    text = ft.get("run", "")
                if text:
                    tile_t: Dict[str, Any] = {"type": "text", "content": text}
                    if pos:
                        tile_t["position"] = pos
                    tiles.append(tile_t)
            elif type_v2 == "filter":
                # Filter zone (quick filter / slicer)
                fz: Dict[str, Any] = {"type": "filter"}
                if param:
                    fz["parameter"] = param
                if name:
                    fz["source_worksheet"] = name
                if pos:
                    fz["position"] = pos
                filter_zones.append(fz)
            elif type_v2 == "paramctrl":
                # Parameter control zone
                fz2: Dict[str, Any] = {"type": "parameter_control"}
                if param:
                    fz2["parameter"] = param
                if pos:
                    fz2["position"] = pos
                filter_zones.append(fz2)
            # Skip color legends, bitmaps, layout containers

            # Recurse
            nested = z.get("zone", [])
            if isinstance(nested, dict):
                nested = [nested]
            if isinstance(nested, list):
                _collect_zones(nested)

    _collect_zones(zone_items)
    result: Dict[str, Any] = {"size": size, "tiles": tiles}
    if filter_zones:
        result["filter_zones"] = filter_zones
    return result


# ---------------------------------------------------------------------------
# Main builder
# ---------------------------------------------------------------------------

def build_compact_spec(raw_content: dict) -> Dict[str, Any]:
    """Transform raw Tableau XML-to-dict into a compact LLM-friendly spec.

    Args:
        raw_content: The full twb_content dict (with "root_tag", "content", "filename").

    Returns:
        Compact spec with model_spec and visual_spec sections.
    """
    content = raw_content.get("content", {})
    if not isinstance(content, dict):
        return {"error": "No content found in Tableau workbook"}

    # ── A. Model Spec ──────────────────────────────────────────────────
    datasource_items = _as_list(content, "datasources", "datasource")

    all_columns: Dict[str, List[Dict[str, Any]]] = {}  # per-datasource columns
    all_measures: List[Dict[str, Any]] = []
    all_relationships: List[Dict[str, Any]] = []
    all_sets: List[Dict[str, Any]] = []
    all_groups: List[Dict[str, Any]] = []
    all_hierarchies: List[Dict[str, Any]] = []
    tables_info: List[Dict[str, Any]] = []

    # Datasource name → caption map (for resolving references)
    ds_caption_map: Dict[str, str] = {}
    # Internal Calculation_XXXX name → user caption map
    calc_name_map: Dict[str, str] = {}

    # Extract parameters from the special Parameters datasource
    parameters = _extract_parameters(datasource_items)

    for ds in datasource_items:
        if not isinstance(ds, dict):
            continue
        attrs = ds.get("@attributes", {})
        ds_name = attrs.get("name", "")
        ds_caption = attrs.get("caption", ds_name)
        ds_caption_map[ds_name] = ds_caption

        # Skip the special "Parameters" datasource (already extracted above)
        if ds_name == "Parameters":
            continue

        # Build calc_name_map from datasource <column> elements
        ds_columns_raw = ds.get("column", [])
        if isinstance(ds_columns_raw, dict):
            ds_columns_raw = [ds_columns_raw]
        for col_elem in ds_columns_raw:
            if not isinstance(col_elem, dict):
                continue
            col_attrs = col_elem.get("@attributes", {})
            internal_name = col_attrs.get("name", "").strip("[]")
            caption = col_attrs.get("caption", "")
            if internal_name and caption:
                calc_name_map[internal_name] = caption

        columns, measures = _extract_column_metadata(ds, calc_name_map)
        relationships = _extract_relationships(ds)
        sets, groups = _extract_sets_and_groups(ds, calc_name_map)
        hierarchies = _extract_hierarchies(ds, calc_name_map)

        # Get logical table names
        conn = ds.get("connection", {})
        relation = conn.get("relation", {}) if isinstance(conn, dict) else {}
        logical_tables = []
        if isinstance(relation, dict):
            t = relation.get("@attributes", {}).get("name", "")
            if t:
                logical_tables.append(t)
        elif isinstance(relation, list):
            for r in relation:
                if isinstance(r, dict):
                    t = r.get("@attributes", {}).get("name", "")
                    if t:
                        logical_tables.append(t)

        # Store columns per datasource (fix the old single-datasource overwrite bug)
        if columns:
            all_columns[ds_caption] = columns
        all_measures.extend(measures)
        all_relationships.extend(relationships)
        all_sets.extend(sets)
        all_groups.extend(groups)
        all_hierarchies.extend(hierarchies)

        ds_info: Dict[str, Any] = {
            "name": ds_caption,
            "logical_tables": logical_tables,
        }
        # Include connection type if available
        if isinstance(conn, dict):
            conn_attrs = conn.get("@attributes", {})
            conn_class = conn_attrs.get("class", "")
            if conn_class:
                ds_info["connection_type"] = conn_class
        tables_info.append(ds_info)

    # Flatten columns for backward compatibility (merge all datasource columns)
    flat_columns: List[Dict[str, Any]] = []
    for ds_name_key, cols in all_columns.items():
        for c in cols:
            # Tag each column with its datasource if multiple
            if len(all_columns) > 1:
                c_copy = dict(c)
                c_copy["datasource"] = ds_name_key
                flat_columns.append(c_copy)
            else:
                flat_columns.append(c)

    model_spec: Dict[str, Any] = {
        "data_sources": tables_info,
        "columns": flat_columns,
        "calculated_fields": all_measures,
        "relationships": all_relationships if all_relationships else None,
        "parameters": parameters if parameters else None,
        "sets": all_sets if all_sets else None,
        "groups": all_groups if all_groups else None,
        "hierarchies": all_hierarchies if all_hierarchies else None,
    }

    # ── B. Visual Spec ─────────────────────────────────────────────────
    worksheet_items = _as_list(content, "worksheets", "worksheet")
    dashboard_items = _as_list(content, "dashboards", "dashboard")

    # Build per-worksheet specs
    ws_specs: Dict[str, Dict[str, Any]] = {}

    for ws in worksheet_items:
        if not isinstance(ws, dict):
            continue
        ws_name = ws.get("@attributes", {}).get("name", "?")

        # Title
        title = ""
        lo = ws.get("layout-options", {})
        if isinstance(lo, dict):
            ft = lo.get("title", {})
            if isinstance(ft, dict):
                run = ft.get("formatted-text", {})
                if isinstance(run, dict):
                    run_val = run.get("run", "")
                    if isinstance(run_val, list):
                        # Multiple <run> elements — join text, strip Tableau Æ placeholder
                        title = " ".join(
                            r for r in run_val
                            if isinstance(r, str) and r.strip() and r != "\u00c6"
                        ).strip()
                    elif isinstance(run_val, str):
                        title = run_val.replace("\u00c6", "").strip()
                    # Handle Tableau <Sheet Name> placeholder
                    if title:
                        title = title.replace("<Sheet Name>", ws_name)

        # Table / Pane / View
        table = ws.get("table", {})
        if not isinstance(table, dict):
            ws_specs[ws_name] = {"title": title, "type": "unknown"}
            continue

        view = table.get("view", {}) if isinstance(table.get("view"), dict) else {}

        # Rows & Cols
        rows_raw = table.get("rows", "")
        cols_raw = table.get("cols", "")
        rows = _parse_shelf(rows_raw, calc_name_map)
        cols = _parse_shelf(cols_raw, calc_name_map)

        # Mark type from panes + detect dual-axis
        panes = table.get("panes", {})
        if isinstance(panes, dict):
            pane_list = panes.get("pane", [])
        else:
            pane_list = []
        if isinstance(pane_list, dict):
            pane_list = [pane_list]

        mark_class = "Automatic"
        mark_classes_found: List[str] = []
        encodings: Dict[str, Any] = {}
        for pane in pane_list:
            if not isinstance(pane, dict):
                continue
            mark = pane.get("mark", {})
            if isinstance(mark, dict):
                mc = mark.get("@attributes", {}).get("class", "")
                if mc:
                    mark_class = mc
                    mark_classes_found.append(mc)
            elif isinstance(mark, list):
                for m_item in mark:
                    if isinstance(m_item, dict):
                        mc = m_item.get("@attributes", {}).get("class", "")
                        if mc:
                            mark_class = mc
                            mark_classes_found.append(mc)
            enc = _extract_encodings(pane, calc_name_map)
            encodings.update(enc)

        # Detect dual-axis: multiple panes with different mark classes
        is_dual_axis = len(set(mark_classes_found)) > 1

        # Infer visual type
        visual_type = _infer_visual_type(mark_class, rows, cols, encodings)
        if is_dual_axis:
            visual_type = "dual_axis"

        # Filters
        filters = _extract_filters(view, calc_name_map)

        # Sorts
        sorts = _extract_sorts(view, calc_name_map)

        # Reference lines / trend lines
        ref_lines = _extract_reference_lines(view, calc_name_map)

        # Build query intent
        # Fields with date-part or bin aggregations are semantically dimensions
        # even though Tableau may mark them with qk (measure) role suffix.
        # Also treat fields with "(bin)" in their name as dimensions (bin
        # calculations referenced by calc ID get aggregation=None, role=measure).
        _DIMENSION_AGGREGATIONS = {"BIN", "YEAR", "MONTH", "QUARTER", "DAY"}
        def _is_dimension(f):
            if f.get("special"):
                return False
            if f.get("role") == "dimension":
                return True
            if f.get("aggregation") in _DIMENSION_AGGREGATIONS:
                return True
            if "(bin)" in f.get("field", "").lower():
                return True
            return False

        dimensions = [f for f in (rows + cols) if _is_dimension(f)]
        measures_used = [
            f for f in (rows + cols)
            if f.get("role") == "measure"
            and f.get("aggregation") not in _DIMENSION_AGGREGATIONS
            and "(bin)" not in f.get("field", "").lower()
        ]

        query_intent: Dict[str, Any] = {}
        if dimensions:
            query_intent["dimensions"] = [
                d["field"] for d in dimensions
            ]
        if measures_used:
            query_intent["measures"] = [
                {"field": m["field"], "aggregation": m.get("aggregation", "SUM")}
                for m in measures_used
            ]

        # Fallback: if no rows/cols dimensions/measures, derive from encodings
        # (common for pie charts where all data lives in color/size/wedge_size)
        if not dimensions and not measures_used and encodings:
            enc_dims = []
            enc_meas = []
            for enc_key in ("color", "text", "tooltip", "label", "detail"):
                enc_val = encodings.get(enc_key)
                if enc_val:
                    items = enc_val if isinstance(enc_val, list) else [enc_val]
                    for item in items:
                        fname = item.get("field", item) if isinstance(item, dict) else item
                        if isinstance(fname, str):
                            enc_dims.append(fname)
            for enc_key in ("size", "wedge_size"):
                enc_val = encodings.get(enc_key)
                if enc_val:
                    items = enc_val if isinstance(enc_val, list) else [enc_val]
                    for item in items:
                        fname = item.get("field", item) if isinstance(item, dict) else item
                        if isinstance(fname, str):
                            enc_meas.append(fname)
            # Deduplicate and avoid adding Record Count as dimension
            if enc_dims:
                query_intent["dimensions"] = list(dict.fromkeys(
                    d for d in enc_dims if d != "Record Count"
                ))
            if enc_meas:
                query_intent["measures"] = [
                    {"field": m, "aggregation": "COUNT" if m == "Record Count" else "SUM"}
                    for m in dict.fromkeys(enc_meas)
                ]

        if filters:
            query_intent["filters"] = filters
        if sorts:
            query_intent["sorts"] = sorts

        tile: Dict[str, Any] = {
            "title": title or ws_name,
            "type": visual_type,
            "query": query_intent,
        }
        if encodings:
            tile["encodings"] = encodings
        if is_dual_axis:
            tile["dual_axis"] = True
            tile["mark_types"] = list(set(mark_classes_found))
        if ref_lines:
            tile["reference_lines"] = ref_lines

        ws_specs[ws_name] = tile

    # Build pages (dashboards + orphan worksheets)
    pages: List[Dict[str, Any]] = []
    dashboard_ws_names: set = set()

    # Actions
    actions = _extract_actions(content)

    for db in dashboard_items:
        if not isinstance(db, dict):
            continue
        db_name = db.get("@attributes", {}).get("name", "Dashboard")

        layout = _extract_dashboard_layout(db)
        ws_tiles = []
        for lt_tile in layout.get("tiles", []):
            if lt_tile.get("type") == "worksheet":
                name = lt_tile["name"]
                dashboard_ws_names.add(name)
                ws_tile = dict(ws_specs.get(name, {"title": name, "type": "unknown"}))
                # Carry zone position into the tile
                if lt_tile.get("position"):
                    ws_tile["zone_position"] = lt_tile["position"]
                ws_tiles.append(ws_tile)

        page: Dict[str, Any] = {
            "page_name": db_name,
            "size": layout.get("size"),
            "tiles": ws_tiles,
        }
        if actions:
            page["interactions"] = actions
        filter_zones = layout.get("filter_zones", [])
        if filter_zones:
            page["filter_zones"] = filter_zones
        pages.append(page)

    # Orphan worksheets (not on any dashboard)
    for ws_name, ws_tile in ws_specs.items():
        if ws_name not in dashboard_ws_names:
            pages.append({
                "page_name": ws_name,
                "tiles": [ws_tile],
            })

    visual_spec = {"pages": pages}

    # ── Assemble ───────────────────────────────────────────────────────
    # Remove None values for compactness
    model_spec = {k: v for k, v in model_spec.items() if v is not None}

    return {
        "model_spec": model_spec,
        "visual_spec": visual_spec,
    }


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def _as_list(parent: dict, container_key: str, child_key: str) -> list:
    """Navigate XML nesting: parent[container_key][child_key] → list."""
    container = parent.get(container_key, {})
    if isinstance(container, list):
        return container
    if isinstance(container, dict):
        children = container.get(child_key, [])
        if isinstance(children, list):
            return children
        if isinstance(children, dict):
            return [children]
        if child_key not in container and "@attributes" in container:
            return [container]
    return []


