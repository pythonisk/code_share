"""
File format converter for transforming various input files to JSON format.
Supports: CSV, XLSX, TXT, PDF, DOCX, and other common formats.
"""

import os
import pandas as pd
from typing import Dict, Any, List, Optional
import logging
from daan.utils.converters.base_converter import BaseFileConverter
from daan.utils.converters.csv_converter import CsvConverter
from daan.utils.converters.directory_converter import DirectoryConverter
from daan.utils.converters.docx_converter import DocxConverter
from daan.utils.converters.excel_converter import ExcelConverter
from daan.utils.converters.json_converter import JsonConverter
from daan.utils.converters.common_json_utils import final_json_cleanup, json_serializer
from daan.utils.converters.pbip_converter import PbipConverter
from daan.utils.converters.pbit_converter import PbitConverter
from daan.utils.converters.pbix_converter import PbixConverter
from daan.utils.converters.pdf_converter import PdfConverter
from daan.utils.converters.ppt_converter import PptConverter
from daan.utils.converters.tableau_converter import TableauConverter
from daan.utils.converters.text_converter import TextConverter
from daan.utils.converters.common_text_utils import convert_binary_file_as_text
from daan.utils.converters.xml_converter import XmlConverter
from daan.utils.converters.zip_converter import ZipConverter

# Configure logging
logger = logging.getLogger(__name__)


class FileToJsonConverter:
    """Converts various file formats to JSON format for consistent processing."""

    def __init__(self):
        self._converter_factories = self._build_converter_factories()
        self.supported_formats = dict(self._converter_factories)
        self._directory_converter = DirectoryConverter(
            convert_file_to_json=self.convert_file_to_json,
            supported_formats=self.supported_formats,
            json_serializer=lambda obj: json_serializer(obj, logger_=logger),
            logger_=logger,
        )

    def get_supported_file_types(self) -> List[str]:
        """
        Get list of supported file extensions.

        Returns:
            List of supported file extensions (including the dot)
        """
        return list(self.supported_formats.keys())

    def is_file_supported(self, file_path: str) -> bool:
        """
        Check if a file type is supported for conversion.

        Args:
            file_path: Path to the file to check

        Returns:
            True if file type is supported, False otherwise
        """
        file_ext = os.path.splitext(file_path)[1].lower()
        return file_ext in self.supported_formats

    def _build_converter_factories(self):
        return {
            '.csv': lambda: CsvConverter(logger_=logger),
            '.xlsx': lambda: ExcelConverter(logger_=logger),
            '.xls': lambda: ExcelConverter(logger_=logger),
            '.txt': lambda: TextConverter(logger_=logger),
            '.html': lambda: TextConverter(logger_=logger),
            '.htm': lambda: TextConverter(logger_=logger),
            '.ini': lambda: TextConverter(logger_=logger),
            '.json': lambda: JsonConverter(logger_=logger),
            '.log': lambda: TextConverter(logger_=logger),
            '.md': lambda: TextConverter(logger_=logger),
            '.properties': lambda: TextConverter(logger_=logger),
            '.py': lambda: TextConverter(logger_=logger),
            '.sql': lambda: TextConverter(logger_=logger),
            # Common source-code file types (read as plain text). Important for
            # zip archives of code (e.g. .cs files), which were previously skipped.
            '.cs': lambda: TextConverter(logger_=logger),
            '.java': lambda: TextConverter(logger_=logger),
            '.js': lambda: TextConverter(logger_=logger),
            '.ts': lambda: TextConverter(logger_=logger),
            '.jsx': lambda: TextConverter(logger_=logger),
            '.tsx': lambda: TextConverter(logger_=logger),
            '.go': lambda: TextConverter(logger_=logger),
            '.rb': lambda: TextConverter(logger_=logger),
            '.php': lambda: TextConverter(logger_=logger),
            '.c': lambda: TextConverter(logger_=logger),
            '.cpp': lambda: TextConverter(logger_=logger),
            '.h': lambda: TextConverter(logger_=logger),
            '.hpp': lambda: TextConverter(logger_=logger),
            '.cshtml': lambda: TextConverter(logger_=logger),
            '.yaml': lambda: TextConverter(logger_=logger),
            '.yml': lambda: TextConverter(logger_=logger),
            '.xml': lambda: XmlConverter(logger_=logger),
            '.docx': lambda: DocxConverter(logger_=logger),
            '.pdf': lambda: PdfConverter(logger_=logger),
            '.pptx': lambda: PptConverter(logger_=logger),
            '.ppt': lambda: PptConverter(logger_=logger),
            '.pbit': lambda: PbitConverter(),
            '.pbix': lambda: PbixConverter(),
            '.pbip': lambda: PbipConverter(),
            '.twbx': lambda: TableauConverter(),
            '.twb': lambda: TableauConverter(),
            '.zip': lambda: ZipConverter(),
        }

    def _create_converter(self, file_ext: str) -> BaseFileConverter:
        factory = self._converter_factories.get(file_ext)
        if not factory:
            raise ValueError(f"No converter registered for extension: {file_ext}")
        return factory()

    def convert_file_to_json(self, file_path: str) -> Dict[str, Any]:
        """
        Convert a file to JSON format based on its extension.

        Args:
            file_path: Path to the input file

        Returns:
            Dictionary containing file metadata and converted content
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        file_ext = os.path.splitext(file_path)[1].lower()
        filename = os.path.basename(file_path)

        if file_ext not in self.supported_formats:
            logger.warning(f"Unsupported file format: {file_ext}")
            return convert_binary_file_as_text(file_path, logger_=logger)

        try:
            converter = self._create_converter(file_ext)
            content = converter.convert(file_path)

            result = {
                "filename": filename,
                "file_type": file_ext,
                "file_path": file_path,
                "content": content,
                "metadata": {
                    "size_bytes": os.path.getsize(file_path),
                    "converted_at": pd.Timestamp.now().isoformat()
                }
            }

            return final_json_cleanup(result)
        except Exception as e:
            logger.error(f"Error converting file {file_path}: {str(e)}")
            return {
                "filename": filename,
                "file_type": file_ext,
                "file_path": file_path,
                "content": {"error": f"Failed to convert: {str(e)}"},
                "metadata": {"conversion_error": True}
            }

    def convert_directory_to_json(
        self,
        directory_path: str,
        output_file: Optional[str] = None,
        recursive: bool = False,
    ) -> Dict[str, Any]:
        return self._directory_converter.convert_directory_to_json(
            directory_path=directory_path,
            output_file=output_file,
            recursive=recursive,
        )


# Convenience functions
def get_supported_file_types() -> List[str]:
    """Get list of supported file extensions."""
    converter = FileToJsonConverter()
    return converter.get_supported_file_types()


def is_file_supported(file_path: str) -> bool:
    """Check if a file type is supported for conversion."""
    converter = FileToJsonConverter()
    return converter.is_file_supported(file_path)


def convert_file_to_json(file_path: str) -> Dict[str, Any]:
    """Convenience function to convert a single file to JSON."""
    converter = FileToJsonConverter()
    return converter.convert_file_to_json(file_path)


def convert_directory_to_json(
    directory_path: str,
    output_file: Optional[str] = None,
    recursive: bool = False,
) -> Dict[str, Any]:
    """Convenience function to convert all files in a directory to JSON."""
    converter = FileToJsonConverter()
    return converter.convert_directory_to_json(
        directory_path=directory_path,
        output_file=output_file,
        recursive=recursive,
    )


# Example usage
if __name__ == "__main__":
    converter = FileToJsonConverter()

    print("FileToJsonConverter with Enhanced Text Processing:")
    print("✓ Removes 'Unnamed' columns (Unnamed: 0, Unnamed: 1, etc.)")
    print("✓ Removes completely empty rows and columns")
    print("✓ Cleans NaN values and converts to empty strings")
    print("✓ Removes null string representations (nan, null, n/a, etc.)")
    print("✓ Strips whitespace from text values")
    print("✓ Provides cleaning summary in output")
    print("\n✓ NEW: Extracts structured sections from text files")
    print("  - Identifies headers/titles using various patterns:")
    print("    • Markdown headers (# Header)")
    print("    • Underlined headers (Header\\n=======)")
    print("    • Numbered sections (1. Section)")
    print("    • ALL CAPS headers")
    print("    • Title case headers")
    print("    • Bracketed headers [Header]")
    print("  - Maps headers to content sections")
    print("  - Creates paragraph-based sections as fallback")
    print("  - Supports keyword-based section extraction")
    print("\nExample JSON structure for text files:")
    print("""{
  \"type\": \"text_file\",
  \"structured_sections\": {
    \"Introduction\": {
      \"content\": \"This is the introduction paragraph...\",
      \"type\": \"section_content\",
      \"header_type\": \"markdown_header\"
    },
    \"Requirements\": {
      \"content\": \"These are the system requirements...\",
      \"type\": \"section_content\", 
      \"header_type\": \"caps_header\"
    }
  }
}""")
    print("\nReady for use!")
