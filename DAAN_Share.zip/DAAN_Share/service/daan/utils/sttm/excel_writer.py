from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

from .helpers import union_columns


def create_sttm_excel_flexible(
    metadata: dict[str, Any],
    mappings: list[dict[str, Any]],
    output_folder: str,
    file_name: str | None = None,
) -> str:
    output_dir = Path(output_folder)
    output_dir.mkdir(parents=True, exist_ok=True)
    if not file_name:
        file_name = f"sttm_output_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    output_path = output_dir / file_name

    meta_rows = [{"Field": key, "Value": value} for key, value in (metadata or {}).items()]
    meta_df = pd.DataFrame(meta_rows if meta_rows else [{"Field": "Info", "Value": "No metadata extracted"}])

    mapping_columns = union_columns(mappings)
    mapping_df = pd.DataFrame(mappings)
    if mapping_columns:
        for column in mapping_columns:
            if column not in mapping_df.columns:
                mapping_df[column] = None
        mapping_df = mapping_df[mapping_columns]

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        meta_df.to_excel(writer, sheet_name="source_target_database_details", index=False)
        mapping_df.to_excel(writer, sheet_name="source_to_target_mapping", index=False)

    return str(output_path)