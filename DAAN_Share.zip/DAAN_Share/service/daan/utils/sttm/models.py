from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from typing_extensions import TypedDict


class AidaSTTMState(TypedDict):
    file_paths: list[str]
    extracted_context: dict[str, str]
    rag_storage_status: bool
    metadata_info_raw: str
    mapping_info_raw: str
    sttm_path: str
    session_folder: str


@dataclass(frozen=True)
class Endpoint:
    instance: str
    field: str


@dataclass
class FieldDef:
    name: str
    dtype: str = ""
    length: str = ""
    pk: bool = False
    fk: bool = False
    default: Optional[str] = None
    description: str = ""
    expression: Optional[str] = None
    porttype: Optional[str] = None


@dataclass
class TransformationDef:
    name: str
    tf_type: str
    fields: dict[str, FieldDef] = field(default_factory=dict)
    attrs: dict[str, str] = field(default_factory=dict)


@dataclass
class SourceDef:
    name: str
    database_type: str = ""
    fields: dict[str, FieldDef] = field(default_factory=dict)


@dataclass
class TargetDef:
    name: str
    database_type: str = ""
    fields: dict[str, FieldDef] = field(default_factory=dict)


@dataclass
class ColumnLineage:
    source_table: str
    source_column: str
    source_dtype: str
    source_length: str
    source_pk: bool
    source_fk: bool
    source_desc: str
    target_table: str
    target_column: str
    target_dtype: str
    target_length: str
    target_pk: bool
    target_fk: bool
    target_desc: str
    mapping_type: str
    transformation_rule: str
    business_rule: str
    data_conversion_rule: str
    aggregation_logic: str
    lookup_table: Optional[str]
    data_enrichment_rule: str
    data_cleansing_rule: str
    data_standardization_rule: str
    data_masking_rule: str
    data_validation_rule: str
    error_handling_rule: str
    default_value_handling: str
    data_quality_checks: str
    data_profiling_results: str
    data_lineage: str
    pii_indicator: bool
    mask_sensitive_data: bool
    audit_trail: str
    sample_data: str
    column_description: str
    confidence: float = 1.0
    lineage_path: list[str] = field(default_factory=list)


@dataclass
class ParseResult:
    rows: list[dict[str, Any]]
    parser_name: str
    confidence: float
    coverage: float
    gaps: list[str] = field(default_factory=list)
    diagnostics: dict[str, Any] = field(default_factory=dict)