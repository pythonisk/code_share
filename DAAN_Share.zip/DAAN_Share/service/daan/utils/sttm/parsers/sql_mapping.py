from __future__ import annotations

import re
from typing import Optional

from ..helpers import (
    classify_mapping_type,
    dedupe_rows,
    infer_business_rule,
    normalize_expr,
    normalize_ws,
    unique_preserve,
    unique_preserve_pairs,
    validate_and_score_rows,
)
from ..models import ParseResult


class SqlMappingParser:
    name = "sql_mapping"

    def can_handle(self, _file_name: str, content: str) -> bool:
        upper = content.upper()
        return any(token in upper for token in ["INSERT INTO", "CREATE TABLE", "MERGE INTO", "SELECT", "WITH ", "PROCEDURE", "FUNCTION"])

    def parse(self, _file_name: str, content: str) -> ParseResult:
        try:
            import sqlglot  # noqa: F401
            return self._parse_with_sqlglot(content)
        except Exception:
            return self._parse_with_regex(content)

    def _parse_with_sqlglot(self, content: str) -> ParseResult:
        import sqlglot
        from sqlglot import exp

        rows: list[dict[str, object]] = []
        statements = sqlglot.parse(content)
        for stmt in statements:
            if isinstance(stmt, exp.Insert):
                target_table = stmt.this.sql() if stmt.this is not None else ""
                query = stmt.expression
                if isinstance(query, exp.Select):
                    rows.extend(self._rows_from_select(query, target_table))
            elif isinstance(stmt, exp.Create):
                target_table = stmt.this.sql() if stmt.this is not None else ""
                expr = stmt.expression
                if isinstance(expr, exp.Select):
                    rows.extend(self._rows_from_select(expr, target_table))
            elif isinstance(stmt, exp.Merge):
                target_table = stmt.this.sql() if stmt.this is not None else ""
                using_expr = stmt.args.get("using")
                source_table = using_expr.sql() if using_expr else ""
                using_sql = using_expr.sql() if using_expr else ""
                from_tables = self._extract_from_tables("FROM " + using_sql) if using_sql else []
                if not from_tables and source_table:
                    from_tables = [source_table.split()[-1]]
                default_source = from_tables[0] if from_tables else source_table
                for when_expr in stmt.args.get("expressions", []):
                    when_sql = when_expr.sql()
                    for match in re.finditer(r"(\w+)\s*=\s*([^,]+)", re.sub(r"(?i)^.*?SET\s+", "", when_sql)):
                        target_col = match.group(1).strip()
                        source_expr = match.group(2).strip()
                        source_cols = self._extract_source_columns_from_expr(source_expr)
                        transformation_rule = normalize_expr(source_expr)
                        mapping_type = classify_mapping_type(transformation_rule, [(default_source, col[1]) for col in source_cols if col[1]], None)
                        business_rule = infer_business_rule(mapping_type, transformation_rule, target_col)
                        for source_table_name, source_col in source_cols or [("", "")]:
                            rows.append({
                                "Source Table Name": source_table_name or default_source,
                                "Source Attribute Name": source_col,
                                "Target Table Name": target_table,
                                "Target Attribute Name": target_col,
                                "Mapping Type": mapping_type,
                                "Transformation Rule": transformation_rule,
                                "Business Rule Applied": business_rule,
                                "Lookup/Reference Table Used": None,
                                "Confidence Score": 0.86,
                                "Lineage Path": f"{source_table_name or default_source}.{source_col} -> {target_table}.{target_col}" if source_col else f"{target_table}.{target_col}",
                            })

        validated_rows, quality, issues = validate_and_score_rows(rows)
        return ParseResult(
            rows=dedupe_rows(validated_rows),
            parser_name=self.name,
            confidence=min(1.0, 0.74 + 0.22 * quality),
            coverage=1.0 if rows else 0.0,
            gaps=issues,
            diagnostics={"row_count": len(rows), "mode": "sqlglot"},
        )

    def _rows_from_select(self, select_expr, target_table: str) -> list[dict[str, object]]:
        rows: list[dict[str, object]] = []
        from_tables = self._extract_from_tables(select_expr.sql())
        default_source_table = from_tables[0] if from_tables else ""
        select_sql = select_expr.sql()
        cols_sql = self._extract_select_columns(select_sql)
        for column_sql in cols_sql:
            target_col = self._extract_alias(column_sql) or self._guess_target_name(column_sql)
            transformation_rule = normalize_expr(column_sql)
            source_cols = self._extract_source_columns_from_expr(column_sql) or [("", "")]
            mapping_type = classify_mapping_type(
                transformation_rule,
                [(default_source_table, source_col[1]) for source_col in source_cols if source_col[1]],
                None,
            )
            for source_table_name, source_col in source_cols:
                effective_source = source_table_name or default_source_table
                rows.append({
                    "Source Table Name": effective_source,
                    "Source Attribute Name": source_col,
                    "Target Table Name": target_table,
                    "Target Attribute Name": target_col,
                    "Mapping Type": mapping_type,
                    "Transformation Rule": transformation_rule,
                    "Business Rule Applied": infer_business_rule(mapping_type, transformation_rule, target_col),
                    "Lookup/Reference Table Used": None,
                    "Confidence Score": 0.88,
                    "Lineage Path": f"{effective_source}.{source_col} -> {target_table}.{target_col}" if source_col else f"{target_table}.{target_col}",
                })
        return rows

    def _parse_with_regex(self, content: str) -> ParseResult:
        rows: list[dict[str, object]] = []
        statements = re.split(r";\s*(?:\n|$)", content)
        for stmt in statements:
            stmt_clean = normalize_ws(stmt)
            if not stmt_clean:
                continue

            insert_match = re.search(
                r"INSERT\s+INTO\s+([A-Za-z0-9_\.]+)\s*(?:\((.*?)\))?\s*SELECT\s+(.*?)\s+FROM\s+(.*)",
                stmt,
                flags=re.IGNORECASE | re.DOTALL,
            )
            ctas_match = re.search(
                r"CREATE\s+TABLE\s+([A-Za-z0-9_\.]+)\s+AS\s+SELECT\s+(.*?)\s+FROM\s+(.*)",
                stmt,
                flags=re.IGNORECASE | re.DOTALL,
            )

            target_table = ""
            target_cols: list[str] = []
            select_part = ""
            from_part = ""

            if insert_match:
                target_table = insert_match.group(1)
                raw_target_cols = insert_match.group(2) or ""
                if raw_target_cols:
                    target_cols = [col.strip() for col in raw_target_cols.split(",") if col.strip()]
                select_part = insert_match.group(3)
                from_part = insert_match.group(4)
            elif ctas_match:
                target_table = ctas_match.group(1)
                select_part = ctas_match.group(2)
                from_part = ctas_match.group(3)
            else:
                continue

            source_tables = self._extract_from_tables("FROM " + from_part)
            default_source_table = source_tables[0] if source_tables else ""
            select_cols = self._smart_split_csv(select_part)

            for idx, expr in enumerate(select_cols):
                expr = expr.strip()
                target_col = target_cols[idx] if idx < len(target_cols) else (self._extract_alias(expr) or self._guess_target_name(expr))
                source_cols = self._extract_source_columns_from_expr(expr) or [("", "")]
                transformation_rule = normalize_expr(expr)
                mapping_type = classify_mapping_type(
                    transformation_rule,
                    [(default_source_table, source_col[1]) for source_col in source_cols if source_col[1]],
                    None,
                )
                business_rule = infer_business_rule(mapping_type, transformation_rule, target_col)
                for source_table_name, source_col in source_cols:
                    effective_source = source_table_name or default_source_table
                    rows.append({
                        "Source Table Name": effective_source,
                        "Source Attribute Name": source_col,
                        "Target Table Name": target_table,
                        "Target Attribute Name": target_col,
                        "Mapping Type": mapping_type,
                        "Transformation Rule": transformation_rule,
                        "Business Rule Applied": business_rule,
                        "Lookup/Reference Table Used": None,
                        "Confidence Score": 0.78,
                        "Lineage Path": f"{effective_source}.{source_col} -> {target_table}.{target_col}" if source_col else f"{target_table}.{target_col}",
                    })

        validated_rows, quality, issues = validate_and_score_rows(rows)
        return ParseResult(
            rows=dedupe_rows(validated_rows),
            parser_name=self.name,
            confidence=min(1.0, 0.65 + 0.22 * quality),
            coverage=1.0 if rows else 0.0,
            gaps=issues,
            diagnostics={"row_count": len(rows), "mode": "regex"},
        )

    def _extract_from_tables(self, sql: str) -> list[str]:
        tables: list[str] = []
        for match in re.finditer(r"\bFROM\s+([A-Za-z0-9_\.]+)", sql, flags=re.IGNORECASE):
            tables.append(match.group(1))
        for match in re.finditer(r"\bJOIN\s+([A-Za-z0-9_\.]+)", sql, flags=re.IGNORECASE):
            tables.append(match.group(1))
        return unique_preserve(tables)

    def _smart_split_csv(self, text: str) -> list[str]:
        parts: list[str] = []
        buffer: list[str] = []
        level = 0
        in_single = False
        in_double = False
        for char in text:
            if char == "'" and not in_double:
                in_single = not in_single
            elif char == '"' and not in_single:
                in_double = not in_double
            elif char == "(" and not in_single and not in_double:
                level += 1
            elif char == ")" and not in_single and not in_double and level > 0:
                level -= 1
            elif char == "," and not in_single and not in_double and level == 0:
                parts.append("".join(buffer).strip())
                buffer = []
                continue
            buffer.append(char)
        if buffer:
            parts.append("".join(buffer).strip())
        return parts

    def _extract_select_columns(self, select_sql: str) -> list[str]:
        match = re.search(r"\bSELECT\b(.*?)\bFROM\b", select_sql, flags=re.IGNORECASE | re.DOTALL)
        return self._smart_split_csv(match.group(1)) if match else []

    def _extract_alias(self, expr: str) -> Optional[str]:
        match = re.search(r"\bAS\s+([A-Za-z_][A-Za-z0-9_]*)\s*$", expr, flags=re.IGNORECASE)
        if match:
            return match.group(1)
        match = re.search(r"([A-Za-z_][A-Za-z0-9_]*)\s*$", expr.strip())
        if match and "." not in match.group(1):
            return match.group(1)
        return None

    def _guess_target_name(self, expr: str) -> str:
        alias = self._extract_alias(expr)
        if alias:
            return alias
        match = re.search(r"([A-Za-z_][A-Za-z0-9_]*)\s*$", expr.strip())
        return match.group(1) if match else "derived_column"

    def _extract_source_columns_from_expr(self, expr: str) -> list[tuple[str, str]]:
        expr_clean = re.sub(r"'[^']*'", "", expr)
        pairs: list[tuple[str, str]] = []
        for match in re.finditer(r"\b([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\b", expr_clean):
            pairs.append((match.group(1), match.group(2)))
        if pairs:
            return unique_preserve_pairs(pairs)
        tokens = re.findall(r"\b([A-Za-z_][A-Za-z0-9_]*)\b", expr_clean)
        reserved = {
            "SELECT", "CASE", "WHEN", "THEN", "ELSE", "END", "AS", "NULL", "SUM", "COUNT", "AVG",
            "MIN", "MAX", "UPPER", "LOWER", "TRIM", "SUBSTR", "CURRENT_DATE", "CURRENT_TIMESTAMP",
        }
        cols: list[tuple[str, str]] = []
        for token in tokens:
            if token.upper() in reserved or re.fullmatch(r"\d+", token):
                continue
            cols.append(("", token))
        return unique_preserve_pairs(cols)