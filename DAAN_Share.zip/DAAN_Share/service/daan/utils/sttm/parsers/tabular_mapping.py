from __future__ import annotations

from ..helpers import dedupe_rows, validate_and_score_rows
from ..models import ParseResult


class TabularMappingParser:
    name = "tabular_mapping"

    def can_handle(self, _file_name: str, content: str) -> bool:
        lowered = content.lower()
        return (
            ("source attribute" in lowered and "target attribute" in lowered)
            or ("source table" in lowered and "target table" in lowered)
            or ("|" in lowered and "source" in lowered and "target" in lowered)
        )

    def parse(self, _file_name: str, content: str) -> ParseResult:
        lines = [line.strip() for line in content.splitlines() if line.strip()]
        if len(lines) < 2:
            return ParseResult([], self.name, 0.0, 0.0, ["Insufficient tabular lines"])

        header_idx = None
        delimiter = None
        headers: list[str] = []

        for index, line in enumerate(lines[:20]):
            if "|" in line:
                candidate = [item.strip() for item in line.split("|")]
                if len(candidate) >= 2:
                    headers = [header.lower() for header in candidate]
                    header_idx = index
                    delimiter = "|"
                    break
            elif "," in line:
                candidate = [item.strip() for item in line.split(",")]
                if len(candidate) >= 2 and ("source" in line.lower() or "target" in line.lower()):
                    headers = [header.lower() for header in candidate]
                    header_idx = index
                    delimiter = ","
                    break

        if header_idx is None or delimiter is None:
            return ParseResult([], self.name, 0.0, 0.0, ["No table header found"])

        rows: list[dict[str, object]] = []
        for line in lines[header_idx + 1 :]:
            columns = [item.strip() for item in line.split(delimiter)]
            if len(columns) != len(headers):
                continue

            item = dict(zip(headers, columns))
            row = {
                "Source Table Name": item.get("source table", item.get("source table name", "")),
                "Source Attribute Name": item.get("source attribute", item.get("source attribute name", item.get("source field", ""))),
                "Source Data Type": item.get("source data type", ""),
                "Source Data Length/Precision": item.get("source data length/precision", ""),
                "Target Table Name": item.get("target table", item.get("target table name", "")),
                "Target Attribute Name": item.get("target attribute", item.get("target attribute name", item.get("target field", ""))),
                "Target Data Type": item.get("target data type", ""),
                "Target Data Length/Precision": item.get("target data length/precision", ""),
                "Mapping Type": item.get("mapping type", "Direct"),
                "Transformation Rule": item.get("transformation rule", "Direct mapping"),
                "Business Rule Applied": item.get("business rule applied", "None"),
                "Lookup/Reference Table Used": item.get("lookup/reference table used"),
            }
            if row["Target Attribute Name"]:
                rows.append(row)

        validated_rows, quality, issues = validate_and_score_rows(rows)
        return ParseResult(
            rows=dedupe_rows(validated_rows),
            parser_name=self.name,
            confidence=min(1.0, 0.70 + 0.25 * quality),
            coverage=1.0 if rows else 0.0,
            gaps=issues,
            diagnostics={"row_count": len(rows)},
        )