from __future__ import annotations

import html
import re
import xml.etree.ElementTree as ET
from typing import Any

from ..helpers import classify_mapping_type, dedupe_rows, infer_business_rule, normalize_expr, unique_preserve, validate_and_score_rows
from ..models import ParseResult


class TalendXmlParser:
    name = "talend_xml"

    def can_handle(self, file_name: str, content: str) -> bool:
        preview = content[:12000]
        return (
            file_name.lower().endswith(".xml")
            and (
                "talendfile:ProcessType" in preview
                or "xmlns:TalendMapper" in preview
                or "componentName=\"tMap\"" in preview
            )
        )

    def parse(self, _file_name: str, content: str) -> ParseResult:
        try:
            root = ET.fromstring(content)
        except Exception as exc:
            return ParseResult([], self.name, 0.0, 0.0, [f"Talend XML parse failed: {exc}"])

        nodes = self._collect_nodes(root)
        connections = self._collect_connections(root)
        incoming: dict[str, list[dict[str, str]]] = {}
        for connection in connections:
            incoming.setdefault(connection["target"], []).append(connection)

        source_nodes = {
            name: node for name, node in nodes.items() if self._is_input_component(node.get("component_name", ""))
        }
        output_nodes = {
            name: node for name, node in nodes.items() if self._is_output_component(node.get("component_name", ""))
        }

        rows: list[dict[str, Any]] = []
        target_tables: list[str] = []
        source_tables: list[str] = []
        transformation_types: list[str] = []

        for output_name, output_node in output_nodes.items():
            output_schema = output_node.get("metadata", {}).get("FLOW", {})
            if not output_schema:
                continue

            ancestors = self._ancestor_names(output_name, incoming)
            path_nodes = [nodes[name] for name in ancestors if name in nodes]
            tmap_nodes = [node for node in path_nodes if node.get("component_name") == "tMap"]
            upstream_sources = [node for node in path_nodes if self._is_input_component(node.get("component_name", ""))]

            if not upstream_sources:
                continue

            target_table = self._table_name(output_node)
            target_tables.append(target_table)
            source_node = upstream_sources[0]
            source_table = self._table_name(source_node)
            source_tables.append(source_table)
            source_schema = source_node.get("metadata", {}).get("FLOW", {})

            component_chain = [
                node.get("component_name", "")
                for node in reversed(path_nodes)
                if node.get("component_name") and not self._is_input_component(node.get("component_name", ""))
            ]
            transformation_types.extend(component_chain)

            expression_maps = []
            for tmap_node in tmap_nodes:
                expressions = tmap_node.get("tmap_outputs", {})
                if expressions:
                    expression_maps.append(expressions)

            for column_name, target_meta in output_schema.items():
                expression = self._resolve_expression(column_name, expression_maps)
                transformation_rule = normalize_expr(expression or column_name)
                source_columns = self._extract_source_columns(transformation_rule)
                if not source_columns and column_name in source_schema:
                    source_columns = [column_name]

                mapping_type = classify_mapping_type(
                    transformation_rule,
                    [(source_table, source_column) for source_column in source_columns],
                    None,
                )
                business_rule = infer_business_rule(mapping_type, transformation_rule, column_name)
                source_candidates = source_columns or [""]

                for source_column in source_candidates:
                    source_meta = source_schema.get(source_column, {})
                    lineage_path = [
                        f"{source_node.get('unique_name', source_table)}.{source_column}" if source_column else source_node.get("unique_name", source_table),
                        *[node.get("unique_name", "") for node in reversed(path_nodes) if node.get("unique_name")],
                        f"{output_name}.{column_name}",
                    ]
                    rows.append({
                        "Source Table Name": source_table,
                        "Source Attribute Name": source_column,
                        "Source Data Type": source_meta.get("type", ""),
                        "Source Data Length/Precision": source_meta.get("length") or source_meta.get("precision") or "",
                        "Source Primary Key": False,
                        "Source Foreign Key": False,
                        "Source Description/Comments": source_column,
                        "Target Table Name": target_table,
                        "Target Attribute Name": column_name,
                        "Target Data Type": target_meta.get("type", ""),
                        "Target Data Length/Precision": target_meta.get("length") or target_meta.get("precision") or "",
                        "Target Primary Key": False,
                        "Target Foreign Key": False,
                        "Target Description/Comments": column_name,
                        "Mapping Type": mapping_type,
                        "Transformation Rule": transformation_rule,
                        "Business Rule Applied": business_rule,
                        "Lookup/Reference Table Used": None,
                        "Confidence Score": 0.88 if source_column else 0.72,
                        "Lineage Path": " -> ".join(unique_preserve([step for step in lineage_path if step])),
                    })

        validated_rows, quality, issues = validate_and_score_rows(rows)
        coverage = 1.0 if rows else 0.0
        return ParseResult(
            rows=dedupe_rows(validated_rows),
            parser_name=self.name,
            confidence=min(1.0, 0.72 + 0.22 * quality),
            coverage=coverage,
            gaps=issues,
            diagnostics={
                "row_count": len(validated_rows),
                "source_tables": unique_preserve([value for value in source_tables if value]),
                "target_tables": unique_preserve([value for value in target_tables if value]),
                "source_names": unique_preserve([node.get("unique_name", "") for node in source_nodes.values()]),
                "target_names": unique_preserve([node.get("unique_name", "") for node in output_nodes.values()]),
                "transformation_types": unique_preserve([value for value in transformation_types if value]),
                "framework": root.attrib.get("framework", ""),
                "job_type": root.attrib.get("jobType", ""),
            },
        )

    def _collect_nodes(self, root: ET.Element) -> dict[str, dict[str, Any]]:
        nodes: dict[str, dict[str, Any]] = {}
        for node in root.findall("./node"):
            component_name = node.attrib.get("componentName", "")
            unique_name = self._parameter_map(node).get("UNIQUE_NAME") or component_name
            metadata = self._metadata_map(node)
            nodes[unique_name] = {
                "unique_name": unique_name,
                "component_name": component_name,
                "parameters": self._parameter_map(node),
                "metadata": metadata,
                "tmap_outputs": self._tmap_outputs(node),
            }
        return nodes

    def _collect_connections(self, root: ET.Element) -> list[dict[str, str]]:
        connections: list[dict[str, str]] = []
        for connection in root.findall("./connection"):
            connections.append({
                "source": connection.attrib.get("source", ""),
                "target": connection.attrib.get("target", ""),
                "label": connection.attrib.get("label", ""),
                "metaname": connection.attrib.get("metaname", ""),
                "output_id": connection.attrib.get("outputId", ""),
            })
        return connections

    def _parameter_map(self, node: ET.Element) -> dict[str, str]:
        params: dict[str, str] = {}
        for param in node.findall("./elementParameter"):
            name = param.attrib.get("name", "")
            value = self._normalize_text(param.attrib.get("value", ""))
            if name:
                params[name] = value
        return params

    def _metadata_map(self, node: ET.Element) -> dict[str, dict[str, dict[str, str]]]:
        metadata: dict[str, dict[str, dict[str, str]]] = {}
        for metadata_node in node.findall("./metadata"):
            connector = metadata_node.attrib.get("connector", "")
            columns: dict[str, dict[str, str]] = {}
            for column in metadata_node.findall("./column"):
                name = column.attrib.get("name", "")
                if not name:
                    continue
                columns[name] = {
                    "type": column.attrib.get("type", ""),
                    "length": column.attrib.get("length", ""),
                    "precision": column.attrib.get("precision", ""),
                }
            if connector:
                metadata[connector] = columns
        return metadata

    def _tmap_outputs(self, node: ET.Element) -> dict[str, dict[str, str]]:
        if node.attrib.get("componentName") != "tMap":
            return {}

        outputs: dict[str, dict[str, str]] = {}
        for node_data in node.findall("./nodeData"):
            for output_table in node_data.findall("./outputTables"):
                table_name = output_table.attrib.get("name", "")
                entries: dict[str, str] = {}
                for entry in output_table.findall("./mapperTableEntries"):
                    entry_name = entry.attrib.get("name", "")
                    expression = normalize_expr(self._normalize_text(entry.attrib.get("expression", "")))
                    if entry_name:
                        entries[entry_name] = expression
                if table_name:
                    outputs[table_name] = entries
        return outputs

    def _ancestor_names(self, target_name: str, incoming: dict[str, list[dict[str, str]]], visited: set[str] | None = None) -> list[str]:
        local_visited = visited or set()
        if target_name in local_visited:
            return []
        local_visited.add(target_name)
        output = [target_name]
        for connection in incoming.get(target_name, []):
            source_name = connection.get("source", "")
            if source_name:
                output.extend(self._ancestor_names(source_name, incoming, local_visited))
        return unique_preserve(output)

    def _table_name(self, node: dict[str, Any]) -> str:
        params = node.get("parameters", {})
        for key in ["FILENAME", "TABLE", "DBTABLE", "LABEL", "UNIQUE_NAME"]:
            value = self._normalize_text(params.get(key, ""))
            if value:
                return value
        return node.get("unique_name", "")

    def _resolve_expression(self, column_name: str, expression_maps: list[dict[str, dict[str, str]]]) -> str:
        for output_map in expression_maps:
            for column_map in output_map.values():
                if column_name in column_map:
                    return column_map[column_name]
        return ""

    def _extract_source_columns(self, expression: str) -> list[str]:
        columns = [match.group(1) for match in re.finditer(r"\b\w+\.([A-Za-z_][A-Za-z0-9_]*)\b", expression)]
        return unique_preserve(columns)

    def _normalize_text(self, value: str) -> str:
        text = html.unescape(str(value or "")).strip()
        if len(text) >= 2 and text[0] == '"' and text[-1] == '"':
            return text[1:-1]
        return text

    def _is_input_component(self, component_name: str) -> bool:
        return component_name.startswith("tFileInput") or component_name.startswith("tDBInput") or component_name.startswith("tInput")

    def _is_output_component(self, component_name: str) -> bool:
        return "Output" in component_name