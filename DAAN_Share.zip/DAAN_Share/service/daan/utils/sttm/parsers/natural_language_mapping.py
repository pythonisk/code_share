from __future__ import annotations

import re
from typing import Any, Optional

from ..helpers import dedupe_rows, validate_and_score_rows
from ..models import ParseResult


class NaturalLanguageMappingParser:
    """Parser for natural language STTM rule description files.

    Handles text files containing:
      - A metadata section with bullet-point "- Key: Value" lines describing source/target systems
      - A column rules section with "ColumnName: rule1, rule2, ..." lines describing mappings

    Activates when content has both metadata lines (source/target system references)
    and column-level rule lines (mentioning mapping/transform/validate/sample keywords),
    and is NOT a code file.
    """

    name = "natural_language_mapping"

    # Metadata key normalization map
    _META_KEYS = {
        "source system name": "Source System Name",
        "source system": "Source System Name",
        "source database/schema name": "Source Database/Schema Name",
        "source database": "Source Database/Schema Name",
        "source schema": "Source Database/Schema Name",
        "target system name": "Target System Name",
        "target system": "Target System Name",
        "target database/schema name": "Target Database/Schema Name",
        "target database": "Target Database/Schema Name",
        "target schema": "Target Database/Schema Name",
        "loading method": "Loading Method",
        "extraction method": "Extraction Method",
        "extraction frequency": "Extraction Frequency/Schedule",
        "loading tool": "Loading Tool",
        "extraction tool": "Extraction Tool",
        "output code format": "Output code format",
        "bulk or parallel execution": "Bulk or Parallel Execution",
        "data flow step": "Data Flow/Process Step",
        "data flow/process step": "Data Flow/Process Step",
        "pre/post processing": "Pre/Post Processing Steps",
        "sql or script reference": "Source to Target Mapping SQL/Script Reference",
        "encryption requirement": "Encryption Requirement",
        "compliance requirement": "Compliance Requirement",
        "mapping version": "Mapping Version/Revision",
        "mapping owner": "Mapping Owner/Author",
        "last updated": "Last Updated Date",
    }

    # Patterns that indicate mapping type
    _MAPPING_TYPE_PATTERNS = {
        "direct mapping": "Direct",
        "direct": "Direct",
        "lookup": "Lookup-derived",
        "aggregate": "Aggregation",
        "derive": "Expression/Derived",
        "convert": "Expression/Derived",
        "transform": "Expression/Derived",
        "trim": "Expression/Derived",
        "capitalize": "Expression/Derived",
        "lowercase": "Expression/Derived",
        "uppercase": "Expression/Derived",
        "constant": "Constant",
        "system-derived": "System-derived",
    }

    def can_handle(self, _file_name: str, content: str) -> bool:
        lowered = content.lower()
        # Must have metadata-style "- Key: Value" lines AND column rule lines
        has_metadata = bool(re.search(r'^\s*-\s*(source|target)\s+(system|database|schema)', lowered, re.MULTILINE))
        has_rules = bool(re.search(r'^\s*\w+\s*:\s*.*(mapping|transform|convert|trim|validate|sample)', lowered, re.MULTILINE))
        # Should NOT be code files
        is_code = any(token in lowered for token in [".withColumn(", "SELECT ", "CREATE TABLE", "def ", "import "])
        return has_metadata and has_rules and not is_code

    def parse(self, _file_name: str, content: str) -> ParseResult:
        metadata = self._extract_metadata(content)
        source_table = self._infer_table_name(metadata, "source")
        target_table = self._infer_table_name(metadata, "target")
        column_rules = self._extract_column_rules(content)

        if not column_rules:
            return ParseResult([], self.name, 0.0, 0.0, ["No column mapping rules found in natural language content"])

        rows: list[dict[str, object]] = []
        for col_name, rule_text in column_rules:
            row = self._build_mapping_row(col_name, rule_text, source_table, target_table)
            rows.append(row)

        validated_rows, quality, issues = validate_and_score_rows(rows)
        return ParseResult(
            rows=dedupe_rows(validated_rows),
            parser_name=self.name,
            confidence=min(1.0, 0.75 + 0.20 * quality),
            coverage=1.0 if rows else 0.0,
            gaps=issues,
            diagnostics={"row_count": len(rows), "metadata_extracted": bool(metadata)},
        )

    def _extract_metadata(self, content: str) -> dict[str, str]:
        """Extract metadata from '- Key: Value' lines."""
        metadata: dict[str, str] = {}
        for match in re.finditer(r'^\s*-\s*([^:]+):\s*(.+)$', content, re.MULTILINE):
            key_raw = match.group(1).strip().lower()
            value = match.group(2).strip()
            normalized_key = self._META_KEYS.get(key_raw)
            if normalized_key:
                metadata[normalized_key] = value
        return metadata

    def _infer_table_name(self, metadata: dict[str, str], side: str) -> str:
        """Infer table name from metadata (source or target)."""
        if side == "source":
            schema = metadata.get("Source Database/Schema Name", "")
            return schema if schema else "Source"
        else:
            schema = metadata.get("Target Database/Schema Name", "")
            return schema if schema else "Target"

    def _extract_column_rules(self, content: str) -> list[tuple[str, str]]:
        """Extract column name + rule text from the mapping rules section.

        Matches lines like:
            CustomerID: Unique ID, direct mapping, must be unique, ...
            FirstName: Trim spaces, capitalize first letter, ...
            Address, City, State, ZipCode, Country: Clean, standardize, ...
        """
        rules: list[tuple[str, str]] = []
        # Pattern: ColumnName(s): rule description ending in period or EOL
        # Exclude lines that look like metadata (starting with -)
        for match in re.finditer(
            r'^(?!\s*-)([A-Z][A-Za-z0-9_]*(?:\s*,\s*[A-Z][A-Za-z0-9_]*)*)\s*:\s*(.+?)\.?\s*$',
            content,
            re.MULTILINE,
        ):
            col_names_str = match.group(1).strip()
            rule_text = match.group(2).strip()

            # Skip lines that are clearly section headers or metadata
            if any(skip in col_names_str.lower() for skip in ["source system", "target system", "loading", "extraction", "output code"]):
                continue

            # Handle multi-column lines like "Address, City, State, ZipCode, Country"
            col_names = [c.strip() for c in col_names_str.split(",") if c.strip()]
            for col_name in col_names:
                rules.append((col_name, rule_text))

        return rules

    def _build_mapping_row(self, col_name: str, rule_text: str, source_table: str, target_table: str) -> dict[str, object]:
        """Build a full mapping row from column name and natural language rule text."""
        lower_rule = rule_text.lower()

        # Infer mapping type
        mapping_type = "Direct"
        for pattern, mtype in self._MAPPING_TYPE_PATTERNS.items():
            if pattern in lower_rule:
                mapping_type = mtype
                break

        # Extract sample data
        sample = self._extract_sample(rule_text)

        # Extract transformation rule
        transformation = self._extract_transformation(rule_text)

        # Extract validation rules
        validation = self._extract_validation(rule_text)

        # Detect PII
        pii_keywords = ["masking", "anonymiz", "pii", "sensitive", "personal"]
        is_pii = any(kw in lower_rule for kw in pii_keywords)
        needs_masking = "masking" in lower_rule or "anonymiz" in lower_rule

        # Detect data type from context
        data_type = self._infer_data_type(col_name, rule_text)

        # Determine if primary/foreign key
        is_pk = "primary key" in lower_rule or ("unique" in lower_rule and "id" in col_name.lower())
        is_fk = "foreign key" in lower_rule

        # Business rules
        business_rule = self._extract_business_rule(rule_text)

        # Cleansing rules
        cleansing = self._extract_cleansing(rule_text)

        # Standardization
        standardization = self._extract_standardization(rule_text)

        return {
            "Source Table Name": source_table,
            "Source Attribute Name": col_name,
            "Source Data Type": data_type,
            "Source Data Length/Precision": "",
            "Source Primary Key": "Yes" if is_pk else "No",
            "Source Foreign Key": "Yes" if is_fk else "No",
            "Source Default Value": None,
            "Source Description/Comments": rule_text,
            "Target Table Name": target_table,
            "Target Attribute Name": col_name,
            "Target Data Type": data_type,
            "Target Data Length/Precision": "",
            "Target Primary Key": "Yes" if is_pk else "No",
            "Target Foreign Key": "Yes" if is_fk else "No",
            "Target Description/Comments": rule_text,
            "Mapping Type": mapping_type,
            "Transformation Rule": transformation,
            "Business Rule Applied": business_rule,
            "Data Conversion/Format Rule": self._extract_conversion(rule_text),
            "Aggregation/Calculation Logic": None,
            "Lookup/Reference Table Used": None,
            "Data Enrichment Rule": None,
            "Data Cleansing Rule": cleansing,
            "Data Standardization Rule": standardization,
            "Data Masking/Anonymization Rule": "Masking required" if needs_masking else None,
            "Data Validation Rule": validation,
            "Error Handling Rule": None,
            "Default Value Handling": None,
            "Data Quality Checks": validation,
            "Data Profiling Results": None,
            "Data Lineage/Traceability": None,
            "Data Sensitivity/PII Indicator": "Yes" if is_pii else "No",
            "Mask/Anonymize Sensitive Data": "Yes" if needs_masking else "No",
            "Audit Trail/Change Log": None,
            "Sample Data": sample,
            "Column Description": rule_text,
            "Confidence Score": 0.88,
            "Lineage Path": f"{source_table}.{col_name} -> {target_table}.{col_name}",
        }

    def _extract_sample(self, rule_text: str) -> Optional[str]:
        """Extract sample data from 'sample X' pattern."""
        match = re.search(r'sample\s+(.+?)(?:\.|,|$)', rule_text, re.IGNORECASE)
        if match:
            return match.group(1).strip()
        return None

    def _extract_transformation(self, rule_text: str) -> Optional[str]:
        """Extract transformation rules from text."""
        transforms = []
        patterns = [
            (r'trim\s*(?:spaces)?', "Trim"),
            (r'capitalize\s*(?:first letter)?', "Capitalize"),
            (r'lowercase', "Convert to lowercase"),
            (r'uppercase', "Convert to uppercase"),
            (r'convert\s+to\s+([^,\.]+)', r"Convert to \1"),
            (r'remove\s+([^,\.]+)', r"Remove \1"),
            (r'validate\s+([^,\.]+)', r"Validate \1"),
        ]
        for pattern, replacement in patterns:
            match = re.search(pattern, rule_text, re.IGNORECASE)
            if match:
                if r"\1" in replacement:
                    transforms.append(re.sub(pattern, replacement, match.group(0), flags=re.IGNORECASE))
                else:
                    transforms.append(replacement)
        return ", ".join(transforms) if transforms else None

    def _extract_validation(self, rule_text: str) -> Optional[str]:
        """Extract validation rules."""
        validations = []
        if re.search(r'cannot be null|must not be null|not null', rule_text, re.IGNORECASE):
            validations.append("Not Null")
        if re.search(r'must be unique|unique', rule_text, re.IGNORECASE):
            validations.append("Unique")
        if re.search(r'valid values?\s+([^,\.]+)', rule_text, re.IGNORECASE):
            match = re.search(r'valid values?\s+([^,\.]+)', rule_text, re.IGNORECASE)
            if match:
                validations.append(f"Valid values: {match.group(1).strip()}")
        if re.search(r'must be\s*>=?\s*(\d+)', rule_text, re.IGNORECASE):
            match = re.search(r'must be\s*(>=?\s*\d+)', rule_text, re.IGNORECASE)
            if match:
                validations.append(f"Value {match.group(1)}")
        if re.search(r'(\d+)\s*digits', rule_text, re.IGNORECASE):
            match = re.search(r'(\d+)\s*digits', rule_text, re.IGNORECASE)
            if match:
                validations.append(f"Must be {match.group(1)} digits")
        if re.search(r'validate\s*(url|format|iso|date|email)', rule_text, re.IGNORECASE):
            match = re.search(r'validate\s*(url|format|iso|date|email)', rule_text, re.IGNORECASE)
            if match:
                validations.append(f"Validate {match.group(1)}")
        if re.search(r'must be\s+(true|false|active|inactive)', rule_text, re.IGNORECASE):
            match = re.search(r'must be\s+([^,\.]+)', rule_text, re.IGNORECASE)
            if match:
                validations.append(f"Must be {match.group(1).strip()}")
        return ", ".join(validations) if validations else None

    def _extract_business_rule(self, rule_text: str) -> Optional[str]:
        """Extract business rules."""
        rules = []
        if "cannot be null" in rule_text.lower() or "must not be null" in rule_text.lower():
            rules.append("Not Null")
        if "unique" in rule_text.lower():
            rules.append("Unique")
        match = re.search(r'valid values?\s+([^,\.]+)', rule_text, re.IGNORECASE)
        if match:
            rules.append(f"Valid values: {match.group(1).strip()}")
        return ", ".join(rules) if rules else None

    def _extract_cleansing(self, rule_text: str) -> Optional[str]:
        """Extract cleansing rules."""
        rules = []
        if re.search(r'trim', rule_text, re.IGNORECASE):
            rules.append("Trim whitespace")
        if re.search(r'remove\s+(?:non[- ]?numeric|invalid|special)\s*(?:characters)?', rule_text, re.IGNORECASE):
            match = re.search(r'remove\s+([^,\.]+)', rule_text, re.IGNORECASE)
            if match:
                rules.append(f"Remove {match.group(1).strip()}")
        if re.search(r'clean', rule_text, re.IGNORECASE):
            rules.append("Clean data")
        return ", ".join(rules) if rules else None

    def _extract_standardization(self, rule_text: str) -> Optional[str]:
        """Extract standardization rules."""
        rules = []
        if re.search(r'standardize', rule_text, re.IGNORECASE):
            rules.append("Standardize")
        if re.search(r'e\.?164', rule_text, re.IGNORECASE):
            rules.append("E.164 format")
        if re.search(r'yyyy-?mm-?dd', rule_text, re.IGNORECASE):
            rules.append("YYYY-MM-DD format")
        if re.search(r'iso', rule_text, re.IGNORECASE):
            rules.append("ISO standard")
        return ", ".join(rules) if rules else None

    def _extract_conversion(self, rule_text: str) -> Optional[str]:
        """Extract data conversion/format rules."""
        conversions = []
        if re.search(r'convert\s+to\s+([^,\.]+)', rule_text, re.IGNORECASE):
            match = re.search(r'convert\s+to\s+([^,\.]+)', rule_text, re.IGNORECASE)
            if match:
                conversions.append(f"Convert to {match.group(1).strip()}")
        if re.search(r'e\.?164', rule_text, re.IGNORECASE):
            conversions.append("E.164 phone format")
        if re.search(r'yyyy-?mm-?dd\s+hh:?mm:?ss', rule_text, re.IGNORECASE):
            conversions.append("YYYY-MM-DD HH:MM:SS")
        elif re.search(r'yyyy-?mm-?dd', rule_text, re.IGNORECASE):
            conversions.append("YYYY-MM-DD")
        return ", ".join(conversions) if conversions else None

    def _infer_data_type(self, col_name: str, rule_text: str) -> str:
        """Infer data type from column name and rules."""
        lower_name = col_name.lower()
        lower_rule = rule_text.lower()

        if any(kw in lower_name for kw in ["date", "dob", "created", "updated", "login"]):
            if "hh:mm:ss" in lower_rule or "timestamp" in lower_rule:
                return "TIMESTAMP"
            return "DATE"
        if any(kw in lower_name for kw in ["id", "code", "points"]):
            if "points" in lower_name:
                return "INTEGER"
            return "VARCHAR"
        if any(kw in lower_name for kw in ["email", "name", "address", "city", "state", "country", "url", "phone", "notes", "language"]):
            return "VARCHAR"
        if "true/false" in lower_rule or "boolean" in lower_rule:
            return "BOOLEAN"
        if any(kw in lower_name for kw in ["status", "gender", "opt"]):
            return "VARCHAR"
        return "VARCHAR"
