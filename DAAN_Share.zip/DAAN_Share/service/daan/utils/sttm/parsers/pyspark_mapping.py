from __future__ import annotations

import ast
import re
from typing import Optional

from ..helpers import classify_mapping_type, dedupe_rows, infer_business_rule, unique_preserve, validate_and_score_rows
from ..models import ParseResult
from .sql_mapping import SqlMappingParser


class PySparkMappingParser:
    name = "pyspark_mapping"

    def can_handle(self, _file_name: str, content: str) -> bool:
        return any(token in content for token in ["spark.table(", ".withColumn(", ".select(", ".selectExpr(", ".saveAsTable(", ".insertInto("])

    def parse(self, _file_name: str, content: str) -> ParseResult:
        try:
            tree = ast.parse(content)
        except Exception as exc:
            return ParseResult([], self.name, 0.0, 0.0, [f"PySpark AST parse failed: {exc}"])

        var_sources: dict[str, str] = {}
        string_vars: dict[str, str] = {}
        rows: list[dict[str, object]] = []

        # Regex fallback for source table (handles dbtable= and source_table= patterns)
        source_table_fallback = self._regex_source_table(content)

        # --- Pass 1: Collect variable-to-table mappings from Assign nodes ---
        for node in ast.walk(tree):
            if not isinstance(node, ast.Assign):
                continue
            for tgt in node.targets:
                if not isinstance(tgt, ast.Name):
                    continue
                var_name = tgt.id

                # String constant assignment (e.g. source_table = "dbo.customers")
                if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                    string_vars[var_name] = node.value.value
                    val = node.value.value
                    if "." in val or "table" in var_name.lower() or "source" in var_name.lower():
                        var_sources[var_name] = val

                # Call assignment (spark.table / spark.read...load / chained calls)
                elif isinstance(node.value, ast.Call):
                    tbl = self._find_table_call(node.value)
                    if tbl:
                        var_sources[var_name] = tbl
                    else:
                        tbl = self._find_jdbc_table(node.value)
                        if tbl:
                            var_sources[var_name] = tbl
                        else:
                            root = self._root_name(node.value)
                            if root and root in var_sources:
                                var_sources[var_name] = var_sources[root]

        # --- Pass 2: Process ALL Call nodes for withColumn / select / selectExpr ---
        # (walks every Call in the AST, including chained calls inside a single assignment)
        for node in ast.walk(tree):
            if not (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)):
                continue

            attr = node.func.attr

            if attr == "withColumn" and len(node.args) >= 2:
                root_var = self._root_name(node.func.value)
                source_table = var_sources.get(root_var, source_table_fallback)
                target_col = self._const_str(node.args[0]) or "derived_col"
                expr = self._ast_to_expr(node.args[1])
                source_cols = self._extract_cols_from_ast(node.args[1])
                mapping_type = classify_mapping_type(expr, [(source_table, col) for col in source_cols], None)
                business_rule = infer_business_rule(mapping_type, expr, target_col)
                for source_col in source_cols or [""]:
                    rows.append({
                        "Source Table Name": source_table,
                        "Source Attribute Name": source_col,
                        "Target Table Name": "",
                        "Target Attribute Name": target_col,
                        "Mapping Type": mapping_type,
                        "Transformation Rule": expr,
                        "Business Rule Applied": business_rule,
                        "Lookup/Reference Table Used": None,
                        "Confidence Score": 0.84,
                        "Lineage Path": f"{source_table}.{source_col} -> {target_col}" if source_col else target_col,
                    })

            elif attr in {"select", "selectExpr"}:
                root_var = self._root_name(node.func.value)
                source_table = var_sources.get(root_var, source_table_fallback)
                for arg in node.args:
                    if attr == "selectExpr" and isinstance(arg, ast.Constant):
                        expr = str(arg.value)
                        target_col = self._extract_sql_alias(expr) or self._guess_target_from_sql_expr(expr)
                        source_cols = [col for _, col in SqlMappingParser()._extract_source_columns_from_expr(expr)] or [target_col]
                    else:
                        expr = self._ast_to_expr(arg)
                        target_col = self._extract_alias_from_ast(arg) or self._guess_col_name_from_ast(arg)
                        source_cols = self._extract_cols_from_ast(arg)
                    mapping_type = classify_mapping_type(expr, [(source_table, col) for col in source_cols], None)
                    business_rule = infer_business_rule(mapping_type, expr, target_col)
                    for source_col in source_cols or [""]:
                        rows.append({
                            "Source Table Name": source_table,
                            "Source Attribute Name": source_col,
                            "Target Table Name": "",
                            "Target Attribute Name": target_col,
                            "Mapping Type": mapping_type,
                            "Transformation Rule": expr,
                            "Business Rule Applied": business_rule,
                            "Lookup/Reference Table Used": None,
                            "Confidence Score": 0.82,
                            "Lineage Path": f"{source_table}.{source_col} -> {target_col}" if source_col else target_col,
                        })

        # --- Pass 3: Resolve target table from saveAsTable / insertInto ---
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr in {"saveAsTable", "insertInto"}:
                target_table = ""
                if node.args:
                    arg = node.args[0]
                    if isinstance(arg, ast.Constant):
                        target_table = str(arg.value)
                    elif isinstance(arg, ast.Name) and arg.id in string_vars:
                        target_table = string_vars[arg.id]
                if target_table:
                    for row in rows:
                        if not row.get("Target Table Name"):
                            row["Target Table Name"] = target_table

        validated_rows, quality, issues = validate_and_score_rows(rows)
        return ParseResult(
            rows=dedupe_rows(validated_rows),
            parser_name=self.name,
            confidence=min(1.0, 0.70 + 0.24 * quality),
            coverage=1.0 if rows else 0.0,
            gaps=issues,
            diagnostics={"row_count": len(rows)},
        )

    def _root_name(self, node: ast.AST) -> str:
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            return self._root_name(node.value)
        if isinstance(node, ast.Call):
            return self._root_name(node.func)
        return ""

    def _find_table_call(self, node: ast.AST) -> Optional[str]:
        """Find spark.table("tablename") anywhere in a call chain."""
        for child in ast.walk(node):
            if isinstance(child, ast.Call) and isinstance(child.func, ast.Attribute):
                if child.func.attr == "table" and child.args and isinstance(child.args[0], ast.Constant):
                    return str(child.args[0].value)
        return None

    def _find_jdbc_table(self, node: ast.AST) -> Optional[str]:
        """Find .options(dbtable="...") or .option("dbtable","...") in a call chain."""
        for child in ast.walk(node):
            if not (isinstance(child, ast.Call) and isinstance(child.func, ast.Attribute)):
                continue
            if child.func.attr == "options":
                for kw in child.keywords:
                    if kw.arg == "dbtable" and isinstance(kw.value, ast.Constant):
                        return str(kw.value.value)
            elif child.func.attr == "option" and len(child.args) >= 2:
                if isinstance(child.args[0], ast.Constant) and str(child.args[0].value) == "dbtable":
                    if isinstance(child.args[1], ast.Constant):
                        return str(child.args[1].value)
        return None

    def _regex_source_table(self, content: str) -> str:
        """Regex fallback to find source table from JDBC options or variable assignments."""
        match = re.search(r'dbtable\s*[=:]\s*["\']([^"\']+)["\']', content)
        if match:
            return match.group(1)
        match = re.search(r'source_table\s*=\s*["\']([^"\']+)["\']', content, re.IGNORECASE)
        if match:
            return match.group(1)
        return ""

    def _const_str(self, node: ast.AST) -> Optional[str]:
        return str(node.value) if isinstance(node, ast.Constant) else None

    def _ast_to_expr(self, node: ast.AST) -> str:
        try:
            return ast.unparse(node)
        except Exception:
            return str(node)

    def _extract_cols_from_ast(self, node: ast.AST) -> list[str]:
        cols: list[str] = []
        for child in ast.walk(node):
            if isinstance(child, ast.Call) and isinstance(child.func, ast.Name) and child.func.id == "col":
                if child.args and isinstance(child.args[0], ast.Constant):
                    cols.append(str(child.args[0].value))
            if isinstance(child, ast.Call) and isinstance(child.func, ast.Attribute) and child.func.attr == "col":
                if child.args and isinstance(child.args[0], ast.Constant):
                    cols.append(str(child.args[0].value))
        return unique_preserve(cols)

    def _extract_alias_from_ast(self, node: ast.AST) -> Optional[str]:
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "alias":
            if node.args and isinstance(node.args[0], ast.Constant):
                return str(node.args[0].value)
        return None

    def _guess_col_name_from_ast(self, node: ast.AST) -> str:
        alias = self._extract_alias_from_ast(node)
        if alias:
            return alias
        expr = self._ast_to_expr(node)
        match = re.search(r"col\([\"']([^\"']+)[\"']\)", expr)
        return match.group(1) if match else "derived_column"

    def _extract_sql_alias(self, expr: str) -> Optional[str]:
        match = re.search(r"\bAS\s+([A-Za-z_][A-Za-z0-9_]*)\s*$", expr, flags=re.IGNORECASE)
        return match.group(1) if match else None

    def _guess_target_from_sql_expr(self, expr: str) -> str:
        alias = self._extract_sql_alias(expr)
        if alias:
            return alias
        match = re.search(r"\b([A-Za-z_][A-Za-z0-9_]*)\b\s*$", expr.strip())
        return match.group(1) if match else "derived_column"