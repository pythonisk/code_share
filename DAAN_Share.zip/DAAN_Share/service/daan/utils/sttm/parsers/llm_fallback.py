from __future__ import annotations

from ..models import ParseResult


class LlmFallbackParser:
    name = "llm_fallback"

    def can_handle(self, _file_name: str, _content: str) -> bool:
        return True

    def parse(self, _file_name: str, _content: str) -> ParseResult:
        return ParseResult([], self.name, 0.0, 0.0, ["LLM fallback not configured in DAAN utility layer"])