from __future__ import annotations

from typing import Protocol

from ..models import ParseResult


class BaseParser(Protocol):
    name: str

    def can_handle(self, file_name: str, content: str) -> bool:
        ...

    def parse(self, file_name: str, content: str) -> ParseResult:
        ...