from __future__ import annotations

import json

from ..helpers import dedupe_rows, validate_and_score_rows
from ..models import ParseResult


# Canonical 36-field STTM schema: (Excel column title, [accepted aliases], default).
# Lets the LLM emit a compact row (a few snake_case keys) while the tool always
# expands every row to the full column set, filling sensible defaults.
_STTM_SCHEMA: list[tuple[str, list[str], object]] = [
    ("Source Table Name", ["source_table", "sourceTable", "source_object"], ""),
    ("Source Attribute Name", ["source_column", "sourceColumn", "source", "source_column_name"], ""),
    ("Source Data Type", ["source_dtype", "sourceType", "source_datatype"], ""),
    ("Source Data Length/Precision", ["source_length", "source_precision"], ""),
    ("Source Primary Key", ["source_pk", "source_primary_key"], "No"),
    ("Source Foreign Key", ["source_fk", "source_foreign_key"], "No"),
    ("Source Default Value", ["source_default", "source_default_value"], ""),
    ("Source Description/Comments", ["source_desc", "source_description"], ""),
    ("Target Table Name", ["target_table", "targetTable", "target_object"], ""),
    ("Target Attribute Name", ["target_column", "targetColumn", "target", "target_column_name"], ""),
    ("Target Data Type", ["target_dtype", "targetType", "target_datatype"], ""),
    ("Target Data Length/Precision", ["target_length", "target_precision"], ""),
    ("Target Primary Key", ["target_pk", "target_primary_key", "primary_key"], "No"),
    ("Target Foreign Key", ["target_fk", "target_foreign_key", "foreign_key_reference"], "No"),
    ("Target Description/Comments", ["target_desc", "target_description", "description"], ""),
    ("Mapping Type", ["mapping_type", "direct_or_derived"], "Direct"),
    ("Transformation Rule", ["transformation_rule", "transformation"], "Direct mapping"),
    ("Business Rule Applied", ["business_rule", "business_rule_applied"], ""),
    ("Data Conversion/Format Rule", ["conversion_rule", "data_conversion", "conversion_format"], ""),
    ("Aggregation/Calculation Logic", ["aggregation_logic", "calculation", "aggregation_calculation"], ""),
    ("Lookup/Reference Table Used", ["lookup_table", "lookup_reference"], ""),
    ("Data Enrichment Rule", ["enrichment_rule", "data_enrichment"], ""),
    ("Data Cleansing Rule", ["cleansing_rule", "data_cleansing"], ""),
    ("Data Standardization Rule", ["standardization_rule", "standardization_case", "data_standardization"], ""),
    ("Data Masking/Anonymization Rule", ["masking_rule", "data_masking"], ""),
    ("Data Validation Rule", ["validation_rule", "validation_regex", "data_validation"], ""),
    ("Error Handling Rule", ["error_handling", "error_handling_rule"], ""),
    ("Default Value Handling", ["default_handling", "default_value_handling", "default_value"], ""),
    ("Data Quality Checks", ["dq_checks", "data_quality", "data_quality_checks"], ""),
    ("Data Profiling Results", ["profiling_results", "data_profiling"], ""),
    ("Data Lineage/Traceability", ["lineage", "data_lineage", "lineage_path"], ""),
    ("Data Sensitivity/PII Indicator", ["pii", "pii_sensitivity", "sensitivity", "sensitivity_label"], "No"),
    ("Mask/Anonymize Sensitive Data", ["mask_sensitive", "mask_anonymize"], "No"),
    ("Audit Trail/Change Log", ["audit_trail", "audit_log"], ""),
    ("Sample Data", ["sample_data", "sample"], ""),
    ("Column Description", ["column_description", "col_description"], ""),
]


def _expand_to_full_schema(item: dict[str, object]) -> dict[str, object]:
    """Expand a compact or partial mapping into the full 36-field STTM schema."""
    row: dict[str, object] = {}
    for title, aliases, default in _STTM_SCHEMA:
        value = default
        for key in (title, *aliases):
            if key in item and item[key] not in (None, ""):
                value = item[key]
                break
        row[title] = value
    return row


class JsonMappingParser:
    name = "json_mapping"

    def can_handle(self, _file_name: str, content: str) -> bool:
        stripped = content.strip()
        return stripped.startswith("{") or stripped.startswith("[")

    def parse(self, _file_name: str, content: str) -> ParseResult:
        try:
            data = json.loads(content)
        except Exception as exc:
            return ParseResult([], self.name, 0.0, 0.0, [f"JSON parse failed: {exc}"])

        rows: list[dict[str, object]] = []

        def normalize_row(item: dict[str, object]) -> dict[str, object]:
            return _expand_to_full_schema(item)

        if isinstance(data, dict):
            for key in ["sttm_mappings", "mappings", "mapping_rows", "rows", "fields"]:
                if key in data and isinstance(data[key], list):
                    for item in data[key]:
                        if isinstance(item, dict):
                            rows.append(normalize_row(item))
                    break
        elif isinstance(data, list):
            for item in data:
                if isinstance(item, dict):
                    rows.append(normalize_row(item))

        validated_rows, quality, issues = validate_and_score_rows(rows)
        return ParseResult(
            rows=dedupe_rows(validated_rows),
            parser_name=self.name,
            confidence=min(1.0, 0.75 + 0.20 * quality),
            coverage=1.0 if rows else 0.0,
            gaps=issues,
            diagnostics={"row_count": len(rows)},
        )