from __future__ import annotations

from pathlib import Path

from ..models import ParseResult
from .informatica_xml import InformaticaPowerMartXmlParser
from .pyspark_mapping import PySparkMappingParser
from .snowpark_java_mapping import SnowparkJavaMappingParser
from .sql_mapping import SqlMappingParser


class EmbeddedStructureParser:
    name = "embedded_structure"

    def __init__(self) -> None:
        self.xml_parser = InformaticaPowerMartXmlParser()
        self.sql_parser = SqlMappingParser()
        self.py_parser = PySparkMappingParser()
        self.snowpark_parser = SnowparkJavaMappingParser()

    def can_handle(self, file_name: str, _content: str) -> bool:
        return Path(file_name).suffix.lower() in {".txt", ".log", ".dat"} or True

    def parse(self, file_name: str, content: str) -> ParseResult:
        candidates: list[ParseResult] = []
        if self.xml_parser.can_handle(file_name, content):
            candidates.append(self.xml_parser.parse(file_name, content))
        if self.snowpark_parser.can_handle(file_name, content):
            candidates.append(self.snowpark_parser.parse(file_name, content))
        if self.py_parser.can_handle(file_name, content):
            candidates.append(self.py_parser.parse(file_name, content))
        if self.sql_parser.can_handle(file_name, content):
            candidates.append(self.sql_parser.parse(file_name, content))
        non_empty = [candidate for candidate in candidates if candidate.rows]
        if not non_empty:
            return ParseResult([], self.name, 0.0, 0.0, ["No embedded structure parsed"])
        best = sorted(non_empty, key=lambda item: (item.confidence, item.coverage, len(item.rows)), reverse=True)[0]
        best.parser_name = f"{self.name}->{best.parser_name}"
        return best