from __future__ import annotations

import re

from ..helpers import classify_mapping_type, dedupe_rows, infer_business_rule, unique_preserve, validate_and_score_rows
from ..models import ParseResult


class SnowparkJavaMappingParser:
    name = "snowpark_java_mapping"

    _DETECT_TOKENS = [
        "session.table(", "Session.table(",
        "Functions.col(", "Functions.lit(", "Functions.concat(",
        "Functions.upper(", "Functions.lower(", "Functions.count(",
        ".withColumn(", ".saveAsTable(", ".copyInto(",
        ".createOrReplaceTempView(",
    ]
    _WINDOW_FUNCS = {"row_number", "rank", "dense_rank", "ntile", "lead", "lag", "cume_dist", "percent_rank"}

    def can_handle(self, file_name: str, content: str) -> bool:
        ext = file_name.rsplit(".", 1)[-1].lower() if "." in file_name else ""
        if ext in {"java", "scala"}:
            return any(token in content for token in self._DETECT_TOKENS[:2])
        upper = content.upper()
        is_snowpark_proc = (("LANGUAGE JAVA" in upper or "LANGUAGE SCALA" in upper) and (("CREATE" in upper and "PROCEDURE" in upper) or ("CREATE" in upper and "FUNCTION" in upper)))
        if is_snowpark_proc:
            return True
        has_session_table = "session.table(" in content or "Session.table(" in content
        return has_session_table and sum(1 for token in self._DETECT_TOKENS[2:] if token in content) >= 2

    def parse(self, _file_name: str, content: str) -> ParseResult:
        content = self._extract_procedure_body(content)
        var_sources: dict[str, str] = {}
        var_ops: dict[str, list[str]] = {}
        rows: list[dict[str, object]] = []
        join_sources: dict[str, list[str]] = {}
        dropped_cols: set[str] = set()
        intermediate_cols: set[str] = set()
        has_final_select = False
        final_select_cols: set[str] = set()

        for line in content.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("//") or stripped.startswith("*"):
                continue

            match = re.search(r"(\w+)\s*=\s*\w+\.table\(\s*[\"']([^\"']+)[\"']\s*\)", stripped)
            if match:
                var_sources[match.group(1)] = match.group(2)
                var_ops.setdefault(match.group(1), []).append("table_read")
                continue

            match = re.search(r"(\w+)\s*=\s*\w+\.read\(\)\s*\.(\w+)\(\s*[\"']([^\"']+)[\"']\s*\)", stripped)
            if match:
                var_sources[match.group(1)] = match.group(3)
                var_ops.setdefault(match.group(1), []).append("file_read")
                continue

            match = re.search(r"(\w+)\s*=\s*(\w+)\.withColumn\(\s*[\"']([^\"']+)[\"']\s*,\s*(.*?)\)\s*;?\s*$", stripped)
            if match:
                result_var, src_var, target_col, expr_text = match.group(1), match.group(2), match.group(3), match.group(4)
                src_table = var_sources.get(src_var, var_sources.get(result_var, ""))
                var_sources[result_var] = src_table
                var_ops.setdefault(result_var, list(var_ops.get(src_var, []))).append("withColumn")
                expr_lower = expr_text.lower()
                if any(func in expr_lower for func in self._WINDOW_FUNCS) or ".over(" in expr_lower or "Window." in expr_text:
                    intermediate_cols.add(target_col)
                source_cols = self._extract_col_refs(expr_text)
                expr_norm = self._normalize_java_expr(expr_text)
                mapping_type = classify_mapping_type(expr_norm, [(src_table, col) for col in source_cols], None)
                business_rule = infer_business_rule(mapping_type, expr_norm, target_col)
                for source_col in source_cols or [""]:
                    rows.append({
                        "Source Table Name": src_table,
                        "Source Attribute Name": source_col,
                        "Target Table Name": "",
                        "Target Attribute Name": target_col,
                        "Mapping Type": mapping_type,
                        "Transformation Rule": expr_norm,
                        "Business Rule Applied": business_rule,
                        "Lookup/Reference Table Used": None,
                        "Confidence Score": 0.86,
                        "Lineage Path": f"{src_table}.{source_col} -> {target_col}" if source_col else target_col,
                    })
                continue

            match = re.search(r"(\w+)\s*=\s*(\w+)\.rename\(\s*[\"']([^\"']+)[\"']\s*,\s*\w+\.col\(\s*[\"']([^\"']+)[\"']\s*\)", stripped)
            if match:
                result_var, src_var = match.group(1), match.group(2)
                new_name, old_name = match.group(3), match.group(4)
                src_table = var_sources.get(src_var, var_sources.get(result_var, ""))
                var_sources[result_var] = src_table
                var_ops.setdefault(result_var, list(var_ops.get(src_var, []))).append("rename")
                rows.append({
                    "Source Table Name": src_table,
                    "Source Attribute Name": old_name,
                    "Target Table Name": "",
                    "Target Attribute Name": new_name,
                    "Mapping Type": "Direct",
                    "Transformation Rule": f"Rename {old_name} -> {new_name}",
                    "Business Rule Applied": "None",
                    "Lookup/Reference Table Used": None,
                    "Confidence Score": 0.90,
                    "Lineage Path": f"{src_table}.{old_name} -> {new_name}",
                })
                continue

            match = re.search(r"(\w+)\s*=\s*(\w+)\.drop\((.*?)\)\s*;?\s*$", stripped)
            if match:
                result_var, src_var, drop_body = match.group(1), match.group(2), match.group(3)
                src_table = var_sources.get(src_var, var_sources.get(result_var, ""))
                var_sources[result_var] = src_table
                var_ops.setdefault(result_var, list(var_ops.get(src_var, []))).append("drop")
                for drop_match in re.finditer(r"[\"']([^\"']+)[\"']", drop_body):
                    dropped_cols.add(drop_match.group(1))
                for drop_match in re.finditer(r"col\(\s*[\"']([^\"']+)[\"']\s*\)", drop_body):
                    dropped_cols.add(drop_match.group(1))
                continue

            match = re.search(r"(\w+)\s*=\s*(\w+)\.select\((.*?)\)\s*;?\s*$", stripped)
            if match:
                result_var, src_var, select_body = match.group(1), match.group(2), match.group(3)
                src_table = var_sources.get(src_var, var_sources.get(result_var, ""))
                var_sources[result_var] = src_table
                var_ops.setdefault(result_var, list(var_ops.get(src_var, []))).append("select")
                has_final_select = True
                final_select_cols.clear()
                for col_expr in self._split_java_args(select_body):
                    alias = self._extract_java_alias(col_expr)
                    source_cols = self._extract_col_refs(col_expr)
                    target_col = alias or (source_cols[0] if source_cols else "derived_column")
                    final_select_cols.add(target_col)
                    expr_norm = self._normalize_java_expr(col_expr)
                    mapping_type = classify_mapping_type(expr_norm, [(src_table, col) for col in source_cols], None)
                    business_rule = infer_business_rule(mapping_type, expr_norm, target_col)
                    for source_col in source_cols or [""]:
                        rows.append({
                            "Source Table Name": src_table,
                            "Source Attribute Name": source_col,
                            "Target Table Name": "",
                            "Target Attribute Name": target_col,
                            "Mapping Type": mapping_type,
                            "Transformation Rule": expr_norm,
                            "Business Rule Applied": business_rule,
                            "Lookup/Reference Table Used": None,
                            "Confidence Score": 0.84,
                            "Lineage Path": f"{src_table}.{source_col} -> {target_col}" if source_col else target_col,
                        })
                continue

            match = re.search(r"(\w+)\s*=\s*(\w+)\.join\(\s*(\w+)", stripped)
            if match:
                result_var, left_var, right_var = match.group(1), match.group(2), match.group(3)
                left_src = var_sources.get(left_var, "")
                right_src = var_sources.get(right_var, "")
                var_sources[result_var] = left_src
                join_sources.setdefault(result_var, []).append(right_src)
                var_ops.setdefault(result_var, list(var_ops.get(left_var, []))).append(f"join({right_src})")
                continue

            match = re.search(r"(\w+)\s*=\s*(\w+)\.(filter|where)\((.*?)\)\s*;?\s*$", stripped)
            if match:
                result_var, src_var = match.group(1), match.group(2)
                src_table = var_sources.get(src_var, var_sources.get(result_var, ""))
                var_sources[result_var] = src_table
                var_ops.setdefault(result_var, list(var_ops.get(src_var, []))).append("filter")
                continue

            match = re.search(r"(\w+)\s*=\s*(\w+)\.groupBy\((.*?)\)\.agg\((.*?)\)\s*;?\s*$", stripped)
            if match:
                result_var, src_var = match.group(1), match.group(2)
                group_body, agg_body = match.group(3), match.group(4)
                src_table = var_sources.get(src_var, var_sources.get(result_var, ""))
                var_sources[result_var] = src_table
                var_ops.setdefault(result_var, list(var_ops.get(src_var, []))).append("groupBy_agg")
                group_cols = self._extract_col_refs(group_body)
                for group_col in group_cols:
                    rows.append({
                        "Source Table Name": src_table,
                        "Source Attribute Name": group_col,
                        "Target Table Name": "",
                        "Target Attribute Name": group_col,
                        "Mapping Type": "Direct",
                        "Transformation Rule": "GROUP BY key",
                        "Business Rule Applied": f"Group by {group_col}",
                        "Lookup/Reference Table Used": None,
                        "Confidence Score": 0.85,
                        "Lineage Path": f"{src_table}.{group_col}",
                    })
                for agg_expr in self._split_java_args(agg_body):
                    alias = self._extract_java_alias(agg_expr)
                    source_cols = self._extract_col_refs(agg_expr)
                    target_col = alias or (source_cols[0] + "_agg" if source_cols else "derived_agg")
                    expr_norm = self._normalize_java_expr(agg_expr)
                    business_rule = infer_business_rule("Aggregation", expr_norm, target_col)
                    for source_col in source_cols or [""]:
                        rows.append({
                            "Source Table Name": src_table,
                            "Source Attribute Name": source_col,
                            "Target Table Name": "",
                            "Target Attribute Name": target_col,
                            "Mapping Type": "Aggregation",
                            "Transformation Rule": expr_norm,
                            "Business Rule Applied": business_rule,
                            "Lookup/Reference Table Used": None,
                            "Confidence Score": 0.84,
                            "Lineage Path": f"{src_table}.{source_col} -> {target_col}" if source_col else target_col,
                        })
                continue

            match = re.search(r"(\w+)(?:\.write\(\)[^;]*)?\.(?:saveAsTable|copyInto)\(\s*[\"']([^\"']+)[\"']\s*\)", stripped)
            if match:
                target_table = match.group(2)
                for row in rows:
                    if not row.get("Target Table Name"):
                        row["Target Table Name"] = target_table
                continue

            match = re.search(r"(\w+)\.createOrReplaceTempView\(\s*[\"']([^\"']+)[\"']\s*\)", stripped)
            if match:
                dataframe_var, view_name = match.group(1), match.group(2)
                var_sources[view_name] = var_sources.get(dataframe_var, view_name)

        for row in rows:
            src_tbl = row.get("Source Table Name", "")
            for _, joined in join_sources.items():
                if src_tbl and src_tbl in joined:
                    if row.get("Lookup/Reference Table Used") is None:
                        row["Lookup/Reference Table Used"] = src_tbl
                    if row.get("Mapping Type") == "Direct":
                        row["Mapping Type"] = "Join/Derived"

        filtered_rows: list[dict[str, object]] = []
        for row in rows:
            target_attr = str(row.get("Target Attribute Name", "")).strip()
            if target_attr in dropped_cols:
                continue
            if has_final_select and final_select_cols:
                if target_attr in final_select_cols or target_attr not in intermediate_cols:
                    filtered_rows.append(row)
                continue
            if target_attr in intermediate_cols:
                continue
            filtered_rows.append(row)

        validated_rows, quality, issues = validate_and_score_rows(filtered_rows)
        all_ops = sorted({op for ops in var_ops.values() for op in ops})
        return ParseResult(
            rows=dedupe_rows(validated_rows),
            parser_name=self.name,
            confidence=min(1.0, 0.72 + 0.24 * quality),
            coverage=1.0 if filtered_rows else 0.0,
            gaps=issues,
            diagnostics={
                "row_count": len(filtered_rows),
                "source_tables": list(set(var_sources.values())),
                "operations_detected": all_ops,
                "join_sources": {key: value for key, value in join_sources.items()},
                "transformation_types": sorted(set(all_ops) - {"table_read", "file_read"}),
            },
        )

    def _extract_procedure_body(self, content: str) -> str:
        blocks = re.findall(r"\$\$(.*?)\$\$", content, flags=re.DOTALL)
        if blocks:
            body = max(blocks, key=len)
            if "session" in body.lower() or ".table(" in body or ".col(" in body:
                return body
        return content

    def _extract_col_refs(self, expr: str) -> list[str]:
        cols: list[str] = []
        for match in re.finditer(r"\.?col\(\s*[\"']([^\"']+)[\"']\s*\)", expr):
            cols.append(match.group(1))
        for match in re.finditer(r"\$[\"']([^\"']+)[\"']", expr):
            cols.append(match.group(1))
        return unique_preserve(cols)

    def _extract_java_alias(self, expr: str) -> str | None:
        match = re.search(r"\.(?:as|alias)\(\s*[\"']([^\"']+)[\"']\s*\)", expr)
        return match.group(1) if match else None

    def _normalize_java_expr(self, expr: str) -> str:
        expr = expr.strip().rstrip(";")
        expr = re.sub(r"\.(?:as|alias)\(\s*[\"'][^\"']+[\"']\s*\)\s*$", "", expr).strip()
        return expr if expr else "Direct mapping"

    def _split_java_args(self, text: str) -> list[str]:
        parts: list[str] = []
        buffer: list[str] = []
        level = 0
        in_str = False
        str_char = ""
        for char in text:
            if in_str:
                buffer.append(char)
                if char == str_char:
                    in_str = False
                continue
            if char in {'"', "'"}:
                in_str = True
                str_char = char
                buffer.append(char)
                continue
            if char == "(":
                level += 1
            elif char == ")":
                level -= 1
            elif char == "," and level == 0:
                parts.append("".join(buffer).strip())
                buffer = []
                continue
            buffer.append(char)
        if buffer:
            parts.append("".join(buffer).strip())
        return [part for part in parts if part]