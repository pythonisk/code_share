from __future__ import annotations

import html
import re
import xml.etree.ElementTree as ET

from ..helpers import (
    classify_mapping_type,
    dedupe_rows,
    infer_business_rule,
    is_literal,
    is_system_expr,
    merge_sources,
    normalize_expr,
    safe_bool_flag,
    unique_preserve,
    validate_and_score_rows,
)
from ..models import Endpoint, FieldDef, ParseResult, SourceDef, TargetDef, TransformationDef


class InformaticaPowerMartXmlParser:
    name = "informatica_powermart_xml"

    def can_handle(self, _file_name: str, content: str) -> bool:
        preview = content[:10000].upper()
        return (
            "<POWERMART" in preview
            or "&LT;POWERMART" in preview
            or ("<REPOSITORY" in preview and "<MAPPING" in preview)
            or ("&LT;REPOSITORY" in preview and "&LT;MAPPING" in preview)
        )

    def parse(self, _file_name: str, content: str) -> ParseResult:
        try:
            root = ET.fromstring(self._extract_xml_text(content))
        except Exception as exc:
            return ParseResult([], self.name, 0.0, 0.0, [f"XML parse failed: {exc}"])

        sources: dict[str, SourceDef] = {}
        targets: dict[str, TargetDef] = {}
        transformations: dict[str, TransformationDef] = {}
        connectors: list[tuple[Endpoint, Endpoint]] = []

        for elem in root.iter():
            tag = elem.tag.upper()
            if tag == "SOURCE":
                src_name = elem.attrib.get("NAME", "")
                source = SourceDef(name=src_name, database_type=elem.attrib.get("DATABASETYPE", ""))
                for source_field in elem.findall("./SOURCEFIELD"):
                    field_name = source_field.attrib.get("NAME", "")
                    source.fields[field_name] = FieldDef(
                        name=field_name,
                        dtype=source_field.attrib.get("DATATYPE", ""),
                        length=source_field.attrib.get("LENGTH", source_field.attrib.get("PRECISION", "")),
                        pk=safe_bool_flag(source_field.attrib.get("KEYTYPE")),
                        fk="FOREIGN" in str(source_field.attrib.get("KEYTYPE", "")).upper(),
                        default=source_field.attrib.get("DEFAULTVALUE"),
                        description=source_field.attrib.get("DESCRIPTION", "") or field_name,
                    )
                sources[src_name] = source
            elif tag == "TARGET":
                target_name = elem.attrib.get("NAME", "")
                target = TargetDef(name=target_name, database_type=elem.attrib.get("DATABASETYPE", ""))
                for target_field in elem.findall("./TARGETFIELD"):
                    field_name = target_field.attrib.get("NAME", "")
                    target.fields[field_name] = FieldDef(
                        name=field_name,
                        dtype=target_field.attrib.get("DATATYPE", ""),
                        length=target_field.attrib.get("LENGTH", target_field.attrib.get("PRECISION", "")),
                        pk=safe_bool_flag(target_field.attrib.get("KEYTYPE")),
                        fk="FOREIGN" in str(target_field.attrib.get("KEYTYPE", "")).upper(),
                        default=target_field.attrib.get("DEFAULTVALUE"),
                        description=target_field.attrib.get("DESCRIPTION", "") or field_name,
                    )
                targets[target_name] = target
            elif tag == "TRANSFORMATION":
                transformation_name = elem.attrib.get("NAME", "")
                transformation = TransformationDef(name=transformation_name, tf_type=elem.attrib.get("TYPE", ""))
                for attr in elem.findall("./TABLEATTRIBUTE"):
                    transformation.attrs[attr.attrib.get("NAME", "")] = attr.attrib.get("VALUE", "")
                for transform_field in elem.findall("./TRANSFORMFIELD"):
                    field_name = transform_field.attrib.get("NAME", "")
                    transformation.fields[field_name] = FieldDef(
                        name=field_name,
                        dtype=transform_field.attrib.get("DATATYPE", ""),
                        length=transform_field.attrib.get("LENGTH", transform_field.attrib.get("PRECISION", "")),
                        default=transform_field.attrib.get("DEFAULTVALUE"),
                        description=transform_field.attrib.get("DESCRIPTION", ""),
                        expression=transform_field.attrib.get("EXPRESSION"),
                        porttype=transform_field.attrib.get("PORTTYPE"),
                    )
                transformations[transformation_name] = transformation
            elif tag == "CONNECTOR":
                connectors.append((
                    Endpoint(instance=elem.attrib.get("FROMINSTANCE", ""), field=elem.attrib.get("FROMFIELD", "")),
                    Endpoint(instance=elem.attrib.get("TOINSTANCE", ""), field=elem.attrib.get("TOFIELD", "")),
                ))

        incoming: dict[tuple[str, str], list[Endpoint]] = {}
        for from_ep, to_ep in connectors:
            incoming.setdefault((to_ep.instance, to_ep.field), []).append(from_ep)

        source_qualifier_map = self._infer_sq_source_map(transformations, sources)
        all_rows: list[dict[str, object]] = []
        total_target_fields = 0
        resolved_target_fields = 0
        for target_name, target_def in targets.items():
            for target_field_name, target_field_meta in target_def.fields.items():
                total_target_fields += 1
                upstream_eps = incoming.get((target_name, target_field_name), [])
                if not upstream_eps:
                    continue
                resolved_target_fields += 1
                resolved = self._resolve_upstream(upstream_eps, incoming, transformations, sources, source_qualifier_map, set())
                expr = resolved["transformation_rule"]
                lookup_table = resolved["lookup_table"]
                source_pairs = [(row["source_table"], row["source_column"]) for row in resolved["source_rows"]]
                mapping_type = classify_mapping_type(expr, source_pairs, lookup_table)
                business_rule = infer_business_rule(mapping_type, expr, target_field_name)
                rows = merge_sources(
                    source_rows=resolved["source_rows"],
                    target_meta=target_field_meta,
                    target_table=target_name,
                    mapping_type=mapping_type,
                    transformation_rule=expr,
                    business_rule=business_rule,
                    lookup_table=lookup_table,
                    confidence=resolved["confidence"],
                    lineage_path=resolved["lineage_path"] + [f"{target_name}.{target_field_name}"],
                )
                all_rows.extend(rows)

        coverage = (resolved_target_fields / total_target_fields) if total_target_fields else 0.0
        validated_rows, quality_score, issues = validate_and_score_rows(all_rows)
        structural_bonus = 0.15 if sources and targets and connectors else 0.08 if sources and targets else 0.0
        confidence = min(1.0, 0.55 + structural_bonus + 0.25 * coverage + 0.20 * quality_score)
        transformation_types = sorted(set(item.tf_type for item in transformations.values() if item.tf_type))
        return ParseResult(
            rows=dedupe_rows(validated_rows),
            parser_name=self.name,
            confidence=confidence,
            coverage=coverage,
            gaps=issues,
            diagnostics={
                "sources": list(sources.keys()),
                "targets": list(targets.keys()),
                "source_names": list(sources.keys()),
                "target_names": list(targets.keys()),
                "source_systems": [item.database_type for item in sources.values() if item.database_type],
                "target_systems": [item.database_type for item in targets.values() if item.database_type],
                "transformations": list(transformations.keys()),
                "transformation_types": transformation_types,
                "connectors": len(connectors),
                "resolved_target_fields": resolved_target_fields,
                "total_target_fields": total_target_fields,
            },
        )

    def _extract_xml_text(self, content: str) -> str:
        text = content.strip()
        if any(token in text for token in ["&lt;", "&gt;", "&amp;lt;", "&amp;gt;"]):
            text = html.unescape(text)
        start = text.find("<")
        end = text.rfind(">")
        if start == -1 or end == -1 or end <= start:
            raise ValueError("No XML block found")
        text = text[start : end + 1]
        text = re.sub(r"<\?xml[^>]*\?>", "", text, flags=re.IGNORECASE)
        text = re.sub(r"<!DOCTYPE[^>]*>", "", text, flags=re.IGNORECASE)
        return text

    def _infer_sq_source_map(self, transformations: dict[str, TransformationDef], sources: dict[str, SourceDef]) -> dict[str, str]:
        sq_to_source: dict[str, str] = {}
        source_names = list(sources.keys())
        for transformation_name, transformation in transformations.items():
            if transformation.tf_type.upper() != "SOURCE QUALIFIER":
                continue
            if transformation_name.startswith("SQ_"):
                candidate = transformation_name[3:]
                if candidate in sources:
                    sq_to_source[transformation_name] = candidate
                    continue
            best_source = ""
            best_overlap = -1
            transformation_fields = set(transformation.fields.keys())
            for source_name in source_names:
                overlap = len(transformation_fields.intersection(set(sources[source_name].fields.keys())))
                if overlap > best_overlap:
                    best_overlap = overlap
                    best_source = source_name
            if best_source:
                sq_to_source[transformation_name] = best_source
        return sq_to_source

    def _extract_input_ports_from_expr(self, expr: str) -> list[str]:
        if not expr:
            return []
        ports = set(re.findall(r":(?:INPUT|INPORT|LKP)\.([A-Za-z_][A-Za-z0-9_]*)", expr, flags=re.IGNORECASE))
        for token in re.findall(r"\b([A-Za-z_][A-Za-z0-9_]*)\b", expr):
            token_upper = token.upper()
            if token_upper in {
                "IIF", "DECODE", "TO_DATE", "TO_CHAR", "TRUNC", "NVL", "NVL2", "UPPER", "LOWER", "LTRIM", "RTRIM", "SUBSTR", "SYSDATE", "SYSTIMESTAMP", "NULL", "TRUE", "FALSE", "AND", "OR", "NOT", "CASE", "WHEN", "THEN", "ELSE", "END",
            }:
                continue
            if re.fullmatch(r"\d+", token):
                continue
            ports.add(token)
        return list(ports)

    def _resolve_upstream(self, upstream_eps, incoming, transformations, sources, sq_to_source, visited):
        all_source_rows = []
        expr_fragments = []
        lookup_table = None
        lineage_path = []
        business_rules = []
        confidences = []
        for ep in upstream_eps:
            resolved = self._resolve_endpoint(ep, incoming, transformations, sources, sq_to_source, visited)
            all_source_rows.extend(resolved["source_rows"])
            if resolved["transformation_rule"]:
                expr_fragments.append(resolved["transformation_rule"])
            if resolved["lookup_table"] and not lookup_table:
                lookup_table = resolved["lookup_table"]
            lineage_path.extend(resolved["lineage_path"])
            if resolved["business_rule"]:
                business_rules.append(resolved["business_rule"])
            confidences.append(resolved["confidence"])
        dedup_sources = []
        seen = set()
        for row in all_source_rows:
            key = (row.get("source_table", ""), row.get("source_column", ""), row.get("source_dtype", ""), row.get("source_length", ""))
            if key in seen:
                continue
            seen.add(key)
            dedup_sources.append(row)
        return {
            "source_rows": dedup_sources,
            "transformation_rule": " ; ".join(unique_preserve([item for item in expr_fragments if item])) or "Direct mapping",
            "lookup_table": lookup_table,
            "business_rule": " | ".join(unique_preserve(business_rules)) if business_rules else "None",
            "lineage_path": unique_preserve(lineage_path),
            "confidence": min(confidences) if confidences else 0.80,
        }

    def _resolve_endpoint(self, ep, incoming, transformations, sources, sq_to_source, visited):
        if (ep.instance, ep.field) in visited:
            return {"source_rows": [], "transformation_rule": "Recursive reference", "lookup_table": None, "business_rule": "Recursive reference detected", "lineage_path": [f"{ep.instance}.{ep.field}"], "confidence": 0.40}
        local_visited = set(visited)
        local_visited.add((ep.instance, ep.field))
        if ep.instance in sources:
            source = sources[ep.instance]
            meta = source.fields.get(ep.field, FieldDef(name=ep.field))
            return {"source_rows": [{"source_table": ep.instance, "source_column": ep.field, "source_dtype": meta.dtype, "source_length": meta.length, "source_pk": meta.pk, "source_fk": meta.fk, "source_desc": meta.description or ep.field}], "transformation_rule": "Direct mapping", "lookup_table": None, "business_rule": "None", "lineage_path": [f"{ep.instance}.{ep.field}"], "confidence": 0.98}
        transformation = transformations.get(ep.instance)
        if not transformation:
            return {"source_rows": [], "transformation_rule": "Direct mapping", "lookup_table": None, "business_rule": "Unknown lineage", "lineage_path": [f"{ep.instance}.{ep.field}"], "confidence": 0.50}
        if ep.instance in sq_to_source and sq_to_source[ep.instance] in sources:
            actual_source_name = sq_to_source[ep.instance]
            source = sources[actual_source_name]
            meta = source.fields.get(ep.field, FieldDef(name=ep.field))
            return {"source_rows": [{"source_table": actual_source_name, "source_column": ep.field, "source_dtype": meta.dtype, "source_length": meta.length, "source_pk": meta.pk, "source_fk": meta.fk, "source_desc": meta.description or ep.field}], "transformation_rule": "Direct mapping", "lookup_table": None, "business_rule": "None", "lineage_path": [f"{actual_source_name}.{ep.field}", f"{ep.instance}.{ep.field}"], "confidence": 0.96}
        field_meta = transformation.fields.get(ep.field, FieldDef(name=ep.field))
        node = f"{ep.instance}.{ep.field}"
        norm_expr = normalize_expr(field_meta.expression) if field_meta.expression else ""
        if field_meta.expression and (is_literal(norm_expr) or is_system_expr(norm_expr)):
            return {"source_rows": [], "transformation_rule": norm_expr, "lookup_table": None, "business_rule": f"Derived in {transformation.tf_type}", "lineage_path": [node], "confidence": 0.88}
        if transformation.tf_type.upper() == "LOOKUP" and "OUTPUT" in str(field_meta.porttype or "").upper():
            lookup_tbl = transformation.attrs.get("Lookup Table Name")
            lookup_cond = transformation.attrs.get("Lookup Condition", "")
            input_ports = [name for name, field in transformation.fields.items() if "INPUT" in str(field.porttype or "").upper()]
            source_rows = []
            lineage_path = []
            for in_port in input_ports:
                in_eps = incoming.get((ep.instance, in_port), [])
                if not in_eps:
                    continue
                resolved = self._resolve_upstream(in_eps, incoming, transformations, sources, sq_to_source, local_visited)
                source_rows.extend(resolved["source_rows"])
                lineage_path.extend(resolved["lineage_path"])
            lineage_path.append(node)
            return {"source_rows": source_rows, "transformation_rule": f"Lookup {lookup_tbl or ''} using condition [{lookup_cond}] to derive {ep.field}".strip(), "lookup_table": lookup_tbl, "business_rule": f"Lookup-derived field {ep.field}", "lineage_path": unique_preserve(lineage_path), "confidence": 0.92}
        same_field_upstream = incoming.get((ep.instance, ep.field), [])
        referenced_ports = self._extract_input_ports_from_expr(field_meta.expression or "")
        port_upstream = []
        for port in referenced_ports:
            port_upstream.extend(incoming.get((ep.instance, port), []))
        if same_field_upstream:
            port_upstream.extend(same_field_upstream)
        if not port_upstream:
            for (to_inst, to_field), from_eps in incoming.items():
                if to_inst == ep.instance:
                    porttype = str(transformation.fields.get(to_field, FieldDef(name=to_field)).porttype or "")
                    if "INPUT" in porttype.upper() or to_field not in transformation.fields:
                        port_upstream.extend(from_eps)
        if port_upstream:
            resolved = self._resolve_upstream(port_upstream, incoming, transformations, sources, sq_to_source, local_visited)
            business_rule = f"Apply {transformation.tf_type} logic for {ep.field}" if field_meta.expression else resolved["business_rule"]
            return {"source_rows": resolved["source_rows"], "transformation_rule": norm_expr if field_meta.expression else resolved["transformation_rule"], "lookup_table": resolved["lookup_table"], "business_rule": business_rule, "lineage_path": unique_preserve(resolved["lineage_path"] + [node]), "confidence": max(0.75, resolved["confidence"] - (0.02 if field_meta.expression else 0.0))}
        if field_meta.expression:
            referenced = self._extract_input_ports_from_expr(field_meta.expression)
            matched_sources = []
            for src_name, src_def in sources.items():
                matched_fields = [field for field in referenced if field in src_def.fields]
                if matched_fields:
                    matched_sources.append((src_name, matched_fields))
            if len(matched_sources) == 1:
                src_name, matched_fields = matched_sources[0]
                source_rows = []
                lineage_path = []
                for match_field in matched_fields:
                    meta = sources[src_name].fields[match_field]
                    source_rows.append({"source_table": src_name, "source_column": match_field, "source_dtype": meta.dtype, "source_length": meta.length, "source_pk": meta.pk, "source_fk": meta.fk, "source_desc": meta.description or match_field})
                    lineage_path.append(f"{src_name}.{match_field}")
                lineage_path.append(node)
                return {"source_rows": source_rows, "transformation_rule": norm_expr, "lookup_table": None, "business_rule": f"Inferred source lineage for {ep.field} from expression references", "lineage_path": unique_preserve(lineage_path), "confidence": 0.82}
            return {"source_rows": [], "transformation_rule": norm_expr, "lookup_table": None, "business_rule": f"Derived in {transformation.tf_type}", "lineage_path": [node], "confidence": 0.72}
        return {"source_rows": [], "transformation_rule": "Direct mapping", "lookup_table": None, "business_rule": "Unknown lineage", "lineage_path": [node], "confidence": 0.50}