from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .excel_writer import create_sttm_excel_flexible
from .file_reader import read_file_content
from .helpers import coerce_llm_json, dedupe_rows, validate_and_score_rows
from .metadata import heuristic_metadata_from_content, llm_metadata_fallback
from .models import AidaSTTMState
from .registry import ParserRegistry


class AidaSttmService:
    def __init__(self, parser_registry: ParserRegistry | None = None):
        self._registry = parser_registry or ParserRegistry()

    def process_input_files(self, state: AidaSTTMState) -> AidaSTTMState:
        if not state["session_folder"]:
            raise ValueError("session_folder is required")

        extracted_context: dict[str, str] = {}
        for file_path in state["file_paths"]:
            filename = Path(file_path).name
            content = read_file_content(file_path)
            if content.strip():
                extracted_context[filename] = content
        state["extracted_context"] = extracted_context
        state["rag_storage_status"] = False
        return state

    def extract_mapping_details(self, state: AidaSTTMState) -> AidaSTTMState:
        extracted_context = state["extracted_context"]
        all_rows: list[dict[str, Any]] = []
        parse_results = {}

        for filename, content in extracted_context.items():
            result = self._registry.parse_file(filename, content)
            parse_results[filename] = result
            all_rows.extend(result.rows)

        all_rows = dedupe_rows(all_rows)
        validated_rows, quality_score, validation_issues = validate_and_score_rows(all_rows)

        metadata = heuristic_metadata_from_content(extracted_context, parse_results)
        if not any(value for value in metadata.values()):
            metadata = llm_metadata_fallback(extracted_context) or metadata

        metadata["Overall Extracted Mapping Rows"] = len(validated_rows)
        metadata["Overall Validation Score"] = quality_score
        metadata["Overall Validation Issues"] = " | ".join(validation_issues) if validation_issues else None
        metadata["Per File Parser Summary"] = " | ".join(
            f"{filename}:{result.parser_name}:{len(result.rows)}rows"
            for filename, result in parse_results.items()
        )

        state["metadata_info_raw"] = json.dumps(metadata, ensure_ascii=False, default=str)
        state["mapping_info_raw"] = json.dumps({"sttm_mappings": validated_rows}, ensure_ascii=False, default=str)
        return state

    def generate_sttm(self, state: AidaSTTMState, file_name: str | None = None) -> AidaSTTMState:
        metadata_dict = coerce_llm_json(state["metadata_info_raw"])
        mapping_data = coerce_llm_json(state["mapping_info_raw"])
        mappings_list = mapping_data.get("sttm_mappings", []) if isinstance(mapping_data, dict) else []
        if not isinstance(mappings_list, list):
            mappings_list = []

        mappings_list = [mapping for mapping in mappings_list if isinstance(mapping, dict)]
        mappings_list, final_quality, final_issues = validate_and_score_rows(mappings_list)

        metadata_dict["Final Mapping Row Count"] = len(mappings_list)
        metadata_dict["Final Validation Score"] = final_quality
        metadata_dict["Final Validation Issues"] = " | ".join(final_issues) if final_issues else None

        state["sttm_path"] = create_sttm_excel_flexible(
            metadata=metadata_dict,
            mappings=mappings_list,
            output_folder=state["session_folder"],
            file_name=file_name,
        )
        return state

    def run(self, file_paths: list[str], output_folder: str, file_name: str | None = None) -> dict[str, Any]:
        normalized_paths = [str(Path(path).resolve()) for path in file_paths if str(path).strip()]
        if not normalized_paths:
            raise ValueError("At least one input file is required")

        missing = [path for path in normalized_paths if not Path(path).is_file()]
        if missing:
            raise FileNotFoundError(f"Input files not found: {missing}")

        state: AidaSTTMState = {
            "file_paths": normalized_paths,
            "extracted_context": {},
            "rag_storage_status": False,
            "metadata_info_raw": "",
            "mapping_info_raw": "",
            "sttm_path": "",
            "session_folder": str(Path(output_folder).resolve()),
        }
        Path(state["session_folder"]).mkdir(parents=True, exist_ok=True)

        state = self.process_input_files(state)
        state = self.extract_mapping_details(state)
        state = self.generate_sttm(state, file_name=file_name)

        workflow_state_path = Path(state["session_folder"]) / "workflow_state.json"
        workflow_state_path.write_text(json.dumps(state, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

        metadata = coerce_llm_json(state["metadata_info_raw"])
        validation_issues_text = metadata.get("Final Validation Issues") or metadata.get("Overall Validation Issues") or ""
        validation_issues = [issue.strip() for issue in str(validation_issues_text).split("|") if issue.strip()]

        return {
            "status": "ok",
            "artifact_path": state["sttm_path"],
            "workflow_state_path": str(workflow_state_path),
            "mapping_count": metadata.get("Final Mapping Row Count", metadata.get("Overall Extracted Mapping Rows", 0)),
            "validation_score": metadata.get("Final Validation Score", metadata.get("Overall Validation Score", 0.0)),
            "validation_issues": validation_issues,
            "parser_summary": metadata.get("Per File Parser Summary"),
            "metadata": metadata,
        }


def generate_sttm_from_files(file_paths: list[str], output_folder: str, file_name: str | None = None) -> dict[str, Any]:
    return AidaSttmService().run(file_paths=file_paths, output_folder=output_folder, file_name=file_name)