from __future__ import annotations

import logging
import re
from typing import Any

from .helpers import unique_preserve
from .models import ParseResult

logger = logging.getLogger(__name__)


def heuristic_metadata_from_content(
    extracted_context: dict[str, str],
    parse_results: dict[str, ParseResult],
) -> dict[str, Any]:
    source_system = ""
    source_schema = ""
    target_system = ""
    target_schema = ""
    mapping_owner = ""
    mapping_version = ""
    updated_date = ""

    for _, content in extracted_context.items():
        upper = content.upper()

        if not updated_date:
            match = re.search(r'CREATION_DATE="([^"]+)"', content, flags=re.IGNORECASE)
            if match:
                updated_date = match.group(1)

        if not mapping_owner:
            match = re.search(r'OWNER="([^"]+)"', content, flags=re.IGNORECASE)
            if match:
                mapping_owner = match.group(1)

        if not mapping_version:
            match = re.search(r'VERSIONNUMBER="([^"]+)"', content, flags=re.IGNORECASE)
            if match:
                mapping_version = match.group(1)

        if "FLAT FILE" in upper and not source_system:
            source_system = "Flat File"
        if "FLAT FILE" in upper and not target_system:
            target_system = "Flat File"

        match = re.search(r'<SOURCE[^>]*DATABASETYPE="([^"]+)"', content, flags=re.IGNORECASE)
        if match:
            source_system = source_system or match.group(1)
        match = re.search(r'<SOURCE[^>]*DBDNAME="([^"]+)"', content, flags=re.IGNORECASE)
        if match:
            source_schema = source_schema or match.group(1)

        match = re.search(r'<TARGET[^>]*DATABASETYPE="([^"]+)"', content, flags=re.IGNORECASE)
        if match:
            target_system = target_system or match.group(1)

        match = re.search(r'<TARGET[^>]*NAME="([^"]+)"', content, flags=re.IGNORECASE)
        if match:
            target_schema = target_schema or match.group(1)

    for result in parse_results.values():
        diagnostics = result.diagnostics or {}
        if not source_system and diagnostics.get("source_systems"):
            source_system = diagnostics["source_systems"][0]
        if not target_system and diagnostics.get("target_systems"):
            target_system = diagnostics["target_systems"][0]
        if not source_schema and diagnostics.get("source_names"):
            source_schema = diagnostics["source_names"][0]
        if not target_schema and diagnostics.get("target_names"):
            target_schema = diagnostics["target_names"][0]

    all_source_tables: list[str] = []
    all_target_tables: list[str] = []
    for result in parse_results.values():
        for row in result.rows:
            source_table = str(row.get("Source Table Name", "")).strip()
            target_table = str(row.get("Target Table Name", "")).strip()
            if source_table and source_table not in all_source_tables:
                all_source_tables.append(source_table)
            if target_table and target_table not in all_target_tables:
                all_target_tables.append(target_table)

    if not source_schema and all_source_tables:
        first_src = all_source_tables[0]
        source_schema = first_src.rsplit(".", 1)[0] if "." in first_src else " | ".join(all_source_tables[:5])

    if not target_schema and all_target_tables:
        first_tgt = all_target_tables[0]
        target_schema = first_tgt.rsplit(".", 1)[0] if "." in first_tgt else " | ".join(all_target_tables[:5])

    if not source_system or not target_system:
        for result in parse_results.values():
            parser_name = result.parser_name.lower()
            diagnostics = result.diagnostics or {}

            inferred_system = ""
            if "snowpark" in parser_name:
                inferred_system = "Snowflake"
            elif "pyspark" in parser_name:
                inferred_system = "Spark"
            elif "sql" in parser_name:
                for _, content in extracted_context.items():
                    upper = content.upper()
                    if "SNOWFLAKE" in upper or "VARIANT" in upper or "FLATTEN(" in upper:
                        inferred_system = "Snowflake"
                        break
                    if "BIGQUERY" in upper or "STRUCT<" in upper or "`" in content:
                        inferred_system = "BigQuery"
                        break
                    if "REDSHIFT" in upper or "DISTKEY" in upper or "SORTKEY" in upper:
                        inferred_system = "Redshift"
                        break
                    if "HIVE" in upper or "STORED AS" in upper:
                        inferred_system = "Hive"
                        break
                    if any(token in upper for token in ["MERGE INTO", "INSERT INTO", "CREATE TABLE"]):
                        inferred_system = "SQL Database"
                        break

            if not inferred_system:
                for _, content in extracted_context.items():
                    upper = content.upper()
                    if "LANGUAGE JAVA" in upper or "LANGUAGE SCALA" in upper or "SNOWPARK" in upper:
                        inferred_system = "Snowflake"
                        break
                    if "SESSION.TABLE(" in upper:
                        inferred_system = "Snowflake"
                        break

            if inferred_system:
                source_system = source_system or inferred_system
                target_system = target_system or inferred_system

            if not source_schema and diagnostics.get("source_tables"):
                source_schema = " | ".join(diagnostics["source_tables"][:5])

    process_steps: list[str] = []
    for result in parse_results.values():
        diagnostics = result.diagnostics or {}
        parser_name = result.parser_name
        transformation_types = diagnostics.get("transformation_types", [])
        if transformation_types and "informatica" in parser_name:
            process_steps.append(" -> ".join(["Source", *transformation_types, "Target"]))
        elif "informatica" in parser_name:
            process_steps.append("Source -> Source Qualifier -> Target")
        elif "sql" in parser_name:
            process_steps.append("SQL Select/Insert Transformation")
        elif "pyspark" in parser_name:
            process_steps.append("PySpark DataFrame Transformations")
        elif "snowpark" in parser_name:
            ops = diagnostics.get("operations_detected", [])
            if ops:
                process_steps.append(" -> ".join(["Source", *[op for op in ops if op not in {"table_read", "file_read"}], "Target"]))
            else:
                process_steps.append("Snowpark Java DataFrame Transformations")
        elif result.rows:
            if transformation_types:
                process_steps.append(" -> ".join(["Source", *transformation_types, "Target"]))
            else:
                source_tables = unique_preserve([
                    str(row.get("Source Table Name", "")).strip()
                    for row in result.rows if str(row.get("Source Table Name", "")).strip()
                ])
                target_tables = unique_preserve([
                    str(row.get("Target Table Name", "")).strip()
                    for row in result.rows if str(row.get("Target Table Name", "")).strip()
                ])
                if source_tables and target_tables:
                    process_steps.append(f"{', '.join(source_tables[:3])} -> Transformation -> {', '.join(target_tables[:3])}")
                elif target_tables:
                    process_steps.append(f"Source -> Transformation -> {', '.join(target_tables[:3])}")

    return {
        "Source System Name": source_system,
        "Source Database/Schema Name": source_schema,
        "Loading Method": None,
        "Extraction Method": None,
        "Target System Name": target_system,
        "Target Database/Schema Name": target_schema,
        "Extraction Frequency/Schedule": None,
        "Loading Tool": "AIDA STTM",
        "Extraction Tool": "AIDA STTM",
        "Output code format": None,
        "Bulk or Parallel Execution": None,
        "Data Flow/Process Step": " | ".join(unique_preserve(process_steps)) if process_steps else None,
        "Pre/Post Processing Steps": None,
        "Source to Target Mapping SQL/Script Reference": None,
        "Encryption Requirement": None,
        "Compliance Requirement": None,
        "Mapping Version/Revision": mapping_version,
        "Mapping Owner/Author": mapping_owner,
        "Last Updated Date": updated_date,
    }


def llm_metadata_fallback(_: dict[str, str]) -> dict[str, Any]:
    return {}