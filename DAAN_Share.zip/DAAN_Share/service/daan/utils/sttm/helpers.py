from __future__ import annotations

import json
import re
from typing import Any, Optional

from .models import ColumnLineage, FieldDef

MAX_CONTEXT_CHARS = 12_000
MIN_STRUCTURED_CONFIDENCE = 0.80
MIN_STRUCTURED_COVERAGE = 0.75


def safe_bool_flag(value: Any) -> bool:
    normalized = str(value or "").strip().upper()
    return (
        normalized in {"YES", "TRUE", "Y", "1", "PK", "P", "PRIMARY", "PRIMARY KEY", "PRIMARYKEY"}
        or "PRIMARY" in normalized
    )


def bool_to_yes_no(value: Any) -> str:
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if isinstance(value, str):
        return "Yes" if value.strip().upper() in {"YES", "TRUE", "Y", "1"} else value
    return "Yes" if value else "No"


def unique_preserve(values: list[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for value in values:
        if not value or value in seen:
            continue
        seen.add(value)
        output.append(value)
    return output


def unique_preserve_pairs(values: list[tuple[str, str]]) -> list[tuple[str, str]]:
    seen: set[tuple[str, str]] = set()
    output: list[tuple[str, str]] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        output.append(value)
    return output


def normalize_ws(text: Optional[str]) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def is_literal(expr: str) -> bool:
    expr = normalize_ws(expr)
    return (
        bool(re.fullmatch(r"'[^']*'", expr))
        or bool(re.fullmatch(r'"[^"]*"', expr))
        or bool(re.fullmatch(r"\d+(\.\d+)?", expr))
    )


def is_system_expr(expr: str) -> bool:
    normalized = normalize_ws(expr).upper()
    return any(token in normalized for token in ["SYSDATE", "CURRENT_DATE", "CURRENT_TIMESTAMP", "NOW()", "GETDATE()"])


def is_aggregate_expr(expr: str) -> bool:
    normalized = normalize_ws(expr).upper()
    return any(token in normalized for token in ["SUM(", "COUNT(", "AVG(", "MIN(", "MAX("])


def normalize_expr(expr: Optional[str]) -> str:
    normalized = normalize_ws(expr)
    return normalized if normalized else "Direct mapping"


def classify_mapping_type(
    expr: str,
    upstream_sources: list[tuple[str, str]],
    lookup_table: str | None = None,
) -> str:
    expr = normalize_expr(expr)
    if lookup_table or ":LKP." in expr.upper() or "LOOKUP " in expr.upper():
        return "Lookup-derived"
    if is_literal(expr):
        return "Constant"
    if is_system_expr(expr):
        return "System-derived"
    if is_aggregate_expr(expr):
        return "Aggregation"
    if len({source[0] for source in upstream_sources if source[0]}) > 1:
        return "Join/Derived"
    if expr and expr.upper() != "DIRECT MAPPING":
        return "Expression/Derived"
    return "Direct"


def infer_business_rule(mapping_type: str, transformation_rule: str, target_column: str) -> str:
    normalized_rule = normalize_expr(transformation_rule)
    if mapping_type == "Constant":
        return f"Populate {target_column} using constant value"
    if mapping_type == "System-derived":
        return f"Populate {target_column} using system-generated value"
    if mapping_type == "Lookup-derived":
        return f"Populate {target_column} using reference lookup"
    if mapping_type == "Aggregation":
        return f"Populate {target_column} using aggregation logic"
    if mapping_type in {"Expression/Derived", "Join/Derived"}:
        return f"Populate {target_column} using derived expression"
    return "None"


def build_sttm_row_from_lineage(row: ColumnLineage) -> dict[str, Any]:
    return {
        "Source Table Name": row.source_table,
        "Source Attribute Name": row.source_column,
        "Source Data Type": row.source_dtype,
        "Source Data Length/Precision": row.source_length,
        "Source Primary Key": bool_to_yes_no(row.source_pk),
        "Source Foreign Key": bool_to_yes_no(row.source_fk),
        "Source Default Value": None,
        "Source Description/Comments": row.source_desc,
        "Target Table Name": row.target_table,
        "Target Attribute Name": row.target_column,
        "Target Data Type": row.target_dtype,
        "Target Data Length/Precision": row.target_length,
        "Target Primary Key": bool_to_yes_no(row.target_pk),
        "Target Foreign Key": bool_to_yes_no(row.target_fk),
        "Target Description/Comments": row.target_desc,
        "Mapping Type": row.mapping_type,
        "Transformation Rule": row.transformation_rule,
        "Business Rule Applied": row.business_rule,
        "Data Conversion/Format Rule": row.data_conversion_rule,
        "Aggregation/Calculation Logic": row.aggregation_logic,
        "Lookup/Reference Table Used": row.lookup_table,
        "Data Enrichment Rule": row.data_enrichment_rule,
        "Data Cleansing Rule": row.data_cleansing_rule,
        "Data Standardization Rule": row.data_standardization_rule,
        "Data Masking/Anonymization Rule": row.data_masking_rule,
        "Data Validation Rule": row.data_validation_rule,
        "Error Handling Rule": row.error_handling_rule,
        "Default Value Handling": row.default_value_handling,
        "Data Quality Checks": row.data_quality_checks,
        "Data Profiling Results": row.data_profiling_results,
        "Data Lineage/Traceability": row.data_lineage,
        "Data Sensitivity/PII Indicator": row.pii_indicator,
        "Mask/Anonymize Sensitive Data": row.mask_sensitive_data,
        "Audit Trail/Change Log": row.audit_trail,
        "Sample Data": row.sample_data,
        "Column Description": row.column_description,
        "Confidence Score": row.confidence,
        "Lineage Path": " -> ".join(row.lineage_path),
    }


def merge_sources(
    source_rows: list[dict[str, Any]],
    target_meta: FieldDef,
    target_table: str,
    mapping_type: str,
    transformation_rule: str,
    business_rule: str,
    lookup_table: str | None,
    confidence: float,
    lineage_path: list[str],
) -> list[dict[str, Any]]:
    if not source_rows:
        source_rows = [{
            "source_table": "",
            "source_column": "",
            "source_dtype": "",
            "source_length": "",
            "source_pk": False,
            "source_fk": False,
            "source_desc": "",
        }]

    rows: list[dict[str, Any]] = []
    for src in source_rows:
        full_lineage_path = list(lineage_path)
        target_node = f"{target_table}.{target_meta.name}"
        if not full_lineage_path or full_lineage_path[-1] != target_node:
            full_lineage_path.append(target_node)

        lineage = ColumnLineage(
            source_table=src.get("source_table", ""),
            source_column=src.get("source_column", ""),
            source_dtype=src.get("source_dtype", ""),
            source_length=src.get("source_length", ""),
            source_pk=bool(src.get("source_pk", False)),
            source_fk=bool(src.get("source_fk", False)),
            source_desc=src.get("source_desc", ""),
            target_table=target_table,
            target_column=target_meta.name,
            target_dtype=target_meta.dtype,
            target_length=target_meta.length,
            target_pk=target_meta.pk,
            target_fk=target_meta.fk,
            target_desc=target_meta.description,
            mapping_type=mapping_type,
            transformation_rule=transformation_rule,
            business_rule=business_rule or "None",
            data_conversion_rule="None",
            aggregation_logic=transformation_rule if mapping_type == "Aggregation" else "None",
            lookup_table=lookup_table,
            data_enrichment_rule="None",
            data_cleansing_rule="None",
            data_standardization_rule="None",
            data_masking_rule="None",
            data_validation_rule="None",
            error_handling_rule="Log error",
            default_value_handling="None",
            data_quality_checks="Completeness",
            data_profiling_results="Profiled",
            data_lineage="Tracked",
            pii_indicator=False,
            mask_sensitive_data=False,
            audit_trail="Enabled",
            sample_data="",
            column_description=src.get("source_desc") or target_meta.description or target_meta.name,
            confidence=confidence,
            lineage_path=full_lineage_path,
        )
        rows.append(build_sttm_row_from_lineage(lineage))
    return rows


def coerce_llm_json(text: Any) -> dict[str, Any]:
    if isinstance(text, dict):
        return text
    if not text:
        return {}
    text = str(text).strip()

    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            return parsed
        if isinstance(parsed, list):
            return {"sttm_mappings": parsed}
    except Exception:
        pass

    fenced_blocks = re.findall(r"```(?:json)?\s*(.*?)```", text, flags=re.IGNORECASE | re.DOTALL)
    for block in fenced_blocks:
        try:
            parsed = json.loads(block)
            if isinstance(parsed, dict):
                return parsed
            if isinstance(parsed, list):
                return {"sttm_mappings": parsed}
        except Exception:
            continue

    match = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if match:
        try:
            parsed = json.loads(match.group(0))
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass

    return {}


def validate_and_score_rows(rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], float, list[str]]:
    issues: list[str] = []
    valid_rows: list[dict[str, Any]] = []

    for index, row in enumerate(rows, start=1):
        target_column = str(row.get("Target Attribute Name", "")).strip()
        target_table = str(row.get("Target Table Name", "")).strip()
        transformation_rule = normalize_expr(row.get("Transformation Rule", ""))
        mapping_type = str(row.get("Mapping Type", "")).strip() or "Direct"

        if not target_column:
            issues.append(f"Row {index}: missing Target Attribute Name")
            continue

        if mapping_type in {"1:1", "Direct"} and is_literal(transformation_rule):
            row["Mapping Type"] = "Constant"
        elif mapping_type in {"1:1", "Direct"} and is_system_expr(transformation_rule):
            row["Mapping Type"] = "System-derived"

        if ":LKP." in transformation_rule.upper() and not row.get("Lookup/Reference Table Used"):
            issues.append(f"Row {index}: lookup expression found but reference table missing")

        if not target_table:
            issues.append(f"Row {index}: missing Target Table Name")

        valid_rows.append(row)

    quality = 1.0
    if rows:
        quality -= min(0.40, (len(issues) / max(1, len(rows))) * 0.40)
    return valid_rows, max(0.0, quality), issues


def dedupe_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[tuple[str, str, str, str, str, str]] = set()
    output: list[dict[str, Any]] = []
    for row in rows:
        key = (
            str(row.get("Source Table Name", "")).strip().lower(),
            str(row.get("Source Attribute Name", "")).strip().lower(),
            str(row.get("Target Table Name", "")).strip().lower(),
            str(row.get("Target Attribute Name", "")).strip().lower(),
            str(row.get("Transformation Rule", "")).strip().lower(),
            str(row.get("Lookup/Reference Table Used", "")).strip().lower(),
        )
        if key in seen:
            continue
        seen.add(key)
        output.append(row)
    return output


def union_columns(rows: list[dict[str, Any]]) -> list[str]:
    preferred = [
        "Source Table Name",
        "Source Attribute Name",
        "Source Data Type",
        "Source Data Length/Precision",
        "Source Primary Key",
        "Source Foreign Key",
        "Source Default Value",
        "Source Description/Comments",
        "Target Table Name",
        "Target Attribute Name",
        "Target Data Type",
        "Target Data Length/Precision",
        "Target Primary Key",
        "Target Foreign Key",
        "Target Description/Comments",
        "Mapping Type",
        "Transformation Rule",
        "Business Rule Applied",
        "Data Conversion/Format Rule",
        "Aggregation/Calculation Logic",
        "Lookup/Reference Table Used",
        "Data Enrichment Rule",
        "Data Cleansing Rule",
        "Data Standardization Rule",
        "Data Masking/Anonymization Rule",
        "Data Validation Rule",
        "Error Handling Rule",
        "Default Value Handling",
        "Data Quality Checks",
        "Data Profiling Results",
        "Data Lineage/Traceability",
        "Data Sensitivity/PII Indicator",
        "Mask/Anonymize Sensitive Data",
        "Audit Trail/Change Log",
        "Sample Data",
        "Column Description",
        "Confidence Score",
        "Lineage Path",
    ]

    actual: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for column in row.keys():
            if column not in seen:
                seen.add(column)
                actual.append(column)

    ordered = [column for column in preferred if column in seen]
    extras = [column for column in actual if column not in ordered]
    return ordered + extras