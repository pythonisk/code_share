from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)


def read_file_content(file_path: str) -> str:
    ext = Path(file_path).suffix.lower()
    lines: list[str] = []

    if ext in (".xlsx", ".xls"):
        try:
            engine = "openpyxl" if ext == ".xlsx" else "xlrd"
            excel_file = pd.ExcelFile(file_path, engine=engine)
            logger.info("Excel sheets in '%s': %s", Path(file_path).name, excel_file.sheet_names)

            for sheet in excel_file.sheet_names:
                dataframe = pd.read_excel(file_path, sheet_name=sheet, dtype=str, keep_default_na=False, engine=engine)
                if dataframe.empty:
                    continue
                lines.append(f"[Sheet: {sheet}] Columns: {' | '.join(map(str, dataframe.columns.tolist()))}")
                for _, row in dataframe.iterrows():
                    row_text = " | ".join(
                        f"{col}: {val}"
                        for col, val in row.items()
                        if str(val).strip() not in ("", "nan", "None", "NaN")
                    )
                    if row_text.strip():
                        lines.append(row_text)
        except Exception as exc:
            logger.error("Excel read error '%s': %s", file_path, exc)

    elif ext == ".csv":
        try:
            dataframe = pd.read_csv(file_path, dtype=str, keep_default_na=False)
            lines.append(f"[CSV] Columns: {' | '.join(map(str, dataframe.columns.tolist()))}")
            for _, row in dataframe.iterrows():
                row_text = " | ".join(
                    f"{col}: {val}"
                    for col, val in row.items()
                    if str(val).strip() not in ("", "nan", "None", "NaN")
                )
                if row_text.strip():
                    lines.append(row_text)
        except Exception as exc:
            logger.error("CSV read error '%s': %s", file_path, exc)

    else:
        try:
            lines.append(Path(file_path).read_text(encoding="utf-8", errors="ignore"))
        except Exception as exc:
            logger.error("Text read error '%s': %s", file_path, exc)

    return "\n".join(lines)