from __future__ import annotations

import logging
import traceback

from .helpers import (
    MIN_STRUCTURED_CONFIDENCE,
    MIN_STRUCTURED_COVERAGE,
    dedupe_rows,
    unique_preserve,
    validate_and_score_rows,
)
from .models import ParseResult
from .parsers import (
    EmbeddedStructureParser,
    InformaticaPowerMartXmlParser,
    JsonMappingParser,
    LlmFallbackParser,
    NaturalLanguageMappingParser,
    PySparkMappingParser,
    SnowparkJavaMappingParser,
    SqlMappingParser,
    TalendXmlParser,
    TabularMappingParser,
)

logger = logging.getLogger(__name__)


class ParserRegistry:
    def __init__(self) -> None:
        self.parsers = [
            InformaticaPowerMartXmlParser(),
            TalendXmlParser(),
            JsonMappingParser(),
            SnowparkJavaMappingParser(),
            PySparkMappingParser(),
            SqlMappingParser(),
            TabularMappingParser(),
            NaturalLanguageMappingParser(),
            EmbeddedStructureParser(),
            LlmFallbackParser(),
        ]

    def parse_file(self, file_name: str, content: str) -> ParseResult:
        candidates: list[ParseResult] = []

        for parser in self.parsers:
            try:
                if parser.can_handle(file_name, content):
                    result = parser.parse(file_name, content)
                    candidates.append(result)
                    logger.info(
                        "[%s] parser=%s rows=%d confidence=%.2f coverage=%.2f",
                        file_name,
                        result.parser_name,
                        len(result.rows),
                        result.confidence,
                        result.coverage,
                    )
            except Exception as exc:
                logger.error("Parser %s failed for %s: %s", getattr(parser, "name", parser.__class__.__name__), file_name, exc)
                logger.debug(traceback.format_exc())

        if not candidates:
            return ParseResult([], "none", 0.0, 0.0, ["No parser handled file"])

        structured = sorted(
            [candidate for candidate in candidates if candidate.parser_name != "llm_fallback" and candidate.rows],
            key=lambda item: (item.confidence, item.coverage, len(item.rows)),
            reverse=True,
        )
        if structured:
            best = structured[0]
            if best.confidence >= MIN_STRUCTURED_CONFIDENCE and best.coverage >= MIN_STRUCTURED_COVERAGE:
                return best

            llm_results = [candidate for candidate in candidates if candidate.parser_name == "llm_fallback" and candidate.rows]
            if llm_results:
                merged_rows = dedupe_rows(best.rows + llm_results[0].rows)
                validated_rows, _, issues = validate_and_score_rows(merged_rows)
                diagnostics = dict(best.diagnostics or {})
                diagnostics.update({
                    "structured_parser": best.parser_name,
                    "llm_used": True,
                    "structured_rows": len(best.rows),
                    "llm_rows": len(llm_results[0].rows),
                    "merged_rows": len(validated_rows),
                })
                return ParseResult(
                    rows=validated_rows,
                    parser_name=f"hybrid({best.parser_name}+llm)",
                    confidence=min(1.0, max(best.confidence, llm_results[0].confidence) + 0.05),
                    coverage=min(1.0, max(best.coverage, llm_results[0].coverage) + 0.10),
                    gaps=unique_preserve(best.gaps + llm_results[0].gaps + issues),
                    diagnostics=diagnostics,
                )
            return best

        llm_results = sorted(
            [candidate for candidate in candidates if candidate.parser_name == "llm_fallback"],
            key=lambda item: (item.confidence, item.coverage, len(item.rows)),
            reverse=True,
        )
        return llm_results[0] if llm_results else candidates[0]