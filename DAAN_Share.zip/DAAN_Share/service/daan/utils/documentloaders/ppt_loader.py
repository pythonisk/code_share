from __future__ import annotations

from .base_loader import BaseDocumentLoader
from daan.utils.converters.ppt_converter import PptConverter


class PptDocumentLoader(BaseDocumentLoader):
    """PowerPoint loader backed by LangChain UnstructuredPowerPointLoader."""

    @classmethod
    def supported_extensions(cls) -> set[str]:
        return {".ppt", ".pptx"}

    def load_document(self, file_path: str) -> dict:
        extraction_warnings: list[str] = []
        extraction_method = "langchain_unstructured_ppt"
        mode = self.config.get("mode", "elements")
        slides = []
        try:
            from langchain_community.document_loaders import UnstructuredPowerPointLoader

            loader = UnstructuredPowerPointLoader(file_path=file_path, mode=mode)
            docs = loader.load()

            for index, doc in enumerate(docs, start=1):
                metadata = dict(doc.metadata or {})
                slide_number = metadata.get("page_number") or metadata.get("page") or index
                text = doc.page_content or ""
                slides.append(
                    {
                        "slide_number": int(slide_number),
                        "text": text,
                        "char_count": len(text),
                        "metadata": metadata,
                        "has_speaker_notes": False,
                        "speaker_notes": "",
                        "layout_type": str(metadata.get("category") or "unknown"),
                        "shapes_count": 0,
                    }
                )
        except (ImportError, OSError, ValueError) as exc:
            extraction_method = "python_pptx"
            extraction_warnings.append(f"UnstructuredPowerPointLoader unavailable/failed: {exc}")
            slides = self._load_with_python_pptx(file_path=file_path)

        unique_slide_numbers = {
            int(slide["slide_number"])
            for slide in slides
            if slide.get("slide_number") is not None
        }

        full_text = "\n".join(slide["text"] for slide in slides if slide["text"])
        normalized_content = {
            # Kept text_file for immediate compatibility with existing partitioners.
            "type": "text_file",
            "content": full_text,
            "structured_sections": {},
            "slides": slides,
            "summary": {
                "total_slides": len(unique_slide_numbers),
                "total_characters": len(full_text),
                "source_format": "powerpoint",
                "has_animations": False,
                "transitions_present": False,
            },
        }
        return self._build_payload(
            file_path=file_path,
            file_type="ppt",
            content=normalized_content,
            metadata={
                "extraction_method": extraction_method,
                "extraction_warnings": extraction_warnings,
            },
        )

    @staticmethod
    def _load_with_python_pptx(file_path: str) -> list[dict]:
        return PptConverter().convert(file_path=file_path)["slides"]

