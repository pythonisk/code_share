from __future__ import annotations

from abc import ABC, abstractmethod
import os
from pathlib import Path
from typing import Any


class BaseDocumentLoader(ABC):
    """Base contract for document loaders."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}

    @abstractmethod
    def load_document(self, file_path: str) -> dict[str, Any]:
        """Load a single document and return a normalized payload."""
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def supported_extensions(cls) -> set[str]:
        """Return supported extensions including leading dot (e.g. {'.pdf'})."""
        raise NotImplementedError

    @staticmethod
    def _build_payload(
        file_path: str,
        file_type: str,
        content: dict[str, Any],
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        path = Path(file_path)
        resolved_metadata = {
            "loader": file_type,
            "extraction_method": "unknown",
            "extraction_warnings": [],
            "extraction_errors": [],
            "size_bytes": BaseDocumentLoader._safe_size(file_path),
            "source_name": path.name,
            "source_extension": path.suffix.lower(),
        }
        if metadata:
            resolved_metadata.update(metadata)

        return {
            "filename": path.name,
            "file_type": path.suffix.lower(),
            "file_path": str(path),
            "content": content,
            "metadata": resolved_metadata,
        }

    @staticmethod
    def _safe_size(file_path: str) -> int:
        if not file_path:
            return 0
        try:
            return int(os.path.getsize(file_path))
        except OSError:
            return 0
