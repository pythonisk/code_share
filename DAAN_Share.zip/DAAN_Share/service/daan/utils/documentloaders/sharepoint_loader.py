from __future__ import annotations

import os
import logging
import multiprocessing
import tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from queue import Empty

import requests
from dotenv import load_dotenv

from .base_loader import BaseDocumentLoader
from .load_documents import load_document as load_local_document

_GRAPH_BASE = "https://graph.microsoft.com/v1.0"
logger = logging.getLogger(__name__)

_SUPPORTED_FILE_EXTENSIONS = {
    ".c", ".cpp", ".cs", ".csv", ".docx", ".go", ".h", ".hpp", ".htm", ".html",
    ".ini", ".java", ".js", ".json", ".jsx", ".log", ".md", ".pdf", ".php", ".ppt",
    ".pptx", ".properties", ".py", ".rb", ".sql", ".ts", ".tsx", ".txt", ".xls", ".xlsx",
    ".xml", ".yaml", ".yml",
}


def _parse_content_worker(item_name: str, file_path: str, result_queue) -> None:
    warnings: list[str] = []
    try:
        content = SharePointDocumentLoader._parse_local_content(item_name, file_path, warnings)
        result_queue.put((content, warnings))
    except Exception as exc:  # noqa: BLE001
        result_queue.put(("", [f"Could not parse SharePoint file {item_name}: {exc}"]))


class SharePointDocumentLoader(BaseDocumentLoader):
    """SharePoint loader using MSAL client-credentials + Microsoft Graph API."""

    @classmethod
    def supported_extensions(cls) -> set[str]:
        # Source-based loader (SharePoint), not file-extension based.
        return set()

    def load_document(self, file_path: str) -> dict:
        env_creds = self._load_credentials_from_environment()
        config_kwargs = dict(self.config.get("loader_kwargs") or {})
        has_config = bool(config_kwargs)

        tenant_id = str(config_kwargs.pop("tenant_id", None) or env_creds.get("tenant_id") or "")
        client_id = str(config_kwargs.pop("client_id", None) or env_creds.get("client_id") or "")
        client_secret = str(config_kwargs.pop("client_secret", None) or env_creds.get("client_secret") or "")
        site_id = str(config_kwargs.pop("site_id", None) or env_creds.get("site_id") or "")
        site_name = str(config_kwargs.pop("site_name", None) or env_creds.get("site_name") or "")
        folder_path = str(config_kwargs.pop("folder_path", None) or file_path or "")

        credentials_source = "config_dict" if has_config else ("environment" if any(env_creds.values()) else "missing")

        if not all([tenant_id, client_id, client_secret, site_id]):
            raise ValueError(
                "SharePointDocumentLoader requires SHAREPOINT_TENANT_ID, SHAREPOINT_CLIENT_ID, "
                "SHAREPOINT_CLIENT_SECRET, and SHAREPOINT_SITE_ID."
            )

        extraction_warnings: list[str] = []
        token = self._acquire_token(tenant_id, client_id, client_secret)
        drive_id = self._resolve_default_drive_id(token, site_id)
        logger.info("SharePoint ingestion started: folder=%s drive=%s", folder_path, drive_id[:24])
        items = self._list_items(token, drive_id, folder_path, extraction_warnings)
        logger.info("SharePoint traversal complete: folder=%s files=%d", folder_path, len(items))

        documents = []
        for index, item in enumerate(items, start=1):
            item_name = str(item.get("name") or item.get("id") or "sharepoint-item")
            logger.info("SharePoint file %d/%d: downloading %s", index, len(items), item_name)
            item_bytes = self._fetch_item_content(token, drive_id, item["id"], extraction_warnings)
            content = self._parse_downloaded_content(item_name, item_bytes, extraction_warnings)
            logger.info("SharePoint file %d/%d: parsed %s", index, len(items), item_name)
            metadata = {k: v for k, v in item.items() if k != "id"}
            documents.append(
                {
                    "content": content,
                    "metadata": metadata,
                    "sharepoint_id": item.get("id", ""),
                    "modified_by": (item.get("lastModifiedBy") or {}).get("user", {}).get("displayName", ""),
                    "created_date": item.get("createdDateTime", ""),
                    "modified_date": item.get("lastModifiedDateTime", ""),
                }
            )

        normalized_content = {
            "type": "sharepoint_documents",
            "documents": documents,
            "summary": {
                "total_documents": len(documents),
                "site_name": site_name,
                "library_name": drive_id,
                "folder_path_queried": folder_path,
            },
        }
        return self._build_payload(
            file_path=file_path,
            file_type="sharepoint",
            content=normalized_content,
            metadata={
                "extraction_method": "msal_graph_api",
                "extraction_warnings": extraction_warnings,
                "credentials_source": credentials_source,
                "site_name": site_name,
                "library_name": drive_id,
                "folder_path_queried": folder_path,
            },
        )

    def iter_document_batches(self, file_path: str, batch_size: int = 25):
        """Yield parsed SharePoint payloads as bounded batches."""
        env_creds = self._load_credentials_from_environment()
        config_kwargs = dict(self.config.get("loader_kwargs") or {})
        tenant_id = str(config_kwargs.pop("tenant_id", None) or env_creds.get("tenant_id") or "")
        client_id = str(config_kwargs.pop("client_id", None) or env_creds.get("client_id") or "")
        client_secret = str(config_kwargs.pop("client_secret", None) or env_creds.get("client_secret") or "")
        site_id = str(config_kwargs.pop("site_id", None) or env_creds.get("site_id") or "")
        site_name = str(config_kwargs.pop("site_name", None) or env_creds.get("site_name") or "")
        folder_path = str(config_kwargs.pop("folder_path", None) or file_path or "")

        if not all([tenant_id, client_id, client_secret, site_id]):
            raise ValueError(
                "SharePointDocumentLoader requires SHAREPOINT_TENANT_ID, SHAREPOINT_CLIENT_ID, "
                "SHAREPOINT_CLIENT_SECRET, and SHAREPOINT_SITE_ID."
            )

        batch_size = max(1, int(batch_size))
        skip_sources = {str(name) for name in (self.config.get("skip_sources") or ())}
        max_files = config_kwargs.pop("max_files", None)
        max_files = int(max_files) if max_files else None
        max_candidates = config_kwargs.pop("max_candidates", None)
        max_candidates = int(max_candidates) if max_candidates else None
        parse_timeout_seconds = float(config_kwargs.pop("parse_timeout_seconds", 60) or 0)
        token = self._acquire_token(tenant_id, client_id, client_secret)
        drive_id = self._resolve_default_drive_id(token, site_id)
        logger.info(
            "SharePoint batch ingestion started: folder=%s batch_size=%d skipping=%d",
            folder_path,
            batch_size,
            len(skip_sources),
        )

        emitted = 0
        for batch_number, items in enumerate(
            self._iter_item_batches(token, drive_id, folder_path, batch_size, skip_sources, max_candidates), start=1
        ):
            # Download/parse the batch in parallel, but emit one payload per file so
            # each chunk keeps its own SharePoint filename for citations.
            with ThreadPoolExecutor(max_workers=8) as executor:
                futures = {}
                for item in items:
                    item_name = str(item.get("name") or item.get("id") or "sharepoint-item")
                    logger.info("SharePoint file download/parse started: batch=%d name=%s", batch_number, item_name)
                    futures[executor.submit(self._download_and_parse, token, drive_id, item, parse_timeout_seconds)] = item
                parsed = []
                for future in as_completed(futures):
                    item = futures[future]
                    item_name = str(item.get("name") or item.get("id") or "sharepoint-item")
                    try:
                        parsed.append(future.result())
                        logger.info("SharePoint file download/parse completed: batch=%d name=%s", batch_number, item_name)
                    except Exception as exc:
                        logger.exception(
                            "SharePoint file failed: name=%s id=%s",
                            item_name,
                            item.get("id", ""),
                        )
                        parsed.append((item, item_name, "", [f"Could not process SharePoint file {item_name}: {exc}"]))

            for item, item_name, content, warnings in parsed:
                source_identity = self._source_identity(item, folder_path)
                if not str(content).strip():
                    if warnings:
                        logger.warning(
                            "SharePoint file skipped (empty extracted text): name=%s warnings=%s",
                            item_name,
                            "; ".join(str(warning) for warning in warnings),
                        )
                    else:
                        logger.warning(
                            "SharePoint file skipped (empty extracted text): name=%s",
                            item_name,
                        )
                    continue
                emitted += 1
                yield self._build_payload(
                    file_path=source_identity,
                    file_type="sharepoint",
                    content={
                        "type": "sharepoint_documents",
                        "documents": [
                            {
                                "content": content,
                                "metadata": {k: v for k, v in item.items() if k != "id"},
                                "sharepoint_id": item.get("id", ""),
                                "modified_by": (item.get("lastModifiedBy") or {}).get("user", {}).get("displayName", ""),
                                "created_date": item.get("createdDateTime", ""),
                                "modified_date": item.get("lastModifiedDateTime", ""),
                            }
                        ],
                        "summary": {
                            "total_documents": 1,
                            "site_name": site_name,
                            "library_name": drive_id,
                            "folder_path_queried": folder_path,
                        },
                    },
                    metadata={
                        "extraction_method": "msal_graph_api_batch",
                        "extraction_warnings": warnings,
                        "credentials_source": "environment",
                        "site_name": site_name,
                        "library_name": drive_id,
                        "folder_path_queried": folder_path,
                        "batch_number": batch_number,
                        "sharepoint_name": item_name,
                        "sharepoint_source": source_identity,
                    },
                )
                if max_files is not None and emitted >= max_files:
                    logger.info("SharePoint ingestion stopping early: max_files=%d reached", max_files)
                    return
            logger.info(
                "SharePoint batch parsed: batch=%d files=%d emitted_total=%d",
                batch_number,
                len(parsed),
                emitted,
            )

    def _download_and_parse(
        self,
        token: str,
        drive_id: str,
        item: dict,
        parse_timeout_seconds: float,
    ) -> tuple[dict, str, object, list[str]]:
        warnings: list[str] = []
        item_name = str(item.get("name") or item.get("id") or "sharepoint-item")
        try:
            item_bytes = self._fetch_item_content(token, drive_id, item["id"], warnings)
            content, parse_warnings = self._parse_downloaded_content_with_timeout(
                item_name,
                item_bytes,
                parse_timeout_seconds,
            )
            warnings.extend(parse_warnings)
        except Exception as exc:
            logger.exception(
                "SharePoint download/parse failed: name=%s id=%s",
                item_name,
                item.get("id", ""),
            )
            warnings.append(f"Could not process SharePoint file {item_name}: {exc}")
            content = ""
        return item, item_name, content, warnings

    @staticmethod
    def _parse_downloaded_content_with_timeout(
        item_name: str,
        item_bytes: bytes,
        timeout_seconds: float,
    ) -> tuple[object, list[str]]:
        if timeout_seconds <= 0:
            warnings: list[str] = []
            return SharePointDocumentLoader._parse_downloaded_content(item_name, item_bytes, warnings), warnings

        try:
            with tempfile.NamedTemporaryFile(suffix=Path(item_name).suffix, delete=False) as handle:
                handle.write(item_bytes)
                temporary_path = handle.name

            context = multiprocessing.get_context("spawn")
            result_queue = context.Queue()
            process = context.Process(target=_parse_content_worker, args=(item_name, temporary_path, result_queue))
            process.start()
            process.join(timeout_seconds)
            if process.is_alive():
                process.terminate()
                process.join()
                return "", [f"SharePoint file parse timed out after {timeout_seconds:g}s: {item_name}"]

            try:
                return result_queue.get(timeout=1)
            except Empty:
                return "", [f"SharePoint file parser exited without a result: {item_name}"]
        finally:
            if "result_queue" in locals():
                result_queue.close()
                result_queue.join_thread()
            if "temporary_path" in locals():
                Path(temporary_path).unlink(missing_ok=True)

    @classmethod
    def _load_credentials_from_environment(cls) -> dict[str, str]:
        load_dotenv(Path(__file__).resolve().parents[4] / "config" / ".env")
        key_map = {
            "SHAREPOINT_TENANT_ID": "tenant_id",
            "SHAREPOINT_CLIENT_ID": "client_id",
            "SHAREPOINT_CLIENT_SECRET": "client_secret",
            "SHAREPOINT_SITE_ID": "site_id",
            "SHAREPOINT_SITE_NAME": "site_name",
        }
        return {kwarg: (os.getenv(env_key) or "").strip() for env_key, kwarg in key_map.items()}

    @staticmethod
    def _acquire_token(tenant_id: str, client_id: str, client_secret: str) -> str:
        try:
            import msal
        except ImportError as exc:
            raise ImportError("msal is required: pip install msal") from exc
        app = msal.ConfidentialClientApplication(
            client_id,
            authority=f"https://login.microsoftonline.com/{tenant_id}",
            client_credential=client_secret,
        )
        result = app.acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])
        if "access_token" not in result:
            raise RuntimeError(
                f"SharePoint token acquisition failed: {result.get('error_description') or result.get('error')}"
            )
        return result["access_token"]

    @staticmethod
    def _resolve_default_drive_id(token: str, site_id: str) -> str:
        """Fetches the default document library drive ID from SHAREPOINT_SITE_ID via Graph API."""
        resp = requests.get(
            f"{_GRAPH_BASE}/sites/{site_id}/drive",
            headers={"Authorization": f"Bearer {token}"},
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()["id"]

    @staticmethod
    def _list_items(token: str, drive_id: str, folder_path: str, warnings: list[str]) -> list[dict]:
        headers = {"Authorization": f"Bearer {token}"}
        if folder_path:
            pending_folders = [
                f"{_GRAPH_BASE}/drives/{drive_id}/root:/{folder_path.lstrip('/')}:/children"
            ]
        else:
            pending_folders = [f"{_GRAPH_BASE}/drives/{drive_id}/root/children"]

        items: list[dict] = []
        seen_files: set[str] = set()
        seen_folders: set[str] = set()
        folder_requests = 0
        with ThreadPoolExecutor(max_workers=8) as executor:
            while pending_folders:
                batch = pending_folders[:8]
                del pending_folders[:8]
                futures = {
                    executor.submit(SharePointDocumentLoader._fetch_folder_items, url, headers): url
                    for url in batch
                }
                for future in as_completed(futures):
                    url = futures[future]
                    folder_requests += 1
                    logger.info("SharePoint folder request %d complete: %s", folder_requests, url)
                    try:
                        folder_items, folder_warnings = future.result()
                    except Exception as exc:
                        warnings.append(f"Graph API list failed: {exc}")
                        continue

                    warnings.extend(folder_warnings)
                    for item in folder_items:
                        item_id = str(item.get("id") or "")
                        if "file" in item:
                            if item_id and item_id not in seen_files:
                                seen_files.add(item_id)
                                items.append(item)
                        elif "folder" in item and item_id and item_id not in seen_folders:
                            seen_folders.add(item_id)
                            pending_folders.append(
                                f"{_GRAPH_BASE}/drives/{drive_id}/items/{item_id}/children"
                            )

                    logger.info(
                        "SharePoint folder batch progress: pending=%d files_found=%d",
                        len(pending_folders),
                        len(items),
                    )
        return items

    @staticmethod
    def _iter_item_batches(
        token: str,
        drive_id: str,
        folder_path: str,
        batch_size: int,
        skip_sources: set[str] | None = None,
        max_candidates: int | None = None,
    ):
        headers = {"Authorization": f"Bearer {token}"}
        already_indexed = skip_sources or set()
        pending_folders = [
            f"{_GRAPH_BASE}/drives/{drive_id}/root:/{folder_path.lstrip('/')}:/children"
            if folder_path
            else f"{_GRAPH_BASE}/drives/{drive_id}/root/children"
        ]
        seen_files: set[str] = set()
        seen_folders: set[str] = set()
        file_batch: list[dict] = []
        folder_requests = 0
        selected_candidates = 0
        with ThreadPoolExecutor(max_workers=8) as executor:
            while pending_folders:
                current = pending_folders[:8]
                del pending_folders[:8]
                futures = [
                    executor.submit(SharePointDocumentLoader._fetch_folder_items, url, headers)
                    for url in current
                ]
                for future in as_completed(futures):
                    folder_requests += 1
                    logger.info(
                        "SharePoint batch folder request %d complete: pending=%d files_seen=%d",
                        folder_requests,
                        len(pending_folders),
                        len(seen_files),
                    )
                    folder_items, folder_warnings = future.result()
                    if folder_warnings:
                        logger.warning("SharePoint folder warnings: %s", folder_warnings)
                    for item in folder_items:
                        item_id = str(item.get("id") or "")
                        if "file" in item and item_id and item_id not in seen_files:
                            seen_files.add(item_id)
                            if Path(str(item.get("name") or "")).suffix.lower() not in _SUPPORTED_FILE_EXTENSIONS:
                                continue
                            source_identity = SharePointDocumentLoader._source_identity(item, folder_path)
                            item_name = str(item.get("name") or "").strip()
                            legacy_path_match = any(
                                str(existing).replace("/", "\\").lower().endswith(f"\\{item_name.lower()}")
                                for existing in already_indexed
                            )
                            if source_identity in already_indexed or item_name in already_indexed or legacy_path_match:
                                continue
                            file_batch.append(item)
                            selected_candidates += 1
                            if len(file_batch) >= batch_size:
                                yield file_batch
                                file_batch = []
                            if max_candidates is not None and selected_candidates >= max_candidates:
                                return
                        elif "folder" in item and item_id and item_id not in seen_folders:
                            seen_folders.add(item_id)
                            pending_folders.append(
                                f"{_GRAPH_BASE}/drives/{drive_id}/items/{item_id}/children"
                            )
        if file_batch:
            yield file_batch

    @staticmethod
    def _source_identity(item: dict, folder_path: str = "") -> str:
        """Return a stable source key that distinguishes same-named files."""
        name = str(item.get("name") or "").strip()
        parent_path = str((item.get("parentReference") or {}).get("path") or "").strip()
        marker = ":/"
        if marker in parent_path:
            parent_path = parent_path.split(marker, 1)[1].strip("/")
        else:
            parent_path = parent_path.strip("/")
        if parent_path.lower() == "root":
            parent_path = ""
        parent_path = parent_path.replace("/", "\\")
        configured_root = str(folder_path).strip("/\\")
        if configured_root and parent_path.lower() != configured_root.lower() and not parent_path.lower().startswith(
            f"{configured_root.lower()}\\"
        ):
            parent_path = "\\".join(part for part in (configured_root, parent_path) if part)
        path = "\\".join(part.strip("/\\") for part in (parent_path, name) if part.strip("/\\"))
        return path or str(item.get("id") or name)

    @staticmethod
    def _fetch_folder_items(url: str, headers: dict[str, str]) -> tuple[list[dict], list[str]]:
        items: list[dict] = []
        warnings: list[str] = []
        while url:
            resp = requests.get(url, headers=headers, timeout=30)
            if not resp.ok:
                warnings.append(f"Graph API list failed ({resp.status_code}): {resp.text[:200]}")
                break
            data = resp.json()
            items.extend(data.get("value", []))
            url = data.get("@odata.nextLink")
        return items, warnings

    @staticmethod
    def _fetch_item_content(token: str, drive_id: str, item_id: str, warnings: list[str]) -> bytes:
        resp = requests.get(
            f"{_GRAPH_BASE}/drives/{drive_id}/items/{item_id}/content",
            headers={"Authorization": f"Bearer {token}"},
            timeout=60,
            allow_redirects=True,
        )
        if not resp.ok:
            warnings.append(f"Could not download item {item_id} ({resp.status_code})")
            return b""
        return resp.content

    @staticmethod
    def _parse_downloaded_content(item_name: str, item_bytes: bytes, warnings: list[str]) -> object:
        suffix = Path(item_name).suffix.lower()
        if not item_bytes:
            return ""

        try:
            with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as handle:
                handle.write(item_bytes)
                temporary_path = handle.name
            try:
                return SharePointDocumentLoader._parse_local_content(item_name, temporary_path, warnings)
            finally:
                Path(temporary_path).unlink(missing_ok=True)
        except (OSError, ValueError, ImportError) as exc:
            warnings.append(f"Could not parse SharePoint file {item_name}: {exc}")
            return ""

    @staticmethod
    def _parse_local_content(item_name: str, file_path: str, warnings: list[str]) -> object:
        payload = load_local_document(file_path)
        parsed_content = payload.get("content", {})
        extraction_warnings = (payload.get("metadata") or {}).get("extraction_warnings") or []
        warnings.extend(str(warning) for warning in extraction_warnings if warning)
        try:
            from daan.rag.indexing.rag_document_loader import RagDocumentLoaderAdapter

            return RagDocumentLoaderAdapter._extract_text(parsed_content)
        except (AttributeError, TypeError, ValueError):
            warnings.append(f"Could not normalize SharePoint file {item_name} content")
            return str(parsed_content)
