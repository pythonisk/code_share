from __future__ import annotations

from .base_loader import BaseDocumentLoader


class ExcelDocumentLoader(BaseDocumentLoader):
    """Excel loader backed by pandas."""

    @classmethod
    def supported_extensions(cls) -> set[str]:
        return {".xlsx", ".xls"}

    def load_document(self, file_path: str) -> dict:
        extraction_warnings: list[str] = []
        extraction_method = "pandas_read_excel"

        try:
            sheets_payload, sheet_names, per_sheet_row_counts = self._read_sheets_with_pandas(file_path=file_path)
        except Exception as exc:  # Malformed Office files can raise parser-specific exceptions.
            sheets_payload, sheet_names, per_sheet_row_counts = {}, [], {}
            extraction_warnings.append(f"Excel extraction failed: {exc}")

        normalized_content = {
            "type": "excel_workbook",
            "sheets": sheets_payload,
            "sheet_names": sheet_names,
            "summary": {
                "total_sheets": len(sheet_names),
                "elements": 0,
                "per_sheet_row_counts": per_sheet_row_counts,
            },
        }
        return self._build_payload(
            file_path=file_path,
            file_type="excel",
            content=normalized_content,
            metadata={
                "extraction_method": extraction_method,
                "extraction_warnings": extraction_warnings,
            },
        )

    @staticmethod
    def _read_sheets_with_pandas(file_path: str) -> tuple[dict, list[str], dict[str, int]]:
        try:
            import pandas as pd
        except ImportError as exc:
            raise ImportError("ExcelDocumentLoader requires pandas for sheet extraction. Install with: pip install pandas") from exc

        workbook = pd.read_excel(file_path, sheet_name=None)
        sheets_payload: dict[str, dict] = {}
        sheet_names: list[str] = []
        per_sheet_row_counts: dict[str, int] = {}

        for sheet_name, frame in workbook.items():
            normalized_name = str(sheet_name)
            sheet_names.append(normalized_name)
            normalized_frame = frame.fillna("")
            original_columns = list(normalized_frame.columns)
            columns = [str(col) for col in original_columns]
            table_rows = []
            for _, record in normalized_frame.iterrows():
                # Positional zip (not label lookup): survives duplicate/numeric
                # Excel headers that don't round-trip through str() as the same key.
                row_map = {str(col): str(value) for col, value in zip(original_columns, record.values)}
                table_rows.append({"content": row_map, "metadata": {"sheet_name": normalized_name}})

            per_sheet_row_counts[normalized_name] = len(table_rows)
            sheets_payload[normalized_name] = {
                "sheet_name": normalized_name,
                "tables": [
                    {
                        "table_name": f"{normalized_name}_table",
                        "table_type": "tabular",
                        "rows": table_rows,
                        "columns": columns,
                        "shape": [len(table_rows), len(columns)],
                    }
                ],
                "sheet_analysis": {"detected_type": "data_table" if table_rows else "empty"},
                "total_tables": 1,
            }

        return sheets_payload, sheet_names, per_sheet_row_counts
