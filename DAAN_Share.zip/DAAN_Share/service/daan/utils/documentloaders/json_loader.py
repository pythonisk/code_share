from __future__ import annotations

import json

from .base_loader import BaseDocumentLoader


class JsonDocumentLoader(BaseDocumentLoader):
    """JSON loader backed by LangChain JSONLoader with safe fallback parsing."""

    @classmethod
    def supported_extensions(cls) -> set[str]:
        return {".json"}

    def load_document(self, file_path: str) -> dict:
        docs = []
        extraction_warnings: list[str] = []
        parse_method = "builtin"
        # JSONLoader can require jq; keep fallback to avoid hard failure when jq is unavailable.
        try:
            from langchain_community.document_loaders import JSONLoader

            loader = JSONLoader(file_path=file_path, jq_schema=".", text_content=False)
            docs = loader.load()
            parse_method = "jq"
        except (ImportError, OSError, ValueError, TypeError) as exc:
            extraction_warnings.append(f"JSONLoader unavailable/failed: {exc}")
            docs = []

        if docs:
            data = [doc.page_content for doc in docs]
        else:
            with open(file_path, "r", encoding="utf-8") as handle:
                data = json.load(handle)

        max_depth = self._max_depth(data)
        if isinstance(data, dict):
            keys_at_root = [str(key) for key in data.keys()]
        else:
            keys_at_root = []

        normalized_content = {
            "type": "json_file",
            "data": data,
            "summary": {
                "records": len(data) if isinstance(data, list) else 1,
                "parse_method": parse_method,
                "keys_at_root": keys_at_root,
                "max_nesting_depth": max_depth,
                "has_arrays": self._has_arrays(data),
            },
        }
        return self._build_payload(
            file_path=file_path,
            file_type="json",
            content=normalized_content,
            metadata={
                "extraction_method": "langchain_jsonloader" if parse_method == "jq" else "builtin_json",
                "extraction_warnings": extraction_warnings,
            },
        )

    @classmethod
    def _max_depth(cls, value: object, current: int = 0) -> int:
        if isinstance(value, dict):
            if not value:
                return current + 1
            return max(cls._max_depth(item, current + 1) for item in value.values())
        if isinstance(value, list):
            if not value:
                return current + 1
            return max(cls._max_depth(item, current + 1) for item in value)
        return current

    @classmethod
    def _has_arrays(cls, value: object) -> bool:
        if isinstance(value, list):
            return True
        if isinstance(value, dict):
            return any(cls._has_arrays(item) for item in value.values())
        return False
