from __future__ import annotations

from .base_loader import BaseDocumentLoader


class DocxDocumentLoader(BaseDocumentLoader):
    """DOCX loader backed by LangChain Docx2txtLoader."""

    @classmethod
    def supported_extensions(cls) -> set[str]:
        return {".docx"}

    def load_document(self, file_path: str) -> dict:
        extraction_warnings: list[str] = []
        extraction_method = "langchain_docx2txt"
        text = ""
        paragraph_count = 0
        table_data: list[dict] = []
        hyperlinks: list[dict] = []
        image_count = 0
        core_props: dict[str, str] = {}

        try:
            from langchain_community.document_loaders import Docx2txtLoader

            loader = Docx2txtLoader(file_path)
            docs = loader.load()
            text = "\n\n".join(doc.page_content for doc in docs if doc.page_content)
            paragraph_count = max(1, len([line for line in text.splitlines() if line.strip()]))
        except (ImportError, OSError, ValueError) as exc:
            extraction_warnings.append(f"LangChain Docx2txtLoader unavailable/failed: {exc}")
            docs = []

        fallback = self._extract_with_python_docx(file_path)
        paragraph_count = max(paragraph_count, fallback["paragraph_count"])
        table_data = fallback["tables"]
        hyperlinks = fallback["hyperlinks"]
        image_count = fallback["image_count"]
        core_props = fallback["core_props"]

        if not text:
            extraction_method = "python_docx"
            text = fallback["text"]

        normalized_content = {
            "type": "docx_file",
            "content": text,
            "main_document_content": text,
            "structured_sections": {},
            "tables": table_data,
            "hyperlinks": hyperlinks,
            "summary": {
                "total_documents": len(docs),
                "total_characters": len(text),
                "paragraph_count": paragraph_count,
                "table_count": len(table_data),
                "has_images": image_count > 0,
                "image_count": image_count,
                "metadata": core_props,
            },
        }
        return self._build_payload(
            file_path=file_path,
            file_type="docx",
            content=normalized_content,
            metadata={
                "extraction_method": extraction_method,
                "extraction_warnings": extraction_warnings,
            },
        )

    @staticmethod
    def _extract_with_python_docx(file_path: str) -> dict:
        try:
            from docx import Document
        except ImportError:
            return {
                "text": "",
                "paragraph_count": 0,
                "tables": [],
                "hyperlinks": [],
                "image_count": 0,
                "core_props": {},
            }

        document = Document(file_path)
        paragraphs = [paragraph.text for paragraph in document.paragraphs if paragraph.text.strip()]
        text = "\n\n".join(paragraphs)

        tables: list[dict] = []
        for table_index, table in enumerate(document.tables, start=1):
            rows = []
            for row in table.rows:
                rows.append([cell.text for cell in row.cells])
            tables.append({"table_index": table_index, "rows": rows})

        hyperlink_entries: list[dict] = []
        rels = getattr(document.part, "rels", {})
        for rel in rels.values():
            target = str(getattr(rel, "target_ref", "") or "")
            if target.startswith("http"):
                hyperlink_entries.append({"text": "", "url": target})

        image_count = len(getattr(document.part, "_rels", {}))
        core = document.core_properties
        core_props = {
            "author": str(getattr(core, "author", "") or ""),
            "created": str(getattr(core, "created", "") or ""),
            "modified": str(getattr(core, "modified", "") or ""),
        }

        return {
            "text": text,
            "paragraph_count": len(paragraphs),
            "tables": tables,
            "hyperlinks": hyperlink_entries,
            "image_count": image_count,
            "core_props": core_props,
        }
