from __future__ import annotations

import logging

from .base_loader import BaseDocumentLoader

logger = logging.getLogger(__name__)


class PdfDocumentLoader(BaseDocumentLoader):
    """PDF loader backed by unstructured with pypdf fallback."""

    @classmethod
    def supported_extensions(cls) -> set[str]:
        return {".pdf"}

    def load_document(self, file_path: str) -> dict:
        pages: list[dict] = []
        extraction_warnings: list[str] = []
        extraction_method = "unstructured"
        producer = ""
        encrypted = False
        tables_found: list[dict] = []

        try:
            from unstructured.partition.pdf import partition_pdf

            # Try fast (direct text extraction) first; fall back to hi_res
            # (layout + OCR) only if fast yields sparse text (scanned PDF).
            elements = partition_pdf(filename=file_path, strategy="fast")
            total_chars = sum(len(el.text or "") for el in elements)
            if not elements or total_chars < 50:
                extraction_method = "unstructured_hi_res"
                elements = partition_pdf(filename=file_path, strategy="hi_res")
            else:
                extraction_method = "unstructured_fast"

            page_map: dict[int, list[str]] = {}
            for el in elements:
                page_num = int(getattr(el.metadata, "page_number", 1) or 1)
                page_map.setdefault(page_num, []).append(el.text or "")
                if type(el).__name__ == "Table":
                    tables_found.append({"page": page_num, "text": el.text or ""})

            for page_num in sorted(page_map):
                text = "\n".join(page_map[page_num])
                pages.append(
                    {
                        "page_number": page_num,
                        "text": text,
                        "tables": [t for t in tables_found if t["page"] == page_num],
                        "char_count": len(text),
                        "rotation": 0,
                        "extraction_status": "ok" if text else "empty",
                        "has_images": False,
                        "detected_font_sizes": [],
                    }
                )
        except (ImportError, OSError, ValueError) as exc:
            extraction_method = "pypdf_reader"
            extraction_warnings.append(f"unstructured unavailable/failed: {exc}")
            logger.warning("unstructured PDF parsing failed for '%s'; falling back to pypdf: %s", file_path, exc)
            pages, producer, encrypted = self._load_with_pypdf(file_path)

        full_text = "\n".join(page["text"] for page in pages if page["text"])
        avg_char_count = (sum(int(page.get("char_count", 0)) for page in pages) / max(len(pages), 1)) if pages else 0
        normalized_content = {
            "type": "pdf_file",
            "content": full_text,
            "structured_sections": {},
            "pages": pages,
            "summary": {
                "total_pages": len(pages),
                "total_characters": len(full_text),
                "is_scanned_image": bool(pages) and avg_char_count < 20,
                "table_extraction_status": "extracted" if tables_found else "none_found",
                "producer": producer,
                "encryption_status": "encrypted" if encrypted else "none",
            },
        }
        return self._build_payload(
            file_path=file_path,
            file_type="pdf",
            content=normalized_content,
            metadata={
                "extraction_method": extraction_method,
                "extraction_warnings": extraction_warnings,
            },
        )

    @staticmethod
    def _load_with_pypdf(file_path: str) -> tuple[list[dict], str, bool]:
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise ImportError("PdfDocumentLoader fallback requires pypdf. Install with: pip install pypdf") from exc

        reader = PdfReader(file_path)
        metadata = reader.metadata or {}
        pages: list[dict] = []
        for index, page in enumerate(reader.pages, start=1):
            text = page.extract_text() or ""
            rotation = page.get("/Rotate", 0)
            pages.append(
                {
                    "page_number": index,
                    "text": text,
                    "tables": [],
                    "char_count": len(text),
                    "rotation": int(rotation) if str(rotation).isdigit() else 0,
                    "extraction_status": "ok" if text else "empty",
                    "has_images": False,
                    "detected_font_sizes": [],
                }
            )

        producer = str(getattr(metadata, "producer", "") or metadata.get("/Producer") or "")
        return pages, producer, bool(reader.is_encrypted)
