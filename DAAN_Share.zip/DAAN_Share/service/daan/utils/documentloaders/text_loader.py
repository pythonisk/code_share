from __future__ import annotations

import re
from pathlib import Path

from .base_loader import BaseDocumentLoader
from daan.utils.converters.common_text_utils import extract_html_text


class TextDocumentLoader(BaseDocumentLoader):
    """Text/markdown loader backed by LangChain TextLoader."""

    @classmethod
    def supported_extensions(cls) -> set[str]:
        return {
            ".txt",
            ".md",
            ".log",
            ".html",
            ".htm",
            ".xml",
            ".yml",
            ".yaml",
            ".properties",
            ".ini",
            ".cs",
            ".java",
            ".py",
            ".js",
            ".ts",
            ".jsx",
            ".tsx",
            ".go",
            ".rb",
            ".php",
            ".c",
            ".cpp",
            ".h",
            ".hpp",
            ".sql",
        }

    def load_document(self, file_path: str) -> dict:
        extraction_warnings: list[str] = []
        extraction_method = "langchain_textloader"
        encoding = str(self.config.get("encoding", "utf-8"))

        try:
            from langchain_community.document_loaders import TextLoader

            loader = TextLoader(file_path, encoding=encoding, autodetect_encoding=True)
            docs = loader.load()
            content = "\n\n".join(doc.page_content for doc in docs if doc.page_content)
            total_documents = len(docs)
        except (ImportError, OSError, UnicodeDecodeError, ValueError) as exc:
            extraction_method = "builtin_open"
            extraction_warnings.append(f"LangChain TextLoader unavailable/failed: {exc}")
            content, encoding = self._read_text_with_fallback(file_path=file_path, preferred_encoding=encoding)
            total_documents = 1

        source_extension = Path(file_path).suffix.lower()
        if source_extension in {".html", ".htm"}:
            extraction_method = f"{extraction_method}_html_visible_text"
            content = extract_html_text(content)

        non_empty_lines = [line for line in content.splitlines() if line.strip()]
        has_sections = bool(re.search(r"(^\s*#)|(^\s*[A-Z][^\n]{2,80}:\s*$)", content, flags=re.MULTILINE))

        normalized_content = {
            "type": "text_file",
            "content": content,
            "structured_sections": {},
            "summary": {
                "total_documents": total_documents,
                "total_characters": len(content),
                "source_extension": source_extension,
                "line_count": len(non_empty_lines),
                "encoding_detected": encoding,
                "has_structured_sections": has_sections,
            },
        }
        return self._build_payload(
            file_path=file_path,
            file_type="text",
            content=normalized_content,
            metadata={
                "extraction_method": extraction_method,
                "extraction_warnings": extraction_warnings,
            },
        )

    @staticmethod
    def _read_text_with_fallback(file_path: str, preferred_encoding: str) -> tuple[str, str]:
        encodings = [preferred_encoding, "utf-8-sig", "utf-8", "latin-1"]
        tried: set[str] = set()
        for encoding in encodings:
            if encoding in tried:
                continue
            tried.add(encoding)
            try:
                with open(file_path, "r", encoding=encoding) as handle:
                    return handle.read(), encoding
            except (UnicodeDecodeError, OSError):
                continue

        with open(file_path, "rb") as handle:
            return handle.read().decode("utf-8", errors="replace"), "utf-8-replace"
