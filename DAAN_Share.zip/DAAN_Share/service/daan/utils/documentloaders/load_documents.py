from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any

from .base_loader import BaseDocumentLoader


class DocumentLoaderRegistry:
    """Registry/factory for document loaders."""

    LOADER_MAP: dict[str, dict[str, str]] = {
        "text": {
            "module": "daan.utils.documentloaders.text_loader",
            "class": "TextDocumentLoader",
        },
        "csv": {
            "module": "daan.utils.documentloaders.csv_loader",
            "class": "CsvDocumentLoader",
        },
        "sharepoint": {
            "module": "daan.utils.documentloaders.sharepoint_loader",
            "class": "SharePointDocumentLoader",
        },
        "json": {
            "module": "daan.utils.documentloaders.json_loader",
            "class": "JsonDocumentLoader",
        },
        "pdf": {
            "module": "daan.utils.documentloaders.pdf_loader",
            "class": "PdfDocumentLoader",
        },
        "docx": {
            "module": "daan.utils.documentloaders.docx_loader",
            "class": "DocxDocumentLoader",
        },
        "excel": {
            "module": "daan.utils.documentloaders.excel_loader",
            "class": "ExcelDocumentLoader",
        },
        "ppt": {
            "module": "daan.utils.documentloaders.ppt_loader",
            "class": "PptDocumentLoader",
        },
    }

    EXTENSION_MAP: dict[str, str] = {
        ".txt": "text",
        ".md": "text",
        ".log": "text",
        ".html": "text",
        ".htm": "text",
        ".xml": "text",
        ".yml": "text",
        ".yaml": "text",
        ".properties": "text",
        ".ini": "text",
        ".cs": "text",
        ".java": "text",
        ".py": "text",
        ".js": "text",
        ".ts": "text",
        ".jsx": "text",
        ".tsx": "text",
        ".go": "text",
        ".rb": "text",
        ".php": "text",
        ".c": "text",
        ".cpp": "text",
        ".h": "text",
        ".hpp": "text",
        ".sql": "text",
        ".csv": "csv",
        ".json": "json",
        ".pdf": "pdf",
        ".docx": "docx",
        ".xlsx": "excel",
        ".xls": "excel",
        ".ppt": "ppt",
        ".pptx": "ppt",
    }

    @classmethod
    def create_loader(cls, loader_type: str, config: dict[str, Any] | None = None) -> BaseDocumentLoader:
        if loader_type not in cls.LOADER_MAP:
            available = ", ".join(cls.LOADER_MAP.keys())
            raise ValueError(f"Unsupported loader '{loader_type}'. Available: {available}")

        info = cls.LOADER_MAP[loader_type]
        module = importlib.import_module(info["module"])
        loader_class = getattr(module, info["class"])
        return loader_class(config=config)

    @classmethod
    def load_document(
        cls,
        file_path: str,
        loader_type: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        resolved_type = loader_type or cls._resolve_loader_type(file_path)
        loader = cls.create_loader(resolved_type, config=config)
        return loader.load_document(file_path)

    @classmethod
    def get_available_loaders(cls) -> list[str]:
        return list(cls.LOADER_MAP.keys())

    @classmethod
    def get_supported_extensions(cls) -> list[str]:
        return sorted(cls.EXTENSION_MAP.keys())

    @classmethod
    def _resolve_loader_type(cls, file_path: str) -> str:
        ext = Path(file_path).suffix.lower()
        if ext not in cls.EXTENSION_MAP:
            supported = ", ".join(sorted(cls.EXTENSION_MAP.keys()))
            raise ValueError(f"Unsupported extension '{ext}'. Supported: {supported}")
        return cls.EXTENSION_MAP[ext]


def load_document(
    file_path: str,
    loader_type: str | None = None,
    config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Convenience API for loading one document via registry."""
    return DocumentLoaderRegistry.load_document(file_path=file_path, loader_type=loader_type, config=config)
