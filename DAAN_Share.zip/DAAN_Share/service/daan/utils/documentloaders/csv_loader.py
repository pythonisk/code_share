from __future__ import annotations

import csv

from .base_loader import BaseDocumentLoader


class CsvDocumentLoader(BaseDocumentLoader):
    """CSV loader backed by LangChain CSVLoader."""

    @classmethod
    def supported_extensions(cls) -> set[str]:
        return {".csv"}

    def load_document(self, file_path: str) -> dict:
        extraction_warnings: list[str] = []
        extraction_method = "langchain_csvloader"
        encoding = self.config.get("encoding", "utf-8")
        csv_args = self.config.get("csv_args")
        source_column = self.config.get("source_column")
        rows: list[dict] = []
        columns: list[str] = []

        try:
            from langchain_community.document_loaders import CSVLoader

            loader_kwargs = {
                "file_path": file_path,
                "encoding": encoding,
                "autodetect_encoding": True,
            }
            if csv_args is not None:
                loader_kwargs["csv_args"] = csv_args
            if source_column is not None:
                loader_kwargs["source_column"] = source_column

            loader = CSVLoader(**loader_kwargs)
            docs = loader.load()
            for doc in docs:
                rows.append(
                    {
                        "content": doc.page_content,
                        "metadata": dict(doc.metadata or {}),
                    }
                )
        except (ImportError, OSError, UnicodeDecodeError, ValueError) as exc:
            extraction_method = "pandas_read_csv"
            extraction_warnings.append(f"LangChain CSVLoader unavailable/failed: {exc}")
            rows, columns = self._load_csv_with_pandas(file_path=file_path, encoding=str(encoding))

        if not columns:
            columns = self._extract_columns_from_rows(rows)

        detected_delimiter = self._detect_delimiter(file_path=file_path, encoding=str(encoding))
        row_sample = [row.get("content", "") for row in rows[:2]]

        normalized_content = {
            "type": "csv_file",
            "rows": rows,
            "columns": columns,
            "summary": {
                "total_rows": len(rows),
                "column_count": len(columns),
                "detected_delimiter": detected_delimiter,
                "has_header": bool(columns),
                "row_sample": row_sample,
                "encoding_detected": str(encoding),
            },
        }
        return self._build_payload(
            file_path=file_path,
            file_type="csv",
            content=normalized_content,
            metadata={
                "extraction_method": extraction_method,
                "extraction_warnings": extraction_warnings,
            },
        )

    @staticmethod
    def _extract_columns_from_rows(rows: list[dict]) -> list[str]:
        if not rows:
            return []
        first_meta = rows[0].get("metadata") if isinstance(rows[0], dict) else None
        if isinstance(first_meta, dict):
            if "row" in first_meta:
                return ["row"]
            return [str(key) for key in first_meta.keys()]
        return []

    @staticmethod
    def _detect_delimiter(file_path: str, encoding: str) -> str:
        try:
            with open(file_path, "r", encoding=encoding, newline="") as handle:
                sample = handle.read(4096)
            if not sample.strip():
                return ","
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
            return str(dialect.delimiter)
        except (OSError, UnicodeDecodeError, csv.Error):
            return ","

    @staticmethod
    def _load_csv_with_pandas(file_path: str, encoding: str) -> tuple[list[dict], list[str]]:
        try:
            import pandas as pd
        except ImportError as exc:
            raise ImportError("CsvDocumentLoader fallback requires pandas. Install with: pip install pandas") from exc

        frame = pd.read_csv(file_path, encoding=encoding, sep=None, engine="python")
        columns = [str(col) for col in frame.columns]
        rows: list[dict] = []
        for _, record in frame.fillna("").iterrows():
            serialized = ", ".join(f"{col}: {record[col]}" for col in columns)
            rows.append({"content": serialized, "metadata": {"columns": columns}})
        return rows, columns