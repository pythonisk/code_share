"""Best-effort log redaction for UI-safe troubleshooting.

This module is intentionally conservative: when a pattern matches a likely secret/PII,
we replace the sensitive value with a placeholder.

It is NOT a compliance-grade DLP system.
"""

from __future__ import annotations

import re
from collections import Counter
from typing import Iterable


_R = re.compile


# Only re-emit a small allowlist of non-sensitive extras in UI logs.
# This is intentionally conservative: do NOT add keys that can contain secrets/PII
# (e.g., usernames, emails, filenames, full paths, tokens).
_EXTRAS_ALLOWLIST = {
}


# Common secret-like keys used in config/env/logs.
_SECRET_KEYS = (
    "api_key",
    "apikey",
    "secret",
    "password",
    "passwd",
    "token",
    "access_token",
    "refresh_token",
    "client_secret",
)


# Precompiled regexes.
_RE_BEARER = _R(r"(?i)(authorization\s*[:=]\s*bearer\s+)([^\s,;]+)")
_RE_JWT = _R(r"\b[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b")
_RE_OPENAI_KEY = _R(r"\bsk-[A-Za-z0-9]{16,}\b")

# Key/value patterns: foo=bar, foo: bar, foo="bar".
_RE_KEYVALUE = _R(
    r"(?i)\b(" + "|".join(map(re.escape, _SECRET_KEYS)) + r")\b\s*([:=])\s*(\"[^\"]*\"|'[^']*'|[^\s,;]+)"
)

# Connection strings (mask everything after scheme).
_RE_CONN = _R(r"(?i)\b(postgres(?:ql)?|jdbc|snowflake)://[^\s]+")

# Emails.
_RE_EMAIL = _R(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")

# Phone-ish sequences (very approximate, intended for logs).
_RE_PHONE = _R(r"\b(?:\+?\d[\d\-() ]{7,}\d)\b")

# Windows absolute paths, e.g. C:\Users\name\file.txt
# Avoid grabbing common trailing punctuation like "," or ";".
_RE_WIN_PATH = _R(r"\b[A-Za-z]:\\[^\s\"',;]+")

# Windows absolute paths sometimes appear with forward slashes, e.g. C:/Users/name/file.txt
_RE_WIN_PATH_FWD = _R(r"\b[A-Za-z]:/[^\s\"',;]+")

# UNC paths, e.g. \\server\share\folder\file.txt
_RE_UNC_PATH = _R(r"\b\\\\[^\s\\\"',;]+\\[^\s\"',;]+")

# Unix-ish absolute paths rooted in common sensitive dirs.
_RE_UNIX_PATH = _R(r"(?<!:)(?:/Users/|/home/|/var/|/etc/|/opt/|/srv/|/tmp/)[^\s\"',;]+")

# Repo-relative paths that commonly leak local filesystem details.
_RE_REPO_REL_PATH = _R(
    r"\b(?:session_storage|service|ui|data|docs|config|infrastructure|virtual)[/\\][^\s\"',;]+"
)

# Dot-relative paths like ./foo/bar or ../foo/bar
_RE_DOT_REL_PATH = _R(r"\b\.{1,2}[/\\][^\s\"',;]+")

# Private IPs (optional, but generally safe to mask for UI logs).
_RE_PRIVATE_IP = _R(
    r"\b(?:10\.(?:\d{1,3}\.){2}\d{1,3}"
    r"|192\.168\.(?:\d{1,3}\.)\d{1,3}"
    r"|172\.(?:1[6-9]|2\d|3[0-1])\.(?:\d{1,3}\.)\d{1,3})\b"
)


def _strip_plaintext_log_prefix(text: str) -> tuple[str, str | None]:
    """Remove the standard DAAN plaintext prefix and trailing extras.

    DAAN's `PlainTextFormatter` renders log lines as:

        <timestamp> | <LEVEL> | <logger.name> | <message> | k=v k2=v2

    For UI consumption we want a status-like message, so we drop:
    - timestamp
    - level
    - logger name
    - trailing key/value extras (which often contain `session_id`)

    If the line doesn't match the expected format, returns it unchanged.
    """

    s = str(text or "")
    # Find the first 3 occurrences of " | " and keep everything after.
    i1 = s.find(" | ")
    if i1 == -1:
        return s, None
    i2 = s.find(" | ", i1 + 3)
    if i2 == -1:
        return s, None
    i3 = s.find(" | ", i2 + 3)
    if i3 == -1:
        return s, None

    remainder = s[i3 + 3 :]
    # Split message vs extras segment if present.
    if " | " in remainder:
        msg, extras = remainder.split(" | ", 1)
        return msg.strip(), extras.strip() or None
    return remainder.strip(), None


_RE_KV = _R(r"(?P<key>[A-Za-z_][A-Za-z0-9_]*)=(?P<val>'[^']*'|\"[^\"]*\"|\[[^\]]*\]|\{[^\}]*\}|[^\s]+)")


def _unquote(value: str) -> str:
    v = (value or "").strip()
    if len(v) >= 2 and ((v[0] == "'" and v[-1] == "'") or (v[0] == '"' and v[-1] == '"')):
        return v[1:-1]
    return v


def _select_extras(extras: str | None) -> str:
    """Return a formatted allowlisted extras suffix like: " (k=v, k2=v2)"."""

    if not extras:
        return ""

    selected: list[tuple[str, str]] = []
    for m in _RE_KV.finditer(extras):
        key = m.group("key")
        if key not in _EXTRAS_ALLOWLIST:
            continue
        if key == "session_id":
            continue
        val = _unquote(m.group("val"))
        if not val:
            continue
        selected.append((key, val))

    if not selected:
        return ""

    # Keep stable ordering by allowlist insertion order (using set order is unstable).
    order = [
        "old_state",
        "new_state",
        "state",
        "archetype",
        "usecase_id",
        "filenames",
        "uploaded_files",
        "agent_id",
        "pipeline_name",
        "duration_seconds",
        "agent_count",
        "output_count",
    ]
    selected_sorted = sorted(selected, key=lambda kv: order.index(kv[0]) if kv[0] in order else 999)
    rendered = ", ".join([f"{k}={v}" for (k, v) in selected_sorted])
    return f" ({rendered})"


def _subn(pattern: re.Pattern[str], repl: str, text: str, key: str, counts: Counter[str]) -> str:
    new_text, n = pattern.subn(repl, text)
    if n:
        counts[key] += int(n)
    return new_text


def sanitize_log_line(line: str) -> tuple[str, dict[str, int]]:
    """Return a redacted log line and a redaction-count summary.

    Summary keys are stable category names (e.g. "bearer", "jwt").
    """

    raw_line = str(line or "")

    # First normalize the line to a UI-friendly status message.
    msg, extras = _strip_plaintext_log_prefix(raw_line)
    text = f"{msg}{_select_extras(extras)}"

    # Special-case: keep only the status message for any "Wrote ... (<path>)" line.
    # These lines often contain local filesystem paths with spaces, and we don't
    # want to leak them to the UI.
    if text.startswith("Wrote "):
        paren = text.find("(")
        if paren != -1:
            text = text[:paren].rstrip()

    counts: Counter[str] = Counter()

    # Authorization bearer tokens.
    text = _RE_BEARER.sub(lambda m: f"{m.group(1)}<REDACTED>", text)
    # Count manually (regex sub above doesn’t report counts).
    counts["bearer"] += len(_RE_BEARER.findall(text))

    # Token-ish formats.
    # Do this BEFORE generic key/value redaction so we can still categorize JWT/openai keys.
    text = _subn(_RE_OPENAI_KEY, "<REDACTED>", text, "openai_key", counts)
    text = _subn(_RE_JWT, "<REDACTED>", text, "jwt", counts)

    # Generic key/value secrets.
    def _kv_repl(m: re.Match[str]) -> str:
        key = m.group(1)
        sep = m.group(2)
        return f"{key}{sep}<REDACTED>"

    new_text, n = _RE_KEYVALUE.subn(_kv_repl, text)
    if n:
        counts["keyvalue_secret"] += int(n)
    text = new_text

    # Connection strings.
    def _conn_repl(m: re.Match[str]) -> str:
        scheme = m.group(1)
        return f"{scheme}://<REDACTED>"

    new_text, n = _RE_CONN.subn(_conn_repl, text)
    if n:
        counts["connection_string"] += int(n)
    text = new_text

    # PII.
    text = _subn(_RE_EMAIL, "<REDACTED_EMAIL>", text, "email", counts)
    text = _subn(_RE_PHONE, "<REDACTED_PHONE>", text, "phone", counts)

    # Paths.
    text = _subn(_RE_UNC_PATH, "<PATH>", text, "path", counts)
    text = _subn(_RE_WIN_PATH, "<PATH>", text, "path", counts)
    text = _subn(_RE_WIN_PATH_FWD, "<PATH>", text, "path", counts)
    text = _subn(_RE_UNIX_PATH, "<PATH>", text, "path", counts)
    text = _subn(_RE_REPO_REL_PATH, "<PATH>", text, "path", counts)
    text = _subn(_RE_DOT_REL_PATH, "<PATH>", text, "path", counts)

    # If any <PATH> placeholder remains, remove the entire path payload.
    # This prevents leaking path fragments when the original path contains spaces.
    if "<PATH>" in text:
        prefix = text.split("<PATH>", 1)[0].rstrip()
        if prefix.endswith("("):
            prefix = prefix[:-1].rstrip()
        text = prefix if prefix else "<PATH>"

    # Private IPs.
    text = _subn(_RE_PRIVATE_IP, "<IP>", text, "private_ip", counts)

    # Remove any remaining explicit session_id fragments if they appear in message text.
    # (Usually these are in the formatter extras, which we strip above.)
    text = re.sub(r"\bsession_id\s*=\s*('[^']*'|\"[^\"]*\"|[^\s]+)", "session_id=<REDACTED>", text)

    # Collapse repeated whitespace after removals.
    text = re.sub(r"\s{2,}", " ", text).strip()

    return text, dict(counts)


def sanitize_log_lines(lines: Iterable[str]) -> tuple[list[str], dict[str, int]]:
    """Redact a list/iterable of log lines, returning (redacted_lines, summary)."""

    out: list[str] = []
    total: Counter[str] = Counter()

    for line in lines:
        redacted, summary = sanitize_log_line(line)
        out.append(redacted)
        total.update(summary)

    return out, dict(total)
