"""Utility helpers used across DAAN."""
