import json
from typing import Any, Dict, List

from .base_partitioner import BasePartitioner
from .file_partition import FilePartition


class JsonPartitioner(BasePartitioner):
    def partition(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        data = file_data.get("content")
        structure_type = type(data).__name__

        top_level = ""
        if isinstance(data, dict):
            keys = list(data.keys())
            top_level = f"Top-level keys: {', '.join([str(k) for k in keys[:20]])}" + ("…" if len(keys) > 20 else "")
        elif isinstance(data, list):
            top_level = f"Top-level list length: {len(data)}"

        try:
            pretty = json.dumps(data, indent=2, ensure_ascii=False)
        except Exception:
            pretty = str(data)

        max_preview_chars = 8000
        truncated = False
        if len(pretty) > max_preview_chars:
            pretty = pretty[:max_preview_chars]
            truncated = True

        preview_lines = "\n".join(pretty.splitlines()[:20])
        summary = f"JSON file ({structure_type}). {top_level}. Preview:\n{preview_lines}"
        if truncated:
            summary += "\n(truncated)"

        return [
            FilePartition(
                file_path=file_path,
                partition_id="json_preview",
                content=pretty,
                summary=summary,
                metadata={"type": "json", "structure_type": structure_type, "truncated": truncated},
            )
        ]
