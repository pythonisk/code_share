import logging
import math
import os
import re
from typing import Any, Dict, List, Optional

from .abap_partitioner import ABAPPartitioner
from .base_partitioner import BasePartitioner
from .code_partitioner import CodePartitioner
from .file_partition import FilePartition

logger = logging.getLogger(__name__)


class TextPartitioner(BasePartitioner):
    def __init__(self, converter: Optional[Any] = None):
        self.converter = converter
        self.code_partitioner = CodePartitioner()
        self.abap_partitioner = ABAPPartitioner()

    def partition(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        # Extract raw text first so ABAP detection can run before any structured-section short-circuit
        text_content = file_data.get("text", "")
        if not text_content and "content" in file_data and isinstance(file_data["content"], str):
            text_content = file_data["content"]

        # Detect SAP BW ABAP Transformation Routine BEFORE structured_sections check.
        # extract_text_sections() matches ABAP keywords as section headers, making
        # structured_sections non-empty and bypassing ABAP detection if checked later.
        if ABAPPartitioner.is_abap_transformation_routine(text_content):
            logger.info(f"Detected SAP BW Transformation Routine in {file_path}, parsing ABAP sections.")
            return self.abap_partitioner.partition_from_text(file_path, text_content)

        structured_sections = file_data.get("structured_sections", {})
        if structured_sections:
            return self._partition_structured(file_path, structured_sections)

        # Handle SQL files (.sql or .txt with SQL content)
        if (file_path.endswith(".sql") or (file_path.endswith(".txt") and 
            re.search(r"^\s*(CREATE|INSERT|UPDATE|DELETE|SELECT|DROP|ALTER)\s+", text_content, re.IGNORECASE | re.MULTILINE))):
            if self.converter is not None:
                logger.info(f"Detected SQL content in {file_path}, re-processing as SQL.")
                try:
                    sql_content = self.converter._convert_sql(file_path)
                    return self.code_partitioner.partition(file_path, sql_content)
                except Exception as e:
                    logger.warning(f"Failed to re-process {file_path} as SQL: {e}")
            elif re.search(r"^\s*(insert_job:|update_job:|delete_job:)", text_content, re.MULTILINE):
                logger.info(f"Detected JIL content in {file_path}, re-processing as JIL.")
                try:
                    jil_content = self.converter._convert_jil(file_path)
                    return self.code_partitioner.partition(file_path, jil_content)
                except Exception as e:
                    logger.warning(f"Failed to re-process {file_path} as JIL: {e}")
            elif re.search(r"^\s*(def\s+|class\s+|import\s+)", text_content, re.MULTILINE):
                logger.info(f"Detected Python content in {file_path}, re-processing as Python.")
                try:
                    py_content = self.converter._convert_python(file_path)
                    return self.code_partitioner.partition(file_path, py_content)
                except Exception as e:
                    logger.warning(f"Failed to re-process {file_path} as Python: {e}")

        lines = text_content.split("\n")
        preview = "\n".join(lines[:5])
        summary = f"Text file. Preview:\n{preview}\n..."

        filename = os.path.basename(file_path).lower()
        if filename.endswith(".sql"):
            summary = f"SQL Script. Preview:\n{preview}"
        elif filename.endswith(".jil"):
            summary = f"JIL Job Definition. Preview:\n{preview}"
        elif filename.endswith(".xml") or filename.endswith(".txt"):
            if "<?xml" in text_content[:100] or "<workflow" in text_content[:100]:
                summary = f"XML/Workflow File. Preview:\n{preview}"

        return [
            FilePartition(
                file_path=file_path,
                partition_id="full_text",
                content=text_content,
                summary=summary,
                metadata={"type": "text", "length": len(text_content)},
            )
        ]

    def _partition_structured(self, file_path: str, structured_sections: Dict[str, Any]) -> List[FilePartition]:
        partitions = []
        max_section_chars = 8000
        max_section_parts = 10

        for section_title, section_data in structured_sections.items():
            section_content = section_data.get("content", "")
            if not section_content.strip():
                continue

            if len(section_content) > max_section_chars:
                chunk_size = int(math.ceil(len(section_content) / float(max_section_parts)))
                chunk_size = max(2000, min(chunk_size, max_section_chars))
                part_num = 0
                for start in range(0, len(section_content), chunk_size):
                    if part_num >= max_section_parts:
                        break
                    end = min(start + chunk_size, len(section_content))
                    chunk = section_content[start:end]
                    preview = "\n".join([ln for ln in chunk.splitlines()[:4] if ln.strip()])
                    partitions.append(
                        FilePartition(
                            file_path=file_path,
                            partition_id=f"section_{section_title.replace(' ', '_')[:50]}_part_{part_num + 1}",
                            content=chunk,
                            summary=f"Section: {section_title} (part {part_num + 1}). Preview:\n{preview}",
                            metadata={
                                "type": "text_section_chunk",
                                "title": section_title,
                                "chunk_index": part_num + 1,
                                "chunk_range": [start, end],
                                "total_chars": len(section_content),
                            },
                        )
                    )
                    part_num += 1
            else:
                preview = "\n".join([ln for ln in section_content.splitlines()[:4] if ln.strip()])
                partitions.append(
                    FilePartition(
                        file_path=file_path,
                        partition_id=f"section_{section_title.replace(' ', '_')[:50]}",
                        content=section_content,
                        summary=f"Section: {section_title}. Preview:\n{preview}",
                        metadata={"type": "text_section", "title": section_title, "char_count": len(section_content)},
                    )
                )

        return partitions
