import json
import math
from typing import Any, Dict, List

from .base_partitioner import BasePartitioner
from .file_partition import FilePartition


class DocxPartitioner(BasePartitioner):
    def partition(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        partitions = []
        structured_sections = file_data.get("structured_sections", {})

        max_section_chars = 8000
        max_section_parts = 10

        # ── Structured sections ──
        if structured_sections:
            for section_title, section_data in structured_sections.items():
                section_content = section_data.get("content", "")
                if not section_content.strip():
                    continue

                if len(section_content) > max_section_chars:
                    chunk_size = int(math.ceil(len(section_content) / float(max_section_parts)))
                    chunk_size = max(2000, min(chunk_size, max_section_chars))
                    part_num = 0
                    for start in range(0, len(section_content), chunk_size):
                        if part_num >= max_section_parts:
                            break
                        end = min(start + chunk_size, len(section_content))
                        chunk = section_content[start:end]
                        preview = "\n".join([ln for ln in chunk.splitlines()[:4] if ln.strip()])
                        partitions.append(
                            FilePartition(
                                file_path=file_path,
                                partition_id=f"section_{section_title.replace(' ', '_')[:50]}_part_{part_num + 1}",
                                content=chunk,
                                summary=f"DOCX Section: {section_title} (part {part_num + 1}). Preview:\n{preview}",
                                metadata={
                                    "type": "docx_section_chunk",
                                    "title": section_title,
                                    "header_type": section_data.get("header_type"),
                                    "chunk_index": part_num + 1,
                                    "chunk_range": [start, end],
                                    "total_chars": len(section_content),
                                },
                            )
                        )
                        part_num += 1
                else:
                    preview = "\n".join([ln for ln in section_content.splitlines()[:4] if ln.strip()])
                    partitions.append(
                        FilePartition(
                            file_path=file_path,
                            partition_id=f"section_{section_title.replace(' ', '_')[:50]}",
                            content=section_content,
                            summary=f"DOCX Section: {section_title}. Preview:\n{preview}",
                            metadata={
                                "type": "docx_section",
                                "title": section_title,
                                "header_type": section_data.get("header_type"),
                                "char_count": len(section_content),
                            },
                        )
                    )

        # ── Tables ──
        tables = file_data.get("tables", [])
        for table in tables:
            if not isinstance(table, dict):
                continue
            headers = table.get("headers", [])
            data_rows = table.get("data", [])
            table_num = table.get("table_number", "?")
            if not data_rows:
                continue

            # Build a structured dict for downstream consumers
            table_content = {
                "type": "docx_table",
                "columns": headers,
                "rows": [dict(zip(headers, row)) for row in data_rows] if headers else data_rows,
                "shape": [len(data_rows), len(headers)],
            }

            cols_str = ", ".join(str(c) for c in headers[:10])
            if len(headers) > 10:
                cols_str += f" (+{len(headers) - 10} more)"
            # Build a preview from first few rows
            preview_parts = []
            for row in data_rows[:3]:
                items = []
                for h, v in zip(headers[:5], row[:5]):
                    v_str = str(v).strip()
                    if v_str and v_str.lower() not in ("nan", "none", ""):
                        items.append(f"{h}={v_str[:50]}")
                if items:
                    preview_parts.append("; ".join(items))
            row_preview = " | ".join(preview_parts) if preview_parts else "(no preview)"

            summary = (
                f"DOCX Table {table_num}. "
                f"{len(data_rows)} rows, {len(headers)} columns. "
                f"Columns: {cols_str}. "
                f"Preview: {row_preview}"
            )

            partitions.append(
                FilePartition(
                    file_path=file_path,
                    partition_id=f"table_{table_num}",
                    content=table_content,
                    summary=summary,
                    metadata={
                        "type": "docx_table",
                        "table_number": table_num,
                        "columns": headers,
                        "row_count": len(data_rows),
                    },
                )
            )

        # ── Embedded files ──
        embedded_files = file_data.get("embedded_files", [])
        for i, embed in enumerate(embedded_files):
            embed_content = embed.get("content", "")
            if embed_content:
                partitions.append(
                    FilePartition(
                        file_path=file_path,
                        partition_id=f"embedded_{i}_{embed.get('filename')}",
                        content=embed_content,
                        summary=f"Embedded File: {embed.get('filename')} ({embed.get('extension')})",
                        metadata={"type": "embedded_file", "filename": embed.get("filename")},
                    )
                )

        # ── Fallback: if nothing was extracted, use main_document_content or raw content ──
        if not partitions:
            text_content = (
                file_data.get("main_document_content", "")
                or file_data.get("content", "")
                or file_data.get("text", "")
                or ""
            )
            if text_content.strip():
                preview = "\n".join(text_content.split("\n")[:5])
                partitions.append(
                    FilePartition(
                        file_path=file_path,
                        partition_id="full_text",
                        content=text_content,
                        summary=f"DOCX full text. Preview:\n{preview}\n...",
                        metadata={"type": "text", "length": len(text_content)},
                    )
                )

        return partitions
