import os
from typing import Any, Dict


class FilePartition:
    def __init__(self, file_path: str, partition_id: str, content: Any, summary: str, metadata: Dict[str, Any] = None):
        self.file_path = file_path
        self.filename = os.path.basename(file_path)
        self.partition_id = partition_id
        self.content = content
        self.summary = summary
        self.metadata = metadata or {}

    def to_dict(self):
        return {
            "file": self.filename,
            "id": self.partition_id,
            "summary": self.summary,
            "metadata": self.metadata,
        }
