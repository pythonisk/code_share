import math
from typing import Any, Dict, List

from .base_partitioner import BasePartitioner
from .file_partition import FilePartition


class PdfPartitioner(BasePartitioner):
    def partition(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        partitions: List[FilePartition] = []
        structured_sections = file_data.get("structured_sections", {}) or {}
        pages = file_data.get("pages", []) or []
        full_text = file_data.get("content", "") or file_data.get("text", "") or ""

        def _preview(text: str) -> str:
            lines = (text or "").splitlines()
            return "\n".join([ln for ln in lines[:4] if ln.strip()])

        if isinstance(structured_sections, dict) and structured_sections:
            for section_title, section_data in structured_sections.items():
                if not isinstance(section_data, dict):
                    continue
                section_content = section_data.get("content", "") or ""
                if not section_content.strip():
                    continue
                prev = _preview(section_content)
                partitions.append(
                    FilePartition(
                        file_path=file_path,
                        partition_id=f"section_{str(section_title).replace(' ', '_')[:50]}",
                        content=section_content,
                        summary=f"PDF Section: {section_title}. Preview:\n{prev}",
                        metadata={"type": "pdf_section", "title": section_title, "char_count": len(section_content)},
                    )
                )

        if isinstance(pages, list) and pages:
            total_pages = len(pages)
            max_page_partitions = 20
            pages_per_partition = max(1, int(math.ceil(total_pages / float(max_page_partitions))))

            for start_idx in range(0, total_pages, pages_per_partition):
                end_idx = min(start_idx + pages_per_partition, total_pages)
                group = pages[start_idx:end_idx]
                group_text_parts: List[str] = []
                for page in group:
                    if isinstance(page, dict):
                        t = page.get("text", "") or ""
                        if t.strip():
                            group_text_parts.append(t)
                group_text = "\n".join(group_text_parts).strip()
                if not group_text:
                    continue
                prev = _preview(group_text)
                partitions.append(
                    FilePartition(
                        file_path=file_path,
                        partition_id=f"pages_{start_idx + 1}_{end_idx}",
                        content=group_text,
                        summary=f"PDF pages {start_idx + 1}-{end_idx} of {total_pages}. Preview:\n{prev}",
                        metadata={
                            "type": "pdf_pages",
                            "page_range": [start_idx + 1, end_idx],
                            "total_pages": total_pages,
                            "char_count": len(group_text),
                        },
                    )
                )

            # ── Tables embedded in pages ──
            table_counter = 0
            for page in pages:
                if not isinstance(page, dict):
                    continue
                page_num = page.get("page_number", "?")
                for table in page.get("tables", []):
                    if not isinstance(table, dict):
                        continue
                    raw_data = table.get("data", [])
                    if not raw_data or len(raw_data) < 2:
                        continue

                    table_counter += 1
                    # First row is typically headers
                    headers = [str(c).strip() if c else "" for c in raw_data[0]]
                    data_rows = raw_data[1:]

                    table_content = {
                        "type": "pdf_table",
                        "columns": headers,
                        "rows": [dict(zip(headers, row)) for row in data_rows] if headers else data_rows,
                        "shape": [len(data_rows), len(headers)],
                        "page": page_num,
                    }

                    cols_str = ", ".join(h for h in headers[:10] if h)
                    preview_parts = []
                    for row in data_rows[:3]:
                        items = []
                        for h, v in zip(headers[:5], row[:5]):
                            v_str = str(v).strip() if v else ""
                            if v_str and v_str.lower() not in ("nan", "none", ""):
                                items.append(f"{h}={v_str[:50]}")
                        if items:
                            preview_parts.append("; ".join(items))
                    row_preview = " | ".join(preview_parts) if preview_parts else "(no preview)"

                    summary = (
                        f"PDF Table (page {page_num}). "
                        f"{len(data_rows)} rows, {len(headers)} columns. "
                        f"Columns: {cols_str}. "
                        f"Preview: {row_preview}"
                    )

                    partitions.append(
                        FilePartition(
                            file_path=file_path,
                            partition_id=f"table_p{page_num}_{table_counter}",
                            content=table_content,
                            summary=summary,
                            metadata={
                                "type": "pdf_table",
                                "page": page_num,
                                "columns": headers,
                                "row_count": len(data_rows),
                            },
                        )
                    )

        if not partitions and full_text.strip():
            prev = _preview(full_text)
            partitions.append(
                FilePartition(
                    file_path=file_path,
                    partition_id="full_pdf_text",
                    content=full_text,
                    summary=f"Full PDF text. Preview:\n{prev}",
                    metadata={"type": "pdf_full", "char_count": len(full_text)},
                )
            )

        return partitions
