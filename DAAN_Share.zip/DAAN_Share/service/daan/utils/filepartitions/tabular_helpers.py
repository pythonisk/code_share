import math
from typing import Any, Dict, List


def generate_column_profile(rows: List[Dict[str, Any]], columns: List[str]) -> str:
    if not rows:
        return "No data to profile."

    profile_parts = []
    max_unique_display = 10

    for col in columns[:30]:
        values = [r.get(col) for r in rows if r.get(col) is not None and str(r.get(col)).strip() != ""]
        total_val = len(values)
        if total_val == 0:
            profile_parts.append(f"{col}: (Empty)")
            continue

        is_numeric = all(
            isinstance(v, (int, float)) or (isinstance(v, str) and v.replace(".", "", 1).isdigit())
            for v in values[:20]
        )

        if is_numeric:
            try:
                num_vals = [float(v) for v in values]
                _min, _max = min(num_vals), max(num_vals)
                profile_parts.append(
                    f"{col} (Num): Range [{int(_min) if _min.is_integer() else _min} - {int(_max) if _max.is_integer() else _max}]"
                )
            except Exception:
                profile_parts.append(f"{col}: (Mixed)")
        else:
            unique_vals = set(str(v) for v in values)
            count = len(unique_vals)
            if count <= max_unique_display:
                val_list = ", ".join(sorted(list(unique_vals))[:max_unique_display])
                profile_parts.append(f"{col} (Enum): {count} unique [{val_list}]")
            else:
                profile_parts.append(f"{col} (Str): {count} unique values")

    return "; ".join(profile_parts)


def smart_sample_rows(rows: List[Dict[str, Any]], total_rows: int, target_size: int = 50) -> List[Dict[str, Any]]:
    if total_rows <= target_size:
        return rows

    head_count = 7
    tail_count = 7
    middle_target = target_size - (head_count + tail_count)

    top_rows = rows[:head_count]
    bottom_rows = rows[-tail_count:]

    middle_start = head_count
    middle_end = total_rows - tail_count
    middle_rows = []

    if middle_target > 0 and middle_end > middle_start:
        span = middle_end - middle_start
        step = max(1, span // middle_target)

        for i in range(middle_target):
            block_start = middle_start + (i * step)
            block_end = min(block_start + step, middle_end)

            best_row = None
            max_density = -1
            scan_limit = min(block_end, block_start + 20)

            for r_idx in range(block_start, scan_limit):
                if r_idx < len(rows):
                    row = rows[r_idx]
                    density = sum(1 for v in row.values() if v is not None and str(v).strip())
                    if density > max_density:
                        max_density = density
                        best_row = row

            if best_row:
                middle_rows.append(best_row)

    return top_rows + middle_rows + bottom_rows
