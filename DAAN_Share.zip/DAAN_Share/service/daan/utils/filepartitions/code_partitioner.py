from typing import Any, Dict, List

from .base_partitioner import BasePartitioner
from .file_partition import FilePartition


class CodePartitioner(BasePartitioner):
    def partition(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        partitions = []
        structure = file_data.get("structure", [])
        language = file_data.get("language", "unknown")

        if not structure:
            full_text = file_data.get("content", "")
            preview = "\n".join(full_text.split("\n")[:5])
            return [
                FilePartition(
                    file_path=file_path,
                    partition_id="full_code",
                    content=full_text,
                    summary=f"Full {language} code file. Preview:\n{preview}...",
                    metadata={"type": "code", "language": language, "full_file": True},
                )
            ]

        full_text = file_data.get("content", "")
        preview = "\n".join(full_text.split("\n")[:5])
        partitions.append(
            FilePartition(
                file_path=file_path,
                partition_id="full_code",
                content=full_text,
                summary=f"Full {language} code file. Preview:\n{preview}...",
                metadata={"type": "code", "language": language, "full_file": True},
            )
        )

        for i, block in enumerate(structure):
            block_type = block.get("type", "unknown")
            block_name = block.get("name", "unnamed")
            block_content = block.get("content", "")

            if len(block_content) < 50 and block_type not in ["function", "class", "job_definition"]:
                continue

            summary = f"{language} {block_type}: {block_name}"
            if block_type == "function":
                summary = f"Function '{block_name}' (Lines {block.get('lineno')}-{block.get('end_lineno')})"
            elif block_type == "class":
                summary = f"Class '{block_name}' with {len(block.get('methods', []))} methods"
            elif block_type == "job_definition":
                summary = f"JIL Job: {block_name} ({block.get('action')})"
            elif block_type in ["CREATE", "INSERT", "UPDATE", "SELECT"]:
                summary = f"SQL {block_type} statement: {block_name}"

            partitions.append(
                FilePartition(
                    file_path=file_path,
                    partition_id=f"block_{i}_{block_type}_{block_name}",
                    content=block_content,
                    summary=summary,
                    metadata={"type": "code_block", "language": language, "block_type": block_type, "name": block_name},
                )
            )

        return partitions
