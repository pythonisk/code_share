import json
import logging
import os
from typing import Any, Dict, List

from .base_partitioner import BasePartitioner
from .file_partition import FilePartition

logger = logging.getLogger(__name__)


class TableauPartitioner(BasePartitioner):
    def partition(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        partitions: List[FilePartition] = []
        filename = os.path.basename(file_path)

        try:
            inner_content = file_data.get("content", {})
            content = inner_content.get("content", {})
            metadata = inner_content.get("metadata", {})
            embedded_files = inner_content.get("embedded_files", {})
            summary_info = inner_content.get("summary", {})

            compact_spec = inner_content.get("spec", {})
            use_compact = bool(compact_spec)

            context_parts = []
            context_parts.append("HINT: This is a dismantled Tableau file. Think of this as a specification or knowledge document.")
            context_parts.append("Use this to understand the data model, measures, visual types, and layout for Power BI conversion.")
            context_parts.append(f"\nFile: {filename}")
            context_parts.append(f"Format: {summary_info.get('file_format', 'unknown')}")

            if use_compact:
                model_spec = compact_spec.get("model_spec", {})
                visual_spec = compact_spec.get("visual_spec", {})

                data_sources = model_spec.get("data_sources", [])
                if data_sources:
                    context_parts.append(f"\n=== DATA SOURCES (Count: {len(data_sources)}) ===")
                    for i, ds in enumerate(data_sources, 1):
                        ds_name = ds.get("name", f"DataSource_{i}")
                        tables = ds.get("logical_tables", [])
                        tables_str = ", ".join(tables) if tables else "(no tables)"
                        context_parts.append(f"{i}. Name: {ds_name} | Logical Tables: {tables_str}")
                else:
                    context_parts.append("\n=== DATA SOURCES ===\n(None found)")

                columns = model_spec.get("columns", [])
                if columns:
                    context_parts.append(f"\n=== PHYSICAL COLUMNS (Count: {len(columns)}) ===")
                    context_parts.append("These are actual columns from the data source (CSV/database):")
                    for i, col in enumerate(columns, 1):
                        col_name = col.get("name", f"Column_{i}")
                        data_type = col.get("data_type", "unknown")
                        default_agg = col.get("default_aggregation", "")
                        role = col.get("role", "")
                        role_type = col.get("role_type", "")
                        fmt = col.get("format", "")
                        src_table = col.get("source_table", "")
                        ds_tag = col.get("datasource", "")
                        detail = f"{i}. {col_name} ({data_type})"
                        extras = []
                        if role:
                            extras.append(f"role={role}")
                        if role_type:
                            extras.append(f"semantic={role_type}")
                        if default_agg:
                            extras.append(f"default_agg={default_agg}")
                        if fmt:
                            extras.append(f"format={fmt}")
                        if src_table:
                            extras.append(f"table={src_table}")
                        if ds_tag:
                            extras.append(f"ds={ds_tag}")
                        if extras:
                            detail += f" [{', '.join(extras)}]"
                        context_parts.append(detail)
                else:
                    context_parts.append("\n=== PHYSICAL COLUMNS ===\n(None found)")

                calculated_fields = model_spec.get("calculated_fields", [])
                if calculated_fields:
                    context_parts.append(f"\n=== CALCULATED FIELDS / MEASURES (Count: {len(calculated_fields)}) ===")
                    context_parts.append("These are Tableau formulas that need to be converted to Power BI DAX measures or calculated columns:")

                    must_create = [c for c in calculated_fields if c.get("should_be_column")]
                    optional = [c for c in calculated_fields if not c.get("should_be_column")]

                    if must_create:
                        context_parts.append("\n⚠️  CRITICAL - MUST CREATE THESE CALCULATED COLUMNS IN THE TABLE:")
                        context_parts.append("(These must be defined in the semantic model BEFORE visuals can use them)")
                        for i, calc in enumerate(must_create, 1):
                            calc_name = calc.get("name", f"CalcColumn_{i}")
                            formula = calc.get("formula", "")
                            context_parts.append(f"  • {calc_name} = {formula}")
                            hint = calc.get("conversion_hint", "")
                            if hint:
                                wrapped_hint = "\n".join(["      " + line for line in hint.split("\n")])
                                context_parts.append(f"    ℹ️  {wrapped_hint}")

                    if optional:
                        context_parts.append("\n  OPTIONAL MEASURES:")
                        for i, calc in enumerate(optional, 1):
                            calc_name = calc.get("name", f"Calculation_{i}")
                            formula = calc.get("formula", "")
                            calc_type = calc.get("type", "calculated_field")
                            detail = f"  {i}. {calc_name} = {formula}"
                            tags = []
                            if calc_type == "bin":
                                tags.append(f"BIN: size={calc.get('bin_size', '')}, source={calc.get('source_field', '')}")
                            else:
                                tags.append(calc_type.upper())
                            if calc.get("is_lod"):
                                tags.append("LOD EXPRESSION")
                            if calc.get("is_table_calc"):
                                tags.append("TABLE CALC")
                            detail += f" [{', '.join(tags)}]"
                            context_parts.append(detail)
                else:
                    context_parts.append("\n=== CALCULATED FIELDS / MEASURES ===\n(None found)")

                relationships = model_spec.get("relationships", [])
                if relationships:
                    context_parts.append(f"\n=== RELATIONSHIPS/JOINS (Count: {len(relationships)}) ===")
                    for i, rel in enumerate(relationships, 1):
                        left = rel.get("left_table", "?")
                        right = rel.get("right_table", "?")
                        jtype = rel.get("join_type", "inner")
                        join_cols = rel.get("join_columns", [])
                        detail = f"{i}. {left} ↔ {right} ({jtype})"
                        if join_cols:
                            pairs = [f"{jc.get('left_column', '?')}={jc.get('right_column', '?')}" for jc in join_cols]
                            detail += f" ON {', '.join(pairs)}"
                        context_parts.append(detail)
                else:
                    context_parts.append("\n=== RELATIONSHIPS/JOINS ===\n(None found - may use implicit joins)")

                pages = visual_spec.get("pages", [])
                if pages:
                    context_parts.append(f"\n=== DASHBOARDS/PAGES (Count: {len(pages)}) ===")
                    for i, page in enumerate(pages, 1):
                        page_name = page.get("page_name", f"Page_{i}")
                        tiles = page.get("tiles", [])
                        context_parts.append(f"{i}. {page_name} | Contains {len(tiles)} visual(s)")
                        for j, tile in enumerate(tiles, 1):
                            raw_title = tile.get("title", f"Visual {j}")
                            if isinstance(raw_title, list):
                                tile_title = " ".join(
                                    str(t) for t in raw_title
                                    if isinstance(t, str) and t.strip() and t != "\u00c6"
                                ).strip() or f"Visual {j}"
                            else:
                                tile_title = str(raw_title).replace("\u00c6", "").strip() or f"Visual {j}"
                            tile_type = tile.get("type", "unknown")
                            query = tile.get("query", {})
                            dims = query.get("dimensions", [])
                            meas_list = query.get("measures", [])
                            detail_parts = []
                            if dims:
                                detail_parts.append(f"dims={','.join(str(d) for d in dims[:5])}")
                            if meas_list:
                                meas_names = [m.get("field", str(m)) if isinstance(m, dict) else str(m) for m in meas_list[:5]]
                                detail_parts.append(f"measures={','.join(meas_names)}")
                            enc = tile.get("encodings", {})
                            if enc:
                                enc_parts = []
                                for ch in ("color", "size", "shape", "label", "detail", "tooltip"):
                                    val = enc.get(ch)
                                    if val:
                                        if isinstance(val, list):
                                            fields = [v.get("field", str(v)) if isinstance(v, dict) else str(v) for v in val]
                                            enc_parts.append(f"{ch}={','.join(fields[:3])}")
                                        elif isinstance(val, dict):
                                            enc_parts.append(f"{ch}={val.get('field', str(val))}")
                                        else:
                                            enc_parts.append(f"{ch}={val}")
                                if enc_parts:
                                    detail_parts.append(f"enc: {'; '.join(enc_parts)}")
                            if tile.get("dual_axis"):
                                detail_parts.append(f"dual_axis marks={tile.get('mark_types', [])}")
                            q_filters = query.get("filters", [])
                            if q_filters:
                                fnames = [f.get("field", "?") if isinstance(f, dict) else str(f) for f in q_filters[:3]]
                                detail_parts.append(f"filters={','.join(fnames)}")
                            ref_lines = tile.get("reference_lines", [])
                            if ref_lines:
                                detail_parts.append(f"ref_lines={len(ref_lines)}")
                            zone_pos = tile.get("zone_position", {})
                            if zone_pos:
                                detail_parts.append(f"pos=({zone_pos.get('x', 0)},{zone_pos.get('y', 0)},{zone_pos.get('w', 0)},{zone_pos.get('h', 0)})")
                            detail_str = f" [{'; '.join(detail_parts)}]" if detail_parts else ""
                            context_parts.append(f"   - {tile_title} ({tile_type}){detail_str}")
                else:
                    context_parts.append("\n=== DASHBOARDS/PAGES ===\n(None found)")

                data_sources_count = len(data_sources)
                measures_count = len(calculated_fields)
                relationships_count = len(relationships) if relationships else 0
                worksheets_count = len(pages)
                dashboards_count = len(pages)

            else:
                data_sources = metadata.get("data_sources", [])
                if data_sources:
                    context_parts.append(f"\n=== DATA SOURCES (Count: {len(data_sources)}) ===")
                    for i, ds in enumerate(data_sources, 1):
                        ds_name = ds.get("name", f"DataSource_{i}")
                        tables = ds.get("tables", [])
                        fields = ds.get("fields", [])
                        tables_str = ", ".join(tables) if tables else "(no tables)"
                        context_parts.append(f"{i}. Name: {ds_name} | Tables: {tables_str}")
                        if fields:
                            context_parts.append(f"   Fields: {', '.join(fields[:30])}" + (" ..." if len(fields) > 30 else ""))
                else:
                    context_parts.append("\n=== DATA SOURCES ===\n(None found)")

                measures = metadata.get("measures", [])
                if measures:
                    context_parts.append(f"\n=== MEASURES/FORMULAS (Count: {len(measures)}) ===")
                    for i, measure in enumerate(measures, 1):
                        measure_name = measure.get("name", f"Measure_{i}")
                        formula = measure.get("formula", "")
                        ds_name = measure.get("datasource", "")
                        detail = f"{i}. {measure_name}"
                        if formula:
                            detail += f" = {formula}"
                        if ds_name:
                            detail += f" (from: {ds_name})"
                        context_parts.append(detail)
                else:
                    context_parts.append("\n=== MEASURES/FORMULAS ===\n(None found)")

                relationships = metadata.get("relationships", [])
                if relationships:
                    context_parts.append(f"\n=== RELATIONSHIPS/JOINS (Count: {len(relationships)}) ===")
                    for i, rel in enumerate(relationships, 1):
                        rel_name = rel.get("name", f"Relationship_{i}")
                        rel_type = rel.get("type", "")
                        detail = f"{i}. {rel_name}"
                        if rel_type:
                            detail += f" (type: {rel_type})"
                        context_parts.append(detail)
                else:
                    context_parts.append("\n=== RELATIONSHIPS/JOINS ===\n(None found - may use implicit joins)")

                worksheets = metadata.get("worksheets", [])
                if worksheets:
                    context_parts.append(f"\n=== WORKSHEETS (Count: {len(worksheets)}) ===")
                    for i, ws in enumerate(worksheets, 1):
                        ws_name = ws.get("name", f"Sheet_{i}")
                        mark_types = ws.get("mark_types", [])
                        ds_used = ws.get("datasources_used", [])
                        detail = f"{i}. {ws_name}"
                        if mark_types:
                            detail += f" | Visual Type(s): {', '.join(mark_types)}"
                        if ds_used:
                            detail += f" | Data: {', '.join(ds_used)}"
                        context_parts.append(detail)
                else:
                    context_parts.append("\n=== WORKSHEETS ===\n(None found)")

                dashboards = metadata.get("dashboards", [])
                if dashboards:
                    context_parts.append(f"\n=== DASHBOARDS (Count: {len(dashboards)}) ===")
                    for i, db in enumerate(dashboards, 1):
                        db_name = db.get("name", f"Dashboard_{i}")
                        ref_sheets = db.get("referenced_worksheets", [])
                        detail = f"{i}. {db_name}"
                        if ref_sheets:
                            detail += f" | Contains: {', '.join(ref_sheets)}"
                        context_parts.append(detail)
                else:
                    context_parts.append("\n=== DASHBOARDS ===\n(None found)")

                data_sources_count = len(data_sources)
                measures_count = len(measures)
                relationships_count = len(relationships)
                worksheets_count = len(worksheets)
                dashboards_count = len(dashboards)

            if embedded_files:
                context_parts.append(f"\n=== EMBEDDED DATA FILES (Count: {len(embedded_files)}) ===")
                for file_name, file_info in embedded_files.items():
                    file_type = file_info.get("type", "unknown")
                    size = file_info.get("size_bytes", 0)
                    context_parts.append(f"- {file_name} ({file_type}, {size} bytes)")

            full_context = "\n".join(context_parts)
            format_indicator = "[COMPACT SPEC]" if use_compact else "[LEGACY FORMAT]"
            partitions.append(
                FilePartition(
                    file_path=file_path,
                    partition_id="tableau_specification",
                    content=full_context,
                    summary=f"Tableau Report '{filename}' {format_indicator} - Dismantled Specification. "
                    f"Data Sources: {data_sources_count}, "
                    f"Measures: {measures_count}, "
                    f"Worksheets: {worksheets_count}, "
                    f"Dashboards: {dashboards_count}",
                    metadata={
                        "type": "tableau_specification",
                        "format": "compact_spec" if use_compact else "legacy_metadata",
                        "file_format": summary_info.get("file_format", "unknown"),
                        "data_sources_count": data_sources_count,
                        "measures_count": measures_count,
                        "relationships_count": relationships_count,
                        "worksheets_count": worksheets_count,
                        "dashboards_count": dashboards_count,
                        "embedded_files_count": len(embedded_files),
                    },
                )
            )

            if content:
                try:
                    raw_content = json.dumps(content, indent=2, ensure_ascii=False)[:15000]
                    partitions.append(
                        FilePartition(
                            file_path=file_path,
                            partition_id="tableau_raw_xml",
                            content=raw_content,
                            summary=f"Tableau file {filename} - Raw XML structure (truncated)",
                            metadata={"type": "tableau_raw_xml", "truncated": True},
                        )
                    )
                except Exception as e:
                    logger.warning(f"Could not create raw XML partition for {filename}: {e}")

        except Exception as e:
            logger.error(f"Error partitioning Tableau file {filename}: {e}")
            partitions.append(
                FilePartition(
                    file_path=file_path,
                    partition_id="tableau_error",
                    content=str(file_data),
                    summary=f"Error partitioning Tableau file {filename}: {str(e)}",
                    metadata={"error": str(e), "type": "tableau_error"},
                )
            )

        return partitions
