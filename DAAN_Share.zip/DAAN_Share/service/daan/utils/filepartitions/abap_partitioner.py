import logging
import re
from typing import Any, Dict, List

from .base_partitioner import BasePartitioner
from .file_partition import FilePartition

logger = logging.getLogger(__name__)

# File extensions that may contain ABAP source code
ABAP_EXTENSIONS = {".abap", ".txt", ".docx"}


class ABAPPartitioner(BasePartitioner):
    """
    Partitioner for SAP BW ABAP Transformation Routine files.

    Detects SAP BW-generated ABAP class files (typically exported as .abap,
    .txt, or .docx) and splits them into named partitions that align with
    the STTM Extraction Agent's required inputs.

    Supported input formats:
        - .abap  : Native ABAP source file from SAP ADT (Eclipse)
        - .txt   : ABAP source exported from SAP GUI (SE38 / SE80)
        - .docx  : ABAP routine exported as Word document (text already extracted)

    Output partitions (partition_id -> content):
        section_Preamble       : Header comment block with TranID, Source, Target, Date
        section_SC1_TYPES      : _ty_s_SC_1 struct — SOURCE field names + ABAP types  [CRITICAL]
        section_TG1_TYPES      : _ty_s_TG_1 struct — TARGET field names + ABAP types
        section_G2_TYPES       : _ty_G_2 struct — grouping struct for aggregation moves
        section_RULES          : LOOP AT <_yt_SC_1> block — all Rule ID mapping rules  [CRITICAL]
        section_start_routine  : METHOD start_routine body (omitted if not present)
        section_end_routine    : METHOD end_routine body — derived field calculations   [CRITICAL]
    """

    # ----------------------------------------------------------------
    # Detection
    # ----------------------------------------------------------------

    @staticmethod
    def is_abap_transformation_routine(text_content: str) -> bool:
        """
        Returns True if the text content is a SAP BW generated ABAP
        transformation routine (lcl_transform pattern).
        """
        indicators = [
            r"RSTRAN_MASTER_TMPL",
            r"CLASS\s+lcl_transform\s+DEFINITION",
            r"TranID\s*\.{4,}",
            # Alternation must stay grouped: ungrouped it matched a bare "HANA"/"RFC"
            # anywhere, so ordinary prose (e.g. the name "Santhanam") was read as ABAP.
            r"Source\s*\.{4,}.*(?:FLATFILE|HANA|RFC)",
            r"TYPES\s*:\s*BEGIN\s+OF\s+_ty_s_SC_1",
        ]
        return any(re.search(p, text_content, re.IGNORECASE) for p in indicators)

    # ----------------------------------------------------------------
    # Entry point (file_data dict — used when called directly)
    # ----------------------------------------------------------------

    def partition(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        text_content = file_data.get("text", "") or file_data.get("content", "")

        if not text_content:
            logger.warning(f"ABAPPartitioner: no text content found in {file_path}")
            return []

        if not self.is_abap_transformation_routine(text_content):
            logger.info(f"ABAPPartitioner: content does not look like ABAP routine — {file_path}")
            return []

        logger.info(f"ABAPPartitioner: parsing ABAP transformation routine — {file_path}")
        return self._extract_sections(file_path, text_content)

    # ----------------------------------------------------------------
    # Public text-based entry point (used by TextPartitioner)
    # ----------------------------------------------------------------

    def partition_from_text(self, file_path: str, text_content: str) -> List[FilePartition]:
        """Partition pre-extracted text content directly (no file_data dict needed)."""
        return self._extract_sections(file_path, text_content)

    # ----------------------------------------------------------------
    # Section extraction
    # ----------------------------------------------------------------

    def _extract_sections(self, file_path: str, text: str) -> List[FilePartition]:
        partitions = []

        def add(partition_id: str, content: str, summary: str, warning: str = None):
            meta = {"type": "abap_section", "title": partition_id}
            if warning:
                meta["warning"] = warning
            if content and content.strip():
                partitions.append(FilePartition(
                    file_path=file_path,
                    partition_id=partition_id,
                    content=content.strip(),
                    summary=summary,
                    metadata=meta,
                ))
            else:
                # Always emit critical sections even if empty, so agent can flag them
                if warning:
                    partitions.append(FilePartition(
                        file_path=file_path,
                        partition_id=partition_id,
                        content="NOT_PRESENT",
                        summary=summary,
                        metadata=meta,
                    ))

        # ---- section_Preamble ----------------------------------------
        m = re.search(
            r"(\*[\s\S]*?TranID[\s\S]*?Date[\s\S]*?)(^PROGRAM\s+\w+\.)",
            text, re.MULTILINE
        )
        if m:
            add("section_Preamble",
                m.group(1).strip() + "\n" + m.group(2),
                "SAP BW Transformation preamble — TranID, Source datasource, Target ADSO, Date")
        else:
            m = re.search(r"([\s\S]*?)(CLASS\s+lcl_transform\s+DEFINITION)", text, re.IGNORECASE)
            if m:
                add("section_Preamble", m.group(1).strip(),
                    "SAP BW Transformation preamble (fallback extraction)")

        # ---- section_SC1_TYPES  [CRITICAL — source field schema] ------
        m = re.search(
            r"(TYPES\s*:?\s*BEGIN\s+OF\s+_ty_s_SC_1[\s\S]*?END\s+OF\s+_ty_s_SC_1\s*\.)",
            text, re.IGNORECASE
        )
        add("section_SC1_TYPES",
            m.group(1) if m else "",
            "Source schema — _ty_s_SC_1: source field names and ABAP type declarations",
            warning=None if m else "section_SC1_TYPES not found — source field types unavailable")

        # ---- section_TG1_TYPES  (target field schema) -----------------
        m = re.search(
            r"(TYPES\s*:?\s*BEGIN\s+OF\s+_ty_s_TG_1[\s\S]*?END\s+OF\s+_ty_s_TG_1\s*\.)",
            text, re.IGNORECASE
        )
        if m:
            add("section_TG1_TYPES", m.group(1),
                "Target schema — _ty_s_TG_1: target field names and ABAP type declarations")

        # ---- section_G2_TYPES  (grouping struct) ----------------------
        m = re.search(
            r"(TYPES\s*:?\s*BEGIN\s+OF\s+_ty_G_2[\s\S]*?END\s+OF\s+_ty_G_2\s*\.)",
            text, re.IGNORECASE
        )
        if m:
            add("section_G2_TYPES", m.group(1),
                "Target grouping struct — _ty_G_2: used in aggregation MOVE block")

        # ---- section_RULES  [CRITICAL — all Rule ID mapping blocks] ---
        rules_content = self._extract_rules_block(text)
        add("section_RULES",
            rules_content,
            "Field mapping rules — all Rule ID blocks (DIRECT / CONSTANT / FORMULA types)",
            warning=None if rules_content else "section_RULES not found — field mappings unavailable")

        # ---- section_start_routine  (optional pre-processing) ---------
        m = re.search(
            r"(METHOD\s+start_routine\s*\.\s*[\s\S]*?ENDMETHOD\s*\.)",
            text, re.IGNORECASE
        )
        if m:
            add("section_start_routine", m.group(1),
                "start_routine — pre-processing / package-level filter logic")

        # ---- section_end_routine  [CRITICAL — derived field calcs] ----
        end_content = self._extract_end_routine(text)
        add("section_end_routine",
            end_content,
            "end_routine — derived field calculations for all Z_* computed fields",
            warning=None if end_content else "section_end_routine not found — derived fields unavailable")

        self._log_summary(file_path, partitions)
        return partitions

    # ----------------------------------------------------------------
    # Specialised extractors
    # ----------------------------------------------------------------

    def _extract_rules_block(self, text: str) -> str:
        """
        Extract the full block of Rule ID assignments from inside METHOD execute.
        Looks for the LOOP AT <_yt_SC_1> block that contains *<<< Rule ID lines.
        """
        # Strategy 1: find * === RULES marker to ENDLOOP
        m = re.search(
            r"(\*\s*={4,}.*?RULES[\s\S]*?ENDLOOP\s*\.)",
            text, re.IGNORECASE
        )
        if m:
            return m.group(1)

        # Strategy 2: find LOOP AT <_yt_SC_1> ... ENDLOOP containing Rule IDs
        m = re.search(
            r"(LOOP\s+AT\s+<_yt_SC_1>[\s\S]*?<<< Rule ID[\s\S]*?ENDLOOP\s*\.)",
            text, re.IGNORECASE
        )
        if m:
            return m.group(1)

        # Strategy 3: collect all Rule ID blocks individually
        rule_blocks = re.findall(
            r"(\*<<<\s+Rule ID:.*?(?=\*<<<\s+Rule ID:|\Z))",
            text, re.DOTALL
        )
        if rule_blocks:
            return "\n".join(rule_blocks)

        return ""

    def _extract_end_routine(self, text: str) -> str:
        """
        Extract the METHOD end_routine implementation body.
        There are typically two matches:
          1. The METHOD signature in the CLASS DEFINITION (short, no body)
          2. The METHOD implementation in CLASS IMPLEMENTATION (long, has LOOP body)
        We pick the longest match = the implementation.
        """
        matches = list(re.finditer(
            r"(METHOD\s+end_routine\s*\.[\s\S]*?ENDMETHOD\s*\.)",
            text, re.IGNORECASE
        ))
        if not matches:
            return ""
        return max(matches, key=lambda x: len(x.group(1))).group(1)

    # ----------------------------------------------------------------
    # Logging
    # ----------------------------------------------------------------

    def _log_summary(self, file_path: str, partitions: List[FilePartition]):
        found = [p.partition_id for p in partitions if p.content != "NOT_PRESENT"]
        missing = [p.partition_id for p in partitions if p.content == "NOT_PRESENT"]
        logger.info(f"ABAPPartitioner [{file_path}]: extracted {len(found)} sections: {found}")
        if missing:
            logger.warning(f"ABAPPartitioner [{file_path}]: MISSING critical sections: {missing}")
