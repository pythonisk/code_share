import json
from typing import Any, Dict, List

from .base_partitioner import BasePartitioner
from .file_partition import FilePartition


class ADSOPartitioner(BasePartitioner):
    """Partitioner for SAP BW Advanced DataStore Object (ADSO) XML files.

    Emits three named partitions aligned with the STTM Extraction agent inputs:
      adso_metadata  — ADSO root attributes, label, and tlogoProperties
      key_elements   — primary key field names (SAP namespace prefix stripped)
      target_fields  — ALL element nodes with type/length/aggregation/description (no truncation)
    """

    @staticmethod
    def is_adso_xml(root_tag: str, data: Any) -> bool:
        """Return True if this is a SAP BW ADSO XML file."""
        if not isinstance(data, dict):
            return False
        tag = str(root_tag or "").lower()
        has_datastore_tag = "datastore" in tag or "adso" in tag
        has_element_list = isinstance(data.get("element"), (list, dict))
        has_adso_attrs = isinstance(data.get("@attributes"), dict) and (
            "physicalSchemaName" in data["@attributes"]
            or "fieldNamePrefix" in data["@attributes"]
        )
        return (has_datastore_tag or has_adso_attrs) and has_element_list

    def partition(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        data = file_data.get("content")
        return self.partition_from_dict(file_path, data)

    def partition_from_dict(self, file_path: str, data: Dict[str, Any]) -> List[FilePartition]:
        partitions = []

        # ---- adso_metadata ----------------------------------------
        meta = {}
        if isinstance(data.get("@attributes"), dict):
            meta.update(data["@attributes"])
        if isinstance(data.get("endUserTexts"), dict):
            label = data["endUserTexts"].get("@attributes", {}).get("label")
            if label:
                meta["description"] = label
        if isinstance(data.get("tlogoProperties"), dict):
            tlogo_attrs = data["tlogoProperties"].get("@attributes", {})
            for k, v in tlogo_attrs.items():
                short_key = k.split("}")[-1] if "}" in k else k
                meta[short_key] = v
        partitions.append(FilePartition(
            file_path=file_path,
            partition_id="adso_metadata",
            content=json.dumps(meta, indent=2, ensure_ascii=False),
            summary=(
                f"ADSO metadata — name: {meta.get('name', '?')}, "
                f"schema: {meta.get('physicalSchemaName', '?')}, "
                f"description: {meta.get('description', '?')}"
            ),
            metadata={"type": "adso_metadata"},
        ))

        # ---- key_elements -----------------------------------------
        raw_keys = data.get("keyElement", [])
        if isinstance(raw_keys, str):
            raw_keys = [raw_keys]
        elif not isinstance(raw_keys, list):
            raw_keys = []
        # Strip SAP namespace prefix (#///, #///__NON_KEY§, etc.)
        key_names = [str(k).split("/")[-1].split("§")[0] for k in raw_keys if k]
        key_content = "\n".join(key_names) if key_names else "NOT_PRESENT"
        partitions.append(FilePartition(
            file_path=file_path,
            partition_id="key_elements",
            content=key_content,
            summary=f"ADSO primary key fields: {', '.join(key_names) if key_names else 'none found'}",
            metadata={"type": "adso_key_elements", "key_count": len(key_names)},
        ))

        # ---- target_fields ----------------------------------------
        elements = data.get("element", [])
        if isinstance(elements, dict):
            elements = [elements]
        elif not isinstance(elements, list):
            elements = []

        field_rows = []
        for elem in elements:
            if not isinstance(elem, dict):
                continue
            attrs = elem.get("@attributes", {})
            inline = elem.get("inlineType", {})
            inline_attrs = inline.get("@attributes", {}) if isinstance(inline, dict) else {}
            local_props = elem.get("localProperties", {})
            lp_attrs = local_props.get("@attributes", {}) if isinstance(local_props, dict) else {}
            descriptions = local_props.get("descriptions", {}) if isinstance(local_props, dict) else {}
            desc_attrs = descriptions.get("@attributes", {}) if isinstance(descriptions, dict) else {}
            unit_elem = elem.get("unitCurrencyElement")

            xsi_type = lp_attrs.get("{http://www.w3.org/2001/XMLSchema-instance}type", "")
            field_class = "Keyfigure" if "Keyfigure" in xsi_type else "Characteristic"

            field_rows.append({
                "name": attrs.get("name", ""),
                "type": inline_attrs.get("name", ""),
                "length": inline_attrs.get("length", ""),
                "precision": inline_attrs.get("precision", ""),
                "scale": inline_attrs.get("scale", ""),
                "semanticType": inline_attrs.get("semanticType", ""),
                "fieldClass": field_class,
                "aggregationBehavior": attrs.get("aggregationBehavior", ""),
                "description": desc_attrs.get("label", ""),
                "unitCurrencyElement": unit_elem if isinstance(unit_elem, str) else "",
            })

        target_content = json.dumps(
            {"element_count": len(field_rows), "elements": field_rows},
            indent=2,
            ensure_ascii=False,
        )
        partitions.append(FilePartition(
            file_path=file_path,
            partition_id="target_fields",
            content=target_content,
            summary=f"ADSO target fields — {len(field_rows)} elements (all included, no truncation)",
            metadata={"type": "adso_target_fields", "element_count": len(field_rows)},
        ))

        return partitions
