import os
from typing import Any, Dict, List

from .base_partitioner import BasePartitioner
from .file_partition import FilePartition
from .tabular_helpers import generate_column_profile, smart_sample_rows


class TabularPartitioner(BasePartitioner):
    def partition(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        rows = file_data.get("rows", [])
        columns = file_data.get("columns", [])
        total_rows = len(rows)

        logic_keywords = [
            "mapping", "transformation", "rule", "logic", "source_col", "target_col",
            "business_key", "lookup", "expression", "condition", "script", "query",
            "api", "endpoint", "job_name", "workflow",
        ]

        def _is_logic_col(col_name):
            val = str(col_name).lower()
            if "description" in val:
                return False
            return any(k in val for k in logic_keywords)

        file_lower = os.path.basename(file_path).lower()
        is_mapping_file = any(k in file_lower for k in ["mapping", "metadata", "rule", "schema", "config", "def"])
        is_logic = is_mapping_file or any(_is_logic_col(c) for c in columns)

        max_rows_for_full = 150

        if total_rows <= max_rows_for_full or is_logic:
            summary = f"Tabular data ({'Logic' if is_logic else 'Small'}). {len(rows)} rows. Columns: {', '.join(columns[:10])}..."
            return [
                FilePartition(
                    file_path=file_path,
                    partition_id="main_table",
                    content=file_data,
                    summary=summary,
                    metadata={"type": "tabular", "columns": columns, "total_rows": total_rows},
                )
            ]

        sampled_rows = smart_sample_rows(rows, total_rows, target_size=50)
        col_profile = generate_column_profile(rows, [str(c) for c in columns])

        summary = (
            f"Data Profile: Tabular File. Contains {total_rows} rows. "
            f"Metadata: [Rows: {total_rows}, Cols: {len(columns)}, Logic: No].\n"
            f"Column Statistics: {col_profile}"
        )

        return [
            FilePartition(
                file_path=file_path,
                partition_id="data_profile",
                content={
                    "columns": columns,
                    "total_rows": total_rows,
                    "metadata": {"sampling": f"stratified_density_optimized_{len(sampled_rows)}_rows", "row_count": total_rows},
                    "rows": sampled_rows,
                },
                summary=summary,
                metadata={"type": "tabular_profile", "columns": columns, "total_rows": total_rows, "is_sampled": True},
            )
        ]
