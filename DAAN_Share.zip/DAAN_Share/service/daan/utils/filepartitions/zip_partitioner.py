"""
Partitioner for zip_archive content produced by ZipConverter.

Splits a ZipConverter result into per-file partitions by delegating
each embedded file to the correct sub-partitioner (TabularPartitioner
for CSVs, ExcelPartitioner for XLSX, etc.) so that intelligent data
profiling, per-sheet splitting, and other specialised logic is applied.

Projects (PBIP / Tableau extractions) become their own partitions.
"""

import logging
import os
from typing import Any, Dict, List

from .base_partitioner import BasePartitioner
from .file_partition import FilePartition

logger = logging.getLogger(__name__)


class ZipPartitioner(BasePartitioner):
    def partition(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        zip_filename = os.path.basename(file_path)
        partitions: List[FilePartition] = []

        projects = file_data.get("projects", [])
        files = file_data.get("files", {})

        # --- Project-level partitions (PBIP, Tableau, etc.) ---
        for i, project in enumerate(projects):
            source_file = project.get("_source_file", f"project_{i}")
            proj_type = project.get("type", "unknown_project")

            partitions.append(
                FilePartition(
                    file_path=file_path,
                    partition_id=f"project_{i}_{proj_type}",
                    content=project,
                    summary=(
                        f"BI project '{source_file}' extracted from archive '{zip_filename}'. "
                        f"Type: {proj_type}."
                    ),
                    metadata={
                        "type": proj_type,
                        "source_archive": zip_filename,
                        "source_file": source_file,
                    },
                )
            )

        # --- Per-file partitions (CSVs, Excel, SQL, etc.) ---
        if files:
            # Lazy import to avoid circular dependency
            from daan.utils.file_partitioner import FilePartitioner

            file_partitioner = FilePartitioner()

            for rel_path, converted_data in files.items():
                try:
                    # converted_data is a full convert_file_to_json result:
                    # {filename, file_type, content: {type, ...}, metadata}
                    sub_partitions = file_partitioner.partition_file(rel_path, converted_data)

                    for p in sub_partitions:
                        # Prefix filename with zip name for clustering in context
                        p.filename = f"{zip_filename}/{p.filename}"
                        # Update metadata to indicate archive origin
                        p.metadata["source_archive"] = zip_filename
                    partitions.extend(sub_partitions)
                except Exception as exc:
                    logger.warning(
                        "Failed to partition %s from zip %s: %s",
                        rel_path, zip_filename, exc,
                    )
                    # Fallback: create a simple partition with whatever we have
                    partitions.append(
                        FilePartition(
                            file_path=file_path,
                            partition_id=f"file_{rel_path}",
                            content=converted_data,
                            summary=f"File '{rel_path}' from archive '{zip_filename}' (partition error fallback).",
                            metadata={"source_archive": zip_filename, "error": str(exc)},
                        )
                    )

        if not partitions:
            partitions.append(
                FilePartition(
                    file_path=file_path,
                    partition_id="empty_archive",
                    content=file_data,
                    summary=f"Archive '{zip_filename}' contained no processable files.",
                    metadata={"type": "zip_archive", "empty": True},
                )
            )

        logger.info(
            "ZipPartitioner: '%s' -> %d partition(s) (%d project(s), %d file(s))",
            zip_filename, len(partitions), len(projects), len(files),
        )
        return partitions
