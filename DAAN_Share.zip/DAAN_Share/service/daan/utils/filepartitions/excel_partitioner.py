import math
import os
from typing import Any, Dict, List

from .base_partitioner import BasePartitioner
from .file_partition import FilePartition
from .tabular_helpers import generate_column_profile, smart_sample_rows


class ExcelPartitioner(BasePartitioner):
    def partition(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        partitions: List[FilePartition] = []
        sheets = file_data.get("sheets", {})

        min_rows_per_chunk = 25
        small_table_max_rows = 80
        max_partitions_per_table = 20
        schema_preview_rows = 8

        filename_lower = os.path.basename(file_path).lower()
        is_file_level_logic = any(k in filename_lower for k in ["mapping", "metadata", "rule", "schema", "config", "flow", "def", "spec"])

        logic_keywords = [
            "mapping", "transformation", "rule", "logic", "source_col", "target_col",
            "business_key", "lookup", "expression", "condition", "script", "query",
            "api", "endpoint", "job_name", "workflow",
        ]

        def _is_logic_table(columns: List[str]) -> bool:
            for col in columns:
                col_lower = str(col).lower()
                if "description" in col_lower:
                    continue
                if any(k in col_lower for k in logic_keywords):
                    return True
            return False

        def _summarize_rows(rows: List[Dict[str, Any]], columns: List[str]) -> str:
            if not rows:
                return "(no rows)"
            preview_rows = rows[:3]
            preview_parts: List[str] = []
            for r in preview_rows:
                items = []
                for col in columns[:6]:
                    if col in r:
                        val = r.get(col)
                        val_str = str(val).strip()
                        if val_str and val_str.lower() not in {"nan", "none"}:
                            items.append(f"{col}={val_str[:60]}")
                if items:
                    preview_parts.append("; ".join(items))
            return " | ".join(preview_parts) if preview_parts else "(row preview unavailable)"

        for sheet_name, sheet_data in sheets.items():
            tables = sheet_data.get("tables", []) if isinstance(sheet_data, dict) else []

            if tables:
                for t_idx, table in enumerate(tables):
                    if not isinstance(table, dict):
                        continue
                    table_name = str(table.get("table_name", f"Table_{t_idx}"))
                    table_type = str(table.get("table_type", "unknown"))
                    columns = table.get("columns", []) or []
                    rows = table.get("rows", []) or []
                    total_rows = len(rows)

                    columns_str = [str(c) for c in columns]
                    sheet_lower = sheet_name.lower()
                    is_mapping_sheet = any(k in sheet_lower for k in ["mapping", "metadata", "rule", "schema", "config", "flow", "def"])
                    is_logic = is_file_level_logic or is_mapping_sheet or _is_logic_table(columns_str)

                    if total_rows == 0:
                        summary = (
                            f"Excel Sheet '{sheet_name}' / {table_name} ({table_type}) with 0 rows. "
                            f"Columns: {', '.join(columns_str[:12])}"
                        )
                        partitions.append(
                            FilePartition(
                                file_path=file_path,
                                partition_id=f"sheet_{sheet_name}_table_{t_idx}",
                                content={
                                    "sheet_name": sheet_name,
                                    "table_name": table_name,
                                    "table_type": table_type,
                                    "columns": columns,
                                    "rows": [],
                                },
                                summary=summary,
                                metadata={
                                    "type": "excel_table",
                                    "sheet_name": sheet_name,
                                    "table_name": table_name,
                                    "table_type": table_type,
                                    "columns": columns,
                                    "row_range": [0, 0],
                                    "total_rows": 0,
                                },
                            )
                        )
                        continue

                    preview_rows = rows[: min(schema_preview_rows, total_rows)]
                    schema_preview = _summarize_rows(preview_rows, columns_str)
                    schema_summary = (
                        f"Excel Sheet '{sheet_name}' / {table_name} ({table_type}) schema. "
                        f"Total rows: {total_rows}. Columns: {', '.join(columns_str[:12])}. "
                        f"Row preview: {schema_preview}"
                    )
                    partitions.append(
                        FilePartition(
                            file_path=file_path,
                            partition_id=f"sheet_{sheet_name}_table_{t_idx}_schema",
                            content={
                                "sheet_name": sheet_name,
                                "table_name": table_name,
                                "table_type": table_type,
                                "columns": columns,
                                "rows": preview_rows if total_rows > small_table_max_rows else rows,
                            },
                            summary=schema_summary,
                            metadata={
                                "type": "excel_table_schema",
                                "sheet_name": sheet_name,
                                "table_name": table_name,
                                "table_type": table_type,
                                "columns": columns,
                                "row_range": [1, min(total_rows, (len(rows) if total_rows <= small_table_max_rows else len(preview_rows)))],
                                "total_rows": total_rows,
                            },
                        )
                    )

                    if total_rows <= small_table_max_rows or is_logic:
                        if total_rows <= small_table_max_rows:
                            continue

                        rows_per_partition = max(min_rows_per_chunk, int(math.ceil(total_rows / float(max_partitions_per_table))))

                        for start in range(0, total_rows, rows_per_partition):
                            end = min(start + rows_per_partition, total_rows)
                            chunk_rows = rows[start:end]
                            row_preview = _summarize_rows(chunk_rows, columns_str)
                            summary = (
                                f"Excel Sheet '{sheet_name}' / {table_name} ({table_type}) rows {start + 1}-{end} of {total_rows}. "
                                f"Columns: {', '.join(columns_str[:12])}. "
                                f"Row preview: {row_preview}"
                            )

                            partitions.append(
                                FilePartition(
                                    file_path=file_path,
                                    partition_id=f"sheet_{sheet_name}_table_{t_idx}_rows_{start + 1}_{end}",
                                    content={
                                        "sheet_name": sheet_name,
                                        "table_name": table_name,
                                        "table_type": table_type,
                                        "columns": columns,
                                        "rows": chunk_rows,
                                    },
                                    summary=summary,
                                    metadata={
                                        "type": "excel_table_chunk",
                                        "sheet_name": sheet_name,
                                        "table_name": table_name,
                                        "table_type": table_type,
                                        "columns": columns,
                                        "row_range": [start + 1, end],
                                        "total_rows": total_rows,
                                    },
                                )
                            )
                    else:
                        sampled_rows = smart_sample_rows(rows, total_rows, target_size=50)
                        col_profile = generate_column_profile(rows, columns_str)
                        preview_text = _summarize_rows(sampled_rows[:5], columns_str)
                        summary = (
                            f"Data Profile: Excel Sheet '{sheet_name}'. "
                            f"Contains {total_rows} rows. "
                            f"Metadata: [Rows: {total_rows}, Cols: {len(columns)}, Logic Table: No].\n"
                            f"Column Statistics: {col_profile}\n"
                            f"Sample Data ({len(sampled_rows)} density-optimized rows): {preview_text}"
                        )

                        partitions.append(
                            FilePartition(
                                file_path=file_path,
                                partition_id=f"sheet_{sheet_name}_table_{t_idx}_profile",
                                content={
                                    "sheet_name": sheet_name,
                                    "table_name": table_name,
                                    "table_type": table_type,
                                    "columns": columns,
                                    "total_rows": total_rows,
                                    "metadata": {
                                        "column_count": len(columns),
                                        "row_count": total_rows,
                                        "sampling_strategy": f"stratified_density_optimized_{len(sampled_rows)}_rows",
                                    },
                                    "sample_rows": sampled_rows,
                                },
                                summary=summary,
                                metadata={
                                    "type": "excel_data_profile",
                                    "sheet_name": sheet_name,
                                    "columns": columns,
                                    "total_rows": total_rows,
                                    "is_sampled": True,
                                },
                            )
                        )
            else:
                rows = sheet_data.get("rows", []) if isinstance(sheet_data, dict) else []
                columns = sheet_data.get("columns", []) if isinstance(sheet_data, dict) else []
                row_count = len(rows)
                columns_str = [str(c) for c in (columns or [])]
                row_preview = _summarize_rows(rows, columns_str)
                summary = (
                    f"Excel Sheet '{sheet_name}' with {row_count} rows. "
                    f"Columns: {', '.join(columns_str[:12])}. "
                    f"Row preview: {row_preview}"
                )
                partitions.append(
                    FilePartition(
                        file_path=file_path,
                        partition_id=f"sheet_{sheet_name}",
                        content=sheet_data,
                        summary=summary,
                        metadata={"type": "excel_sheet", "sheet_name": sheet_name, "columns": columns},
                    )
                )

        return partitions
