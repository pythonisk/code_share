from abc import ABC, abstractmethod
from typing import Any, Dict, List

from .file_partition import FilePartition


class BasePartitioner(ABC):
    @abstractmethod
    def partition(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        pass
