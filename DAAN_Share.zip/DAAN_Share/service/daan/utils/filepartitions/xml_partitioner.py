import json
from typing import Any, Dict, List

from .adso_partitioner import ADSOPartitioner
from .base_partitioner import BasePartitioner
from .file_partition import FilePartition


class XmlPartitioner(BasePartitioner):
    def __init__(self):
        self.adso_partitioner = ADSOPartitioner()

    def partition(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        data = file_data.get("content")
        root_tag = file_data.get("root_tag") or file_data.get("summary", {}).get("root_element")

        # Detect SAP BW ADSO XML and route to specialised extraction
        if ADSOPartitioner.is_adso_xml(root_tag, data):
            return self.adso_partitioner.partition_from_dict(file_path, data)

        try:
            pretty = json.dumps(data, indent=2, ensure_ascii=False)
        except Exception:
            pretty = str(data)

        max_preview_chars = 8000
        truncated = False
        if len(pretty) > max_preview_chars:
            pretty = pretty[:max_preview_chars]
            truncated = True

        preview_lines = "\n".join(pretty.splitlines()[:20])
        summary = f"XML file. Root: {root_tag}. Preview:\n{preview_lines}"
        if truncated:
            summary += "\n(truncated)"

        return [
            FilePartition(
                file_path=file_path,
                partition_id="xml_preview",
                content=pretty,
                summary=summary,
                metadata={"type": "xml", "root": root_tag, "truncated": truncated},
            )
        ]
