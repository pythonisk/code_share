import logging
import os
from typing import Any, Dict, List, Optional

from daan.utils.file_to_json import FileToJsonConverter
from daan.utils.filepartitions import (
    CodePartitioner,
    DocxPartitioner,
    ExcelPartitioner,
    JsonPartitioner,
    PdfPartitioner,
    TabularPartitioner,
    TableauPartitioner,
    TextPartitioner,
    XmlPartitioner,
    ZipPartitioner,
)
from daan.utils.filepartitions.file_partition import FilePartition


logger = logging.getLogger(__name__)


class FilePartitioner:
    """
    Responsible for splitting files into manageable partitions and generating summaries.
    """

    def __init__(self, converter: Optional[FileToJsonConverter] = None):
        self.converter = converter or FileToJsonConverter()
        self.partitioner_registry = {
            "excel_workbook": ExcelPartitioner,
            "tabular_data": TabularPartitioner,
            "code_file": CodePartitioner,
            "docx_file": DocxPartitioner,
            "pdf_file": PdfPartitioner,
            "json_file": JsonPartitioner,
            "xml_file": XmlPartitioner,
            "tableau_file": TableauPartitioner,
            "zip_archive": ZipPartitioner,
            "text_file": TextPartitioner,
            "unknown": TextPartitioner,
        }

    def _resolve_partitioner(self, file_type: str):
        partitioner_cls = self.partitioner_registry.get(file_type)
        if not partitioner_cls:
            return None
        if partitioner_cls is TextPartitioner:
            return partitioner_cls(converter=self.converter)
        return partitioner_cls()

    def partition_file(self, file_path: str, file_data: Dict[str, Any]) -> List[FilePartition]:
        """
        Partition a file based on its type and content.
        """
        filename = os.path.basename(file_path)
        partitions: List[FilePartition] = []

        try:
            content = file_data.get("content", {})
            file_type = content.get("type", "unknown")

            partitioner = self._resolve_partitioner(file_type)
            if partitioner:
                partition_input = file_data if file_type == "tableau_file" else content
                partitions.extend(partitioner.partition(file_path, partition_input))
            else:
                partitions.append(
                    FilePartition(
                        file_path=file_path,
                        partition_id="full_file",
                        content=content,
                        summary=f"Full content of {filename} ({file_type})",
                        metadata={"type": file_type},
                    )
                )

        except Exception as e:
            logger.error(f"Error partitioning file {filename}: {e}")
            partitions.append(
                FilePartition(
                    file_path=file_path,
                    partition_id="error_fallback",
                    content=str(file_data),
                    summary=f"Error partitioning file: {str(e)}",
                    metadata={"error": str(e)},
                )
            )

        return partitions
