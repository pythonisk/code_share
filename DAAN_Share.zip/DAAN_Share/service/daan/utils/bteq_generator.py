"""Type 1 BTEQ generator with deterministic-first assembly and LLM fallback."""
 
import logging
import os
import re
import zipfile
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime as _dt
from pathlib import Path

import openpyxl

logger = logging.getLogger(__name__)
def _read_excel_raw(excel_path):
    """Read the first relevant Excel sheet and return headers plus row dicts."""
    wb = openpyxl.load_workbook(excel_path, read_only=True)
    sheet = None
    for name in ('Columnn_Mappings', 'Column_Mappings', 'Sheet1'):
        if name in wb.sheetnames:
            sheet = wb[name]
            break
    if sheet is None:
        sheet = wb[wb.sheetnames[0]]
 
    all_rows = []
    for row in sheet.iter_rows(values_only=True):
        all_rows.append([str(c).strip() if c is not None else '' for c in row])
    wb.close()
 
    if not all_rows:
        return [], []
 
    header_idx = 0
    best_score = -1
    for i, row in enumerate(all_rows[:10]):
        non_empty = [c for c in row if c]
        if len(non_empty) < 3:
            continue
        row_text = ' '.join(non_empty).lower()
        score = 0
        score += sum(1 for c in non_empty if '_' in c) * 3
        for kw in ('column', 'table', 'source', 'target', 'rule', 'mapping', 'entity', 'name'):
            if kw in row_text:
                score += 1
        if 'details' in row_text:
            score -= 2
        if score > best_score:
            best_score = score
            header_idx = i
 
    headers = all_rows[header_idx]
    clean_headers = []
    for j, h in enumerate(headers):
        clean_headers.append(h if h else f"Col_{j}")
 
    data_rows = []
    for row in all_rows[header_idx + 1:]:
        if not any(cell.strip() for cell in row if cell):
            continue
        row_vals = [row[j] if j < len(row) else '' for j in range(len(clean_headers))]
        if any(v in clean_headers for v in row_vals if v):
            continue
        row_dict = {}
        for j, h in enumerate(clean_headers):
            row_dict[h] = row[j] if j < len(row) else ''
        data_rows.append(row_dict)
 
    return clean_headers, data_rows
 
 
def _detect_source_table_column(headers):
    """Auto-detect which header is the source table column."""
    for h in headers:
        hl = h.lower()
        if 'source' in hl and 'table' in hl:
            return h
    for h in headers:
        hl = h.lower()
        if 'source' in hl and ('name' in hl or 'tbl' in hl):
            return h
    for h in headers:
        if 'source' in h.lower():
            return h
    return None
 
 
def _detect_target_entity_column(headers):
    """Auto-detect which header is the target entity/table column."""
    for h in headers:
        hl = h.lower()
        if ('target' in hl or 'licdm' in hl or 'entity' in hl) and ('table' in hl or 'name' in hl):
            return h
    for h in headers:
        hl = h.lower()
        if 'target' in hl or 'licdm' in hl:
            return h
    return None
 
 
def _detect_target_column_column(headers):
    """Auto-detect which header is the target column name column."""
    for h in headers:
        hl = h.lower()
        if ('target' in hl or 'licdm' in hl) and 'column' in hl:
            return h
    return None


def _normalize_source_system_value(value):
    """Normalize a source-system literal into a lowercase system code."""
    cleaned = str(value or '').strip().strip("'\"")
    cleaned = cleaned.strip().lower()
    return cleaned or None


def _infer_block_source_system(rows, headers, source_table_name, fallback_source_system=None):
    """Infer the source system for one mapping block."""
    source_table_text = str(source_table_name or '').strip()
    if '.' in source_table_text:
        schema_prefix = _normalize_source_system_value(source_table_text.split('.', 1)[0])
        if schema_prefix and schema_prefix not in ('dbo', 'public'):
            return schema_prefix

    explicit = _normalize_source_system_value(fallback_source_system)
    if explicit:
        return explicit

    tgt_col_h = _detect_target_column_column(headers) or 'LICDM_COLUMN_NAME'
    src_col_h = _detect_column_name(headers, ['source'], ['column']) or 'SOURCE_COLUMN_NAME'
    src_tbl_h = _detect_source_table_column(headers) or 'SOURCE_TABLE_NAME'
    skip_src = {'', 'none', '<literal>', 'null', 'n/a', 'na'}

    literal_candidates = set()
    for row in rows:
        target_col = str(row.get(tgt_col_h, '') or '').strip().upper()
        if target_col != 'CTL_DATA_SOURCE_CD':
            continue

        source_table_val = str(row.get(src_tbl_h, '') or '').strip()
        source_column_val = str(row.get(src_col_h, '') or '').strip()
        is_literal_row = (not source_table_val or source_table_val.lower() in skip_src)
        if not is_literal_row or not source_column_val:
            continue

        normalized = _normalize_source_system_value(source_column_val)
        if normalized:
            literal_candidates.add(normalized)

    if len(literal_candidates) == 1:
        return next(iter(literal_candidates))

    return None


def _block_literal_signature(rows, source_col):
    """Build a variant signature from literal mapping values in one block."""
    skip_values = {'', 'none', '<literal>', 'null', 'n/a', 'na'}
    src_col_h = None
    lkp_sg_h = None
    if rows:
        for h in rows[0]:
            hl = h.lower()
            if 'source' in hl and 'column' in hl:
                src_col_h = h
            if 'lookup' in hl and ('sub_group' in hl or 'sub' in hl):
                lkp_sg_h = h

    literals = []
    for row in rows:
        src_tbl = row.get(source_col, '').strip()
        is_literal_row = (not src_tbl or src_tbl.lower() in skip_values)
        lkp_sg = row.get(lkp_sg_h, '').strip() if lkp_sg_h else ''
        src_col_val = row.get(src_col_h, '').strip() if src_col_h else ''

        if (is_literal_row or lkp_sg == '1') and src_col_val:
            if src_col_val.lower() not in skip_values and src_col_val.upper() != 'NULL':
                literals.append(src_col_val)

    return '|'.join(sorted(literals))


def _group_rows_by_source(data_rows, source_col, target_col_col=None):
    """Group mapping rows into contiguous source-table blocks."""
    skip_values = {'', 'none', '<literal>', 'null', 'n/a', 'na'}
    blocks = []
    current_src = None
    current_rows = []
    pending_shared = []
 
    for row in data_rows:
        src = row.get(source_col, '').strip()
        is_shared = (not src or src.lower() in skip_values)
 
        if is_shared:
            if current_src is None:
                pending_shared.append(row)
            else:
                current_rows.append(row)
        else:
            if src != current_src:
                if current_src is not None:
                    blocks.append((current_src, current_rows))
                current_src = src
                current_rows = list(pending_shared)
                pending_shared = []
            current_rows.append(row)
    if current_src is not None:
        blocks.append((current_src, current_rows))
    from collections import defaultdict as _defaultdict
    src_to_blocks = _defaultdict(list)
    block_order = []
    for src, rows in blocks:
        sig = _block_literal_signature(rows, source_col)
        src_to_blocks[src].append((sig, rows))
        if src not in block_order:
            block_order.append(src)

    merged = {}
    order = []
    for src in block_order:
        entries = src_to_blocks[src]
        unique_sigs = set(sig for sig, _ in entries if sig)
        if len(unique_sigs) <= 1:
            key = src
            if key not in merged:
                merged[key] = []
                order.append(key)
            for _, rows in entries:
                merged[key].extend(rows)
        else:
            for sig, rows in entries:
                if sig:
                    suffix = re.sub(r'[^a-zA-Z0-9]+', '_', sig).strip('_').lower()
                    if len(suffix) > 60:
                        suffix = suffix[:60].rstrip('_')
                    key = f"{src}__{suffix}"
                else:
                    key = src
                if key not in merged:
                    merged[key] = []
                    order.append(key)
                merged[key].extend(rows)

    return {src: merged[src] for src in order}
def _split_comma_source_tables(groups):
    """Expand groups whose keys contain comma-separated source tables."""
    expanded = {}
    for src, rows in groups.items():
        variant_suffix = ''
        base_key = src
        if '__' in src:
            last_dunder = src.rfind('__')
            base_key = src[:last_dunder]
            variant_suffix = src[last_dunder:]

        parts = [s.strip() for s in base_key.split(',') if s.strip()]
        if len(parts) <= 1:
            expanded[src] = rows
        else:
            for part in parts:
                full_key = part + variant_suffix
                if full_key not in expanded:
                    expanded[full_key] = []
                expanded[full_key].extend(rows)
    return expanded
def _read_common_mapping_instructions(excel_path):
    """Read the Common Mapping Instructions sheet when present."""
    try:
        wb = openpyxl.load_workbook(excel_path, read_only=True)
        if 'Common Mapping Instructions' not in wb.sheetnames:
            wb.close()
            return ''
        ws = wb['Common Mapping Instructions']
        lines = []
        for row in ws.iter_rows(values_only=True):
            cells = [str(c).strip() if c is not None else '' for c in row]
            line = ' | '.join(c for c in cells if c)
            if line:
                lines.append(line)
        wb.close()
        return '\n'.join(lines)
    except Exception:
        return ''
def _rows_to_markdown_table(headers, rows):
    """Convert list of row dicts to a markdown table string."""
    lines = ["| " + " | ".join(headers) + " |"]
    lines.append("| " + " | ".join(["---"] * len(headers)) + " |")
    for row in rows:
        vals = [row.get(h, '') for h in headers]
        lines.append("| " + " | ".join(vals) + " |")
    return "\n".join(lines)
def save_scripts_to_zip(scripts_dict, output_dir='output'):
    """Save .btq files and bundle them into a ZIP."""
    os.makedirs(output_dir, exist_ok=True)
    bteq_dir = os.path.join(output_dir, 'bteq_scripts')
    os.makedirs(bteq_dir, exist_ok=True)
 
    file_paths = []
    for fname, content in scripts_dict.items():
        fpath = os.path.join(bteq_dir, fname)
        with open(fpath, 'w', encoding='utf-8') as f:
            f.write(content)
        file_paths.append(fpath)
 
    ts = _dt.now().strftime('%Y%m%d_%H%M%S')
    zip_path = os.path.join(output_dir, f'bteq_scripts_{ts}.zip')
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for fpath in file_paths:
            zf.write(fpath, os.path.basename(fpath))
 
    logger.info(f"BTEQ LLM Generator: Saved {len(file_paths)} .btq files + ZIP -> {zip_path}")
    return zip_path, file_paths
def _detect_column_name(headers, prefix_keywords, suffix_keywords):
    """Find a header matching prefix + suffix keyword combo."""
    for h in headers:
        hl = h.lower()
        if any(p in hl for p in prefix_keywords) and any(s in hl for s in suffix_keywords):
            return h
    return None
 
 
def _extract_business_filters(rules_text: str, src_col: str) -> list:
    """Extract simple business filters and qualify them with `src.`."""
    import re as _re
    filters = []
    if not rules_text:
        return filters
    
    rules_lower = rules_text.lower()
    
    trim_match = _re.search(r"trim\s*\(\s*(\w+)\s*\)\s*(<>|!=|<)\s*['\"]", rules_text, _re.IGNORECASE)
    if trim_match:
        col = trim_match.group(1)
        filters.append(f"TRIM(src.{col}) <> ''")
    not_null_match = _re.search(r"(\w+)\s+is\s+not\s+null", rules_text, _re.IGNORECASE)
    if not_null_match:
        col = not_null_match.group(1)
        filters.append(f"src.{col} IS NOT NULL")
    numeric_match = _re.search(r"(\w+)\s*(>|>=|<|<=)\s*(\d+)", rules_text, _re.IGNORECASE)
    if numeric_match:
        col = numeric_match.group(1)
        op = numeric_match.group(2)
        val = numeric_match.group(3)
        filters.append(f"src.{col} {op} {val}")
    if any(phrase in rules_lower for phrase in ('not blank', 'non-blank', 'not empty', 'non-empty', 'exclude blank', 'exclude empty')):
        if src_col and src_col.lower() not in ('null', 'na', ''):
            filters.append(f"TRIM(src.{src_col}) <> ''")
            filters.append(f"src.{src_col} IS NOT NULL")
    return filters


def _parse_concat_rule_expression(rules_text: str) -> str | None:
    """Parse prose-style concatenate rules into a raw concatenation expression."""
    text = str(rules_text or '').strip()
    if 'concatenate' not in text.lower():
        return None

    delimiter_match = re.search(r'using\s+["\']([^"\']+)["\']', text, re.IGNORECASE)
    delimiter = delimiter_match.group(1) if delimiter_match else '~'

    columns_text = text
    if delimiter_match:
        columns_text = text[delimiter_match.end():]
    columns_text = re.sub(r'(?i)^\s*using\s+', '', columns_text).strip(' :,-')
    columns_text = re.sub(r'(?i)^concatenate\s+', '', columns_text).strip(' :,-')
    columns_text = re.sub(r'(?i)^with\s+', '', columns_text).strip(' :,-')
    columns_text = columns_text.replace(' and ', ',')

    raw_parts = [part.strip(" ' \t\r\n") for part in columns_text.split(',')]
    identifiers = [part for part in raw_parts if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', part)]
    if len(identifiers) < 2:
        return None

    expression_parts = []
    for index, identifier in enumerate(identifiers):
        if index:
            expression_parts.append(_quote_sql_literal(delimiter))
        expression_parts.append(identifier)
    return ' || '.join(expression_parts)


def _build_column_derivations(headers, rows, source_table, source_system, entity_name):
    """Pre-compute derivation metadata from mapping rows."""
    tgt_col_h = _detect_column_name(headers, ['licdm', 'target'], ['column']) or 'LICDM_COLUMN_NAME'
    src_col_h = _detect_column_name(headers, ['source'], ['column']) or 'SOURCE_COLUMN_NAME'
    src_tbl_h = _detect_column_name(headers, ['source'], ['table']) or 'SOURCE_TABLE_NAME'
    rules_h = _detect_column_name(headers, ['licdm', 'rule'], ['rule']) or 'LICDM_RULES'
    transform_h = _detect_column_name(headers, ['business', 'transform'], ['transform', 'business']) or 'BUSINESS TRANSFORMATION'
    lkp_g_h = _detect_column_name(headers, ['lookup'], ['group_cd', 'group']) or 'Lookup_Group_Cd'
    lkp_sg_h = _detect_column_name(headers, ['lookup'], ['sub_group', 'sub']) or 'Lookup_Sub_Group_Cd'
 
    skip_src = {'', 'none', '<literal>', 'null', 'n/a', 'na'}
 
    target_columns = []
    column_specs = []
    sk_column = None
    natural_key_expr = None
    natural_key_col = None
    business_filters = []
 
    for row in rows:
        tgt_col = row.get(tgt_col_h, '').strip()
        if not tgt_col:
            continue
 
        src_col = row.get(src_col_h, '').strip()
        src_tbl = row.get(src_tbl_h, '').strip()
        rules = row.get(rules_h, '').strip()
        transformation = row.get(transform_h, '').strip()
        lkp_g = row.get(lkp_g_h, '').strip()
        lkp_sg = row.get(lkp_sg_h, '').strip()
 
        is_literal_src = (not src_tbl or src_tbl.lower() in skip_src)
 
        hint = ''
        rules_lower = rules.lower()
        source_col_lower = src_col.lower()

        if (
            ('generate sk' in rules_lower)
            or ('generated sk' in rules_lower)
            or ('already generated sk' in rules_lower)
            or source_col_lower.startswith('sk based on ')
        ):
            hint = 'SK_LOOKUP'
            if sk_column is None:
                sk_column = tgt_col
        elif rules and 'concatenat' in rules_lower:
            concat_expr = src_col if '||' in src_col else _parse_concat_rule_expression(rules) or rules
            hint = f'CONCATENATION: {concat_expr}'
            if natural_key_expr is None and '||' in concat_expr:
                natural_key_expr = concat_expr
                natural_key_col = tgt_col
        elif tgt_col.upper() == 'CTL_DATA_SOURCE_CD':
            if src_col and src_col.upper() not in ('NULL', 'NA', 'N/A', ''):
                hint = f'DIRECT_MAP: src.CTL_Data_Source_Cd'
            else:
                hint = f'DIRECT_MAP: src.CTL_Data_Source_Cd'
        elif lkp_g:
            if lkp_sg == '1':
                hint = f'HARDCODE: {src_col}'
            else:
                hint = f'SOURCE_LOOKUP: Lookup_Group_Cd={lkp_g}, Sub_Group={lkp_sg}, source_col={src_col} — use datalake_id from LIC_STANDARD_LOOKUP (NOT Lookup_Id)'
        elif src_col.upper() in ('NULL', 'NA', 'N/A', '') or (is_literal_src and not src_col):
            hint = 'SET_NULL'
        elif is_literal_src and src_col:
            hint = f'LITERAL: {src_col}'
        elif 'cast' in src_col.lower():
            import re as _re
            cast_match = _re.search(r'CAST\s*\(\s*(\w+)', src_col, _re.IGNORECASE)
            raw_col = cast_match.group(1) if cast_match else src_col
            tgt_lower = tgt_col.lower()
            if any(kw in tgt_lower for kw in ('_dttm', '_date', '_dt', '_ts', 'year_from', 'year_to', 'submission')):
                hint = f'DIRECT_MAP_DATE: {raw_col}'
            else:
                hint = f'DIRECT_MAP: {raw_col}'
        elif rules and ('if ' in rules_lower or 'coalesce' in rules_lower):
            hint = f'CONDITIONAL: {rules}'
        else:
            tgt_lower = tgt_col.lower()
            if any(kw in tgt_lower for kw in ('_dttm', '_date', '_dt', '_ts', 'year_from', 'year_to', 'submission')):
                hint = f'DIRECT_MAP_DATE: {src_col}'
            else:
                hint = f'DIRECT_MAP: {src_col}'
 
        target_columns.append(tgt_col)
        column_specs.append({
            'target_col': tgt_col,
            'source_col': src_col,
            'rules': rules,
            'transformation': transformation,
            'lookup_group': lkp_g,
            'lookup_sub_group': lkp_sg,
            'derivation_hint': hint,
        })
        
        row_filters = _extract_business_filters(rules, src_col)
        row_filters += _extract_business_filters(transformation, src_col)
        business_filters.extend(row_filters)

    business_filters = list(dict.fromkeys(business_filters))

    def _is_literal_column(spec):
        hint = str(spec.get('derivation_hint') or '').upper()
        return hint.startswith('LITERAL:') or hint.startswith('HARDCODE:')

    if natural_key_col is None:
        for spec in column_specs:
            if spec['target_col'] == sk_column:
                continue
            if _is_literal_column(spec):
                continue
            t = spec['target_col'].lower()
            if 'source_' in t and '_val' in t:
                natural_key_col = spec['target_col']
                break
            if t.endswith('_num'):
                natural_key_col = spec['target_col']
                break
        if natural_key_col is None and len(target_columns) > 1:
            for col in target_columns[1:]:
                if col == sk_column:
                    continue
                spec = next((s for s in column_specs if s['target_col'] == col), None)
                if spec and not _is_literal_column(spec):
                    natural_key_col = col
                    break

    if natural_key_expr is None and natural_key_col:
        for spec in column_specs:
            if spec['target_col'] != natural_key_col:
                continue
            hint = str(spec.get('derivation_hint') or '')
            if hint.startswith('CONCATENATION:'):
                natural_key_expr = _strip_hint_body(hint)
            elif hint.startswith('DIRECT_MAP') or hint.startswith('DIRECT_MAP_DATE'):
                natural_key_expr = _strip_hint_body(hint)
            elif hint.startswith('LITERAL:') or hint.startswith('HARDCODE:'):
                natural_key_expr = _quote_sql_literal(_strip_hint_body(hint))
            break

    return target_columns, column_specs, sk_column, natural_key_expr, natural_key_col, business_filters


def _strip_hint_body(hint):
    """Extract the SQL-like portion from a derivation hint."""
    body = str(hint or '').split(':', 1)[-1].strip()
    if ' — ' in body:
        body = body.split(' — ', 1)[0].strip()
    return body


def _quote_sql_literal(value):
    """Quote a SQL literal only when needed."""
    text = str(value or '').strip()
    if not text:
        return "''"
    if text.startswith("'") or text.endswith("'"):
        text = text.strip("'").strip()
    if re.fullmatch(r'-?\d+(\.\d+)?', text):
        return text
    if text.startswith('#') and text.endswith('#'):
        return text
    escaped = text.replace("'", "''")
    return f"'{escaped}'"


def _detect_ctl_data_source_mode(column_specs):
    """Determine whether CTL_Data_Source_Cd is sourced or hardcoded from mapping facts."""
    for spec in column_specs:
        if str(spec.get('target_col') or '').strip().upper() != 'CTL_DATA_SOURCE_CD':
            continue

        hint = str(spec.get('derivation_hint') or '').strip().upper()
        if hint.startswith('LITERAL:') or hint.startswith('HARDCODE:'):
            return 'hardcoded'
        if hint:
            return 'sourced'

    return 'sourced'


def _normalize_family_id(entity_name):
    """Create a deterministic family id from the target entity name."""
    normalized = re.sub(r'[^a-zA-Z0-9]+', '_', str(entity_name or '').strip().lower()).strip('_')
    return normalized or 'entity'


def _should_group_by_target(column_specs, business_filters):
    """Only add GROUP BY when mapping facts explicitly imply dedupe or aggregation."""
    filter_text = ' '.join(str(item or '') for item in business_filters).upper()
    if any(token in filter_text for token in ('GROUP BY', 'DISTINCT', 'DEDUP', 'DEDUPLICATE', 'AGGREGATE')):
        return True

    for spec in column_specs:
        combined = ' '.join(
            str(spec.get(key) or '')
            for key in ('rules', 'transformation', 'derivation_hint')
        ).upper()
        if any(token in combined for token in ('GROUP BY', 'DISTINCT', 'DEDUP', 'DEDUPLICATE', 'AGGREGATE')):
            return True

    return False


def _build_type1_family_profile(
    entity_name,
    source_table,
    source_system,
    target_columns,
    column_specs,
    business_filters,
    variant_signature='',
    multi_source_mapping=False,
):
    """Build a deterministic Type 1 family profile from mapping facts only."""
    family_id = _normalize_family_id(entity_name)
    ctl_mode = _detect_ctl_data_source_mode(column_specs)
    target_columns_upper = {str(col).strip().upper() for col in target_columns}
    business_filters_upper = ' '.join(str(item) for item in business_filters).upper()

    requires_deleted_flag = True
    if 'RECORD_DELETED_FLAG' in target_columns_upper:
        requires_deleted_flag = True

    group_by_required = bool(multi_source_mapping) or _should_group_by_target(column_specs, business_filters)
    deleted_row_filter_required = True

    return {
        'family_id': family_id,
        'family_kind': 'type1',
        'target_entity': str(entity_name or '').strip().upper(),
        'source_table': str(source_table or '').strip().upper(),
        'source_system': str(source_system or '').strip().upper(),
        'variant_signature': str(variant_signature or '').strip(),
        'inc_has_record_deleted_flag': requires_deleted_flag,
        'inc_has_ctl_data_source_cd': True,
        'inserts_has_audit_columns': True,
        'target_has_audit_columns': True,
        'step2_filters_deleted_rows': deleted_row_filter_required,
        'ctl_data_source_mode': ctl_mode,
        'target_uses_group_by': group_by_required,
        'target_uses_positional_group_by': group_by_required,
    }


def _build_type1_deterministic_scaffold(scaffold_spec):
    """Return a complete 4-step Type 1 scaffold with FORBIDDEN rules and exit codes."""
    return f"""
╔═══════════════════════════════════════════════════════════════════╗
║  ⛔ TYPE 1 SCRIPT — READ CAREFULLY BEFORE GENERATING              ║
╚═══════════════════════════════════════════════════════════════════╝

Generate EXACTLY 4 steps using ONLY TWO work tables: _INC and _INSERTS

╔═══════════════════════════════════════════════════════════════════╗
║  🚫 ABSOLUTELY FORBIDDEN — DO NOT USE ANY OF THESE                ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  ❌ _UPDATES table                                                ║
║  ❌ _HISTADJ table                                                ║
║  ❌ EFF_FROM_DTTM column                                          ║
║  ❌ EFF_TO_DTTM column                                            ║
║  ❌ CTL_UPDATED_DTTM                                              ║
║  ❌ CTL_UPDATED_JOB_ID                                            ║
║  ❌ CTL_UPDATED_RUN_ID                                            ║
║  ❌ LAG() window function                                         ║
║  ❌ DELETE FROM target table                                      ║
║  ❌ MERGE statements                                              ║
║  ❌ .SET commands                                                 ║
║  ❌ SELECT * or src.*                                             ║
║  ❌ DROP TABLE                                                    ║
║  ❌ CREATE MULTISET TABLE                                         ║
║                                                                   ║
║  ⚠️  IF YOUR OUTPUT CONTAINS ANY OF THE ABOVE, IT IS WRONG!      ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝

## CORRECT STRUCTURE:

.LOGON #TD_SERVER_NAME#/#ETL_USER_ID#,$tdwallet(#ETL_USER_ID#);

/* STEP 1: Populate _INC */
DELETE FROM {scaffold_spec['wrk']}_INC ALL;
.IF ERRORCODE <> 0 THEN .EXIT 10

INSERT INTO {scaffold_spec['wrk']}_INC (
    {scaffold_spec['type1_inc_col_list']}
)
SELECT
    B.{scaffold_spec['sk_column']},
    /* For STRING columns: COALESCE(TRIM(A.<col>), '') */
    /* For DATE columns: COALESCE(A.<col>, DATE '1900-01-01') */
    /* For TIMESTAMP columns: COALESCE(A.<col>, TIMESTAMP '1900-01-01 00:00:00') */
    <derive business columns using COALESCE patterns above>,
    CASE WHEN A.dm_operation_type IN ('D') THEN 1 ELSE 0 END AS RECORD_DELETED_FLAG,
    A.CTL_Data_Source_Cd
FROM (
    SELECT <natural_key_derivation>, <business columns>
    FROM {scaffold_spec['src_view']} src
    WHERE src.dm_operation_type IN ('I', 'A', 'D')
      AND UPPER(src.CTL_Data_Source_Cd) = '{scaffold_spec['source_system_upper']}'
      AND src.CTL_Created_Dttm BETWEEN TIMESTAMP '#MINIMUM_OPEN_DATE#' AND TIMESTAMP '#MAXIMUM_OPEN_DATE#'
    GROUP BY <all non-aggregate columns>
) A
INNER JOIN {scaffold_spec['sk_tbl']} B  /* MUST be INNER JOIN for SK lookup */
    ON A.<natural_key> = B.{scaffold_spec['natural_key_col']}
    AND UPPER(B.SourceTableName) = '{scaffold_spec['source_table_upper']}';
.IF ERRORCODE <> 0 THEN .EXIT 20

/* STEP 2: Populate _INSERTS (new records only) */
DELETE FROM {scaffold_spec['wrk']}_INSERTS ALL;
.IF ERRORCODE <> 0 THEN .EXIT 30

INSERT INTO {scaffold_spec['wrk']}_INSERTS (
    {scaffold_spec['type1_inserts_col_list']}
)
SELECT
    A.{scaffold_spec['sk_column']},
    <business columns from A>,
    A.CTL_Data_Source_Cd
FROM {scaffold_spec['wrk']}_INC A
LEFT JOIN {scaffold_spec['tgt']} tgt
    ON A.{scaffold_spec['sk_column']} = tgt.{scaffold_spec['sk_column']}
WHERE tgt.{scaffold_spec['sk_column']} IS NULL{scaffold_spec['step2_deleted_filter_line']};
.IF ERRORCODE <> 0 THEN .EXIT 40

/* STEP 3: INSERT into target — MUST have GROUP BY */
BEGIN TRANSACTION;

INSERT INTO {scaffold_spec['tgt']} (
    {scaffold_spec['type1_target_col_list']}
)
SELECT
    <all columns from _INSERTS>,
    TIMESTAMP '#V_CURRENT_TIMESTAMP#' AS CTL_CREATED_DTTM,
    #JOB_ID# AS CTL_CREATED_JOB_ID,
    #JOB_RUN_ID# AS CTL_CREATED_RUN_ID
FROM {scaffold_spec['wrk']}_INSERTS
GROUP BY 1, 2, 3, ...;  /* REQUIRED: positional GROUP BY covering ALL select columns */

END TRANSACTION;
.IF ERRORCODE <> 0 THEN .EXIT 50

/* STEP 4: Cleanup */
DELETE FROM {scaffold_spec['wrk']}_INC ALL;
.IF ERRORCODE <> 0 THEN .EXIT 60

DELETE FROM {scaffold_spec['wrk']}_INSERTS ALL;
.IF ERRORCODE <> 0 THEN .EXIT 70

.LOGOFF;
.QUIT 0;

╔═══════════════════════════════════════════════════════════════════╗
║  ✅ CHECKLIST — VERIFY BEFORE OUTPUT                              ║
╠═══════════════════════════════════════════════════════════════════╣
║  ☑ Only 2 work tables: _INC and _INSERTS                         ║
║  ☑ Only 3 audit columns: CTL_CREATED_DTTM, JOB_ID, RUN_ID        ║
║  ☑ Exit codes: 10, 20, 30, 40, 50, 60, 70 in sequence            ║
║  ☑ Final: .QUIT 0                                                ║
║  ☑ COALESCE(TRIM(...), '') for all string columns                ║
║  ☑ INNER JOIN for SK lookup in Step 1                            ║
║  ☑ GROUP BY 1,2,3... in Step 3 target INSERT                     ║
╚═══════════════════════════════════════════════════════════════════╝
"""


def _build_prompt_for_source_table(
    source_table, entity_name, headers, rows, source_system,
    common_instructions='',
    catalog_prompt='',
    family_profile=None,
):
    """Build a compact Type 1 fallback prompt."""
    mapping_text = _rows_to_markdown_table(headers, rows)

    target_columns, column_specs, sk_column, natural_key_expr, natural_key_col, business_filters = \
        _build_column_derivations(headers, rows, source_table, source_system, entity_name)

    if not sk_column and target_columns:
        sk_column = target_columns[0]

    if not natural_key_col:
        natural_key_col = 'SOURCE_KEYS'

    indent = '    '
    target_col_list = (',\n' + indent).join(target_columns)
    col_derivation_lines = []
    for spec in column_specs:
        hint = str(spec.get('derivation_hint') or '')
        if not (
            hint == 'SK_LOOKUP'
            or hint == 'SET_NULL'
            or hint.startswith('CONCATENATION:')
            or hint.startswith('SOURCE_LOOKUP:')
            or hint.startswith('LITERAL:')
            or hint.startswith('HARDCODE:')
            or hint.startswith('CONDITIONAL:')
        ):
            continue
        col_derivation_lines.append(
            f"  - `{spec['target_col']}`: {hint}"
            + (f" | Rules: {spec['rules']}" if spec['rules'] else '')
            + (f" | Transform: {spec['transformation'][:120]}" if spec['transformation'] else '')
        )
    if not col_derivation_lines:
        col_derivation_lines.append("  - Standard direct maps omitted; use exact target/source names from context.")
    col_derivation_text = '\n'.join(col_derivation_lines)

    lookup_joins = []
    for spec in column_specs:
        if spec['lookup_group']:
            alias = f"lkp_{spec['target_col'].lower()}"
            if spec['lookup_sub_group'] == '1':
                pass
            else:
                lookup_joins.append(
                    f"Left Outer Join #DB_PREFIX#core_v.LIC_STANDARD_LOOKUP {alias}\n"
                    f"    ON TRIM(src.{spec['source_col']}) = TRIM({alias}.Source_Cd)\n"
                    f"    AND {alias}.Lookup_Group_Cd = '{spec['lookup_group']}'\n"
                    f"    AND {alias}.Lookup_Sub_Group_Cd IN ({spec['lookup_sub_group']})\n"
                    f"    AND {alias}.Record_Deleted_Flag = 0"
                )
    lookup_join_text = '\n'.join(lookup_joins) if lookup_joins else '(none needed)'

    wrk = f"#DB_PREFIX#WRK_T.{source_system.upper()}__{source_table.upper()}__{entity_name.upper()}"
    tgt = f"#DB_PREFIX#CORE_V.{entity_name.upper()}"
    sk_tbl = f"#DB_PREFIX#CORE_V.SURROGATE_KEY_TBL_{entity_name.upper()}"
    src_view = f"#DB_PREFIX#SRI_{source_system.upper()}_V.{source_table.upper()}"

    family_profile = family_profile or _build_type1_family_profile(
        entity_name,
        source_table,
        source_system,
        target_columns,
        column_specs,
        business_filters,
    )

    common_section = ''
    if common_instructions:
        common_section = f"""
## Common Mapping Instructions
{common_instructions}
"""

    type1_include_record_deleted = family_profile.get('inc_has_record_deleted_flag', True)
    type1_include_ctl_data_source = family_profile.get('inc_has_ctl_data_source_cd', True)
    type1_inserts_has_audit = family_profile.get('inserts_has_audit_columns', True)
    type1_target_has_audit = family_profile.get('target_has_audit_columns', True)
    type1_step2_filters_deleted = family_profile.get('step2_filters_deleted_rows', True)
    type1_ctl_mode = family_profile.get('ctl_data_source_mode', 'sourced')
    type1_inc_cols = [sk_column, natural_key_col] + [
        c for c in target_columns if c != sk_column and c != natural_key_col
    ]
    if type1_include_record_deleted:
        type1_inc_cols.append('RECORD_DELETED_FLAG')
    if type1_include_ctl_data_source:
        type1_inc_cols.append('CTL_DATA_SOURCE_CD')
    _seen_t1 = set()
    type1_inc_cols = [
        c for c in type1_inc_cols if not (c.upper() in _seen_t1 or _seen_t1.add(c.upper()))
    ]
    type1_inc_col_list = (',\n' + indent).join(type1_inc_cols)

    type1_inserts_cols = [c for c in target_columns]
    if type1_include_ctl_data_source:
        type1_inserts_cols.append('CTL_DATA_SOURCE_CD')
    if type1_inserts_has_audit:
        type1_inserts_cols += ['CTL_CREATED_DTTM', 'CTL_CREATED_JOB_ID', 'CTL_CREATED_RUN_ID']
    _seen_t1_ins = set()
    type1_inserts_cols = [
        c for c in type1_inserts_cols if not (c.upper() in _seen_t1_ins or _seen_t1_ins.add(c.upper()))
    ]
    type1_inserts_col_list = (',\n' + indent).join(type1_inserts_cols)

    type1_target_cols = [c for c in target_columns]
    if type1_include_ctl_data_source:
        type1_target_cols.append('CTL_DATA_SOURCE_CD')
    if type1_target_has_audit:
        type1_target_cols += ['CTL_CREATED_DTTM', 'CTL_CREATED_JOB_ID', 'CTL_CREATED_RUN_ID']
    _seen_t1_target = set()
    type1_target_cols = [
        c for c in type1_target_cols if not (c.upper() in _seen_t1_target or _seen_t1_target.add(c.upper()))
    ]
    type1_target_col_list = (',\n' + indent).join(type1_target_cols)

    business_filters_text = '\n'.join(f"  - {f}" for f in business_filters) if business_filters else '(none detected)'

    dynamic_context = f"""## Context
- Target entity: {entity_name}
- Source table: {source_table}
- Source system: {source_system.upper()}
- Source view: {src_view}
- Target table: {tgt}
- Work table prefix: {wrk}
- SK table: {sk_tbl}
- SK column: {sk_column}
- Natural key column: {natural_key_col}
- Natural key expression: {natural_key_expr or '(derive from mapping)'}

## Target Columns
{target_col_list}

## _INC Columns
{type1_inc_col_list}

## _INSERTS Columns
{type1_inserts_col_list}

## Business Filters
{business_filters_text}

## Key Derivations
{col_derivation_text}

## Lookup JOINs
{lookup_join_text}

## Full Mapping Data
{mapping_text}
{common_section}
"""

    catalog_section = ''
    if catalog_prompt and len(catalog_prompt.strip()) > 500:
        catalog_section = f"""
## Supplemental Catalog Rules
{catalog_prompt.replace('{Context}', dynamic_context)}
"""

    step2_deleted_filter_line = "\n  AND A.RECORD_DELETED_FLAG = 0" if type1_step2_filters_deleted else ""
    step3_group_by_line = "GROUP BY 1, 2, 3, ... <positional for ALL columns>;"
    type1_scaffold = _build_type1_deterministic_scaffold({
        'wrk': wrk,
        'tgt': tgt,
        'sk_tbl': sk_tbl,
        'src_view': src_view,
        'source_system_upper': source_system.upper(),
        'source_table_upper': source_table.upper(),
        'sk_column': sk_column,
        'natural_key_col': natural_key_col,
        'type1_inc_col_list': type1_inc_col_list,
        'type1_inserts_col_list': type1_inserts_col_list,
        'type1_target_col_list': type1_target_col_list,
        'step2_deleted_filter_line': step2_deleted_filter_line,
        'step3_group_by_line': step3_group_by_line,
        'business_filters_text': business_filters_text,
    })

    prompt = f"""Generate one raw Teradata BTEQ Type 1 script only.

Use the supplemental rules, dynamic context, and scaffold below together.
Honor the exact Type 1 family shape: 4 steps, `_INC` and `_INSERTS` only, explicit columns everywhere, and no Type 2 artifacts.
Use the exact table names, column names, placeholders, and family-profile expectations from the context.
Output raw `.btq` only, with no markdown or commentary.

{catalog_section}
{dynamic_context}

## Compact Scaffold
{type1_scaffold}
"""
    return prompt

 
 
def _extract_script_from_response(response_text):
    """Extract the raw BTEQ script from an LLM response."""
    text = response_text.strip()
    if "```" in text:
        fence_start = text.index("```")
        text = text[fence_start:]
        first_newline = text.index("\n") if "\n" in text else len(text)
        text = text[first_newline + 1:]
    if "```" in text:
        text = text[: text.rfind("```")]
    return text.strip()


def _fix_select_star(script_text, full_columns):
    """Replace generated `SELECT *` clauses with explicit column lists."""
    if 'SELECT *' not in script_text.upper() and 'SELECT  *' not in script_text.upper():
        return script_text

    col_list = ',\n    '.join(full_columns)
    fixed = re.sub(
        r'(?i)\bSELECT\s+\*\s+FROM\b',
        f'SELECT\n    {col_list}\nFROM',
        script_text,
    )
    fixed = re.sub(
        r'(?i)\bSELECT\s+([A-Z])\.\*\s+FROM\b',
        lambda m: 'SELECT\n    ' + ',\n    '.join(
            f'{m.group(1)}.{c}' for c in full_columns
        ) + '\nFROM',
        fixed,
    )

    if fixed != script_text:
        logger.info("Post-processing: Replaced SELECT * with explicit column list")

    return fixed


def _validate_script_completeness(script_text, fname):
    """Validate Type 1 script has essential steps (simplified)."""
    missing = []
    upper_text = script_text.upper()
    # Essential checks only — prompt FORBIDDEN rules handle the rest
    checks = [
        ('_INC ALL', 'Step 1 _INC'),
        ('_INSERTS ALL', 'Step 2 _INSERTS'),
        ('BEGIN TRANSACTION', 'Step 3 Transaction'),
        ('.LOGOFF', 'Cleanup'),
        ('.QUIT', 'Termination'),
    ]
    for marker, desc in checks:
        if marker.upper() not in upper_text:
            missing.append(desc)
    return missing


def _validate_script_family(script_text):
    """Check for forbidden artifacts in Type 1 scripts."""
    upper_text = script_text.upper()
    # Check for forbidden artifacts
    forbidden_artifacts = [
        ('_UPDATES', 'Forbidden: _UPDATES table'),
        ('_HISTADJ', 'Forbidden: _HISTADJ table'),
        ('EFF_FROM_DTTM', 'Forbidden: EFF_FROM_DTTM'),
        ('EFF_TO_DTTM', 'Forbidden: EFF_TO_DTTM'),
        ('CTL_UPDATED_DTTM', 'Forbidden: CTL_UPDATED_DTTM'),
    ]
    forbidden_found = [desc for marker, desc in forbidden_artifacts if marker in upper_text]
    return {
        "missing_required": [],
        "forbidden_markers": forbidden_found,
        "is_valid": not forbidden_found,
    }


def _validate_unit_specific_script(script_text, unit, fname):
    """Minimal unit-specific validation — prompt handles most rules."""
    issues = []
    upper_text = script_text.upper()
    source_system = str(unit.get('source_system') or '').strip().upper()
    
    # Only check essential source-system filter is present
    if source_system:
        patterns = [
            f"UPPER(SRC.CTL_DATA_SOURCE_CD) = '{source_system}'",
            f"UPPER(A.CTL_DATA_SOURCE_CD) = '{source_system}'",
            f"UPPER(CTL_DATA_SOURCE_CD) = '{source_system}'",
            f"CTL_DATA_SOURCE_CD = '{source_system}'",
        ]
        if not any(p in upper_text for p in patterns):
            issues.append('Missing source-system filter')
    
    return issues


def _repair_unit_hard_rules(script_text, unit, fname):
    """Minimal repairs for header, session commands, and exit codes."""
    source_system = str(unit.get('source_system') or '').strip().upper()
    source_table = str(unit.get('sql_source_table') or unit.get('source_table_key') or '').strip().lower()
    target_entity = str(unit.get('target_entity') or '').strip().lower()
    
    text = script_text
    
    # ── Ensure header exists ──
    if '# MODULE' not in text.upper():
        canonical_header = f"""/*----------------------------------------------------------------------------------------------------*/
/*
# MODULE        : {fname}
# Description   : Type 1 load for {target_entity.upper()} from {source_system} {source_table.upper()}
*/
/*----------------------------------------------------------------------------------------------------*/
"""
        text = canonical_header + '\n' + text.lstrip()
    
    # ── Normalize .LOGON ──
    text = re.sub(
        r'(?im)^\s*\.LOGON\s+.*?;\s*$',
        '.LOGON #TD_SERVER_NAME#/#ETL_USER_ID#,$tdwallet(#ETL_USER_ID#);',
        text, count=1
    )
    
    # ── Remove .SET commands ──
    text = re.sub(r'(?im)^\s*\.SET\s+.*$\n?', '', text)
    
    # ── Normalize .QUIT to .QUIT 0 ──
    text = re.sub(r'(?i)\.QUIT\s+ERRORCODE\b', '.QUIT 0', text)
    text = re.sub(r'(?im)^\s*\.QUIT\s*;?\s*$', '.QUIT 0', text)
    
    # ── Fix bare .EXIT NN → .IF ERRORCODE <> 0 THEN .EXIT NN ──
    for exit_code in [10, 20, 30, 40, 50, 60, 70]:
        pattern = rf'(?im)^\s*\.EXIT\s+{exit_code}\s*;?\s*$'
        replacement = f'.IF ERRORCODE <> 0 THEN .EXIT {exit_code}'
        text = re.sub(pattern, replacement, text)
    
    return text


def _normalize_generated_scripts(generated_scripts):
    """Normalize generated script output into a filename->content mapping."""
    if generated_scripts is None:
        return {}

    if isinstance(generated_scripts, dict):
        if all(isinstance(v, str) for v in generated_scripts.values()):
            return {str(k): str(v) for k, v in generated_scripts.items()}

        # Common agent/tool payload shapes
        if isinstance(generated_scripts.get("scripts_content"), dict):
            return {
                str(k): str(v)
                for k, v in generated_scripts["scripts_content"].items()
            }
        if isinstance(generated_scripts.get("scripts"), dict):
            return {
                str(k): str(v)
                for k, v in generated_scripts["scripts"].items()
            }

    raise ValueError("generated_scripts must be a filename->content mapping or a payload containing one")


def build_preprocessed_bteq_context(
    excel_path,
    target_entity=None,
    source_system=None,
    catalog_prompt='',
):
    """Build deterministic Type 1 script units from a mapping Excel."""
    headers, data_rows = _read_excel_raw(excel_path)
    if not data_rows:
        raise RuntimeError(f"No data rows found in '{excel_path}'")

    if not target_entity:
        entity_col = _detect_target_entity_column(headers)
        if entity_col:
            for row in data_rows:
                val = row.get(entity_col, '').strip()
                if val and val.lower() not in ('', 'none', 'n/a'):
                    target_entity = val
                    break
    if not target_entity:
        target_entity = 'ENTITY'

    source_col = _detect_source_table_column(headers)
    if not source_col:
        raise RuntimeError(
            f"Could not detect source table column in headers: {headers}. "
            "Expected a column with 'source' and 'table' in its name."
        )

    target_col_col = _detect_target_column_column(headers)
    groups = _group_rows_by_source(data_rows, source_col, target_col_col)
    if not groups:
        raise RuntimeError("No source table groups found in mapping data")

    groups = _split_comma_source_tables(groups)
    common_instructions = _read_common_mapping_instructions(excel_path)

    script_units = []
    output_filenames = []

    for idx, (src_table, rows) in enumerate(groups.items(), 1):
        effective_system = _infer_block_source_system(
            rows,
            headers,
            src_table,
            fallback_source_system=source_system,
        )
        clean_table = src_table
        if '.' in src_table:
            parts = src_table.split('.', 1)
            clean_table = parts[1].strip()
        if not effective_system:
            raise RuntimeError(
                f"Could not determine source system for source table '{src_table}'. "
                "Provide source_system explicitly or include a schema prefix in SOURCE_TABLE_NAME."
            )

        safe_name = re.sub(r'[^a-zA-Z0-9_]', '_', clean_table.lower())
        output_filename = f"load_sri_to_fsdm__{effective_system}__{safe_name}__{target_entity.lower()}.btq"
        sql_table = clean_table.split('__')[0] if '__' in clean_table else clean_table

        target_columns, column_specs, sk_column, natural_key_expr, natural_key_col, business_filters = \
            _build_column_derivations(headers, rows, sql_table, effective_system, target_entity)
        variant_signature = _block_literal_signature(rows, source_col)
        multi_source_mapping = any(',' in str(row.get(source_col, '') or '') for row in rows)
        family_profile = _build_type1_family_profile(
            target_entity,
            sql_table,
            effective_system,
            target_columns,
            column_specs,
            business_filters,
            variant_signature=variant_signature,
            multi_source_mapping=multi_source_mapping,
        )
        business_filters_text = business_filters

        unit = {
            "unit_index": idx,
            "catalog_prompt_present": bool(catalog_prompt and catalog_prompt.strip()),
            "source_table_key": src_table,
            "sql_source_table": sql_table,
            "source_system": effective_system,
            "target_entity": target_entity,
            "output_filename": output_filename,
            "headers": headers,
            "mapping_rows": rows,
            "target_columns": target_columns,
            "column_specs": column_specs,
            "sk_column": sk_column,
            "natural_key_expression": natural_key_expr,
            "natural_key_column": natural_key_col,
            "family_id": family_profile.get("family_id"),
            "family_profile": family_profile,
            "business_filters": business_filters_text,
            "common_instructions": common_instructions,
            "variant_signature": variant_signature,
        }
        script_units.append(unit)
        output_filenames.append(output_filename)

    return {
        "status": "ok",
        "excel_path": str(excel_path),
        "source_column": source_col,
        "target_entity": target_entity,
        "source_system": str(source_system or '').strip().lower(),
        "script_unit_count": len(script_units),
        "output_filenames": output_filenames,
        "validation_metadata": {
            "header_count": len(headers),
            "row_count": len(data_rows),
            "group_count": len(script_units),
            "common_instructions_present": bool(common_instructions),
            "catalog_prompt_present": bool(catalog_prompt and catalog_prompt.strip()),
        },
        "script_units": script_units,
    }


def generate_scripts_from_preprocessed_context(
    preprocessed_context,
    llm_client=None,
    progress_callback=None,
    max_tokens=16384,
    temperature=0.0,
    catalog_prompt='',
):
    """Generate Type 1 BTEQ scripts from a preprocessed payload."""
    if llm_client is None:
        from daan.llm.llm_provider import get_llm_response_with_fallback as _get_llm

        class SimpleLLMClient:
            def chat(self, prompt, max_tokens=16384, temperature=0.0):
                return _get_llm(prompt, max_tokens=max_tokens, temperature=temperature)

        llm_client = SimpleLLMClient()

    if callable(llm_client) and not hasattr(llm_client, 'chat'):
        _fn = llm_client

        class _CallableWrapper:
            def chat(self, prompt, max_tokens=16384, temperature=0.0):
                return _fn(prompt, max_tokens=max_tokens, temperature=temperature)

        llm_client = _CallableWrapper()

    def _progress(msg):
        logger.info(msg)
        if progress_callback:
            progress_callback(msg)

    if not isinstance(preprocessed_context, dict):
        raise RuntimeError("preprocessed_context must be a dict payload")

    script_units = preprocessed_context.get('script_units') or []
    if not script_units:
        raise RuntimeError("No script units found in preprocessed context")

    total_units = len(script_units)

    def _generate_one_script(unit):
        source_table = str(unit.get('sql_source_table') or unit.get('source_table_key') or '').strip()
        entity_name = str(unit.get('target_entity') or preprocessed_context.get('target_entity') or 'ENTITY').strip()
        headers = list(unit.get('headers') or [])
        rows = list(unit.get('mapping_rows') or [])
        effective_system = str(unit.get('source_system') or preprocessed_context.get('source_system') or '').strip()
        fname = str(unit.get('output_filename') or '').strip()
        unit_index = int(unit.get('unit_index') or 0)

        if not source_table or not headers or not rows or not fname:
            raise RuntimeError(f"Incomplete script unit payload for unit {unit_index or '?'}")
        if not effective_system:
            raise RuntimeError(
                f"Missing source system for script unit {unit_index or '?'} ({source_table})"
            )

        _progress(f"[{unit_index}/{total_units}] Generating script for {source_table} (system={effective_system}) via prompt-driven LLM path...")

        prompt = _build_prompt_for_source_table(
            source_table,
            entity_name,
            headers,
            rows,
            effective_system,
            common_instructions=str(unit.get('common_instructions') or ''),
            catalog_prompt=catalog_prompt,
            family_profile=unit.get('family_profile') or {},
        )

        _tc, _cs, _sk, _nke, _nkc, _bf = _build_column_derivations(
            headers, rows, source_table, effective_system, entity_name)
        _full_cols = list(_tc)
        for _ac in ['RECORD_DELETED_FLAG', 'CTL_DATA_SOURCE_CD',
                     'CTL_CREATED_DTTM', 'CTL_CREATED_JOB_ID', 'CTL_CREATED_RUN_ID']:
            if _ac.upper() not in {c.upper() for c in _full_cols}:
                _full_cols.append(_ac)

        max_attempts = 2  # 1 initial + 1 retry
        current_prompt = prompt
        for attempt in range(1, max_attempts + 1):
            try:
                response = llm_client.chat(
                    current_prompt,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )
                script_text = _extract_script_from_response(str(response))

                if not script_text or len(script_text) < 100:
                    raise RuntimeError("LLM returned very short/empty output")

                script_text = _fix_select_star(script_text, _full_cols)
                script_text = _repair_unit_hard_rules(script_text, unit, fname)

                missing = _validate_script_completeness(script_text, fname)
                family_validation = _validate_script_family(script_text)
                validation_failures = list(missing)
                validation_failures.extend(family_validation['missing_required'])
                validation_failures.extend(family_validation['forbidden_markers'])
                validation_failures.extend(_validate_unit_specific_script(script_text, unit, fname))
                validation_failures = list(dict.fromkeys(validation_failures))

                if validation_failures and attempt < max_attempts:
                    _progress(f"⚠️ Script invalid (issues: {', '.join(validation_failures)}), retrying ({attempt}/{max_attempts})...")
                    current_prompt = prompt + (
                        f"\n\n## CRITICAL RETRY: The previous output was invalid. "
                        "You MUST include ALL 4 steps completely and you MUST stay within the correct Type 1 script family. "
                        "Do NOT use generic templates such as DROP TABLE, CREATE MULTISET TABLE, .SET commands, SK_LOOKUP, ROW_NUMBER, DBC.DBCINFO, _UPDATES, or _HISTADJ when generating Type 1 scripts. "
                        "Generate the ENTIRE script from .LOGON to .QUIT 0. "
                        "Fix every issue below exactly as stated:\n- "
                        + "\n- ".join(validation_failures)
                    )
                    continue
                elif validation_failures:
                    # Validation failed but don't block—return script with warning
                    _progress(f"⚠️ {fname} — {len(script_text)} chars (validation warnings: {', '.join(validation_failures)})")

                _progress(f"✅ {fname} — {len(script_text)} chars")
                return (fname, script_text)

            except Exception as e:
                if attempt < max_attempts:
                    _progress(f"⚠️ Attempt {attempt} failed for {source_table}: {e}, retrying...")
                    continue
                logger.error(f"LLM generation failed for {source_table}: {e}", exc_info=True)
                _progress(f"❌ Failed for {source_table}: {e}")
                raise RuntimeError(f"Error generating script for {source_table}: {e}")

            raise RuntimeError(f"Max attempts exceeded for {source_table}")

    results = {}
    _progress(f"Starting parallel generation for {total_units} source tables...")
    with ThreadPoolExecutor(max_workers=min(3, total_units)) as executor:
        futures = {
            executor.submit(_generate_one_script, unit): unit
            for unit in script_units
        }
        for future in as_completed(futures):
            unit = futures[future]
            source_table = str(unit.get('source_table_key') or unit.get('sql_source_table') or 'unknown')
            try:
                fname, script_text = future.result()
                results[fname] = script_text
            except Exception as e:
                logger.error(f"Parallel generation failed for {source_table}: {e}", exc_info=True)
                _progress(f"❌ Parallel task failed for {source_table}: {e}")

    if len(results) != total_units:
        raise RuntimeError(f"Generated {len(results)} of {total_units} required scripts")

    return results


def postprocess_generated_bteq_scripts(
    generated_scripts,
    output_dir='output',
):
    """Validate, normalize, and persist generated BTEQ scripts."""
    normalized_scripts = _normalize_generated_scripts(generated_scripts)
    if not normalized_scripts:
        raise RuntimeError("No generated scripts provided for post-processing")

    processed_scripts = {}
    validation_results = {}

    for fname, raw_text in normalized_scripts.items():
        script_text = _extract_script_from_response(str(raw_text))
        missing = _validate_script_completeness(script_text, fname)
        family_validation = _validate_script_family(script_text)

        # Use a conservative full-column set for generic SELECT * replacement.
        generic_full_cols = [
            'RECORD_DELETED_FLAG', 'CTL_DATA_SOURCE_CD',
            'CTL_CREATED_DTTM', 'CTL_CREATED_JOB_ID', 'CTL_CREATED_RUN_ID',
        ]
        script_text = _fix_select_star(script_text, generic_full_cols)

        processed_scripts[fname] = script_text
        validation_results[fname] = {
            "missing_steps": missing,
            "missing_required": family_validation["missing_required"],
            "forbidden_markers": family_validation["forbidden_markers"],
            "is_complete": not missing,
            "is_valid_family": family_validation["is_valid"],
            "char_count": len(script_text),
        }

    invalid_scripts = {
        fname: result for fname, result in validation_results.items()
        if result["missing_steps"] or result["missing_required"] or result["forbidden_markers"]
    }
    validation_warnings = []
    if invalid_scripts:
        for fname, result in invalid_scripts.items():
            summary = (
                f"{fname}: missing_steps={result['missing_steps']}, "
                f"missing_required={result['missing_required']}, "
                f"forbidden={result['forbidden_markers']}"
            )
            validation_warnings.append(summary)
            logger.warning("BTEQ validation warning (script saved anyway): %s", summary)

    zip_path, file_paths = save_scripts_to_zip(processed_scripts, output_dir=output_dir)
    return {
        "status": "ok",
        "scripts_generated": len(processed_scripts),
        "script_names": list(processed_scripts.keys()),
        "scripts_content": processed_scripts,
        "validation_results": validation_results,
        "validation_warnings": validation_warnings,
        "zip_path": zip_path,
        "files": file_paths,
        "output_dir": output_dir,
    }


# ─── Main entry point ─────────────────────────────────────────────────
 
 
def generate_scripts_with_llm(
    excel_path,
    target_entity=None,
    source_system=None,
    llm_client=None,
    progress_callback=None,
    max_tokens=16384,
    temperature=0.0,
    catalog_prompt='',
):
    """Generate Type 1 BTEQ scripts with prompt-led generation."""
    preprocessed_context = build_preprocessed_bteq_context(
        excel_path=excel_path,
        target_entity=target_entity,
        source_system=source_system,
        catalog_prompt=catalog_prompt,
    )
    return generate_scripts_from_preprocessed_context(
        preprocessed_context,
        llm_client=llm_client,
        progress_callback=progress_callback,
        max_tokens=max_tokens,
        temperature=temperature,
        catalog_prompt=catalog_prompt,
    )
