"""Code Generator Agent - Generates Python code for synthetic data generation.

This version uses ML-learned patterns from trained Bayesian Networks to generate
realistic expressions. No external LLM calls - pure ML-based pattern matching
provides faster, more reliable, and higher-quality synthetic data generation.
"""
import json
import logging
import os
from pathlib import Path
from typing import Dict, List, Any
from datetime import datetime, timedelta, date
from decimal import Decimal



logger = logging.getLogger(__name__)


class PythonScriptGenerator:
    """
    Generate Python code using Faker library for data generation
    """
    
    def __init__(self, generation_plan: Dict[str, Any], output_dir: str, output_format: str = 'csv', include_nulls: bool = True):
        """
        Initialize Code Generator Agent
        
        Args:
            generation_plan: Plan from PlannerAgent
            output_dir: Directory to save generated Python scripts
            output_format: Output format ('csv' or 'excel')
            include_nulls: Whether to include NULL values in nullable columns
        """
        self.generation_plan = generation_plan
        self.output_dir = output_dir
        self.output_format = output_format.lower() if output_format else 'csv'
        self.include_nulls = include_nulls
        self.generated_scripts = {}
        self.learned_patterns = {}  # Will store ML-learned patterns
        
        os.makedirs(output_dir, exist_ok=True)
    
    def set_learned_patterns(self, learned_patterns: Dict[str, Any]):
        """
        Set ML-learned patterns for enhanced generation
        
        Args:
            learned_patterns: Dictionary of learned patterns from MLPatternLearner
        """
        self.learned_patterns = learned_patterns
        logger.info(f"Set learned patterns for {len(learned_patterns)} tables")
    
    def generate_all_scripts(self) -> Dict[str, str]:
        """
        Generate Python scripts for all tables
    
        Returns:
            Dictionary mapping table names to script paths
        """
        try:
            print("\n💻 Generating Python scripts...")
            
            table_plans = self.generation_plan.get('table_plans', {})
            execution_order = self.generation_plan.get('execution_order', [])
            
            for table in execution_order:
                if table in table_plans:
                    script_path = self._generate_table_script(table, table_plans[table])
                    self.generated_scripts[table] = script_path
            
            logger.info(f"Generated {len(self.generated_scripts)} Python scripts")
            return self.generated_scripts
        
        except Exception as e:
            logger.error(f"Script generation failed: {str(e)}")
            print(f"❌ Error: {str(e)}")
            return {}
    
    def _generate_table_script(self, table_name: str, table_plan: Dict[str, Any]) -> str:
        """
        Generate Python script for a single table
        
        Args:
            table_name: Name of the table
            table_plan: Generation plan for the table
        
        Returns:
            Path to generated script
        """
        try:
            row_count = table_plan['row_count']
            original_row_count = table_plan.get('original_row_count', row_count)  # Get source table row count
            columns = table_plan['columns']
            
            logger.info(f"Generating script for {table_name} with {len(columns)} columns and {row_count} rows (source: {original_row_count} rows)")
            script = self._build_script_template(table_name, row_count, columns, original_row_count, self.generation_plan)
            
            if not script:
                logger.error(f"Script template is empty for {table_name}")
                print(f"  [!] Script template empty for {table_name}")
                return ""
            
            script_filename = f"generate_{table_name.lower()}.py"
            script_path = os.path.join(self.output_dir, script_filename)
            
            # Ensure directory exists
            os.makedirs(self.output_dir, exist_ok=True)
            
            # Write with UTF-8 encoding
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(script)
            
            logger.info(f"Generated script: {script_path}")
            print(f"  * Generated script for {table_name}")
            return script_path
        
        except KeyError as e:
            logger.error(f"Missing key in table_plan for {table_name}: {str(e)}")
            print(f"  [!] Missing data for {table_name}: {str(e)}")
            return ""
        except Exception as e:
            logger.error(f"Failed to generate script for {table_name}: {type(e).__name__}: {str(e)}")
            print(f"  [!] Error generating script for {table_name}: {type(e).__name__}: {str(e)}")
            return ""
    
    def _build_script_template(self, table_name: str, row_count: int, columns: List[Dict], original_row_count: int = None, generation_plan: Dict[str, Any] = None) -> str:
        """
        Build complete Python script template with optional Bayesian model support
        
        Args:
            table_name: Table name
            row_count: Number of rows to generate
            columns: Column definitions
            original_row_count: Original source table row count (for dimension table detection)
            generation_plan: Full generation plan (for FK parent table lookups)
        
        Returns:
            Python script as string
        """
        # Use provided original row count, or fall back to generated row count
        if original_row_count is None:
            original_row_count = row_count
        
        # Store original row count for use in dimension table detection
        self._current_table_original_row_count = original_row_count
        
        # Check if we have a Bayesian model for this table
        has_bayesian_model = table_name in self.learned_patterns and \
                             self.learned_patterns[table_name].get('has_bayesian_model', False)
        
        imports = self._get_imports(table_name, has_bayesian_model)
        
        # Build FK loading logic BEFORE main logic (pass generation_plan for parent table lookups)
        fk_setup = self._build_fk_setup(table_name, columns, generation_plan)
        
        # Build model loading setup if Bayesian model exists
        model_setup = self._build_model_setup(table_name, has_bayesian_model)
        
        main_logic = self._build_main_logic(table_name, row_count, columns, generation_plan)
        timestamp = datetime.now().isoformat()
        
        file_ext = '.xlsx' if self.output_format == 'excel' else '.csv'
        
        script = imports + "\n\n"
        script += f"# Generated Script for {table_name}\n"
        script += f"# Generated at: {timestamp}\n"
        script += f"# Purpose: Generate {row_count} rows of synthetic data\n"
        script += f"# Output Format: {self.output_format.upper()}\n"
        if has_bayesian_model:
            script += f"# ML Model: Bayesian Network (uses {table_name}_bayesian.pkl)\n"
        script += "\n"
        script += "fake = Faker()\n\n"
        
        # Add ID pattern generator helper
        script += "def generate_id_within_pattern(min_id, max_id, gap=1):\n"
        script += "    \"\"\"Generate ID within pattern range to preserve distribution.\"\"\"\n"
        script += "    if gap <= 1:\n"
        script += "        return random.randint(int(min_id), int(max_id))\n"
        script += "    base = int(min_id)\n"
        script += "    max_steps = int((max_id - min_id) / gap)\n"
        script += "    return int(base + random.randint(0, max_steps) * gap)\n\n"
        
        # Add model loading code if needed
        if model_setup:
            script += model_setup + "\n\n"
        
        script += f"def generate_{table_name.lower()}_data(output_path):\n"
        script += f'    """Generate {row_count} rows of synthetic data for {table_name} and write to {file_ext}."""\n'
        script += f"    headers = {[col['column_name'] for col in columns]}\n"
        script += "    os.makedirs(os.path.dirname(output_path), exist_ok=True)\n"
        script += "    preview = []\n"
        
        # Add FK setup code (loads parent tables if needed)
        if fk_setup:
            script += fk_setup
        
        if self.output_format == 'excel':
            script += "    rows = []\n"
            script += main_logic
            script += "    df = pd.DataFrame(rows)\n"
            script += "    df.to_excel(output_path, index=False, engine='openpyxl')\n"
            script += "    preview = rows[:5]\n"
        else:
            # For CSV: need to write each row to file as generated
            script += "    with open(output_path, 'w', newline='', encoding='utf-8') as csv_file:\n"
            script += "        writer = csv.writer(csv_file)\n"
            script += "        writer.writerow(headers)\n"
            script += "        preview = []\n"
            script += self._indent_for_csv(main_logic)
        
        script += "    return preview\n\n"
        script += "if __name__ == \"__main__\":\n"
        script += f"    output_path = f\"{{os.path.dirname(__file__)}}/../output/SDV/{table_name.upper()}{file_ext}\"\n"
        script += f"    print(\"Generating {row_count} rows for {table_name}...\")\n"
        if has_bayesian_model:
            script += f"    if not PGMPY_AVAILABLE:\n"
            script += f"        print(\"[WARNING] pgmpy not available - using fallback statistical generation\")\n"
        script += f"    preview = generate_{table_name.lower()}_data(output_path)\n"
        script += "    # Display first few rows\n"
        script += "    if preview:\n"
        script += "        df = pd.DataFrame(preview)\n"
        script += "        print(\"\\nFirst 5 rows:\")\n"
        script += "        print(df.head())\n"
        script += "    print(f\"\\nData saved to {output_path}\")\n"
        
        return script
    
    def _get_imports(self, table_name: str = None, has_bayesian_model: bool = False) -> str:
        """Generate import statements"""
        # Use explicit newline-joined strings to avoid unintended
        # indentation in the generated scripts.
        imports = (
            "import pandas as pd\n"
            "from faker import Faker\n"
            "import os\n"
            "from datetime import datetime, timedelta, date\n"
            "import random\n"
            "import csv\n"
            "import pickle\n"
            "import json"
        )
        
        if self.output_format == 'excel':
            imports += "\nimport openpyxl"
        
        # Add pgmpy imports if Bayesian model is available
        if has_bayesian_model:
            imports += "\ntry:\n"
            imports += "    from pgmpy.inference import VariableElimination\n"
            imports += "    PGMPY_AVAILABLE = True\n"
            imports += "except ImportError:\n"
            imports += "    PGMPY_AVAILABLE = False\n"
            imports += "    print('Warning: pgmpy not available. Install with: pip install pgmpy')"
        
        return imports
    
    def _build_column_generators(self, columns: List[Dict]) -> List[str]:
        """Build generator function calls for each column"""
        generators = []
        for col in columns:
            gen_code = self._get_faker_call(col)
            generators.append(gen_code)
        return generators
    
    def _build_main_logic(self, table_name: str, row_count: int, columns: List[Dict], generation_plan: Dict[str, Any] = None) -> str:
        """
        Build main data generation logic
        
        Args:
            table_name: Table name
            row_count: Number of rows
            columns: Column definitions
            generation_plan: Full generation plan (for FK parent table lookups)
        
        Returns:
            Main logic code as string
        """
        # Get expressions from ML patterns (NO LLM) - Direct generation from learned patterns
        # ML patterns contain actual distribution data, probabilities, and statistics
        ml_exprs = self._get_ml_pattern_expressions(table_name, row_count, columns)
        logger.info(f"Using ML-pattern expressions for {table_name}: {len(ml_exprs)} columns")
        print(f"  ✓ Using ML-pattern-based expressions ({len(ml_exprs)} columns)")
        
        # Extract table_plans from generation_plan for FK lookups
        table_plans = generation_plan.get('table_plans', {}) if generation_plan else {}
        
        # Parse ML expressions to extract variable definitions that should go before the loop
        # Only extract assignments that don't reference 'i' (the loop variable)
        pre_loop_vars = ""
        parsed_ml_exprs = {}
        
        for col_name, expr in ml_exprs.items():
            # Check if expression contains variable assignments (semicolon-separated statements)
            if ';' in expr:
                # Split by semicolon and extract parts
                parts = [p.strip() for p in expr.split(';') if p.strip()]
                # Last part is the actual expression to use in the dict
                actual_expr = parts[-1]
                # Earlier parts are variable assignments
                var_assignments = []
                
                for part in parts[:-1]:
                    # Check if this part has a variable assignment
                    if '=' in part and not part.startswith('random.') and not part.startswith('fake.'):
                        # Only extract to pre-loop if it doesn't reference 'i'
                        # Variables that reference 'i' must stay inside the loop
                        has_i_reference = any([
                            ' i ' in part, part.startswith('i '), part.endswith(' i'),
                            'i+' in part, 'i-' in part, 'i*' in part, 'i/' in part,
                            '[i]' in part, '(i)' in part, '{i}' in part,
                            "f'" in part, 'f"' in part  # f-strings often reference i
                        ])
                        
                        if not has_i_reference:
                            pre_loop_vars += f"    {part}\n"
                        else:
                            # This assignment references i, keep it inline
                            var_assignments.append(part)
                
                # If we kept some var assignments inline, reconstruct the expression
                if var_assignments:
                    actual_expr = '; '.join(var_assignments + [actual_expr])
                
                parsed_ml_exprs[col_name] = actual_expr
            else:
                parsed_ml_exprs[col_name] = expr
        
        # Replace the original ml_exprs with parsed version
        ml_exprs = parsed_ml_exprs
        
        # Build the logic with pre-loop variables first
        logic = pre_loop_vars
        
        # Check if we have a Bayesian model available
        has_bayesian_model = table_name in self.learned_patterns and \
                             self.learned_patterns[table_name].get('has_bayesian_model', False)
        
        # Collect PK/FK override expressions to apply AFTER row generation
        # This ensures Bayesian inference doesn't corrupt PK/FK values
        pk_fk_overrides = []
        
        # Always start the loop
        logic += f"    for i in range({row_count}):\n"
        
        # If Bayesian model is available, always create base row first, then overlay Bayesian values
        if has_bayesian_model:
            logic += f"        # STEP 1: Create base row with all columns (ensures no missing keys)\n"
            logic += f"        row = {{\n"
            indent_offset = ""  # No extra indentation - base row is always created
        else:
            logic += "        row = {\n"
            indent_offset = ""

        for col in columns:
            col_name = col['column_name']
            is_pk = col['is_primary_key']
            is_fk = col['is_foreign_key']
            nullable = col['nullable']
            strategy = col['generation_strategy']

            # PRIORITY 1: Primary keys (auto-increment)
            # PKs continue from where real data stopped (max_real_pk_value)
            if is_pk:
                pk_expr = None  # Will be set for Bayesian override
                max_real_pk = col.get('max_real_pk_value')  # Max PK from real Snowflake data
                
                # Check if we have detected increment pattern from samples
                pattern = col.get('increment_pattern')
                if pattern and pattern.get('pattern_type') == 'sequential':
                    start_val = int(pattern.get('start', 1))
                    step_val = int(pattern.get('step', 1))
                    sample_vals = col.get('sample_values', [])
                    
                    unique_count = len(set([v for v in sample_vals if v is not None]))
                    original_row_count = getattr(self, '_current_table_original_row_count', 1000000)
                    
                    valid_nums = sorted([float(v) for v in sample_vals if v is not None])
                    is_dense_sequence = False
                    if len(valid_nums) >= 2:
                        diffs = [valid_nums[i+1] - valid_nums[i] for i in range(len(valid_nums)-1)]
                        is_dense_sequence = all(d == 1.0 for d in diffs)
                    
                    is_dimension_table = (unique_count <= 10 and step_val == 1 and 
                                         is_dense_sequence and unique_count > 0 and 
                                         original_row_count <= 100)
                    
                    if is_dimension_table:
                        pk_expr = f"(i % {unique_count}) + {start_val}"
                        logic += f'{indent_offset}            "{col_name}": {pk_expr},  # PK: dimension table (cycle {unique_count} values)\n'
                    else:
                        # Use max real PK value + 1 as starting point if available
                        if max_real_pk is not None:
                            try:
                                real_max = int(float(max_real_pk))
                                continue_from = real_max + step_val
                                if step_val == 1:
                                    pk_expr = f"{continue_from} + i"
                                else:
                                    pk_expr = f"{continue_from} + (i * {step_val})"
                                logic += f'{indent_offset}            "{col_name}": {pk_expr},  # PK: continues from real data (max={real_max})\n'
                                logger.info(f"PK {col_name}: Continuing from real data max={real_max}, synthetic starts at {continue_from}")
                            except (ValueError, TypeError):
                                if step_val == 1:
                                    pk_expr = f"{start_val} + i"
                                else:
                                    pk_expr = f"{start_val} + (i * {step_val})"
                                logic += f'{indent_offset}            "{col_name}": {pk_expr},  # PK: sequential pattern (start={start_val})\n'
                        elif step_val == 1:
                            pk_expr = f"{start_val} + i"
                            logic += f'{indent_offset}            "{col_name}": {pk_expr},  # PK: sequential pattern (start={start_val}, step={step_val})\n'
                        else:
                            pk_expr = f"{start_val} + (i * {step_val})"
                            logic += f'{indent_offset}            "{col_name}": {pk_expr},  # PK: sparse pattern (start={start_val}, step={step_val})\n'
                    logger.info(f"PK {col_name}: Using detected pattern - start={start_val}, step={step_val}, dimension_table={is_dimension_table}")
                else:
                    ml_id_pattern = None
                    if table_name in self.learned_patterns:
                        table_patterns = self.learned_patterns[table_name].get('columns', {})
                        col_pattern_data = table_patterns.get(col_name, {})
                        ml_id_pattern = col_pattern_data.get('id_pattern')
                    
                    if ml_id_pattern:
                        min_id = int(ml_id_pattern.get('min_id', 1))
                        gap = int(ml_id_pattern.get('most_common_gap', 1))
                        
                        # Use max real PK value if available
                        if max_real_pk is not None:
                            try:
                                real_max = int(float(max_real_pk))
                                continue_from = real_max + gap
                                if gap > 1:
                                    pk_expr = f"{continue_from} + (i * {gap})"
                                else:
                                    pk_expr = f"{continue_from} + i"
                                logic += f'{indent_offset}            "{col_name}": {pk_expr},  # PK: continues from real data max={real_max}\n'
                                logger.info(f"PK {col_name}: ML pattern, continuing from real max={real_max}")
                            except (ValueError, TypeError):
                                if gap > 1:
                                    pk_expr = f"{min_id} + (i * {gap})"
                                else:
                                    pk_expr = f"{min_id} + i"
                                logic += f'{indent_offset}            "{col_name}": {pk_expr},  # PK: ML-learned pattern\n'
                        else:
                            if gap > 1:
                                pk_expr = f"{min_id} + (i * {gap})"
                                logic += f'{indent_offset}            "{col_name}": {pk_expr},  # PK: ML-learned sparse pattern (min={min_id}, gap={gap})\n'
                            else:
                                pk_expr = f"{min_id} + i"
                                logic += f'{indent_offset}            "{col_name}": {pk_expr},  # PK: ML-learned sequential (start={min_id})\n'
                    else:
                        sample_vals = col.get('sample_values', [])
                        data_type = col.get('data_type', '').upper()
                        
                        if data_type in ['TEXT', 'VARCHAR', 'STRING'] and sample_vals:
                            import re as _re
                            first_val = str(sample_vals[0])
                            prefix_match = _re.match(r'^([A-Za-z]+)(\d+)$', first_val)
                            if prefix_match and all(_re.match(r'^[A-Za-z]+\d+$', str(v)) for v in sample_vals[:5] if v is not None):
                                prefix = prefix_match.group(1)
                                digit_len = len(prefix_match.group(2))
                                
                                # Use max real PK to continue numbering
                                pk_start_num = 1
                                if max_real_pk is not None:
                                    real_pk_match = _re.match(r'^[A-Za-z]+(\d+)$', str(max_real_pk))
                                    if real_pk_match:
                                        pk_start_num = int(real_pk_match.group(1)) + 1
                                        logger.info(f"PK {col_name}: TEXT ID continues from real max {max_real_pk} -> starts at {pk_start_num}")
                                
                                pk_expr = f'f"{prefix}{{({pk_start_num} + i):0{digit_len}d}}"'
                                logic += f'{indent_offset}            "{col_name}": {pk_expr},  # PK: TEXT ID continues from real data (max={max_real_pk})\n'
                                logger.info(f"PK {col_name}: TEXT ID pattern - prefix={prefix}, digits={digit_len}, start_num={pk_start_num}")
                            else:
                                pk_expr = f'f"{col_name}_{{i + 1}}"'
                                logic += f'{indent_offset}            "{col_name}": {pk_expr},  # PK: text-based\n'
                        elif sample_vals:
                            try:
                                if max_real_pk is not None:
                                    continue_from = int(float(max_real_pk)) + 1
                                else:
                                    continue_from = min([int(v) if isinstance(v, (int, str)) else 1 for v in sample_vals if v])
                                pk_expr = f"i + {continue_from}"
                                logic += f'{indent_offset}            "{col_name}": {pk_expr},  # Auto-increment PK starting from {continue_from}\n'
                            except (ValueError, TypeError):
                                pk_expr = "i + 1"
                                logic += f'{indent_offset}            "{col_name}": {pk_expr},  # Auto-increment PK (default)\n'
                        else:
                            pk_expr = "i + 1"
                            logic += f'{indent_offset}            "{col_name}": {pk_expr},  # Auto-increment PK\n'
                
                # Record PK override for Bayesian correction
                if pk_expr and has_bayesian_model:
                    pk_fk_overrides.append((col_name, pk_expr))
                continue

            # PRIORITY 2: Foreign keys (referential integrity from schema)
            # Schema FK constraints are AUTHORITATIVE - override any ML patterns
            if is_fk:
                fk_refs = col.get('foreign_key_references', [])
                if fk_refs and len(fk_refs) > 0:
                    parent_table = fk_refs[0].get('referenced_table', '').upper()
                    parent_col = fk_refs[0].get('referenced_column', '').upper()
                    ai_detected = fk_refs[0].get('ai_detected', False)
                    is_self_ref = (parent_table == table_name.upper())
                    
                    if parent_table:
                        parent_var = f"{parent_table.lower()}_ids"
                        ai_note = " # Schema FK (authoritative)" if not ai_detected else " # AI-detected FK"
                        
                        if is_self_ref:
                            if nullable and self.include_nulls:
                                fk_expr = f"random.choice({parent_var}_pool) if {parent_var}_pool else None"
                            else:
                                fk_expr = f"random.choice({parent_var}_pool) if {parent_var}_pool else None"
                            logic += f'{indent_offset}            "{col_name}": {fk_expr},{ai_note} (self-ref - uses pool)\n'
                        else:
                            fk_expr = f"random.choice({parent_var}) if {parent_var} else None"
                            logic += f'{indent_offset}            "{col_name}": {fk_expr},{ai_note}\n'
                        
                        # Record FK override for Bayesian correction
                        if has_bayesian_model:
                            pk_fk_overrides.append((col_name, fk_expr))
                        
                        logger.info(f"FK configured: {col_name} -> {parent_table}.{parent_col}" + (" (AI-detected)" if ai_detected else ""))
                        continue
                
                # Fallback: use sample values from schema
                sample_vals = col.get('sample_values', [])
                if sample_vals:
                    logic += f'{indent_offset}            "{col_name}": random.choice({sample_vals}),  # FK - using sample values\n'
                    continue
                
                # Last resort: random placeholder
                logic += f'{indent_offset}            "{col_name}": random.randint(1, 100000),  # FK - fallback\n'
                continue

            # PRIORITY 3: Check for ID patterns (high-cardinality numeric columns)
            col_pattern = self.learned_patterns.get(table_name, {}).get('columns', {}).get(col_name)
            id_pattern = col_pattern.get('id_pattern') if col_pattern else None
            
            if id_pattern and col_pattern.get('cardinality') == 'high' and col_pattern.get('is_numeric'):
                # Use learned ID pattern for realistic ID generation
                min_id = id_pattern.get('min_id', 1)
                max_id = id_pattern.get('max_id', 100000)
                gap = id_pattern.get('most_common_gap', 1)
                logic += f'{indent_offset}            "{col_name}": generate_id_within_pattern({min_id}, {max_id}, {gap}),  # High-cardinality ID with pattern\n'
                continue

            # Use LLM-provided expression (PRIORITY)
            expr = ml_exprs.get(col_name)
            
            # Fallback to rule-based only if LLM didn't provide expression
            if not expr:
                logger.warning(f"LLM expression not found for {col_name}, using rule-based fallback")
                expr = self._get_faker_call(col)

            # Apply NULL logic only if include_nulls is enabled and column is nullable
            if nullable and strategy != 'sequence' and self.include_nulls:
                logic += f'{indent_offset}            "{col_name}": {expr} if random.random() > 0.2 else None,\n'
            else:
                logic += f'{indent_offset}            "{col_name}": {expr},\n'

        logic += f"{indent_offset}        }}\n"
        
        # STEP 2: If Bayesian model available, overlay inferred values for non-PK/FK columns
        # This preserves the base row's complete column set while using Bayesian correlations
        # IMPORTANT: Skip numeric columns - Bayesian returns discretized bin INDICES (0-9)
        # which corrupt actual numeric values. STEP 1's Gaussian distribution is better for numerics.
        if has_bayesian_model:
            # Collect PK/FK column names AND numeric column names to skip during overlay
            pk_fk_col_names = [col_name for col_name, _ in pk_fk_overrides]
            # Identify numeric columns that should NOT be overridden by Bayesian bin indices
            numeric_col_names = []
            for col in columns:
                dt = col.get('data_type', '').upper()
                if any(t in dt for t in ['NUMBER', 'INT', 'FLOAT', 'DECIMAL', 'NUMERIC', 'DOUBLE', 'REAL']):
                    numeric_col_names.append(col['column_name'])
            skip_col_names = pk_fk_col_names + numeric_col_names
            logic += f"\n        # STEP 2: Overlay Bayesian inference values (non-PK/FK/numeric columns only)\n"
            logic += f"        if bayesian_model is not None and inference_engine is not None:\n"
            logic += f"            inferred_row = generate_row_with_inference()\n"
            logic += f"            if inferred_row is not None:\n"
            logic += f"                # Merge inferred values, but skip PK/FK and numeric columns\n"
            logic += f"                # (Bayesian returns discretized bin indices for numerics which corrupt actual values)\n"
            logic += f"                skip_cols = {skip_col_names}\n"
            logic += f"                for col_key, col_val in inferred_row.items():\n"
            logic += f"                    if col_key not in skip_cols:\n"
            logic += f"                        row[col_key] = col_val\n"
        
        # STEP 3: Always override PK and FK values after row creation
        # Bayesian inference returns discretized bin values for ALL columns,
        # including PKs (1,2,3...) and FKs (1,2...) which break referential integrity.
        # We must ALWAYS set the correct PK/FK values regardless of row source.
        if pk_fk_overrides and has_bayesian_model:
            logic += f"\n        # STEP 3: Override PK/FK columns with correct values\n"
            for override_col, override_expr in pk_fk_overrides:
                logic += f'        row["{override_col}"] = {override_expr}\n'
        
        # Add self-referential ID collection logic if needed
        has_self_ref = any(
            col.get('is_foreign_key') and 
            col.get('foreign_key_references') and 
            col['foreign_key_references'][0].get('referenced_table', '').upper() == table_name.upper()
            for col in columns
        )
        
        if has_self_ref:
            # Collect PKs for self-referential FKs - ADD TO POOL AFTER ROW CREATION
            pk_col = next((c['column_name'] for c in columns if c['is_primary_key']), None)
            if pk_col:
                parent_var = f"{table_name.lower()}_ids_pool"
                logic += f"        # Collect PK for self-referential FK references\n"
                logic += f"        if '{pk_col}' in row and row['{pk_col}'] is not None:\n"
                logic += f"            {parent_var}.append(row['{pk_col}'])\n"
        
        if self.output_format == 'excel':
            logic += "        rows.append(row)\n"
        else:
            logic += "        writer.writerow([row[h] for h in headers])\n"
            logic += "        if len(preview) < 5:\n"
            logic += "            preview.append(row)\n"
        
        return logic

    def _build_model_setup(self, table_name: str, has_bayesian_model: bool) -> str:
        """
        Build model loading and setup code for Bayesian inference
        
        Args:
            table_name: Table name
            has_bayesian_model: Whether this table has a trained Bayesian model
        
        Returns:
            Setup code as string or empty string
        """
        if not has_bayesian_model:
            return ""
        
        setup = ""
        setup += "# Load Bayesian Network ML model for realistic synthetic data generation\n"
        setup += "bayesian_model = None\n"
        setup += "inference_engine = None\n"
        setup += "model_variables = None\n\n"
        setup += f"def load_bayesian_model():\n"
        setup += f"    global bayesian_model, inference_engine, model_variables\n"
        setup += f"    try:\n"
        setup += f"        if PGMPY_AVAILABLE:\n"
        setup += f"            model_path = os.path.join(os.path.dirname(__file__), '../output/models/{table_name}_bayesian.pkl')\n"
        setup += f"            if os.path.exists(model_path):\n"
        setup += f"                with open(model_path, 'rb') as f:\n"
        setup += f"                    bayesian_model = pickle.load(f)\n"
        setup += f"                    inference_engine = VariableElimination(bayesian_model)\n"
        setup += f"                    model_variables = list(bayesian_model.nodes())\n"
        setup += f"                print('[OK] Loaded Bayesian Network model with ' + str(len(model_variables)) + ' variables')\n"
        setup += f"                return True\n"
        setup += f"            else:\n"
        setup += f"                print('[WARNING] Bayesian model not found at ' + model_path)\n"
        setup += f"    except Exception as e:\n"
        setup += f"        print('[WARNING] Failed to load Bayesian model: ' + str(e))\n"
        setup += f"    return False\n\n"
        setup += f"def generate_row_with_inference():\n"
        setup += f"    \"\"\"Generate a single row using Bayesian inference if available, else fallback\"\"\"\n"
        setup += f"    if bayesian_model is None or inference_engine is None:\n"
        setup += f"        return None\n"
        setup += f"    \n"
        setup += f"    try:\n"
        setup += f"        # Use inference engine to generate values respecting probabilistic relationships\n"
        setup += f"        evidence = {{}}\n"
        setup += f"        # Start inference with no evidence (can be extended to use generated values)\n"
        setup += f"        results = {{}}\n"
        setup += f"        \n"
        setup += f"        for var in model_variables:\n"
        setup += f"            try:\n"
        setup += f"                # Query marginal probability for this variable\n"
        setup += f"                marginal = inference_engine.query(variables=[var], evidence=evidence)\n"
        setup += f"                # Sample from the distribution\n"
        setup += f"                state_names = marginal.state_names[var]\n"
        setup += f"                probabilities = marginal.values.flatten()\n"
        setup += f"                sampled_value = random.choices(state_names, weights=probabilities, k=1)[0]\n"
        setup += f"                \n"
        setup += f"                # Try to convert back to appropriate type\n"
        setup += f"                try:\n"
        setup += f"                    results[var] = int(sampled_value)\n"
        setup += f"                except ValueError:\n"
        setup += f"                    try:\n"
        setup += f"                        results[var] = float(sampled_value)\n"
        setup += f"                    except ValueError:\n"
        setup += f"                        results[var] = sampled_value\n"
        setup += f"                \n"
        setup += f"                # Update evidence for next inference (conditional probability)\n"
        setup += f"                evidence[var] = str(sampled_value)\n"
        setup += f"            except Exception as e:\n"
        setup += f"                # Fallback for any variable - return None\n"
        setup += f"                return None\n"
        setup += f"        \n"
        setup += f"        return results\n"
        setup += f"    except Exception as e:\n"
        setup += f"        return None\n\n"
        setup += "# Attempt to load the Bayesian model\n"
        setup += "load_bayesian_model()\n"
        
        return setup

    def _build_fk_setup(self, table_name: str, columns: List[Dict], generation_plan: Dict[str, Any] = None) -> str:
        """
        Build setup code to load parent table data for FK columns
        Uses SMART strategy:
        1. Generate sequential IDs based on parent table row count from generation_plan (GUARANTEED to work)
        2. Try to load actual parent table IDs from file as override (if available)
        3. Fall back to sample values only if all else fails
        
        This ensures FK values are ALWAYS valid and don't depend on timing of parallel execution.
        
        Args:
            table_name: Table name
            columns: Column definitions
            generation_plan: Full generation plan (contains parent table row counts)
        
        Returns:
            Setup code as string (empty if no FKs)
        """
        setup = ""
        loaded_tables = set()
        table_plans = generation_plan.get('table_plans', {}) if generation_plan else {}
        
        for col in columns:
            if not col.get('is_foreign_key', False):
                continue
            
            fk_refs = col.get('foreign_key_references', [])
            if not fk_refs:
                continue
            
            parent_table = fk_refs[0].get('referenced_table', '').upper()
            parent_col = fk_refs[0].get('referenced_column', 'ID').upper()
            ai_detected = fk_refs[0].get('ai_detected', False)
            
            if not parent_table or parent_table in loaded_tables:
                continue
            
            # Handle self-referential FKs (e.g., MANAGER_ID -> EMPLOYEES.EMPLOYEE_ID)
            is_self_ref = (parent_table == table_name.upper())
            
            loaded_tables.add(parent_table)
            parent_var = f"{parent_table.lower()}_ids"
            
            # Get parent table row count from generation plan
            parent_row_count = table_plans.get(parent_table, {}).get('row_count', 100)
            
            # Try both CSV and Excel formats
            csv_file = f"{{os.path.dirname(__file__)}}/../output/SDV/{parent_table.upper()}.csv"
            excel_file = f"{{os.path.dirname(__file__)}}/../output/SDV/{parent_table.upper()}.xlsx"
            
            ai_comment = " (AI-detected)" if ai_detected else ""
            setup += f"    # Load {parent_table}.{parent_col} for FK reference{ai_comment}\n"
            setup += f"    {parent_var} = []\n"
            
            if is_self_ref:
                # Self-referential: build IDs on-the-fly from already generated rows
                setup += f"    # Self-referential FK: will use previously generated IDs\n"
                setup += f"    {parent_var}_pool = []  # Collect IDs as we generate\n"
            else:
                # Regular FK: Load parent table IDs dynamically from file
                # NO hardcoding - use actual data that was generated
                setup += f"    # Load parent table IDs from file (generated data)\n"
                setup += f"    try:\n"
                setup += f"        parent_df = None\n"
                setup += f"        if os.path.exists(f\"{csv_file}\"):\n"
                setup += f"            parent_df = pd.read_csv(f\"{csv_file}\")\n"
                setup += f"        elif os.path.exists(f\"{excel_file}\"):\n"
                setup += f"            parent_df = pd.read_excel(f\"{excel_file}\")\n"
                setup += f"        \n"
                setup += f"        if parent_df is not None and len(parent_df) > 0:\n"
                setup += f"            # Load actual parent table IDs using referenced column name\n"
                setup += f"            ref_col = '{parent_col}'\n"
                setup += f"            if ref_col in parent_df.columns:\n"
                setup += f"                all_ids = parent_df[ref_col].dropna().unique().tolist()\n"
                setup += f"            else:\n"
                setup += f"                # Fallback to first column if referenced column not found\n"
                setup += f"                all_ids = parent_df.iloc[:, 0].dropna().unique().tolist()\n"
                setup += f"            if len(all_ids) > 0:\n"
                setup += f"                {parent_var} = all_ids\n"
                setup += f"                print(f\"[OK] Loaded {{len({parent_var})}} {parent_table} IDs from file\")\n"
                setup += f"            else:\n"
                setup += f"                print(f\"[WARNING] Parent table {parent_table} has no IDs\")\n"
                setup += f"        else:\n"
                setup += f"            print(f\"[WARNING] Parent table file {parent_table} not found or empty\")\n"
                setup += f"    except Exception as e:\n"
                setup += f"        print(f\"[WARNING] Failed to load parent table {parent_table}: {{e}}\")\n"
            setup += f"\n"
        
        return setup
    
    def _indent_for_csv(self, logic: str) -> str:
        """Add 4 more spaces to indent code for CSV context manager (with block)"""
        lines = logic.split('\n')
        indented = []
        for line in lines:
            if line.strip():  # Non-empty lines
                indented.append('    ' + line)  # Add 4 more spaces (was 8, now 12)
            else:
                indented.append(line)
        return '\n'.join(indented)

    def _get_text_faker_by_name(self, col_name: str) -> str:
        """Get appropriate Faker call for a TEXT column based on column name heuristics"""
        col_upper = col_name.upper()
        if 'NAME' in col_upper:
            return "fake.name()"
        elif 'EMAIL' in col_upper:
            return "fake.email()"
        elif 'ADDRESS' in col_upper or 'ADDR' in col_upper:
            return "fake.address().replace('\\n', ', ')"
        elif 'PHONE' in col_upper or 'MOBILE' in col_upper:
            return "fake.phone_number()"
        elif 'COMMENT' in col_upper or 'DESC' in col_upper or 'DESCRIPTION' in col_upper:
            return "fake.sentence()"
        elif 'TITLE' in col_upper:
            return "fake.sentence(nb_words=4)"
        elif 'CITY' in col_upper:
            return "fake.city()"
        elif 'STATE' in col_upper or 'PROVINCE' in col_upper:
            return "fake.state()"
        elif 'COUNTRY' in col_upper:
            return "fake.country()"
        elif 'ZIP' in col_upper or 'POSTAL' in col_upper:
            return "fake.zipcode()"
        elif 'COMPANY' in col_upper or 'ORG' in col_upper:
            return "fake.company()"
        elif 'URL' in col_upper or 'WEBSITE' in col_upper:
            return "fake.url()"
        else:
            return "fake.word()"

    def _get_ml_pattern_expressions(self, table_name: str, row_count: int, columns: List[Dict]) -> Dict[str, str]:
        """Generate Python expressions directly from ML-learned patterns.
        
        This method replaces LLM calls with deterministic pattern-based generation.
        It's faster, more reliable, and uses actual learned distributions.
        
        Returns a mapping of column_name -> Python expression string
        """
        expressions = {}
        
        if table_name not in self.learned_patterns:
            logger.info(f"No learned patterns for {table_name}, using basic generation")
            return {}
        
        table_patterns = self.learned_patterns[table_name]
        col_patterns = table_patterns.get('columns', {})
        
        for col in columns:
            col_name = col['column_name']
            data_type = col.get('data_type', '').upper()
            is_pk = col.get('is_primary_key', False)
            is_fk = col.get('is_foreign_key', False)
            nullable = col.get('nullable', False)
            
            # Skip PK and FK - handled elsewhere
            if is_pk or is_fk:
                continue
            
            if col_name not in col_patterns:
                # No ML pattern for this column — use sample_values or data-type heuristics
                sample_vals = col.get('sample_values', [])
                # Filter out None / empty strings
                clean_samples = [v for v in sample_vals if v is not None and str(v).strip()]

                if 'INT' in data_type or data_type == 'NUMBER':
                    if clean_samples:
                        try:
                            numeric_vals = [int(float(v)) for v in clean_samples]
                            if numeric_vals:
                                expressions[col_name] = f"random.randint({min(numeric_vals)}, {max(numeric_vals)})"
                            else:
                                expressions[col_name] = "random.randint(1, 1000)"
                        except (ValueError, TypeError):
                            expressions[col_name] = "random.randint(1, 1000)"
                    else:
                        expressions[col_name] = "random.randint(1, 1000)"
                elif 'FLOAT' in data_type or 'DECIMAL' in data_type:
                    expressions[col_name] = "random.uniform(0, 1000)"
                elif 'DATE' in data_type:
                    expressions[col_name] = "fake.date_between(start_date='-30y')"
                elif 'TEXT' in data_type or 'VARCHAR' in data_type or 'STRING' in data_type:
                    # If we have a small set of sample values, use them directly
                    # instead of falling back to fake.word()
                    if clean_samples and len(clean_samples) <= 50:
                        import json as _json
                        vals_repr = _json.dumps(clean_samples)
                        expressions[col_name] = f"random.choice({vals_repr})"
                        logger.debug(f"{table_name}.{col_name}: Using {len(clean_samples)} sample values (no ML pattern)")
                    else:
                        expressions[col_name] = self._get_text_faker_by_name(col_name)
                else:
                    if clean_samples and len(clean_samples) <= 50:
                        import json as _json
                        vals_repr = _json.dumps([str(v) for v in clean_samples])
                        expressions[col_name] = f"random.choice({vals_repr})"
                    else:
                        expressions[col_name] = "fake.word()"
                continue
            
            col_pattern = col_patterns[col_name]
            
            # Extract key pattern attributes
            cardinality = col_pattern.get('cardinality', 'medium')
            top_values = col_pattern.get('top_values', {})
            probabilities = col_pattern.get('probabilities', {})
            statistics = col_pattern.get('statistics', {})
            null_percentage = col_pattern.get('null_percentage', 0)
            
            # Generate expression based on pattern
            expr = None
            
            # NUMERIC columns - use statistics if available
            if 'INT' in data_type or 'FLOAT' in data_type or 'DECIMAL' in data_type or 'NUMERIC' in data_type or data_type == 'NUMBER':
                if statistics:
                    mean_val = statistics.get('mean', 500)
                    std_val = statistics.get('std', 100)
                    min_val = statistics.get('min', 0)
                    max_val = statistics.get('max', 1000)
                    
                    # Use Gaussian distribution bounded by min/max
                    if std_val > 0:
                        expr = f"max({min_val}, min({max_val}, random.gauss({mean_val}, {std_val})))"
                    else:
                        expr = f"random.uniform({min_val}, {max_val})"
                    
                    # For integers, convert to int
                    # NUMBER type in Snowflake can be integer - check if statistics suggest integer values
                    is_integer_like = ('INT' in data_type and 'FLOAT' not in data_type) or \
                                     (data_type == 'NUMBER' and min_val == int(min_val) and max_val == int(max_val))
                    if is_integer_like:
                        expr = f"int({expr})"
                else:
                    sample_vals = col.get('sample_values', [])
                    if sample_vals:
                        try:
                            numeric_vals = [float(v) for v in sample_vals if v is not None]
                            if numeric_vals:
                                is_int = ('INT' in data_type) or (data_type == 'NUMBER' and all(v == int(v) for v in numeric_vals))
                                min_val = int(min(numeric_vals)) if is_int else min(numeric_vals)
                                max_val = int(max(numeric_vals)) if is_int else max(numeric_vals)
                                if is_int:
                                    expr = f"random.randint({min_val}, {max_val})"
                                else:
                                    expr = f"random.uniform({min_val}, {max_val})"
                        except:
                            pass
                
                if not expr:
                    expr = "random.randint(1, 1000)"
            
            # TEXT columns - use probabilities if available (categorical)
            elif 'VARCHAR' in data_type or 'TEXT' in data_type or 'STRING' in data_type or 'CHAR' in data_type:
                # COMMENT columns: always use Faker (too many unique values, don't try to use probabilities)
                if 'COMMENT' in col_name.upper():
                    expr = "fake.sentence()"
                    logger.debug(f"{table_name}.{col_name}: Using Faker for comment column")
                
                # DETECT TEXT ID COLUMNS with prefix patterns (e.g., ACC707644, STU336568, COL745381)
                # These should generate NEW unique IDs, not recycle sample values
                elif cardinality == 'high' and col.get('sample_values'):
                    sample_vals = [str(v) for v in col.get('sample_values', []) if v is not None]
                    if sample_vals:
                        # Check for prefix+digits pattern (e.g., ACC707644, STU336568)
                        import re as _re
                        prefix_match = _re.match(r'^([A-Za-z]+)(\d+)$', sample_vals[0])
                        if prefix_match and all(_re.match(r'^[A-Za-z]+\d+$', v) for v in sample_vals[:5]):
                            prefix = prefix_match.group(1)
                            digit_len = len(prefix_match.group(2))
                            max_digit = 10**digit_len - 1
                            expr = f"f'{prefix}{{random.randint(0, {max_digit}):0{digit_len}d}}'"
                            logger.debug(f"{table_name}.{col_name}: TEXT ID with prefix '{prefix}' + {digit_len} digits")
                        else:
                            # High cardinality text but NOT an ID pattern.
                            # Still use probabilities/top_values if available (e.g. SUBCATEGORY
                            # with 20-50 distinct values can be above the 0.9 ratio threshold
                            # but should NOT get fake.word()).
                            if probabilities and len(probabilities) > 0:
                                filtered_probs = {k: v for k, v in probabilities.items() if k != "None" and k is not None}
                                if filtered_probs:
                                    values_list = list(filtered_probs.keys())
                                    weights_list = list(filtered_probs.values())
                                    try:
                                        import json
                                        vals_repr = json.dumps(values_list)
                                        weights_repr = repr(weights_list)
                                        expr = f"random.choices({vals_repr}, weights={weights_repr}, k=1)[0]"
                                        logger.debug(f"{table_name}.{col_name}: High-cardinality TEXT with {len(filtered_probs)} learned probabilities")
                                    except Exception:
                                        expr = None
                            elif top_values and len(top_values) > 0:
                                values_list = list(top_values.keys())
                                try:
                                    import json
                                    vals_repr = json.dumps(values_list)
                                    expr = f"random.choice({vals_repr})"
                                    logger.debug(f"{table_name}.{col_name}: High-cardinality TEXT with {len(top_values)} top values")
                                except Exception:
                                    expr = None

                            # Final fallback: use sample_values from schema metadata
                            if not expr:
                                clean_samples = [v for v in sample_vals if v and str(v).strip()]
                                if clean_samples:
                                    import json as _json
                                    vals_repr = _json.dumps(clean_samples)
                                    expr = f"random.choice({vals_repr})"
                                    logger.debug(f"{table_name}.{col_name}: Using {len(clean_samples)} sample values as fallback")
                                else:
                                    expr = self._get_text_faker_by_name(col_name)
                    else:
                        expr = self._get_text_faker_by_name(col_name)
                
                # Check if we have enumerated values (low/medium cardinality categorical - up to 100 unique)
                elif probabilities and len(probabilities) > 0 and len(probabilities) <= 100:
                    # Use weighted sampling with learned probabilities
                    # IMPORTANT: Filter out "None" string from probabilities
                    filtered_probs = {k: v for k, v in probabilities.items() if k != "None" and k is not None}
                    
                    if filtered_probs and len(filtered_probs) > 0:
                        values_list = list(filtered_probs.keys())
                        weights_list = list(filtered_probs.values())
                        
                        try:
                            import json
                            vals_repr = json.dumps(values_list)
                            weights_repr = repr(weights_list)
                            expr = f"random.choices({vals_repr}, weights={weights_repr}, k=1)[0]"
                            logger.debug(f"{table_name}.{col_name}: Using {len(filtered_probs)} learned value probabilities (excluded NULL)")
                        except Exception as e:
                            logger.warning(f"{table_name}.{col_name}: Failed to generate weighted choice, using fallback: {e}")
                            expr = None
                    else:
                        expr = None
                
                elif top_values and len(top_values) > 0 and len(top_values) <= 100:
                    # Use top values if no explicit probabilities (up to 100 unique values)
                    values_list = list(top_values.keys())
                    try:
                        import json
                        vals_repr = json.dumps(values_list)
                        expr = f"random.choice({vals_repr})"
                        logger.debug(f"{table_name}.{col_name}: Using {len(top_values)} top values")
                    except Exception as e:
                        logger.warning(f"{table_name}.{col_name}: Failed to generate choice, using fallback: {e}")
                        expr = None
                
                if not expr:
                    expr = self._get_text_faker_by_name(col_name)
            
            # DATE/TIMESTAMP columns
            elif 'DATE' in data_type or 'TIMESTAMP' in data_type:
                if statistics:
                    date_min = statistics.get('min')
                    date_max = statistics.get('max')
                    # Handle both float timestamps and date strings
                    if date_min and date_max:
                        try:
                            # Convert numeric timestamps to date strings if needed
                            import pandas as pd
                            if isinstance(date_min, (int, float)):
                                date_min_str = pd.Timestamp(date_min).strftime('%Y-%m-%d')
                                date_max_str = pd.Timestamp(date_max).strftime('%Y-%m-%d')
                            else:
                                date_min_str = str(date_min)
                                date_max_str = str(date_max)
                            expr = f"fake.date_between(start_date='{date_min_str}', end_date='{date_max_str}')"
                        except:
                            expr = f"fake.date_between(start_date='{date_min}', end_date='{date_max}')"
                
                if not expr:
                    expr = "fake.date_between(start_date='-10y')"
            
            # Handle nulls if nullable AND include_nulls is enabled
            if nullable and null_percentage > 0 and self.include_nulls:
                null_prob = null_percentage / 100
                expr = f"None if random.random() < {null_prob} else ({expr})"
            
            if expr:
                expressions[col_name] = expr
                logger.debug(f"{table_name}.{col_name}: {expr}")
        
        return expressions

    def _get_faker_call(self, column: Dict[str, Any]) -> str:
        """
        Get appropriate Faker call for a column
        
        Args:
            column: Column definition
        
        Returns:
            Faker function call as string
        """
        strategy = column['generation_strategy']
        data_type = column['data_type'].upper()
        max_len = column['max_length']
        
        if strategy == 'sequence':
            return 'i + 1'

        # Placeholder values for foreign keys; actual FK values will be
        # overwritten by the ReferentialIntegrityAgent based on parent
        # tables, so we only need type-compatible dummy data here.
        if strategy == 'foreign_key':
            return 'random.randint(1, 100000)'
        
        if strategy == 'word':
            if max_len and max_len <= 10:
                return 'fake.word()[:10]'
            return 'fake.word()'
        
        if strategy == 'sentence':
            if max_len and max_len <= 100:
                return f'fake.sentence(nb_words=10)[:{max_len}]'
            return 'fake.sentence(nb_words=15)'
        
        if strategy == 'random_int':
            # Generic integer range; keeps IDs and numeric fields numeric
            return 'random.randint(1, 100000)'
        
        if strategy == 'random_float':
            return 'round(random.uniform(1, 10000), 2)'
        
        if strategy == 'boolean':
            return 'random.choice([True, False])'
        
        if strategy == 'date_time':
            return 'fake.date_time_this_year()'
        
        if strategy == 'email':
            return 'fake.email()'

        if strategy == 'phone':
            return 'fake.phone_number()[:20]'

        if strategy == 'name':
            return 'fake.name()[:50]'
        
        return 'fake.word()'
    
    def get_script_summary(self) -> str:
        """Get summary of generated scripts"""
        summary = "\n" + "="*60 + "\n"
        summary += "GENERATED SCRIPTS SUMMARY\n"
        summary += "="*60 + "\n"
        
        for table, script_path in self.generated_scripts.items():
            summary += f"✓ {table}: {script_path}\n"
        
        summary += f"\nTotal Scripts: {len(self.generated_scripts)}\n"
        summary += "="*60 + "\n"
        
        return summary
