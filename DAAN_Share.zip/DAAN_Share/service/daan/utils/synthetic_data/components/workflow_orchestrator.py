"""
Supervisor Agent - Orchestrates the entire data generation workflow
"""
import logging
import subprocess
import sys
import os
from typing import Dict, Any, List
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
import time

logger = logging.getLogger(__name__)

# Thread-safe output lock
output_lock = Lock()


class WorkflowOrchestrator:
    """
    Orchestrate the complete synthetic data generation workflow
    """
    
    def __init__(self, metadata: Dict[str, Any], generation_plan: Dict[str, Any], 
                 scripts_dir: str, output_dir: str, output_format: str = 'csv'):
        """
        Initialize Workflow Orchestrator
        
        Args:
            metadata: Schema metadata
            generation_plan: Generation plan
            scripts_dir: Directory containing generated scripts
            output_dir: Output directory for generated data
            output_format: Output format ('csv' or 'excel')
        """
        self.metadata = metadata
        self.generation_plan = generation_plan
        self.scripts_dir = scripts_dir
        self.output_dir = output_dir
        self.output_format = output_format.lower()
        self.execution_results = {}
    
    def execute_workflow(self) -> bool:
        """
        Execute complete data generation workflow
        
        Returns:
            bool: True if all steps completed successfully
        """
        try:
            print("\n" + "="*60)
            print("🚀 STARTING SYNTHETIC DATA GENERATION WORKFLOW")
            print("="*60)
            
            # Step 1: Execute generation scripts
            if not self._execute_generation_scripts():
                logger.error("Generation scripts execution failed")
                return False
            
            # Step 2: Enforce referential integrity
            if not self._enforce_referential_integrity():
                logger.error("Referential integrity enforcement failed")
                return False
            
            # Step 3: Validate generated data
            if not self._validate_generated_data():
                logger.error("Data validation failed")
                return False
            
            # Step 4: Generate summary report
            self._generate_execution_report()
            
            logger.info("Workflow completed successfully")
            print("\n" + "="*60)
            print("✓ WORKFLOW COMPLETED SUCCESSFULLY")
            print("="*60)
            return True
        
        except Exception as e:
            logger.error(f"Workflow execution failed: {str(e)}")
            print(f"❌ Workflow Error: {str(e)}")
            return False
    
    def _execute_generation_scripts(self) -> bool:
        """
        Execute all generated Python scripts SEQUENTIALLY (in order)
        This ensures parent tables are generated before child tables,
        allowing FK relationships to load parent data correctly.
        
        Returns:
            bool: True if all scripts executed successfully
        """
        try:
            print("\n📊 STEP 1: Executing generation scripts (SEQUENTIAL)...")

            execution_order = self.generation_plan.get('execution_order', [])
            if not execution_order:
                # Fallback to table plans if execution order is missing
                execution_order = list(self.generation_plan.get('table_plans', {}).keys())

            if not execution_order:
                logger.error("No tables found in generation plan to execute")
                print("❌ No tables found in generation plan to execute")
                return False

            executed_count = 0
            failed_tables = []
            start_time = time.time()

            # Execute scripts in order (sequentially)
            # This ensures parent tables exist before child tables load them for FK references
            for table in execution_order:
                try:
                    print(f"  * Executing {table}...")
                    result = self._execute_single_script(table)
                    output_exists, output_path = self._output_file_exists(table)

                    if result['success'] and output_exists:
                        print(f"    ✓ {table} completed")
                        logger.info(f"Script executed: {table}")
                        executed_count += 1
                        self.execution_results[table] = {
                            'status': 'SUCCESS',
                            'output': result.get('output', ''),
                            'output_file': output_path
                        }
                    else:
                        if result['success'] and not output_exists:
                            error_msg = f"Script completed but output file not found for {table}"
                        else:
                            error_msg = result.get('error', 'Unknown script execution error')

                        print(f"    ✗ {table} failed: {error_msg}")
                        logger.error(f"Script failed for {table}: {error_msg}")
                        self.execution_results[table] = {
                            'status': 'FAILED',
                            'error': error_msg,
                            'stdout': result.get('stdout', ''),
                            'stderr': result.get('stderr', ''),
                            'returncode': result.get('returncode')
                        }
                        failed_tables.append(table)
                        # Continue with next table even if one fails
                except Exception as e:
                    print(f"    ✗ {table} error: {str(e)}")
                    logger.error(f"Script execution error for {table}: {str(e)}")
                    self.execution_results[table] = {
                        'status': 'FAILED',
                        'error': str(e)
                    }
                    failed_tables.append(table)
                    # Continue with next table

            elapsed_time = time.time() - start_time
            print(f"\n✓ Generated {executed_count}/{len(execution_order)} tables in {elapsed_time:.1f}s")
            logger.info(f"Executed {executed_count}/{len(execution_order)} scripts in {elapsed_time:.1f}s")

            if failed_tables:
                failed_list = ", ".join(failed_tables)
                print(f"❌ Failed tables: {failed_list}")
                logger.error(f"Failed tables: {failed_list}")
                return False

            return True

        except Exception as e:
            logger.error(f"Script execution failed: {str(e)}")
            print(f"❌ Error: {str(e)}")
            return False
    
    def _execute_single_script(self, table: str) -> Dict[str, Any]:
        """
        Execute a single generation script
        
        Args:
            table: Table name
            
        Returns:
            Dictionary with execution result
        """
        script_file = f"generate_{table.lower()}.py"
        script_path = os.path.join(self.scripts_dir, script_file)
        
        if not os.path.exists(script_path):
            return {
                'success': False,
                'error': f'Script not found: {script_path}'
            }
        
        with output_lock:
            print(f"  * Executing {table}...")
        
        try:
            env = os.environ.copy()
            result = subprocess.run(
                [sys.executable, script_path],
                capture_output=True,
                text=True,
                timeout=3600,  # 60-minute timeout per script
                env=env,
                cwd=self.scripts_dir
            )

            if result.returncode == 0:
                return {
                    'success': True,
                    'output': result.stdout,
                    'stdout': result.stdout,
                    'stderr': result.stderr,
                    'returncode': result.returncode
                }
            else:
                error_parts = [f"Return code: {result.returncode}"]
                if result.stderr and result.stderr.strip():
                    error_parts.append(f"stderr: {result.stderr.strip()}")
                if result.stdout and result.stdout.strip():
                    error_parts.append(f"stdout: {result.stdout.strip()}")

                return {
                    'success': False,
                    'error': "\n".join(error_parts),
                    'stdout': result.stdout,
                    'stderr': result.stderr,
                    'returncode': result.returncode
                }
        
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'error': f'Script timeout after 3600s'
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def _output_file_exists(self, table: str) -> tuple[bool, str]:
        """Check whether output data file exists for a table."""
        ext = ".xlsx" if self.output_format == 'excel' else ".csv"
        candidates = [
            table.upper(), table, table.lower()
        ]
        # Check both the root output_dir and the SDV/ subfolder that the
        # generated scripts write to by default.
        search_dirs = [
            self.output_dir,
            os.path.join(self.output_dir, "SDV"),
        ]
        for search_dir in search_dirs:
            for name in candidates:
                path = os.path.join(search_dir, f"{name}{ext}")
                if os.path.exists(path):
                    return True, path

        return False, ""
    
    def _enforce_referential_integrity(self) -> bool:
        """
        Enforce referential integrity constraints
        
        Returns:
            bool: True if successful
        """
        try:
            print("\n🔗 STEP 2: Enforcing referential integrity...")
            
            from daan.native_tools.synthetic_data.components.referential_integrity_enforcer import ReferentialIntegrityEnforcer
            
            ri_agent = ReferentialIntegrityEnforcer(self.generation_plan, self.metadata, self.output_dir, self.output_format)
            
            if ri_agent.enforce_referential_integrity():
                print("* Referential integrity enforced")
                
                # Generate integrity script
                script_path = os.path.join(self.scripts_dir, "apply_referential_integrity.py")
                if ri_agent.generate_integrity_script(script_path):
                    print("* Integrity script generated")
                
                return True
            else:
                logger.error("Failed to enforce referential integrity")
                return False
        
        except Exception as e:
            logger.error(f"Referential integrity enforcement failed: {str(e)}")
            print(f"[ERROR] {str(e)}")
            return False
    
    def _validate_generated_data(self) -> bool:
        """
        Validate generated data SEQUENTIALLY
        
        Returns:
            bool: True if validation passed
        """
        try:
            print("\n✓ STEP 3: Validating generated data...")
            
            execution_order = self.generation_plan.get('execution_order', [])
            
            # Validate tables sequentially
            for table in execution_order:
                try:
                    result = self._validate_single_table(table)
                    print(f"  * {table}: {result['rows']} rows, {result['cols']} columns")
                    logger.info(f"Validated {table}: {result['rows']} rows")
                except Exception as e:
                    print(f"  ⚠ Validation error for {table}: {str(e)}")
                    logger.warning(f"Validation failed for {table}: {str(e)}")
            
            print("✓ Data validation completed")
            return True
        
        except Exception as e:
            logger.error(f"Data validation failed: {str(e)}")
            print(f"❌ Error: {str(e)}")
            return False
    
    def _validate_single_table(self, table: str) -> Dict[str, Any]:
        """
        Validate a single table
        
        Args:
            table: Table name
            
        Returns:
            Dictionary with validation result
        """
        import pandas as pd
        
        # Try multiple file name patterns (uppercase/lowercase) to be robust
        if self.output_format == 'excel':
            paths_to_try = [
                os.path.join(self.output_dir, f"{table.upper()}.xlsx"),
                os.path.join(self.output_dir, f"{table}.xlsx"),
            ]
        else:
            paths_to_try = [
                os.path.join(self.output_dir, f"{table.upper()}.csv"),
                os.path.join(self.output_dir, f"{table}.csv"),
                os.path.join(self.output_dir, f"{table.lower()}.csv"),
            ]
        
        for data_path in paths_to_try:
            if os.path.exists(data_path):
                if data_path.endswith('.xlsx'):
                    df = pd.read_excel(data_path)
                else:
                    df = pd.read_csv(data_path)
                
                return {
                    'rows': len(df),
                    'cols': len(df.columns)
                }
        
        raise FileNotFoundError(f"Data file not found for {table} (tried {[os.path.basename(p) for p in paths_to_try]})")
    
    def _generate_execution_report(self):
        """Generate and display execution report"""
        try:
            print("\n" + "="*60)
            print("EXECUTION REPORT")
            print("="*60)
            
            execution_order = self.generation_plan.get('execution_order', [])
            table_plans = self.generation_plan.get('table_plans', {})
            
            total_rows = 0
            successful_tables = 0
            pattern_quality_summary = {}
            
            for table in execution_order:
                if table in table_plans:
                    plan = table_plans[table]
                    row_count = plan['row_count']
                    total_rows += row_count
                    
                    status = self.execution_results.get(table, {}).get('status', 'UNKNOWN')
                    if status == 'SUCCESS':
                        successful_tables += 1
                    
                    # Collect pattern quality info from columns
                    columns = plan.get('columns', [])
                    pk_count = 0
                    pattern_detected = 0
                    for col in columns:
                        if col.get('is_primary_key'):
                            pk_count += 1
                            if col.get('increment_pattern'):
                                pattern_detected += 1
                    
                    if pk_count > 0:
                        pattern_quality = f"{pattern_detected}/{pk_count}"
                        pattern_quality_summary[table] = pattern_quality
                    
                    print(f"  {table}: {row_count} rows - {status}")
            
            # Print pattern quality summary if available
            if pattern_quality_summary:
                print("\nPATTERN QUALITY (PKs with detected patterns):")
                for table, quality in pattern_quality_summary.items():
                    print(f"  {table}: {quality} patterns detected")
            
            print(f"\nTotal Tables: {len(execution_order)}")
            print(f"Successful: {successful_tables}")
            print(f"Total Rows Generated: {total_rows}")
            print(f"Output Directory: {self.output_dir}")
            print("="*60)
            
            logger.info(f"Report generated: {successful_tables}/{len(execution_order)} tables successful")
        
        except Exception as e:
            logger.error(f"Failed to generate report: {str(e)}")
