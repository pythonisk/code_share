"""
ML Pattern Learner Component - Bayesian Network ML Training
Trains actual Bayesian Network models using pgmpy
Learns probabilistic distributions and relationships from sample data
Includes caching to avoid retraining on same database schema
"""
import os
import json
import logging
import pandas as pd
import numpy as np
import pickle
import warnings
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
from collections import defaultdict

# ML Libraries for Bayesian Networks
try:
    from pgmpy.models import DiscreteBayesianNetwork
    from pgmpy.estimators import MaximumLikelihoodEstimator, BayesianEstimator
    from pgmpy.inference import VariableElimination
    PGMPY_AVAILABLE = True
except ImportError:
    PGMPY_AVAILABLE = False
    warnings.warn("pgmpy not installed. Install with: pip install pgmpy")

warnings.filterwarnings('ignore')
logger = logging.getLogger(__name__)


class MLPatternLearner:
    """
    Train Bayesian Network ML models from sample data
    Uses pgmpy for actual machine learning with probabilistic graphical models
    Includes caching to avoid retraining on same database schema
    """
    
    def __init__(self, output_dir: str, save_samples: bool = True, use_cache: bool = True, force_retrain: bool = False):
        """
        Initialize ML Pattern Learner with Bayesian Network support and caching
        
        Args:
            output_dir: Directory to save learned patterns and trained models
            save_samples: Whether to save sample data to CSV for reference
            use_cache: Whether to use cached models if available
            force_retrain: Force retraining even if cache exists
        """
        self.output_dir = output_dir
        self.save_samples = save_samples
        self.use_cache = use_cache and not force_retrain
        self.force_retrain = force_retrain
        self.learned_patterns = {}
        self.trained_models = {}  # Store trained Bayesian models per table
        
        # Import cache manager
        from daan.native_tools.synthetic_data.components.model_cache_manager import ModelCacheManager
        self.cache_manager = ModelCacheManager(os.path.join(output_dir, 'model_cache'))
        
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(os.path.join(output_dir, 'models'), exist_ok=True)
        if save_samples:
            os.makedirs(os.path.join(output_dir, 'samples'), exist_ok=True)
    
    def learn_patterns_from_dataframes(self, table_dataframes: Dict[str, pd.DataFrame], force_retrain: Optional[bool] = None, database: str = "sdg") -> Dict[str, Any]:
        """
        Train Bayesian Network ML models directly from DataFrames.
        Uses per-table caching - loads individual table models from cache.

        Args:
            table_dataframes: Dictionary of {table_name: DataFrame}
            force_retrain: Override use_cache setting (True = force training, False = use cache if available)
            database: Logical database name used as the cache key prefix (default: "sdg")

        Returns:
            Dictionary of learned patterns and trained models per table
        """
        try:
            if force_retrain is None:
                force_retrain = self.force_retrain

            print("\n🧠 Training Bayesian Network ML models from input data...")
            
            # Process each table - check cache first, then train if needed
            for table_name, df in table_dataframes.items():
                if df is None or df.empty:
                    print(f"  * Skipping {table_name} - no data")
                    continue
                
                # Check if model is cached for this table (per-table cache lookup)
                if self.use_cache and not force_retrain and self.cache_manager.is_table_cached(database, table_name):
                    print(f"  ⚡ Loading cached model for {table_name}...")
                    cached_model = self.cache_manager.load_table_model(database, table_name)
                    
                    if cached_model:
                        # Extract the actual BayesianNetwork object, not the whole cache dict.
                        # Storing the dict caused VariableElimination(dict).check_model() to fail
                        # when the generated script loaded the .pkl at runtime.
                        bn_model = cached_model.get('bayesian_model')
                        if bn_model is not None:
                            self.trained_models[table_name] = bn_model
                        self.learned_patterns[table_name] = cached_model.get('patterns', {})
                        print(f"    ✓ Loaded from cache - {len(cached_model.get('patterns', {}).get('columns', []))} columns")
                        continue
                
                # No cache or force retrain - train the model
                print(f"  * Training {table_name} ({len(df)} rows)...")
                
                # Save sample to CSV for reference/debugging
                if self.save_samples:
                    try:
                        sample_file = os.path.join(self.output_dir, 'samples', f"{table_name}_sample.csv")
                        df.to_csv(sample_file, index=False)
                        print(f"    💾 Saved sample to samples/{table_name}_sample.csv")
                    except Exception as e:
                        logger.warning(f"Could not save sample for {table_name}: {str(e)}")
                
                patterns = self._train_table_model_from_df(table_name, df)
                
                if patterns:
                    self.learned_patterns[table_name] = patterns
                    print(f"    ✓ Model trained - {len(patterns['columns'])} columns, {patterns.get('model_edges', 0)} edges")
                    
                    # Save individual table model to cache immediately after training
                    if self.use_cache:
                        # Create model dict with patterns included
                        model_to_cache = {
                            'patterns': patterns,
                            'bayesian_model': self.trained_models.get(table_name)  # May be None if insufficient data
                        }
                        if self.cache_manager.save_table_model(database, table_name, model_to_cache):
                            print(f"    💾 Cached model for {table_name}")
            
            # Save learned patterns and models
            if self.learned_patterns:
                self._save_patterns()
                self._save_trained_models()
                print(f"\n✓ ML training complete for {len(self.learned_patterns)} tables")
                print(f"  📁 Patterns: output/learned_patterns.json")
                print(f"  🧠 Models: output/model_cache/{database}/")
            else:
                print("\n⚠ No models trained - check if data is available")
            
            return self.learned_patterns
            
        except Exception as e:
            logger.error(f"ML training failed: {str(e)}")
            print(f"❌ ML training error: {str(e)}")
            return {}
    
    def _train_table_model_from_df(self, table_name: str, df: pd.DataFrame) -> Optional[Dict[str, Any]]:
        """
        Train a Bayesian Network model directly from a DataFrame
        
        Args:
            table_name: Name of the table
            df: DataFrame from Snowflake
        
        Returns:
            Dictionary with trained model and learned patterns
        """
        try:
            if df.empty:
                logger.warning(f"Empty DataFrame for {table_name}")
                return None
            
            # Analyze relationships between columns
            relationships = self._detect_relationships(df)
            
            # Extract statistical patterns for each column
            column_patterns = {}
            for col in df.columns:
                col_pattern = self._extract_column_pattern(df, col)
                if col_pattern:
                    column_patterns[col] = col_pattern
            
            # Train Bayesian Network model if possible
            bayesian_model = None
            model_edges = 0
            if PGMPY_AVAILABLE and len(df.columns) >= 2 and len(df) >= 100:
                try:
                    print(f"    🔄 Training Bayesian Network for {table_name}...")
                    bayesian_model, model_edges = self._train_bayesian_network(df, relationships)
                    if bayesian_model:
                        self.trained_models[table_name] = bayesian_model
                        print(f"    ✅ Bayesian Network trained with {model_edges} edges")
                    else:
                        print(f"    ⚠️ No Bayesian model created (may need more relationships)")
                except Exception as e:
                    logger.warning(f"Bayesian training failed for {table_name}: {str(e)}")
                    print(f"    ⚠️ Bayesian training error: {str(e)}")
                    import traceback
                    traceback.print_exc()
            
            return {
                'table_name': table_name,
                'sample_size': len(df),
                'columns': column_patterns,
                'relationships': relationships,
                'has_bayesian_model': bayesian_model is not None,
                'model_edges': model_edges
            }
            
        except Exception as e:
            logger.error(f"Error training {table_name}: {str(e)}")
            print(f"    ⚠ Training error: {str(e)}")
            return None
    
    def _train_bayesian_network(self, df: pd.DataFrame, relationships: Dict) -> tuple:
        """
        Train a Bayesian Network model on the data
        
        Args:
            df: DataFrame with sample data
            relationships: Detected relationships between columns
        
        Returns:
            Tuple of (trained model, number of edges)
        """
        try:
            # Filter to only medium-cardinality columns (< 200 unique values)
            # This expands coverage while keeping memory manageable
            low_card_cols = []
            for col in df.columns:
                unique_count = df[col].nunique()
                if unique_count < 200:  # Include medium-cardinality columns
                    low_card_cols.append(col)
            
            if len(low_card_cols) < 2:
                print(f"    ⚠️ Not enough medium-cardinality columns (<200 unique values) for Bayesian Network")
                return None, 0
            
            # Use only low-cardinality columns
            df_filtered = df[low_card_cols].copy()
            
            # Discretize numeric columns for Bayesian Network
            df_discrete = df_filtered.copy()
            for col in df_discrete.columns:
                if pd.api.types.is_numeric_dtype(df_discrete[col]):
                    # Convert numeric to categorical bins using entropy-based approach
                    unique_count = df_discrete[col].nunique()
                    if unique_count > 10:  # Only discretize if many unique values
                        # Use more bins for better granularity (up to 10 bins)
                        n_bins = min(10, max(5, int(unique_count / 5)))
                        df_discrete[col] = pd.qcut(df_discrete[col], q=n_bins, 
                                                   labels=False, duplicates='drop')
                
                # Convert to string for pgmpy
                df_discrete[col] = df_discrete[col].astype(str)
            
            edges = []
            
            # Build edges from detected relationships (only if both columns are in filtered set)
            for rel in relationships.get('one_to_many', {}).keys():
                col1, col2 = rel.split(' -> ')
                if col1 in df_discrete.columns and col2 in df_discrete.columns:
                    edges.append((col1, col2))
            
            for rel in relationships.get('many_to_one', {}).keys():
                col1, col2 = rel.split(' -> ')
                if col1 in df_discrete.columns and col2 in df_discrete.columns:
                    edges.append((col1, col2))
            
            # For many-to-many, select one direction to avoid cycles
            for rel in relationships.get('many_to_many', {}).keys():
                parts = rel.split(' <-> ')
                if len(parts) == 2:
                    col1, col2 = parts
                    if col1 in df_discrete.columns and col2 in df_discrete.columns:
                        edges.append((col1, col2))
            
            # Remove duplicates
            edges = list(set(edges))
            
            if not edges:
                # If no relationships detected, create minimal network with low-card columns
                if len(low_card_cols) >= 2:
                    edges = [(low_card_cols[0], low_card_cols[1])]
                else:
                    return None, 0
            
            print(f"    🔍 Training on {len(low_card_cols)} low-cardinality columns: {low_card_cols[:5]}...")
            
            # Create and train the Discrete Bayesian Network
            model = DiscreteBayesianNetwork(edges)
            model.fit(df_discrete, estimator=MaximumLikelihoodEstimator)
            
            return model, len(edges)
            
        except Exception as e:
            logger.error(f"Bayesian Network training error: {str(e)}")
            return None, 0
    
    def _detect_relationships(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Detect relationships between columns using correlation analysis
        
        Args:
            df: DataFrame with sample data
        
        Returns:
            Dictionary describing relationships
        """
        relationships = {
            'one_to_many': {},
            'many_to_one': {},
            'many_to_many': {},
            'correlations': {}
        }
        
        try:
            columns = df.columns.tolist()
            
            # Analyze column pairs for cardinality relationships
            for i, col1 in enumerate(columns):
                for col2 in columns[i+1:]:
                    # Count unique values
                    unique_col1 = df[col1].nunique()
                    unique_col2 = df[col2].nunique()
                    
                    if unique_col1 < 2 or unique_col2 < 2:
                        continue
                    
                    # Calculate cardinality ratios
                    combinations = df.groupby(col1)[col2].nunique()
                    avg_combinations = combinations.mean()
                    
                    rev_combinations = df.groupby(col2)[col1].nunique()
                    avg_rev_combinations = rev_combinations.mean()
                    
                    # Classify relationship (improved thresholds - more sensitive)
                    # 1.2 threshold captures more relationships instead of 1.5
                    if avg_combinations > 1.2 and avg_rev_combinations <= 1.2:
                        relationships['one_to_many'][f"{col1} -> {col2}"] = {
                            'avg_ratio': round(avg_combinations, 2),
                            'unique_col1': int(unique_col1),
                            'unique_col2': int(unique_col2)
                        }
                    elif avg_rev_combinations > 1.2 and avg_combinations <= 1.2:
                        relationships['many_to_one'][f"{col1} -> {col2}"] = {
                            'avg_ratio': round(avg_rev_combinations, 2),
                            'unique_col1': int(unique_col1),
                            'unique_col2': int(unique_col2)
                        }
                    elif avg_combinations > 1.2 and avg_rev_combinations > 1.2:
                        relationships['many_to_many'][f"{col1} <-> {col2}"] = {
                            'col1_to_col2': round(avg_combinations, 2),
                            'col2_to_col1': round(avg_rev_combinations, 2),
                            'unique_col1': int(unique_col1),
                            'unique_col2': int(unique_col2)
                        }
        
        except Exception as e:
            logger.debug(f"Relationship detection skipped: {str(e)}")
        
        return relationships
    
    def _extract_column_pattern(self, df: pd.DataFrame, column: str) -> Optional[Dict[str, Any]]:
        """
        Extract distribution pattern for a single column
        
        Args:
            df: DataFrame with sample data
            column: Column name
        
        Returns:
            Dictionary with column pattern
        """
        try:
            col_data = df[column]
            
            # Basic statistics
            unique_count = col_data.nunique()
            total_count = len(col_data)
            null_count = col_data.isna().sum()
            
            # Value distribution (capture all values for better pattern recognition)
            # Limit to 500 most common for very high cardinality columns
            value_counts = col_data.value_counts(dropna=False).head(500)
            distribution = value_counts.to_dict()
            
            # Normalize to probabilities
            probabilities = (value_counts / total_count).to_dict()
            
            # Check if categorical or numerical
            is_numeric = pd.api.types.is_numeric_dtype(col_data)
            
            # Determine cardinality
            if total_count > 0:
                cardinality_ratio = unique_count / total_count
            else:
                cardinality_ratio = 0.0
                
            if cardinality_ratio > 0.9:
                cardinality = 'high'
            elif cardinality_ratio > 0.1:
                cardinality = 'medium'
            else:
                cardinality = 'low'
            
            pattern = {
                'unique_count': int(unique_count),
                'total_count': int(total_count),
                'null_count': int(null_count),
                'null_percentage': float(null_count / total_count * 100) if total_count > 0 else 0.0,
                'is_numeric': bool(is_numeric),
                'cardinality': cardinality,
                'top_values': {str(k): int(v) for k, v in list(distribution.items())[:100]},
                'probabilities': {str(k): float(v) for k, v in list(probabilities.items())[:100]}
            }
            
            # Add numerical statistics if applicable
            if is_numeric:
                col_numeric = pd.to_numeric(col_data, errors='coerce').dropna()
                if len(col_numeric) > 0:
                    pattern['statistics'] = {
                        'mean': float(col_numeric.mean()),
                        'std': float(col_numeric.std()) if len(col_numeric) > 1 else 0.0,
                        'min': float(col_numeric.min()),
                        'max': float(col_numeric.max()),
                        'median': float(col_numeric.median()),
                        'q25': float(col_numeric.quantile(0.25)),
                        'q75': float(col_numeric.quantile(0.75))
                    }
                    
                    # For ID columns (high cardinality unique numeric), analyze patterns
                    if cardinality == 'high' and unique_count == total_count:
                        pattern['id_pattern'] = self._analyze_id_pattern(col_numeric, column)
            
            return pattern
            
        except Exception as e:
            logger.error(f"Error extracting pattern for {column}: {str(e)}")
            return None
    
    def _analyze_id_pattern(self, col_numeric, column: str) -> Dict[str, Any]:
        """
        Analyze patterns in ID columns (sequential, gaps, distribution)
        
        Args:
            col_numeric: Numeric series with ID values
            column: Column name
        
        Returns:
            Dictionary with ID pattern info
        """
        try:
            sorted_ids = sorted(col_numeric.dropna().unique())
            
            if len(sorted_ids) < 2:
                return None
            
            # Calculate gaps between consecutive IDs
            gaps = [sorted_ids[i+1] - sorted_ids[i] for i in range(len(sorted_ids)-1)]
            
            # Check if sequential (all gaps equal to 1)
            is_sequential = all(gap == 1 for gap in gaps)
            
            # Average gap
            avg_gap = float(np.mean(gaps)) if gaps else 1.0
            
            # Most common gap (mode)
            from collections import Counter
            gap_counts = Counter(gaps)
            most_common_gap = gap_counts.most_common(1)[0][0] if gap_counts else 1
            
            id_pattern = {
                'is_sequential': bool(is_sequential),
                'min_id': float(sorted_ids[0]),
                'max_id': float(sorted_ids[-1]),
                'avg_gap': float(avg_gap),
                'most_common_gap': float(most_common_gap),
                'total_unique': len(sorted_ids),
                'expected_continuous_count': int((sorted_ids[-1] - sorted_ids[0]) / avg_gap + 1) if avg_gap > 0 else 0,
                'gap_distribution': dict(gap_counts.most_common(10))  # Top 10 gaps
            }
            
            return id_pattern
            
        except Exception as e:
            logger.debug(f"Could not analyze ID pattern for {column}: {str(e)}")
            return None
    
    def _fallback_statistical_learning_from_dfs(self, table_dataframes: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
        """
        Fallback to statistical learning if pgmpy is not available
        """
        print("\n📊 Using statistical pattern learning (no ML dependencies)...")
        
        for table_name, df in table_dataframes.items():
            if df is None or df.empty:
                continue
            
            print(f"  * Analyzing {table_name}...")
            try:
                relationships = self._detect_relationships(df)
                column_patterns = {}
                
                for col in df.columns:
                    col_pattern = self._extract_column_pattern(df, col)
                    if col_pattern:
                        column_patterns[col] = col_pattern
                
                self.learned_patterns[table_name] = {
                    'table_name': table_name,
                    'sample_size': len(df),
                    'columns': column_patterns,
                    'relationships': relationships,
                    'has_bayesian_model': False,
                    'model_edges': 0
                }
                print(f"    ✓ Patterns extracted for {len(column_patterns)} columns")
            except Exception as e:
                print(f"    ⚠ Analysis error: {str(e)}")
        
        if self.learned_patterns:
            self._save_patterns()
            print(f"\n✓ Statistical analysis complete for {len(self.learned_patterns)} tables")
        
        return self.learned_patterns
    
    def _save_patterns(self):
        """Save learned patterns to JSON file - DEPRECATED
        
        No longer needed since PKL Bayesian models are the primary source.
        This is kept for debugging/reference only but not used in generation.
        """
        # JSON pattern saving disabled - using PKL models instead
        logger.info("JSON pattern saving disabled - PKL models are primary source")
    
    def _save_trained_models(self):
        """Save trained Bayesian models to pickle files"""
        if not self.trained_models:
            return
        
        try:
            for table_name, model in self.trained_models.items():
                model_file = os.path.join(self.output_dir, 'models', f"{table_name}_bayesian.pkl")
                
                with open(model_file, 'wb') as f:
                    pickle.dump(model, f)
                
                logger.info(f"Saved Bayesian model for {table_name}")
            
            print(f"  ✓ Saved {len(self.trained_models)} trained Bayesian models")
            
        except Exception as e:
            logger.error(f"Failed to save models: {str(e)}")
    
    def get_column_pattern(self, table: str, column: str) -> Optional[Dict[str, Any]]:
        """
        Get learned pattern for a specific column
        
        Args:
            table: Table name
            column: Column name
        
        Returns:
            Pattern dictionary or None
        """
        if table in self.learned_patterns:
            return self.learned_patterns[table]['columns'].get(column)
        return None
    
    def get_table_relationships(self, table: str) -> Optional[Dict[str, Any]]:
        """
        Get learned relationships for a table
        
        Args:
            table: Table name
        
        Returns:
            Relationships dictionary or None
        """
        if table in self.learned_patterns:
            return self.learned_patterns[table].get('relationships')
        return None
    
    def get_trained_model(self, table: str):
        """
        Get trained Bayesian model for a table
        
        Args:
            table: Table name
        
        Returns:
            Trained Bayesian Network model or None
        """
        return self.trained_models.get(table)
