import os
import json
import logging
import re
import glob
from typing import List, Dict, Optional

# Robust imports: support running as a module (-m) and directly as a script
# When executed as part of the package (recommended)
from daan.utils.file_to_json import FileToJsonConverter
from daan.utils.file_partitioner import FilePartitioner
from daan.utils.filepartitions.file_partition import FilePartition
from daan.llm.cost_tracking import estimate_tokens
from daan.llm.llm_provider import build_llm_tags, get_core_agent_model, get_llm_completion

# Configure logger
logger = logging.getLogger(__name__)

class ContextMapper:
    """
    Uses LLM to map agent inputs to file partitions.
    """

    def __init__(self) -> None:
        self.token_usage = {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
            "model": "",
            "provider": "",
        }

    def _record_batch_usage(self, prompt: str, completion: dict[str, object]) -> None:
        usage = completion.get("usage") if isinstance(completion, dict) else None
        if isinstance(usage, dict) and usage:
            prompt_tokens = int(usage.get("prompt_tokens") or usage.get("input_tokens") or 0)
            completion_tokens = int(usage.get("completion_tokens") or usage.get("output_tokens") or 0)
            total_tokens = int(usage.get("total_tokens") or (prompt_tokens + completion_tokens) or 0)
        else:
            model_name = str((completion or {}).get("model") or "").strip() or "gpt-4"
            completion_text = str((completion or {}).get("text") or "")
            estimated = estimate_tokens(model=model_name, prompt=prompt or "", completion=completion_text or "")
            prompt_tokens = int(estimated.get("prompt_tokens") or 0)
            completion_tokens = int(estimated.get("completion_tokens") or 0)
            total_tokens = int(estimated.get("total_tokens") or 0)

        self.token_usage["prompt_tokens"] += prompt_tokens
        self.token_usage["completion_tokens"] += completion_tokens
        self.token_usage["total_tokens"] += total_tokens

        model_name = str((completion or {}).get("model") or "").strip()
        provider_name = str((completion or {}).get("provider") or "").strip()
        if model_name:
            self.token_usage["model"] = model_name
        if provider_name:
            self.token_usage["provider"] = provider_name

    def map_context_multi_agent(self, agents: List[Dict[str, str]], partitions: List[FilePartition]) -> Dict[str, Dict[str, List[FilePartition]]]:
        """
        Ask LLM to map partitions to inputs for MULTIPLE agents in one go (batched).
        
        Args:
            agents: List of dicts with 'id', 'name', 'inputs'
            partitions: List of FilePartition objects
            
        Returns:
            Dict: { agent_id: { input_name: [FilePartition] } }
        """
        if not partitions:
            return {agent['id']: {} for agent in agents}

        # Constants for batching
        MAX_CONTEXT_TOKENS = 100000 
        CHARS_PER_TOKEN = 4
        MAX_CONTEXT_CHARS = MAX_CONTEXT_TOKENS * CHARS_PER_TOKEN
        BASE_PROMPT_CHARS = 5000 # Higher overhead for agent list
        
        final_results = {agent['id']: {} for agent in agents}
        
        total_partitions = len(partitions)
        logger.info(f"Mapping {total_partitions} partitions for {len(agents)} agents")

        current_batch = []
        current_batch_chars = BASE_PROMPT_CHARS
        
        batch_count = 0
        
        for i, p in enumerate(partitions):
            partition_str = f"ID: {len(current_batch)}\nFile: {p.filename}\nPartition: {p.partition_id}\nSummary: {p.summary}\n---"
            partition_chars = len(partition_str)
            
            if current_batch and (current_batch_chars + partition_chars > MAX_CONTEXT_CHARS):
                batch_count += 1
                logger.info(f"Processing batch {batch_count} ({len(current_batch)} partitions)")
                batch_mapping = self._map_batch_multi_agent(agents, current_batch)
                self._merge_results_multi_agent(final_results, batch_mapping)
                
                current_batch = []
                current_batch_chars = BASE_PROMPT_CHARS
            
            current_batch.append(p)
            current_batch_chars += partition_chars
            
        if current_batch:
            batch_count += 1
            logger.info(f"Processing final batch {batch_count} ({len(current_batch)} partitions)")
            batch_mapping = self._map_batch_multi_agent(agents, current_batch)
            self._merge_results_multi_agent(final_results, batch_mapping)
                
        return final_results

    def _merge_results_multi_agent(self, final_results, batch_results):
        for agent_id, inputs_map in batch_results.items():
            if agent_id not in final_results:
                final_results[agent_id] = {}
            
            for input_name, partitions in inputs_map.items():
                if input_name not in final_results[agent_id]:
                    final_results[agent_id][input_name] = []
                final_results[agent_id][input_name].extend(partitions)

    def _map_batch_multi_agent(self, agents: List[Dict[str, str]], partitions: List[FilePartition]) -> Dict[str, Dict[str, List[FilePartition]]]:
        # Prepare agents info
        agents_info = []
        for agent in agents:
            agents_info.append(f"Agent ID: {agent['id']}\nName: {agent['name']}\nInputs: {agent['inputs']}\n---")
        agents_text = "\n".join(agents_info)

        # Prepare partitions info
        partitions_info = []
        for i, p in enumerate(partitions):
            partitions_info.append(f"ID: {i}\nFile: {p.filename}\nPartition: {p.partition_id}\nSummary: {p.summary}\n---")
        partitions_text = "\n".join(partitions_info)
        
        prompt = f"""
You are a smart context manager responsible for mapping file data to agent inputs.

Task: Map available file partitions to the required inputs for MULTIPLE agents.

Agents and Requirements:
{agents_text}

Available File Partitions (Current Batch):
{partitions_text}

Instructions:
1. For EACH agent, analyze their 'Required Inputs' (the curly-brace placeholders like {{questionnaire_context}}).
2. Understand the purpose of each input in the context of the agent's role/name.
3. Scan the 'Available File Partitions' to find matches using these strategies (in priority order):

   a) EXACT NAME MATCH: If the input name matches (or closely matches) a filename, map it.
      - Example: Input "{{questionnaire_context}}" → file "questionnaire_context.csv" → MATCH
      - Example: Input "{{metadata_mapping_context}}" → file with "metadata" or "mapping" in name → MATCH

   b) SEMANTIC MATCH: Match the INTENT of the input with the CONTENT/SUMMARY of the file.
      - Example: "Project Charter" → files containing project scope, goals, charter documents
      - Example: "Source DDL" → SQL files with CREATE TABLE statements
      - Example: "ETL Inventory" → Excel/CSV files listing ETL jobs or mappings

   c) CONTEXTUAL MATCH: If the agent's role suggests it needs certain data, map relevant files.
      - Example: A "Business Analyst" agent likely needs questionnaire/requirements files
      - Example: A "Data Engineer" agent likely needs schema/DDL/mapping files

4. Be precise but flexible. If a file is clearly relevant to an input (even if the name isn't an exact match), include it.

5. DEPENDENCY-AWARE AGENTS: Some agents have inputs like "{{user_story_draft_markdown}}" or "{{previous_agent_output}}"
   that refer to the OUTPUT of another agent, NOT a file. For these inputs:
   - Do NOT map any file partitions to them.
   - Leave that agent's mapping empty if ALL its inputs are outputs from other agents.
   - This is correct behavior — these agents receive context at execution time, not from files.

6. Return a JSON object with the mapping.
   - Keys must be the EXACT Agent IDs from the 'Agents and Requirements' section.
   - Do NOT use placeholder IDs like "AGENT_ID_1" unless that is the actual ID.
   - Include ALL agent IDs in the response, even if they have empty mappings.

Policy (Very Important):
Play it SAFE — false positives are acceptable, but false negatives (missing relevant files) are not.
When in doubt, map the file. It is better to include a possibly irrelevant file than to miss a relevant one.

Special Rule for Data Files (CRITICAL — do not skip):
If an agent's inputs contain a generic data container such as {{sample_data_files}}, {{datasets}},
{{data_sources}}, {{raw_data}}, {{input_data}}, or any similar plural/generic data holder,
you MUST map EVERY available file of the same type (e.g., ALL CSV files) to that input.
- NEVER selectively include some CSV files while excluding others when a generic input is present.
- Example: 4 CSV files available + agent has {{sample_data_files}} → map ALL 4 CSV IDs to sample_data_files.
- Omitting even one file of the same type is a critical error.

Format:
{{
    "mappings": {{
        "ACTUAL_AGENT_ID": {{
            "Input Name A": [0, 2],
            "Input Name B": [5]
        }},
        "ANOTHER_AGENT_ID": {{}}
    }}
}}

Return ONLY the JSON.
"""
        response_text = "None (Exception occurred before response)"
        try:
            completion = get_llm_completion(
                prompt=prompt,
                tags=build_llm_tags(component="smart_context_manager"),
                model=get_core_agent_model("smart_context_manager"),
            )
            response_text = str(completion.get("text") or "")
            self._record_batch_usage(prompt, completion)

            response_text = response_text.strip()
            if response_text.startswith("```json"):
                response_text = response_text[7:]
            if response_text.startswith("```"):
                response_text = response_text[3:]
            if response_text.endswith("```"):
                response_text = response_text[:-3]
            
            # logger.debug(f"LLM Mapping Response Raw: {response_text[:300]}...")
            
            mapping_data = json.loads(response_text)
            
            # Process result
            result = {}
            raw_mappings = mapping_data.get("mappings", {})
            
            if not raw_mappings:
                 logger.warning(f"LLM returned valid JSON but empty 'mappings' key. Full response: {response_text}")

            for agent_id, inputs_map in raw_mappings.items():
                result[agent_id] = {}
                for input_name, indices in inputs_map.items():
                    selected_partitions = []
                    for idx in indices:
                        if 0 <= idx < len(partitions):
                            selected_partitions.append(partitions[idx])
                        else:
                            logger.warning(f"LLM returned invalid partition index {idx} for agent {agent_id}. Max index: {len(partitions)-1}")
                    result[agent_id][input_name] = selected_partitions
            
            return result

        except Exception as e:
            logger.error(f"Error in multi-agent mapping batch: {e}")
            logger.error(f"Failed Response Text: {response_text}")
            return {}

class SmartContextManager:
    def __init__(self, inputs_dir: str):
        self.inputs_dir = inputs_dir
        self.converter = FileToJsonConverter()
        self.partitioner = FilePartitioner(converter=self.converter)
        self.mapper = ContextMapper()
        # Simple keyword heuristics used as fallback when LLM mapping fails
        self._keyword_map = {
            'ddl|sql|schema|table|view|proc|function': lambda p: (
                p.filename.lower().endswith('.sql') or 'sql' in p.summary.lower() or p.metadata.get('language') == 'sql'
            ),
            'excel|xlsx|sheet|workbook|csv|tabular|table|sample_data|data_files|datasets': lambda p: (
                p.metadata.get('type') in ['excel_sheet', 'tabular'] or p.filename.lower().endswith(('.xlsx', '.xls', '.csv'))
            ),
            'docx|word|document|section|charter|brd|srs|sow': lambda p: (
                p.metadata.get('type') in ['docx_section', 'text_section'] or p.filename.lower().endswith('.docx')
            ),
            'jil|autosys|job': lambda p: (
                'jil' in p.summary.lower() or p.filename.lower().endswith('.jil')
            ),
            'xml|workflow|mapping': lambda p: (
                p.filename.lower().endswith('.xml') or 'xml' in p.summary.lower()
            ),
            'python|py|script|function|class': lambda p: (
                p.filename.lower().endswith('.py') or p.metadata.get('language') == 'python'
            ),
            'file_path|file_paths|source_file|source_code|etl|talend|informatica|pyspark|snowpark|sttm|code|mapping': lambda p: (
                p.filename.lower().endswith(
                    ('.cs', '.java', '.js', '.ts', '.jsx', '.tsx', '.go', '.rb',
                     '.php', '.c', '.cpp', '.h', '.hpp', '.py', '.scala', '.sql', '.xml', '.json')
                )
            ),
            'checklist|guideline|standard|policy|best practice': lambda p: (
                any(k in p.summary.lower() for k in ['checklist','guideline','standard','policy','best practice'])
            ),
            'interview|meeting|transcript': lambda p: (
                 any(k in p.filename.lower() for k in ['interview','meeting','transcript']) or
                 any(k in p.summary.lower() for k in ['interview','meeting','transcript'])
            ),
            'stakeholder|feedback': lambda p: (
                 any(k in p.filename.lower() for k in ['stakeholder','feedback']) or
                 any(k in p.summary.lower() for k in ['stakeholder','feedback'])
            ),
            'requirement|specification|brd': lambda p: (
                 any(k in p.filename.lower() for k in ['requirement','specification','brd']) or
                 any(k in p.summary.lower() for k in ['requirement','specification','brd'])
            ),
            'tableau|bi|dashboard|workbook|report|visualization': lambda p: (
                p.filename.lower().endswith(('.twbx', '.twb')) or
                any(k in p.summary.lower() for k in ['tableau', 'dashboard', 'workbook'])
            ),
        }

    def get_mapping_token_usage(self) -> Dict[str, int]:
        return {
            "prompt_tokens": int(self.mapper.token_usage.get("prompt_tokens") or 0),
            "completion_tokens": int(self.mapper.token_usage.get("completion_tokens") or 0),
            "total_tokens": int(self.mapper.token_usage.get("total_tokens") or 0),
            "model": str(self.mapper.token_usage.get("model") or "").strip(),
            "provider": str(self.mapper.token_usage.get("provider") or "").strip(),
        }

    def _get_full_file_content(self, file_path: str) -> str:
        """
        Return the complete raw content of a file for validation agents.
        This bypasses partitioning to ensure the agent receives the entire file.
        Enhanced for SQL files to preserve structure for multi-layered lineage analysis.
        """
        try:
            filename = os.path.basename(file_path)
            
            # For SQL files - critical for data lineage with multi-layer views
            if file_path.lower().endswith('.sql'):
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                # Provide structured context for SQL
                sql_context = {
                    "file_name": filename,
                    "file_type": "sql_script",
                    "purpose": "Complete SQL content for multi-layered data lineage analysis",
                    "content": content,
                    "note": "Full SQL file provided - includes all CTEs, views, tables, and dependencies"
                }
                return json.dumps(sql_context, indent=2, ensure_ascii=False)
            
            # For other text-based files (Python, XML, etc.)
            text_extensions = ['.py', '.txt', '.jil', '.xml', '.json', '.csv']
            if any(file_path.lower().endswith(ext) for ext in text_extensions):
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                return content
            
            # For structured files (Excel, etc.), use the converter but return full JSON
            file_data = self.converter.convert_file_to_json(file_path)
            if file_data:
                return json.dumps(file_data, indent=2, default=str)
            
            return f"Unable to extract content from {filename}"
            
        except Exception as e:
            logger.error(f"Error reading full file content from {file_path}: {e}")
            return f"Error reading file: {str(e)}"

    def _fallback_match_partitions(self, agent_inputs: str, partitions: List[FilePartition], max_per_type: int = 5) -> List[FilePartition]:
        """Heuristic fallback: select relevant partitions using keyword rules only; if none, return empty."""
        if not partitions:
            return []
        text = (agent_inputs or '').lower()
        selected: List[FilePartition] = []
        seen_keys = set()

        # Apply keyword groups; only use results when a pattern matches agent inputs
        for pattern, predicate in self._keyword_map.items():
            try:
                if re.search(pattern, text):
                    matches = [p for p in partitions if predicate(p)]
                    # Keep unique by (file, partition_id)
                    for p in matches[:max_per_type]:
                        key = (p.file_path, p.partition_id)
                        if key not in seen_keys:
                            selected.append(p)
                            seen_keys.add(key)
            except Exception:
                continue

        # If no keyword matched, return empty list so context mapper can skip this agent
        if not selected:
            return []

        return selected

    def get_context_for_multiple_agents(self, agents: List[Dict[str, str]], files_to_process: Optional[List[str]] = None) -> Dict[str, str]:
        """
        Get context for a list of agents efficiently.
        Returns: { agent_id: context_string }
        """
        # 1. Load and partition all files (once)
        all_partitions = []
        input_files = []
        
        if files_to_process:
            # Clean up empty strings and filter out non-existent files
            clean_files = [f for f in files_to_process if f and f.strip()]
            logger.info(f"Filtering inputs to specific files: {clean_files}")
            
            for fname in clean_files:
                # Construct path
                if os.path.isabs(fname):
                    file_path = fname
                else:
                    file_path = os.path.join(self.inputs_dir, fname)
                
                if os.path.exists(file_path):
                    input_files.append(file_path)
                else:
                    # Try fuzzy match (helpful if UI sends names without extensions or with different casing)
                    basename = os.path.basename(fname)
                    matches = [
                        os.path.join(self.inputs_dir, f) 
                        for f in os.listdir(self.inputs_dir) 
                        if f.lower().startswith(basename.lower().split('.')[0])
                    ]
                    if matches:
                        input_files.extend(matches)
                        logger.info(f"Fuzzy matched {fname} to {matches}")
                    else:
                        logger.warning(f"File not found: {file_path}")
            
            # Remove duplicates
            input_files = list(set(input_files))
        else:
            if os.path.exists(self.inputs_dir):
                extensions = {'.xlsx', '.xls', '.txt', '.pdf', '.docx', '.csv', '.md',
                            '.py', '.sql', '.jil', '.xml', '.json',
                            '.cs', '.java', '.js', '.ts', '.jsx', '.tsx',  # Source-code formats
                            '.go', '.rb', '.php', '.c', '.cpp', '.h', '.hpp',
                            '.twbx', '.twb',  # Tableau formats
                            '.pbip', '.pbit', '.pbix',  # Power BI formats
                            '.zip'}  # Archives
                for ext in extensions:
                    input_files.extend(glob.glob(os.path.join(self.inputs_dir, f"*{ext}")))
        
        # Validation: Ensure we have files to process
        if not input_files:
            msg = f"No input files found in {self.inputs_dir}"
            if files_to_process:
                msg = f"None of the requested files were found in {self.inputs_dir}: {files_to_process}"
            logger.error(msg)
            raise FileNotFoundError(msg)
            
        logger.info(f"SCM (Smart Context Manager): Found {len(input_files)} input files to process: {[os.path.basename(f) for f in input_files]}")

        for file_path in input_files:
            try:
                # Check for system files to skip (requirements.txt, README, etc.)
                filename = os.path.basename(file_path).lower()
                if filename == "requirements.txt":
                    logger.info(f"SCM: Skipping system file: {filename}")
                    continue
                    
                file_data = self.converter.convert_file_to_json(file_path)
                if file_data:
                    partitions = self.partitioner.partition_file(file_path, file_data)
                    logger.info(f"SCM: Validating file '{os.path.basename(file_path)}' -> {len(partitions)} partitions generated.")
                    all_partitions.extend(partitions)
                else:
                    logger.warning(f"SCM: converted file_data is empty for {file_path}")
            except Exception as e:
                logger.error(f"Error processing file {file_path}: {e}")

        logger.info(f"SCM: Total partitions generated from all files: {len(all_partitions)}")

        # 2. Map context for all agents
        mapped_results = {}
        try:
            mapped_results = self.mapper.map_context_multi_agent(agents, all_partitions)
            
            # Detailed logging of mapping results
            for agent in agents:
                aid = agent['id']
                aname = agent['name']
                amap = mapped_results.get(aid, {})
                total_mapped = sum(len(p_list) for p_list in amap.values())
                if total_mapped == 0:
                    logger.warning(f"SCM: Agent '{aname}' (ID: {aid}) mapped to 0 partitions via LLM.")
                else:
                    logger.info(f"SCM: Agent '{aname}' (ID: {aid}) mapped to {total_mapped} partitions. Inputs covered: {list(amap.keys())}")
                    
        except Exception as e:
            logger.error(f"LLM mapping failed catastrophically: {e}")
            raise
        
        # 3. Construct final context strings
        final_contexts = {}
        for agent in agents:
            agent_id = agent['id']
            agent_name = agent.get('name', agent_id)
            agent_map = mapped_results.get(agent_id, {}) if mapped_results else {}
            full_context_mode = agent.get('full_context_mode', False)
            
            # Check if agent is "starved" (has 0 partitions mapped)
            # We want to ensure "Recall" safety: if matching failed completely, fallback to EVERYTHING.
            # This aligns with the imperative that "all agents get selected" / get context.
            partition_count = sum(len(parts) for parts in agent_map.values())
            is_starved = (partition_count == 0)

            # FULL CONTEXT MODE: For validation agents, provide complete files instead of partitions
            # IMPORTANT: For full_context_mode, provide files even if starved (no LLM mapping)
            if full_context_mode:
                logger.info(f"SCM: Agent '{agent_name}' (ID: {agent_id}) requires FULL CONTEXT MODE. Bypassing partitioning.")
                
                # Collect unique file paths from mapped partitions (if any)
                relevant_files = set()
                if not is_starved:
                    for input_name, partitions in agent_map.items():
                        for p in partitions:
                            relevant_files.add(p.file_path)
                else:
                    # If starved (no LLM mapping), include ALL input files
                    # This is critical for data lineage - we need all SQL/data files
                    logger.warning(f"SCM: Agent '{agent_name}' is starved but requires full_context_mode. Including ALL input files.")
                    relevant_files = set(input_files)
                
                # Build full file context
                full_file_context = {}
                TABULAR_EXTS = {'.csv', '.xlsx', '.xls', '.parquet'}

                for file_path in sorted(relevant_files):
                    filename = os.path.basename(file_path)
                    ext = os.path.splitext(filename)[1].lower()
                    
                    if ext in TABULAR_EXTS:
                        logger.warning(f"SCM: File {filename} is tabular data. Bypassing raw text mode and using data profiles instead to prevent context overload.")
                        
                        # Extract the already generated profiles from partitions
                        file_parts = []
                        is_logic_file = False
                        
                        for p in all_partitions:
                            if p.file_path == file_path:
                                # to_dict() only has metadata/summary. We must manually append 'content' containing the rows.
                                p_data = p.to_dict()
                                p_data["content"] = p.content 
                                file_parts.append(p_data)
                                
                                # Detect if the partitioner recognized this as STTM/Logic to give a better label
                                if "Logic Table: Yes" in p.summary or "Logic: Yes" in p.summary or "mapping" in p.partition_id.lower() or "Logic" in p.summary and "Logic: No" not in p.summary and "Logic Table: No" not in p.summary:
                                    is_logic_file = True

                        full_file_context[filename] = {
                            "Type": "Tabular Logic Data (STTM)" if is_logic_file else "Tabular Data Profile",
                            "Purpose": "All logic/mapping rows preserved in structured JSON chunks." if is_logic_file else "Tabular data is never injected raw; using semantic data profiles and sample rows.",
                            "Content": file_parts
                        }
                    else:
                        full_content = self._get_full_file_content(file_path)
                        full_file_context[filename] = {
                            "Type": "Complete File Content",
                            "Purpose": "Full file provided for comprehensive validation/lineage analysis",
                            "Content": full_content
                        }
                
                final_context_string = json.dumps(full_file_context, indent=2, default=str)
                final_contexts[agent_id] = final_context_string
                logger.info(f"SCM: Full context for validation agent {agent_id}: {len(final_context_string)} chars from {len(relevant_files)} complete file(s).")
                continue  # Skip partition-based processing for this agent

            # PARTITION-BASED MODE: Standard processing for non-validation agents
            # Invert mapping: Partition -> Inputs to avoid duplication
            partition_to_inputs = {}

            if is_starved:
                # Check if this agent's inputs are all references to other agents' outputs
                # (e.g., {user_story_draft_markdown} which is AGENT_1's output, not a file)
                agent_inputs_str = agent.get('inputs', '')
                depends_on = agent.get('depends_on', '')

                # Heuristic: if agent has depends_on or its inputs don't match any filename pattern,
                # it's likely a downstream/action agent waiting for runtime context
                is_dependent_agent = bool(depends_on and depends_on.strip() and depends_on.strip() != '[]')

                if is_dependent_agent:
                    logger.info(
                        f"SCM: Agent '{agent.get('name', agent_id)}' (ID: {agent_id}) is a dependent agent "
                        f"(depends_on: {depends_on}). Its inputs are generated at runtime by upstream agents. "
                        f"Skipping file-based context mapping."
                    )
                    context_dict = {
                        "_context_status": {
                            "status": "pending",
                            "reason": f"This agent depends on [{depends_on}]. Its context will be generated at execution time from the output of upstream agent(s).",
                            "agent_inputs": agent_inputs_str,
                            "depends_on": depends_on,
                        }
                    }
                    final_context_string = json.dumps(context_dict, indent=2, default=str)
                    final_contexts[agent_id] = final_context_string
                    logger.info(f"SCM: Final context for dependent agent {agent_id}: pending (awaiting upstream output).")
                    continue

                # Non-dependent but starved — try heuristic safety net
                logger.warning(
                    f"SCM: Agent '{agent.get('name', agent_id)}' (ID: {agent_id}) is STARVED (0 partitions). "
                    f"Attempting heuristic safety-net mapping based on input keywords."
                )

                # Heuristic safety net: try to match partitions purely based on
                # the agent's declared inputs. This mirrors the Tier 2
                # correction we use for non-starved agents.
                fallback_parts = self._fallback_match_partitions(agent.get('inputs', ''), all_partitions)
                heuristic_added_count = 0
                for p in fallback_parts:
                    p_key = (p.file_path, p.partition_id)
                    if p_key not in partition_to_inputs:
                        partition_to_inputs[p_key] = {
                            'partition': p,
                            'inputs': set(['fallback_context (safety net)'])
                        }
                        heuristic_added_count += 1

                if heuristic_added_count > 0:
                    logger.info(
                        f"SCM: Heuristic safety net added {heuristic_added_count} partitions "
                        f"for starved agent {agent_id}."
                    )
                else:
                    logger.warning(
                        f"SCM: Heuristic safety net also found 0 partitions for agent {agent_id}; "
                        f"this agent will receive a no-context message."
                    )
                    context_dict = {
                        "_context_status": {
                            "status": "no_context",
                            "reason": f"No relevant files were found for this agent's inputs ({agent.get('inputs', 'N/A')}). "
                                      f"Ensure the input directory contains files matching the agent's expected data.",
                            "agent_inputs": agent.get('inputs', ''),
                        }
                    }
                    final_context_string = json.dumps(context_dict, indent=2, default=str)
                    final_contexts[agent_id] = final_context_string
                    continue
            else:
                # Normal processing for mapped agents
                for input_name, partitions in agent_map.items():
                    if not partitions:
                        continue
                    for p in partitions:
                        p_key = (p.file_path, p.partition_id)
                        if p_key not in partition_to_inputs:
                            partition_to_inputs[p_key] = {'partition': p, 'inputs': set()}
                        partition_to_inputs[p_key]['inputs'].add(input_name)

                # 2. Heuristic Fallback (Restored & Augmented)
                # Try to find missed connections using keyword matching on the agent's inputs string.
                # This acts as a Tier 2 correction for mapped agents who might have missed specific files.
                fallback_parts = self._fallback_match_partitions(agent.get('inputs', ''), all_partitions)
                heuristic_added_count = 0
                for p in fallback_parts:
                    p_key = (p.file_path, p.partition_id)
                    if p_key not in partition_to_inputs:
                        partition_to_inputs[p_key] = {'partition': p, 'inputs': set(['heuristic_match'])}
                        heuristic_added_count += 1
                
                if heuristic_added_count > 0:
                    logger.info(f"SCM: Heuristics added {heuristic_added_count} partitions for agent {agent_id} (Tier 2 correction).")

                # 2.5. CSV Completeness Check
                # If this agent already has ≥1 CSV partition in context, ensure ALL uploaded CSV
                # files are also included. This prevents LLM mappings from silently omitting
                # individual files (e.g., Transportation 1.csv omitted while the others are present).
                mapped_csv_keys = [
                    key for key, entry in partition_to_inputs.items()
                    if entry['partition'].filename.lower().endswith('.csv')
                ]
                if mapped_csv_keys:
                    # Determine the input label already used for other CSV files
                    # (prefer a real label over the synthetic 'heuristic_match' tag)
                    csv_input_label = 'sample_data_files'
                    for key in mapped_csv_keys:
                        for lbl in partition_to_inputs[key]['inputs']:
                            if lbl not in ('heuristic_match', 'fallback_context (safety net)'):
                                csv_input_label = lbl
                                break

                    csv_completeness_added = 0
                    for p in all_partitions:
                        if p.filename.lower().endswith('.csv'):
                            p_key = (p.file_path, p.partition_id)
                            if p_key not in partition_to_inputs:
                                partition_to_inputs[p_key] = {
                                    'partition': p,
                                    'inputs': set([csv_input_label])
                                }
                                csv_completeness_added += 1

                    if csv_completeness_added > 0:
                        logger.warning(
                            f"SCM: CSV Completeness Fix — added {csv_completeness_added} missing CSV "
                            f"file(s) for agent '{agent.get('name', agent_id)}' (ID: {agent_id}). "
                            f"These were silently omitted by LLM mapping. "
                            f"Mapped to input slot: '{csv_input_label}'."
                        )

            # 3. Tier 3: Unmatched Files Inventory (New)
            # Identify files that are included in the detailed context
            included_filenames = set()
            for entry in partition_to_inputs.values():
                included_filenames.add(entry['partition'].filename)
            
            unmatched_inventory = []
            seen_unmatched_files = set()

            # Scan all partitions to find files that were NOT included in the detailed context
            for p in all_partitions:
                if p.filename not in included_filenames and p.filename not in seen_unmatched_files:
                     # Add brief summary of available but unused file
                     unmatched_inventory.append({
                         "filename": p.filename,
                         "summary_preview": p.summary[:200].replace('\n', ' ') + "..." if p.summary else "No summary"
                     })
                     seen_unmatched_files.add(p.filename)

            # Build context JSON
            context_dict = {}
            
            # Sort partitions for deterministic output (e.g., by filename)
            sorted_keys = sorted(partition_to_inputs.keys(), key=lambda k: k[0])

            for key in sorted_keys:
                entry = partition_to_inputs[key]
                p = entry['partition']
                inputs = sorted(list(entry['inputs']))
                
                # Group partitions by filename
                if p.filename not in context_dict:
                    context_dict[p.filename] = []

                context_dict[p.filename].append({
                    "Partition": p.partition_id,
                    "Relevant to Inputs": ", ".join(inputs),
                    "Content": p.content 
                })
            
            # Inject Usage/Unmatched Inventory
            if unmatched_inventory:
                context_dict["_available_but_unmapped_files"] = {
                    "note": "These files exist in the workspace but were not mapped to specific inputs. Use this list to identify missing information.",
                    "files": unmatched_inventory
                }

            # Use default=str to handle non-serializable objects in content (e.g. dates, sets)
            final_context_string = json.dumps(context_dict, indent=2, default=str)
            final_contexts[agent_id] = final_context_string
            logger.info(f"SCM: Final context for agent {agent_id}: {len(final_context_string)} chars via {len(sorted_keys)} partitions.")
            
        return final_contexts


if __name__ == "__main__":
    """
    Minimal harness for safe, side-effect-free sanity checks.
    - By default, lists detected input files and basic partition counts without calling the LLM.
    - Use `--run-mapping` to exercise mapping (will initialize the LLM client).
    """
    import argparse
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(description="SmartContextManager sanity runner")
    parser.add_argument(
        "--inputs",
        default=os.path.join(os.getcwd(), "Inputs"),
        help="Path to inputs directory (default: ./Inputs)",
    )
    parser.add_argument(
        "--run-mapping",
        action="store_true",
        help="Run LLM-based context mapping (may require env configuration)",
    )
    parser.add_argument(
        "--agent-name",
        default="TestAgent",
        help="Agent name for mapping when --run-mapping is set",
    )
    parser.add_argument(
        "--agent-inputs",
        default="Project Charter; Source DDL; ETL Inventory",
        help="Comma/semicolon-separated inputs description for mapping",
    )

    args = parser.parse_args()

    # Fast path: enumerate files and partition without touching the LLM
    converter = FileToJsonConverter()
    partitioner = FilePartitioner(converter=converter)

    input_files = []
    if os.path.exists(args.inputs):
        extensions = [
            ".xlsx", ".xls", ".txt", ".pdf", ".docx", ".csv",
            ".py", ".sql", ".jil", ".xml", ".json",
            ".twbx", ".twb",
            ".pbip", ".pbit", ".pbix",
            ".zip",
        ]
        for ext in extensions:
            input_files.extend(glob.glob(os.path.join(args.inputs, f"*{ext}")))

    print(f"[SANITY] Inputs dir: {args.inputs}")
    print(f"[SANITY] Files detected: {len(input_files)}")

    total_partitions = 0
    for fp in input_files:
        try:
            data = converter.convert_file_to_json(fp)
            if not data:
                continue
            parts = partitioner.partition_file(fp, data)
            total_partitions += len(parts)
        except Exception as e:
            print(f"[WARN] Failed processing {os.path.basename(fp)}: {e}")

    print(f"[SANITY] Total partitions created (no LLM): {total_partitions}")

    if args.run_mapping:
        # Only now create the full manager (will initialize LLM client)
        scm = SmartContextManager(inputs_dir=args.inputs)
        context = scm.get_context_for_agent(
            agent_name=args.agent_name,
            agent_inputs=args.agent_inputs,
        )
        # Print just a small preview to avoid flooding stdout
        preview = "\n".join(context.splitlines()[:50])
        print("[MAPPING] Context preview (first 50 lines):\n" + preview)