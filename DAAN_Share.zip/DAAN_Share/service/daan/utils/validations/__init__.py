"""Validations utilities."""
