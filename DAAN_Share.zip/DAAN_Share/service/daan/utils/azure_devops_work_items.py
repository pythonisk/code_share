"""Parsing helpers for Azure DevOps work-item tool output.

Both the execution layer and the display layer need to read the work items out
of the raw output returned by the Azure DevOps tools. Keeping the parsing in one
place ensures both layers interpret that output the same way.
"""

from __future__ import annotations

import json
from typing import Any


def _try_json(value: Any) -> Any:
    if not isinstance(value, str):
        return None
    text = value.strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except (json.JSONDecodeError, ValueError):
        return None


def extract_azure_devops_work_items(obj: Any) -> list[dict[str, Any]]:
    """Return the unique Azure DevOps work items found in a tool payload.

    Accepts a single payload or a list of payloads. It unwraps the common
    wrapper shapes the tools return, keeps only real work items, drops
    duplicates, and preserves their original order. Returns an empty list when
    there are none.
    """
    work_items: list[dict[str, Any]] = []
    seen_ids: set[Any] = set()

    def _add(candidate: Any) -> bool:
        if not (isinstance(candidate, dict) and "id" in candidate and isinstance(candidate.get("fields"), dict)):
            return False
        if not any(str(k).startswith("System.") for k in candidate["fields"].keys()):
            return False
        wid = candidate.get("id")
        if wid not in seen_ids:
            seen_ids.add(wid)
            work_items.append(candidate)
        return True

    def _walk(node: Any) -> None:
        if _add(node):
            return
        if isinstance(node, dict):
            # Some responses wrap the real data as JSON text — parse it and continue.
            if node.get("type") == "text" and isinstance(node.get("text"), str):
                parsed = _try_json(node["text"])
                if parsed is not None:
                    _walk(parsed)
                return
            # Some responses group several items in a list — unwrap each one.
            if "id" not in node and isinstance(node.get("value"), list):
                for entry in node["value"]:
                    body = entry.get("body") if isinstance(entry, dict) else None
                    if isinstance(body, str):
                        parsed = _try_json(body)
                        if parsed is not None:
                            _walk(parsed)
                    elif isinstance(body, dict):
                        _walk(body)
                    elif isinstance(entry, dict):
                        _walk(entry)
                return
            return
        if isinstance(node, list):
            for element in node:
                _walk(element)

    _walk(obj)
    return work_items
