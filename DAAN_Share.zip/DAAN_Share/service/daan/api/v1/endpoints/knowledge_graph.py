"""Knowledge Graph – consolidated API endpoints.

Minimal surface:
  /graph                              – full graph visualization
  /graph/session/{session_id}         – session subgraph
  /output/{session_id}                – structured session output contract
    /                                   – natural language query runner (NL -> Cypher, read-only)
  /stats                              – node/edge counts
"""

from __future__ import annotations

import logging
from datetime import date, datetime
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import or_

from daan.admin.user_service import authenticate_user
from daan.core.dependencies import get_current_active_user, require_admin
from daan.core.database import get_db
from daan.knowledge_graph import close_kg_connection, get_kg_connection
from daan.knowledge_graph.connection import get_kg_db_path
from daan.knowledge_graph import queries
from daan.knowledge_graph.graph_export import (
    export_full_graph,
    export_session_subgraph,
)
from daan.flow.session_service import (
    delete_session_dir,
    read_session_file,
    read_run_deliverables,
    read_context_map_output,
    write_context_map_output,
    write_agent_output,
    write_feedback_text,
    write_quality_output,
    write_reporter_output,
    write_refinement_output,
    write_agent_proposal,
    read_agent_proposal,
    delete_agent_proposal,
    list_agent_proposals,
    read_agent_score,
    REPORTER_OUTPUT_FILENAME,
    QUALITY_OUTPUT_FILENAME,
    REFINEMENT_OUTPUT_FILENAME,
)
from daan.models.archetype import Agent as AgentModel, UseCase as UseCaseModel
from daan.models.archetype import UseCaseAgentMapping as UseCaseAgentMapModel
from daan.knowledge_graph.query_executor import DEFAULT_MAX_ROWS, convert_nl_to_cypher, execute_cypher

logger = logging.getLogger(__name__)


def _selected_learning_history_from_context(
    context_map: dict[str, Any],
    *,
    agent_id: str | None = None,
) -> list[dict[str, str]]:
    """Return the current selected learning-history items from session config."""
    target_agent_id = str(agent_id or "").strip()
    items: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for agent in (context_map.get("agents") or []):
        if not isinstance(agent, dict):
            continue
        current_agent_id = str(agent.get("agent_id") or "").strip()
        if target_agent_id and current_agent_id != target_agent_id:
            continue
        for entry in (agent.get("applied_learning_history") or []):
            if not isinstance(entry, dict):
                continue
            feedback_id = str(entry.get("feedback_id") or "").strip()
            comment = str(entry.get("comment") or "").strip()
            if not comment:
                continue
            key = (current_agent_id, feedback_id or comment.casefold())
            if key in seen:
                continue
            seen.add(key)
            items.append({
                "agent_id": current_agent_id,
                "feedback_id": feedback_id,
                "comment": comment,
            })
    return items


def _learning_history_from_session_artifacts(
    conn,
    session_ids: list[str],
    *,
    agent_id: str,
) -> list["LearningHistoryItem"]:
    """Build agent-specific learning history from persisted session artifacts.

    Disk artifacts are the authoritative source for which agent a feedback item
    actually modified. This avoids polluted KG feedback edges from older broad
    chat-rerun logic.
    """
    target_agent_id = str(agent_id or "").strip()
    if not target_agent_id:
        return []

    items: list[LearningHistoryItem] = []
    seen: set[tuple[str, str, str]] = set()

    def _history_item_id(
        *,
        session_id: str,
        current_agent_id: str,
        source_kind: str,
        raw_feedback_id: str,
        comment: str,
        seq: int = 0,
    ) -> str:
        base = str(raw_feedback_id or "").strip()
        normalized_comment = comment.casefold()
        if source_kind == "feedback":
            return f"artifact:{session_id}:{current_agent_id}:feedback:{seq}:{normalized_comment}"
        if base:
            return f"artifact:{session_id}:{current_agent_id}:learning:{base}"
        return f"artifact:{session_id}:{current_agent_id}:learning:{normalized_comment}"

    for sid in session_ids:
        session_meta = queries.get_session_meta(conn, sid) or {}
        started_at = str(session_meta.get("started_at") or "")

        for deliverable in read_run_deliverables(sid):
            current_agent_id = str(deliverable.get("agent_id") or "").strip()
            if current_agent_id != target_agent_id:
                continue
            for feedback in (deliverable.get("feedback") or []):
                comment = str(feedback.get("feedback_text") or "").strip()
                if not comment:
                    continue
                seq = int(feedback.get("seq") or 0)
                key = (sid, current_agent_id, comment.casefold())
                if key in seen:
                    continue
                seen.add(key)
                items.append(LearningHistoryItem(
                    feedback_id=_history_item_id(
                        session_id=sid,
                        current_agent_id=current_agent_id,
                        source_kind="feedback",
                        raw_feedback_id="",
                        comment=comment,
                        seq=seq or 0,
                    ),
                    session_id=sid,
                    agent_id=current_agent_id,
                    comment=comment,
                    source="chat",
                    created_at=started_at,
                ))

    items.sort(key=lambda item: (item.created_at, item.session_id, item.feedback_id), reverse=True)
    return items
router = APIRouter()


def _is_admin(current_user: object) -> bool:
    role = getattr(current_user, "role", None)
    return str(getattr(role, "name", "") or "").strip().casefold() == "admin"


def _parse_quality_score(text: str) -> float | None:
    """Best-effort extraction of a leading numeric quality score from text."""
    import re

    match = re.search(r"\d+(?:\.\d+)?", str(text or ""))
    if not match:
        return None
    try:
        return float(match.group(0))
    except ValueError:
        return None


def _session_owner_username(conn, session_id: str) -> str:
    """Return the username that created the session (via INITIATED edge), or ''."""
    try:
        res = conn.execute(
            "MATCH (u:User)-[:INITIATED]->(s:Session) WHERE s.id = $sid RETURN u.username AS username LIMIT 1",
            {"sid": session_id},
        )
        if res.has_next():
            return str(res.get_next()[0] or "").strip()
    except Exception:
        logger.debug("owner lookup failed for %s", session_id, exc_info=True)
    return ""


def _require_session_access(conn, session_id: str, current_user: object) -> None:
    """Row-level access guard: only the run's owner or an admin may proceed.

    Raises HTTP 403 otherwise. Sessions with no recorded owner (legacy runs)
    are treated as private and are only visible to admins, matching the
    run-history scoping.
    """
    if _is_admin(current_user):
        return
    owner_username = _session_owner_username(conn, session_id)
    requester = str(getattr(current_user, "username", "") or "").strip()
    if owner_username and owner_username == requester:
        return
    raise HTTPException(
        status_code=403,
        detail="You do not have access to this run.",
    )



def _normalize_agent_type(value: str | None) -> str:
    raw = str(value or "").strip().casefold()
    if raw == "action_agent" or "action" in raw:
        return "action_agent"
    return "dynamic_agent"


def _resolve_usecase_from_agents(db: Session, agent_ids: list[str]) -> tuple[str, str] | tuple[None, None]:
    """Infer (usecase_id, usecase_name) from agent-to-usecase mapping in daan.db."""
    if not agent_ids:
        return (None, None)

    rows = (
        db.query(UseCaseAgentMapModel.usecase_id)
        .filter(UseCaseAgentMapModel.agent_id.in_(agent_ids))
        .all()
    )
    if not rows:
        return (None, None)

    counts: dict[str, int] = {}
    for row in rows:
        ucid = str(getattr(row, "usecase_id", "") or "").strip()
        if not ucid:
            continue
        counts[ucid] = counts.get(ucid, 0) + 1

    if not counts:
        return (None, None)

    best_usecase_id = max(counts, key=counts.get)
    usecase = (
        db.query(UseCaseModel)
        .filter(UseCaseModel.usecaseid == best_usecase_id)
        .first()
    )
    return (best_usecase_id, str(usecase.name or "").strip() if usecase else "")


# ── Response Schemas ────────────────────────────────────────────────────


class GraphNode(BaseModel):
    id: str
    label: str
    type: str
    properties: dict[str, Any] = {}


class GraphEdge(BaseModel):
    id: str
    source: str
    target: str
    label: str
    properties: dict[str, Any] = {}


class GraphData(BaseModel):
    nodes: list[GraphNode]
    edges: list[GraphEdge]


class GraphResponse(BaseModel):
    graph: GraphData
    stats: dict[str, int] = {}


class NLQRequest(BaseModel):
    question: str


class NLQResponse(BaseModel):
    question: str
    generated_cypher: str
    rows: list[dict[str, Any]]
    count: int
    summary: str


# ── Session Output Contract ────────────────────────────────────────────


class SessionInfo(BaseModel):
    session_id: str | None = None
    usecase_id: str | None = None
    usecase_name: str | None = None
    user_id: str | None = None
    status: str | None = None
    created_ts: str | datetime | date | None = None


class FeedbackRef(BaseModel):
    feedback_id: str | None = None
    type: str | None = None
    ref: str | None = None
    output_generated: str | None = None


class FeedbackOutputInfo(BaseModel):
    output_ref: str | None = None
    overall_score: float | None = None


class AgentOutputInfo(BaseModel):
    agent_id: str | None = None
    agent_name: str | None = None
    role: str | None = None
    agent_type: str | None = None
    timestamp: str | None = None
    output_generated: str | None = None
    overall_score: float | None = None
    feedback_id: str | None = None
    feedback: str | None = None
    outputs_after_feedback: list[FeedbackOutputInfo] = []


class SessionOutputResponse(BaseModel):
    session: SessionInfo
    agents: list[AgentOutputInfo] = []
    feedback: list[FeedbackRef] = []

    model_config = {
        "json_schema_extra": {
            "example": {
                "session": {
                    "session_id": "string",
                    "usecase_id": "string",
                    "usecase_name": "string",
                    "user_id": "string",
                    "status": "string",
                    "created_ts": "string"
                },
                "agents": [
                    {
                        "agent_id": "string",
                        "agent_name": "string",
                        "role": "string",
                        "agent_type": "string",
                        "timestamp": "string",
                        "output_generated": "string",
                        "overall_score": 0,
                        "feedback_id": "string",
                        "feedback": "string",
                        "outputs_after_feedback": [
                            {
                                "output_ref": "string",
                                "overall_score": 0
                            }
                        ]
                    }
                ],
                "feedback": [
                    {
                        "feedback_id": "string",
                        "type": "string",
                        "ref": "string",
                        "output_generated": "string"
                    }
                ]
            }
        }
    }


class KGCleanupAuthRequest(BaseModel):
    username_or_email: str = Field(min_length=3, max_length=255)
    password: str = Field(min_length=1, max_length=255)
    user_id: str = Field(min_length=1, max_length=50)


class RunHistoryItem(BaseModel):
    session_id: str
    role: str = ""
    usecase_id: str = ""
    usecase_name: str = ""
    status: str = ""
    quality_score: float | None = None
    started_at: str = ""


class RunHistoryResponse(BaseModel):
    archetype: str
    runs: list[RunHistoryItem] = []


class TraceSessionItem(BaseModel):
    session_id: str
    usecase: str = ""
    user: str = ""
    timestamp: str = ""


class RunFeedbackEntry(BaseModel):
    seq: int
    feedback_text: str = ""
    output: str = ""


class RunAgentDeliverable(BaseModel):
    agent_id: str
    agent_name: str = ""
    agent_type: str = "dynamic_agent"
    final_output: str = ""
    base_output: str = ""
    context: str = ""
    refined_prompt: str = ""
    # Raw persisted quality-score payload (score.json) for this agent, if any.
    # Lets the studio/run-history view restore the same score card shown when
    # the agent first ran. None when the agent was never scored.
    score: dict[str, Any] | None = None
    feedback: list[RunFeedbackEntry] = []


class AgentProposal(BaseModel):
    """A pending non-destructive suggested edit to an agent's output.

    ``current_output`` is what the run currently shows; ``proposed_output`` is
    the LLM-generated revision produced from the user's feedback and stored on
    disk as a draft. The proposal is promoted only when the client calls
    ``/proposals/keep``, or dropped by ``/proposals/discard``.
    """

    agent_id: str
    current_output: str = ""
    proposed_output: str = ""
    feedback_text: str = ""
    created_at: str = ""


class RunDetailResponse(BaseModel):
    session_id: str
    archetype: str = ""
    role: str = ""
    usecase_name: str = ""
    status: str = ""
    started_at: str = ""
    quality_score: float | None = None
    final_report_md: str = ""
    quality_report_md: str = ""
    refinement_output_md: str = ""
    agents: list[RunAgentDeliverable] = []
    proposals: list[AgentProposal] = []
    is_owner: bool = False
    is_admin: bool = False
    can_delete: bool = False


class SessionChatRequest(BaseModel):
    session_id: str = Field(min_length=1)
    question: str = Field(min_length=1, max_length=4000)
    # When set, feedback proposals are scoped to this single agent (the tab the
    # user is currently viewing) instead of every deliverable in the run.
    agent_id: str | None = None


class SessionChatResponse(BaseModel):
    session_id: str
    question: str
    answer: str
    intent: str = "question"
    output_updated: bool = False
    updated_agents: list[str] = []
    proposals: list[AgentProposal] = []


class LearningHistoryItem(BaseModel):
    feedback_id: str
    session_id: str
    agent_id: str | None = None
    comment: str
    source: str = ""
    created_at: str = ""


class LearningHistoryResponse(BaseModel):
    session_id: str
    usecase_id: str = ""
    items: list[LearningHistoryItem] = []
    applied_items: list[LearningHistoryItem] = []


class ApplyLearningHistoryRequest(BaseModel):
    agent_id: str = Field(min_length=1)
    selected_feedback: list[str] = Field(min_length=1, max_length=50)
    selected_feedback_ids: list[str] = Field(default_factory=list, max_length=50)


class ApplyLearningHistoryResponse(BaseModel):
    session_id: str
    agent_id: str
    output: str
    applied_feedback: list[str]
    changed: bool


class RemoveLearningHistoryRequest(BaseModel):
    agent_id: str = Field(min_length=1)
    feedback_id: str = Field(min_length=1)


class RemoveLearningHistoryResponse(BaseModel):
    session_id: str
    agent_id: str
    feedback_id: str
    changed: bool


class ProposalActionResponse(BaseModel):
    session_id: str
    applied_agents: list[str] = []
    discarded_agents: list[str] = []
    # Downstream agents whose output was regenerated by the confirmation cascade
    # (so the UI can re-fetch and refresh their Output tab).
    updated_agents: list[str] = []
    quality_score: float | None = None


# ── Graph Visualization Endpoints ───────────────────────────────────────


@router.get("/graph", response_model=GraphResponse)
def get_full_graph(
    current_user: Annotated[object, Depends(get_current_active_user)],
    limit: int = Query(default=500, ge=1, le=5000, description="Max nodes to return"),
) -> GraphResponse:
    """Full knowledge graph as nodes + edges for visualization."""
    try:
        conn = get_kg_connection()
        data = export_full_graph(conn, limit=limit)
        return GraphResponse(**data)
    except Exception as exc:
        logger.exception("Failed to export full graph")
        raise HTTPException(status_code=500, detail=f"Graph export failed: {exc}") from exc


@router.get("/graph/session/{session_id}", response_model=GraphResponse)
def get_session_graph(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> GraphResponse:
    """Subgraph for a session: runs, stages, agents, artifacts, quality."""
    try:
        conn = get_kg_connection()
        _require_session_access(conn, session_id, current_user)
        data = export_session_subgraph(conn, session_id)
        if not data["graph"]["nodes"]:
            raise HTTPException(status_code=404, detail=f"No graph data for session '{session_id}'")

        # Enrich Agent nodes from daan.db so UI gets canonical metadata.
        nodes = data.get("graph", {}).get("nodes", [])
        agent_nodes = [n for n in nodes if str(n.get("type") or "") == "Agent"]
        agent_ids = [
            str((n.get("properties") or {}).get("agent_id") or n.get("id") or "").strip()
            for n in agent_nodes
            if str((n.get("properties") or {}).get("agent_id") or n.get("id") or "").strip()
        ]
        agent_names = [
            str((n.get("properties") or {}).get("agent_name") or n.get("label") or "").strip()
            for n in agent_nodes
            if str((n.get("properties") or {}).get("agent_name") or n.get("label") or "").strip()
        ]

        if agent_ids or agent_names:
            db_agents = (
                db.query(AgentModel)
                .filter(
                    or_(
                        AgentModel.agent_id.in_(agent_ids),
                        AgentModel.agent_name.in_(agent_names),
                    )
                )
                .all()
            )
            by_id = {str(a.agent_id or "").strip(): a for a in db_agents if str(a.agent_id or "").strip()}
            by_name = {
                str(a.agent_name or "").strip().casefold(): a
                for a in db_agents
                if str(a.agent_name or "").strip()
            }

            for node in agent_nodes:
                props = node.setdefault("properties", {})
                aid = str(props.get("agent_id") or node.get("id") or "").strip()
                aname = str(props.get("agent_name") or node.get("label") or "").strip()
                db_a = by_id.get(aid)
                if db_a is None and aname:
                    db_a = by_name.get(aname.casefold())

                if db_a is not None:
                    props["agent_id"] = str(db_a.agent_id or aid)
                    props["agent_name"] = str(db_a.agent_name or aname or aid)
                    props["role"] = str(db_a.role or "")
                    props["agent_type"] = _normalize_agent_type(db_a.agent_type)
                    node["label"] = props["agent_name"] or props["agent_id"]
                else:
                    props["agent_type"] = _normalize_agent_type(props.get("agent_type"))

        return GraphResponse(**data)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to export session graph")
        raise HTTPException(status_code=500, detail=f"Session graph export failed: {exc}") from exc


# ── Structured Output Contract ──────────────────────────────────────────


@router.get("/output/{session_id}", response_model=SessionOutputResponse)
def get_session_output(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> SessionOutputResponse:
    """Structured session output for stage-wise UI visualization.

    Returns the full contract: session, agents (enriched from daan.db),
    outputs (base + all post-feedback), feedback.
    """
    try:
        conn = get_kg_connection()
        _require_session_access(conn, session_id, current_user)
        data = queries.get_session_output(conn, session_id)

        # ── Enrich agent_id/agent_name/role from daan.db ─────────────────
        # Link strategy:
        # 1) direct by agent_id
        # 2) fallback by agent_name (case-insensitive)
        # Also stamp usecase_id onto every agent row for explicit linkage.
        agent_ids = [
            a.get("agent_id") for a in data.get("agents", []) if a.get("agent_id")
        ]
        agent_names = [
            str(a.get("agent_name") or "").strip() for a in data.get("agents", []) if str(a.get("agent_name") or "").strip()
        ]
        if agent_ids or agent_names:
            try:
                db_agents = (
                    db.query(AgentModel)
                    .filter(
                        or_(
                            AgentModel.agent_id.in_(agent_ids),
                            AgentModel.agent_name.in_(agent_names),
                        )
                    )
                    .all()
                )
                db_agent_map: dict[str, AgentModel] = {
                    a.agent_id: a for a in db_agents
                }
                db_agent_by_name: dict[str, AgentModel] = {
                    str(a.agent_name or "").strip().casefold(): a for a in db_agents if str(a.agent_name or "").strip()
                }
                for agent in data["agents"]:
                    aid = agent.get("agent_id") or ""
                    aname = str(agent.get("agent_name") or "").strip()

                    db_a = db_agent_map.get(aid)
                    if db_a is None and aname:
                        db_a = db_agent_by_name.get(aname.casefold())

                    if db_a is not None:
                        agent["agent_id"] = db_a.agent_id
                        if db_a.agent_name:
                            agent["agent_name"] = db_a.agent_name
                        if db_a.role:
                            agent["role"] = db_a.role
                        agent["agent_type"] = _normalize_agent_type(db_a.agent_type)
                    else:
                        agent["agent_type"] = _normalize_agent_type(agent.get("agent_type"))

            except Exception:
                logger.debug("agent enrichment from daan.db failed")

        # ── Resolve usecase details from daan.db (with fallback inference) ─
        usecase_id = str((data.get("session") or {}).get("usecase_id") or "").strip()
        usecase_name = str((data.get("session") or {}).get("usecase_name") or "").strip()

        if usecase_id:
            try:
                db_uc = db.query(UseCaseModel).filter(UseCaseModel.usecaseid == usecase_id).first()
                if db_uc:
                    data["session"]["usecase_name"] = str(db_uc.name or "")
            except Exception:
                logger.debug("usecase lookup failed for %s", usecase_id)
        else:
            try:
                inferred_id, inferred_name = _resolve_usecase_from_agents(
                    db,
                    [str(a.get("agent_id") or "").strip() for a in data.get("agents", []) if str(a.get("agent_id") or "").strip()],
                )
                if inferred_id:
                    data["session"]["usecase_id"] = inferred_id
                    if inferred_name:
                        data["session"]["usecase_name"] = inferred_name
                    usecase_id = inferred_id
            except Exception:
                logger.debug("usecase inference from agents failed")

        return SessionOutputResponse(**data)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to build session output")
        raise HTTPException(status_code=500, detail=f"Session output failed: {exc}") from exc


 # ── Query Runner (Natural Language -> Cypher) ──────────────────────────


def _execute_nlq(question: str) -> NLQResponse:
    question = (question or "").strip()
    if not question:
        raise HTTPException(status_code=400, detail="question is required")

    try:
        cypher = convert_nl_to_cypher(question=question, max_rows=DEFAULT_MAX_ROWS)
    except Exception as exc:
        logger.exception("NLQ generation failed")
        raise HTTPException(
            status_code=500,
            detail=f"NLQ generation failed: {exc}",
        ) from exc

    try:
        rows = execute_cypher(cypher)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"NLQ execution failed. Generated query may be invalid: {exc}") from exc

    summary = f"Found {len(rows)} rows for the question."
    if rows:
        try:
            summary = summary
        except Exception:
            pass

    return NLQResponse(
        question=question,
        generated_cypher=cypher,
        rows=rows,
        count=len(rows),
        summary=summary,
    )


@router.post("/", response_model=NLQResponse, summary="Run Query")
def run_nlq_query(
    payload: NLQRequest,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> NLQResponse:
    """Run query from natural language input (NL -> Cypher, read-only only)."""
    _ = current_user
    return _execute_nlq(question=payload.question)


@router.post("/nlq", response_model=NLQResponse, include_in_schema=False)
def run_nlq_query_legacy(
    payload: NLQRequest,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> NLQResponse:
    """Legacy alias for backward compatibility (hidden from Swagger)."""
    _ = current_user
    return _execute_nlq(question=payload.question)


@router.get("/query/{query_name}", response_model=NLQResponse, include_in_schema=False)
def run_query_legacy(
    query_name: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> NLQResponse:
    """Legacy alias mapped to NLQ engine (hidden from Swagger)."""
    _ = current_user
    return _execute_nlq(question=query_name)


@router.delete("/session/{session_id}", response_model=dict[str, Any])
def delete_session_graph(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> dict[str, Any]:
    """Delete one session and its dependent runtime graph.

    A user may delete sessions they created; admins may delete any session.
    """
    conn = get_kg_connection()

    exists = conn.execute("MATCH (s:Session) WHERE s.id = $sid RETURN s.id AS id", {"sid": session_id})
    if not exists.has_next():
        raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")

    # Ownership check: owner (via INITIATED edge) or Admin may delete.
    is_admin = _is_admin(current_user)
    owner_username = _session_owner_username(conn, session_id)
    requester = str(getattr(current_user, "username", "") or "").strip()
    if not is_admin and (not owner_username or owner_username != requester):
        raise HTTPException(
            status_code=403,
            detail="You can only delete sessions you created.",
        )

    counts = {
        "runs": 0,
        "agent_runs": 0,
        "artifacts": 0,
        "quality": 0,
        "issues": 0,
        "feedback": 0,
        "stage_executions": 0,
        "step_executions": 0,
    }

    count_queries = {
        "runs": "MATCH (s:Session)-[:HAS_RUN]->(r:Run) WHERE s.id=$sid RETURN count(r) AS cnt",
        "agent_runs": "MATCH (s:Session)-[:HAS_RUN]->(:Run)-[:EXECUTED_AGENT]->(ar:AgentRun) WHERE s.id=$sid RETURN count(ar) AS cnt",
        "artifacts": "MATCH (s:Session)-[:HAS_RUN]->(:Run)-[:EXECUTED_AGENT]->(:AgentRun)-[:GENERATED|USED_INPUT]->(art:Artifact) WHERE s.id=$sid RETURN count(art) AS cnt",
        "quality": "MATCH (s:Session)-[:HAS_RUN]->(:Run)-[:HAS_QUALITY]->(q:QualityAssessment) WHERE s.id=$sid RETURN count(q) AS cnt",
        "issues": "MATCH (s:Session)-[:HAS_RUN]->(:Run)-[:HAS_ISSUE]->(i:Issue) WHERE s.id=$sid RETURN count(i) AS cnt",
        "feedback": "MATCH (s:Session)-[:HAS_FEEDBACK]->(f:Feedback) WHERE s.id=$sid RETURN count(f) AS cnt",
        "stage_executions": "MATCH (s:Session)-[:HAS_RUN]->(:Run)-[:HAS_STAGE_EXEC]->(se:StageExecution) WHERE s.id=$sid RETURN count(se) AS cnt",
        "step_executions": "MATCH (s:Session)-[:HAS_RUN]->(:Run)-[:HAS_STAGE_EXEC]->(:StageExecution)-[:HAS_STEP]->(step:StepExecution) WHERE s.id=$sid RETURN count(step) AS cnt",
    }
    for key, cypher in count_queries.items():
        res = conn.execute(cypher, {"sid": session_id})
        counts[key] = res.get_next()[0] if res.has_next() else 0

    try:
        # Delete complete runtime subgraph anchored at this session, including
        # stage-step linked evidence nodes that older query patterns could miss.
        conn.execute(
            """
            MATCH (s:Session)
            WHERE s.id = $sid
            OPTIONAL MATCH (s)-[:HAS_FEEDBACK]->(f:Feedback)
            OPTIONAL MATCH (s)-[:HAS_RUN]->(r:Run)
            OPTIONAL MATCH (r)-[:EXECUTED_AGENT]->(ar:AgentRun)
            OPTIONAL MATCH (r)-[:HAS_STAGE_EXEC]->(se:StageExecution)
            OPTIONAL MATCH (se)-[:HAS_STEP]->(step:StepExecution)
            OPTIONAL MATCH (r)-[:HAS_ISSUE]->(ri:Issue)
            OPTIONAL MATCH (r)-[:HAS_QUALITY]->(rq:QualityAssessment)
            OPTIONAL MATCH (ar)-[:HAS_ISSUE]->(ari:Issue)
            OPTIONAL MATCH (ar)-[:HAS_QUALITY]->(arq:QualityAssessment)
            OPTIONAL MATCH (ar)-[:GENERATED]->(ga:Artifact)
            OPTIONAL MATCH (ar)-[:USED_INPUT]->(ua:Artifact)
            OPTIONAL MATCH (step)-[:STEP_ARTIFACT]->(sa:Artifact)
            OPTIONAL MATCH (step)-[:STEP_ISSUE]->(si:Issue)
            OPTIONAL MATCH (step)-[:STEP_QUALITY]->(sq:QualityAssessment)
            DETACH DELETE step, se, ar, ga, ua, sa, ri, rq, ari, arq, si, sq, f, r, s
            """,
            {"sid": session_id},
        )
    except Exception as exc:
        logger.exception("KG session delete failed for %s", session_id)
        raise HTTPException(status_code=500, detail=f"Failed to delete session graph: {exc}") from exc

    verify = conn.execute("MATCH (s:Session) WHERE s.id = $sid RETURN s.id AS id", {"sid": session_id})
    if verify.has_next():
        raise HTTPException(status_code=500, detail=f"Session '{session_id}' could not be fully deleted")

    storage_deleted = False
    storage_error = None
    try:
        delete_session_dir(session_id)
        storage_deleted = True
    except Exception as exc:
        storage_error = str(exc)
        logger.warning("Session storage delete failed for %s: %s", session_id, exc)

    logger.info("KG admin delete session: session_id=%s counts=%s storage_deleted=%s", session_id, counts, storage_deleted)
    return {
        "session_id": session_id,
        "deleted": counts,
        "session_storage_deleted": storage_deleted,
        "session_storage_error": storage_error,
    }


@router.delete("/clean-all-kg-data", response_model=dict[str, Any], summary="Clean all KG Data")
def clean_all_kg_data(
    payload: KGCleanupAuthRequest,
    current_user: Annotated[object, Depends(require_admin)],
    db: Annotated[Session, Depends(get_db)],
) -> dict[str, Any]:
    """Admin-only KG cleanup that removes graph data without deleting DB files/schema."""
    # Re-auth is mandatory before destructive operation.
    auth_user = authenticate_user(db, payload.username_or_email, payload.password)
    if auth_user is None:
        raise HTTPException(status_code=401, detail="Invalid username/email or password")

    # Ensure the provided credentials + user_id belong to the currently authenticated admin.
    current_username = str(getattr(current_user, "username", "") or "").strip()
    current_email = str(getattr(current_user, "email", "") or "").strip().lower()
    current_user_id = str(getattr(current_user, "id", "") or "").strip()
    provided_username = str(getattr(auth_user, "username", "") or "").strip()
    provided_email = str(getattr(auth_user, "email", "") or "").strip().lower()
    provided_user_id = str(getattr(auth_user, "id", "") or "").strip()
    requested_user_id = str(payload.user_id or "").strip()

    if not requested_user_id:
        raise HTTPException(status_code=400, detail="user_id is required")
    if requested_user_id != provided_user_id:
        raise HTTPException(status_code=403, detail="Provided user_id does not match credentials")
    if requested_user_id != current_user_id:
        raise HTTPException(status_code=403, detail="Provided user_id does not match logged-in admin")

    if current_username != provided_username:
        if not current_email or not provided_email or current_email != provided_email:
            raise HTTPException(status_code=403, detail="Credentials must match the currently logged-in admin user")

    conn = get_kg_connection()

    tables = [
        "Archetype", "Role", "UseCase", "User", "Planner", "Agent",
        "PromptVersion", "Tool", "WorkflowStage", "SubStage",
        "Session", "Run", "AgentRun", "StageExecution", "StepExecution",
        "Artifact", "QualityAssessment", "Issue", "Feedback",
    ]

    counts_before: dict[str, int] = {}
    for table in tables:
        try:
            result = conn.execute(f"MATCH (n:{table}) RETURN count(n) AS cnt")
            counts_before[table] = result.get_next()[0] if result.has_next() else 0
        except Exception:
            counts_before[table] = 0

    # Delete all graph data while preserving database files and schema definitions.
    for table in tables:
        conn.execute(f"MATCH (n:{table}) DETACH DELETE n")

    counts_after: dict[str, int] = {}
    for table in tables:
        try:
            result = conn.execute(f"MATCH (n:{table}) RETURN count(n) AS cnt")
            counts_after[table] = result.get_next()[0] if result.has_next() else 0
        except Exception:
            counts_after[table] = 0

    logger.warning("KG clean all data executed by admin user '%s'", current_username)
    return {
        "cleaned": True,
        "db_path": str(get_kg_db_path()),
        "deleted_nodes": counts_before,
        "remaining_nodes": counts_after,
        "db_files_preserved": True,
    }


# ── Stats ───────────────────────────────────────────────────────────────


@router.get("/stats", response_model=dict[str, int])
def get_graph_stats(
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> dict[str, int]:
    """Node counts per table."""
    conn = get_kg_connection()
    tables = [
        "Archetype", "Role", "UseCase", "User", "Planner", "Agent",
        "PromptVersion", "Tool", "WorkflowStage", "SubStage",
        "Session", "Run", "AgentRun", "StageExecution", "StepExecution",
        "Artifact", "QualityAssessment", "Issue", "Feedback",
    ]
    stats = {}
    for table in tables:
        try:
            result = conn.execute(f"MATCH (n:{table}) RETURN count(n) AS cnt")
            if result.has_next():
                stats[table] = result.get_next()[0]
            else:
                stats[table] = 0
        except Exception:
            stats[table] = 0
    return stats


def _derive_run_status(session_id: str, kg_status: str) -> str:
    """Map a raw KG session status to the user-facing run status.

    The workflow surfaces three statuses (``running`` is no longer used):

      * ``completed``      – the final report has been generated.
      * ``report_pending`` – every agent for the run has executed, but the final
        report has not been generated yet.
      * ``abandoned``      – the run stopped before all of its agents executed.

    ``completed`` is authoritative from the graph (set when the report is
    produced). The other two are derived from disk by comparing the agents that
    actually produced output against the full agent set for the run.
    """
    status = (kg_status or "").strip().lower()
    if status == "completed":
        return "completed"
    try:
        context_map = read_context_map_output(session_id)
        total = {
            str(a.get("agent_id") or "").strip()
            for a in (context_map.get("agents") or [])
            if str(a.get("agent_id") or "").strip()
        }
        executed = {
            str(d.get("agent_id") or "").strip()
            for d in read_run_deliverables(session_id)
            if str(d.get("agent_id") or "").strip() and str(d.get("final_output") or "").strip()
        }
        if total and executed >= total:
            return "report_pending"
        if executed:  # some agents ran but not all
            return "incomplete"
    except Exception:
        logger.debug("Failed to derive run status for %s", session_id, exc_info=True)
    return "abandoned"


@router.get("/run-history", response_model=RunHistoryResponse, summary="Run History")
def get_run_history(
    current_user: Annotated[object, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
    archetype: str = Query(..., min_length=1, description="Archetype display name"),
    usecase_id: str | None = Query(
        default=None,
        description="When provided, only sessions for this use case are returned "
        "(archetype-level view returns every use case's sessions).",
    ),
    limit: int = Query(default=200, ge=1, le=1000, description="Max runs to return"),
) -> RunHistoryResponse:
    """Run history for an archetype: session id, role, status, final quality score, start time.

    When ``usecase_id`` is supplied the result is scoped to that single use case;
    otherwise every use case's sessions in the archetype are returned.
    """
    try:
        conn = get_kg_connection()
        # Strict per-user isolation: EVERY user (including admins) only sees the
        # runs they personally initiated. Run history is privacy/security
        # sensitive and must never expose another user's sessions, so there is
        # deliberately no admin bypass here.
        requester = str(getattr(current_user, "username", "") or "").strip()
        if not requester:
            # Fail closed: without an identifiable owner, return nothing rather
            # than risk leaking every user's history.
            return RunHistoryResponse(archetype=archetype.strip(), runs=[])
        runs = queries.get_run_history_for_archetype(
            conn, archetype.strip(), limit=limit, owner_username=requester,
        )

        # Backfill usecase_id from disk for sessions whose KG HAS_SESSION edge
        # may be missing (e.g. context-only "abandoned" sessions where the edge
        # was never written or was written after the archetype query ran).
        for r in runs:
            if not str(r.get("usecase_id") or "").strip():
                try:
                    ctx = read_context_map_output(r["session_id"])
                    uc_id_disk = str(
                        (ctx.get("usecase_details") or {}).get("usecaseid")
                        or (ctx.get("usecase_details") or {}).get("usecase_id")
                        or ""
                    ).strip()
                    if uc_id_disk:
                        r["usecase_id"] = uc_id_disk
                except Exception:
                    pass

        # Scope to a single use case when requested (Use Case page view).
        usecase_filter = (usecase_id or "").strip()
        if usecase_filter:
            runs = [
                r for r in runs
                if str(r.get("usecase_id") or "").strip() == usecase_filter
            ]

        # Resolve role from daan.db via the use-case when the graph has none.
        usecase_ids = sorted({
            str(r.get("usecase_id") or "").strip()
            for r in runs
            if str(r.get("usecase_id") or "").strip()
        })
        role_by_usecase: dict[str, str] = {}
        name_by_usecase: dict[str, str] = {}
        if usecase_ids:
            uc_rows = (
                db.query(UseCaseModel.usecaseid, UseCaseModel.role, UseCaseModel.name)
                .filter(UseCaseModel.usecaseid.in_(usecase_ids))
                .all()
            )
            role_by_usecase = {
                str(uid or "").strip(): str(role or "").strip()
                for uid, role, _name in uc_rows
            }
            name_by_usecase = {
                str(uid or "").strip(): str(name or "").strip()
                for uid, _role, name in uc_rows
            }

        items: list[RunHistoryItem] = []
        for r in runs:
            usecase_id = str(r.get("usecase_id") or "").strip()
            role = str(r.get("role") or "").strip()
            if not role:
                role = role_by_usecase.get(usecase_id, "")
            usecase_name = str(r.get("usecase_name") or "").strip()
            if not usecase_name:
                usecase_name = name_by_usecase.get(usecase_id, "") or usecase_id
            items.append(RunHistoryItem(
                session_id=r["session_id"],
                role=role,
                usecase_id=usecase_id,
                usecase_name=usecase_name,
                status=_derive_run_status(r["session_id"], r.get("status") or ""),
                quality_score=r.get("quality_score"),
                started_at=r.get("started_at") or "",
            ))

        return RunHistoryResponse(archetype=archetype.strip(), runs=items)
    except Exception as exc:
        logger.exception("Failed to fetch run history")
        raise HTTPException(status_code=500, detail=f"Run history failed: {exc}") from exc


@router.get("/trace-sessions", response_model=list[TraceSessionItem], summary="Trace Sessions")
def get_trace_sessions(
    current_user: Annotated[object, Depends(require_admin)],
    limit: int = Query(default=200, ge=1, le=1000, description="Max sessions to return"),
) -> list[TraceSessionItem]:
    """Return recent workflow sessions for the Traceability table."""
    _ = current_user
    try:
        conn = get_kg_connection()
        rows = queries.list_trace_sessions(conn, limit=limit)
        items: list[TraceSessionItem] = []
        for row in rows:
            session_id = str(row.get("session_id") or "").strip()
            if not session_id:
                continue

            usecase_name = str(row.get("usecase_name") or "").strip()
            usecase_id = str(row.get("usecase_id") or "").strip()
            if not usecase_name or not usecase_id:
                try:
                    context_map = read_context_map_output(session_id)
                    usecase_details = context_map.get("usecase_details") or {}
                    if not usecase_id:
                        usecase_id = str(
                            usecase_details.get("usecaseid")
                            or usecase_details.get("usecase_id")
                            or ""
                        ).strip()
                    if not usecase_name:
                        usecase_name = str(
                            usecase_details.get("usecase")
                            or usecase_details.get("name")
                            or ""
                        ).strip()
                except Exception:
                    pass

            items.append(TraceSessionItem(
                session_id=session_id,
                usecase=usecase_name or usecase_id,
                user=str(row.get("owner_username") or "").strip(),
                timestamp=str(row.get("timestamp") or "").strip(),
            ))
        return items
    except Exception as exc:
        logger.exception("Failed to fetch trace sessions")
        raise HTTPException(status_code=500, detail=f"Trace session listing failed: {exc}") from exc


@router.get("/run-detail/{session_id}", response_model=RunDetailResponse, summary="Run Detail")
def get_run_detail(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> RunDetailResponse:
    """Full detail for a single run: deliverables, final report, quality and feedback."""
    try:
        conn = get_kg_connection()
        meta = queries.get_session_meta(conn, session_id)
        if meta is None:
            raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")

        usecase_id = str(meta.get("usecase_id") or "").strip()
        role = str(meta.get("role") or "").strip()
        usecase_name = str(meta.get("usecase_name") or "").strip()

        # Fall back to daan.db for role / use-case name when the graph has none.
        if usecase_id and (not role or not usecase_name):
            uc_row = (
                db.query(UseCaseModel.role, UseCaseModel.name)
                .filter(UseCaseModel.usecaseid == usecase_id)
                .first()
            )
            if uc_row is not None:
                role = role or str(uc_row[0] or "").strip()
                usecase_name = usecase_name or str(uc_row[1] or "").strip()
        if not usecase_name:
            usecase_name = usecase_id

        # Agent deliverables from disk; resolve display names via daan.db.
        raw_agents = read_run_deliverables(session_id)
        agent_ids = [a["agent_id"] for a in raw_agents if a.get("agent_id")]

        # Per-agent context + refined prompt live in context_map_output.json.
        # Read them so the run-history "View" can restore the Context and
        # Prompt tabs exactly as they were during the run.
        cfg_by_agent: dict[str, dict] = {}
        try:
            context_map = read_context_map_output(session_id)
            for cfg in (context_map.get("agents") or []):
                cid = str(cfg.get("agent_id") or "").strip()
                if cid and isinstance(cfg, dict):
                    cfg_by_agent[cid] = cfg
        except Exception:
            logger.debug("No context_map_output for %s", session_id, exc_info=True)

        name_by_agent: dict[str, str] = {}
        type_by_agent: dict[str, str] = {}
        if agent_ids:
            ag_rows = (
                db.query(AgentModel.agent_id, AgentModel.agent_name, AgentModel.agent_type)
                .filter(AgentModel.agent_id.in_(agent_ids))
                .all()
            )
            name_by_agent = {
                str(aid or "").strip(): str(name or "").strip()
                for aid, name, _agent_type in ag_rows
            }
            type_by_agent = {
                str(aid or "").strip(): _normalize_agent_type(agent_type)
                for aid, _name, agent_type in ag_rows
            }

        agents: list[RunAgentDeliverable] = []
        for a in raw_agents:
            aid = str(a.get("agent_id") or "").strip()
            # The Refinement agent is an internal post-processing step, not a
            # user-facing deliverable, so it is surfaced separately via
            # refinement_output_md and must not appear as its own agent tab.
            if aid == "REFINEMENT_AGENT":
                continue
            cfg = cfg_by_agent.get(aid, {})
            try:
                agent_score = read_agent_score(session_id, aid)
            except Exception:
                agent_score = None
            agents.append(RunAgentDeliverable(
                agent_id=aid,
                agent_name=name_by_agent.get(aid, "") or aid,
                agent_type=_normalize_agent_type(type_by_agent.get(aid) or cfg.get("agent_type")),
                final_output=a.get("final_output") or "",
                base_output=a.get("base_output") or "",
                context=str(cfg.get("context") or ""),
                refined_prompt=str(
                    cfg.get("refined_prompt")
                    or cfg.get("prompt")
                    or cfg.get("instruction")
                    or ""
                ),
                score=agent_score,
                feedback=[
                    RunFeedbackEntry(
                        seq=int(f.get("seq") or 0),
                        feedback_text=f.get("feedback_text") or "",
                        output=f.get("output") or "",
                    )
                    for f in a.get("feedback", [])
                ],
            ))

        # For incomplete sessions, also include agents that were planned (in
        # context_map_output.json) but never executed.  Appending them in plan
        # order after executed agents restores the full pipeline in the UI.
        executed_ids = {a.agent_id for a in agents}
        for cid, cfg in cfg_by_agent.items():
            if cid in executed_ids or cid == "REFINEMENT_AGENT":
                continue
            cfg_name = str(cfg.get("agent_name") or cfg.get("name") or "").strip()
            agents.append(RunAgentDeliverable(
                agent_id=cid,
                agent_name=name_by_agent.get(cid, "") or cfg_name or cid,
                agent_type=_normalize_agent_type(type_by_agent.get(cid) or cfg.get("agent_type")),
                final_output="",
                base_output="",
                context=str(cfg.get("context") or ""),
                refined_prompt=str(
                    cfg.get("refined_prompt")
                    or cfg.get("prompt")
                    or cfg.get("instruction")
                    or ""
                ),
                score=None,
                feedback=[],
            ))

        final_report_md = read_session_file(session_id, REPORTER_OUTPUT_FILENAME) or ""
        quality_report_md = read_session_file(session_id, QUALITY_OUTPUT_FILENAME) or ""
        # When the Refinement agent produced a revised output, surface it so the
        # run-history view shows the SAME final output as the planner page
        # (avoids showing the pre-refinement per-agent output here).
        refinement_output_md = read_session_file(session_id, REFINEMENT_OUTPUT_FILENAME) or ""

        # Pending non-destructive proposals ("Suggested Changes") awaiting Keep/Undo.
        proposals: list[AgentProposal] = []
        try:
            for entry in list_agent_proposals(session_id):
                aid = str(entry.get("agent_id") or "").strip()
                proposals.append(AgentProposal(
                    agent_id=aid,
                    current_output=str(entry.get("current_output") or ""),
                    proposed_output=str(entry.get("proposed_output") or ""),
                    feedback_text=str(entry.get("feedback_text") or ""),
                    created_at=str(entry.get("created_at") or ""),
                ))
        except Exception:
            logger.exception("Failed to list proposals for %s", session_id)

        is_admin = _is_admin(current_user)
        owner_username = str(meta.get("owner_username") or "").strip()
        requester = str(getattr(current_user, "username", "") or "").strip()
        is_owner = bool(owner_username) and owner_username == requester

        # Row-level scoping: only the owner or an admin may view a run's detail.
        if not (is_owner or is_admin):
            raise HTTPException(
                status_code=403,
                detail="You do not have access to this run.",
            )

        return RunDetailResponse(
            session_id=session_id,
            archetype=str(meta.get("archetype") or "").strip(),
            role=role,
            usecase_name=usecase_name,
            status=_derive_run_status(session_id, str(meta.get("status") or "")),
            started_at=str(meta.get("started_at") or "").strip(),
            quality_score=meta.get("quality_score"),
            final_report_md=final_report_md,
            quality_report_md=quality_report_md,
            refinement_output_md=refinement_output_md,
            agents=agents,
            proposals=proposals,
            is_owner=is_owner,
            is_admin=is_admin,
            can_delete=is_owner or is_admin,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to fetch run detail for %s", session_id)
        raise HTTPException(status_code=500, detail=f"Run detail failed: {exc}") from exc


class GenerateReportResponse(BaseModel):
    session_id: str
    final_report_md: str
    quality_report_md: str = ""
    quality_score: float | None = None
    status: str = "completed"


@router.post(
    "/generate-report/{session_id}",
    response_model=GenerateReportResponse,
    summary="Generate Final Report",
)
async def generate_report(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> GenerateReportResponse:
    """Generate (or regenerate) the final report for a historical run.

    Reads the run's agent deliverables from disk, runs the reporter agent to
    compose the final report, and runs the quality agent to score it. Both
    artifacts are written to the session store so subsequent views show them.
    Only the run's owner or an admin may generate the report.
    """
    session_id = (session_id or "").strip()
    try:
        conn = get_kg_connection()
        meta = queries.get_session_meta(conn, session_id)
        if meta is None:
            raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")

        owner_username = str(meta.get("owner_username") or "").strip()
        requester = str(getattr(current_user, "username", "") or "").strip()
        if not (_is_admin(current_user) or (owner_username and owner_username == requester)):
            raise HTTPException(
                status_code=403,
                detail="You do not have permission to generate the report for this run.",
            )

        usecase_id = str(meta.get("usecase_id") or "").strip()
        archetype = str(meta.get("archetype") or "").strip()
        role = str(meta.get("role") or "").strip()
        if usecase_id and not role:
            uc_row = (
                db.query(UseCaseModel.role)
                .filter(UseCaseModel.usecaseid == usecase_id)
                .first()
            )
            if uc_row is not None:
                role = str(uc_row[0] or "").strip()

        deliverables = read_run_deliverables(session_id)
        agent_outputs: dict[str, str] = {}
        for a in deliverables:
            aid = str(a.get("agent_id") or "").strip()
            content = str(a.get("final_output") or a.get("base_output") or "").strip()
            if aid and content:
                agent_outputs[aid] = content

        if not agent_outputs:
            raise HTTPException(
                status_code=409,
                detail="No agent deliverables found for this run; cannot generate a report.",
            )

        # Compose metadata for the reporter agent (best-effort).
        metadata: dict[str, Any] = {}
        try:
            from daan.usecases.usecase_service import get_usecase_details

            metadata = get_usecase_details(archetype, usecase_id) or {}
        except Exception:
            metadata = {}

        from daan.agents.core.reporter_agent import run_reporter_agent_async
        from daan.agents.core.quality_check_agent import run_quality_agent_async

        report = await run_reporter_agent_async(
            agent_outputs=agent_outputs,
            metadata=metadata,
            role=role or None,
            provider=None,
        )
        report_md = str(report or "").strip()
        if not report_md:
            raise HTTPException(status_code=502, detail="Reporter agent produced no report.")
        write_reporter_output(session_id, report_md)

        # Score the freshly generated report (best-effort).
        quality_md = ""
        quality_score: float | None = None
        try:
            quality_context = {
                "report": report_md,
                "session_id": session_id,
                "archetype": archetype,
                "usecase_id": usecase_id,
                "stage": "final_report",
            }
            assessment, _q_usage, _q_model, _q_provider = await run_quality_agent_async(
                quality_context=quality_context,
                role=role or None,
                provider=None,
            )
            quality_md = str(assessment or "").strip()
            if quality_md:
                write_quality_output(session_id, quality_md)
                quality_score = _parse_quality_score(quality_md)
                try:
                    from daan.knowledge_graph import workflow_instrumentation as kg_instr

                    kg_instr.record_quality_assessment(session_id, quality_md)
                except Exception:
                    logger.debug("KG report-quality instrumentation failed", exc_info=True)
        except Exception:
            logger.exception("Failed to score generated report for %s", session_id)

        # Mark the run + session as completed so the run-history view no longer
        # shows it as "Running" once the final report has been produced.
        completed_status = "completed"
        try:
            from daan.knowledge_graph import kg_events

            latest_run_id = queries._latest_run_id_for_session(conn, session_id)
            if latest_run_id:
                kg_events.on_run_completed(conn, latest_run_id, status="completed")
            kg_events.on_session_completed(conn, session_id, status="completed")
        except Exception:
            logger.debug("KG session-completion instrumentation failed", exc_info=True)
            completed_status = str(meta.get("status") or "").strip()

        return GenerateReportResponse(
            session_id=session_id,
            final_report_md=report_md,
            quality_report_md=quality_md,
            quality_score=quality_score,
            status=completed_status,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to generate report for %s", session_id)
        raise HTTPException(status_code=500, detail=f"Report generation failed: {exc}") from exc


# ── Suggested-change proposals (Keep / Discard) ─────────────────────────────


class ProposalActionRequest(BaseModel):
    """Optional targeting for Keep/Discard. Omit ``agent_ids`` to act on all
    currently pending proposals in the session."""

    agent_ids: list[str] | None = None


@router.post(
    "/sessions/{session_id}/proposals/keep",
    response_model=ProposalActionResponse,
    summary="Apply pending suggested changes to the run's output",
)
async def keep_proposals(
    session_id: str,
    payload: ProposalActionRequest,
    current_user: Annotated[object, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> ProposalActionResponse:
    """Promote pending proposal drafts to the current output.

    For each targeted agent, the proposal.md draft is written as the next
    ``feedback`` revision on disk (so run history keeps the audit trail) and
    the proposal files are cleaned up. A fresh quality assessment is then
    computed over the updated deliverables and recorded in the knowledge graph
    as a ``chat_feedback`` rerun.
    """
    from daan.knowledge_graph import workflow_instrumentation as kg_instr

    sid = (session_id or "").strip()
    if not sid:
        raise HTTPException(status_code=400, detail="session_id is required")

    try:
        conn = get_kg_connection()
        meta = queries.get_session_meta(conn, sid)
        if meta is None:
            raise HTTPException(status_code=404, detail=f"Session '{sid}' not found")

        usecase_id = str(meta.get("usecase_id") or "").strip()
        archetype = str(meta.get("archetype") or "").strip()

        pending = list_agent_proposals(sid)
        if not pending:
            return ProposalActionResponse(session_id=sid)

        # Snapshot: does a refinement output file already back the "Output"
        # tab? If so, we must rewrite it after Keep so the tab reflects the
        # promoted content (otherwise the tab keeps rendering the stale
        # pre-Keep refinement text).
        had_refinement_output = bool((read_session_file(sid, REFINEMENT_OUTPUT_FILENAME) or "").strip())

        target_ids: set[str] | None = None
        if payload.agent_ids:
            target_ids = {str(a).strip() for a in payload.agent_ids if str(a).strip()}

        # Resolve display names for KG instrumentation.
        agent_ids_all = [str(p.get("agent_id") or "").strip() for p in pending]
        name_by_agent: dict[str, str] = {}
        if agent_ids_all:
            ag_rows = (
                db.query(AgentModel.agent_id, AgentModel.agent_name)
                .filter(AgentModel.agent_id.in_(agent_ids_all))
                .all()
            )
            name_by_agent = {
                str(aid or "").strip(): str(name or "").strip()
                for aid, name in ag_rows
            }

        deliverables_by_agent = {
            str(d.get("agent_id") or "").strip(): d
            for d in read_run_deliverables(sid)
        }

        applied: list[str] = []
        updated_entries: list[dict[str, Any]] = []
        feedback_text_seen = ""
        refined_outputs: dict[str, str] = {}
        for entry in pending:
            aid = str(entry.get("agent_id") or "").strip()
            if not aid:
                continue
            if target_ids is not None and aid not in target_ids:
                continue
            proposed = str(entry.get("proposed_output") or "").strip()
            if not proposed:
                continue

            feedback_text_seen = feedback_text_seen or str(entry.get("feedback_text") or "")

            # Next feedback revision number for this agent.
            agent_deliverable = deliverables_by_agent.get(aid, {})
            existing_seqs = [int(f.get("seq") or 0) for f in agent_deliverable.get("feedback", [])]
            next_seq = (max(existing_seqs) + 1) if existing_seqs else 1

            try:
                write_feedback_text(sid, aid, next_seq, entry.get("feedback_text") or "")
                output_path = write_agent_output(sid, aid, proposed, feedback_seq=next_seq)
            except Exception:
                logger.exception("Failed to promote proposal for agent %s in %s", aid, sid)
                continue

            delete_agent_proposal(sid, aid)
            applied.append(aid)
            refined_outputs[aid] = proposed
            updated_entries.append({
                "agent_id": aid,
                "agent_name": name_by_agent.get(aid, "") or aid,
                "output": proposed,
                "output_path": output_path,
            })

        quality_score: float | None = None
        if applied:
            # Keep the consolidated "Output" tab in sync. When a refinement
            # output backed the tab prior to Keep, rewrite it so the run-history
            # Output tab reflects the promoted content instead of the stale
            # pre-Keep refinement text. If there is no refinement file (first
            # run / refinement skipped), the tab already reads per-agent
            # deliverables which now include the new feedback revision, so no
            # rewrite is needed.
            if had_refinement_output:
                try:
                    # Prefer the latest final_output per agent so we include
                    # unchanged agents alongside the promoted ones. If the run
                    # only has one agent, this collapses to just that content.
                    latest_by_agent: dict[str, str] = {}
                    for d in read_run_deliverables(sid):
                        aid_l = str(d.get("agent_id") or "").strip()
                        if aid_l:
                            latest_by_agent[aid_l] = str(d.get("final_output") or d.get("base_output") or "")
                    if len(latest_by_agent) == 1:
                        combined_output = next(iter(latest_by_agent.values()))
                    else:
                        combined_output = "\n\n".join(
                            content for content in latest_by_agent.values() if content
                        )
                    if combined_output.strip():
                        write_refinement_output(sid, combined_output)
                except Exception:
                    logger.exception("Failed to refresh refinement output after Keep for %s", sid)

            # Recompute quality and record a chat_feedback rerun in the KG so
            # the per-run quality score reflects the applied changes.
            assessment: str | None = None
            try:
                from daan.agents.core.quality_check_agent import run_quality_agent_async

                quality_context = {
                    "report": "\n\n".join(
                        f"### {aid}\n{content}" for aid, content in refined_outputs.items()
                    ),
                    "session_id": sid,
                    "archetype": archetype,
                    "usecase_id": usecase_id,
                    "stage": "chat_feedback",
                }
                role = str(meta.get("role") or "").strip()
                assessment, _q_usage, _q_model, _q_provider = await run_quality_agent_async(
                    quality_context=quality_context,
                    role=role or None,
                    provider=None,
                )
                if assessment:
                    write_quality_output(sid, assessment)
                    quality_score = _parse_quality_score(assessment)
            except Exception:
                logger.exception("Quality recomputation failed for %s after Keep", sid)
                assessment = None

            try:
                kg_instr.record_chat_feedback_rerun(
                    session_id=sid,
                    current_user=current_user,
                    archetype=archetype,
                    usecase_id=usecase_id,
                    feedback_text=feedback_text_seen,
                    updated_agents=updated_entries,
                    target_agent_ids=applied,
                    assessment=assessment,
                )
            except Exception:
                logger.exception("Failed to record chat_feedback rerun for %s", sid)

        # Cascade: when the user confirms feedback for an agent, rerun the
        # agents whose ``depends_on`` includes it so downstream outputs stay
        # consistent. Works from the live workflow and from the run-history view
        # (where the session is rehydrated from persisted config + outputs).
        cascade_updated: list[str] = []
        if applied:
            try:
                from daan.flow.session_store import (
                    get_session as _get_live_session,
                    create_session as _create_live_session,
                )
                from daan.agents.agent_type_utils import is_action_agent
                from daan.api.v1.endpoints.workflow import (
                    _rerun_action_agent_with_feedback,
                )

                live_session = _get_live_session(sid)
                if live_session is None:
                    # Rehydrate a session from persisted context map + current
                    # deliverables so the downstream cascade also runs for a
                    # historical run opened in the run-history view.
                    context_map = read_context_map_output(sid)
                    if context_map and context_map.get("agents"):
                        live_session = _create_live_session(
                            sid, archetype, usecase_id, context_map_result=context_map
                        )
                        for d in read_run_deliverables(sid):
                            aid_l = str(d.get("agent_id") or "").strip()
                            if not aid_l:
                                continue
                            content = str(d.get("final_output") or d.get("base_output") or "")
                            cfg = live_session.get_agent_config(aid_l)
                            if cfg is not None and is_action_agent(cfg.get("agent_type")):
                                live_session.action_agent_outputs[aid_l] = content
                            else:
                                live_session.dynamic_agent_outputs[aid_l] = content
                            # Seed the feedback sequence from disk so downstream
                            # reruns write a new feedback/{seq} folder instead of
                            # overwriting an existing one.
                            fb_seqs = [int(f.get("seq") or 0) for f in (d.get("feedback") or [])]
                            if fb_seqs:
                                live_session.feedback_seq_by_agent[aid_l] = max(fb_seqs)

                if live_session is not None:
                    # Sync the promoted outputs into the live session. An edited
                    # action (MCP) agent is rerun directly so the change is
                    # published to the external system (ADO/Jira). Dynamic agents
                    # do not cascade: execution pauses after every stage, so any
                    # dependent agents consume the updated output when they run.
                    for _aid, _content in refined_outputs.items():
                        cfg = live_session.get_agent_config(_aid)
                        if cfg is not None and is_action_agent(cfg.get("agent_type")):
                            live_session.action_agent_outputs[_aid] = _content
                            if await _rerun_action_agent_with_feedback(
                                live_session, _aid, feedback_text_seen
                            ):
                                cascade_updated.append(_aid)
                        else:
                            live_session.dynamic_agent_outputs[_aid] = _content
            except Exception:
                logger.exception("Failed to cascade downstream reruns after Keep for %s", sid)

        # De-duplicate while preserving order; exclude the edited agents already
        # reported via ``applied_agents``.
        seen_updated: set[str] = set(applied)
        updated_agents: list[str] = []
        for a in cascade_updated:
            if a and a not in seen_updated:
                seen_updated.add(a)
                updated_agents.append(a)

        return ProposalActionResponse(
            session_id=sid,
            applied_agents=applied,
            updated_agents=updated_agents,
            quality_score=quality_score,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to keep proposals for %s", sid)
        raise HTTPException(status_code=500, detail=f"Keep proposals failed: {exc}") from exc


@router.post(
    "/sessions/{session_id}/proposals/discard",
    response_model=ProposalActionResponse,
    summary="Discard pending suggested changes",
)
def discard_proposals(
    session_id: str,
    payload: ProposalActionRequest,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> ProposalActionResponse:
    """Delete pending proposal drafts without applying them (Undo)."""
    sid = (session_id or "").strip()
    if not sid:
        raise HTTPException(status_code=400, detail="session_id is required")

    target_ids: set[str] | None = None
    if payload.agent_ids:
        target_ids = {str(a).strip() for a in payload.agent_ids if str(a).strip()}

    discarded: list[str] = []
    try:
        pending = list_agent_proposals(sid)
        for entry in pending:
            aid = str(entry.get("agent_id") or "").strip()
            if not aid:
                continue
            if target_ids is not None and aid not in target_ids:
                continue
            if delete_agent_proposal(sid, aid):
                discarded.append(aid)
    except Exception as exc:
        logger.exception("Failed to discard proposals for %s", sid)
        raise HTTPException(status_code=500, detail=f"Discard proposals failed: {exc}") from exc

    return ProposalActionResponse(session_id=sid, discarded_agents=discarded)


def _classify_chat_intent(question: str, llm) -> str:
    """Classify a chat message as an informational ``question`` or a ``feedback``
    request that asks to change/update/improve the run's output.

    Falls back to a keyword heuristic if the LLM classification is unavailable.
    """
    q = (question or "").strip()
    if not q:
        return "question"

    prompt = (
        "Classify the user's message about a generated work product into exactly "
        "one label.\n"
        "Return ONLY one word: QUESTION or FEEDBACK.\n\n"
        "- QUESTION: the user is asking for information, an explanation, a "
        "comparison, or the status of the run (e.g. 'why is the quality score "
        "low', 'compare this with the previous run', 'explain the output').\n"
        "- FEEDBACK: the user is instructing a change to the output — to add, "
        "remove, fix, rewrite, improve, reformat or otherwise modify it (e.g. "
        "'add error handling', 'update the procedure to include logging', "
        "'make it shorter', 'use MERGE instead of INSERT').\n\n"
        f"Message: {q}\n\n"
        "Label:"
    )
    try:
        raw = str(llm(prompt) or "").strip().upper()
        if "FEEDBACK" in raw:
            return "feedback"
        if "QUESTION" in raw:
            return "question"
    except Exception:
        logger.debug("intent classification failed; falling back to heuristic", exc_info=True)

    # Heuristic fallback: leading imperative / change verbs ⇒ feedback.
    lowered = q.lower()
    change_markers = (
        "add ", "remove ", "delete ", "update ", "change ", "fix ", "rewrite",
        "refactor", "improve", "make it", "modify", "replace ", "include ",
        "convert ", "rename", "shorten", "expand", "correct ", "regenerate",
    )
    if lowered.endswith("?"):
        return "question"
    if any(lowered.startswith(m) or f" {m}" in lowered for m in change_markers):
        return "feedback"
    return "question"


async def _propose_chat_feedback(
    *,
    session_id: str,
    usecase_id: str,
    instruction: str,
    role: str,
    name_by_agent: dict[str, str] | None = None,
    target_agent_id: str | None = None,
) -> tuple[str, list[dict[str, Any]]]:
    """Generate non-destructive *proposal* edits for a feedback instruction.

    For every current deliverable, the block-preserving refinement agent
    produces a revised output that applies the user's instruction with the
    smallest change possible. The revised output is written to a companion
    ``proposal.md`` draft file — the original ``output.md`` is left untouched.
    The user must then Keep or Discard the proposal via the dedicated
    endpoints; only Keep promotes the draft to the current output and records
    the KG state transition.

    Returns a human-readable summary and the list of proposal payloads
    ``[{agent_id, agent_name, current_output, proposed_output, feedback_text, created_at}]``.
    """
    from daan.agents.core.refinement_agent import run_block_refinement_async
    from daan.knowledge_graph import workflow_instrumentation as kg_instr

    name_by_agent = name_by_agent or {}

    deliverables = read_run_deliverables(session_id)
    if not deliverables:
        return (
            "There are no agent deliverables stored for this run, so there is "
            "nothing to update.",
            [],
        )

    proposals: list[dict[str, Any]] = []
    normalized_target = (target_agent_id or "").strip()
    for agent in deliverables:
        agent_id = str(agent.get("agent_id") or "").strip()
        if not agent_id:
            continue
        # The Refinement agent is an internal step, never a feedback target.
        if agent_id == "REFINEMENT_AGENT":
            continue
        # Scope the proposal to the agent whose tab the user is viewing so
        # feedback for one agent does not silently rewrite the others.
        if normalized_target and agent_id != normalized_target:
            continue
        current_output = str(agent.get("final_output") or agent.get("base_output") or "").strip()
        if not current_output:
            continue
        try:
            try:
                _owner = _session_owner_username(get_kg_connection(), session_id) or None
            except Exception:
                _owner = None
            agent_history = kg_instr.get_recurrence_guidance_text(
                usecase_id,
                run_limit=5,
                agent_id=agent_id,
                owner_username=_owner,
            )
            proposed = await run_block_refinement_async(
                current_output=current_output,
                feedback_text=instruction,
                role=role or None,
                history_text=agent_history or None,
                provider=None,
            )
        except Exception:
            logger.exception(
                "Block refinement failed for agent %s in session %s", agent_id, session_id
            )
            continue

        proposed_text = str(proposed or "").strip()
        if not proposed_text or proposed_text == current_output:
            # Either the LLM returned nothing useful, or the feedback produced
            # no textual change — skip so the UI does not show an empty diff.
            continue

        try:
            write_agent_proposal(session_id, agent_id, proposed_text, instruction)
        except Exception:
            logger.exception(
                "Failed to persist proposal for agent %s in session %s", agent_id, session_id
            )
            continue

        proposal_meta = read_agent_proposal(session_id, agent_id) or {}
        proposals.append({
            "agent_id": agent_id,
            "agent_name": name_by_agent.get(agent_id, "") or agent_id,
            "current_output": current_output,
            "proposed_output": proposed_text,
            "feedback_text": instruction,
            "created_at": str(proposal_meta.get("created_at") or ""),
        })

    if not proposals:
        return (
            "I looked at your feedback but couldn't produce a suggested change. "
            "Please try rephrasing.",
            [],
        )

    count = len(proposals)
    noun = "deliverable" if count == 1 else "deliverables"
    return (
        f"Here are suggested changes for {count} {noun}. Review the highlighted "
        f"diff below, then click **Keep** to apply the changes or **Undo** to "
        f"discard them. Nothing has been changed yet.",
        proposals,
    )


async def _apply_chat_feedback(
    *,
    session_id: str,
    instruction: str,
    role: str,
    current_user: object,
    archetype: str,
    usecase_id: str,
    name_by_agent: dict[str, str] | None = None,
) -> tuple[str, list[str]]:
    """Deprecated: destructively apply feedback in one step.

    Retained only for callers not yet migrated to the proposal-based flow.
    New code paths must use :func:`_propose_chat_feedback` followed by the
    explicit Keep endpoint so the user can review changes before they land.
    """
    from daan.agents.core.refinement_agent import run_refinement_agent_async
    from daan.knowledge_graph import workflow_instrumentation as kg_instr

    name_by_agent = name_by_agent or {}

    deliverables = read_run_deliverables(session_id)
    if not deliverables:
        return (
            "There are no agent deliverables stored for this run, so there is "
            "nothing to update.",
            [],
        )

    guidance = (
        "## User feedback to incorporate\n"
        f"{instruction.strip()}\n\n"
        "Apply this feedback to the output below. Keep all correct content and "
        "the original format; only make the changes the feedback requires."
    )

    updated_agents: list[str] = []
    updated_entries: list[dict[str, Any]] = []
    refined_outputs: dict[str, str] = {}
    for agent in deliverables:
        agent_id = str(agent.get("agent_id") or "").strip()
        if not agent_id:
            continue
        current_output = str(agent.get("final_output") or agent.get("base_output") or "").strip()
        if not current_output:
            continue
        try:
            refined = await run_refinement_agent_async(
                current_output=current_output,
                guidance_text=guidance,
                role=role or None,
                provider=None,
            )
        except Exception:
            logger.exception("Refinement failed for agent %s in session %s", agent_id, session_id)
            continue

        refined_text = str(refined or "").strip()
        if not refined_text:
            continue

        # Next feedback revision number for this agent.
        existing_seqs = [int(f.get("seq") or 0) for f in agent.get("feedback", [])]
        next_seq = (max(existing_seqs) + 1) if existing_seqs else 1
        try:
            write_feedback_text(session_id, agent_id, next_seq, instruction)
            output_path = write_agent_output(session_id, agent_id, refined_text, feedback_seq=next_seq)
            updated_agents.append(agent_id)
            refined_outputs[agent_id] = refined_text
            updated_entries.append({
                "agent_id": agent_id,
                "agent_name": name_by_agent.get(agent_id, "") or agent_id,
                "output": refined_text,
                "output_path": output_path,
            })
        except Exception:
            logger.exception("Failed to persist refined output for agent %s", agent_id)

    if not updated_agents:
        return (
            "I tried to apply your feedback but couldn't update any output. "
            "Please try rephrasing your request.",
            [],
        )

    # Recompute quality over the updated deliverables and record a new
    # chat-feedback run in the KG so the per-run quality score updates.
    assessment: str | None = None
    try:
        from daan.agents.core.quality_check_agent import run_quality_agent_async

        quality_context = {
            "report": "\n\n".join(
                f"### {agent_id}\n{content}" for agent_id, content in refined_outputs.items()
            ),
            "session_id": session_id,
            "archetype": archetype,
            "usecase_id": usecase_id,
            "stage": "chat_feedback",
        }
        assessment, _q_usage, _q_model, _q_provider = await run_quality_agent_async(
            quality_context=quality_context,
            role=role or None,
            provider=None,
        )
        if assessment:
            write_quality_output(session_id, assessment)
    except Exception:
        logger.exception("Failed to compute quality after chat feedback for %s", session_id)
        assessment = None

    kg_instr.record_chat_feedback_rerun(
        session_id=session_id,
        current_user=current_user,
        archetype=archetype,
        usecase_id=usecase_id,
        feedback_text=instruction,
        updated_agents=updated_entries,
        assessment=assessment,
    )

    count = len(updated_agents)
    noun = "deliverable" if count == 1 else "deliverables"
    score_note = ""
    if assessment is not None:
        score = _parse_quality_score(assessment)
        if score is not None:
            score_note = f" The new quality score is {score:g}."
    return (
        f"✅ Applied your feedback and updated {count} {noun}. The Run tab now "
        f"shows the revised output with your feedback recorded.{score_note}",
        updated_agents,
    )


@router.get(
    "/sessions/{session_id}/learning-history",
    response_model=LearningHistoryResponse,
    summary="Learning History",
)
def get_learning_history(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
    agent_id: str | None = Query(default=None),
) -> LearningHistoryResponse:
    """Feedback from the owner's previous five sessions for this use case."""
    conn = get_kg_connection()
    meta = queries.get_session_meta(conn, session_id)
    if meta is None:
        raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")

    owner_username = str(meta.get("owner_username") or "").strip()
    requester = str(getattr(current_user, "username", "") or "").strip()
    if not owner_username or owner_username != requester:
        raise HTTPException(status_code=403, detail="You do not have access to this run.")

    usecase_id = str(meta.get("usecase_id") or "").strip()
    if not usecase_id:
        return LearningHistoryResponse(session_id=session_id, items=[])

    recent_session_ids = queries.get_recent_sessions_for_usecase(
        conn,
        usecase_id,
        limit=6,
        owner_username=owner_username,
    )
    previous_session_ids = [sid for sid in recent_session_ids if sid != session_id][:5]
    normalized_agent_id = (agent_id or "").strip()
    if normalized_agent_id:
        all_items = _learning_history_from_session_artifacts(
            conn,
            previous_session_ids,
            agent_id=normalized_agent_id,
        )
    else:
        rows = queries.get_feedback_for_sessions(
            conn,
            previous_session_ids,
            agent_id=None,
        )
        all_items = [
            LearningHistoryItem(
                feedback_id=str(row.get("feedback_id") or ""),
                session_id=str(row.get("session_id") or ""),
                agent_id=str(row.get("agent_id") or "").strip() or None,
                comment=str(row.get("comment") or "").strip(),
                source=str(row.get("source") or ""),
                created_at=str(row.get("created_at") or ""),
            )
            for row in rows
            if str(row.get("feedback_id") or "").strip()
            and str(row.get("comment") or "").strip()
        ]

    context_map = read_context_map_output(session_id)
    agent_config = next(
        (
            item for item in (context_map.get("agents") or [])
            if str(item.get("agent_id") or "").strip() == normalized_agent_id
        ),
        {},
    )
    applied_ids = {
        str(item.get("feedback_id") or "").strip()
        for item in (agent_config.get("applied_learning_history") or [])
        if isinstance(item, dict)
    }
    applied_comments = {
        str(item.get("comment") or "").strip().casefold()
        for item in (agent_config.get("applied_learning_history") or [])
        if isinstance(item, dict) and str(item.get("comment") or "").strip()
    }
    applied_items = [
        item for item in all_items
        if item.feedback_id in applied_ids or item.comment.strip().casefold() in applied_comments
    ]
    items = [
        item for item in all_items
        if item.feedback_id not in applied_ids and item.comment.strip().casefold() not in applied_comments
    ]
    return LearningHistoryResponse(
        session_id=session_id,
        usecase_id=usecase_id,
        items=items,
        applied_items=applied_items,
    )


@router.post(
    "/sessions/{session_id}/learning-history/apply",
    response_model=ApplyLearningHistoryResponse,
    summary="Apply selected lessons directly",
)
async def apply_learning_history(
    session_id: str,
    payload: ApplyLearningHistoryRequest,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> ApplyLearningHistoryResponse:
    """Persist selected lessons directly in one agent's workflow instruction."""
    from daan.flow.session_store import get_session

    sid = (session_id or "").strip()
    agent_id = payload.agent_id.strip()
    selected = [
        str(item or "").strip()[:1000]
        for item in payload.selected_feedback
        if str(item or "").strip()
    ]
    if not selected:
        raise HTTPException(status_code=400, detail="Select at least one lesson.")
    selected_ids = {
        str(item or "").strip()
        for item in payload.selected_feedback_ids
        if str(item or "").strip()
    }

    conn = get_kg_connection()
    meta = queries.get_session_meta(conn, sid)
    if meta is None:
        raise HTTPException(status_code=404, detail=f"Session '{sid}' not found")
    _require_session_access(conn, sid, current_user)

    context_map = read_context_map_output(sid)
    agents = list(context_map.get("agents") or [])
    agent_config = next(
        (item for item in agents if str(item.get("agent_id") or "").strip() == agent_id),
        None,
    )
    if agent_config is None:
        raise HTTPException(status_code=404, detail=f"Workflow config for agent '{agent_id}' not found.")

    existing = [
        item for item in (agent_config.get("applied_learning_history") or [])
        if isinstance(item, dict)
    ]
    existing_ids = {str(item.get("feedback_id") or "").strip() for item in existing}
    additions = [
        {"feedback_id": feedback_id, "comment": comment}
        for feedback_id, comment in zip(payload.selected_feedback_ids, selected)
        if str(feedback_id or "").strip() in selected_ids
        and str(feedback_id or "").strip() not in existing_ids
    ]
    if not additions and selected:
        additions = [
            {"feedback_id": f"comment:{comment.casefold()}", "comment": comment}
            for comment in selected
            if f"comment:{comment.casefold()}" not in existing_ids
        ]
    agent_config["applied_learning_history"] = existing + additions
    write_context_map_output(sid, context_map)

    live_session = get_session(sid)
    if live_session is not None:
        live_agents = list(live_session.context_map_result.get("agents") or [])
        live_agent = next(
            (item for item in live_agents if str(item.get("agent_id") or "").strip() == agent_id),
            None,
        )
        if live_agent is not None:
            live_agent["applied_learning_history"] = existing + additions
            live_session.touch()
    delete_agent_proposal(sid, agent_id)

    return ApplyLearningHistoryResponse(
        session_id=sid,
        agent_id=agent_id,
        output="",
        applied_feedback=selected,
        changed=bool(additions),
    )


@router.post(
    "/sessions/{session_id}/learning-history/remove",
    response_model=RemoveLearningHistoryResponse,
    summary="Remove applied lesson",
)
async def remove_learning_history(
    session_id: str,
    payload: RemoveLearningHistoryRequest,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> RemoveLearningHistoryResponse:
    """Remove one previously applied lesson from an agent workflow."""
    from daan.flow.session_store import get_session

    sid = (session_id or "").strip()
    agent_id = payload.agent_id.strip()
    feedback_id = payload.feedback_id.strip()

    conn = get_kg_connection()
    meta = queries.get_session_meta(conn, sid)
    if meta is None:
        raise HTTPException(status_code=404, detail=f"Session '{sid}' not found")
    _require_session_access(conn, sid, current_user)

    context_map = read_context_map_output(sid)
    agents = list(context_map.get("agents") or [])
    agent_config = next(
        (item for item in agents if str(item.get("agent_id") or "").strip() == agent_id),
        None,
    )
    if agent_config is None:
        raise HTTPException(status_code=404, detail=f"Workflow config for agent '{agent_id}' not found.")

    existing = [
        item for item in (agent_config.get("applied_learning_history") or [])
        if isinstance(item, dict)
    ]
    remaining = [
        item for item in existing
        if str(item.get("feedback_id") or "").strip() != feedback_id
    ]
    changed = len(remaining) != len(existing)
    if changed:
        agent_config["applied_learning_history"] = remaining
        write_context_map_output(sid, context_map)

        live_session = get_session(sid)
        if live_session is not None:
            live_agent = live_session.get_agent_config(agent_id)
            if live_agent is not None:
                live_agent["applied_learning_history"] = remaining
                live_session.touch()

    return RemoveLearningHistoryResponse(
        session_id=sid,
        agent_id=agent_id,
        feedback_id=feedback_id,
        changed=changed,
    )


@router.post("/session-chat", response_model=SessionChatResponse, summary="Session Chat")
async def session_chat(
    payload: SessionChatRequest,
    current_user: Annotated[object, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> SessionChatResponse:
    """Chat about a run.

    The message is first classified: an informational *question* is answered from
    the run's knowledge-graph context, while a *feedback* request (an instruction
    to change/update the output) is applied like feedback — the run's agent
    deliverables are refined with the user's instruction and saved as a new
    feedback revision.
    """
    session_id = payload.session_id.strip()
    question = payload.question.strip()
    try:
        conn = get_kg_connection()
        meta = queries.get_session_meta(conn, session_id)
        if meta is None:
            raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")

        usecase_id = str(meta.get("usecase_id") or "").strip()
        role = str(meta.get("role") or "").strip()
        usecase_name = str(meta.get("usecase_name") or "").strip()
        if usecase_id and (not role or not usecase_name):
            uc_row = (
                db.query(UseCaseModel.role, UseCaseModel.name)
                .filter(UseCaseModel.usecaseid == usecase_id)
                .first()
            )
            if uc_row is not None:
                role = role or str(uc_row[0] or "").strip()
                usecase_name = usecase_name or str(uc_row[1] or "").strip()

        archetype = str(meta.get("archetype") or "").strip()

        from daan.llm.llm_provider import get_llm_response

        # ── Classify intent: informational question vs. feedback/update request ──
        intent = _classify_chat_intent(question, get_llm_response)

        if intent == "feedback":
            # Resolve agent display names for KG instrumentation.
            raw_agents = read_run_deliverables(session_id)
            agent_ids = [a["agent_id"] for a in raw_agents if a.get("agent_id")]
            name_by_agent: dict[str, str] = {}
            if agent_ids:
                ag_rows = (
                    db.query(AgentModel.agent_id, AgentModel.agent_name)
                    .filter(AgentModel.agent_id.in_(agent_ids))
                    .all()
                )
                name_by_agent = {
                    str(aid or "").strip(): str(name or "").strip()
                    for aid, name in ag_rows
                }
            # Non-destructive: produce a proposal draft per agent. The user must
            # explicitly Keep the proposal to promote it to the current output.
            answer, proposal_entries = await _propose_chat_feedback(
                session_id=session_id,
                usecase_id=usecase_id,
                instruction=question,
                role=role,
                name_by_agent=name_by_agent,
                target_agent_id=payload.agent_id,
            )
            proposals = [
                AgentProposal(
                    agent_id=str(p.get("agent_id") or ""),
                    current_output=str(p.get("current_output") or ""),
                    proposed_output=str(p.get("proposed_output") or ""),
                    feedback_text=str(p.get("feedback_text") or ""),
                    created_at=str(p.get("created_at") or ""),
                )
                for p in proposal_entries
            ]
            return SessionChatResponse(
                session_id=session_id,
                question=question,
                answer=answer,
                intent="feedback",
                # output_updated stays False until the user promotes the
                # proposal via /proposals/keep — the diff view drives the
                # subsequent refresh, not this response.
                output_updated=False,
                updated_agents=[],
                proposals=proposals,
            )

        # ── Question: answer from grounded knowledge-graph context ──────────────
        timeline = queries.get_session_run_timeline(conn, session_id)
        history = queries.get_recent_feedback_and_issues_for_usecase(
            conn, usecase_id, run_limit=5,
            owner_username=(_session_owner_username(conn, session_id) or None),
        ) if usecase_id else {}
        context_map = read_context_map_output(session_id)
        selected_learning_items = _selected_learning_history_from_context(
            context_map,
            agent_id=(payload.agent_id.strip() if payload.agent_id else None),
        )

        # Per-run timeline within this session (baseline + each feedback rerun).
        run_lines = []
        baseline_score = None
        latest_scored = None
        for t in timeline:
            trig = (t.get("trigger") or "").strip() or "initial"
            is_feedback_run = "feedback" in trig.lower()
            label = "post-feedback" if is_feedback_run else "initial (before feedback)"
            score = t.get("score")
            if score is None:
                score_text = "not scored"
            else:
                score_text = f"{score:g}/{t.get('max_score') or 100:g}"
                latest_scored = score
                if baseline_score is None and not is_feedback_run:
                    baseline_score = score
            run_lines.append(
                f"  - run #{t.get('run_number')} [{label}, trigger={trig}, "
                f"status={t.get('status') or ''}]: quality {score_text}"
            )

        issue_lines = [
            f"  - [{i.get('severity')}] {i.get('issue_type')}: {i.get('description')} (status={i.get('status')})"
            for i in (history.get("issues") or [])
        ]
        feedback_lines = [
            f"  - ({f.get('feedback_type')}, rating={f.get('rating')}): {f.get('comment') or ''}"
            for f in (history.get("feedback") or [])
            if str(f.get("source") or "").strip().lower() != "learning_history"
        ]
        selected_learning_lines = [
            f"  - [{str(item.get('agent_id') or '').strip() or 'session'}] {str(item.get('comment') or '').strip()}"
            for item in selected_learning_items
            if str(item.get("comment") or "").strip()
        ]

        quality_report_md = read_session_file(session_id, QUALITY_OUTPUT_FILENAME) or ""
        if len(quality_report_md) > 4000:
            quality_report_md = quality_report_md[:4000] + "\n…(truncated)…"

        # Refinement agent prompt (built from this use case's last-5 feedback &
        # issues) and the refined output it produced — so the assistant can
        # answer questions about the refinement step.
        from daan.knowledge_graph import workflow_instrumentation as kg_instr

        refinement_prompt_text = ""
        try:
            refinement_prompt_text = (
                kg_instr.get_recurrence_guidance_text(usecase_id, run_limit=5)
                if usecase_id
                else ""
            ) or ""
        except Exception:
            refinement_prompt_text = ""
        if not refinement_prompt_text.strip():
            refinement_prompt_text = (
                "(empty — no prior execution feedback or issues exist for this "
                "use case yet, so the Refinement agent was skipped on the first run.)"
            )
        elif len(refinement_prompt_text) > 4000:
            refinement_prompt_text = refinement_prompt_text[:4000] + "\n…(truncated)…"

        refinement_output_md = read_session_file(session_id, REFINEMENT_OUTPUT_FILENAME) or ""
        if len(refinement_output_md) > 4000:
            refinement_output_md = refinement_output_md[:4000] + "\n…(truncated)…"

        context_parts = [
            "You are an assistant that answers questions about a single DAAN workflow run.",
            "Use the provided context to answer. The 'Run timeline' lists every run "
            "in this session in order: the first run is the initial output before any "
            "feedback, and later runs are reruns produced after user feedback. Use it "
            "to answer comparisons such as 'previous run' or 'score before feedback'. "
            "If a value is genuinely missing (e.g. 'not scored'), say so plainly.",
            "",
            "## Run metadata",
            f"- Session ID: {session_id}",
            f"- Archetype: {meta.get('archetype') or ''}",
            f"- Use case: {usecase_name or usecase_id}",
            f"- Role: {role}",
            f"- Status: {meta.get('status') or ''}",
            f"- Latest quality score: {meta.get('quality_score')}",
            f"- Initial quality score (before feedback): {baseline_score if baseline_score is not None else 'not recorded'}",
            "",
            "## Run timeline (this session, oldest first)",
            ("\n".join(run_lines) if run_lines else "  (no runs recorded)"),
            "",
            "## Issues from recent runs of this use case",
            ("\n".join(issue_lines) if issue_lines else "  (none)"),
            "",
            "## User feedback from recent runs of this use case",
            ("\n".join(feedback_lines) if feedback_lines else "  (none)"),
            "",
            "## Currently selected Learning History for this session",
            "This section is authoritative for questions about which lessons are currently applied. "
            "Use ONLY this section when the question asks about selected/applied Learning History, "
            "and ignore broader run history for that purpose.",
            ("\n".join(selected_learning_lines) if selected_learning_lines else "  (none selected)"),
            "",
            "## Refinement agent prompt (built from the last 5 executions' feedback & issues)",
            "This is the system guidance given to the Refinement agent, which "
            "post-processes the output to incorporate prior feedback and avoid "
            "previously reported issues.",
            refinement_prompt_text,
            "",
            "## Refinement agent output (excerpt)",
            (refinement_output_md or "  (the refinement agent did not produce a separate output for this run)"),
            "",
            "## Quality assessment report (excerpt)",
            (quality_report_md or "  (no quality report)"),
            "",
            "## Question",
            question,
            "",
            "Provide a concise, helpful answer.",
        ]
        prompt = "\n".join(context_parts)

        answer = get_llm_response(prompt)
        return SessionChatResponse(
            session_id=session_id,
            question=question,
            answer=str(answer or "").strip(),
            intent="question",
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Session chat failed for %s", session_id)
        raise HTTPException(status_code=500, detail=f"Session chat failed: {exc}") from exc

