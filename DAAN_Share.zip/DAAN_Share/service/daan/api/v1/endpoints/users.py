from daan.admin.user_service import get_all_users_with_roles
from typing import Annotated
from fastapi import APIRouter, Depends, HTTPException, Query,status
from sqlalchemy import or_
from sqlalchemy.orm import Session
from daan.core.database import get_db
from daan.core.dependencies import get_current_active_user, require_admin, require_admin_or_developer
from daan.models.archetype import Archetype
from daan.models.archetype_assignment import UserArchetypeAssignment
from daan.models.user import User
from daan.schemas.user import PaginatedUsersResponse, UserResponse, UserUpdate,UserCreate,Token, UserLogin, UserArchetypeAssignmentResponse, UserArchetypeAssignmentCreate
from daan.admin.user_service import (delete_user_by_username,get_user_by_username,update_user_by_username,bootstrap_first_admin,login_user,
    assign_role_to_user,create_user,get_all_roles,get_all_permissions,get_user_archetype_assignments,assign_archetype_to_user,revoke_archetype_from_user
)
from daan.models.role import Role
from daan.schemas.role import RoleResponse, PermissionSchema

router = APIRouter()


@router.post("/generateToken", response_model=Token)
def generate_token(
    payload: UserLogin,
    db: Annotated[Session, Depends(get_db)],
) -> Token:
    """Generate a JWT access token for valid credentials."""
    try:
        token, user = login_user(db, payload.username_or_email, payload.password)
        role_name = user.role.name if user.role else "User"
        return Token(access_token=token, user_id=user.id, username=user.username, role=role_name)
    except ValueError:
        raise HTTPException(status_code=401, detail="Invalid username/email or password")


@router.post("/bootstrap-admin", response_model=Token, status_code=status.HTTP_201_CREATED)
def bootstrap_admin(
    payload: UserCreate,
    db: Annotated[Session, Depends(get_db)],
) -> Token:
    """Create the first admin account and return an auth token."""
    try:
        token, user = bootstrap_first_admin(db, payload)
        role_name = user.role.name if user.role else "Admin"
        return Token(access_token=token, user_id=user.id, username=user.username, role=role_name)
    except PermissionError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/users", response_model=PaginatedUsersResponse)
def get_all_users(
    _: Annotated[User, Depends(require_admin_or_developer)],
    db: Annotated[Session, Depends(get_db)],
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=10, ge=1, le=500),
    search: str | None = Query(default=None),
    user_id: int | None = Query(default=None, ge=1),
    username: str | None = Query(default=None),
    email: str | None = Query(default=None),
    role: str | None = Query(default=None),
    archetype: str | None = Query(default=None),
) -> PaginatedUsersResponse:
    """List users and current roles for admin dashboard."""

    def serialize_user(user: User) -> dict:
        # We manually attach assigned archetypes before serialization
        assignments = get_user_archetype_assignments(db, user)

        # Calculate accessible archetypes based on role
        if user.role and user.role.name == "Admin":
            accessible = ["Full Access"]
        else:
            accessible = [a["archetype_name"] for a in assignments]

        # Using dict mapping so FastAPI/Pydantic parses it naturally
        return {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "firstname": user.firstname,
            "lastname": user.lastname,
            "last_login": user.last_login,
            "is_active": user.is_active,
            "role": user.role,
            "created_at": user.created_at,
            "updated_at": user.updated_at,
            "assigned_archetypes": assignments,
            "accessible_archetypes": accessible
        }

    query = db.query(User).outerjoin(Role)

    if user_id is not None:
        query = query.filter(User.id == user_id)
    if username:
        query = query.filter(User.username == username)
    if email:
        query = query.filter(User.email == email)
    if role:
        query = query.filter(Role.name.ilike(role.strip()))
    if archetype:
        normalized_archetype = archetype.strip()
        if normalized_archetype.lower() == "full access":
            query = query.filter(Role.name.ilike("Admin"))
        else:
            query = query.filter(
                User.archetype_assignments.any(
                    UserArchetypeAssignment.archetype.has(Archetype.name == normalized_archetype)
                )
            )
    if search and search.strip():
        pattern = f"%{search.strip()}%"
        query = query.filter(
            or_(
                User.username.ilike(pattern),
                User.email.ilike(pattern),
                User.firstname.ilike(pattern),
                User.lastname.ilike(pattern),
                Role.name.ilike(pattern),
            )
        )

    total = query.order_by(None).count()

    resolved_skip = (page - 1) * page_size
    users = query.order_by(User.id.asc()).offset(resolved_skip).limit(page_size).all()
    response_users = [serialize_user(user) for user in users]
    total_pages = max(1, (total + page_size - 1) // page_size)
    return PaginatedUsersResponse(
        items=response_users,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
    )


@router.get("/roles", response_model=list[RoleResponse])
def get_roles(
    db: Annotated[Session, Depends(get_db)],
) -> list[RoleResponse]:
    """List all available roles."""
    return get_all_roles(db)


@router.get("/permissions", response_model=list[PermissionSchema])
def get_permissions(
    _: Annotated[User, Depends(require_admin_or_developer)],
    db: Annotated[Session, Depends(get_db)],
) -> list[PermissionSchema]:
    """List all available permissions (admin or developer)."""
    return get_all_permissions(db)

@router.post("/users", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def add_user(
    payload: UserCreate,
    db: Annotated[Session, Depends(get_db)],
) -> UserResponse:
    """Create a new user."""
    try:
        return create_user(db, payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/{username}/details", response_model=dict)
def get_user_details(
    username: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> dict:
    """Get complete user details including role and all permissions."""
    user = get_user_by_username(db, username)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    is_admin = current_user.role is not None and current_user.role.name == "Admin"
    if not is_admin and current_user.username != username:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    permissions = []
    if user.role and user.role.permissions:
        permissions = [
            {"id": perm.id, "name": perm.name, "description": perm.description}
            for perm in user.role.permissions
        ]
    
    # Include assigned archetypes
    assigned_archetypes = get_user_archetype_assignments(db, user)
    
    return {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "firstname": user.firstname,
        "lastname": user.lastname,
        "is_active": user.is_active,
        "last_login": user.last_login,
        "created_at": user.created_at,
        "updated_at": user.updated_at,
        "role": {
            "id": user.role.id,
            "name": user.role.name,
            "description": user.role.description,
        } if user.role else None,
        "permissions": permissions,
        "assigned_archetypes": assigned_archetypes
    }


@router.put("/{username}", response_model=UserResponse)
def edit_user(
    username: str,
    payload: UserUpdate,
    _: Annotated[User, Depends(require_admin)],
    db: Annotated[Session, Depends(get_db)],
) -> UserResponse:
    """Update user profile (admin only)."""
    existing = get_user_by_username(db, username)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")

    try:
        updated = update_user_by_username(db, username, payload)
        if updated is None:
            raise HTTPException(status_code=404, detail="User not found")
        return updated
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.delete("/{username}")
def remove_user(
    username: str,
    _: Annotated[User, Depends(require_admin)],
    db: Annotated[Session, Depends(get_db)],
) -> dict[str, str]:
    """Delete user by username (admin only)."""
    deleted = delete_user_by_username(db, username)
    if not deleted:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "User deleted successfully"}


@router.get("/management-permissions", response_model=dict)
def get_user_management_permissions(
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> dict:
    """Get user management permissions for the current user (edit/delete capabilities)."""
    is_admin = current_user.role is not None and current_user.role.name == "Admin"
    
    # Only admin users can edit and delete users
    return {
        "canEdit": is_admin,
        "canDelete": is_admin
    }


@router.post("/{username}/assign-role/{role_id}", response_model=UserResponse)
def assign_role(
    username: str,
    role_id: int,
    _: Annotated[User, Depends(require_admin)],
    db: Annotated[Session, Depends(get_db)],
) -> UserResponse:
    """Assign a specific role to a user."""
    user = assign_role_to_user(db, username, role_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.get("/{username}/permissions", response_model=list[dict])
def get_user_permissions(
    username: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> list[dict]:
    """Get all permissions for a user based on their role."""
    user = get_user_by_username(db, username)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    
    is_admin = current_user.role is not None and current_user.role.name == "Admin"
    if not is_admin and current_user.username != username:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    if user.role is None:
        return []
    
    return [
        {"id": perm.id, "name": perm.name, "description": perm.description}
        for perm in user.role.permissions
    ]


@router.get("/{username}/role", response_model=RoleResponse | None)
def get_user_role(
    username: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> RoleResponse | None:
    """Get the role assigned to a user."""
    user = get_user_by_username(db, username)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    
    is_admin = current_user.role is not None and current_user.role.name == "Admin"
    if not is_admin and current_user.username != username:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    return user.role


@router.get("/{username}/archetypes", response_model=list[UserArchetypeAssignmentResponse])
def get_user_archetypes(
    username: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> list[UserArchetypeAssignmentResponse]:
    """Get all archetypes assigned to a user."""
    user = get_user_by_username(db, username)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    # Check 1: Is user looking at themselves?
    # Check 2: Does user have ViewUserAssignments permission?
    is_self = current_user.username == username
    has_permission = any(p.name == "ViewUserAssignments" for p in current_user.role.permissions) if current_user.role else False

    if not (is_self or has_permission):
        raise HTTPException(status_code=403, detail="Not authorized to view user archetype assignments")

    assignments = get_user_archetype_assignments(db, user)
    return assignments


@router.post("/{username}/archetypes", response_model=UserArchetypeAssignmentResponse)
def assign_archetype(
    username: str,
    payload: UserArchetypeAssignmentCreate,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> UserArchetypeAssignmentResponse:
    """Assign an archetype to a user with specific access level."""
    user = get_user_by_username(db, username)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    # Check: Does the user have the AssignArchetype permission?
    has_permission = any(p.name == "AssignArchetype" for p in current_user.role.permissions) if current_user.role else False

    if not has_permission:
        raise HTTPException(status_code=403, detail="Not authorized to assign archetypes")

    try:
        assignment = assign_archetype_to_user(db, user.id, payload)
        return assignment
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.delete("/{username}/archetypes/{archetype_id}")
def revoke_archetype(
    username: str,
    archetype_id: int,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> dict[str, str]:
    """Revoke an archetype assignment from a user."""
    user = get_user_by_username(db, username)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    # Check: Does the user have the AssignArchetype permission? (Assuming management of assignments)
    # If the request is for RevokeArchetype specifically, we check for that permission.
    has_permission = any(p.name == "AssignArchetype" for p in current_user.role.permissions) if current_user.role else False

    if not has_permission:
        raise HTTPException(status_code=403, detail="Not authorized to revoke archetypes")

    deleted = revoke_archetype_from_user(db, user.id, archetype_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Assignment not found")
    return {"message": "Archetype revoked successfully"}