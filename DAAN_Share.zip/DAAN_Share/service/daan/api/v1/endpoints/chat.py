"""Chat API for the DAAN assistant.

Backs the landing-page chat (ui/src/components/ChatInterface.tsx). Each message is
answered by the RAG engine over the 'daan' knowledge base (overall DAAN assistant),
optionally scoped to a single use case via `usecase_id`. Sessions and messages are
persisted in the chat_sessions / chat_messages tables.
"""

from __future__ import annotations

from datetime import datetime
import json
import time
from typing import Annotated, Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy.orm import Session

from daan.chat.chat_context_service import (
    append_uploaded_context,
    build_chat_history_text,
    build_retrieval_chat_context,
    extract_uploaded_context,
    is_greeting_or_smalltalk_query,
    is_session_context_query,
    select_relevant_uploaded_context,
)
from daan.core.config import get_settings
from daan.core.database import get_db
from daan.core.dependencies import get_current_active_user
from daan.models.chat import ChatMessage, ChatSession
from daan.models.user import User
from daan.native_tools.rag_tool import RagTool
from daan.flow.session_service import (
    create_session_dir,
    delete_session_dir,
    ensure_context_map_output,
    list_session_dirs,
    append_chat_session_message,
    read_chat_session_manifest,
    read_chat_session_messages,
    read_context_map_output,
    write_chat_session_manifest,
)
from daan.flow.session_store import SessionState, create_session as create_workflow_session, get_session as get_workflow_session
from daan.agents.agent_type_utils import normalize_agent_type
from daan.api.v1.endpoints.rag_router import (
    SearchResult,
    _build_explainability_payload,
    _build_final_context,
    _build_fallback_graph_edges,
    _build_fallback_graph_nodes,
    _build_reasoning_steps,
    _clean_answer_text,
    _resolve_kb_config,
    _resolve_system_prompt,
    _strip_graph_payload,
    synthesize_kb_answer,
    _query_link,
    tracer,
)
from daan.rag.observability.rag_tracer import RagTrace, build_trace_evidence_envelope
from daan.token_usage.access import user_has_access_to_kb
from daan.usecases.usecase_service import get_usecase_details, resolve_archetype_for_usecase

router = APIRouter()

DAAN_KB_ID = "daan"


class CreateSessionResponse(BaseModel):
    id: str
    title: str


def _generate_chat_session_id() -> str:
    return str(int(time.time() * 1000))


def _normalize_usecase_id(value: str | None) -> str | None:
    normalized = str(value or "").strip()
    if not normalized:
        return None
    if normalized.casefold() in {"string", "null", "none", "undefined"}:
        return None
    return normalized.upper()


def _normalize_kb_id(value: str | None) -> str | None:
    normalized = str(value or "").strip()
    if not normalized:
        return None
    if normalized.casefold() in {"string", "null", "none", "undefined"}:
        return None
    return normalized


def _available_kb_ids(rag_config: dict[str, Any]) -> set[str]:
    return {
        str(kb.get("id") or "").strip()
        for kb in rag_config.get("knowledge_bases", []) or []
        if str(kb.get("id") or "").strip()
    }


def _resolve_chat_agent_kb_id(
    *,
    session_id: str,
    requested_kb_id: str | None,
    rag_config: dict[str, Any],
) -> str:
    available_kb_ids = _available_kb_ids(rag_config)
    manifest = read_chat_session_manifest(session_id)
    manifest_kb_id = _normalize_kb_id(str(manifest.get("kb_id") or "")) if manifest else None

    normalized_requested_kb_id = _normalize_kb_id(requested_kb_id)
    if normalized_requested_kb_id and manifest_kb_id and normalized_requested_kb_id != manifest_kb_id:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Session '{session_id}' belongs to knowledge base '{manifest_kb_id}', "
                f"not '{normalized_requested_kb_id}'."
            ),
        )

    resolved_kb_id = normalized_requested_kb_id or manifest_kb_id or DAAN_KB_ID
    if available_kb_ids and resolved_kb_id not in available_kb_ids:
        raise HTTPException(status_code=400, detail=f"Unknown kb_id '{resolved_kb_id}'")
    return resolved_kb_id


def _resolve_standard_chat_kb_id(requested_kb_id: str | None, rag_config: dict[str, Any]) -> str:
    available_kb_ids = _available_kb_ids(rag_config)
    resolved_kb_id = _normalize_kb_id(requested_kb_id) or DAAN_KB_ID
    if available_kb_ids and resolved_kb_id not in available_kb_ids:
        raise HTTPException(status_code=400, detail=f"Unknown kb_id '{resolved_kb_id}'")
    return resolved_kb_id


def _is_chat_agent_usecase(usecase_id: str | None) -> bool:
    if not usecase_id:
        return False
    try:
        details = get_usecase_details("", usecase_id)
    except FileNotFoundError:
        return False
    for agent in details.get("agents", []) or []:
        if normalize_agent_type(agent.get("agent_type")) == "chat_agent":
            return True
    return False


def _flatten_chat_agent_context(context_map_result: dict[str, Any]) -> str:
    context_map = context_map_result.get("context_map") if isinstance(context_map_result, dict) else {}
    if not isinstance(context_map, dict):
        return ""

    sections: list[str] = []
    for agent_id, mapped_inputs in context_map.items():
        if not isinstance(mapped_inputs, dict):
            continue
        pieces: list[str] = []
        for input_name, values in mapped_inputs.items():
            if isinstance(values, list):
                rendered = []
                for value in values:
                    rendered.append(getattr(value, "summary", None) or getattr(value, "filename", None) or str(value))
                value_text = "\n".join(rendered)
            else:
                value_text = str(values)
            if value_text.strip():
                pieces.append(f"{input_name}:\n{value_text.strip()}")
        if pieces:
            sections.append(f"AGENT {agent_id}:\n" + "\n\n".join(pieces))
    return "\n\n".join(sections)


def _build_chat_agent_history_text(records: list[dict[str, Any]], limit: int = 8) -> str:
    if limit > 0:
        records = records[-limit:]

    lines: list[str] = []
    for record in records:
        role = str(record.get("role") or "").strip() or "message"
        content = str(record.get("content") or "").strip()
        if content:
            lines.append(f"{role.title()}: {content}")
    return "\n".join(lines)


def _select_chat_agent_config(agents: list[dict[str, Any]]) -> dict[str, Any]:
    for agent in agents:
        if normalize_agent_type(agent.get("agent_type")) == "chat_agent":
            return agent
    raise HTTPException(status_code=404, detail="No chat_agent configuration found for this use case")


def _persist_chat_agent_turn(
    session_id: str,
    role: str,
    content: str,
    *,
    usecase_id: str | None = None,
    kb_id: str | None = None,
    references: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    append_chat_session_message(
        session_id,
        role=role,
        content=content,
        usecase_id=usecase_id,
        kb_id=kb_id,
        references=references,
        metadata=metadata,
    )


def _resolve_chat_agent_session_request(
    *,
    session_id: str,
    requested_usecase_id: str | None,
    current_user_id: int | None,
) -> tuple[dict[str, Any], str | None]:
    manifest = read_chat_session_manifest(session_id)
    owner_user_id = manifest.get("user_id") if manifest else None
    if manifest and owner_user_id not in (None, current_user_id):
        raise HTTPException(status_code=403, detail="Not your session")
    manifest_usecase_id = _normalize_usecase_id(str(manifest.get("usecase_id") or "")) if manifest else None

    if requested_usecase_id and manifest_usecase_id and requested_usecase_id != manifest_usecase_id:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Session '{session_id}' belongs to use case '{manifest_usecase_id}', "
                f"not '{requested_usecase_id}'."
            ),
        )

    effective_usecase_id = requested_usecase_id or manifest_usecase_id
    return manifest, effective_usecase_id


async def _handle_chat_agent_message(
    *,
    db: Session,
    current_user: User,
    session_id: str,
    message: str,
    usecase_id: str,
    kb_id: str | None,
    user_id: int | None,
    files: list[UploadFile],
) -> dict[str, Any]:
    settings = get_settings()
    rag_config = settings.load_rag_config()
    resolved_kb_id = _resolve_chat_agent_kb_id(
        session_id=session_id,
        requested_kb_id=kb_id,
        rag_config=rag_config,
    )
    kb_config = _resolve_kb_config(rag_config, resolved_kb_id)
    if kb_config is None or not user_has_access_to_kb(db, current_user, resolved_kb_id, kb_config=kb_config):
        raise HTTPException(status_code=403, detail=f"Not authorized to access knowledge base '{resolved_kb_id}'.")
    archetype = resolve_archetype_for_usecase(usecase_id) or ""
    details = get_usecase_details(archetype, usecase_id)
    agents = details.get("agents", []) or []
    if not agents:
        raise HTTPException(status_code=404, detail="No agents found for this chat-agent use case")
    chat_agent_config = _select_chat_agent_config(agents)

    if files:
        raise HTTPException(
            status_code=400,
            detail=(
                "Chat-agent file uploads must go through the session upload endpoint before messaging. "
                "Upload files to /api/sessions/{session_id}/upload-files, then refresh context mapping."
            ),
        )

    create_session_dir(session_id)
    write_chat_session_manifest(
        session_id,
        user_id=user_id,
        archetype=archetype,
        usecase_id=usecase_id,
        kb_id=resolved_kb_id,
    )
    context_map_result = ensure_context_map_output(
        session_id=session_id,
        agents=agents,
        usecase_details=details.get("usecase_details", {}),
    )

    workflow_session = get_workflow_session(session_id)
    if workflow_session is None:
        workflow_session = create_workflow_session(
            session_id=session_id,
            archetype=archetype,
            usecase_id=usecase_id,
            user_id=user_id,
            context_map_result=context_map_result,
        )
    else:
        if getattr(workflow_session, "user_id", None) is None:
            workflow_session.user_id = user_id
        workflow_session.context_map_result = context_map_result
        workflow_session.archetype = archetype or workflow_session.archetype
        workflow_session.usecase_id = usecase_id
        workflow_session.touch()
    workflow_session.context_map_output_path = f"session_storage/{session_id}/context_map_output.json"
    workflow_session.state = SessionState.CONTEXT_MAPPED
    workflow_session.touch()

    query_text = message.strip()
    previous_turns = read_chat_session_messages(session_id, limit=16)
    chat_history_text = _build_chat_agent_history_text(previous_turns)
    retrieval_history_text = build_chat_history_text(previous_turns, query=query_text)
    retrieval_chat_context = build_retrieval_chat_context(query_text, retrieval_history_text)
    uploaded_context_text = _flatten_chat_agent_context(read_context_map_output(session_id))

    effective_rag_config = _build_chat_rag_config(rag_config, resolved_kb_id)
    tool = RagTool(effective_rag_config)
    query_link = _query_link(query_text)
    retriever_type = _resolve_chat_agent_retriever_type(effective_rag_config, resolved_kb_id)
    try:
        t_start = time.monotonic()
        search_kwargs: dict[str, Any] = {
            "query": query_text,
            "k": 8,
            "retriever_type": retriever_type,
            "kb_id": resolved_kb_id,
            "metadata_filter": None,
        }
        if retrieval_chat_context:
            search_kwargs["chat_context"] = retrieval_chat_context
        docs = tool.search_documents(
            **search_kwargs,
        )
        retrieval_latency_ms = int((time.monotonic() - t_start) * 1000)
        chat_agent_prompt = (
            str(chat_agent_config.get("prompt") or "").strip()
            or str(chat_agent_config.get("instruction") or "").strip()
            or _resolve_system_prompt(rag_config, resolved_kb_id)
        )
        t_synth_start = time.monotonic()
        answer, reasoning_steps = _synthesize_chat_answer(
            query_text,
            docs,
            chat_agent_prompt,
            chat_history_text=chat_history_text,
            uploaded_context_text=uploaded_context_text,
        )
        answer_generation_ms = int((time.monotonic() - t_synth_start) * 1000)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"Chat failed: {exc}") from exc

    t_explain_start = time.monotonic()
    trace_docs = [doc if isinstance(doc, SearchResult) else SearchResult(**doc) for doc in docs]
    final_context = _build_final_context(
        [part for part in [chat_history_text, uploaded_context_text, *[doc.content for doc in trace_docs]] if part]
    )
    explainability = _build_explainability_payload(
        None,
        query_link,
        retriever_type,
        retrieval_latency_ms,
        trace_docs,
        answer,
        final_context,
        reasoning_steps or _build_reasoning_steps(query_text, trace_docs),
    )
    explainability_ms = int((time.monotonic() - t_explain_start) * 1000)
    latency_ms = retrieval_latency_ms + answer_generation_ms + explainability_ms
    timing_breakdown = dict(explainability.get("timing_breakdown", {}) or {})
    timing_breakdown["answer_generation_ms"] = answer_generation_ms
    timing_breakdown["explainability_ms"] = explainability_ms
    explainability["timing_breakdown"] = timing_breakdown
    explainability["latency_ms"] = latency_ms
    evidence = build_trace_evidence_envelope(
        tool.get_last_evidence_envelope(query_text),
        session_id=resolved_kb_id,
        query=query_text,
        query_link=query_link,
        retriever_type=retriever_type,
        latency_ms=latency_ms,
        selected_references=list(explainability.get("selected_references", [])) if explainability else [],
        selected_source_ids=list(explainability.get("final_selected_chunk_ids", [])) if explainability else [doc.id for doc in trace_docs],
    )
    trace = RagTrace(
        evidence=evidence,
        query=query_text,
        query_link=query_link,
        retrieved_docs=[doc.content[:200] for doc in trace_docs],
        reranked_docs=[doc.content[:200] for doc in trace_docs],
        final_context=final_context,
        retriever_type=retriever_type,
        latency_ms=latency_ms,
        session_id=resolved_kb_id,
        owner_user_id=current_user.id,
        origin_session_id=session_id,
        seed_chunk_ids=list(explainability.get("seed_chunk_ids", [])) if explainability else [],
        traversal_hops=list(explainability.get("traversal_hops", [])) if explainability else [],
        visited_node_ids=list(explainability.get("visited_node_ids", [])) if explainability else [],
        edge_list=list(explainability.get("edge_list", [])) if explainability else [],
        final_selected_chunk_ids=list(explainability.get("final_selected_chunk_ids", [])) if explainability else [doc.id for doc in trace_docs],
        explainability=_strip_graph_payload(explainability) if explainability else {},
        graph_nodes=list(explainability.get("graph_nodes", [])) if explainability else _build_fallback_graph_nodes(query_link, trace_docs),
        graph_edges=list(explainability.get("graph_edges", [])) if explainability else _build_fallback_graph_edges(query_link, trace_docs),
    )
    tracer.record(trace)

    references = [doc.id for doc in trace_docs]
    assistant_metadata = {
        "reference_ids": references,
        "kb_id": resolved_kb_id,
        "trace_id": trace.trace_id,
        "query_link": query_link,
        "retriever_type": retriever_type,
        "evidence_available": True,
        "explainability_available": True,
        "selected_references": list(explainability.get("selected_references", [])),
    }

    _persist_chat_agent_turn(session_id, "user", message, usecase_id=usecase_id, kb_id=resolved_kb_id)
    _persist_chat_agent_turn(
        session_id,
        "assistant",
        answer,
        usecase_id=usecase_id,
        kb_id=resolved_kb_id,
        references=references,
        metadata=assistant_metadata,
    )

    return {
        "response": answer,
        "references": references,
        "session_id": session_id,
        "mode": "chat_agent",
        "metadata": assistant_metadata,
    }


def _resolve_chat_retrieval_profile(rag_config: dict[str, Any], kb_id: str) -> dict[str, Any]:
    for kb in rag_config.get("knowledge_bases", []) or []:
        if str(kb.get("id")) != kb_id:
            continue
        profile = kb.get("chat_retrieval_profile")
        return dict(profile) if isinstance(profile, dict) else {}
    return {}


def _build_chat_rag_config(rag_config: dict[str, Any], kb_id: str) -> dict[str, Any]:
    profile = _resolve_chat_retrieval_profile(rag_config, kb_id)
    if not profile:
        return rag_config

    configured = dict(rag_config)
    if profile.get("retriever_type"):
        configured["default_retriever_type"] = str(profile.get("retriever_type"))
    if "use_hybrid" in profile:
        configured["use_hybrid"] = bool(profile.get("use_hybrid"))
    if "candidate_pool" in profile:
        configured["candidate_pool"] = int(profile.get("candidate_pool") or 0)
    if "max_probe_branches" in profile:
        configured["max_probe_branches"] = int(profile.get("max_probe_branches") or 0)
    if "use_lexical_chunk_resolution" in profile:
        configured["use_lexical_chunk_resolution"] = bool(profile.get("use_lexical_chunk_resolution"))
    if isinstance(profile.get("context_extrapolation"), dict):
        configured_context_extrapolation = dict(configured.get("context_extrapolation") or {})
        configured_context_extrapolation.update(profile.get("context_extrapolation") or {})
        configured["context_extrapolation"] = configured_context_extrapolation
    return configured


def _resolve_chat_retriever_type(rag_config: dict[str, Any], kb_id: str) -> str:
    profile = _resolve_chat_retrieval_profile(rag_config, kb_id)
    if profile.get("retriever_type"):
        return str(profile.get("retriever_type"))
    return str(rag_config.get("default_retriever_type") or "graph_rag")


def _resolve_chat_agent_retriever_type(rag_config: dict[str, Any], kb_id: str) -> str:
    profile = _resolve_chat_retrieval_profile(rag_config, kb_id)
    if profile.get("retriever_type"):
        return str(profile.get("retriever_type"))
    return "vector"


def _synthesize_chat_answer(
    query: str,
    docs: list[dict],
    system_prompt: str,
    chat_history_text: str = "",
    uploaded_context_text: str = "",
    feedback_context: str = "",
) -> tuple[str, list[dict[str, Any]]]:
    """Generate a detailed markdown answer plus grounded reasoning steps.

    Returns (answer_markdown, reasoning_steps). The LLM is asked to emit both
    in a single JSON response so no extra call is needed. If parsing fails,
    returns (plain_answer, []) and the caller falls back to templated steps.
    """
    rag_context = "\n\n".join(f"[{d['id']}] {d['content']}" for d in docs if d.get("content"))
    sections: list[str] = []
    if feedback_context.strip():
        sections.append(f"PREVIOUS USER FEEDBACK FOR SIMILAR QUERIES:\n{feedback_context.strip()}")
    if chat_history_text.strip():
        sections.append(f"PRIOR CHAT HISTORY:\n{chat_history_text.strip()}")
    if uploaded_context_text.strip():
        sections.append(f"UPLOADED DOCUMENT CONTEXT:\n{uploaded_context_text.strip()}")
    if rag_context.strip():
        sections.append(f"RAG CONTEXT:\n{rag_context.strip()}")

    if not sections:
        return "I couldn't find relevant information in the DAAN knowledge base to answer that.", []

    context_text = "\n\n".join(sections)
    has_feedback = bool(feedback_context.strip())

    if has_feedback:
        format_instruction = (
            "The user previously gave feedback on a similar answer. Their feedback is in the "
            "'PREVIOUS USER FEEDBACK FOR SIMILAR QUERIES' section. "
            "You MUST follow that feedback exactly — it overrides any default formatting."
        )
    else:
        format_instruction = (
            "Format the answer as clean, detailed markdown:\n"
            "- Start with a brief summary (1-2 sentences)\n"
            "- Follow with detailed explanation using headings or bullet points\n"
            "- Be thorough — cover all relevant aspects from the context\n"
            "- Do NOT give a short 2-3 line answer when the context has more information\n"
            "- Use **bold** for key terms and proper markdown structure"
        )

    valid_chunk_ids = [str(d["id"]) for d in docs if d.get("id")]
    chunk_id_list = ", ".join(valid_chunk_ids) or "(none)"

    citation_instruction = (
        "Cite your sources inline: each RAG CONTEXT chunk is prefixed with a bracketed identifier "
        "(e.g. [Services.cs:0:0]). Whenever a sentence or bullet uses information from a chunk, append that "
        "exact bracketed identifier immediately after it. Only reuse identifiers that literally appear in "
        "the CONTEXT — never invent one, and omit the citation if no chunk was used."
    )

    reasoning_instruction = (
        "You MUST return a single JSON object with EXACTLY two keys and nothing else:\n"
        '  "reasoning_steps": array of 3-6 step objects describing how you actually'
        " used the CONTEXT to answer, in order. Each step is an object with:\n"
        '    - "title" (short label, e.g. "Interpreted the question", "Reviewed excerpt from Services.cs")\n'
        '    - "detail" (1-3 sentence explanation grounded in the CONTEXT)\n'
        '    - "chunk_ids" (array of chunk IDs from the CONTEXT that this step used;'
        f" allowed values: [{chunk_id_list}]; use [] when no chunk applies)\n"
        '  "answer": the final markdown answer string as instructed above.\n'
        "Rules for reasoning_steps:\n"
        "- Steps must reflect the ACTUAL reasoning you used, not boilerplate.\n"
        "- Cite ONLY chunk IDs listed above; never invent IDs.\n"
        "- Do not include a step that just says 'synthesized the answer' with no substance.\n"
        "Return raw JSON only — no markdown fences, no prose before or after."
    )

    prompt = (
        f"{system_prompt}\n\n"
        f"{format_instruction}\n\n"
        f"{citation_instruction}\n\n"
        "Answer the QUESTION using only the CONTEXT below. Do NOT introduce outside knowledge. "
        "If the context doesn't fully answer the question, say so clearly.\n\n"
        f"CONTEXT:\n{context_text}\n\n"
        f"QUESTION: {query}\n\n"
        f"{reasoning_instruction}\n"
    )
    from daan.llm.llm_provider import get_llm_response_with_fallback

    raw = get_llm_response_with_fallback(prompt)
    parsed = _parse_answer_with_reasoning(raw)
    if parsed is None:
        return _clean_answer_text(raw), []

    answer_text = _clean_answer_text(str(parsed.get("answer") or "").strip())
    steps = _normalize_reasoning_steps(parsed.get("reasoning_steps"), valid_chunk_ids)
    return answer_text, steps


def _parse_answer_with_reasoning(raw: str) -> dict[str, Any] | None:
    """Best-effort extraction of a JSON object with 'answer' and 'reasoning_steps'."""
    if not raw:
        return None
    text = raw.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
        text = text.strip()
    try:
        obj = json.loads(text)
    except (json.JSONDecodeError, ValueError):
        start = text.find("{")
        end = text.rfind("}")
        if start == -1 or end == -1 or end <= start:
            return None
        try:
            obj = json.loads(text[start : end + 1])
        except (json.JSONDecodeError, ValueError):
            return None
    if not isinstance(obj, dict):
        return None
    if "answer" not in obj or "reasoning_steps" not in obj:
        return None
    return obj


def _normalize_reasoning_steps(
    raw_steps: Any, valid_chunk_ids: list[str]
) -> list[dict[str, Any]]:
    if not isinstance(raw_steps, list):
        return []
    valid_set = set(valid_chunk_ids)
    steps: list[dict[str, Any]] = []
    for index, item in enumerate(raw_steps, start=1):
        if not isinstance(item, dict):
            continue
        title = str(item.get("title") or "").strip()
        detail = str(item.get("detail") or "").strip()
        if not title and not detail:
            continue
        raw_ids = item.get("chunk_ids") or []
        chunk_ids: list[str] = []
        if isinstance(raw_ids, list):
            for chunk_id in raw_ids:
                cid = str(chunk_id or "").strip()
                if cid and cid in valid_set and cid not in chunk_ids:
                    chunk_ids.append(cid)
        steps.append(
            {
                "step": index,
                "title": title or f"Step {index}",
                "detail": detail,
                "chunk_ids": chunk_ids,
            }
        )
    return steps


def _greeting_reply(query: str, system_prompt: str) -> str:
    """Answer greetings/small-talk conversationally, without RAG retrieval or forced formatting."""
    prompt = (
        f"{system_prompt}\n\n"
        "The user sent a greeting or small-talk message, not a real question. "
        "Reply with a short, friendly, conversational sentence or two — no headings, "
        "no 'Summary' label, no markdown structure, no mention of documents or context.\n\n"
        f"USER MESSAGE: {query}\n\nREPLY:"
    )
    from daan.llm.llm_provider import get_llm_response_with_fallback

    return _clean_answer_text(get_llm_response_with_fallback(prompt))


def _answer_from_session_context(
    query: str,
    system_prompt: str,
    chat_history_text: str = "",
    uploaded_context_text: str = "",
) -> str:
    sections: list[str] = []
    if chat_history_text.strip():
        sections.append(f"PRIOR CHAT HISTORY:\n{chat_history_text.strip()}")
    if uploaded_context_text.strip():
        sections.append(f"UPLOADED DOCUMENT CONTEXT FROM THIS SESSION:\n{uploaded_context_text.strip()}")

    if not sections:
        return "There is not enough session context available yet to answer that from this chat alone."

    session_context = "\n\n".join(sections)
    prompt = (
        f"{system_prompt}\n\n"
        "Answer the USER REQUEST using ONLY the current chat session context below. Base the answer "
        "primarily on PRIOR CHAT HISTORY. Use UPLOADED DOCUMENT CONTEXT only when it belongs to this same "
        "session and materially supports the answer. Do NOT retrieve or rely on unrelated knowledge-base "
        "content. If no uploaded documents were part of this session, do not mention supporting documents.\n"
        "Follow the user's requested format dynamically: for a summary or recap, produce a structured "
        "markdown summary; for a direct question, answer it directly from the session context. "
        "If the session context does not contain the needed information, say so clearly instead of "
        "inferring from external knowledge.\n\n"
        f"SESSION CONTEXT:\n{session_context}\n\n"
        f"USER REQUEST: {query}\n\nANSWER:"
    )

    from daan.llm.llm_provider import get_llm_response_with_fallback  # lazy import

    return get_llm_response_with_fallback(prompt).strip()


@router.get("/sessions")
def list_sessions(
    db: Annotated[Session, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    sessions = (
        db.query(ChatSession)
        .filter(ChatSession.user_id == current_user.id)
        .order_by(ChatSession.updated_at.desc())
        .all()
    )
    for session in sessions:
        messages = session.messages
        last = messages[-1].content if messages else ""
        out.append(
            {
                "id": session.id,
                "title": session.title,
                "lastMessage": (last or "")[:80],
                "timestamp": session.updated_at.isoformat() if session.updated_at else None,
                "messageCount": len(messages),
            }
        )

    for session_dir in list_session_dirs():
        session_id = session_dir.name
        manifest = read_chat_session_manifest(session_id)
        if not manifest:
            continue
        if manifest.get("user_id") not in (None, current_user.id):
            continue
        records = read_chat_session_messages(session_id, limit=200)
        last = str(records[-1].get("content") or "") if records else ""
        updated_at = str(manifest.get("updated_at") or "").strip() or None
        out.append(
            {
                "id": session_id,
                "title": str(manifest.get("usecase_id") or "Chat Agent").strip() or "Chat Agent",
                "lastMessage": last[:80],
                "timestamp": updated_at,
                "messageCount": len(records),
            }
        )

    out.sort(key=lambda item: str(item.get("timestamp") or ""), reverse=True)
    return out


@router.post("/sessions", response_model=CreateSessionResponse)
def create_session(
    db: Annotated[Session, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> CreateSessionResponse:
    session = ChatSession(
        id=_generate_chat_session_id(),
        user_id=current_user.id,
        title="New Chat",
    )
    db.add(session)
    db.commit()
    return CreateSessionResponse(id=session.id, title=session.title)


@router.get("/sessions/{session_id}/messages")
def get_session_messages(
    session_id: str,
    db: Annotated[Session, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> list[dict[str, Any]]:
    def _parse_references_payload(value: str | None) -> dict[str, Any] | None:
        if not value:
            return None
        try:
            parsed = json.loads(value)
        except (TypeError, ValueError, json.JSONDecodeError):
            return None
        if isinstance(parsed, dict):
            return parsed
        if isinstance(parsed, list):
            return {"reference_ids": [str(item) for item in parsed if item]}
        return None

    manifest = read_chat_session_manifest(session_id)
    if manifest:
        owner_user_id = manifest.get("user_id")
        if owner_user_id not in (None, current_user.id):
            raise HTTPException(status_code=403, detail="Not your session")

        records = read_chat_session_messages(session_id, limit=0)
        return [
            {
                "id": str(index + 1),
                "role": str(record.get("role") or ""),
                "content": str(record.get("content") or ""),
                "timestamp": record.get("timestamp"),
                "metadata": dict(record.get("metadata") or {}) if isinstance(record.get("metadata"), dict) else None,
            }
            for index, record in enumerate(records)
            if str(record.get("content") or "").strip()
        ]

    session = db.get(ChatSession, session_id)
    if session is not None and session.user_id not in (None, current_user.id):
        raise HTTPException(status_code=403, detail="Not your session")
    messages = (
        db.query(ChatMessage)
        .filter(ChatMessage.session_id == session_id)
        .order_by(ChatMessage.id)
        .all()
    )
    return [
        {
            "id": str(m.id),
            "role": m.role,
            "content": m.content,
            "timestamp": m.created_at.isoformat() if m.created_at else None,
            "metadata": _parse_references_payload(m.references_json),
        }
        for m in messages
    ]


@router.delete("/sessions/{session_id}")
def delete_session(
    session_id: str,
    db: Annotated[Session, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> dict[str, Any]:
    manifest = read_chat_session_manifest(session_id)
    if manifest:
        owner_user_id = manifest.get("user_id")
        if owner_user_id not in (None, current_user.id):
            raise HTTPException(status_code=403, detail="Not your session")
        delete_session_dir(session_id)
        return {"deleted": True, "id": session_id}

    session = db.get(ChatSession, session_id)
    if session is None:
        return {"deleted": False, "id": session_id}
    if session.user_id not in (None, current_user.id):
        raise HTTPException(status_code=403, detail="Not your session")
    db.delete(session)
    db.commit()
    return {"deleted": True, "id": session_id}


@router.post("/message")
async def send_message(
    db: Annotated[Session, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_active_user)],
    message: str = Form(...),
    session_id: str = Form(...),
    usecase_id: str | None = Form(default=None),
    kb_id: str | None = Form(default=None),
    files: list[UploadFile] = File(default=[]),
) -> dict[str, Any]:
    """Answer a chat message from the DAAN KB and persist the exchange.

    `usecase_id` (optional) scopes retrieval to a single use case. File attachments
    are accepted but not yet ingested (planned) — answers come from the DAAN KB.
    """
    if not message or not message.strip():
        raise HTTPException(status_code=400, detail="Message is required")

    normalized_usecase_id = _normalize_usecase_id(usecase_id)
    _chat_manifest, effective_chat_usecase_id = _resolve_chat_agent_session_request(
        session_id=session_id,
        requested_usecase_id=normalized_usecase_id,
        current_user_id=current_user.id,
    )
    if effective_chat_usecase_id and _is_chat_agent_usecase(effective_chat_usecase_id):
        return await _handle_chat_agent_message(
            db=db,
            current_user=current_user,
            session_id=session_id,
            message=message.strip(),
            usecase_id=effective_chat_usecase_id,
            kb_id=_normalize_kb_id(kb_id),
            user_id=current_user.id,
            files=files,
        )

    current_upload_context_text = ""

    # Ensure the session exists for this user.
    session = db.get(ChatSession, session_id)
    if session is None:
        session = ChatSession(id=session_id, user_id=current_user.id, title=message.strip()[:40])
        db.add(session)
    elif session.user_id not in (None, current_user.id):
        raise HTTPException(status_code=403, detail="Not your session")
    elif session.title == "New Chat":
        session.title = message.strip()[:40]

    db.add(ChatMessage(session_id=session_id, role="user", content=message.strip()))
    if files:
        new_uploaded_context = await extract_uploaded_context(files)
        current_upload_context_text = new_uploaded_context
        session.uploaded_context_text = append_uploaded_context(
            session.uploaded_context_text,
            new_uploaded_context,
        )
    session.updated_at = datetime.utcnow()
    db.commit()

    recent_messages = (
        db.query(ChatMessage)
        .filter(ChatMessage.session_id == session_id)
        .order_by(ChatMessage.id)
        .all()
    )
    query_text = message.strip()
    chat_history_text = build_chat_history_text(
        recent_messages,
        query=query_text,
    )
    uploaded_context_text = select_relevant_uploaded_context(
        query_text,
        session.uploaded_context_text,
        preferred_context_text=current_upload_context_text,
    )
    retrieval_chat_context = build_retrieval_chat_context(query_text, chat_history_text)

    # Retrieve from the DAAN KB (optionally scoped to a use case) and synthesize.
    settings = get_settings()
    rag_config = settings.load_rag_config()
    requested_kb_id = _normalize_kb_id(kb_id)
    resolved_kb_id = _resolve_standard_chat_kb_id(requested_kb_id, rag_config)
    kb_config = _resolve_kb_config(rag_config, resolved_kb_id)
    if kb_config is None or not user_has_access_to_kb(db, current_user, resolved_kb_id, kb_config=kb_config):
        raise HTTPException(status_code=403, detail=f"Not authorized to access knowledge base '{resolved_kb_id}'.")
    effective_rag_config = _build_chat_rag_config(rag_config, resolved_kb_id)
    tool = RagTool(effective_rag_config)
    metadata_filter = {"usecase_id": normalized_usecase_id} if normalized_usecase_id else None
    retriever_type = _resolve_chat_retriever_type(effective_rag_config, resolved_kb_id)
    # Explicit KB chat should keep full explainability/graph traces even when the
    # selected knowledge base is the default DAAN KB.
    should_include_kb_explainability = bool(requested_kb_id)
    should_use_session_context_only = is_session_context_query(message.strip())
    should_answer_as_greeting = is_greeting_or_smalltalk_query(message.strip())

    # Retrieve enhanced feedback (query expansion + answer shaping)
    from daan.chat.chat_feedback_service import retrieve_enhanced_feedback
    enhanced_feedback = retrieve_enhanced_feedback(message.strip(), current_user.id, kb_id=resolved_kb_id)
    feedback_context = enhanced_feedback.answer_instructions

    try:
        query_link = _query_link(query_text)
        trace_id = ""
        latency_ms = 0
        evidence_available = False
        explainability: dict[str, Any] | None = None

        # Build expanded query from feedback-derived terms
        expanded_query = query_text
        if enhanced_feedback.query_expansion_terms:
            expansion = " ".join(enhanced_feedback.query_expansion_terms)
            expanded_query = f"{query_text} {expansion}"
        effective_k = 8 + enhanced_feedback.extra_k

        if should_answer_as_greeting:
            answer = _greeting_reply(
                query_text,
                _resolve_system_prompt(rag_config, resolved_kb_id),
            )
            references = []
        elif should_use_session_context_only:
            answer = _answer_from_session_context(
                query_text,
                _resolve_system_prompt(rag_config, resolved_kb_id),
                chat_history_text=chat_history_text,
                uploaded_context_text=uploaded_context_text,
            )
            references = []
        elif should_include_kb_explainability:
            t_start = time.monotonic()
            search_kwargs: dict[str, Any] = {
                "query": expanded_query,
                "k": effective_k,
                "retriever_type": retriever_type,
                "kb_id": resolved_kb_id,
                "query_link": query_link,
                "metadata_filter": metadata_filter,
                "include_explainability": True,
            }
            if retrieval_chat_context:
                search_kwargs["chat_context"] = retrieval_chat_context
            raw_payload = tool.search_documents(**search_kwargs)
            retrieval_latency_ms = int((time.monotonic() - t_start) * 1000)
            payload = dict(raw_payload if isinstance(raw_payload, dict) else {})
            raw_docs = payload.get("results", [])
            docs = [SearchResult(**doc) for doc in raw_docs]
            final_context = _build_final_context(
                [part for part in [chat_history_text, uploaded_context_text, *[doc.content for doc in docs]] if part]
            )
            system_prompt = _resolve_system_prompt(rag_config, resolved_kb_id)
            t_synth_start = time.monotonic()
            answer, reasoning_steps = synthesize_kb_answer(
                query_text,
                docs,
                system_prompt,
                chat_history_text=chat_history_text,
                uploaded_context_text=uploaded_context_text,
                feedback_context=feedback_context,
            )
            answer_generation_ms = int((time.monotonic() - t_synth_start) * 1000)
            t_explain_start = time.monotonic()
            explainability = _build_explainability_payload(
                payload.get("explainability") if isinstance(payload.get("explainability"), dict) else None,
                query_link,
                retriever_type,
                latency_ms,
                docs,
                answer,
                final_context,
                reasoning_steps,
            )
            explainability_ms = int((time.monotonic() - t_explain_start) * 1000)
            latency_ms = retrieval_latency_ms + answer_generation_ms + explainability_ms
            timing_breakdown = dict(explainability.get("timing_breakdown", {}) or {})
            timing_breakdown["answer_generation_ms"] = answer_generation_ms
            timing_breakdown["explainability_ms"] = explainability_ms
            explainability["timing_breakdown"] = timing_breakdown
            explainability["latency_ms"] = latency_ms
            evidence = build_trace_evidence_envelope(
                tool.get_last_evidence_envelope(query_text),
                session_id=resolved_kb_id,
                query=query_text,
                query_link=query_link,
                retriever_type=retriever_type,
                latency_ms=latency_ms,
                selected_references=list(explainability.get("selected_references", [])) if explainability else [],
                selected_source_ids=list(explainability.get("final_selected_chunk_ids", [])) if explainability else [doc.id for doc in docs],
            )
            trace = RagTrace(
                evidence=evidence,
                query=query_text,
                query_link=query_link,
                retrieved_docs=[doc.content[:200] for doc in docs],
                reranked_docs=[doc.content[:200] for doc in docs],
                final_context=final_context,
                retriever_type=retriever_type,
                latency_ms=latency_ms,
                session_id=resolved_kb_id,
                owner_user_id=current_user.id,
                origin_session_id=session_id,
                seed_chunk_ids=list(explainability.get("seed_chunk_ids", [])) if explainability else [],
                traversal_hops=list(explainability.get("traversal_hops", [])) if explainability else [],
                visited_node_ids=list(explainability.get("visited_node_ids", [])) if explainability else [],
                edge_list=list(explainability.get("edge_list", [])) if explainability else [],
                final_selected_chunk_ids=list(explainability.get("final_selected_chunk_ids", [])) if explainability else [doc.id for doc in docs],
                explainability=_strip_graph_payload(explainability) if explainability else {},
                graph_nodes=list(explainability.get("graph_nodes", [])) if explainability else _build_fallback_graph_nodes(query_link, docs),
                graph_edges=list(explainability.get("graph_edges", [])) if explainability else _build_fallback_graph_edges(query_link, docs),
            )
            trace_id = trace.trace_id
            tracer.record(trace)
            evidence_available = True
            references = [doc.id for doc in docs]
        else:
            t_start = time.monotonic()
            search_kwargs = {
                "query": expanded_query,
                "k": effective_k,
                "retriever_type": retriever_type,
                "kb_id": resolved_kb_id,
                "metadata_filter": metadata_filter,
            }
            if retrieval_chat_context:
                search_kwargs["chat_context"] = retrieval_chat_context
            docs = tool.search_documents(**search_kwargs)
            retrieval_latency_ms = int((time.monotonic() - t_start) * 1000)
            t_synth_start = time.monotonic()
            answer, reasoning_steps = _synthesize_chat_answer(
                query_text,
                docs,
                _resolve_system_prompt(rag_config, resolved_kb_id),
                chat_history_text=chat_history_text,
                uploaded_context_text=uploaded_context_text,
                feedback_context=feedback_context,
            )
            answer_generation_ms = int((time.monotonic() - t_synth_start) * 1000)
            t_explain_start = time.monotonic()
            trace_docs = [doc if isinstance(doc, SearchResult) else SearchResult(**doc) for doc in docs]
            final_context = _build_final_context(
                [part for part in [chat_history_text, uploaded_context_text, *[doc.content for doc in trace_docs]] if part]
            )
            explainability = _build_explainability_payload(
                None,
                query_link,
                retriever_type,
                retrieval_latency_ms,
                trace_docs,
                answer,
                final_context,
                reasoning_steps or _build_reasoning_steps(query_text, trace_docs),
            )
            explainability_ms = int((time.monotonic() - t_explain_start) * 1000)
            latency_ms = retrieval_latency_ms + answer_generation_ms + explainability_ms
            timing_breakdown = dict(explainability.get("timing_breakdown", {}) or {})
            timing_breakdown["answer_generation_ms"] = answer_generation_ms
            timing_breakdown["explainability_ms"] = explainability_ms
            explainability["timing_breakdown"] = timing_breakdown
            explainability["latency_ms"] = latency_ms
            evidence = build_trace_evidence_envelope(
                tool.get_last_evidence_envelope(query_text),
                session_id=resolved_kb_id,
                query=query_text,
                query_link=query_link,
                retriever_type=retriever_type,
                latency_ms=latency_ms,
                selected_references=list(explainability.get("selected_references", [])) if explainability else [],
                selected_source_ids=list(explainability.get("final_selected_chunk_ids", [])) if explainability else [doc.id for doc in trace_docs],
            )
            trace = RagTrace(
                evidence=evidence,
                query=query_text,
                query_link=query_link,
                retrieved_docs=[doc.content[:200] for doc in trace_docs],
                reranked_docs=[doc.content[:200] for doc in trace_docs],
                final_context=final_context,
                retriever_type=retriever_type,
                latency_ms=latency_ms,
                session_id=resolved_kb_id,
                owner_user_id=current_user.id,
                origin_session_id=session_id,
                seed_chunk_ids=list(explainability.get("seed_chunk_ids", [])) if explainability else [],
                traversal_hops=list(explainability.get("traversal_hops", [])) if explainability else [],
                visited_node_ids=list(explainability.get("visited_node_ids", [])) if explainability else [],
                edge_list=list(explainability.get("edge_list", [])) if explainability else [],
                final_selected_chunk_ids=list(explainability.get("final_selected_chunk_ids", [])) if explainability else [doc.id for doc in trace_docs],
                explainability=_strip_graph_payload(explainability) if explainability else {},
                graph_nodes=list(explainability.get("graph_nodes", [])) if explainability else _build_fallback_graph_nodes(query_link, trace_docs),
                graph_edges=list(explainability.get("graph_edges", [])) if explainability else _build_fallback_graph_edges(query_link, trace_docs),
            )
            trace_id = trace.trace_id
            tracer.record(trace)
            evidence_available = True
            references = [d["id"] for d in docs]
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"Chat failed: {exc}") from exc

    assistant_metadata = {
        "reference_ids": references,
        "kb_id": resolved_kb_id,
    }
    if evidence_available:
        assistant_metadata.update(
            {
                "trace_id": trace_id,
                "query_link": query_link,
                "retriever_type": retriever_type,
                "evidence_available": True,
            }
        )
    if explainability:
        assistant_metadata.update(
            {
                "trace_id": trace_id,
                "query_link": query_link,
                "retriever_type": retriever_type,
                "explainability_available": True,
                "selected_references": list(explainability.get("selected_references", [])),
            }
        )

    db.add(
        ChatMessage(
            session_id=session_id,
            role="assistant",
            content=answer,
            references_json=json.dumps(assistant_metadata),
        )
    )
    session.updated_at = datetime.utcnow()
    db.commit()

    return {
        "response": answer,
        "references": references,
        "session_id": session_id,
        "metadata": assistant_metadata,
    }


# ---------------------------------------------------------------------------
# Chat Feedback: Enhanced feedback storage and retrieval
# ---------------------------------------------------------------------------


class FeedbackRequest(BaseModel):
    """Request body for submitting chat feedback."""
    original_query: str
    bot_response: str
    session_id: str
    is_positive: bool
    feedback_text: str | None = None
    kb_id: str | None = None


@router.post("/feedback")
async def submit_chat_feedback(
    request: FeedbackRequest,
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> dict[str, Any]:
    """Store user feedback for a chat response.

    Thumbs-down with text: embeds query + feedback together in pgvector so future
    similar queries can both retrieve better content AND shape the answer.
    """
    if request.is_positive:
        return {"status": "ok", "message": "Positive feedback noted"}

    if not request.feedback_text or not request.feedback_text.strip():
        return {"status": "ok", "message": "No feedback text provided"}

    try:
        from daan.chat.chat_feedback_service import TurnFeedback, store_turn_feedback

        doc_id = store_turn_feedback(TurnFeedback(
            original_query=request.original_query,
            bot_response=request.bot_response,
            session_id=request.session_id,
            user_id=current_user.id,
            is_positive=False,
            feedback_text=request.feedback_text.strip(),
            kb_id=_normalize_kb_id(request.kb_id),
        ))

        if doc_id:
            return {"status": "ok", "message": "Feedback saved successfully", "doc_id": doc_id}
        return {"status": "ok", "message": "Feedback noted (no text stored)"}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to save feedback: {exc}") from exc
