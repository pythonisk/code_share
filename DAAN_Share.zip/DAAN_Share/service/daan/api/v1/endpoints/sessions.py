"""Session lifecycle endpoints — create session, serve session files."""

import io
import mimetypes
import zipfile
from typing import Annotated, Literal
from pathlib import Path
from datetime import datetime
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, File, UploadFile, Form
from fastapi.responses import PlainTextResponse, FileResponse, StreamingResponse
from pydantic import BaseModel
from uuid import uuid4

from daan.core.dependencies import get_current_active_user, require_admin
from daan.core.logging import get_logger
from daan.utils.log_sanitizer import sanitize_log_lines
from daan.flow.session_service import (
    read_chat_session_manifest,
    create_session_dir,
    get_artifacts_dir,
    get_session_dir,
    list_artifact_files,
    list_session_files,
    read_session_file,
    read_session_log,
    write_chat_session_manifest,
)
from daan.flow.session_store import SessionState, create_session, get_session

router = APIRouter()
unfiltered_router = APIRouter()
logger = get_logger(__name__)


# ── Schemas ─────────────────────────────────────────────────────────────


class CreateSessionRequest(BaseModel):
    userid: str
    usecase_id: str | None = None
    archetype: str | None = None
    mode: Literal["workflow", "chat_agent"] = "workflow"
    kb_id: str | None = None


class CreateSessionResponse(BaseModel):
    session_id: str
    userid: str
    archetype: str


class SessionFilesResponse(BaseModel):
    session_id: str
    files: list[str]


class FileUploadResponse(BaseModel):
    session_id: str
    uploaded_files: list[str]
    message: str


class SessionLogResponse(BaseModel):
    session_id: str
    lines: list[str]
    truncated: bool
    redaction_summary: dict[str, int]
    generated_at: str
    message_format: Literal["text"] = "text"
    has_artifacts: bool = False


class UnfilteredSessionLogResponse(BaseModel):
    session_id: str
    raw_log: str
    message_format: Literal["text"] = "text"


# ── Endpoints ───────────────────────────────────────────────────────────


@router.post("", response_model=CreateSessionResponse)
def create_session_route(
    request: CreateSessionRequest,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> CreateSessionResponse:
    """Create a new session: generate session_id, create disk folder, init in-memory store."""
    _ = current_user

    usecase_id = str(request.usecase_id or "").strip()
    archetype = str(request.archetype or "").strip()

    if request.mode == "workflow" and (not usecase_id or not archetype):
        raise HTTPException(
            status_code=422,
            detail="usecase_id and archetype are required for workflow sessions",
        )

    logger.info("Session creation requested", extra={
        "endpoint": "/sessions",
        "userid": request.userid,
        "archetype": archetype,
        "usecase_id": usecase_id,
        "mode": request.mode,
        "kb_id": request.kb_id,
    })

    session_id = str(uuid4())

    # Create disk-backed session directory
    create_session_dir(session_id)

    # Initialize in-memory session store
    create_session(
        session_id=session_id,
        user_id=getattr(current_user, "id", None),
        archetype=archetype,
        usecase_id=usecase_id,
    )

    if request.mode == "chat_agent":
        write_chat_session_manifest(
            session_id,
            user_id=getattr(current_user, "id", None),
            archetype=archetype,
            usecase_id=usecase_id,
            kb_id=str(request.kb_id or "").strip() or "daan",
        )

    logger.info("Session created successfully", extra={
        "session_id": session_id,
        "endpoint": "/sessions",
        "userid": request.userid,
        "archetype": archetype,
        "usecase_id": usecase_id,
        "mode": request.mode,
        "kb_id": request.kb_id,
    })

    return CreateSessionResponse(
        session_id=session_id,
        userid=request.userid,
        archetype=archetype,
    )


@router.post("/{session_id}/upload-files", response_model=FileUploadResponse)
def upload_files_to_session(
    session_id: str,
    files: list[UploadFile] = File(...),
    current_user: Annotated[object, Depends(get_current_active_user)] = None,
) -> FileUploadResponse:
    """Upload files to a specific session's inputs directory."""
    _ = current_user
    
    logger.info("File upload requested", extra={
        "session_id": session_id,
        "endpoint": "/upload-files",
        "file_count": len(files),
        "filenames": [f.filename for f in files if f.filename]
    })
    
    # Verify session exists
    session_dir = get_session_dir(session_id)
    if session_dir is None:
        logger.warning("File upload attempted for non-existent session", extra={
            "session_id": session_id,
            "endpoint": "/upload-files"
        })
        raise HTTPException(status_code=404, detail="Session not found")
    
    inputs_dir = session_dir / "inputs"
    inputs_dir.mkdir(exist_ok=True)
    
    uploaded_files = []
    
    try:
        for file in files:
            if not file.filename:
                continue
                
            # Save file to session inputs directory
            file_path = inputs_dir / file.filename
            
            with open(file_path, "wb") as buffer:
                content = file.file.read()
                buffer.write(content)
            
            uploaded_files.append(file.filename)
            
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to upload files: {str(e)}"
        )
    
    logger.info("Files uploaded successfully", extra={
        "session_id": session_id,
        "endpoint": "/upload-files",
        "uploaded_count": len(uploaded_files),
        "uploaded_files": uploaded_files
    })

    manifest = read_chat_session_manifest(session_id)
    if manifest:
        usecase_id = str(manifest.get("usecase_id") or "").strip()
        archetype = str(manifest.get("archetype") or "").strip()
        if usecase_id:
            try:
                from daan.flow.supervisor import ContextMapper
                from daan.usecases.usecase_service import get_usecase_details

                details = get_usecase_details(archetype, usecase_id)
                agents = details.get("agents", []) or []
                if agents:
                    context_map_result = ContextMapper.run_detailed(
                        agents=agents,
                        usecase_details=details.get("usecase_details", {}),
                        session_id=session_id,
                    )
                    existing = get_session(session_id)
                    if existing is None:
                        existing = create_session(
                            session_id=session_id,
                            user_id=getattr(current_user, "id", None),
                            archetype=archetype,
                            usecase_id=usecase_id,
                            context_map_result=context_map_result,
                        )
                    else:
                        existing.context_map_result = context_map_result
                        if archetype:
                            existing.archetype = archetype
                        existing.usecase_id = usecase_id
                        existing.touch()
                    existing.context_map_output_path = f"session_storage/{session_id}/context_map_output.json"
                    existing.state = SessionState.CONTEXT_MAPPED
                    existing.touch()
            except Exception as exc:
                logger.warning(
                    "Chat-agent context refresh after upload failed: %s",
                    exc,
                    extra={"session_id": session_id, "endpoint": "/upload-files"},
                )
    
    return FileUploadResponse(
        session_id=session_id,
        uploaded_files=uploaded_files,
        message=f"Successfully uploaded {len(uploaded_files)} files"
    )


@router.get("/{session_id}/files", response_model=SessionFilesResponse)
def list_session_files_route(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> SessionFilesResponse:
    """List all output files in a session directory."""
    _ = current_user

    logger.info("Session files list requested", extra={
        "session_id": session_id,
        "endpoint": "/files"
    })

    session_dir = get_session_dir(session_id)
    if session_dir is None:
        logger.warning("File list requested for non-existent session", extra={
            "session_id": session_id,
            "endpoint": "/files"
        })
        raise HTTPException(status_code=404, detail="Session directory not found.")

    files = list_session_files(session_id)

    # Also include files from the artifacts/ subdirectory as relative paths
    # so the frontend can serve them via GET /{session_id}/files/{path}
    artifact_paths = [
        str(p.relative_to(session_dir)).replace("\\", "/")
        for p in list_artifact_files(session_id)
    ]
    all_files = files + [p for p in artifact_paths if p not in files]

    logger.info("Session files listed successfully", extra={
        "session_id": session_id,
        "endpoint": "/files",
        "file_count": len(all_files),
    })

    return SessionFilesResponse(session_id=session_id, files=all_files)


@router.get("/{session_id}/files/{file_path:path}")
def serve_session_file(
    session_id: str,
    file_path: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
):
    """Serve any file from the session directory tree.

    Supports sub-paths (e.g. ``agents/AGENT_1/output.md``) and binary files
    (e.g. ``.zip``, ``.csv``, ``.docx``).  The response Content-Type is
    derived from the file extension.
    """
    _ = current_user

    logger.info("Session file requested", extra={
        "session_id": session_id,
        "endpoint": "/files/{file_path}",
        "file_path": file_path
    })

    session_dir = get_session_dir(session_id)
    if session_dir is None:
        raise HTTPException(status_code=404, detail="Session not found.")

    target = (session_dir / file_path).resolve()

    # Guard against path traversal
    if not target.is_relative_to(session_dir.resolve()):
        raise HTTPException(status_code=400, detail="Invalid file path.")

    if not target.is_file():
        raise HTTPException(status_code=404, detail=f"File '{file_path}' not found in session.")

    media_type, _ = mimetypes.guess_type(target.name)
    if media_type is None:
        media_type = "application/octet-stream"

    logger.info("Session file served successfully", extra={
        "session_id": session_id,
        "endpoint": "/files/{file_path}",
        "file_path": file_path,
        "media_type": media_type
    })

    # For text-like types, read and return as PlainTextResponse for backward compat.
    # For everything else, use FileResponse which handles streaming and headers.
    _TEXT_TYPES = {"application/json", "text/plain", "text/markdown", "text/csv", "text/html"}
    if media_type in _TEXT_TYPES or media_type.startswith("text/"):
        try:
            content = target.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            content = target.read_text(encoding="utf-8", errors="replace")
        return PlainTextResponse(content=content, media_type=media_type)

    return FileResponse(
        path=target,
        media_type=media_type,
        filename=target.name,
    )


@router.get("/{session_id}/download-artifacts")
def download_artifacts(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
):
    """Download all artifacts produced by a session's tools/agents.

    Behavior:
    - 0 files  -> 404
    - 1 file   -> serve it directly (preserves original format)
    - N files  -> zip them on the fly and stream back
    """
    _ = current_user

    logger.info("Artifact download requested", extra={
        "session_id": session_id,
        "endpoint": "/download-artifacts"
    })

    artifacts = list_artifact_files(session_id)

    if not artifacts:
        raise HTTPException(
            status_code=404,
            detail="No artifacts found for this session. Run the pipeline first.",
        )

    artifacts_dir = get_artifacts_dir(session_id)

    # ── Single file: serve directly ───────────────────────────────
    if len(artifacts) == 1:
        single = artifacts[0]
        media_type, _ = mimetypes.guess_type(single.name)
        if media_type is None:
            media_type = "application/octet-stream"

        logger.info("Serving single artifact", extra={
            "session_id": session_id,
            "artifact_name": single.name,
        })
        return FileResponse(
            path=single,
            media_type=media_type,
            filename=single.name,
        )

    # ── Multiple files: zip on the fly ────────────────────────────
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for file_path in artifacts:
            arcname = str(file_path.relative_to(artifacts_dir))
            zf.write(file_path, arcname=arcname)
    buf.seek(0)

    zip_name = f"artifacts_{session_id[:8]}.zip"
    logger.info("Serving zipped artifacts", extra={
        "session_id": session_id,
        "file_count": len(artifacts),
        "zip_name": zip_name,
    })

    return StreamingResponse(
        iter([buf.read()]),
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{zip_name}"'},
    )


@router.get("/{session_id}/download-agent-outputs")
def download_agent_outputs(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
):
    """Download a session's deliverables as a zip.

    Bundles every agent output markdown file (recursively, under ``agents/``)
    together with any generated artifacts of any type (CSV, XLSX, JSON, images,
    etc.) that agents wrote to the session ``artifacts/`` folder. This is fully
    generic — nothing is hardcoded per use case, so a synthetic-data run's CSV or
    any other produced file is captured automatically.
    """
    _ = current_user

    logger.info("Agent outputs download requested", extra={
        "session_id": session_id,
        "endpoint": "/download-agent-outputs"
    })

    session_dir = get_session_dir(session_id)
    if session_dir is None:
        raise HTTPException(status_code=404, detail="Session directory not found.")

    # Agent output markdown files (preserve their AGENT_x/... layout in the zip).
    agents_dir = session_dir / "agents"
    md_files = list(agents_dir.rglob("*.md")) if agents_dir.is_dir() else []

    # Generated artifacts of any type (e.g. synthetic-data CSVs) live under the
    # session's artifacts/ folder. Include all of them regardless of extension.
    artifacts_dir = get_artifacts_dir(session_id)
    artifact_files = list_artifact_files(session_id)

    if not md_files and not artifact_files:
        raise HTTPException(
            status_code=404,
            detail="No agent outputs or artifacts found for this session.",
        )

    # Zip them on the fly, namespacing each group so filenames never collide.
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for file_path in md_files:
            arcname = f"agents/{file_path.relative_to(agents_dir)}"
            zf.write(file_path, arcname=arcname)
        for file_path in artifact_files:
            arcname = f"artifacts/{file_path.relative_to(artifacts_dir)}"
            zf.write(file_path, arcname=arcname)
    buf.seek(0)

    zip_name = f"session_outputs_{session_id[:8]}.zip"
    logger.info("Serving zipped session outputs", extra={
        "session_id": session_id,
        "agent_file_count": len(md_files),
        "artifact_file_count": len(artifact_files),
        "zip_name": zip_name,
    })

    return StreamingResponse(
        iter([buf.read()]),
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{zip_name}"'},
    )


@router.get("/{session_id}/session-log", response_model=SessionLogResponse)
def get_session_log_route(
    session_id: str,
    current_user: Annotated[object, Depends(require_admin)],
) -> SessionLogResponse:
    """Return a redacted copy of the per-session session.log.

    Security: Admin-only by default to reduce log exfiltration risk.
    """

    _ = current_user

    sid = (session_id or "").strip()
    if not sid:
        raise HTTPException(status_code=400, detail="session_id is required")

    max_bytes = 25_000_000

    try:
        lines, truncated = read_session_log(sid, max_bytes=max_bytes)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to read session log: {exc}") from exc

    redacted_lines, summary = sanitize_log_lines(lines)

    # Audit access without ever logging returned content.
    try:
        username = getattr(current_user, "username", None)
    except Exception:
        username = None

    logger.info(
        "Session log accessed",
        extra={
            "target_session_id": sid,
            "endpoint": "/sessions/{session_id}/session-log",
            "max_bytes": int(max_bytes),
            "returned_lines": len(redacted_lines),
            "truncated": bool(truncated),
            "redactions": summary,
            "username": username,
        },
    )

    artifacts_dir = get_artifacts_dir(sid)
    has_artifacts = artifacts_dir.is_dir() and any(artifacts_dir.iterdir())

    return SessionLogResponse(
        session_id=sid,
        lines=redacted_lines,
        truncated=bool(truncated),
        redaction_summary=summary,
        generated_at=datetime.utcnow().isoformat(),
        has_artifacts=has_artifacts,
    )


@unfiltered_router.get("/unfiltered-session-logs/{sessionId}", response_model=UnfilteredSessionLogResponse)
def get_unfiltered_session_logs_route(
    sessionId: str,
    current_user: Annotated[object, Depends(require_admin)],
) -> UnfilteredSessionLogResponse:
    """Return the raw per-session session.log without redaction.

    Security: Admin-only because this endpoint intentionally bypasses log redaction.
    """

    _ = current_user

    sid = (sessionId or "").strip()
    try:
        sid = str(UUID(sid))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="sessionId must be a valid UUID") from exc

    max_bytes = 25_000_000

    try:
        lines, _ = read_session_log(sid, max_bytes=max_bytes)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Session not found") from exc
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception(
            "Failed to read unfiltered session log",
            extra={"target_session_id": sid, "endpoint": "/unfiltered-session-logs/{sessionId}"},
        )
        raise HTTPException(status_code=500, detail="Failed to read unfiltered session log") from exc

    try:
        username = getattr(current_user, "username", None)
    except Exception:
        username = None

    logger.info(
        "Unfiltered session log accessed",
        extra={
            "target_session_id": sid,
            "endpoint": "/unfiltered-session-logs/{sessionId}",
            "max_bytes": int(max_bytes),
            "returned_lines": len(lines),
            "username": username,
        },
    )

    return UnfilteredSessionLogResponse(
        session_id=sid,
        raw_log="\n".join(lines),
    )
