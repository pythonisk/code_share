"""Metadata catalog endpoint.

GET /api/metadata
    Returns paginated agent / use-case / prompt metadata for archetype 8.
    Supports optional server-side filtering on usecase_name, agent_name, role.
"""

from __future__ import annotations

from typing import Annotated, List, Optional

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.orm import Session

from daan.core.database import get_db
from daan.core.dependencies import get_current_active_user

router = APIRouter()

# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------

class MetadataRow(BaseModel):
    usecase_name: Optional[str] = None
    agent_name: Optional[str] = None
    role: Optional[str] = None
    agent_actions: Optional[str] = None
    input_context: Optional[str] = None
    output_format: Optional[str] = None
    agent_type: Optional[str] = None
    local_tools: Optional[str] = None
    mcp_server: Optional[str] = None
    prompt_text: Optional[str] = None


class MetadataResponse(BaseModel):
    items: List[MetadataRow]
    total: int
    page: int
    page_size: int
    total_pages: int


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------

_BASE_SQL = """
    SELECT
        uc.name               AS usecase_name,
        ag.agent_name,
        ag.role,
        ag.agent_actions,
        ag.input_context,
        ag.output_format,
        ag.agent_type,
        ag.local_tools,
        ag.mcp_server,
        p.prompt_text
    FROM public.usecase_archetype_mapping ucarch
    JOIN public.usecases              uc   ON uc.usecaseid   = ucarch.usecase_id
    JOIN public.usecase_agent_mapping ucag ON ucarch.usecase_id = ucag.usecase_id
    JOIN public.agents                ag   ON ucag.agent_id  = ag.agent_id
    JOIN public.prompt                p    ON ag.prompt_id   = p.id
    WHERE ucarch.archetype_id = 8
"""


@router.get("/metadata", response_model=MetadataResponse)
def get_metadata(
    current_user: Annotated[object, Depends(get_current_active_user)],
    db: Session = Depends(get_db),
    usecase_name: Optional[str] = Query(None, description="Partial match on use-case name"),
    agent_name: Optional[str] = Query(None, description="Partial match on agent name"),
    role: Optional[str] = Query(None, description="Partial match on agent role"),
    page: int = Query(1, ge=1, description="1-based page number"),
    page_size: int = Query(20, ge=1, le=10000, description="Rows per page (use 10000 for full export)"),
) -> MetadataResponse:
    """Return paginated agent metadata with optional filters."""

    where_clauses: list[str] = []
    params: dict = {}

    if usecase_name and usecase_name.strip():
        where_clauses.append("LOWER(uc.name) LIKE :usecase_name")
        params["usecase_name"] = f"%{usecase_name.strip().lower()}%"

    if agent_name and agent_name.strip():
        where_clauses.append("LOWER(ag.agent_name) LIKE :agent_name")
        params["agent_name"] = f"%{agent_name.strip().lower()}%"

    if role and role.strip():
        where_clauses.append("LOWER(ag.role) LIKE :role")
        params["role"] = f"%{role.strip().lower()}%"

    sql_body = _BASE_SQL
    if where_clauses:
        sql_body += " AND " + " AND ".join(where_clauses)

    # Count total matching rows
    count_sql = f"SELECT COUNT(*) FROM ({sql_body}) AS _sub"
    total: int = db.execute(text(count_sql), params).scalar() or 0

    # Fetch the requested page
    offset = (page - 1) * page_size
    data_sql = sql_body + " ORDER BY uc.name, ag.agent_name LIMIT :_limit OFFSET :_offset"
    params["_limit"] = page_size
    params["_offset"] = offset

    rows = db.execute(text(data_sql), params).mappings().all()
    total_pages = max(1, (total + page_size - 1) // page_size)

    return MetadataResponse(
        items=[MetadataRow(**dict(row)) for row in rows],
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
    )
