"""Audit log endpoints.

GET /audit-log
    Returns the full audit trail, optionally filtered by usecase_id or
    agent_id.  Results are ordered newest-first.  A pre-built ``breadcrumb``
    field is included so the UI can render the
    ``"Use Case X > Agent Y > Prompt vN"`` label without any extra work.

GET /audit-log/usecases/{usecase_id}
    Convenience shortcut — equivalent to GET /audit-log?usecase_id=…
"""

from __future__ import annotations

from typing import Annotated, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from daan.core.database import get_db
from daan.core.dependencies import get_current_active_user
from daan.models.archetype import AuditLog
from daan.schemas.archetype import AuditLogEntry
from sqlalchemy import or_

router = APIRouter()


def _row_to_entry(row: AuditLog) -> AuditLogEntry:
    return AuditLogEntry(
        id=row.id,
        usecase_name=row.usecase_name,
        usecase_id=row.usecase_id,
        agent_name=row.agent_name,
        agent_id=row.agent_id,
        prompt_version=row.prompt_version,
        prompt_preview=row.prompt_preview,
        action=row.action,
        changed_by_username=row.changed_by_username,
        changed_at=row.changed_at,
        changes=row.changes,
    )


@router.get("/audit-log", response_model=list[AuditLogEntry])
def get_audit_log(
    current_user: Annotated[object, Depends(get_current_active_user)],
    db: Session = Depends(get_db),
    usecase: Optional[str] = Query(None, description="Filter by use case name or ID (partial match)"),
    agent: Optional[str] = Query(None, description="Filter by agent name or ID (partial match)"),
    action: Optional[str] = Query(None, description="Filter by exact action label"),
    limit: int = Query(200, ge=1, le=500, description="Max rows to return"),
    offset: int = Query(0, ge=0, description="Pagination offset"),
) -> list[AuditLogEntry]:
    """Return audit log entries, newest first."""
    _ = current_user
    query = db.query(AuditLog).order_by(AuditLog.changed_at.desc())

    if usecase:
        query = query.filter(
            or_(
                AuditLog.usecase_name.ilike(f"%{usecase}%"),
                AuditLog.usecase_id.ilike(f"%{usecase}%"),
            )
        )
    if agent:
        query = query.filter(
            or_(
                AuditLog.agent_name.ilike(f"%{agent}%"),
                AuditLog.agent_id.ilike(f"%{agent}%"),
            )
        )
    if action:
        query = query.filter(AuditLog.action == action)

    rows = query.offset(offset).limit(limit).all()
    return [_row_to_entry(r) for r in rows]


@router.get(
    "/audit-log/usecases/{usecase_id}",
    response_model=list[AuditLogEntry],
)
def get_audit_log_for_usecase(
    usecase_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
    db: Session = Depends(get_db),
    limit: int = Query(200, ge=1, le=500),
    offset: int = Query(0, ge=0),
) -> list[AuditLogEntry]:
    """Shortcut — audit trail for one use case, newest first."""
    _ = current_user
    rows = (
        db.query(AuditLog)
        .filter(AuditLog.usecase_id == usecase_id)
        .order_by(AuditLog.changed_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )
    return [_row_to_entry(r) for r in rows]
