"""Archetype endpoints."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException

from sqlalchemy.orm import Session
from sqlalchemy import text
from daan.archetypes.archetypes_service import list_archetypes
from daan.core.database import get_db
from daan.core.dependencies import get_current_active_user
from daan.schemas.archetype import ArchetypeResponse, ArchetypeRolesResponse, ArchetypeUpdate
from daan.models.user import User
from daan.models.archetype import Archetype
from daan.admin.user_service import has_edit_access_to_archetype
from daan.usecases.usecase_service import list_archetype_roles

router = APIRouter()


@router.get("")
def get_all_archetypes(
    db: Session = Depends(get_db),
):
    """Get all distinct archetypes."""
    result = db.query(Archetype).all()
    return [{"name": arch.name, "description": arch.description} for arch in result]


@router.get("/{archetype_name}/roles", response_model=ArchetypeRolesResponse)
def get_archetype_roles(
    archetype_name: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> ArchetypeRolesResponse:
    """Get distinct roles for an archetype from use case data."""
    _ = current_user
    try:
        roles = list_archetype_roles(archetype_name)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return ArchetypeRolesResponse(archetype=archetype_name, roles=roles)


@router.put("/{archetype_id}", response_model=ArchetypeResponse)
def edit_archetype(
    archetype_id: int,
    payload: ArchetypeUpdate,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> ArchetypeResponse:
    """Update archetype details (Developer/Admin check)."""
    # Check 1: Is user.role == 'Admin'?
    is_admin = current_user.role is not None and current_user.role.name == "Admin"
    
    # Check 2: Has 'edit' access level in user_archetype_assignment?
    has_edit = has_edit_access_to_archetype(db, current_user.id, archetype_id)
    
    if not (is_admin or has_edit):
        raise HTTPException(
            status_code=403, 
            detail="Forbidden: You do not have edit permission for this archetype"
        )
    
    arch = db.query(Archetype).filter(Archetype.id == archetype_id).first()
    if not arch:
        raise HTTPException(status_code=404, detail="Archetype not found")
        
    if payload.name:
        arch.name = payload.name
    if payload.description:
        arch.description = payload.description
        
    db.commit()
    db.refresh(arch)
    
    return ArchetypeResponse(
        id=arch.id,
        name=arch.name,
        description=arch.description,
        roles=[]  # roles relationship is many-to-many and requires joining via ArchetypeRoleMap
    )
