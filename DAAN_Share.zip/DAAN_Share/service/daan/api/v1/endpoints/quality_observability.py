"""Endpoints for persisted final quality observability metrics."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from daan.core.database import get_db
from daan.core.dependencies import get_current_active_user
from daan.flow.session_service import (
    QUALITY_OUTPUT_FILENAME,
    REPORTER_OUTPUT_FILENAME,
    get_session_dir,
    read_context_map_output,
    read_session_file,
)
from daan.flow.session_store import get_session
from daan.models.archetype import UseCase
from daan.models.user import User
from daan.observability.quality_store import (
    collect_agent_scores,
    get_average_for_archetype,
    get_average_for_usecase,
    get_dq_indicators_overview,
    store_session_quality_scores,
)
from daan.schemas.quality_observability import (
    DqIndicatorsResponse,
    FinalQualityScoreAverageResponse,
    FinalQualityScoreMetricResponse,
    FinalQualityScoreStoreRequest,
    UsecaseScoreGroup,
)
from daan.token_usage.access import (
    get_accessible_archetype_names,
    get_accessible_usecase_ids,
    is_admin_user,
    user_has_access_to_usecase,
)

router = APIRouter()


def _session_metadata(session_id: str) -> dict[str, str]:
    live_session = get_session(session_id)
    usecase_id = str(getattr(live_session, "usecase_id", "") or "").strip()
    archetype = str(getattr(live_session, "archetype", "") or "").strip()

    context_map = read_context_map_output(session_id)
    usecase_details = context_map.get("usecase_details") or {}
    if not usecase_id:
        usecase_id = str(usecase_details.get("usecaseid") or usecase_details.get("usecase_id") or "").strip()
    if not archetype:
        archetype = str(context_map.get("archetype") or usecase_details.get("archetype") or "").strip()

    return {
        "usecase_id": usecase_id,
        "archetype": archetype,
    }


def _quality_artifacts(session_id: str) -> dict[str, str | None]:
    live_session = get_session(session_id)
    assessment = str(getattr(live_session, "latest_quality_assessment", "") or "").strip()
    quality_output_path = str(getattr(live_session, "quality_output_path", "") or "").strip() or None
    reporter_output_path = str(getattr(live_session, "reporter_output_path", "") or "").strip() or None

    if not assessment:
        assessment = str(read_session_file(session_id, QUALITY_OUTPUT_FILENAME) or "").strip()

    report_text = str(read_session_file(session_id, REPORTER_OUTPUT_FILENAME) or "").strip()
    session_dir = get_session_dir(session_id)
    if session_dir is not None:
        if quality_output_path is None:
            quality_output_path = str(session_dir / QUALITY_OUTPUT_FILENAME)
        if reporter_output_path is None:
            reporter_output_path = str(session_dir / REPORTER_OUTPUT_FILENAME)

    return {
        "assessment": assessment,
        "report_text": report_text,
        "quality_output_path": quality_output_path,
        "reporter_output_path": reporter_output_path,
    }


@router.post("/quality-observability/final-scores", response_model=FinalQualityScoreMetricResponse)
def store_final_quality_score_route(
    payload: FinalQualityScoreStoreRequest,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> FinalQualityScoreMetricResponse:
    """Persist one session's finalized quality score into PostgreSQL."""
    session_id = str(payload.session_id or "").strip()
    if not session_id:
        raise HTTPException(status_code=400, detail="session_id is required")

    metadata = _session_metadata(session_id)
    usecase_id = metadata["usecase_id"]
    archetype = metadata["archetype"]
    if not usecase_id:
        raise HTTPException(status_code=404, detail="No use case metadata found for this session")
    if not user_has_access_to_usecase(db, current_user, usecase_id):
        raise HTTPException(status_code=403, detail="Not authorized to store quality score for this use case")

    artifacts = _quality_artifacts(session_id)
    if not artifacts["report_text"]:
        raise HTTPException(status_code=409, detail="Final report not found for this session")

    agent_scores = collect_agent_scores(session_id)
    if not agent_scores:
        raise HTTPException(status_code=409, detail="No agent scores found for this session")
    try:
        row = store_session_quality_scores(
            session_id=session_id,
            usecase_id=usecase_id,
            archetype=archetype,
            username=str(getattr(current_user, "username", "") or "").strip() or None,
            agent_scores=agent_scores,
            reporter_output_path=artifacts["reporter_output_path"],
            quality_output_path=artifacts["quality_output_path"],
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return FinalQualityScoreMetricResponse.model_validate(row)


@router.get("/quality-observability/usecases/{usecase_id}/average", response_model=FinalQualityScoreAverageResponse)
def usecase_quality_average_route(
    usecase_id: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> FinalQualityScoreAverageResponse:
    """Return the stored final quality average for one use case."""
    normalized_usecase_id = str(usecase_id or "").strip()
    if not normalized_usecase_id:
        raise HTTPException(status_code=400, detail="usecase_id is required")
    if not user_has_access_to_usecase(db, current_user, normalized_usecase_id):
        raise HTTPException(status_code=403, detail="Not authorized to view quality score for this use case")

    try:
        result = get_average_for_usecase(normalized_usecase_id)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if result["sample_count"] == 0:
        raise HTTPException(status_code=404, detail="No final quality scores stored for this use case")
    return FinalQualityScoreAverageResponse(**result)


@router.get("/quality-observability/archetypes/{archetype}/average", response_model=FinalQualityScoreAverageResponse)
def archetype_quality_average_route(
    archetype: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> FinalQualityScoreAverageResponse:
    """Return the stored final quality average for one archetype."""
    normalized_archetype = str(archetype or "").strip()
    if not normalized_archetype:
        raise HTTPException(status_code=400, detail="archetype is required")
    if not is_admin_user(current_user):
        accessible = {value.casefold() for value in get_accessible_archetype_names(db, current_user)}
        if normalized_archetype.casefold() not in accessible:
            raise HTTPException(status_code=403, detail="Not authorized to view quality score for this archetype")

    try:
        result = get_average_for_archetype(normalized_archetype)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if result["sample_count"] == 0:
        raise HTTPException(status_code=404, detail="No final quality scores stored for this archetype")
    return FinalQualityScoreAverageResponse(**result)


@router.get("/quality-observability/dq-indicators", response_model=DqIndicatorsResponse)
def dq_indicators_route(
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
    archetype: str | None = None,
) -> DqIndicatorsResponse:
    """Return the usecase -> sessions -> agents quality hierarchy (all users).

    Admins see every use case; other users see only use cases they can access.
    """
    try:
        groups = get_dq_indicators_overview(archetype)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    if not is_admin_user(current_user):
        accessible = {str(uid) for uid in get_accessible_usecase_ids(db, current_user)}
        groups = [g for g in groups if str(g.get("usecase_id")) in accessible]

    # Resolve human-friendly use case names from the application database.
    usecase_ids = [str(g.get("usecase_id")) for g in groups]
    name_by_id: dict[str, str] = {}
    if usecase_ids:
        rows = db.query(UseCase.usecaseid, UseCase.name).filter(UseCase.usecaseid.in_(usecase_ids)).all()
        name_by_id = {str(uid): str(name) for uid, name in rows}
    for group in groups:
        group["usecase_name"] = name_by_id.get(str(group.get("usecase_id")))

    return DqIndicatorsResponse(usecases=[UsecaseScoreGroup(**group) for group in groups])
