"""RAG API routes."""

from __future__ import annotations

import hashlib
import asyncio
import json
import os
import re
import time
import uuid
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, File, Form, UploadFile
from fastapi.responses import FileResponse, PlainTextResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from daan.core.config import get_settings
from daan.core.database import get_db
from daan.core.dependencies import get_current_active_user
from daan.graph_stores.graph_document import GraphEdge, GraphNode
from daan.models.evidence_models import EvidenceEnvelope
from daan.models.user import User
from daan.native_tools.rag_tool import RagTool
from daan.rag.observability.rag_tracer import RagTrace, RagTracer, build_trace_evidence_envelope
from daan.token_usage.access import is_admin_user, user_has_access_to_kb

router = APIRouter()
tracer = RagTracer(base_dir=get_settings().SESSION_STORAGE_DIR)
_KB_LIST_CACHE_TTL_SECONDS = 60.0
_kb_list_cache: dict[str, tuple[float, list[dict]]] = {}
_MAX_UPLOAD_BYTES = 50 * 1024 * 1024  # 50MB limit
_ALLOWED_UPLOAD_EXTENSIONS = {
    ".txt",
    ".md",
    ".html",
    ".htm",
    ".xml",
    ".yml",
    ".yaml",
    ".properties",
    ".ini",
    ".pdf",
    ".docx",
    ".ppt",
    ".pptx",
    ".csv",
    ".json",
    ".xlsx",
    ".xls",
    ".cs",
    ".java",
    ".py",
    ".js",
    ".ts",
    ".jsx",
    ".tsx",
    ".go",
    ".rb",
    ".php",
    ".c",
    ".cpp",
    ".h",
    ".hpp",
    ".sql",
}

# Rate limiting: track uploads per user (user_id -> list of upload timestamps)
_MAX_FILES_PER_HOUR = 100
_upload_history: dict[str, list[float]] = {}


def _require_kb_access(
    db: Session,
    current_user: User,
    kb_id: str,
    *,
    rag_config: dict | None = None,
) -> str:
    try:
        resolved_kb_id = RagTracer.normalize_partition_id(kb_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    effective_rag_config = rag_config or get_settings().load_rag_config()
    kb_config = _resolve_kb_config(effective_rag_config, resolved_kb_id)
    if kb_config is None or not bool(kb_config.get("enabled", True)):
        raise HTTPException(status_code=404, detail=f"Knowledge base not found: {resolved_kb_id}")

    if not user_has_access_to_kb(db, current_user, resolved_kb_id, kb_config=kb_config):
        raise HTTPException(status_code=403, detail=f"Not authorized to access knowledge base '{resolved_kb_id}'.")

    return resolved_kb_id


class IndexRequest(BaseModel):
    file_path: str


class SearchRequest(BaseModel):
    query: str
    query_link: str | None = None
    retriever_type: str | None = None
    top_k: int = 5
    kb_id: str
    # When True, also generate a natural-language answer grounded in the retrieved chunks.
    synthesize: bool = False
    include_explainability: bool = False


class SearchResult(BaseModel):
    id: str
    content: str
    source: str | None = None
    chunk_index: int = 0
    query_link: str | None = None


class SearchResponse(BaseModel):
    trace_id: str
    query_link: str
    # LLM answer grounded in `references`; None unless synthesize=True was requested.
    summary_response: str | None = None
    references: list[SearchResult] = Field(default_factory=list)
    explainability: dict[str, Any] | None = None
    query_normalization: dict[str, Any] | None = None
    branch_contributions: list[dict[str, Any]] = Field(default_factory=list)
    graph_contribution: dict[str, Any] | None = None
    timing_breakdown: dict[str, int] | None = None
    ce_status: dict[str, Any] | None = None


class TraversalGraphResponse(BaseModel):
    trace_id: str
    query_link: str
    retriever_type: str
    traversal_hops: list[dict[str, Any]] = Field(default_factory=list)
    selected_chunk_ids: list[str] = Field(default_factory=list)
    graph_contribution: dict[str, Any] | None = None
    nodes: list[GraphNode] = Field(default_factory=list)
    edges: list[GraphEdge] = Field(default_factory=list)


class EvidenceResponse(BaseModel):
    trace_id: str
    kb_id: str
    evidence: EvidenceEnvelope


class PersonaQuestionGroup(BaseModel):
    persona: str
    icon: str | None = None
    questions: list[str] = Field(default_factory=list)


class PersonaQuestionsResponse(BaseModel):
    personas: list[PersonaQuestionGroup] = Field(default_factory=list)


class EvaluateRequest(BaseModel):
    """Score one RAG answer against a known-correct expected answer (LLM judge)."""

    question: str
    expected_answer: str
    rag_answer: str
    kb_id: str | None = None  # optional; for traceability only


class EvaluateResponse(BaseModel):
    """Four 0.0-1.0 quality metrics plus their average and a short rationale."""

    correctness: float
    completeness: float
    relevance: float
    faithfulness: float
    overall: float
    rationale: str = ""


class BatchEvaluateItem(BaseModel):
    """One evaluation case: the question and its ground-truth expected answer.

    If `rag_answer` is provided it is scored as-is; otherwise the answer is
    generated live by running the RAG search+synthesis for `kb_id`.
    """

    question: str
    expected_answer: str
    rag_answer: str | None = None


class BatchEvaluateRequest(BaseModel):
    kb_id: str
    items: list[BatchEvaluateItem]
    retriever_type: str = "graph_rag"
    top_k: int = 5


class BatchEvaluateResult(EvaluateResponse):
    """Per-item score, echoing the question and the answer that was judged."""

    question: str
    rag_answer: str


class BatchEvaluateResponse(BaseModel):
    kb_id: str
    count: int
    # Average of each metric across all scored items (the scorecard).
    scorecard: dict[str, float] = Field(default_factory=dict)
    results: list[BatchEvaluateResult] = Field(default_factory=list)


def _resolve_search_retrieval_profile(rag_config: dict[str, Any], kb_id: str) -> dict[str, Any]:
    for kb in rag_config.get("knowledge_bases", []) or []:
        if str(kb.get("id")) != kb_id:
            continue
        profile = kb.get("chat_retrieval_profile")
        return dict(profile) if isinstance(profile, dict) else {}
    return {}


def _build_search_rag_config(rag_config: dict[str, Any], kb_id: str) -> dict[str, Any]:
    profile = _resolve_search_retrieval_profile(rag_config, kb_id)
    if not profile:
        return rag_config

    configured = dict(rag_config)
    if profile.get("retriever_type"):
        configured["default_retriever_type"] = str(profile.get("retriever_type"))
    if "use_hybrid" in profile:
        configured["use_hybrid"] = bool(profile.get("use_hybrid"))
    if "candidate_pool" in profile:
        configured["candidate_pool"] = int(profile.get("candidate_pool") or 0)
    if "max_probe_branches" in profile:
        configured["max_probe_branches"] = int(profile.get("max_probe_branches") or 0)
    if "use_lexical_chunk_resolution" in profile:
        configured["use_lexical_chunk_resolution"] = bool(profile.get("use_lexical_chunk_resolution"))
    if isinstance(profile.get("context_extrapolation"), dict):
        configured_context_extrapolation = dict(configured.get("context_extrapolation") or {})
        configured_context_extrapolation.update(profile.get("context_extrapolation") or {})
        configured["context_extrapolation"] = configured_context_extrapolation
    return configured


def _resolve_search_retriever_type(rag_config: dict[str, Any], kb_id: str, requested_retriever_type: str | None) -> str:
    requested = str(requested_retriever_type or "").strip()
    if requested:
        return requested

    profile = _resolve_search_retrieval_profile(rag_config, kb_id)
    if profile.get("retriever_type"):
        return str(profile.get("retriever_type"))
    return str(rag_config.get("default_retriever_type") or "graph_rag")


def _kb_list_cache_key(rag_config: dict) -> str:
    payload = json.dumps(rag_config, sort_keys=True, default=str)
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()


def _clone_kb_list(entries: list[dict]) -> list[dict]:
    return [
        {
            **entry,
            "documents": list((entry or {}).get("documents", []) or []),
        }
        for entry in (entries or [])
    ]


def _clear_kb_list_cache() -> None:
    _kb_list_cache.clear()


def _normalize_kb_id(raw_name: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "_", str(raw_name).strip().lower()).strip("_")
    return normalized[:64]


def _safe_upload_name(filename: str | None) -> str:
    """Return a filesystem-safe basename for an uploaded file.

    Strips any directory components (path-traversal safe) and unsupported
    characters while preserving the human-readable original name so citations
    and the document viewer show the real file name instead of a random id.
    """
    name = os.path.basename(str(filename or "").strip().replace("\\", "/"))
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(". ")
    return name or "document"

def _resolve_ingestion_file_path(raw_path: str, session_storage_dir: str) -> Path:
    candidate = Path(str(raw_path or "").strip())
    if not str(candidate):
        raise HTTPException(status_code=400, detail="file_path is required.")

    try:
        resolved = candidate.resolve(strict=True)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail="file_path was not found.") from exc

    if not resolved.is_file():
        raise HTTPException(status_code=400, detail="file_path must point to a file.")

    project_root = Path(__file__).resolve().parents[5]
    allowed_roots = [
        Path(session_storage_dir).resolve(),
        (project_root / "data").resolve(),
    ]
    if not any(resolved.is_relative_to(root) for root in allowed_roots):
        raise HTTPException(
            status_code=400,
            detail="file_path is outside allowed ingestion directories.",
        )

    return resolved


def _validate_uploaded_file(filename: str | None, content: bytes) -> str:
    """Validate file extension and size."""
    ext = Path(str(filename or "file")).suffix.lower()
    if ext not in _ALLOWED_UPLOAD_EXTENSIONS:
        allowed = ", ".join(sorted(_ALLOWED_UPLOAD_EXTENSIONS))
        raise HTTPException(status_code=400, detail=f"Unsupported file type '{ext or '<none>'}'. Allowed: {allowed}")
    if len(content) > _MAX_UPLOAD_BYTES:
        max_mb = _MAX_UPLOAD_BYTES / (1024 * 1024)
        raise HTTPException(
            status_code=413,
            detail=f"Uploaded file exceeds max size of {max_mb:.0f}MB.",
        )
    return ext


def _check_rate_limit(user_id: str) -> None:
    """Check if user has exceeded upload rate limit.
    
    Args:
        user_id: User identifier
        
    Raises:
        HTTPException: If rate limit exceeded
    """
    now = time.time()
    one_hour_ago = now - 3600  # 1 hour in seconds
    
    # Clean up old timestamps for this user
    if user_id in _upload_history:
        _upload_history[user_id] = [ts for ts in _upload_history[user_id] if ts > one_hour_ago]
    else:
        _upload_history[user_id] = []
    
    # Check rate limit
    recent_uploads = len(_upload_history[user_id])
    if recent_uploads >= _MAX_FILES_PER_HOUR:
        raise HTTPException(
            status_code=429,
            detail=f"Rate limit exceeded. Maximum {_MAX_FILES_PER_HOUR} files per hour allowed. Try again later.",
        )
    
    # Record this upload attempt
    _upload_history[user_id].append(now)


@router.post("/knowledge-bases/{kb_id}/index")
async def index_kb(kb_id: str, request: IndexRequest) -> dict:
    settings = get_settings()
    resolved_path = _resolve_ingestion_file_path(request.file_path, settings.SESSION_STORAGE_DIR)
    rag_config = settings.load_rag_config()
    tool = RagTool(rag_config)
    try:
        result = await tool.index_file_structured(
            file_path=str(resolved_path),
            kb_id=kb_id,
            include_graph_store=False,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    _clear_kb_list_cache()
    return {"status": "ok", "kb_id": kb_id, **result}


@router.post("/knowledge-bases/{kb_id}/upload-and-index")
async def upload_and_index_kb(
    kb_id: str,
    file: UploadFile = File(...),
    current_user: Annotated[User, Depends(get_current_active_user)] = None,
) -> dict:
    """Upload a file and index it into the specified knowledge base.
    
    Rate limited to 100 files per hour per user. Max file size 50MB.
    """
    # Check rate limit before processing
    if current_user:
        _check_rate_limit(str(current_user.id))
    
    settings = get_settings()
    rag_config = settings.load_rag_config()
    tool = RagTool(rag_config)
    
    # Create RAG uploads directory if it doesn't exist
    rag_uploads_dir = os.path.join(settings.SESSION_STORAGE_DIR, "rag_uploads", kb_id)
    os.makedirs(rag_uploads_dir, exist_ok=True)
    # Validate upload once; preserve original filename via safe_name below.
    content = await file.read()
    _validate_uploaded_file(file.filename, content)
    # Preserve the original filename (so citations/viewer show the real name) while
    # keeping uploads collision-free by isolating each one in its own subdirectory.
    safe_name = _safe_upload_name(file.filename)
    upload_dir = os.path.join(rag_uploads_dir, uuid.uuid4().hex)
    os.makedirs(upload_dir, exist_ok=True)
    file_path = os.path.join(upload_dir, safe_name)
    
    try:
        # Save the uploaded file
        with open(file_path, "wb") as f:
            f.write(content)
        
        # Index the file
        result = await tool.index_file_structured(
            file_path=file_path,
            kb_id=kb_id,
            include_graph_store=tool.kb_uses_graph_store(kb_id),
            display_name=file.filename,
        )
    except Exception as exc:
        # Clean up file if indexing fails
        if os.path.exists(file_path):
            os.remove(file_path)
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    _clear_kb_list_cache()
    
    return {
        "status": "ok",
        "kb_id": kb_id,
        "original_filename": file.filename,
        "stored_path": file_path,
        **result
    }


@router.post("/knowledge-bases/create-and-upload")
async def create_and_upload_kb(
    current_user: Annotated[User, Depends(get_current_active_user)],
    kb_name: str = Form(...),
    description: str = Form(""),
    customer: str = Form(""),
    kb_type: str = Form(""),
    system_prompt: str = Form(""),
    file: UploadFile | None = File(None),
) -> dict:
    """Create a new vector-only knowledge base, optionally ingesting a first file."""
    if not is_admin_user(current_user):
        raise HTTPException(status_code=403, detail="Admin access is required to create knowledge bases.")

    normalized_name = str(kb_name or "").strip()
    kb_id = _normalize_kb_id(normalized_name)
    if not normalized_name or not kb_id:
        raise HTTPException(status_code=400, detail="Knowledge base name is required.")

    settings = get_settings()
    rag_config = settings.load_rag_config()
    tool = RagTool(rag_config)

    try:
        created = tool.create_knowledge_base(
            kb_id=kb_id,
            name=normalized_name,
            description=description,
            customer=customer,
            kb_type=kb_type,
            system_prompt=system_prompt,
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    _clear_kb_list_cache()

    if file is None:
        return {
            "status": "ok",
            "created": True,
            "kb_id": kb_id,
            "kb_name": created["name"],
            "chunks_indexed": 0,
        }

    rag_uploads_dir = os.path.join(settings.SESSION_STORAGE_DIR, "rag_uploads", kb_id)
    os.makedirs(rag_uploads_dir, exist_ok=True)

    # Validate before entering the try below so 400/413 is not masked as a 500.
    content = await file.read()
    _validate_uploaded_file(file.filename, content)

    # Preserve the original filename (so citations/viewer show the real name) while
    # keeping uploads collision-free by isolating each one in its own subdirectory.
    safe_name = _safe_upload_name(file.filename)
    upload_dir = os.path.join(rag_uploads_dir, uuid.uuid4().hex)
    os.makedirs(upload_dir, exist_ok=True)
    file_path = os.path.join(upload_dir, safe_name)

    try:
        with open(file_path, "wb") as f:
            f.write(content)

        result = await tool.index_file_structured(
            file_path=file_path,
            kb_id=kb_id,
            include_graph_store=tool.kb_uses_graph_store(kb_id),
            display_name=file.filename,
        )
    except Exception as exc:
        if os.path.exists(file_path):
            os.remove(file_path)
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    _clear_kb_list_cache()

    return {
        "status": "ok",
        "created": True,
        "kb_id": kb_id,
        "kb_name": created["name"],
        "original_filename": file.filename,
        "stored_path": file_path,
        **result,
    }


@router.post("/search", response_model=SearchResponse)
async def search(
    request: SearchRequest,
    db: Annotated[Session, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> SearchResponse:
    resolved_query_link = request.query_link or _query_link(request.query)
    rag_config = get_settings().load_rag_config()
    resolved_kb_id = _require_kb_access(db, current_user, request.kb_id, rag_config=rag_config)
    effective_rag_config = _build_search_rag_config(rag_config, resolved_kb_id)
    resolved_retriever_type = _resolve_search_retriever_type(effective_rag_config, resolved_kb_id, request.retriever_type)
    tool = RagTool(effective_rag_config)

    t_start = time.monotonic()
    try:
        raw_payload = await asyncio.wait_for(
            asyncio.to_thread(
                tool.search_documents,
                query=request.query,
                k=request.top_k,
                retriever_type=resolved_retriever_type,
                kb_id=resolved_kb_id,
                query_link=resolved_query_link,
                include_explainability=request.include_explainability,
            ),
            timeout=120,
        )
    except asyncio.TimeoutError as exc:
        raise HTTPException(
            status_code=504,
            detail=(
                f"Retrieval timed out after 120s for retriever '{resolved_retriever_type}' on kb '{request.kb_id}'. "
                "This indicates a slow retrieval path or external dependency, not a confirmed knowledge-graph outage."
            ),
        ) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    latency_ms = int((time.monotonic() - t_start) * 1000)

    if request.include_explainability:
        payload = dict(raw_payload if isinstance(raw_payload, dict) else {})
        raw_docs = payload.get("results", [])
    else:
        payload = {}
        raw_docs = raw_payload if isinstance(raw_payload, list) else []

    deduped_docs = _deduplicate_docs(raw_docs)
    results = [SearchResult(**doc) for doc in deduped_docs]
    final_context = _build_final_context([r.content for r in results])

    summary_response: str | None = None
    answer_generation_ms = 0
    if request.synthesize:
        t_answer_start = time.monotonic()
        try:
            system_prompt = _resolve_system_prompt(rag_config, resolved_kb_id)
            summary_response = await asyncio.wait_for(
                asyncio.to_thread(_synthesize_answer, request.query, results, system_prompt),
                timeout=60,
            )
        except asyncio.TimeoutError:
            summary_response = "Answer synthesis timed out. The retrieval results are available in the references below."
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"LLM synthesis failed: {exc}") from exc
        answer_generation_ms = int((time.monotonic() - t_answer_start) * 1000)

    explainability = _build_explainability_payload(
        payload.get("explainability") if request.include_explainability else None,
        resolved_query_link,
        resolved_retriever_type,
        latency_ms,
        results,
        summary_response,
        final_context,
        [],
    )
    timing_breakdown = dict(explainability.get("timing_breakdown", {})) if explainability else {}
    timing_breakdown["answer_generation_ms"] = answer_generation_ms
    if explainability is not None:
        explainability["timing_breakdown"] = timing_breakdown
    evidence = build_trace_evidence_envelope(
        tool.get_last_evidence_envelope(request.query),
        session_id=resolved_kb_id,
        query=request.query,
        query_link=resolved_query_link,
        retriever_type=resolved_retriever_type,
        latency_ms=latency_ms,
        selected_references=list(explainability.get("selected_references", [])) if explainability else [],
        selected_source_ids=list(explainability.get("final_selected_chunk_ids", [])) if explainability else [r.id for r in results],
    )

    trace = RagTrace(
        evidence=evidence,
        query=request.query,
        query_link=resolved_query_link,
        retrieved_docs=[r.content[:200] for r in results],
        reranked_docs=[r.content[:200] for r in results],
        final_context=final_context,
        retriever_type=resolved_retriever_type,
        latency_ms=latency_ms,
        session_id=resolved_kb_id,
        owner_user_id=current_user.id,
        seed_chunk_ids=list(explainability.get("seed_chunk_ids", [])) if explainability else [],
        traversal_hops=list(explainability.get("traversal_hops", [])) if explainability else [],
        visited_node_ids=list(explainability.get("visited_node_ids", [])) if explainability else [],
        edge_list=list(explainability.get("edge_list", [])) if explainability else [],
        final_selected_chunk_ids=list(explainability.get("final_selected_chunk_ids", [])) if explainability else [r.id for r in results],
        branches=list(explainability.get("branches", [])) if explainability else [],
        graph_summary=dict(explainability.get("graph_contribution", {})) if explainability else {},
        timing_breakdown=timing_breakdown,
        query_normalization=dict(explainability.get("query_normalization", {})) if explainability else {},
        explainability=_strip_graph_payload(explainability) if explainability else {},
        graph_nodes=list(explainability.get("graph_nodes", [])) if explainability else _build_fallback_graph_nodes(resolved_query_link, results),
        graph_edges=list(explainability.get("graph_edges", [])) if explainability else _build_fallback_graph_edges(resolved_query_link, results),
    )
    tracer.record(trace)

    return SearchResponse(
        trace_id=trace.trace_id,
        query_link=resolved_query_link,
        summary_response=summary_response,
        references=results,
        explainability=_strip_graph_payload(explainability) if request.include_explainability else None,
        query_normalization=dict(explainability.get("query_normalization", {})) if explainability else None,
        branch_contributions=list(explainability.get("branch_contributions", [])) if explainability else [],
        graph_contribution=dict(explainability.get("graph_contribution", {})) if explainability else None,
        timing_breakdown=timing_breakdown,
        ce_status=dict(explainability.get("ce_status", {})) if explainability else None,
    )


@router.get("/knowledge-bases/{kb_id}/traces/{trace_id}/explainability")
async def get_explainability(
    kb_id: str,
    trace_id: str,
    db: Annotated[Session, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> dict[str, Any]:
    resolved_kb_id = _require_kb_access(db, current_user, kb_id)
    trace = tracer.read_trace_by_id(
        resolved_kb_id,
        trace_id,
        owner_user_id=current_user.id,
        allow_all=is_admin_user(current_user),
    )
    if not trace:
        raise HTTPException(status_code=404, detail="Explainability trace not found.")

    explainability = dict(trace.get("explainability") or {})
    if not explainability:
        raise HTTPException(status_code=404, detail="Explainability payload not available for this trace.")
    explainability.setdefault("trace_id", trace_id)
    explainability.setdefault("query_link", str(trace.get("query_link", "") or ""))
    explainability.setdefault("retriever_type", str(trace.get("retriever_type", "") or "graph_rag"))
    explainability.setdefault("latency_ms", int(trace.get("latency_ms", 0) or 0))
    explainability.setdefault("query_normalization", dict(trace.get("query_normalization", {}) or {}))
    explainability.setdefault("timing_breakdown", dict(trace.get("timing_breakdown", {}) or {}))
    explainability, synchronized_trace = _synchronize_trace_graph_metrics(trace, explainability)
    explainability.setdefault("graph_expansion", _build_graph_expansion_summary(synchronized_trace))
    explainability.setdefault("retrieval_journey", _build_retrieval_journey_summary(synchronized_trace, explainability))
    if not explainability.get("reasoning_steps"):
        rag_config = get_settings().load_rag_config()
        system_prompt = _resolve_system_prompt(rag_config, resolved_kb_id)
        reasoning_results = _results_from_explainability(explainability)
        if reasoning_results:
            try:
                t_reasoning_start = time.monotonic()
                answer_text, reasoning_steps = await asyncio.wait_for(
                    asyncio.to_thread(synthesize_kb_answer, str(trace.get("query", "") or ""), reasoning_results, system_prompt),
                    timeout=60,
                )
                explainability["reasoning_steps"] = reasoning_steps
                explainability["answer_to_reference_mapping"] = _build_answer_to_reference_mapping(answer_text, reasoning_results)
                explainability["timing_breakdown"] = {
                    **dict(explainability.get("timing_breakdown", {}) or {}),
                    "explainability_ms": int((time.monotonic() - t_reasoning_start) * 1000),
                }
            except asyncio.TimeoutError:
                explainability.setdefault("reasoning_steps", [])
    return explainability


@router.get("/knowledge-bases/{kb_id}/traces/{trace_id}/evidence", response_model=EvidenceResponse)
async def get_evidence(
    kb_id: str,
    trace_id: str,
    db: Annotated[Session, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> EvidenceResponse:
    resolved_kb_id = _require_kb_access(db, current_user, kb_id)
    trace = tracer.read_trace_by_id(
        resolved_kb_id,
        trace_id,
        owner_user_id=current_user.id,
        allow_all=is_admin_user(current_user),
    )
    if not trace:
        raise HTTPException(status_code=404, detail="Evidence trace not found.")

    evidence = trace.get("evidence")
    if not evidence:
        raise HTTPException(status_code=404, detail="Evidence payload not available for this trace.")

    return EvidenceResponse(
        trace_id=trace_id,
        kb_id=resolved_kb_id,
        evidence=EvidenceEnvelope.model_validate(evidence),
    )


@router.get("/knowledge-bases/{kb_id}/traces/{trace_id}/graph", response_model=TraversalGraphResponse)
async def get_traversal_graph(
    kb_id: str,
    trace_id: str,
    db: Annotated[Session, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> TraversalGraphResponse:
    resolved_kb_id = _require_kb_access(db, current_user, kb_id)
    trace = tracer.read_trace_by_id(
        resolved_kb_id,
        trace_id,
        owner_user_id=current_user.id,
        allow_all=is_admin_user(current_user),
    )
    if not trace:
        raise HTTPException(status_code=404, detail="Traversal graph not found.")

    explainability, synchronized_trace = _synchronize_trace_graph_metrics(trace, trace.get("explainability") or {})

    graph_nodes_raw = list(trace.get("graph_nodes", []) or [])
    graph_edges_raw = list(trace.get("graph_edges", []) or [])
    nodes, edges = _truncate_graph_payload(graph_nodes_raw, graph_edges_raw)
    nodes, edges = _annotate_graph_phases(nodes, edges, synchronized_trace)

    return TraversalGraphResponse(
        trace_id=trace_id,
        query_link=str(trace.get("query_link", "") or ""),
        retriever_type=str(trace.get("retriever_type", "") or "graph_rag"),
        traversal_hops=list(synchronized_trace.get("traversal_hops", []) or []),
        selected_chunk_ids=list(trace.get("final_selected_chunk_ids", []) or []),
        graph_contribution=dict(explainability.get("graph_contribution", {}) or {}),
        nodes=[GraphNode(**node) for node in nodes],
        edges=[GraphEdge(**edge) for edge in edges],
    )


@router.get("/knowledge-bases/{kb_id}/documents/open", response_model=None)
async def open_rag_document(
    kb_id: str,
    source_path: str,
    db: Annotated[Session, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> FileResponse | PlainTextResponse:
    settings = get_settings()
    resolved_kb_id = _require_kb_access(db, current_user, kb_id)
    rag_uploads_dir = Path(settings.SESSION_STORAGE_DIR) / "rag_uploads" / resolved_kb_id
    if not rag_uploads_dir.exists():
        raise HTTPException(status_code=404, detail="Knowledge base uploads directory not found.")

    requested = Path(str(source_path).strip())
    candidate = requested if requested.is_absolute() else rag_uploads_dir / requested.name
    resolved_candidate = candidate.resolve()
    resolved_root = rag_uploads_dir.resolve()

    if not resolved_candidate.is_relative_to(resolved_root):
        raise HTTPException(status_code=400, detail="Invalid document path.")

    if not resolved_candidate.is_file():
        matches = sorted(rag_uploads_dir.glob(f"**/{requested.name}"))
        resolved_candidate = matches[0].resolve() if matches else resolved_candidate

    if not resolved_candidate.is_file():
        raise HTTPException(status_code=404, detail="Document not found.")

    media_type = _guess_media_type(resolved_candidate)
    if media_type.startswith("text/") or media_type in {"application/json", "application/xml"}:
        try:
            content = resolved_candidate.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            content = resolved_candidate.read_text(encoding="utf-8", errors="replace")
        return PlainTextResponse(content=content, media_type=media_type)

    return FileResponse(path=resolved_candidate, media_type=media_type, filename=resolved_candidate.name)


@router.post("/evaluate", response_model=EvaluateResponse)
async def evaluate(request: EvaluateRequest) -> EvaluateResponse:
    """Score a single RAG answer against its expected answer using the LLM judge."""
    from daan.rag.evaluation.answer_evaluator import evaluate_answer

    try:
        scores = evaluate_answer(
            question=request.question,
            expected_answer=request.expected_answer,
            generated_answer=request.rag_answer,
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"Evaluation failed: {exc}") from exc

    return EvaluateResponse(**scores)


@router.post("/evaluate/batch", response_model=BatchEvaluateResponse)
async def evaluate_batch(request: BatchEvaluateRequest) -> BatchEvaluateResponse:
    """Score a set of question/expected-answer pairs and return a scorecard.

    For any item without a supplied `rag_answer`, the answer is generated live by
    running the RAG search+synthesis for `kb_id` (so this doubles as an end-to-end
    quality run over an eval set).
    """
    from daan.rag.evaluation.answer_evaluator import METRIC_KEYS, evaluate_answer

    if not request.items:
        raise HTTPException(status_code=400, detail="items must not be empty.")

    rag_config = get_settings().load_rag_config()

    results: list[BatchEvaluateResult] = []
    for item in request.items:
        rag_answer = item.rag_answer
        if not rag_answer:
            try:
                rag_answer = _generate_answer_for_kb(
                    query=item.question,
                    kb_id=request.kb_id,
                    retriever_type=request.retriever_type,
                    top_k=request.top_k,
                    rag_config=rag_config,
                )
            except Exception as exc:  # noqa: BLE001
                raise HTTPException(
                    status_code=500, detail=f"Answer generation failed: {exc}"
                ) from exc

        scores = evaluate_answer(
            question=item.question,
            expected_answer=item.expected_answer,
            generated_answer=rag_answer,
        )
        results.append(
            BatchEvaluateResult(
                question=item.question,
                rag_answer=rag_answer,
                **scores,
            )
        )

    # Scorecard: average of each metric (+ overall) across all items.
    scorecard: dict[str, float] = {}
    if results:
        for key in (*METRIC_KEYS, "overall"):
            scorecard[key] = round(
                sum(getattr(r, key) for r in results) / len(results), 2
            )

    return BatchEvaluateResponse(
        kb_id=request.kb_id,
        count=len(results),
        scorecard=scorecard,
        results=results,
    )


@router.get("/knowledge-bases")
async def list_kbs() -> dict:
    rag_config = get_settings().load_rag_config()
    cache_key = _kb_list_cache_key(rag_config)
    cached = _kb_list_cache.get(cache_key)
    if cached and (time.monotonic() - cached[0]) < _KB_LIST_CACHE_TTL_SECONDS:
        return {"knowledge_bases": _clone_kb_list(cached[1])}

    tool = RagTool(rag_config)
    # KBs with enabled=false are soft-deleted (hidden) — never surfaced in the main list.
    knowledge_bases = [kb for kb in tool.list_knowledge_bases() if kb.get("enabled", True)]
    _kb_list_cache[cache_key] = (time.monotonic(), _clone_kb_list(knowledge_bases))
    return {"knowledge_bases": knowledge_bases}


@router.get("/knowledge-bases/hidden")
async def list_hidden_kbs(
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> dict:
    """Admin-only: list soft-deleted (hidden) user-created KBs so they can be restored."""
    if not is_admin_user(current_user):
        raise HTTPException(status_code=403, detail="Admin access is required to view hidden knowledge bases.")

    settings = get_settings()
    user_kb_ids = {str(kb.get("id")) for kb in settings.load_user_knowledge_bases() if kb.get("id")}
    rag_config = settings.load_rag_config()
    tool = RagTool(rag_config)
    hidden = [
        kb
        for kb in tool.list_knowledge_bases()
        if kb["id"] in user_kb_ids and not kb.get("enabled", True)
    ]
    return {"knowledge_bases": hidden}


@router.post("/knowledge-bases/{kb_id}/hide")
async def hide_kb(
    kb_id: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> dict:
    """Soft-delete: hide a user-created KB from the UI without deleting its data."""
    if not is_admin_user(current_user):
        raise HTTPException(status_code=403, detail="Admin access is required to hide knowledge bases.")

    settings = get_settings()
    user_kb_ids = {str(kb.get("id")) for kb in settings.load_user_knowledge_bases() if kb.get("id")}
    if kb_id not in user_kb_ids:
        raise HTTPException(
            status_code=403,
            detail=f"'{kb_id}' is a curated knowledge base and cannot be hidden from the UI.",
        )

    if not settings.set_user_knowledge_base_enabled(kb_id, enabled=False):
        raise HTTPException(status_code=404, detail=f"Knowledge base not found: {kb_id}")
    _clear_kb_list_cache()
    return {"status": "hidden", "kb_id": kb_id}


@router.post("/knowledge-bases/{kb_id}/restore")
async def restore_kb(
    kb_id: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> dict:
    """Restore a previously hidden (soft-deleted) user-created KB back into the UI."""
    if not is_admin_user(current_user):
        raise HTTPException(status_code=403, detail="Admin access is required to restore knowledge bases.")

    settings = get_settings()
    user_kb_ids = {str(kb.get("id")) for kb in settings.load_user_knowledge_bases() if kb.get("id")}
    if kb_id not in user_kb_ids:
        raise HTTPException(
            status_code=403,
            detail=f"'{kb_id}' is a curated knowledge base and is managed outside the UI.",
        )

    if not settings.set_user_knowledge_base_enabled(kb_id, enabled=True):
        raise HTTPException(status_code=404, detail=f"Knowledge base not found: {kb_id}")
    _clear_kb_list_cache()
    return {"status": "restored", "kb_id": kb_id}


@router.get("/knowledge-bases/{kb_id}/persona-questions", response_model=PersonaQuestionsResponse)
async def get_persona_questions(kb_id: str) -> dict:
    rag_config = get_settings().load_rag_config()
    kb_config = _resolve_kb_config(rag_config, kb_id)
    if kb_config is None:
        raise HTTPException(status_code=404, detail=f"Knowledge base not found: {kb_id}")

    configured_path = str(kb_config.get("persona_questions_path") or "").strip()
    if not configured_path:
        return {"personas": []}

    questions_path = Path(configured_path)
    if not questions_path.is_absolute():
        questions_path = Path(__file__).resolve().parents[5] / questions_path

    if not questions_path.exists() or not questions_path.is_file():
        raise HTTPException(status_code=404, detail=f"Persona questions file not found: {configured_path}")

    try:
        with questions_path.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=500, detail=f"Invalid persona questions JSON: {exc}") from exc

    personas = payload.get("personas") if isinstance(payload, dict) else payload
    if not isinstance(personas, list):
        return {"personas": []}

    return {"personas": personas}


@router.delete("/knowledge-bases/{kb_id}")
async def delete_kb(
    kb_id: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> dict:
    """Delete a knowledge base along with its vectors, uploads and config entry."""
    if not is_admin_user(current_user):
        raise HTTPException(status_code=403, detail="Admin access is required to delete knowledge bases.")

    settings = get_settings()
    user_kb_ids = {str(kb.get("id")) for kb in settings.load_user_knowledge_bases() if kb.get("id")}
    if kb_id not in user_kb_ids:
        raise HTTPException(
            status_code=403,
            detail=f"'{kb_id}' is a curated knowledge base and cannot be deleted from the UI.",
        )

    rag_config = settings.load_rag_config()
    tool = RagTool(rag_config)
    try:
        result = tool.delete_knowledge_base(kb_id=kb_id, session_storage_dir=settings.SESSION_STORAGE_DIR)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    _clear_kb_list_cache()
    return {"status": "deleted" if result.get("deleted") else "not_found", **result}


@router.get("/traces/{kb_id}")
async def get_traces(
    kb_id: str,
    db: Annotated[Session, Depends(get_db)],
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> dict:
    resolved_kb_id = _require_kb_access(db, current_user, kb_id)
    traces = tracer.read_traces(
        resolved_kb_id,
        owner_user_id=current_user.id,
        allow_all=is_admin_user(current_user),
    )
    cleaned_traces = [_deduplicate_trace(trace) for trace in traces]
    cleaned_traces = _deduplicate_trace_runs(cleaned_traces)
    return {"kb_id": resolved_kb_id, "traces": cleaned_traces}


def _query_link(query: str) -> str:
    if not query:
        return "global"
    return hashlib.sha1(query.strip().lower().encode("utf-8")).hexdigest()[:16]


def _clean_answer_text(text: str) -> str:
    """Strip stray trailing punctuation runs (e.g. ',,,,.') the LLM occasionally appends."""
    return re.sub(r"([.!?])[\s,]+$", r"\1", text.strip())


DEFAULT_SYSTEM_PROMPT = "You are a helpful assistant that answers strictly from the provided context."
RAG_SYNTHESIS_TEMPERATURE = 0.0
RAG_SYNTHESIS_MAX_TOKENS = 2200


def _resolve_system_prompt(rag_config: dict, kb_id: str) -> str:
    """Return the domain persona for `kb_id` from config, or a neutral default.

    Keeps the endpoint generic: domain framing lives with each knowledge base in
    rag_config.yml (`knowledge_bases[].system_prompt`), not hard-coded here.
    """
    kb = _resolve_kb_config(rag_config, kb_id)
    if kb is not None:
        prompt = str(kb.get("system_prompt") or "").strip()
        return prompt or DEFAULT_SYSTEM_PROMPT
    return DEFAULT_SYSTEM_PROMPT


def _resolve_kb_config(rag_config: dict, kb_id: str) -> dict | None:
    for kb in rag_config.get("knowledge_bases", []) or []:
        if str(kb.get("id")) == str(kb_id):
            return kb
    return None


def _synthesize_answer(
    query: str,
    results: list[SearchResult],
    system_prompt: str = DEFAULT_SYSTEM_PROMPT,
    chat_history_text: str = "",
    uploaded_context_text: str = "",
    feedback_context: str = "",
) -> str:
    """Generate a detailed, well-formatted markdown answer from retrieved chunks.

    Simple flow:
    1. Build context from retrieved docs + chat history + any prior feedback
    2. If feedback exists, tell the model to follow it
    3. Otherwise use the default detailed markdown format
    4. Return the answer
    """
    if not results:
        return "No relevant information was found in the knowledge base to answer this question."

    context = "\n\n".join(
        _build_answer_context_sections(
            results,
            chat_history_text=chat_history_text,
            uploaded_context_text=uploaded_context_text,
            feedback_context=feedback_context,
        )
    )

    has_feedback = bool(feedback_context.strip())

    if has_feedback:
        format_instruction = (
            "The user previously gave feedback on a similar answer. Their feedback is in the "
            "'PREVIOUS USER FEEDBACK FOR SIMILAR QUERIES' section of the context. "
            "You MUST follow that feedback exactly — it overrides any default formatting rules."
        )
    else:
        format_instruction = (
            "Format the answer as clean, detailed markdown:\n"
            "- Start with a brief summary (1-2 sentences)\n"
            "- Follow with detailed explanation organized with headings or bullet points\n"
            "- Be thorough — cover all relevant aspects found in the context\n"
            "- Do NOT give a short 2-3 line answer when the context has more information\n"
            "- Use **bold** for key terms and proper markdown structure"
        )

    citation_instruction = (
        "Cite your sources: each RAG CONTEXT chunk is prefixed with a bracketed identifier, e.g. "
        "[filename.ext:0]. Whenever a sentence or bullet uses information from a chunk, append that "
        "exact bracketed identifier immediately after it. Only reuse identifiers that literally "
        "appear in the CONTEXT — never invent one, and omit the citation if no chunk was used."
    )

    prompt = (
        f"{system_prompt}\n\n"
        f"{format_instruction}\n\n"
        f"{citation_instruction}\n\n"
        "Answer the QUESTION using only the CONTEXT below. Do NOT introduce outside knowledge. "
        "If the context doesn't fully answer the question, say so clearly.\n\n"
        f"CONTEXT:\n{context}\n\n"
        f"QUESTION: {query}\n\nANSWER:"
    )

    from daan.llm.llm_provider import get_llm_response_with_fallback

    return _clean_answer_text(
        get_llm_response_with_fallback(
            prompt,
            temperature=RAG_SYNTHESIS_TEMPERATURE,
            max_tokens=RAG_SYNTHESIS_MAX_TOKENS,
        )
    )


def _build_answer_context_sections(
    results: list[SearchResult],
    chat_history_text: str = "",
    uploaded_context_text: str = "",
    feedback_context: str = "",
) -> list[str]:
    sections: list[str] = []
    if feedback_context.strip():
        sections.append(f"PREVIOUS USER FEEDBACK FOR SIMILAR QUERIES:\n{feedback_context.strip()}")
    if chat_history_text.strip():
        sections.append(f"PRIOR CHAT HISTORY:\n{chat_history_text.strip()}")
    if uploaded_context_text.strip():
        sections.append(f"UPLOADED DOCUMENT CONTEXT:\n{uploaded_context_text.strip()}")

    rag_context = "\n\n".join(f"[{r.id}] {r.content}" for r in results)
    if rag_context.strip():
        sections.append(f"RAG CONTEXT:\n{rag_context}")
    return sections


def synthesize_kb_answer(
    query: str,
    results: list[SearchResult],
    system_prompt: str = DEFAULT_SYSTEM_PROMPT,
    chat_history_text: str = "",
    uploaded_context_text: str = "",
    feedback_context: str = "",
) -> tuple[str, list[dict[str, Any]]]:
    """Generate a detailed markdown answer from retrieved chunks.

    Returns (answer_text, reasoning_steps), where reasoning_steps describes the
    retrieval -> review -> synthesis trail used to ground the answer.
    """
    answer = _synthesize_answer(
        query,
        results,
        system_prompt,
        chat_history_text=chat_history_text,
        uploaded_context_text=uploaded_context_text,
        feedback_context=feedback_context,
    )
    return answer, _build_reasoning_steps(query, results)


def _build_reasoning_steps(query: str, results: list[SearchResult]) -> list[dict[str, Any]]:
    """Derive a step-by-step chain-of-thought trail from the retrieval results.

    This mirrors the actual retrieval/synthesis flow (no extra LLM call) so the
    "Thinking" panel always has something meaningful to show for grounded answers.
    """
    if not results:
        return []

    all_chunk_ids = [r.id for r in results]
    steps: list[dict[str, Any]] = [
        {
            "step": 1,
            "title": "Interpreted the question",
            "detail": f'Parsed the question "{query.strip()}" to identify what information to retrieve.',
            "chunk_ids": [],
        },
        {
            "step": 2,
            "title": f"Retrieved {len(results)} relevant chunk(s) from the knowledge base",
            "detail": "Ranked candidate passages from the knowledge base by relevance to the question.",
            "chunk_ids": all_chunk_ids,
        },
    ]

    for result in results[:5]:
        source_name = Path(str(result.source or "")).name or f"chunk {result.id}"
        excerpt = re.sub(r"\s+", " ", result.content or "").strip()[:220]
        steps.append(
            {
                "step": len(steps) + 1,
                "title": f"Reviewed excerpt from {source_name}",
                "detail": excerpt,
                "chunk_ids": [result.id],
            }
        )

    steps.append(
        {
            "step": len(steps) + 1,
            "title": "Synthesized the final answer",
            "detail": "Combined the reviewed excerpts into a single answer grounded in the retrieved context.",
            "chunk_ids": all_chunk_ids,
        }
    )
    return steps


def _generate_answer_for_kb(
    query: str,
    kb_id: str,
    retriever_type: str,
    top_k: int,
    rag_config: dict,
) -> str:
    """Run RAG search + synthesis for one question (used by batch evaluation)."""
    tool = RagTool(rag_config)
    raw_docs = tool.search_documents(
        query=query,
        k=top_k,
        retriever_type=retriever_type,
        kb_id=kb_id,
        query_link=_query_link(query),
    )
    results = [SearchResult(**doc) for doc in _deduplicate_docs(raw_docs)]
    system_prompt = _resolve_system_prompt(rag_config, kb_id)
    return _synthesize_answer(query, results, system_prompt)


def _deduplicate_docs(docs: list[dict]) -> list[dict]:
    """Deduplicate exact/near-exact content variants while preserving rank order."""
    unique_docs: list[dict] = []
    seen_normalized: list[str] = []

    for doc in docs:
        content = str(doc.get("content", "") or "")
        normalized = _normalize_text(content)
        if not normalized:
            continue

        if _is_duplicate_text(normalized, seen_normalized):
            continue

        seen_normalized.append(normalized)
        unique_docs.append(doc)

    return unique_docs


def _deduplicate_trace(trace: dict) -> dict:
    """Deduplicate text-heavy trace fields for stable readability across old/new runs."""
    cleaned = dict(trace)
    cleaned.pop("owner_user_id", None)
    cleaned.pop("origin_session_id", None)
    cleaned["retrieved_docs"] = _deduplicate_texts([str(t) for t in trace.get("retrieved_docs", [])])
    cleaned["reranked_docs"] = _deduplicate_texts([str(t) for t in trace.get("reranked_docs", [])])

    final_context = str(trace.get("final_context", "") or "")
    context_parts = [part.strip() for part in final_context.split("\n\n") if part.strip()]
    cleaned["final_context"] = _build_final_context(context_parts)
    return cleaned


def _build_explainability_payload(
    raw_explainability: dict[str, Any] | None,
    query_link: str,
    retriever_type: str,
    latency_ms: int,
    results: list[SearchResult],
    summary_response: str | None,
    final_context: str,
    reasoning_steps: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    explainability = dict(raw_explainability or {})
    explainability["query_link"] = query_link
    explainability["retriever_type"] = retriever_type
    explainability["latency_ms"] = latency_ms
    explainability["reasoning_steps"] = list(reasoning_steps or [])
    explainability["candidate_chunk_ids"] = list(explainability.get("candidate_chunk_ids", []))
    explainability["ontology_seed_ids"] = list(explainability.get("ontology_seed_ids", []))
    explainability["seed_chunk_ids"] = list(explainability.get("seed_chunk_ids", []))
    explainability["visited_node_ids"] = list(explainability.get("visited_node_ids", []))
    explainability["traversal_hops"] = list(explainability.get("traversal_hops", []))
    explainability["edge_list"] = list(explainability.get("edge_list", []))
    explainability["knowledge_area_probes"] = list(explainability.get("knowledge_area_probes", []))
    explainability["branch_contributions"] = list(explainability.get("branch_contributions", []))
    explainability["branches"] = list(explainability.get("branches", []))
    explainability["graph_contribution"] = dict(explainability.get("graph_contribution", {}))
    explainability["query_normalization"] = dict(explainability.get("query_normalization", {}))
    explainability["timing_breakdown"] = dict(explainability.get("timing_breakdown", {}))
    explainability["ce_status"] = dict(explainability.get("ce_status", {}))
    explainability["final_selected_chunk_ids"] = list(explainability.get("final_selected_chunk_ids", [])) or [r.id for r in results]
    explainability["reranking_applied"] = bool(explainability.get("reranking_applied", False) or results)
    explainability["selected_references"] = explainability.get("selected_references") or [
        _to_explainability_chunk(result) for result in results
    ]
    explainability["reranked_chunks"] = explainability.get("reranked_chunks") or [
        {**_to_explainability_chunk(result), "score": 1.0 / (index + 1)}
        for index, result in enumerate(results)
    ]
    explainability["seed_chunks"] = explainability.get("seed_chunks") or [
        _to_explainability_chunk(result) for result in results[: min(3, len(results))]
    ]
    explainability["final_context_snapshot"] = explainability.get("final_context_snapshot") or final_context[:1200]
    explainability["answer_to_reference_mapping"] = _build_answer_to_reference_mapping(summary_response, results)
    explainability.setdefault("graph_nodes", _build_fallback_graph_nodes(query_link, results))
    explainability.setdefault("graph_edges", _build_fallback_graph_edges(query_link, results))
    explainability = _refresh_graph_runtime_metrics(explainability)
    return explainability


def _results_from_explainability(explainability: dict[str, Any]) -> list[SearchResult]:
    results: list[SearchResult] = []
    for item in explainability.get("selected_references", []) or []:
        if not isinstance(item, dict):
            continue
        chunk_id = str(item.get("id") or "").strip()
        content = str(item.get("snippet") or item.get("content") or "").strip()
        if not chunk_id or not content:
            continue
        results.append(
            SearchResult(
                id=chunk_id,
                content=content,
                source=item.get("source"),
                chunk_index=int(item.get("chunk_index") or 0),
                query_link=explainability.get("query_link"),
            )
        )
    return results


def _humanize_graph_identifier(node_id: Any) -> str:
    raw = str(node_id or "").strip()
    if not raw:
        return ""
    if ":" in raw:
        raw = raw.split(":", 1)[1]
    raw = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", raw)
    raw = re.sub(r"[_\-.]+", " ", raw)
    return raw.strip()


def _refresh_graph_runtime_metrics(explainability: dict[str, Any]) -> dict[str, Any]:
    refreshed = dict(explainability or {})
    branches = [branch for branch in (refreshed.get("branches") or []) if isinstance(branch, dict)]
    if not branches:
        return refreshed

    selected_ids = {
        str(item) for item in (refreshed.get("final_selected_chunk_ids") or []) if str(item)
    }
    if not selected_ids:
        selected_ids = {
            str(item.get("id"))
            for item in (refreshed.get("selected_references") or [])
            if isinstance(item, dict) and str(item.get("id") or "")
        }

    visited_node_ids: list[str] = []
    traversal_hops: list[dict[str, Any]] = []
    seed_chunk_ids: set[str] = set()
    expanded_chunk_ids: set[str] = set()
    graph_only_chunk_ids: set[str] = set()
    candidate_chunk_ids: set[str] = set()

    for branch in branches:
        visited_node_ids.extend(str(item) for item in (branch.get("visited_node_ids") or []) if str(item))
        traversal_hops.extend(item for item in (branch.get("traversal_hops") or []) if isinstance(item, dict))
        seed_chunk_ids.update(str(item) for item in (branch.get("seed_chunk_ids") or []) if str(item))
        expanded_chunk_ids.update(str(item) for item in (branch.get("expanded_chunk_ids") or []) if str(item))
        graph_only_chunk_ids.update(str(item) for item in (branch.get("graph_only_chunk_ids") or []) if str(item))
        candidate_chunk_ids.update(str(item) for item in (branch.get("candidate_chunk_ids") or []) if str(item))

    refreshed["visited_node_ids"] = list(dict.fromkeys(visited_node_ids))
    refreshed["traversal_hops"] = traversal_hops
    refreshed["seed_chunk_ids"] = list(dict.fromkeys([*refreshed.get("seed_chunk_ids", []), *seed_chunk_ids]))
    if not refreshed.get("candidate_chunk_ids") and candidate_chunk_ids:
        refreshed["candidate_chunk_ids"] = list(candidate_chunk_ids)

    graph_selected_chunks = graph_only_chunk_ids & selected_ids
    recomputed_summary = {
        "visited_nodes": len(set(refreshed.get("visited_node_ids", []))),
        "expanded_chunks": len(expanded_chunk_ids),
        "graph_only_candidates": len(graph_only_chunk_ids),
        "graph_selected_chunks": len(graph_selected_chunks),
        "graph_contribution_rate": round(len(graph_selected_chunks) / max(1, len(selected_ids)), 4),
        "non_seed_survival_rate": round(len({chunk_id for chunk_id in selected_ids if chunk_id not in seed_chunk_ids}) / max(1, len(selected_ids)), 4),
    }

    existing_summary = dict(refreshed.get("graph_contribution", {}) or {})
    if recomputed_summary["visited_nodes"] > int(existing_summary.get("visited_nodes", 0) or 0):
        refreshed["graph_contribution"] = {
            **recomputed_summary,
            "metrics_available": True,
            "source": "runtime_graph_summary",
        }
    else:
        refreshed["graph_contribution"] = {
            **recomputed_summary,
            **existing_summary,
            "metrics_available": bool(existing_summary.get("metrics_available", True)),
            "source": str(existing_summary.get("source") or "runtime_graph_summary"),
        }
    return refreshed


def _graph_metric_numbers_non_zero(summary: dict[str, Any] | None) -> bool:
    if not isinstance(summary, dict):
        return False
    for key in (
        "visited_nodes",
        "expanded_chunks",
        "graph_only_candidates",
        "graph_selected_chunks",
        "graph_contribution_rate",
    ):
        value = summary.get(key)
        if isinstance(value, (int, float)) and float(value) > 0:
            return True
    return False


def _mark_historical_graph_metrics_unavailable(explainability: dict[str, Any]) -> dict[str, Any]:
    refreshed = dict(explainability or {})
    summary = dict(refreshed.get("graph_contribution", {}) or {})
    for key in (
        "visited_nodes",
        "expanded_chunks",
        "graph_only_candidates",
        "graph_selected_chunks",
        "graph_contribution_rate",
        "non_seed_survival_rate",
    ):
        summary.pop(key, None)
    summary["metrics_available"] = False
    summary["status_label"] = "Historical Trace - Metrics Not Available"
    summary["source"] = "historical_trace_unavailable"
    refreshed["graph_contribution"] = summary
    return refreshed


def _has_real_graph_payload(trace: dict[str, Any], branches: list[dict[str, Any]]) -> bool:
    """True only for genuine graph structure, not the query->seed->chunk vector fallback.

    ``_build_fallback_graph_nodes`` always populates graph_nodes/graph_edges, so their
    mere presence would otherwise make a vector-only run look graph-backed.
    """
    node_sources = [trace.get("graph_nodes") or []] + [branch.get("graph_nodes") or [] for branch in branches]
    for nodes in node_sources:
        for node in nodes:
            label = str((node or {}).get("label") or "").strip()
            if label and label not in ("Query", "Chunk"):
                return True

    edge_sources = [trace.get("graph_edges") or [], trace.get("edge_list") or []]
    edge_sources += [branch.get("graph_edges") or [] for branch in branches]
    for edges in edge_sources:
        for edge in edges:
            edge_type = str((edge or {}).get("type") or "").strip().lower()
            if edge_type and edge_type != "seed":
                return True

    return False


def _should_mark_historical_graph_metrics_unavailable(trace: dict[str, Any], explainability: dict[str, Any]) -> bool:
    summary = dict(explainability.get("graph_contribution", {}) or {})
    if summary.get("metrics_available") is False:
        return True
    if _graph_metric_numbers_non_zero(summary):
        return False

    branches = [branch for branch in (explainability.get("branches") or trace.get("branches") or []) if isinstance(branch, dict)]
    if not branches:
        return False

    has_selected_chunks = bool(
        explainability.get("final_selected_chunk_ids")
        or trace.get("final_selected_chunk_ids")
        or any(branch.get("selected_chunk_ids") for branch in branches)
    )
    graph_traversal_attempted = any(int(branch.get("graph_traversal_ms", 0) or 0) > 0 for branch in branches)
    branch_has_graph_runtime = any(
        branch.get("visited_node_ids")
        or branch.get("expanded_chunk_ids")
        or branch.get("graph_only_chunk_ids")
        or branch.get("traversal_hops")
        for branch in branches
    )
    has_graph_payload = _has_real_graph_payload(trace, branches)
    return bool(has_selected_chunks and graph_traversal_attempted and has_graph_payload and not branch_has_graph_runtime)


def _synchronize_trace_graph_metrics(
    trace: dict[str, Any],
    raw_explainability: dict[str, Any] | None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    explainability = dict(raw_explainability or {})
    explainability.setdefault("branches", list(trace.get("branches", []) or []))
    explainability.setdefault("final_selected_chunk_ids", list(trace.get("final_selected_chunk_ids", []) or []))
    explainability.setdefault("seed_chunk_ids", list(trace.get("seed_chunk_ids", []) or []))
    explainability.setdefault("visited_node_ids", list(trace.get("visited_node_ids", []) or []))
    explainability.setdefault("traversal_hops", list(trace.get("traversal_hops", []) or []))
    explainability.setdefault("graph_contribution", dict(trace.get("graph_summary", {}) or {}))
    explainability = _refresh_graph_runtime_metrics(explainability)
    if _should_mark_historical_graph_metrics_unavailable(trace, explainability):
        explainability = _mark_historical_graph_metrics_unavailable(explainability)

    synchronized_trace = dict(trace)
    synchronized_trace["graph_summary"] = dict(explainability.get("graph_contribution", {}) or {})
    synchronized_trace["seed_chunk_ids"] = list(explainability.get("seed_chunk_ids", []) or trace.get("seed_chunk_ids", []) or [])
    synchronized_trace["visited_node_ids"] = list(explainability.get("visited_node_ids", []) or trace.get("visited_node_ids", []) or [])
    synchronized_trace["traversal_hops"] = list(explainability.get("traversal_hops", []) or trace.get("traversal_hops", []) or [])
    synchronized_trace["branches"] = list(explainability.get("branches", []) or trace.get("branches", []) or [])
    return explainability, synchronized_trace


def _build_graph_expansion_summary(trace: dict[str, Any]) -> dict[str, Any]:
    graph_nodes = list(trace.get("graph_nodes", []) or [])
    seed_chunk_ids = {str(item) for item in (trace.get("seed_chunk_ids") or []) if str(item)}
    visited_node_ids = {str(item) for item in (trace.get("visited_node_ids") or []) if str(item)}
    ontology_seed_ids = [str(item) for item in (trace.get("ontology_seed_ids") or []) if str(item)]
    traversal_hops = list(trace.get("traversal_hops", []) or [])

    concept_ids: list[str] = []
    expanded_chunk_ids: set[str] = set()
    for node in graph_nodes:
        node_id = str(node.get("id") or "").strip()
        label = str(node.get("label") or "").strip()
        if not node_id or node_id.startswith("query:") or label == "Query":
            continue
        if label == "Chunk":
            if node_id in visited_node_ids and node_id not in seed_chunk_ids:
                expanded_chunk_ids.add(node_id)
            continue
        concept_ids.append(node_id)

    identified_concepts: list[str] = []
    for concept_id in ontology_seed_ids:
        humanized = _humanize_graph_identifier(concept_id)
        if humanized and humanized not in identified_concepts:
            identified_concepts.append(humanized)

    all_concepts: list[str] = []
    for concept_id in concept_ids:
        humanized = _humanize_graph_identifier(concept_id)
        if humanized and humanized not in all_concepts:
            all_concepts.append(humanized)

    if not identified_concepts:
        identified_concepts = all_concepts[:6]
    related_concepts = [concept for concept in all_concepts if concept not in identified_concepts][:6]
    graph_expansion_level = max((int(hop.get("depth") or 0) for hop in traversal_hops), default=0)
    traversal_executed = bool(traversal_hops or expanded_chunk_ids or related_concepts or identified_concepts)
    graph_summary = dict(trace.get("graph_summary", {}) or {})

    return {
        "traversal_executed": traversal_executed,
        "concepts_identified": identified_concepts,
        "related_concepts": related_concepts,
        "graph_expansion_level": graph_expansion_level,
        "expanded_context_chunks_count": int(graph_summary.get("expanded_chunks") or len(expanded_chunk_ids) or 0),
    }


def _build_retrieval_journey_summary(trace: dict[str, Any], explainability: dict[str, Any]) -> dict[str, Any]:
    graph_expansion = _build_graph_expansion_summary(trace)
    candidate_chunk_ids = [str(item) for item in (explainability.get("candidate_chunk_ids") or []) if str(item)]
    seed_chunk_ids = [str(item) for item in (trace.get("seed_chunk_ids") or []) if str(item)]
    final_selected_chunk_ids = [str(item) for item in (trace.get("final_selected_chunk_ids") or []) if str(item)]
    graph_contribution = dict(explainability.get("graph_contribution", {}) or {})

    retrieved_chunks_count = len(candidate_chunk_ids) if candidate_chunk_ids else len(seed_chunk_ids)
    return {
        "retrieved_chunks_count": retrieved_chunks_count,
        "graph_expanded_chunks_count": int(graph_contribution.get("expanded_chunks") or graph_expansion.get("expanded_context_chunks_count") or 0),
        "final_selected_chunks_count": len(final_selected_chunk_ids),
        "reranking_applied": bool(explainability.get("reranking_applied", False)),
    }


def _to_explainability_chunk(result: SearchResult) -> dict[str, Any]:
    return {
        "id": result.id,
        "source": result.source,
        "chunk_index": result.chunk_index,
        "snippet": result.content,
    }


def _build_answer_to_reference_mapping(summary_response: str | None, results: list[SearchResult]) -> list[dict[str, Any]]:
    if not summary_response:
        return []

    mappings: list[dict[str, Any]] = []
    for result in results:
        token = f"[{result.id}]"
        if token not in summary_response:
            continue
        for segment in re.split(r"(?<=[.!?])\s+", summary_response):
            if token in segment:
                mappings.append(
                    {
                        "reference_id": result.id,
                        "citation_token": token,
                        "answer_excerpt": segment.strip()[:320],
                    }
                )
                break
    return mappings


def _strip_graph_payload(explainability: dict[str, Any] | None) -> dict[str, Any]:
    cleaned = dict(explainability or {})
    cleaned.pop("graph_nodes", None)
    cleaned.pop("graph_edges", None)
    return cleaned


def _build_fallback_graph_nodes(query_link: str, results: list[SearchResult]) -> list[dict[str, Any]]:
    return [
        {
            "id": f"query:{query_link}",
            "label": "Query",
            "properties": {"name": "Query"},
        },
        *[
            {
                "id": result.id,
                "label": "Chunk",
                "properties": {
                    "source": result.source,
                    "chunk_index": result.chunk_index,
                    "text": result.content,
                },
            }
            for result in results
        ],
    ]


def _build_fallback_graph_edges(query_link: str, results: list[SearchResult]) -> list[dict[str, Any]]:
    query_node_id = f"query:{query_link}"
    return [
        {
            "source_id": query_node_id,
            "target_id": result.id,
            "type": "seed",
            "properties": {"rank": index + 1},
        }
        for index, result in enumerate(results)
    ]


def _truncate_graph_payload(
    nodes: list[dict[str, Any]],
    edges: list[dict[str, Any]],
    max_nodes: int = 240,
    max_edges: int = 600,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    trimmed_nodes = nodes[:max_nodes]
    allowed_ids = {str(node.get("id")) for node in trimmed_nodes}
    trimmed_edges = [
        edge for edge in edges
        if str(edge.get("source_id")) in allowed_ids and str(edge.get("target_id")) in allowed_ids
    ][:max_edges]
    return trimmed_nodes, trimmed_edges


def _annotate_graph_phases(
    nodes: list[dict[str, Any]],
    edges: list[dict[str, Any]],
    trace: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Tag each node/edge with the pipeline `phase` it belongs to.

    Uses data already present in the trace so the UI can render the full flow of
    information: query -> seed retrieval -> graph traversal -> candidate chunks ->
    selected evidence. Purely additive: nodes/edges without a match fall back to a
    neutral phase and existing rendering keeps working.
    """
    seed_ids = {str(cid) for cid in (trace.get("seed_chunk_ids") or [])}
    selected_ids = {str(cid) for cid in (trace.get("final_selected_chunk_ids") or [])}
    visited_ids = {str(nid) for nid in (trace.get("visited_node_ids") or [])}

    # Chunk ids that were reached via traversal hops (neighbors), not seeds.
    hop_neighbor_ids: set[str] = set()
    for hop in trace.get("traversal_hops") or []:
        for neighbor_id in hop.get("neighbor_ids") or []:
            hop_neighbor_ids.add(str(neighbor_id))

    for node in nodes:
        node_id = str(node.get("id", ""))
        label = str(node.get("label", ""))
        properties = node.setdefault("properties", {})

        if node_id.startswith("query:") or label == "Query":
            phase = "query"
        elif node_id in selected_ids:
            phase = "selected_chunk"
        elif node_id in seed_ids:
            phase = "seed"
        elif label == "Chunk":
            phase = "candidate_chunk" if node_id in hop_neighbor_ids else "chunk"
        elif node_id in visited_ids:
            phase = "traversal_entity"
        else:
            phase = "entity"

        properties["phase"] = phase

    for edge in edges:
        edge_type = str(edge.get("type", ""))
        properties = edge.setdefault("properties", {})

        if edge_type == "rerank-selected":
            phase = "selection"
        elif edge_type == "seed":
            phase = "retrieval"
        elif edge_type == "MENTIONS":
            phase = "traversal"
        else:
            phase = "relation"

        properties["phase"] = phase

    return nodes, edges



def _guess_media_type(file_path: Path) -> str:
    import mimetypes

    media_type, _ = mimetypes.guess_type(file_path.name)
    return media_type or "application/octet-stream"


def _build_final_context(texts: list[str]) -> str:
    """Return a readable context string with duplicate parts removed and overlaps merged."""
    cleaned_parts = _deduplicate_texts(texts)
    if not cleaned_parts:
        return ""

    non_structural_parts = [part for part in cleaned_parts if not _is_structural_chunk(part)]
    if non_structural_parts:
        cleaned_parts = non_structural_parts

    merged_parts: list[str] = [cleaned_parts[0].strip()]
    for part in cleaned_parts[1:]:
        candidate = part.strip()
        if not candidate:
            continue

        previous = merged_parts[-1]
        overlap = _find_overlap(previous, candidate)
        if overlap:
            merged_parts[-1] = f"{previous}{candidate[overlap:]}"
            continue

        merged_parts.append(candidate)

    return "\n\n".join(merged_parts)


def _find_overlap(previous: str, current: str) -> int:
    """Return the size of the largest suffix/prefix overlap between two chunks."""
    previous_normalized = _normalize_for_overlap(previous)
    current_normalized = _normalize_for_overlap(current)
    max_window = min(len(previous_normalized), len(current_normalized), 240)

    for size in range(max_window, 40, -1):
        if previous_normalized[-size:] == current_normalized[:size]:
            return _raw_overlap_length(previous, current, size)

    return 0


def _normalize_for_overlap(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip())


def _raw_overlap_length(previous: str, current: str, normalized_overlap: int) -> int:
    """Map a normalized overlap length back to the current raw string length."""
    current_slice: list[str] = []
    visible = 0

    for char in current:
        current_slice.append(char)
        if not char.isspace():
            visible += 1
        elif current_slice and len(current_slice) > 1 and current_slice[-2].isspace():
            continue

        normalized = _normalize_for_overlap("".join(current_slice))
        if len(normalized) >= normalized_overlap:
            return len("".join(current_slice))

    return 0


def _deduplicate_texts(texts: list[str]) -> list[str]:
    """Deduplicate strings preserving order using exact, containment and similarity checks."""
    unique: list[str] = []
    seen_normalized: list[str] = []

    for text in texts:
        normalized = _normalize_text(text)
        if not normalized:
            continue
        if _is_duplicate_text(normalized, seen_normalized):
            continue
        seen_normalized.append(normalized)
        unique.append(text)

    return unique


def _deduplicate_trace_runs(traces: list[dict]) -> list[dict]:
    """Collapse repeated runs with duplicate/near-duplicate final context, keeping latest."""
    kept: list[dict] = []
    kept_contexts: list[str] = []

    # Iterate newest -> oldest so the latest equivalent run wins.
    for trace in reversed(traces):
        context = _normalize_text(str(trace.get("final_context", "") or ""))
        if not context:
            kept.append(trace)
            kept_contexts.append("")
            continue

        is_duplicate = False
        for existing in kept_contexts:
            if not existing:
                continue
            if context == existing:
                is_duplicate = True
                break
            if len(context) > 120 and len(existing) > 120 and (context in existing or existing in context):
                is_duplicate = True
                break
            if SequenceMatcher(None, context, existing).ratio() >= 0.90:
                is_duplicate = True
                break

        if is_duplicate:
            continue

        kept.append(trace)
        kept_contexts.append(context)

    return list(reversed(kept))


def _trace_signature(trace: dict) -> str:
    query = _normalize_text(str(trace.get("query", "") or ""))
    retriever_type = str(trace.get("retriever_type", "") or "").strip().lower()
    final_context = _normalize_text(str(trace.get("final_context", "") or ""))
    return f"{query}|{retriever_type}|{final_context}"


def _normalize_text(text: str) -> str:
    return re.sub(r"[^\w\s]", "", " ".join((text or "").split()).lower())


def _is_duplicate_text(text: str, existing: list[str]) -> bool:
    prefix = text[:220]
    for candidate in existing:
        if text == candidate:
            return True
        if prefix and candidate.startswith(prefix):
            return True
        if len(text) > 80 and len(candidate) > 80 and (text in candidate or candidate in text):
            return True
        if len(text) > 180 and len(candidate) > 180 and _token_overlap_ratio(text, candidate) >= 0.78:
            return True
        if SequenceMatcher(None, text, candidate).ratio() >= 0.92:
            return True
    return False


def _token_overlap_ratio(left: str, right: str) -> float:
    left_tokens = set(re.findall(r"\w+", left))
    right_tokens = set(re.findall(r"\w+", right))
    if not left_tokens or not right_tokens:
        return 0.0

    shared = left_tokens & right_tokens
    return len(shared) / min(len(left_tokens), len(right_tokens))


def _is_structural_chunk(text: str) -> bool:
    normalized = " ".join((text or "").lower().split())
    if not normalized:
        return True

    if "table of contents" in normalized:
        return True

    # PDF TOC chunks often contain dot leaders and page-number scaffolding, not useful context.
    if text.count(".") >= 30:
        return True

    # Header/provenance blocks are not useful retrieval context for answers.
    header_markers = [
        "department",
        "approver",
        "owner",
        "latest distributable version",
    ]
    if sum(1 for marker in header_markers if marker in normalized) >= 2:
        return True

    # ABB/PDF identifier header lines like 9AAD134842 are metadata, not semantic content.
    if re.search(r"\b\d[a-z]{3}\d{6}\b", normalized):
        return True

    return False
