"""API endpoint for use case export functionality."""

import json
import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException, Depends, Query, BackgroundTasks
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from daan.usecases.export.export_service import UseCaseExportService
from daan.usecases.export.copilot_generator import CopilotExportService
from daan.usecases.export.schemas import (
    UseCaseConfig,
    AgentPromptConfig,
    LLMConfig,
    ToolReference,
    AgentMCPMapping,
    MCPServerConfig,
    AgentOrchestrationStep,
)
from daan.core.dependencies import get_current_active_user
from daan.core.database import SessionLocal
from daan.models.archetype import (
    UseCase,
    Agent,
    UseCaseAgentMapping,
    GeneratedPrompt,
    Prompt,
    Archetype,
    UseCaseArchetypeMapping,
)
from daan.models.user_mcp import UserMcpConfig
from daan.admin.user_service import can_edit_archetype
from daan.llm.llm_provider import load_llm_config, get_default_provider_name
from daan.models.user import User

logger = logging.getLogger(__name__)

router = APIRouter()
export_service = UseCaseExportService()
copilot_export_service = CopilotExportService()


@router.post("/usecases/{usecase_id}/export")
async def export_usecase(
    usecase_id: str,
    background_tasks: BackgroundTasks,
    format: str = Query("python", pattern="^(python|copilot)$", description="Export target: 'python' standalone package or 'copilot' customization pack."),
    current_user: Dict[str, Any] = Depends(get_current_active_user),
) -> FileResponse:
    """
    Export a use case as a standalone ZIP package.
    
    Args:
        usecase_id: ID of the use case to export
        format: 'python' (default) for a runnable package, or 'copilot' for a
            GitHub Copilot customization pack (.github/ + .vscode/).
        current_user: Authenticated user
    
    Returns:
        ZIP file for download or structured error response
    
    Raises:
        HTTPException with appropriate status code
    """
    try:
        user_email = current_user.email if hasattr(current_user, 'email') else current_user.get('email', 'unknown') if isinstance(current_user, dict) else 'unknown'
        logger.info(f"Export request for use case: {usecase_id} (format={format}) by user: {user_email}")
        
        # Fetch use case configuration from database
        usecase_config = await _fetch_usecase_config(usecase_id, current_user)
        
        # Copilot target: emit .github/ + .vscode/ customization files
        if format == "copilot":
            zip_path = copilot_export_service.export(usecase_config)
            filename = f"copilot_{usecase_id}.zip"
            background_tasks.add_task(_delete_file, zip_path)
            return FileResponse(
                path=str(zip_path),
                media_type="application/zip",
                filename=filename,
            )
        
        # Export the use case (Python standalone package)
        zip_path, validation_result = export_service.export_usecase(usecase_config)
        
        # Check if export was successful
        if zip_path is None:
            # Return validation errors
            error_response = validation_result.to_dict()
            
            # Determine HTTP status based on error types
            status_code = _determine_status_code(validation_result.errors)
            
            raise HTTPException(
                status_code=status_code,
                detail=error_response
            )
        
        # Return ZIP file for download; delete it after sending
        filename = f"usecase_{usecase_id}_v{usecase_config.version}.zip"
        background_tasks.add_task(_delete_file, zip_path)
        return FileResponse(
            path=str(zip_path),
            media_type="application/zip",
            filename=filename
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error during export: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "status": "failed",
                "error": "EXPORT_FAILED",
                "message": f"Unexpected error: {str(e)}"
            }
        )


async def _fetch_usecase_config(usecase_id: str, current_user: Dict) -> UseCaseConfig:
    """
    Fetch use case configuration from database.
    
    Queries the DAAN database to retrieve all information needed for export:
    - Use case metadata
    - Agent definitions and configurations
    - Agent prompts and roles
    - Execution orchestration
    - Tool references
    - MCP server mappings
    - LLM configurations
    
    Args:
        usecase_id: Use case ID
        current_user: Authenticated user
    
    Returns:
        UseCaseConfig object with all required data
    
    Raises:
        HTTPException if use case not found or access denied
    """
    db = SessionLocal()
    
    try:
        # ============================================================
        # Step 0: Get current user object (for authorization checks)
        # ============================================================
        # current_user is a User ORM object (injected by get_current_active_user)
        user_obj = current_user if not isinstance(current_user, dict) else (
            db.query(User).filter(User.id == current_user["id"]).first() if current_user.get("id") else None
        )
        
        # ============================================================
        # Step 1: Fetch Use Case Metadata
        # ============================================================
        logger.debug(f"Fetching use case: {usecase_id}")
        usecase = db.query(UseCase).filter(UseCase.usecaseid == usecase_id).first()
        
        if not usecase:
            raise HTTPException(
                status_code=404,
                detail={
                    "status": "failed",
                    "error": "USECASE_NOT_FOUND",
                    "message": f"Use case '{usecase_id}' not found"
                }
            )
        
        # ============================================================
        # Step 1.5: Verify current_user has permission via archetype
        # ============================================================
        if user_obj:
            # Get archetype from use case mapping
            archetype_mapping = db.query(UseCaseArchetypeMapping).filter(
                UseCaseArchetypeMapping.usecase_id == usecase_id
            ).first()
            
            if archetype_mapping:
                archetype = db.query(Archetype).filter(
                    Archetype.id == archetype_mapping.archetype_id
                ).first()
                
                if archetype and not can_edit_archetype(db, user_obj, archetype.name):
                    logger.warning(f"User {user_obj.username} denied access to use case {usecase_id} (archetype: {archetype.name})")
                    raise HTTPException(
                        status_code=403,
                        detail={
                            "status": "failed",
                            "error": "ACCESS_DENIED",
                            "message": f"You don't have permission to export this use case"
                        }
                    )
            
            logger.info(f"User {user_obj.username} authorized to export use case {usecase_id}")
        
        logger.info(f"Fetched use case: {usecase.name} (ID: {usecase_id})")
        
        # ============================================================
        # Step 2: Fetch Agent Mappings (execution order)
        # ============================================================
        agent_mappings = db.query(UseCaseAgentMapping).filter(
            UseCaseAgentMapping.usecase_id == usecase_id
        ).order_by(UseCaseAgentMapping.execution_order).all()
        
        if not agent_mappings:
            raise HTTPException(
                status_code=422,
                detail={
                    "status": "failed",
                    "error": "NO_AGENTS",
                    "message": "Use case has no agents assigned"
                }
            )
        
        logger.debug(f"Found {len(agent_mappings)} agents for use case {usecase_id}")
        
        # ============================================================
        # Step 3: Process Each Agent
        # ============================================================
        agents = []
        llm_configs = {}
        agent_tools = {}
        agent_mcp_mappings = {}
        orchestration = []
        
        for step_index, mapping in enumerate(agent_mappings):
            # Fetch agent definition
            agent = db.query(Agent).filter(Agent.agent_id == mapping.agent_id).first()
            
            if not agent:
                logger.warning(f"Agent {mapping.agent_id} referenced in mapping but not found")
                continue
            
            logger.debug(f"Processing agent: {agent.agent_id} (step {step_index})")
            
            # ====== 3.1: Fetch Agent Prompt ======
            prompt_text = ""
            
            # Try GeneratedPrompt table first (via prompt_id)
            if agent.prompt_id:
                prompt_obj = db.query(GeneratedPrompt).filter(
                    GeneratedPrompt.id == agent.prompt_id
                ).first()
                if prompt_obj and prompt_obj.prompt_text:
                    prompt_text = prompt_obj.prompt_text
                    logger.debug(f"Fetched prompt from GeneratedPrompt table for {agent.agent_id}")
            
            # Fallback: Try Prompt table (extended schema)
            if not prompt_text:
                prompt_from_prompts = db.query(Prompt).filter(
                    Prompt.use_case_id == usecase_id,
                    Prompt.agent_name == agent.agent_name
                ).first()
                if prompt_from_prompts and prompt_from_prompts.prompt:
                    prompt_text = prompt_from_prompts.prompt
                    logger.debug(f"Fetched prompt from Prompt table for {agent.agent_id}")
            
            # Fallback: Generate from agent fields
            if not prompt_text:
                prompt_text = f"As a {agent.role or 'assistant'}, {agent.input_context or 'process the input'}"
                logger.debug(f"Generated fallback prompt for {agent.agent_id}")
            
            # ====== 3.2: Create Agent Prompt Config ======
            agent_config = AgentPromptConfig(
                agent_id=agent.agent_id,
                prompt=prompt_text,
                role=agent.role or "Agent",
                instructions=agent.input_context or "Process the input",
                expected_outputs=agent.output_format or "Return the result",
                agent_type=agent.agent_type,
            )
            agents.append(agent_config)
            logger.debug(f"Created agent config for {agent.agent_id}")
            
            # ====== 3.3: Create LLM Config from llm_config.yml ======
            try:
                llm_cfg = load_llm_config()
                provider_name = get_default_provider_name()
                
                # Extract model parameters from loaded config
                providers_cfg = llm_cfg.get("providers", {}) or {}
                provider_cfg = providers_cfg.get(provider_name, {})
                
                model = provider_cfg.get("model", "gpt-4o")
                temperature = provider_cfg.get("temperature", 0.7)
                max_tokens = provider_cfg.get("max_tokens", 16384)
                
                llm_configs[agent.agent_id] = LLMConfig(
                    agent_id=agent.agent_id,
                    model=model,
                    provider=provider_name,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                logger.debug(f"Created LLM config for {agent.agent_id}: {provider_name}/{model}")
            except Exception as e:
                logger.warning(f"Failed to load LLM config, using defaults: {str(e)}")
                llm_configs[agent.agent_id] = LLMConfig(
                    agent_id=agent.agent_id,
                    model="gpt-4o",
                    provider="azure_openai",
                    temperature=0.7,
                    max_tokens=16384,
                )
                logger.debug(f"Created default LLM config for {agent.agent_id}")
            
            # ====== 3.4: Parse Local Tools ======
            tools_list = []
            _raw_tools = (agent.local_tools or '').strip().strip('[]').strip()
            if _raw_tools:
                # Format: "tool_name|tool_id|file_path;tool2_name|tool2_id|file_path2"
                tool_entries = _raw_tools.split(";")
                for tool_entry in tool_entries:
                    tool_entry = tool_entry.strip().strip('[]').strip()
                    if not tool_entry:
                        continue
                    
                    parts = [p.strip() for p in tool_entry.split("|")]
                    
                    if len(parts) >= 1:
                        tool_name = parts[0]
                        tool_id = parts[1] if len(parts) > 1 else tool_name
                        file_path = parts[2] if len(parts) > 2 else f"tools/{tool_name}.py"
                        method_name = parts[3] if len(parts) > 3 else None

                        # Class.method dot notation → extract method_name automatically
                        if method_name is None and '.' in tool_name:
                            method_name = tool_name.split('.')[-1]
                        
                        tool_ref = ToolReference(
                            tool_name=tool_name,
                            tool_id=tool_id,
                            file_path=file_path,
                            method_name=method_name
                        )
                        tools_list.append(tool_ref)
                        logger.debug(f"Added tool {tool_name} to agent {agent.agent_id}")
                
                if tools_list:
                    agent_tools[agent.agent_id] = tools_list
            
            # ====== 3.5: Parse MCP Server Mappings ======
            _raw_mcp = (agent.mcp_server or '').strip().strip('[]').strip()
            if _raw_mcp:
                # Format: "server1;server2;server3" — strip brackets stored by some DB serializers
                mcp_servers = [s.strip().strip('[]"\' ') for s in _raw_mcp.split(";") if s.strip().strip('[]"\' ')]
                if mcp_servers:
                    agent_mcp_mappings[agent.agent_id] = AgentMCPMapping(
                        agent_id=agent.agent_id,
                        mcp_servers=mcp_servers
                    )
                    logger.debug(f"Added MCP servers {mcp_servers} to agent {agent.agent_id}")
            
            # ====== 3.6: Add Orchestration Step ======
            orch_step = AgentOrchestrationStep(
                agent_id=agent.agent_id,
                step_index=step_index,
                input_source="user_input" if step_index == 0 else "previous_agent",
                input_key="input" if step_index == 0 else None,
                source_agent_id=agent_mappings[step_index - 1].agent_id if step_index > 0 else None,
                output_key=agent.agent_id
            )
            orchestration.append(orch_step)
            logger.debug(f"Added orchestration step {step_index} for {agent.agent_id}")
        
        # ============================================================
        # Step 4: Collect All MCP Servers (from UserMcpConfig)
        # ============================================================
        mcp_servers = []
        all_mcp_server_ids = set()
        for mapping in agent_mcp_mappings.values():
            all_mcp_server_ids.update(mapping.mcp_servers)
        
        # Query UserMcpConfig for per-user MCP server configurations
        for server_id in all_mcp_server_ids:
            mcp_user_config = None
            if user_obj:
                mcp_user_config = db.query(UserMcpConfig).filter(
                    UserMcpConfig.user_id == user_obj.id,
                    UserMcpConfig.mcp_server_name == server_id,
                    UserMcpConfig.is_active == True
                ).first()
            
            # Build config from user config if available, otherwise use defaults
            mcp_config = MCPServerConfig(
                server_id=server_id,
                server_name=mcp_user_config.mcp_server_name if mcp_user_config else server_id,
                transport="stdio",
                server_type="external"
            )
            mcp_servers.append(mcp_config)
            logger.debug(f"Added MCP server config for {server_id}" + 
                        (f" (user: {user_obj.username})" if mcp_user_config else " (default)"))
        
        # ============================================================
        # Step 5: Define Input/Output Schemas (from Prompt table)
        # ============================================================
        input_schema = {
            "type": "object",
            "properties": {
                "input": {"type": "string"}
            },
            "required": ["input"]
        }
        
        output_schema = {
            "type": "object",
            "properties": {
                "result": {"type": "string"}
            }
        }
        
        # Try to extract schema from first agent's Prompt record
        try:
            first_prompt = db.query(Prompt).filter(
                Prompt.use_case_id == usecase_id
            ).first()
            
            if first_prompt:
                # Build input schema from input_keywords if available
                if first_prompt.input_keywords:
                    keywords = [kw.strip() for kw in str(first_prompt.input_keywords).split(",") if kw.strip()]
                    if keywords:
                        input_schema = {
                            "type": "object",
                            "properties": {
                                kw: {"type": "string"} for kw in keywords
                            },
                            "required": keywords
                        }
                
                # Build output schema from output_format if available
                if first_prompt.output_format:
                    output_schema = {
                        "type": "object",
                        "properties": {
                            "result": {"type": "string", "description": first_prompt.output_format}
                        }
                    }
                
                logger.debug("Extracted schemas from Prompt table")
        except Exception as e:
            logger.warning(f"Could not extract schemas from Prompt table: {str(e)}", exc_info=False)
        
        logger.debug("Defined input/output schemas")
        
        # ============================================================
        # Step 6: Construct UseCaseConfig
        # ============================================================
        config = UseCaseConfig(
            usecase_id=usecase.usecaseid,
            usecase_name=usecase.name,
            version=getattr(usecase, "version", "1.0.0") or "1.0.0",
            description=usecase.task or usecase.role or usecase.name,
            agents=agents,
            orchestration=orchestration,
            agent_tools=agent_tools,
            llm_configs=llm_configs,
            agent_mcp_mappings=agent_mcp_mappings,
            mcp_servers=mcp_servers,
            input_schema=input_schema,
            output_schema=output_schema,
        )
        
        logger.info(
            f"Successfully created UseCaseConfig for {usecase_id}: "
            f"{len(agents)} agents, {len(llm_configs)} LLM configs, "
            f"{len(agent_tools)} agents with tools, {len(mcp_servers)} MCP servers"
        )
        
        return config
    
    except HTTPException:
        # Re-raise HTTP exceptions as-is
        raise
    
    except Exception as e:
        logger.error(f"Error fetching use case config for {usecase_id}: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "status": "failed",
                "error": "CONFIG_FETCH_FAILED",
                "message": f"Failed to fetch use case configuration: {str(e)}"
            }
        )
    
    finally:
        db.close()
        logger.debug("Database session closed")


def _delete_file(path) -> None:
    """Delete a file after it has been streamed to the client."""
    try:
        import os
        os.unlink(path)
        logger.debug(f"Cleaned up temp ZIP: {path}")
    except Exception:
        pass


def _determine_status_code(errors: list) -> int:
    """
    Determine HTTP status code based on error types.
    
    Args:
        errors: List of validation errors
    
    Returns:
        HTTP status code
    """
    error_codes = {error.error_code for error in errors}
    
    # Security errors -> 403
    if 'SECRET_DETECTED_IN_EXPORT' in error_codes:
        return 403
    
    # Not found errors -> 404
    if any(code in error_codes for code in ['USECASE_NOT_FOUND', 'AGENT_NOT_FOUND']):
        return 404
    
    # Configuration errors -> 422
    if any(code in error_codes for code in [
        'TOOL_FILE_NOT_FOUND',
        'MCP_CONFIG_MISSING',
        'LLM_CONFIG_MISSING',
        'CONFIG_FILE_NOT_FOUND',
    ]):
        return 422
    
    # Validation errors -> 400
    return 400
