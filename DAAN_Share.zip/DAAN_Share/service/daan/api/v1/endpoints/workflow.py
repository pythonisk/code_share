"""Workflow execution endpoints — context-map, run-agents, feedback, proceed, finalize, session status."""

import asyncio
from typing import Annotated, Any, Literal
import io
import json
import os
import re
import zipfile
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request, File, UploadFile, Form
from sqlalchemy.orm import Session
from fastapi.responses import FileResponse
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, ConfigDict, Field, model_validator
from uuid import uuid4

from daan.agents.agent_type_utils import is_action_agent
from daan.core.database import get_db
from daan.core.dependencies import get_current_active_user
from daan.admin.team_service import set_team_api_key
from daan.flow.context_vars import set_daan_user_id
from daan.core.logging import get_logger
from daan.core.config import get_settings
from daan.flow.agent_runner import (
    run_action_agents_async,
    run_single_agent_async,
)
from daan.core.observers.reasoning_observer import (
    get_or_create_bus,
    get_reasoning_metrics,
    HEARTBEAT_SENTINEL,
    _BUSES as _REASONING_BUSES,
    _to_jsonable as _reasoning_jsonable,
)
from daan.flow.session_store import (
    SessionState,
    create_session,
    get_session,
)
from daan.flow.session_service import (
    write_agent_output,
    write_reporter_output,
    write_session_token_usage,
    write_quality_output,
    write_refinement_output,
    write_agent_score,
    read_agent_score,
    write_feedback_sample_file,
    write_feedback_sample_schema,
    write_feedback_text,
    read_run_deliverables,
    read_context_map_output,
    write_context_map_output,
    get_artifacts_dir,
)
from daan.llm.cost_tracking import (
    build_cost_record,
    compute_cost_split_usd,
    compute_cost_usd,
    estimate_tokens,
    record_llm_sidecall_cost,
    resolve_agent_provider_and_model,
    resolve_provider_and_model,
)

from daan.feedback.agent_scoring import compute_agent_scores_with_io
from daan.feedback.schema_extractor_agent import extract_schema_json_with_io
from daan.feedback.schema_apply import apply_schema_to_output_with_io
from daan.knowledge_graph import workflow_instrumentation as kg_instr
from daan.observability.quality_store import (
    collect_agent_scores,
    store_session_quality_scores,
)
from daan.utils.azure_devops_work_items import extract_azure_devops_work_items
router = APIRouter()
logger = get_logger(__name__)

def _get_agent_cfg_with_disk_fallback(session: Any, agent_id: str) -> dict[str, Any]:
    """Return agent config, falling back to context_map_output.json when needed.

    This protects scoring/schema sidecalls from missing prompt/context if the
    in-memory session object is incomplete/stale.
    """
    aid = str(agent_id or "").strip()
    if not aid or session is None:
        return {}

    mem_cfg = None
    try:
        mem_cfg = session.get_agent_config(aid)
    except Exception:
        mem_cfg = None

    disk_cfg: dict[str, Any] = {}
    try:
        disk = read_context_map_output(session.session_id)
        for a in (disk.get("agents") or []):
            if str(a.get("agent_id") or "").strip() == aid and isinstance(a, dict):
                disk_cfg = a
                break
    except Exception:
        disk_cfg = {}

    if not isinstance(mem_cfg, dict):
        return disk_cfg if isinstance(disk_cfg, dict) else {}

    if not isinstance(disk_cfg, dict) or not disk_cfg:
        return mem_cfg

    merged = {**disk_cfg, **mem_cfg}
    for key in (
        "agent_name",
        "agent_type",
        "prompt",
        "instruction",
        "task",
        "inputs",
        "output",
        "output_format",
        "context",
        "provider",
        "llm_provider",
        "model_provider",
        "model",
    ):
        if not str(merged.get(key) or "").strip() and str(disk_cfg.get(key) or "").strip():
            merged[key] = disk_cfg.get(key)
    return merged


def _get_or_rehydrate_session_for_execution(session_id: str) -> Any | None:
    """Return a live workflow session, rebuilding it from persisted artifacts when needed.

    Historical sessions restored from Run History are not present in the
    in-memory session store after a server restart. Rehydrate enough state from
    context_map_output.json and saved agent outputs so action/finalize flows can
    continue from the restored session.
    """
    sid = str(session_id or "").strip()
    if not sid:
        return None

    session = get_session(sid)
    context_map = read_context_map_output(sid)
    agents = context_map.get("agents") or []
    if session is not None and agents:
        session.context_map_result = context_map

    if session is None:
        if not agents:
            return None

        archetype = ""
        usecase_id = ""
        try:
            from daan.knowledge_graph.connection import get_kg_connection
            from daan.knowledge_graph import queries as kg_queries

            conn = get_kg_connection()
            meta = kg_queries.get_session_meta(conn, sid) or {}
            archetype = str(meta.get("archetype") or "").strip()
            usecase_id = str(meta.get("usecase_id") or "").strip()
        except Exception:
            archetype = ""
            usecase_id = ""

        if not usecase_id:
            usecase_id = str((context_map.get("usecase_details") or {}).get("usecase_id") or "").strip()
        if not archetype:
            archetype = str((context_map.get("usecase_details") or {}).get("archetype") or "").strip()

        session = create_session(
            session_id=sid,
            user_id=None,
            archetype=archetype,
            usecase_id=usecase_id,
            context_map_result=context_map,
        )
    elif agents:
        session.context_map_result = context_map

    session.context_map_output_path = f"session_storage/{sid}/context_map_output.json"
    session.dynamic_agent_outputs = {}
    session.base_dynamic_agent_outputs = {}
    session.action_agent_outputs = {}
    session.feedback_seq_by_agent = {}

    has_dynamic_outputs = False
    has_action_outputs = False
    for deliverable in read_run_deliverables(sid):
        agent_id = str(deliverable.get("agent_id") or "").strip()
        if not agent_id:
            continue

        content = str(deliverable.get("final_output") or deliverable.get("base_output") or "")
        if not content.strip():
            continue

        agent_cfg = session.get_agent_config(agent_id) or {}
        if is_action_agent(agent_cfg.get("agent_type")):
            session.action_agent_outputs[agent_id] = content
            has_action_outputs = True
        else:
            session.dynamic_agent_outputs[agent_id] = content
            session.base_dynamic_agent_outputs.setdefault(agent_id, content)
            has_dynamic_outputs = True

        fb_seqs = [int(f.get("seq") or 0) for f in (deliverable.get("feedback") or [])]
        if fb_seqs:
            session.feedback_seq_by_agent[agent_id] = max(fb_seqs)

    if has_action_outputs:
        session.state = SessionState.ACTIONS_DONE
    elif has_dynamic_outputs:
        session.state = SessionState.AGENTS_DONE
    else:
        session.state = SessionState.CONTEXT_MAPPED

    session.touch()
    return session

def _read_text_file_from_allowed_roots(path_str: str) -> str:
    """Read a UTF-8 text file from allowed storage roots.

    Only allows files under SESSION_STORAGE_DIR or ./output.
    """
    settings = get_settings()
    # Resolve roots consistently with daan.flow.session_service._storage_root()
    # (i.e., relative paths are interpreted from the repo root, not the process CWD).
    repo_root = Path(__file__).resolve().parents[5]

    session_root = Path(settings.SESSION_STORAGE_DIR)
    if not session_root.is_absolute():
        session_root = repo_root / session_root
    session_root = session_root.resolve()

    output_root = (repo_root / "output").resolve()

    raw = (path_str or "").strip().replace("\\", "/")
    if not raw:
        raise HTTPException(status_code=400, detail="file path is required")

    if raw.startswith("session_storage/"):
        rel = raw[len("session_storage/") :]
        candidate = (session_root / rel).resolve()
    elif raw.startswith("output/"):
        rel = raw[len("output/") :]
        candidate = (output_root / rel).resolve()
    else:
        candidate = Path(raw).resolve()

    allowed = False
    for root in (session_root, output_root):
        if candidate == root or root in candidate.parents:
            allowed = True
            break

    if not allowed:
        raise HTTPException(status_code=400, detail="file path is not under an allowed directory")

    if not candidate.exists() or not candidate.is_file():
        raise HTTPException(status_code=404, detail="file not found")

    try:
        return candidate.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return candidate.read_text(encoding="utf-8", errors="replace")


def _format_exception_for_client(exc: Exception) -> str:
    """Format exceptions for HTTP responses (handles ExceptionGroup)."""
    def _one(e: BaseException) -> str:
        text = str(e).strip()
        if not text:
            text = repr(e)

        chain: list[str] = [text]
        cause = getattr(e, "__cause__", None)
        if isinstance(cause, BaseException) and str(cause).strip():
            chain.append(f"cause={str(cause).strip()}")
        context = getattr(e, "__context__", None)
        if isinstance(context, BaseException) and str(context).strip():
            chain.append(f"context={str(context).strip()}")
        return " ; ".join(chain)

    try:
        if isinstance(exc, BaseExceptionGroup):  # type: ignore[name-defined]
            parts: list[str] = []
            for sub in exc.exceptions:
                parts.append(_one(sub))
            joined = " | ".join(parts)
            return joined or _one(exc)
    except Exception:
        pass

    return _one(exc)


# ── Schemas ─────────────────────────────────────────────────────────────


class SessionStatusMessageResponse(BaseModel):
    """Minimal, UI-focused status message.

    Intentionally small: meant for popup/toast rendering.
    """

    session_id: str
    state: str
    message_format: Literal["markdown", "text"]
    message: str
    error: str | None = None
    updated_at: str | None = None
    poll_after_ms: int = 0


class ContextMapRequest(BaseModel):
    session_id: str
    usecase_id: str
    archetype: str
    extra_context: dict[str, Any] = Field(default_factory=dict)
    # How many files the user attached this run; lets the backend distinguish
    # "no files by choice" from "upload didn't land" when inputs/ is empty.
    uploaded_file_count: int | None = None
    # Per-agent LiteLLM model id overrides scoped to this run only.
    model_overrides: dict[str, str] = Field(default_factory=dict)




class ContextMapResponse(BaseModel):
    session_id: str
    archetype: str
    usecase_id: str
    context_map_output_path: str
    agents: list[dict]


class RunAgentsRequest(BaseModel):
    session_id: str

    model_config = ConfigDict(extra="allow")

    @model_validator(mode="before")
    @classmethod
    def _unwrap_openapi_example_wrapper(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        if "session_id" in data:
            return data
        value = data.get("value")
        if isinstance(value, dict) and "session_id" in value:
            merged = dict(value)
            for key in ("archetype", "usecase_id", "agents"):
                if key in data and key not in merged:
                    merged[key] = data[key]
            return merged
        return data

    model_config = ConfigDict(
        extra="allow",
        json_schema_extra={
            "examples": [
                {
                    "session_id": "string",
                }
            ]
        },
    )


class RunParallelLoopRequest(BaseModel):
    session_id: str
    batch_size: int | None = None


class RunAgentsResponse(BaseModel):
    session_id: str
    state: str
    dynamic_agent_output_paths: dict[str, str]


class ProceedRequest(BaseModel):
    session_id: str


class ProceedResponse(BaseModel):
    session_id: str
    state: str
    action_agent_output_paths: dict[str, str]


class RefinementRequest(BaseModel):
    session_id: str
    provider: str | None = Field(default=None, description="Optional LLM model provider override (e.g., 'openai', 'azure').")


class RefinementResponse(BaseModel):
    session_id: str
    state: str
    skipped: bool = False
    reason: str | None = None
    refinement_output_path: str | None = None
    scores: dict[str, Any] | None = None


class RefinementPromptResponse(BaseModel):
    session_id: str
    available: bool
    prompt: str
    refinement_output_path: str | None = None
    refinement_done: bool = False


class RefinementOutputResponse(BaseModel):
    session_id: str
    available: bool
    content: str
    refinement_output_path: str | None = None
    scores: dict[str, Any] | None = None


class FinalizeRequest(BaseModel):
    session_id: str
    provider: str | None = Field(default=None, description="Optional LLM model provider override (e.g., 'openai', 'azure').")


class FinalizeResponse(BaseModel):
    session_id: str
    state: str
    reporter_output_path: str | None = None
    quality_output_path: str | None = None


class FinalReportContentResponse(BaseModel):
    session_id: str
    reporter_output_path: str
    content: str


class QualityReportContentResponse(BaseModel):
    session_id: str
    quality_output_path: str
    content: str


class SessionStatusResponse(BaseModel):
    session_id: str
    archetype: str
    usecase_id: str
    state: str
    feedback_count: int
    max_feedback: int
    dynamic_agent_output_paths: dict[str, str]
    action_agent_output_paths: dict[str, str]
    reporter_output_path: str | None = None
    quality_output_path: str | None = None
    context_map_output_path: str | None = None
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0
    total_tokens: int = 0
    total_cost_usd: float = 0.0
    provider_cost_totals: dict[str, float] = Field(default_factory=dict)
    agent_cost_records: dict[str, list[dict[str, Any]]] = Field(default_factory=dict)
    has_artifacts: bool = False
    loop_progress: dict[str, Any] = Field(default_factory=dict)
    created_at: str
    updated_at: str
    error: str | None = None

class SessionCostResponse(BaseModel):
    session_id: str
    total_prompt_tokens: int
    total_completion_tokens: int
    total_tokens: int
    total_cost_usd: float
    provider_cost_totals: dict[str, float]
    agent_cost_records: dict[str, list[dict[str, Any]]]


def _record_agent_costs(
    *,
    session: Any,
    run_type: str,
    agents: list[dict[str, Any]],
    outputs: dict[str, str],
    usage_by_agent: dict[str, dict[str, int]],
    input_message: str,
    model_by_agent: dict[str, str] | None = None,
    provider_by_agent: dict[str, str] | None = None,
) -> None:
    """Create normalized cost records for each agent output and attach to session."""
    cfg_by_id = {
        str(a.get("agent_id") or "").strip(): a
        for a in agents
        if str(a.get("agent_id") or "").strip()
    }

    for agent_id, output_text in (outputs or {}).items():
        aid = str(agent_id or "").strip() or "unknown_agent"
        agent_cfg = cfg_by_id.get(aid) or (session.get_agent_config(aid) if hasattr(session, "get_agent_config") else None)
        provider, model = resolve_agent_provider_and_model(agent_cfg)
        runtime_model = str((model_by_agent or {}).get(aid) or "").strip()
        runtime_provider = str((provider_by_agent or {}).get(aid) or "").strip()
        if runtime_model:
            model = runtime_model
        if runtime_provider:
            provider = runtime_provider

        usage = (usage_by_agent or {}).get(aid) or {}
        prompt_tokens = int(usage.get("prompt_tokens") or 0)
        completion_tokens = int(usage.get("completion_tokens") or 0)

        if prompt_tokens == 0 and completion_tokens == 0:
            estimated = estimate_tokens(model=model, prompt=input_message or "", completion=output_text or "")
            prompt_tokens = int(estimated.get("prompt_tokens") or 0)
            completion_tokens = int(estimated.get("completion_tokens") or 0)

        cost_usd = compute_cost_usd(
            model=model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
        )[0]

        rec = build_cost_record(
            agent_id=aid,
            run_type=run_type,
            provider=provider,
            model=model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            cost_usd=cost_usd,
        )
        session.record_agent_cost(aid, rec)
        
_record_llm_sidecall_cost = record_llm_sidecall_cost


def _scoring_context_for_agent(session: Any, agent_cfg: dict[str, Any]) -> str:
    """Resolve the context handed to the evaluator for one agent.

    Action agents receive their real input from upstream (``depends_on``) agents at
    runtime, not from uploaded files; context-mapping therefore leaves a
    ``no_context`` placeholder in their config. Scoring against that placeholder
    makes the evaluator treat a valid run as if it had no input (Context ≈ 0). For
    action agents, build the context from the parents' outputs so the evaluator can
    see the source the output was derived from.
    """
    context = str(agent_cfg.get("context") or "").strip()
    if not is_action_agent(agent_cfg.get("agent_type")):
        return context

    try:
        from daan.flow.dynamic_flow_builder.dynamic_adk_flow import _parse_depends_on
    except Exception:
        return context

    outputs_by_id = {
        **(getattr(session, "dynamic_agent_outputs", None) or {}),
        **(getattr(session, "action_agent_outputs", None) or {}),
    }
    parts: list[str] = []
    for dep in _parse_depends_on(agent_cfg.get("depends_on") or agent_cfg.get("depend_on")):
        text = str(outputs_by_id.get(dep) or "").strip()
        if text:
            parts.append(f"### Output from {dep}\n{text}")
    parent_context = "\n\n".join(parts).strip()
    return parent_context or context


def _score_and_persist_agent_outputs(
    *,
    session: Any,
    agents: list[dict[str, Any]],
    outputs: dict[str, str],
    route_name: str,
) -> None:
    """Best-effort base score persistence for dynamic or action agent outputs."""
    if session is None or not outputs:
        return

    agent_cfg_by_id = {
        str(agent.get("agent_id") or "").strip(): agent
        for agent in agents
        if str(agent.get("agent_id") or "").strip()
    }

    for agent_id, content in outputs.items():
        try:
            agent_cfg = (
                agent_cfg_by_id.get(str(agent_id), {})
                or _get_agent_cfg_with_disk_fallback(session, str(agent_id))
                or {}
            )
            context = _scoring_context_for_agent(session, agent_cfg)
            refined_prompt = str(
                agent_cfg.get("prompt")
                or agent_cfg.get("instruction")
                or agent_cfg.get("task")
                or ""
            ).strip()
            output_format = str(agent_cfg.get("output_format") or agent_cfg.get("output") or "").strip()

            provider, _model = resolve_agent_provider_and_model(agent_cfg)

            score_obj, score_prompt, score_raw, score_meta = compute_agent_scores_with_io(
                agent_id=str(agent_id),
                agent_name=str(agent_cfg.get("agent_name") or agent_id),
                context=context,
                prompt=refined_prompt,
                output=str(content or ""),
                input_keywords=str(agent_cfg.get("inputs") or ""),
                sample_output=output_format,
                schema_authoritative=False,
                provider_name=provider,
            )

            write_agent_score(session.session_id, str(agent_id), score_obj.to_dict())
            _record_llm_sidecall_cost(
                session=session,
                agent_id=str(agent_id),
                run_type="scoring",
                agent_cfg=agent_cfg,
                llm_prompt=score_prompt,
                llm_response=score_raw,
                usage_metadata=score_meta.get("usage"),
                provider_name=str(score_meta.get("provider") or ""),
                model_name=str(score_meta.get("model") or ""),
            )
            _persist_token_usage_snapshot(session)
        except Exception as exc:
            logger.warning(
                "Failed to compute/persist score for agent '%s' during %s: %s",
                agent_id,
                route_name,
                exc,
                extra={"session_id": session.session_id, "agent_id": str(agent_id)},
            )

def _status_message_for_state(session: Any) -> tuple[Literal["markdown", "text"], str, int]:
    """Build a UI-friendly status message from the workflow state."""

    state = str(getattr(session, "state", "") or "")
    # session.state is Enum; get its value if possible
    if hasattr(getattr(session, "state", None), "value"):
        state = str(getattr(session.state, "value") or state)

    feedback_count = int(getattr(session, "feedback_count", 0) or 0)
    max_feedback = int(getattr(session, "max_feedback", 0) or 0)
    remaining = max(max_feedback - feedback_count, 0)

    message_format: Literal["markdown", "text"] = "markdown"
    poll_after_ms = 0

    if state == SessionState.INITIALIZED.value:
        poll_after_ms = 0
        message = "### Session initialized ✅"

    elif state == SessionState.CONTEXT_MAPPED.value:
        poll_after_ms = 0
        message = "### Context mapped ✅"

    elif state == SessionState.AGENTS_RUNNING.value:
        poll_after_ms = 1500
        message = "### Running agents ⏳"

    elif state == SessionState.PARALLEL_AGENTS_RUNNING.value:
        poll_after_ms = 1500
        message = "### Running parallel / loop agents ⏳"

    elif state == SessionState.AGENTS_DONE.value:
        poll_after_ms = 0
        message = (
            "### Draft outputs ready ✅\n\n"
            f"Feedback remaining: **{remaining}/{max_feedback}**."
        )

    elif state == SessionState.ACTIONS_RUNNING.value:
        poll_after_ms = 1500
        message = "### Running action agents ⏳"

    elif state == SessionState.ACTIONS_DONE.value:
        poll_after_ms = 0
        message = "### Action agents completed ✅"

    elif state == SessionState.REPORTING.value:
        poll_after_ms = 1500
        message = "### Generating report ⏳"

    elif state == SessionState.REPORT_DONE.value:
        poll_after_ms = 1500
        message = "### Report generated ✅"

    elif state == SessionState.QUALITY_CHECK.value:
        poll_after_ms = 1500
        message = "### Running quality check ⏳"

    elif state == SessionState.COMPLETED.value:
        poll_after_ms = 0
        message = "### Workflow completed ✅"

    elif state == SessionState.FAILED.value:
        poll_after_ms = 0
        err = str(getattr(session, "error", None) or "Unknown error")
        message = (
            "### Workflow failed ❌\n\n"
            f"**Error:** {err}"
        )

    else:
        poll_after_ms = 1500
        message_format = "markdown"
        message = (
            "### Status unavailable ⚠️\n\n"
            f"Current state: **{state or 'unknown'}**\n\n"
            "Keep polling or check the debug session endpoint."
        )

    return message_format, message, poll_after_ms


def _build_status_message(session: Any) -> SessionStatusMessageResponse:
    message_format, message, poll_after_ms = _status_message_for_state(session)

    sid = str(getattr(session, "session_id", "") or "")
    state = getattr(session, "state", None)
    state_value = str(getattr(state, "value", state) or "")

    return SessionStatusMessageResponse(
        session_id=sid,
        state=state_value,
        message_format=message_format,
        message=message,
        error=getattr(session, "error", None),
        updated_at=getattr(session, "updated_at", None),
        poll_after_ms=poll_after_ms,
    )

def _empty_token_bucket() -> dict[str, int]:
    return {
        "prompt_tokens": 0,
        "completion_tokens": 0,
        "total_tokens": 0,
    }

def _build_token_usage_payload(session: Any) -> dict[str, Any]:
    planning_tokens = _empty_token_bucket()
    reporter_tokens = _empty_token_bucket()
    quality_tokens = _empty_token_bucket()

    agent_execution_agents: list[dict[str, Any]] = []
    agent_execution_summary = _empty_token_bucket()

    total_tokens = _empty_token_bucket()

    planning_cost = 0.0
    reporter_cost = 0.0
    quality_cost = 0.0
    agent_execution_cost = 0.0
    computed_total_cost = 0.0
    input_cost = 0.0
    output_cost = 0.0

    for _agent_id, records in (getattr(session, "agent_cost_records", None) or {}).items():
        for record in records:
            p = int(record.get("prompt_tokens") or 0)
            c = int(record.get("completion_tokens") or 0)
            t = int(record.get("total_tokens") or 0)
            cost = float(record.get("cost_usd") or 0.0)
            in_cost, out_cost = compute_cost_split_usd(record.get("model") or "", p, c)

            total_tokens["prompt_tokens"] += p
            total_tokens["completion_tokens"] += c
            total_tokens["total_tokens"] += t
            computed_total_cost += cost
            input_cost += in_cost
            output_cost += out_cost

            run_type = record.get("run_type")
            agent_name = record.get("agent_id")

            if run_type in ("planning", "context_map"):
                planning_tokens["prompt_tokens"] += p
                planning_tokens["completion_tokens"] += c
                planning_tokens["total_tokens"] += t
                planning_cost += cost
            elif agent_name == "REPORTER_AGENT":
                reporter_tokens["prompt_tokens"] += p
                reporter_tokens["completion_tokens"] += c
                reporter_tokens["total_tokens"] += t
                reporter_cost += cost
            elif agent_name == "QUALITY_AGENT":
                quality_tokens["prompt_tokens"] += p
                quality_tokens["completion_tokens"] += c
                quality_tokens["total_tokens"] += t
                quality_cost += cost
            else:
                agent_execution_agents.append(
                    {
                        "agent_id": agent_name,
                        "run_type": run_type,
                        "model": record.get("model"),
                        "prompt_tokens": p,
                        "completion_tokens": c,
                        "total_tokens": t,
                        "cost_usd": round(cost, 6),
                    }
                )
                agent_execution_summary["prompt_tokens"] += p
                agent_execution_summary["completion_tokens"] += c
                agent_execution_summary["total_tokens"] += t
                agent_execution_cost += cost

    # The freshly recomputed split (input + output) is the coherent total and
    # stays correct even for sessions whose stored cost_usd was 0/None. Fall
    # back to the session/record totals only when the split is unavailable.
    recomputed_total = input_cost + output_cost
    session_total_cost = getattr(session, "total_cost_usd", None) or 0.0
    total_cost = recomputed_total or float(session_total_cost) or computed_total_cost

    return {
        "session_id": session.session_id,
        "planning_tokens": planning_tokens,
        "planning_cost_usd": round(planning_cost, 6),
        "agent_execution_tokens": {
            "agents": agent_execution_agents,
            "summary": agent_execution_summary,
            "cost_usd": round(agent_execution_cost, 6),
        },
        "reporter_agent": reporter_tokens,
        "reporter_cost_usd": round(reporter_cost, 6),
        "quality_assessment": quality_tokens,
        "quality_cost_usd": round(quality_cost, 6),
        "total_tokens": total_tokens,
        "input_cost_usd": round(input_cost, 6),
        "output_cost_usd": round(output_cost, 6),
        "total_cost_usd": round(total_cost, 6),
    }


def _persist_token_usage_snapshot(session: Any) -> None:
    """Best-effort write of cumulative token usage for a session."""
    try:
        payload = _build_token_usage_payload(session)
        write_session_token_usage(session.session_id, payload)
    except Exception:
        pass

# ── Endpoints ───────────────────────────────────────────────────────────


@router.post("/context-map", response_model=ContextMapResponse)
def context_map_route(
    request: ContextMapRequest,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> ContextMapResponse:
    """Extract context for use case agents from input files."""
    _ = current_user

    from daan.usecases.usecase_service import get_usecase_details
    from daan.flow.supervisor import ContextMapper

    requested_session_id = (request.session_id or "").strip()
    if not requested_session_id:
        logger.warning("Context map requested without session_id", extra={
            "endpoint": "/context-map",
            "archetype": request.archetype,
            "usecase_id": request.usecase_id
        })
        raise HTTPException(status_code=400, detail="session_id is required")
    
    logger.info("Context map requested", extra={
        "session_id": requested_session_id,
        "endpoint": "/context-map",
        "archetype": request.archetype,
        "usecase_id": request.usecase_id,
        "has_extra_context": bool(request.extra_context)
    })

    try:
        details = get_usecase_details(request.archetype, request.usecase_id)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    agents = details.get("agents", [])
    if not agents:
        raise HTTPException(status_code=404, detail="No agents found for this use case")

    # If extra_context contains free-text inputs (e.g. dashboard_prompts), write them as
    # .txt files into the session inputs folder BEFORE context mapping runs so that
    # SmartContextManager can pick them up and map them to the correct agent input variables.
    _text_input_keys = {"dashboard_prompts", "requirements_context", "business_requirements"}
    extra_context_pre = request.extra_context or {}
    for key, value in extra_context_pre.items():
        if key in _text_input_keys and value and isinstance(value, str) and value.strip():
            try:
                from daan.flow.session_service import get_inputs_dir, create_session_dir
                create_session_dir(requested_session_id)
                inputs_dir = get_inputs_dir(requested_session_id)
                inputs_dir.mkdir(parents=True, exist_ok=True)
                txt_file = inputs_dir / f"{key}.txt"
                txt_file.write_text(value.strip(), encoding="utf-8")
                logger.info("Wrote extra_context text input '%s' to session inputs", key, extra={"session_id": requested_session_id})
            except Exception as _e:
                logger.warning("Failed to write extra_context key '%s' to file: %s", key, _e)

    # Set team virtual key for this request context
    user_id = getattr(current_user, "id", None)
    set_daan_user_id(user_id)
    if user_id:
        db = next(get_db())
        try:
            from daan.admin.team_service import get_active_api_key_for_user, set_team_api_key
            team_key = get_active_api_key_for_user(db, user_id)
            set_team_api_key(team_key)
        finally:
            db.close()

    try:
        context_map_result = ContextMapper.run_detailed(
            agents=agents,
            usecase_details=details.get("usecase_details", {}),
            session_id=requested_session_id,
            uploaded_file_count=request.uploaded_file_count,
        )
        enriched_agents = context_map_result["agents"]
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        # Surface the real cause instead of a bare 500 so the UI/log show why mapping failed.
        logger.exception("Context map failed for session %s", requested_session_id)
        raise HTTPException(status_code=500, detail=f"Context mapping failed: {exc}") from exc

    # Collect any extra runtime fields from the request (e.g. Databricks credentials,
    # Jira keys, Snowflake config, etc.). These are forwarded into every action agent's
    # context so tools can read them from reviewed_output.
    # NOTE: must be done BEFORE saving to session so credentials are persisted.
    extra_context = request.extra_context or {}
    if extra_context:
        enriched_agents = [
            {**a, **extra_context,
             "context": (a.get("context") or "") + "\n" + "\n".join(f"{k}: {v}" for k, v in extra_context.items())}
            #if a.get("agent_type", "").lower() == "action_agent"
            if is_action_agent(a.get("agent_type"))
            else {**a, **extra_context}
            for a in enriched_agents
        ]

    # Per-run model overrides: agent_id -> LiteLLM model id (session-scoped, not persisted).
    run_model_overrides = request.model_overrides or {}
    if run_model_overrides:
        for a in enriched_agents:
            aid = str(a.get("agent_id") or "").strip()
            override = str(run_model_overrides.get(aid) or "").strip()
            if override:
                a["model"] = override
        # Re-persist the enriched agents to context_map_output.json so
        # /run-next-stage sees the overrides after rehydrating from disk.
        try:
            existing_disk = read_context_map_output(requested_session_id) or {}
            existing_disk["agents"] = enriched_agents
            write_context_map_output(requested_session_id, existing_disk)
        except Exception:
            logger.warning(
                "Failed to persist model_overrides to context_map_output.json for session '%s'",
                requested_session_id,
            )

    session = None
    # Cache enriched agent configs (with credentials) in session store
    try:
        existing = get_session(requested_session_id)
        if existing is None:
            existing = create_session(
                session_id=requested_session_id,
                user_id=getattr(current_user, "id", None),
                archetype=request.archetype,
                usecase_id=request.usecase_id,
                context_map_result={
                    "agents": enriched_agents,
                    "dag": context_map_result.get("dag", ""),
                    "usecase_details": details.get("usecase_details", {}),
                },
            )
        else:
            if getattr(existing, "user_id", None) is None:
                existing.user_id = getattr(current_user, "id", None)
            existing.archetype = request.archetype
            existing.usecase_id = request.usecase_id
            existing.context_map_result = {
                "agents": enriched_agents,
                "dag": context_map_result.get("dag", ""),
                "usecase_details": details.get("usecase_details", {}),
            }
            existing.touch()
        existing.state = SessionState.CONTEXT_MAPPED
        existing.context_map_output_path = f"session_storage/{requested_session_id}/context_map_output.json"
        existing.touch()
        session = existing
    except Exception:
        pass
    
    # Record planner/context-map token usage into session totals.
    if session is not None:
        planning_usage = (context_map_result.get("token_usage") or {}) if isinstance(context_map_result, dict) else {}
        planner_input = (
            f"context_map archetype={request.archetype} usecase_id={request.usecase_id} "
            f"agent_count={len(agents)}"
        )
        planner_output = json.dumps(
            {
                "session_id": requested_session_id,
                "mapped_agents": [str(a.get("agent_id") or "") for a in enriched_agents],
                "context_chars": sum(len(str(a.get("context") or "")) for a in enriched_agents),
            },
            ensure_ascii=False,
        )
        _record_agent_costs(
            session=session,
            run_type="context_map",
            agents=[],
            outputs={"CONTEXT_MAPPER": planner_output},
            usage_by_agent={"CONTEXT_MAPPER": planning_usage},
            input_message=planner_input,
            model_by_agent={"CONTEXT_MAPPER": str(planning_usage.get("model") or "").strip()} if str(planning_usage.get("model") or "").strip() else None,
            provider_by_agent={"CONTEXT_MAPPER": str(planning_usage.get("provider") or "").strip()} if str(planning_usage.get("provider") or "").strip() else None,
        )
        _persist_token_usage_snapshot(session)

    # ── KG: record session creation (best-effort) ───────────────────────
    usecase_name = str((details.get("usecase_details") or {}).get("name") or "")
    kg_instr.record_session_created(
        requested_session_id, current_user, request.archetype, request.usecase_id, usecase_name
    )

    logger.info("Context map completed successfully", extra={
        "session_id": requested_session_id,
        "endpoint": "/context-map",
        "archetype": request.archetype,
        "usecase_id": request.usecase_id,
        "agent_count": len(enriched_agents),
        "context_map_output_path": f"session_storage/{requested_session_id}/context_map_output.json"
    })
    
    return ContextMapResponse(
        session_id=requested_session_id,
        archetype=request.archetype,
        usecase_id=request.usecase_id,
        context_map_output_path=f"session_storage/{requested_session_id}/context_map_output.json",
        agents=enriched_agents,
    )


# ---------------------------------------------------------------------------
# POST /run-next-stage  (generic, stage-by-stage execution for any DAG)
# ---------------------------------------------------------------------------

# Fallback batch size for loop agents whose use case sets no loop_config.
_DEFAULT_LOOP_BATCH_SIZE = 5


class RunNextStageRequest(BaseModel):
    session_id: str
    batch_size: int | None = None
    # Per-agent LiteLLM model id overrides applied to this run only.
    model_overrides: dict[str, str] = Field(default_factory=dict)


class RunNextStageResponse(BaseModel):
    session_id: str
    state: str
    stage_index: int
    stage_type: str
    ran_agents: list[str]
    agent_output_paths: dict[str, str]
    has_more_stages: bool


@router.post("/run-next-stage", response_model=RunNextStageResponse)
async def run_next_stage_route(
    request: RunNextStageRequest,
    current_user: Annotated[object, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> RunNextStageResponse:
    """Execute the next pending stage of the workflow and pause.

    Stage order and mode come from the use case ``dag``; each agent's input is
    assembled from its ``depends_on`` parents' outputs. Runs one stage per call.
    """
    from daan.admin.team_service import get_active_api_key_for_user
    from daan.flow import stage_executor

    user_id = getattr(current_user, "id", None)
    set_daan_user_id(user_id)
    if user_id:
        set_team_api_key(get_active_api_key_for_user(db, user_id))

    session_id = (request.session_id or "").strip()
    if not session_id:
        raise HTTPException(status_code=400, detail="session_id is required")

    # Prime the reasoning bus up-front so agent_runner's `get_bus(sid)` finds
    # the same instance during streaming; terminal events append to it below.
    get_or_create_bus(session_id)

    session = _get_or_rehydrate_session_for_execution(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found. Call /api/workflow/context-map first.")
    if getattr(session, "user_id", None) is None:
        session.user_id = user_id

    agents = list(session.context_map_result.get("agents", []) or [])
    if not agents:
        raise HTTPException(status_code=404, detail="No agents found for this session.")

    agents_by_id: dict[str, dict[str, Any]] = {
        str(a.get("agent_id") or "").strip(): a
        for a in agents
        if str(a.get("agent_id") or "").strip()
    }

     # Apply per-run model overrides so the freshest UI selection wins over the saved config.
    run_model_overrides = request.model_overrides or {}
    applied_overrides = False
    for aid, model in run_model_overrides.items():
        model = str(model or "").strip()
        if model and aid in agents_by_id:
            agents_by_id[aid]["model"] = model
            applied_overrides = True
    if applied_overrides:
        session.context_map_result = {
            **(session.context_map_result or {}),
            "agents": list(agents_by_id.values()),
        }
        try:
            disk = read_context_map_output(session_id) or {}
            disk["agents"] = list(agents_by_id.values())
            write_context_map_output(session_id, disk)
        except Exception:
            logger.warning(
                "Failed to persist run-time model_overrides to context_map_output.json for '%s'",
                session_id,
            )

    # DAG is authoritative for stage order + mode; loop_config supplies batch size.
    batch_size = int(request.batch_size or 0)
    dag_str = str(session.context_map_result.get("dag") or "")
    if session.usecase_id:
        try:
            from daan.core.database import SessionLocal
            from daan.models.archetype import UseCase as UseCaseModel
            with SessionLocal() as _uc_db:
                uc = _uc_db.query(UseCaseModel).filter(UseCaseModel.usecaseid == session.usecase_id).first()
                if uc:
                    if not dag_str:
                        dag_str = str(getattr(uc, "dag", "") or "")
                    if batch_size <= 0 and getattr(uc, "loop_config", None):
                        batch_size = int(uc.loop_config)
        except Exception as exc:
            logger.warning("Could not load use case %s for DAG: %s", session.usecase_id, exc)
    if batch_size <= 0:
        batch_size = _DEFAULT_LOOP_BATCH_SIZE

    plan = stage_executor.build_stage_plan(agents, dag_str)
    if not plan:
        raise HTTPException(status_code=400, detail="No runnable stages for this session.")

    outputs_by_id: dict[str, str] = {
        **(session.dynamic_agent_outputs or {}),
        **(session.action_agent_outputs or {}),
    }
    completed_ids = {aid for aid, txt in outputs_by_id.items() if str(txt or "").strip()}

    stage_index, stage = stage_executor.next_pending_stage(plan, completed_ids)
    if stage is None:
        session.state = SessionState.AGENTS_DONE
        session.touch()
        _persist_token_usage_snapshot(session)
        return RunNextStageResponse(
            session_id=session.session_id,
            state=session.state.value,
            stage_index=len(plan),
            stage_type="",
            ran_agents=[],
            agent_output_paths={},
            has_more_stages=False,
        )

    stage_cfgs = [agents_by_id[aid] for aid in stage["agents"]]
    session.state = SessionState.AGENTS_RUNNING
    session.touch()

    # Resolve credentials once; initialise MCP per agent (isolated) for those that declare a server.
    from daan.core.credential_resolver import CredentialResolver
    _cr = CredentialResolver(next(get_db()), session.user_id or 0)

    mcp_by_agent: dict[str, Any] = {}
    stage_needs_mcp = [c for c in stage_cfgs if str(c.get("mcp_tools") or c.get("mcp_server") or "").strip()]
    if stage_needs_mcp:
        from daan.mcp_servers.core.mcp_toolset_provider import initialize_mcp_for_agents
        for c in stage_needs_mcp:
            aid = str(c.get("agent_id") or "").strip()
            mcp_by_agent[aid] = await initialize_mcp_for_agents(
                [c], session.session_id, credential_resolver=_cr
            )

    try:
        outputs, usage_by_agent, model_by_agent, provider_by_agent, errors = await stage_executor.run_stage_async(
            session_id=session.session_id,
            stage=stage,
            agents_by_id=agents_by_id,
            outputs_by_id=outputs_by_id,
            mcp_by_agent=mcp_by_agent,
            batch_size=batch_size,
            credential_resolver=_cr,
        )
    except Exception as exc:
        session.state = SessionState.FAILED
        session.error = _format_exception_for_client(exc)
        session.touch()
        raise HTTPException(status_code=500, detail=f"Stage execution failed: {session.error}")

    if errors:
        session.state = SessionState.FAILED
        session.error = "; ".join(f"{aid}: {_format_exception_for_client(exc)}" for aid, exc in errors)
        session.touch()
        raise HTTPException(status_code=500, detail=f"Stage execution failed: {session.error}")

    # Normalize action-agent outputs to readable text BEFORE they are stored and
    # scored, so the evaluator (and disk/UI) see the same clean summary instead
    # of raw MCP tool JSON. Uses the same renderer as the read-time display path.
    for aid in list(outputs.keys()):
        cfg = agents_by_id.get(aid, {})
        if is_action_agent(cfg.get("agent_type")):
            outputs[aid] = _make_action_output_readable(aid, str(outputs.get(aid) or ""))

    # Persist outputs; keep type-keyed maps so the rest of the app keeps working.
    agent_output_paths: dict[str, str] = {}
    for aid, content in outputs.items():
        content = str(content or "").strip()
        if not content:
            session.state = SessionState.FAILED
            session.error = f"Agent '{aid}' returned empty output"
            session.touch()
            raise HTTPException(status_code=500, detail=session.error)
        cfg = agents_by_id.get(aid, {})
        path = write_agent_output(session.session_id, aid, content)
        agent_output_paths[aid] = path
        if is_action_agent(cfg.get("agent_type")):
            session.action_agent_outputs[aid] = content
            session.action_agent_output_paths[aid] = path
        else:
            session.dynamic_agent_outputs[aid] = content
            session.dynamic_agent_output_paths[aid] = path
            if not session.base_dynamic_agent_outputs:
                session.base_dynamic_agent_outputs = {}
            session.base_dynamic_agent_outputs.setdefault(aid, content)

    _record_agent_costs(
        session=session,
        run_type="stage",
        agents=stage_cfgs,
        outputs=outputs,
        usage_by_agent=usage_by_agent,
        input_message="",
        model_by_agent=model_by_agent,
        provider_by_agent=provider_by_agent,
    )
    _score_and_persist_agent_outputs(
        session=session, agents=stage_cfgs, outputs=outputs, route_name="/run-next-stage",
    )
    _persist_token_usage_snapshot(session)

    try:
        kg_instr.record_agent_run(
            session, current_user, stage_cfgs, outputs, agent_output_paths, trigger="stage",
        )
    except Exception:
        logger.debug("KG record_agent_run skipped", exc_info=True)

    completed_after = {
        aid
        for aid, txt in {
            **(session.dynamic_agent_outputs or {}),
            **(session.action_agent_outputs or {}),
        }.items()
        if str(txt or "").strip()
    }
    more = stage_executor.has_more_stages(plan, completed_after)
    session.state = SessionState.AGENTS_RUNNING if more else SessionState.AGENTS_DONE
    session.touch()

    logger.info(
        "Stage executed",
        extra={
            "session_id": session.session_id,
            "endpoint": "/run-next-stage",
            "stage_index": stage_index,
            "stage_type": stage.get("type"),
            "ran_agents": list(outputs.keys()),
            "has_more_stages": more,
        },
    )

    response = RunNextStageResponse(
        session_id=session.session_id,
        state=session.state.value,
        stage_index=stage_index,
        stage_type=str(stage.get("type") or "sequential"),
        ran_agents=list(outputs.keys()),
        agent_output_paths=agent_output_paths,
        has_more_stages=more,
    )

    # Emit lifecycle events to the reasoning bus so the UI's polling tab
    # sees the closing steps (agent_complete per ran agent, then
    # stage_complete and final).
    reasoning_bus = get_or_create_bus(session.session_id)
    for ran_aid in outputs.keys():
        agent_cfg = agents_by_id.get(ran_aid, {})
        reasoning_bus.emit(
            "agent_complete",
            {
                "agent_id": ran_aid,
                "agent_name": str(agent_cfg.get("agent_name") or ran_aid),
            },
        )
    reasoning_bus.emit(
        "stage_complete",
        {"stage_index": stage_index, "ran_agents": list(outputs.keys())},
    )
    reasoning_bus.emit(
        "final",
        {"result": _reasoning_jsonable(response.model_dump())},
    )
    return response


# ---------------------------------------------------------------------------
# SSE (push) transport for reasoning events.
#
# Design notes vs the earlier failed SSE attempt:
#   * Pure subscriber — this endpoint never drives the stage. Closing the
#     stream (tab close, network flap) unsubscribes without cancelling the
#     agent run. The stage is still started by POST /run-next-stage.
#   * Bus subscribe() is push-based (asyncio.Queue); no server-side polling.
#   * Honors Last-Event-ID (SSE spec) and ?after=N (belt-and-braces) so the
#     client resumes from the exact seq it saw last.
#   * Frames include `id: <seq>` so browser EventSource reconnects populate
#     Last-Event-ID automatically.
#   * Heartbeat comment every 10s to defeat 30-60s idle-close proxies.
#   * Response headers set so gzip / X-Accel buffering can't stall the stream.
# The old POST/GET run-next-stage/stream routes and _build_stream_response
# have been removed — they conflated control plane with data plane, which is
# what caused the "client abort → stage cancelled" regression.
# ---------------------------------------------------------------------------


def _sse_frame(event: dict[str, Any]) -> str:
    """Format one event as an SSE frame with `id:` for Last-Event-ID resume."""
    event_type = str(event.get("type") or "message")
    seq = event.get("seq")
    try:
        data = json.dumps(event, default=str, ensure_ascii=False)
    except Exception:
        data = json.dumps({"v": 1, "type": "error", "message": "unserializable event"})
    if seq is None:
        return f"event: {event_type}\ndata: {data}\n\n"
    return f"id: {seq}\nevent: {event_type}\ndata: {data}\n\n"


# 10s: 3-6x headroom under typical 30-60s proxy idle-close; costs ~7 bytes.
_SSE_HEARTBEAT_SECONDS = 10.0


async def _reasoning_stream_generator(session_id: str, after_seq: int):
    """Yield SSE frames for the given session, replaying from ``after_seq``.

    Never raises; on any bus-not-found / cancellation path we emit one final
    frame (or just return) so the client sees a clean close.
    """
    logger.info("SSE reasoning-stream opened session=%s after=%s", session_id, after_seq)
    # Header flush: many proxies won't send response headers until they see
    # the first body byte, so this comment unblocks the client immediately.
    yield ": stream-open\n\n"

    # get_or_create so a subscriber that beats POST /run-next-stage still
    # gets a live bus to attach to; the POST will find the same instance.
    bus = get_or_create_bus(session_id)

    subscriber = bus.subscribe(after_seq)
    yielded = 0
    try:
        async for event in subscriber:
            if event is HEARTBEAT_SENTINEL:
                yield ": ping\n\n"
                continue
            yield _sse_frame(event)
            yielded += 1
    except asyncio.CancelledError:
        # Client disconnected. This is normal — do NOT propagate to the stage.
        logger.info(
            "SSE reasoning-stream client disconnected session=%s yielded=%d bus_seq=%d",
            session_id, yielded, getattr(bus, "_seq", -1),
        )
        raise
    finally:
        # Async generators must be closed so the `finally` inside subscribe()
        # runs and unregisters the queue.
        try:
            await subscriber.aclose()
        except Exception:
            pass
        logger.info(
            "SSE reasoning-stream closed session=%s yielded=%d bus_seq=%d",
            session_id, yielded, getattr(bus, "_seq", -1),
        )


@router.get("/session/{session_id}/reasoning-stream")
async def reasoning_stream_route(
    session_id: str,
    request: Request,
    current_user: Annotated[object, Depends(get_current_active_user)],
    after: int = -1,
) -> StreamingResponse:
    """Server-Sent Events stream of reasoning events for a session."""
    _ = current_user
    # Last-Event-ID (SSE spec) wins over ?after= when both present, since it
    # reflects what the browser actually received on a prior connection.
    last_event_id = request.headers.get("last-event-id")
    after_seq = after
    if last_event_id is not None:
        try:
            after_seq = int(last_event_id)
        except ValueError:
            pass
    return StreamingResponse(
        _reasoning_stream_generator(session_id, after_seq),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
            # Prevent any downstream compressor from double-encoding.
            "Content-Encoding": "identity",
        },
    )


@router.get("/reasoning-diagnostics")
def reasoning_diagnostics_route(
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> dict[str, Any]:
    """Diagnostic: module counters + per-bus snapshot for debugging."""
    _ = current_user
    import time as _time
    buses = []
    for sid, bus in list(_REASONING_BUSES.items()):
        buses.append({
            "session_id": sid,
            "closed": bus._closed,
            "event_count": len(bus._events),
            "seq": bus._seq,
            "age_seconds": round(_time.time() - bus._created_at, 1),
        })
    return {"metrics": get_reasoning_metrics(), "buses": buses}


# ---------------------------------------------------------------------------
# Output formatting helpers
# ---------------------------------------------------------------------------

_RESOURCE_MANIFEST_FENCE_RE = re.compile(
    r"```[^\S\r\n]*[A-Za-z0-9_-]*[^\S\r\n]*\r?\n(\{.*?\})\r?\n```",
    re.DOTALL,
)
_HTML_TAG_RE = re.compile(r"<[^>]+>")


def _strip_html(text: str) -> str:
    return _HTML_TAG_RE.sub("", text).strip()


def _try_render_azure_devops_work_items(raw: str) -> str | None:
    """Render Azure DevOps work items as a readable Markdown summary.

    Parses the raw output, extracts any work items, and formats them. Returns
    None when the output doesn't contain Azure DevOps work items, so the caller
    can fall back to another display format.
    """
    try:
        parsed = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return None

    work_items = extract_azure_devops_work_items(parsed)
    if not work_items:
        return None

    lines = [f"\u2705 Created {len(work_items)} Azure DevOps work item(s):"]
    for w in work_items:
        fields = w.get("fields") or {}
        wid = w.get("id")
        wtype = str(fields.get("System.WorkItemType") or "Work Item")
        title = str(fields.get("System.Title") or "(untitled)")
        state = str(fields.get("System.State") or "").strip()
        html = (((w.get("_links") or {}).get("html") or {}).get("href")) or w.get("url") or ""
        suffix = f" ({state})" if state else ""
        line = f"- **{wtype} #{wid}** \u2014 {title}{suffix}"
        if html:
            line += f" \u2014 {html}"
        lines.append(line)
    return "\n".join(lines).strip()


def _make_action_output_readable(agent_id: str, raw: str) -> str:
    """Display action-agent output cleanly: show whatever the API returns,
    strip HTML tags, skip large document-body fields."""
    if not raw or not raw.strip():
        return raw

    stripped = raw.strip()

    # Azure DevOps work items don't match the generic branches below, so try
    # rendering them first.
    azure_rendered = _try_render_azure_devops_work_items(stripped)
    if azure_rendered is not None:
        return azure_rendered

    # ── Shape 1: raw MCP content-block JSON [{type:"text",text:"{json}"}] ────
    obj: dict | None = None
    try:
        parsed = json.loads(stripped)
        blocks = parsed if isinstance(parsed, list) else [parsed]
        for block in blocks:
            if isinstance(block, dict) and block.get("type") == "text":
                inner = block.get("text")
                if isinstance(inner, str):
                    try:
                        candidate = json.loads(inner)
                        if isinstance(candidate, dict) and ("status" in candidate or "success" in candidate):
                            obj = candidate
                            break
                    except (json.JSONDecodeError, ValueError):
                        continue
        if obj is None and isinstance(parsed, dict) and ("status" in parsed or "success" in parsed):
            obj = parsed
    except (json.JSONDecodeError, ValueError):
        pass

    if obj is not None:
        # Batch-publish tool result (e.g. Trello PublishUserStoryCards):
        # {"success":.., "data": {"created_cards": [...], "board_url":.., "summary":..}}
        # Render as a readable card list instead of dumping the raw JSON.
        data_field = obj.get("data") if isinstance(obj.get("data"), dict) else None
        if data_field is not None and "created_cards" in data_field:
            card_lines: list[str] = []
            created = data_field.get("created_cards") or []
            skipped = data_field.get("skipped_cards") or []
            summary = data_field.get("summary") or {}
            board_url = data_field.get("board_url")

            card_lines.append(f"\u2705 Created {len(created)} card(s) on the Trello board:")
            for card in created:
                title = card.get("title") or "Untitled card"
                url = card.get("card_url") or ""
                card_lines.append(f"- **{title}** \u2014 {url}" if url else f"- **{title}**")

            if skipped:
                card_lines.append(f"\n\u23ed\ufe0f Skipped {len(skipped)} duplicate(s):")
                for card in skipped:
                    card_lines.append(f"- {card.get('title', 'Untitled card')} ({card.get('reason', 'duplicate')})")

            warnings = data_field.get("warnings") or obj.get("warnings") or []
            if warnings:
                card_lines.append("\n\u26a0\ufe0f Warnings:")
                for warning in warnings:
                    card_lines.append(f"- {warning}")

            if board_url:
                card_lines.append(f"\nBoard: {board_url}")
            if summary:
                card_lines.append(
                    f"\nSummary: {summary.get('created', len(created))} created, "
                    f"{summary.get('skipped_duplicates', len(skipped))} skipped, "
                    f"{summary.get('failed', 0)} failed (of {summary.get('total_input_cards', len(created) + len(skipped))} total)."
                )
            return "\n".join(card_lines).strip()

        lines: list[str] = []

        status = str(obj.get("status") or "").strip()
        if not status and "success" in obj:
            status = "success" if obj.get("success") else "error"
        if status:
            icon = "\u2705" if status.lower() in ("success", "ok", "created") else "\u26a0\ufe0f"
            lines += [f"{icon} **Status:** {status}", ""]

        message = obj.get("message")
        if message:
            lines += [_strip_html(str(message)), ""]

        # Flatten nested page/resource/result dicts into one display dict
        detail: dict = {}
        for key in ("page", "resource", "result"):
            val = obj.get(key)
            if isinstance(val, dict):
                detail.update(val)
        detail.update({k: v for k, v in obj.items() if k not in ("status", "message", "page", "resource", "result")})

        # Reconstruct Confluence URL when id is known but url is missing.
        # Only do this when CONFLUENCE_BASE_URL is actually configured in this
        # process — never fall back to a hardcoded domain, since that could
        # silently point the user at a completely different Confluence tenant.
        if not detail.get("url") and detail.get("id"):
            base = os.getenv("CONFLUENCE_BASE_URL", "").rstrip("/")
            if base:
                page_id = str(detail["id"]).strip()
                space = str(detail.get("space_key") or "").strip()
                if space:
                    title_slug = re.sub(r"[^\w]+", "+", str(detail.get("title") or "").strip())
                    detail["url"] = f"{base}/spaces/{space}/pages/{page_id}/{title_slug}"
                else:
                    # space_key absent (retrieve response) — use the direct-ID short URL
                    detail["url"] = f"{base}/pages/{page_id}"

        # Large document-body fields are redundant — dynamic agent shows the doc
        skip_keys = {"content", "body", "storage", "html", "value", "markdown"}
        for k, v in detail.items():
            if k in skip_keys or v is None or v == "" or isinstance(v, (dict, list)):
                continue
            v_str = _strip_html(str(v))
            if not v_str or len(v_str) > 300:
                continue
            label = k.replace("_", " ").title()
            if v_str.startswith("http://") or v_str.startswith("https://"):
                # Show a short label for URL fields so long links don't crowd the summary.
                link_text = "Open link" if k.lower() == "url" else v_str
                lines.append(f"- **{label}:** [{link_text}]({v_str})")
            else:
                lines.append(f"- **{label}:** {v_str}")

        result = "\n".join(lines).strip()
        return result if result else raw

    # ── Shape 2: already human-readable — strip machine tail + HTML ──────────
    result = raw
    # Some tools return their message wrapped in a JSON envelope. When that
    # message is plain text (not structured data), show the message itself
    # instead of the raw envelope.
    try:
        env = json.loads(stripped)
        env_blocks = env if isinstance(env, list) else [env]
        env_texts = [
            b["text"] for b in env_blocks
            if isinstance(b, dict) and b.get("type") == "text" and isinstance(b.get("text"), str)
        ]
        if env_texts:
            result = "\n".join(env_texts).strip() or raw
    except (json.JSONDecodeError, ValueError):
        pass
    # Remove the resource-manifest fenced block appended by the agent
    for m in list(_RESOURCE_MANIFEST_FENCE_RE.finditer(raw)):
        try:
            data = json.loads(m.group(1))
        except (json.JSONDecodeError, ValueError):
            continue
        if isinstance(data, dict) and isinstance(data.get("resources"), list):
            result = result.replace(m.group(0), "")
    result = re.sub(r"(?im)^[^\n]*\bresource manifest\b[^\n]*\n?", "", result)
    # Remove any "Published Content" section (full document body — already shown by dynamic agent)
    result = re.sub(r"\n*###\s*Published Content\s*\n.*$", "", result, flags=re.DOTALL)
    # Strip residual HTML tags
    result = _HTML_TAG_RE.sub("", result)
    return result.strip() or raw

class AgentOutputView(BaseModel):
    session_id: str
    usecase_id: str | None = None
    agent_id: str
    agent_name: str | None = None
    output_path: str | None = None
    content: str | None = None
    score: dict[str, Any] | None = None
    feedback_id: str | None = None
    rerun_id: str | None = None


@router.get("/agent/output", response_model=AgentOutputView)
def feedback_output_route(
    session_id: str,
    agent_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
    usecase_id: str | None = None,
) -> AgentOutputView:
    """Fetch the latest effective output path for an agent from the session store."""
    _ = current_user

    sid = (session_id or "").strip()
    aid = (agent_id or "").strip()
    ucid = (usecase_id or "").strip() if usecase_id is not None else None
    
    logger.info("Agent output requested", extra={
        "session_id": sid,
        "endpoint": "/agent/output",
        "agent_id": aid,
        "usecase_id": ucid
    })

    session = get_session(sid)

    if session is not None and ucid and session.usecase_id and session.usecase_id != ucid:
        raise HTTPException(
            status_code=404,
            detail=f"Session '{sid}' is for usecase '{session.usecase_id}', not '{ucid}'.",
        )

    # ── Disk-first: return the NEWEST persisted revision ────────────────────
    # read_run_deliverables picks the most-recently-written output (base or any
    # feedback/{seq}) by mtime, so it reflects cascade reruns (e.g. a downstream
    # action agent republished after an upstream Keep). Reading from disk also
    # keeps this endpoint consistent with the run-history view and survives a
    # backend restart, where the in-memory session (and its output paths) is
    # gone. The in-memory session is only a fallback for an agent still mid-run
    # that has not yet been flushed to disk.
    content: str | None = None
    output_path: str | None = None
    newest_feedback_seq: int | None = None
    try:
        for d in read_run_deliverables(sid):
            if str(d.get("agent_id") or "").strip() != aid:
                continue
            disk_final = str(d.get("final_output") or "").strip()
            if disk_final:
                content = disk_final
            fb_seqs = [int(f.get("seq") or 0) for f in (d.get("feedback") or [])]
            if fb_seqs:
                newest_feedback_seq = max(fb_seqs)
            break
    except Exception:
        logger.exception("Disk deliverable read failed for %s/%s", sid, aid)

    # In-memory fallbacks (agent still running in this process, not yet on disk).
    if session is not None:
        if content is None or content == "":
            base_output = (session.base_dynamic_agent_outputs or {}).get(aid)
            output_path = (session.dynamic_agent_output_paths or {}).get(aid)
            if base_output is None or str(base_output).strip() == "":
                base_output = (session.dynamic_agent_outputs or {}).get(aid)
            if base_output is None or str(base_output).strip() == "":
                base_output = (session.action_agent_outputs or {}).get(aid)
                output_path = (session.action_agent_output_paths or {}).get(aid)
            if base_output is not None and str(base_output).strip() != "":
                content = str(base_output)
        else:
            # Keep the in-memory path for informational purposes when present.
            output_path = (
                (session.dynamic_agent_output_paths or {}).get(aid)
                or (session.action_agent_output_paths or {}).get(aid)
            )

    if content is None or str(content).strip() == "":
        raise HTTPException(status_code=404, detail=f"Output for agent '{aid}' not found.")

    # For action agents: convert raw MCP JSON to a compact confirmation card at
    # read time so old sessions on disk are handled the same as new ones.
    content = _make_action_output_readable(aid, str(content))

    # Score for the newest revision (feedback score if present, else base).
    score: dict[str, Any] | None = None
    try:
        if newest_feedback_seq is not None:
            score = read_agent_score(sid, aid, feedback_seq=newest_feedback_seq)
    except Exception:
        score = None
    if score is None:
        try:
            score = read_agent_score(sid, aid)
        except Exception:
            score = None

    logger.info("Agent output retrieved successfully", extra={
        "session_id": sid,
        "endpoint": "/agent/output",
        "agent_id": aid,
        "output_path": output_path,
        "newest_feedback_seq": newest_feedback_seq,
        "content_length": len(content) if content else 0,
        "has_content": bool(content),
    })

    return AgentOutputView(
        session_id=sid,
        usecase_id=(session.usecase_id if session is not None else ucid),
        agent_id=aid,
        agent_name=aid,
        output_path=output_path,
        content=content,
        score=score,
        feedback_id=(session.latest_feedback_id_by_agent or {}).get(aid) if session is not None else None,
        rerun_id=(session.latest_rerun_id_by_agent or {}).get(aid) if session is not None else None,
    )

def _best_effort_text_from_upload(filename: str, data: bytes) -> str:
    """Best-effort text extraction from uploaded sample output file.

    Mandatory constraint: schema extraction is driven by raw file content.
    This helper may use existing extractors for well-known binary formats.
    """
    name = (filename or "").lower()
    ext = Path(name).suffix

    if ext == ".pdf":
        try:
            import pdfplumber

            with pdfplumber.open(io.BytesIO(data)) as pdf:
                pages = []
                for p in pdf.pages:
                    text = p.extract_text() or ""
                    if text.strip():
                        pages.append(text)
                joined = "\n\n".join(pages).strip()
                if joined:
                    return joined
        except Exception:
            pass

        try:
            from PyPDF2 import PdfReader

            reader = PdfReader(io.BytesIO(data))
            pages = []
            for page in reader.pages:
                t = (page.extract_text() or "").strip()
                if t:
                    pages.append(t)
            joined = "\n\n".join(pages).strip()
            if joined:
                return joined
        except Exception:
            pass

    if ext == ".docx":
        try:
            from docx import Document

            doc = Document(io.BytesIO(data))
            parts: list[str] = []
            for p in doc.paragraphs:
                if p.text and p.text.strip():
                    parts.append(p.text.strip())
            joined = "\n".join(parts).strip()
            if joined:
                return joined
        except Exception:
            pass

    # Default: decode bytes directly.
    try:
        return (data or b"").decode("utf-8", errors="replace")
    except Exception:
        try:
            return (data or b"").decode("latin-1", errors="replace")
        except Exception:
            return str(data[:20000])

class AgentRerunRequest(BaseModel):
    session_id: str
    agent_id: str
    usecase_id: str | None = None
    user_feedback: str
    sample_output: str | None = None


class AgentRerunResponse(BaseModel):
    session_id: str
    usecase_id: str | None = None
    agent_id: str
    feedback_id: str
    rerun_id: str
    output_path: str


async def _rerun_action_agent_with_feedback(
    session: Any,
    action_agent_id: str,
    feedback_text: str,
) -> bool:
    """Re-execute a single action agent so a chat edit reaches the external system.

    When the user gives feedback directly to an action (MCP) agent — e.g. "add
    one more task in the epic" on ``PostUserStoriesToAzureDevOps`` — the change
    must actually be published. The downstream cascade excludes the edited agent
    itself, so this runs it explicitly. Phase 1 idempotency re-injects the
    previously-created resource ids, and the feedback text is passed through so
    the agent updates existing resources instead of creating duplicates.
    Returns True when the agent was rerun and produced output.
    """
    cfg = session.get_agent_config(action_agent_id)
    if cfg is None or not is_action_agent(cfg.get("agent_type")):
        return False

    try:
        from daan.mcp_servers.core.mcp_toolset_provider import initialize_mcp_for_agents
        from daan.core.credential_resolver import CredentialResolver
        _cr_db = next(get_db())
        _cr = CredentialResolver(_cr_db, session.user_id or 0)

        pre_loaded_mcp_toolsets = await initialize_mcp_for_agents([cfg], credential_resolver=_cr)
        extra_input: dict[str, Any] = {}
        if feedback_text and feedback_text.strip():
            extra_input["feedback_instruction"] = feedback_text.strip()

        action_outputs, action_usage, _action_model, _action_provider, action_input = await run_action_agents_async(
            [cfg],
            session.session_id,
            session.dynamic_agent_outputs,
            pre_loaded_mcp_toolsets=pre_loaded_mcp_toolsets,
            extra_input=extra_input or None,
            credential_resolver=_cr,
        )
    except Exception as exc:
        logger.warning(
            "Action agent feedback rerun failed: %s",
            exc,
            extra={"session_id": session.session_id, "agent_id": action_agent_id},
        )
        return False

    content = str((action_outputs or {}).get(action_agent_id) or "").strip()
    if not content:
        return False

    session.action_agent_outputs[action_agent_id] = content
    _record_agent_costs(
        session=session,
        run_type="chat_feedback_rerun",
        agents=[cfg],
        outputs={action_agent_id: content},
        usage_by_agent=action_usage,
        input_message=action_input,
    )

    # Write the real result as the next feedback revision so the Output tab shows
    # the published state (after the promoted proposal revision), not the draft.
    try:
        existing = [
            d for d in read_run_deliverables(session.session_id)
            if str(d.get("agent_id") or "").strip() == action_agent_id
        ]
        seqs = (
            [int(f.get("seq") or 0) for f in (existing[0].get("feedback") or [])]
            if existing else []
        )
        next_seq = (max(seqs) + 1) if seqs else 1
        session.feedback_seq_by_agent[action_agent_id] = next_seq
        act_path = write_agent_output(session.session_id, action_agent_id, content, feedback_seq=next_seq)
        session.action_agent_output_paths[action_agent_id] = act_path
    except Exception:
        logger.exception(
            "Failed to persist action feedback rerun output for %s", action_agent_id
        )

    try:
        kg_instr.record_agent_run(
            session, None, [cfg],
            {action_agent_id: content}, session.action_agent_output_paths,
            trigger="chat_feedback_rerun",
        )
    except Exception:
        logger.exception("Failed to record action feedback rerun for %s", action_agent_id)

    session.touch()
    _persist_token_usage_snapshot(session)
    return True


@router.post("/agent/feedback", response_model=AgentRerunResponse)
async def feedback_agent_rerun_route(
    session_id: str = Form(...),
    agent_id: str = Form(...),
    user_feedback: str = Form(...),
    usecase_id: str | None = Form(default=None),
    sample_output_file: UploadFile | None = File(default=None),
    #payload: AgentRerunRequest,
    current_user: Annotated[object, Depends(get_current_active_user)] = None,
) -> AgentRerunResponse:
    """Re-run a single dynamic_agent using base output + user feedback."""
    _ = current_user

    sid = (session_id or "").strip()
    aid = (agent_id or "").strip()
    ucid = (usecase_id or "").strip() if usecase_id is not None else None
    feedback_text = (user_feedback or "").strip()
    # sid = (payload.session_id or "").strip()
    # aid = (payload.agent_id or "").strip()
    # ucid = (payload.usecase_id or "").strip() if payload.usecase_id is not None else None
    # feedback_text = (payload.user_feedback or "").strip()

    logger.info("Agent feedback and rerun requested", extra={
        "session_id": sid,
        "endpoint": "/agent/feedback",
        "agent_id": aid,
        "usecase_id": ucid,
        "feedback_length": len(feedback_text),
        "has_sample_output": bool(sample_output_file)
    })

    if not sid or not aid:
        logger.warning("Agent feedback requested with missing session_id or agent_id", extra={
            "session_id": sid,
            "agent_id": aid,
            "endpoint": "/agent/feedback"
        })
        raise HTTPException(status_code=400, detail="session_id and agent_id are required")
    if not feedback_text:
        logger.warning("Agent feedback requested without feedback text", extra={
            "session_id": sid,
            "agent_id": aid,
            "endpoint": "/agent/feedback"
        })
        raise HTTPException(status_code=400, detail="user_feedback is required")

    session = get_session(sid)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found. Run /api/workflow/run-dynamic-agents first.")

    if session.feedback_count >= session.max_feedback:
        raise HTTPException(
            status_code=409,
            detail=f"Maximum feedback rounds ({session.max_feedback}) reached. Call /proceed instead.",
        )

    if ucid and session.usecase_id and session.usecase_id != ucid:
        raise HTTPException(
            status_code=404,
            detail=f"Session '{sid}' is for usecase '{session.usecase_id}', not '{ucid}'.",
        )

    base_output = (session.base_dynamic_agent_outputs or {}).get(aid)
    if base_output is None or str(base_output).strip() == "":
        raise HTTPException(status_code=409, detail=f"Base output for agent '{aid}' not found. Run /run-dynamic-agents first.")

    agent_cfg = _get_agent_cfg_with_disk_fallback(session, aid)
    if not agent_cfg:
        raise HTTPException(status_code=404, detail=f"Agent config for '{aid}' not found in session.")

    refined_prompt = str(
        agent_cfg.get("prompt")
        or agent_cfg.get("instruction")
        or agent_cfg.get("task")
        or ""
    ).strip()
    context = str(agent_cfg.get("context") or "").strip()
    provider, _model = resolve_agent_provider_and_model(agent_cfg)

    # Determine feedback sequence for versioned storage
    seq = int((session.feedback_seq_by_agent.get(aid) or 0)) + 1

    # Persist raw user feedback text for auditability (do not log body)
    try:
        write_feedback_text(sid, aid, seq, feedback_text)
    except Exception as exc:
        logger.warning(
            "Failed to persist feedback text: %s",
            exc,
            extra={"session_id": sid, "agent_id": aid, "feedback_seq": seq},
        )

    # Optional: sample schema extraction (mandatory helper) from raw uploaded file
    sample_schema: dict[str, Any] | None = None
    if sample_output_file is not None and sample_output_file.filename:
        try:
            raw_bytes = await sample_output_file.read()
            # Store raw sample output file alongside feedback rerun artifacts
            sample_path = write_feedback_sample_file(
                sid,
                aid,
                seq,
                sample_output_file.filename,
                raw_bytes,
            )

            sample_text = _best_effort_text_from_upload(sample_output_file.filename, raw_bytes)
            schema_obj, schema_prompt, schema_raw = extract_schema_json_with_io(
                file_text=sample_text,
                filename=sample_output_file.filename,
                provider_name=provider,
            )
            sample_schema = schema_obj

            # Persist extracted schema JSON
            write_feedback_sample_schema(sid, aid, seq, schema_obj)

            _record_llm_sidecall_cost(
                session=session,
                agent_id=aid,
                run_type="schema_extract",
                agent_cfg=agent_cfg,
                llm_prompt=schema_prompt,
                llm_response=schema_raw,
            )

            logger.info(
                "Sample schema extracted for feedback rerun",
                extra={"session_id": sid, "agent_id": aid, "sample_path": sample_path},
            )
        except Exception as exc:
            # Best-effort: proceed without schema enforcement
            logger.warning(
                "Sample schema extraction failed; proceeding without schema enforcement: %s",
                exc,
                extra={"session_id": sid, "agent_id": aid},
            )

    # Cumulative feedback: improve the latest effective output, not the original base.
    effective_output = (session.dynamic_agent_outputs or {}).get(aid)
    if effective_output is None or str(effective_output).strip() == "":
        effective_output = base_output

    rerun_input_message = (
        "You are re-running a single agent inside a workflow.\n\n"
        f"Agent ID: {aid}\n\n"
        "Current output to improve (latest version; do not regress prior improvements unless required by feedback):\n"
        f"{effective_output}\n\n"
        "User feedback (must address):\n"
        f"{feedback_text}\n\n"
        "Original base output (reference only):\n"
        f"{base_output}\n\n"
    )
    if context:
        rerun_input_message += f"Context:\n{context}\n\n"
    if sample_schema is not None:
        rerun_input_message += (
            "Output MUST be valid JSON and MUST follow this sample schema/skeleton exactly (structure only; values may differ):\n"
            f"{json.dumps(sample_schema, ensure_ascii=False, indent=2, default=str)}\n\n"
        )
    rerun_input_message += (
        "Return the complete improved output text. "
        "Do not return a partial report. "
        "If the agent instructions require calling tools, execute those tools before returning final output."
    )

    session.state = SessionState.AGENTS_RUNNING
    session.feedback_count += 1
    session.touch()

    try:
        new_output, usage, model_name, provider_name = await run_single_agent_async(
                agent_config=agent_cfg,
                session_id=sid,
                input_message=rerun_input_message,
            )
        new_output = str(new_output).strip()
    except Exception as exc:
        session.state = SessionState.FAILED
        session.error = str(exc)
        session.touch()
        raise HTTPException(status_code=500, detail=f"Agent rerun failed: {exc}")

    if not new_output:
        session.state = SessionState.FAILED
        session.error = "Agent rerun returned empty output"
        session.touch()
        raise HTTPException(status_code=500, detail="Agent rerun returned empty output")

    feedback_id = str(uuid4())
    rerun_id = str(uuid4())

    # If schema is available, apply it to the draft output to produce canonical JSON.
    if sample_schema is not None:
        try:
            json_text, apply_prompt, apply_raw = apply_schema_to_output_with_io(
                draft_output=new_output,
                sample_schema=sample_schema,
                provider_name=provider,
            )
            new_output = json_text.strip()
            _record_llm_sidecall_cost(
                session=session,
                agent_id=aid,
                run_type="schema_apply",
                agent_cfg=agent_cfg,
                llm_prompt=apply_prompt,
                llm_response=apply_raw,
            )
        except Exception as exc:
            logger.warning(
                "Schema application failed; keeping draft output: %s",
                exc,
                extra={"session_id": sid, "agent_id": aid},
            )

    session.dynamic_agent_outputs[aid] = new_output
    _record_agent_costs(
        session=session,
        run_type="feedback_rerun",
        agents=[agent_cfg],
        outputs={aid: new_output},
        usage_by_agent={aid: usage or {}},
        input_message=rerun_input_message,
        model_by_agent={aid: model_name} if model_name else None,
        provider_by_agent={aid: provider_name} if provider_name else None,
    )
    session.latest_feedback_id_by_agent[aid] = feedback_id
    session.latest_rerun_id_by_agent[aid] = rerun_id
    session.state = SessionState.AGENTS_DONE

    # Score the final output (post schema-apply when applicable) and persist score next to output
    try:
        sample_schema_text = json.dumps(sample_schema, ensure_ascii=False, indent=2, default=str) if sample_schema is not None else ""
        score_obj, score_prompt, score_raw, score_meta = compute_agent_scores_with_io(
            agent_id=aid,
            agent_name=str(agent_cfg.get("agent_name") or aid),
            context=context,
            prompt=refined_prompt,
            output=new_output,
            input_keywords=str(agent_cfg.get("inputs") or ""),
            sample_output=sample_schema_text if sample_schema is not None else str(agent_cfg.get("output_format") or ""),
            schema_authoritative=bool(sample_schema is not None),
            provider_name=provider,
        )
        write_agent_score(sid, aid, score_obj.to_dict(), feedback_seq=seq)
        # Defer KG Issue creation until after the rerun's Run node is created
        # (record_feedback_rerun below) so the issue attaches to the new run.
        rerun_score_dict = score_obj.to_dict()
        rerun_score_agent_name = str(agent_cfg.get("agent_name") or aid)
        _record_llm_sidecall_cost(
            session=session,
            agent_id=aid,
            run_type="scoring",
            agent_cfg=agent_cfg,
            llm_prompt=score_prompt,
            llm_response=score_raw,
            usage_metadata=score_meta.get("usage"),
            provider_name=str(score_meta.get("provider") or ""),
            model_name=str(score_meta.get("model") or ""),
        )
        _persist_token_usage_snapshot(session)
    except Exception as exc:
        rerun_score_dict = None
        rerun_score_agent_name = ""
        logger.warning(
            "Failed to score feedback rerun output: %s",
            exc,
            extra={"session_id": sid, "agent_id": aid},
        )

    # Write updated output to disk (versioned; no overwrite)
    output_path = ""
    try:
        seq = int((session.feedback_seq_by_agent.get(aid) or 0)) + 1
        session.feedback_seq_by_agent[aid] = seq
        output_path = write_agent_output(sid, aid, new_output, feedback_seq=seq)
        session.dynamic_agent_output_paths[aid] = output_path
    except Exception:
        pass

    session.touch()
    _persist_token_usage_snapshot(session)

    # ── KG: record feedback + the rerun it triggered (best-effort) ───────
    kg_instr.record_feedback_rerun(
        session, current_user, aid, agent_cfg, feedback_text, new_output, output_path,
        score_dict=rerun_score_dict,
    )

    # Persist a KG Issue for a low-scoring rerun (after the rerun's Run node
    # exists) so the shortfall feeds the refinement agent's "issues to avoid".
    if rerun_score_dict is not None:
        kg_instr.record_agent_score_issue(sid, rerun_score_agent_name, rerun_score_dict)

    # Feedback reruns only the target agent. Because execution pauses after every
    # stage, downstream agents have not run yet and will consume this updated
    # output when the workflow continues — no dependent cascade is needed.

    # ── Quality assessment for THIS rerun (best-effort) ─────────────────
    # Each feedback rerun creates a new Run node; capture a run-level quality
    # score for it so the quality is recorded for every run (not just the final
    # report). The QualityAssessment attaches to the latest run, which is the
    # rerun created by record_feedback_rerun above. Never blocks the response.
    try:
        from daan.agents.core.quality_check_agent import run_quality_agent_async
        from daan.usecases.usecase_service import get_usecase_details

        rerun_quality_role = None
        try:
            qc_details = get_usecase_details(session.archetype, session.usecase_id)
            rerun_quality_role = (qc_details.get("usecase_details", {}) or {}).get("role", None)
        except Exception:
            rerun_quality_role = None

        combined_rerun_outputs = dict(session.dynamic_agent_outputs)
        if session.action_agent_outputs:
            combined_rerun_outputs.update(session.action_agent_outputs)

        rerun_quality_context = {
            "report": "\n\n".join(
                f"### {agent_id}\n{content}"
                for agent_id, content in combined_rerun_outputs.items()
            ),
            "session_id": session.session_id,
            "archetype": session.archetype,
            "usecase_id": session.usecase_id,
            "stage": "feedback_rerun",
        }

        rerun_assessment, _rq_usage, _rq_model, _rq_provider = await run_quality_agent_async(
            quality_context=rerun_quality_context,
            role=rerun_quality_role,
            provider=None,
        )

        rerun_quality_provider, rerun_quality_model = resolve_provider_and_model(None)
        rerun_quality_prompt = (
            f"quality_context={json.dumps(rerun_quality_context, ensure_ascii=False, default=str)}\n"
            f"role={rerun_quality_role or ''}"
        )
        rerun_quality_est = estimate_tokens(
            model=rerun_quality_model, prompt=rerun_quality_prompt, completion=rerun_assessment or ""
        )
        rerun_quality_cost, rerun_quality_estimated_cost = compute_cost_usd(
            model=rerun_quality_model,
            prompt_tokens=int(rerun_quality_est.get("prompt_tokens") or 0),
            completion_tokens=int(rerun_quality_est.get("completion_tokens") or 0),
        )
        session.record_agent_cost(
            "QUALITY_AGENT",
            build_cost_record(
                agent_id="QUALITY_AGENT",
                run_type="quality_check_feedback_rerun",
                provider=rerun_quality_provider,
                model=rerun_quality_model,
                prompt_tokens=int(rerun_quality_est.get("prompt_tokens") or 0),
                completion_tokens=int(rerun_quality_est.get("completion_tokens") or 0),
                estimated_tokens=True,
                cost_usd=rerun_quality_cost,
                estimated_cost=rerun_quality_estimated_cost,
            ),
        )
        session.touch()
        _persist_token_usage_snapshot(session)

        kg_instr.record_quality_assessment(session.session_id, rerun_assessment)
    except Exception as rerun_quality_exc:
        logger.warning(
            "Failed to capture feedback-rerun quality assessment: %s",
            rerun_quality_exc,
            extra={"session_id": sid, "agent_id": aid},
        )

    logger.info("Agent feedback and rerun completed successfully", extra={
        "session_id": sid,
        "endpoint": "/agent/feedback",
        "agent_id": aid,
        "feedback_id": feedback_id,
        "rerun_id": rerun_id,
        "output_path": output_path,
        "feedback_count": session.feedback_count
    })

    return AgentRerunResponse(
        session_id=sid,
        usecase_id=session.usecase_id,
        agent_id=aid,
        feedback_id=feedback_id,
        rerun_id=rerun_id,
        output_path=output_path,
    )


@router.post("/run-refinement-agent", response_model=RefinementResponse)
async def run_refinement_agent_route(
    request: RefinementRequest,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> RefinementResponse:
    """Run the Refinement agent after dynamic + action agents.

    The Refinement agent revises the combined agent output using the last 5
    executions' user feedback and issues (pulled from the knowledge graph) as
    its system prompt, so prior feedback is incorporated and previously reported
    issues do not recur.

    When the use case has no prior history (first run / no KG data), this step is
    SKIPPED gracefully — the session state is left unchanged so finalization can
    proceed normally.
    """
    _ = current_user

    logger.info("Refinement agent execution requested", extra={
        "session_id": request.session_id,
        "endpoint": "/run-refinement-agent",
    })

    session = get_session(request.session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found. Run /run-dynamic-agents first.")

    if session.state not in (
        SessionState.AGENTS_DONE,
        SessionState.ACTIONS_DONE,
        SessionState.REFINED,
    ):
        raise HTTPException(
            status_code=409,
            detail=(
                f"Cannot refine in state '{session.state.value}'. "
                "Dynamic (and action) agents must be done first."
            ),
        )

    # Resolve role from usecase details (best-effort).
    role = None
    try:
        from daan.usecases.usecase_service import get_usecase_details
        details = get_usecase_details(session.archetype, session.usecase_id)
        role = (details.get("usecase_details", {}) or {}).get("role", None)
    except Exception:
        pass

    # Refine each agent's output INDEPENDENTLY, using only that agent's own
    # prior feedback/issues. This prevents one agent's history (for example a
    # dynamic agent's reported errors) from leaking into an unrelated agent's
    # output (such as a downstream action agent). Agents that have no prior
    # history of their own are left completely unchanged.
    combined_outputs = dict(session.dynamic_agent_outputs)
    if session.action_agent_outputs:
        combined_outputs.update(session.action_agent_outputs)
    if not combined_outputs:
        raise HTTPException(status_code=409, detail="No agent outputs found to refine.")

    per_agent_guidance: dict[str, str] = {}
    for agent_id in combined_outputs:
        agent_guidance = kg_instr.get_recurrence_guidance_text(
            session.usecase_id,
            run_limit=5,
            agent_id=agent_id,
            owner_username=getattr(current_user, "username", None),
        )
        if agent_guidance:
            per_agent_guidance[agent_id] = agent_guidance

    if not per_agent_guidance:
        # No agent has any prior feedback/issues (first run) — skip gracefully.
        session.refinement_skipped = True
        session.touch()
        logger.info("Refinement skipped — no prior history for any agent", extra={
            "session_id": session.session_id,
            "usecase_id": session.usecase_id,
        })
        return RefinementResponse(
            session_id=session.session_id,
            state=session.state.value,
            skipped=True,
            reason="No prior feedback or issues found for this use case (first run).",
        )

    session.state = SessionState.REFINING
    session.touch()

    try:
        from daan.agents.core.refinement_agent import run_refinement_agent_async

        refinement_provider, refinement_model = resolve_provider_and_model(request.provider)
        refined_sections: dict[str, str] = {}
        total_prompt_tokens = 0
        total_completion_tokens = 0

        for agent_id, content in combined_outputs.items():
            agent_guidance = per_agent_guidance.get(agent_id)
            if not agent_guidance:
                # Keep this agent's output untouched — no history means there is
                # nothing to refine, and no other agent's feedback applies here.
                refined_sections[agent_id] = content
                continue

            refined_piece = await run_refinement_agent_async(
                current_output=content,
                guidance_text=agent_guidance,
                role=role,
                provider=request.provider,
            )
            refined_sections[agent_id] = refined_piece or content

            piece_prompt = f"{agent_guidance}\n\n{content}\nrole={role or ''}"
            piece_est = estimate_tokens(
                model=refinement_model, prompt=piece_prompt, completion=refined_piece or ""
            )
            total_prompt_tokens += int(piece_est.get("prompt_tokens") or 0)
            total_completion_tokens += int(piece_est.get("completion_tokens") or 0)

        refined = "\n\n".join(
            f"### {agent_id}\n{content}" for agent_id, content in refined_sections.items()
        )
        # Combined guidance is retained only as scoring context below.
        guidance_text = "\n\n".join(per_agent_guidance.values())

        refinement_cost, refinement_estimated_cost = compute_cost_usd(
            model=refinement_model,
            prompt_tokens=total_prompt_tokens,
            completion_tokens=total_completion_tokens,
        )
        session.record_agent_cost(
            "REFINEMENT_AGENT",
            build_cost_record(
                agent_id="REFINEMENT_AGENT",
                run_type="refinement",
                provider=refinement_provider,
                model=refinement_model,
                prompt_tokens=total_prompt_tokens,
                completion_tokens=total_completion_tokens,
                estimated_tokens=True,
                cost_usd=refinement_cost,
                estimated_cost=refinement_estimated_cost,
            ),
        )

        session.refinement_output = refined
        session.refinement_skipped = False
        refinement_path = write_refinement_output(session.session_id, refined)
        session.refinement_output_path = refinement_path

        # Score the refined output so the UI can display quality scores for the
        # Refinement agent, mirroring the per-agent scoring of dynamic agents.
        try:
            score_obj, score_prompt, score_raw = compute_agent_scores_with_io(
                agent_id="REFINEMENT_AGENT",
                agent_name="Refinement Agent",
                context=guidance_text,
                prompt=(
                    "Refine the provided output by incorporating prior user "
                    "feedback and ensuring previously reported issues do not recur."
                ),
                output=str(refined or ""),
                input_keywords="",
                sample_output="",
                schema_authoritative=False,
                provider_name=refinement_provider,
            )
            session.refinement_scores = score_obj.to_dict()
            write_agent_score(session.session_id, "REFINEMENT_AGENT", session.refinement_scores)
            kg_instr.record_agent_score_issue(
                session.session_id,
                "Refinement Agent",
                session.refinement_scores,
            )
            _record_llm_sidecall_cost(
                session=session,
                agent_id="REFINEMENT_AGENT",
                run_type="scoring",
                agent_cfg={},
                llm_prompt=score_prompt,
                llm_response=score_raw,
            )
        except Exception as score_exc:
            logger.warning(
                "Failed to compute refinement score: %s",
                score_exc,
                extra={"session_id": session.session_id},
            )

        session.state = SessionState.REFINED
        session.touch()
    except Exception as exc:
        session.state = SessionState.FAILED
        session.error = f"Refinement agent failed: {_format_exception_for_client(exc)}"
        session.touch()
        raise HTTPException(status_code=500, detail=session.error) from exc

    _persist_token_usage_snapshot(session)

    logger.info("Refinement agent execution completed", extra={
        "session_id": session.session_id,
        "endpoint": "/run-refinement-agent",
        "state": session.state.value,
    })

    return RefinementResponse(
        session_id=session.session_id,
        state=session.state.value,
        skipped=False,
        refinement_output_path=session.refinement_output_path,
        scores=session.refinement_scores,
    )


@router.post("/finalize", response_model=FinalizeResponse)
async def finalize_route(
    request: FinalizeRequest,
    current_user: Annotated[object, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> FinalizeResponse:
    """Run reporter agent + quality assessment automatically after agents complete.

    This replaces the old separate /reporter-agent/run and /qualityagent/run endpoints.
    """
    from daan.admin.team_service import get_active_api_key_for_user
    user_id = getattr(current_user, "id", None)
    set_daan_user_id(user_id)
    if user_id:
        set_team_api_key(get_active_api_key_for_user(db, user_id))

    logger.info("Workflow finalization requested", extra={
        "session_id": request.session_id,
        "endpoint": "/finalize",
        "provider_override": request.provider
    })

    from daan.agents.core.reporter_agent import run_reporter_agent_async
    from daan.agents.core.quality_check_agent import run_quality_agent_async
    from daan.usecases.usecase_service import get_usecase_details

    session = _get_or_rehydrate_session_for_execution(request.session_id)
    if session is None:
        logger.warning("Finalization requested for non-existent session", extra={
            "session_id": request.session_id,
            "endpoint": "/finalize"
        })
        raise HTTPException(status_code=404, detail="Session not found.")

    has_finalizable_outputs = bool(
        session.refinement_output
        or session.dynamic_agent_outputs
        or session.action_agent_outputs
    )
    allowed_retry_states = {
        SessionState.AGENTS_DONE,
        SessionState.ACTIONS_DONE,
        SessionState.REFINED,
        SessionState.REPORT_DONE,
        SessionState.COMPLETED,
    }
    if session.state == SessionState.FAILED and has_finalizable_outputs:
        logger.info(
            "Retrying finalization from recoverable FAILED state",
            extra={
                "session_id": request.session_id,
                "endpoint": "/finalize",
                "error": session.error,
            },
        )
    elif session.state not in allowed_retry_states:
        raise HTTPException(
            status_code=409,
            detail=f"Cannot finalize in state '{session.state.value}'. Agents must be done first.",
        )

    # Resolve role from usecase details (fixed for a given usecase)
    role = None
    details: dict[str, Any] = {}
    try:
        details = get_usecase_details(session.archetype, session.usecase_id)
        usecase_details = details.get("usecase_details", {})
        role = usecase_details.get("role", None)
    except FileNotFoundError:
        pass

    # Gather all agent outputs. When the Refinement agent produced a revised
    # output (use case has prior history), the reporter is based on that refined
    # output so prior feedback/issues are reflected in the final report.
    if session.refinement_output:
        agent_outputs = {"refined_output": session.refinement_output}
    else:
        agent_outputs = dict(session.dynamic_agent_outputs)
        if session.action_agent_outputs:
            agent_outputs.update(session.action_agent_outputs)

    if not agent_outputs:
        raise HTTPException(status_code=409, detail="No agent outputs found in session.")

    # ── Reporter ────────────────────────────────────────────────────────
    session.state = SessionState.REPORTING
    session.error = None
    session.touch()

    try:
        report, reporter_usage, reporter_model, reporter_provider = await run_reporter_agent_async(
            agent_outputs=agent_outputs,
            metadata=details,
            role=role,
            provider=request.provider,
        )
        resolved_reporter_provider, resolved_reporter_model = resolve_provider_and_model(request.provider)
        reporter_provider = reporter_provider or resolved_reporter_provider
        reporter_model = reporter_model or resolved_reporter_model
        reporter_cost = compute_cost_usd(
            model=reporter_model,
            prompt_tokens=int(reporter_usage.get("prompt_tokens") or 0),
            completion_tokens=int(reporter_usage.get("completion_tokens") or 0),
        )[0]
        session.record_agent_cost(
            "REPORTER_AGENT",
            build_cost_record(
                agent_id="REPORTER_AGENT",
                run_type="reporter",
                provider=reporter_provider,
                model=reporter_model,
                prompt_tokens=int(reporter_usage.get("prompt_tokens") or 0),
                completion_tokens=int(reporter_usage.get("completion_tokens") or 0),
                cost_usd=reporter_cost,
            ),
        )
        session.latest_report = report
        reporter_path = write_reporter_output(session.session_id, report)
        session.reporter_output_path = reporter_path
        session.state = SessionState.REPORT_DONE
        session.touch()
    except Exception as exc:
        session.state = SessionState.FAILED
        session.error = f"Reporter agent failed: {exc}"
        session.touch()
        raise HTTPException(status_code=500, detail=session.error) from exc

    # ── Quality Assessment ──────────────────────────────────────────────
    session.state = SessionState.QUALITY_CHECK
    session.touch()

    try:
        quality_context = {
            "report": report,
            "session_id": session.session_id,
            "archetype": session.archetype,
            "usecase_id": session.usecase_id,
        }
        # Pull feedback + issues from the last 5 executions of this use case so
        # the quality agent can validate that previously reported problems do
        # not recur (best-effort; empty when no history / KG unavailable).
        recurrence_guard = kg_instr.get_recurrence_guard(
            session.usecase_id,
            run_limit=5,
            owner_username=getattr(current_user, "username", None),
        )
        if recurrence_guard.get("issues") or recurrence_guard.get("feedback"):
            quality_context["prior_issues_to_avoid"] = recurrence_guard.get("issues", [])
            quality_context["prior_feedback"] = recurrence_guard.get("feedback", [])
            quality_context["recurrence_validation_instruction"] = (
                "Validate the report against the prior_issues_to_avoid and "
                "prior_feedback from the last executions of this use case. "
                "Flag any issue that has recurred and lower the score accordingly."
            )
        assessment, quality_usage, quality_model, quality_provider = await run_quality_agent_async(
            quality_context=quality_context,
            role=role,
            provider=request.provider,
        )
        resolved_quality_provider, resolved_quality_model = resolve_provider_and_model(request.provider)
        quality_provider = quality_provider or resolved_quality_provider
        quality_model = quality_model or resolved_quality_model
        quality_cost = compute_cost_usd(
            model=quality_model,
            prompt_tokens=int(quality_usage.get("prompt_tokens") or 0),
            completion_tokens=int(quality_usage.get("completion_tokens") or 0),
        )[0]
        session.record_agent_cost(
            "QUALITY_AGENT",
            build_cost_record(
                agent_id="QUALITY_AGENT",
                run_type="quality_check",
                provider=quality_provider,
                model=quality_model,
                prompt_tokens=int(quality_usage.get("prompt_tokens") or 0),
                completion_tokens=int(quality_usage.get("completion_tokens") or 0),
                cost_usd=quality_cost,
            ),
        )
        session.latest_quality_assessment = assessment
        quality_path = write_quality_output(session.session_id, assessment)
        session.quality_output_path = quality_path
        session.state = SessionState.COMPLETED
        session.touch()
    except Exception as exc:
        session.state = SessionState.FAILED
        session.error = f"Quality agent failed: {exc}"
        session.touch()
        raise HTTPException(status_code=500, detail=session.error) from exc
    _persist_token_usage_snapshot(session)

    # ── KG: record quality assessment + session completion (best-effort) ─
    # Collect the per-agent scores first so the KG quality node records the
    # authoritative overall average (mean of each agent's overall_score) rather
    # than a number parsed out of the assessment markdown.
    agent_scores: list[dict] = []
    try:
        agent_scores = collect_agent_scores(session.session_id)
    except Exception:
        logger.warning(
            "Failed to collect agent quality scores",
            extra={"session_id": session.session_id, "endpoint": "/finalize"},
            exc_info=True,
        )

    overall_values = [
        float(a.get("overall_score") or 0.0)
        for a in agent_scores
        if a.get("overall_score") is not None
    ]
    session_overall_score = (
        round(sum(overall_values) / len(overall_values), 2) if overall_values else None
    )

    kg_instr.record_quality_and_completion(
        session.session_id, assessment, score=session_overall_score
    )

    # ── Persist per-agent + session quality scores to PostgreSQL (best-effort) ─
    try:
        store_session_quality_scores(
            session_id=session.session_id,
            usecase_id=str(session.usecase_id or "").strip(),
            archetype=str(session.archetype or "").strip(),
            username=str(getattr(current_user, "username", "") or "").strip() or None,
            agent_scores=agent_scores,
            reporter_output_path=session.reporter_output_path,
            quality_output_path=session.quality_output_path,
        )
    except Exception:
        logger.warning(
            "Failed to persist final quality score metric",
            extra={"session_id": session.session_id, "endpoint": "/finalize"},
            exc_info=True,
        )

    logger.info("Workflow finalization completed successfully", extra={
        "session_id": session.session_id,
        "endpoint": "/finalize",
        "state": session.state.value,
        "reporter_output_path": session.reporter_output_path,
        "quality_output_path": session.quality_output_path,
        "final_cost": session.total_cost_usd
    })

    return FinalizeResponse(
        session_id=session.session_id,
        state=session.state.value,
        reporter_output_path=session.reporter_output_path,
        quality_output_path=session.quality_output_path,
    )


@router.get("/final-report", response_model=FinalReportContentResponse)
def final_report_content_route(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> FinalReportContentResponse:
    """Return reporter (final report) markdown content for a session."""
    _ = current_user

    logger.info("Final report content requested", extra={
        "session_id": session_id,
        "endpoint": "/final-report"
    })

    sid = (session_id or "").strip()
    if not sid:
        logger.warning("Final report requested without session_id", extra={
            "endpoint": "/final-report"
        })
        raise HTTPException(status_code=400, detail="session_id is required")

    session = get_session(sid)
    if session is None:
        logger.warning("Final report requested for non-existent session", extra={
            "session_id": sid,
            "endpoint": "/final-report"
        })
        raise HTTPException(status_code=404, detail="Session not found.")

    reporter_path = (session.reporter_output_path or "").strip()
    if not reporter_path:
        logger.warning("Final report requested but no report available", extra={
            "session_id": sid,
            "endpoint": "/final-report"
        })
        raise HTTPException(status_code=404, detail="Final report not available. Run /api/workflow/finalize first.")

    content = _read_text_file_from_allowed_roots(reporter_path)
    
    logger.info("Final report content retrieved successfully", extra={
        "session_id": session.session_id,
        "endpoint": "/final-report",
        "reporter_path": reporter_path,
        "content_length": len(content)
    })
    
    return FinalReportContentResponse(
        session_id=session.session_id,
        reporter_output_path=reporter_path,
        content=content,
    )


@router.get("/refinement-prompt", response_model=RefinementPromptResponse)
def refinement_prompt_route(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
    agent_id: str | None = None,
) -> RefinementPromptResponse:
    """Return the Refinement agent's system prompt for a session.

    When ``agent_id`` is provided, the prompt is built from that agent's own
    last 5 feedback records instead of the use-case-wide history. This keeps the
    refinement prompt isolated and specific to the selected agent.
    """
    _ = current_user

    sid = (session_id or "").strip()
    if not sid:
        raise HTTPException(status_code=400, detail="session_id is required")

    session = get_session(sid)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found.")

    guidance = kg_instr.get_recurrence_guidance_text(
        session.usecase_id,
        run_limit=5,
        agent_id=(agent_id.strip() if agent_id else None),
        owner_username=getattr(current_user, "username", None),
    )
    available = bool(guidance)
    if agent_id:
        prompt = guidance or (
            "No prior feedback records were found for this agent yet. The "
            "agent-specific refinement prompt will start populating once this "
            "agent has its own feedback history."
        )
    else:
        prompt = guidance or (
            "No prior execution feedback or issues found for this use case yet. "
            "The Refinement agent will be skipped on the first run and will start "
            "improving the output once this use case has execution history."
        )

    return RefinementPromptResponse(
        session_id=session.session_id,
        available=available,
        prompt=prompt,
        refinement_output_path=session.refinement_output_path,
        refinement_done=session.state == SessionState.REFINED or bool(session.refinement_output),
    )


@router.get("/refinement-output", response_model=RefinementOutputResponse)
def refinement_output_route(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> RefinementOutputResponse:
    """Return the Refinement agent's refined output content and quality scores."""
    _ = current_user

    sid = (session_id or "").strip()
    if not sid:
        raise HTTPException(status_code=400, detail="session_id is required")

    session = get_session(sid)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found.")

    path = (session.refinement_output_path or "").strip()
    if not path:
        return RefinementOutputResponse(
            session_id=session.session_id,
            available=False,
            content="",
            refinement_output_path=None,
            scores=session.refinement_scores,
        )

    content = _read_text_file_from_allowed_roots(path)

    return RefinementOutputResponse(
        session_id=session.session_id,
        available=True,
        content=content,
        refinement_output_path=path,
        scores=session.refinement_scores,
    )


@router.get("/quality-report", response_model=QualityReportContentResponse)
def quality_report_content_route(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> QualityReportContentResponse:
    """Return quality assessment markdown content for a session."""
    _ = current_user

    logger.info("Quality report content requested", extra={
        "session_id": session_id,
        "endpoint": "/quality-report"
    })

    sid = (session_id or "").strip()
    if not sid:
        logger.warning("Quality report requested without session_id", extra={
            "endpoint": "/quality-report"
        })
        raise HTTPException(status_code=400, detail="session_id is required")

    session = get_session(sid)
    if session is None:
        logger.warning("Quality report requested for non-existent session", extra={
            "session_id": sid,
            "endpoint": "/quality-report"
        })
        raise HTTPException(status_code=404, detail="Session not found.")

    quality_path = (session.quality_output_path or "").strip()
    if not quality_path:
        logger.warning("Quality report requested but no report available", extra={
            "session_id": sid,
            "endpoint": "/quality-report"
        })
        raise HTTPException(status_code=404, detail="Quality report not available. Run /api/workflow/finalize first.")

    content = _read_text_file_from_allowed_roots(quality_path)
    
    logger.info("Quality report content retrieved successfully", extra={
        "session_id": session.session_id,
        "endpoint": "/quality-report",
        "quality_path": quality_path,
        "content_length": len(content)
    })
    
    return QualityReportContentResponse(
        session_id=session.session_id,
        quality_output_path=quality_path,
        content=content,
    )


@router.get("/session/{session_id}", response_model=SessionStatusResponse)
def session_status_route(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> SessionStatusResponse:
    """Get the current state and outputs of a workflow session."""
    _ = current_user

    logger.info("Session status requested", extra={
        "session_id": session_id,
        "endpoint": "/session/{session_id}"
    })

    session = get_session(session_id)
    if session is None:
        logger.warning("Session status requested for non-existent session", extra={
            "session_id": session_id,
            "endpoint": "/session/{session_id}"
        })
        raise HTTPException(status_code=404, detail="Session not found.")

    logger.info("Session status retrieved successfully", extra={
        "session_id": session_id,
        "endpoint": "/session/{session_id}",
        "state": session.state.value,
        "archetype": session.archetype,
        "total_cost": session.total_cost_usd,
        "total_tokens": session.total_tokens
    })

    # Check if artifacts exist for frontend toggle
    artifacts_dir = get_artifacts_dir(session_id)
    has_artifacts = artifacts_dir.is_dir() and any(artifacts_dir.iterdir())
    
    response_data = session.to_dict()
    response_data["has_artifacts"] = has_artifacts

    return SessionStatusResponse(**response_data)

@router.get("/session/{session_id}/token_usage")
def session_costs_route(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
):
    """
    Token usage summary grouped by workflow phase:
    - Planning (context management / planning LLMs)
    - Agent execution (all task agents, feedback, subagents)
    - Reporter agent
    - Quality assessment
    - Total tokens
    """

    _ = current_user

    logger.info("Session token usage requested", extra={
        "session_id": session_id,
        "endpoint": "/session/{session_id}/token_usage"
    })

    session = get_session(session_id)
    if session is None:
        logger.warning("Token usage requested for non-existent session", extra={
            "session_id": session_id,
            "endpoint": "/session/{session_id}/token_usage"
        })
        raise HTTPException(status_code=404, detail="Session not found")

    payload = _build_token_usage_payload(session)
    try:
        write_session_token_usage(session.session_id, payload)
    except Exception:
        pass
    logger.info("Session token usage retrieved successfully", extra={
        "session_id": session_id,
        "endpoint": "/session/{session_id}/token_usage",
        "total_tokens": payload.get("total_tokens", {}).get("total_tokens", 0),
        "total_cost": session.total_cost_usd
    })
    
    return payload

@router.get("/session/{session_id}/status", response_model=SessionStatusMessageResponse)
def session_status_view_route(
    session_id: str,
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> SessionStatusMessageResponse:
    """Get a minimal workflow status message for a session (Markdown-supported)."""
    _ = current_user

    logger.debug("Session status message requested", extra={
        "session_id": session_id,
        "endpoint": "/session/{session_id}/status"
    })

    session = get_session(session_id)
    if session is None:
        logger.warning("Status message requested for non-existent session", extra={
            "session_id": session_id,
            "endpoint": "/session/{session_id}/status"
        })
        raise HTTPException(status_code=404, detail="Session not found.")

    return _build_status_message(session)
