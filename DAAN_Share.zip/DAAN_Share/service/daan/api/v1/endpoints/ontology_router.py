"""Ontology API routes (human-in-the-loop knowledge-graph building).

Flow:
  1. POST /knowledge-bases/{kb_id}/ontology/generate  (upload file OR server path)
        -> extract a document-level ontology and return it as JSON for review.
  2. POST /knowledge-bases/{kb_id}/ontology/revise     (ontology + feedback)
        -> apply the user's feedback and return the revised ontology.
  3. POST /knowledge-bases/{kb_id}/ontology/publish     (approved ontology)
        -> write entities/relationships into the KB's graph store.

The ontology JSON contract is defined by ``ontology_agent._normalize_ontology``.
"""

from __future__ import annotations

import asyncio
import logging
import os
import uuid
from typing import Any

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, Field

from daan.core.config import get_settings
from daan.rag.ontology.document_loader import load_document_text
from daan.rag.ontology.ontology_agent import (
    build_extraction_prompt_preview,
    generate_ontology,
    merge_ontologies,
    revise_ontology,
)
from daan.rag.ontology.ontology_publisher import (
    fetch_existing_entities,
    fetch_full_graph,
    fetch_node_neighborhood,
    publish_ontology,
    resolve_and_enrich_ontology,
)

logger = logging.getLogger(__name__)

router = APIRouter()

# How many documents to extract concurrently during the map step.
_MAP_CONCURRENCY = 5


class ReviseRequest(BaseModel):
    """Apply free-text feedback to a previously generated ontology."""

    ontology: dict[str, Any]
    feedback: str
    # Optional source text so the agent can ground feedback against the document.
    document_text: str | None = None


class PublishRequest(BaseModel):
    """Publish an approved ontology into the KB's graph store."""

    ontology: dict[str, Any]


class MergeRequest(BaseModel):
    """Merge several per-document ontologies (client-side map) into one."""

    ontologies: list[dict[str, Any]]


class OntologyResponse(BaseModel):
    status: str = "ok"
    kb_id: str
    ontology: dict[str, Any] = Field(default_factory=dict)
    # Ids of entities already present in the KB's graph, so the UI can mark which
    # nodes are existing (and which relationships link into the existing graph).
    existing_entity_ids: list[str] = Field(default_factory=list)
    # A short preview of the document text the LLM received (for transparency).
    context_preview: str = ""
    # Number of source documents that contributed to this response.
    document_count: int = 0
    # The exact ontology-extraction prompt the agent uses (for transparency in UI).
    agent_prompt: str = ""


@router.post("/knowledge-bases/{kb_id}/ontology/generate", response_model=OntologyResponse)
async def generate_kb_ontology(
    kb_id: str,
    files: list[UploadFile] = File(default=[]),
    file_path: str | None = Form(default=None),
    custom_prompt: str | None = Form(default=None),
) -> OntologyResponse:
    """Generate one ontology from one or more uploaded files (or a server file path).

    Uses a map-reduce strategy so it scales to many (or very large) documents:
    each document is extracted into its own ontology (the "map"), then all of
    them are merged and de-duplicated into a single ontology (the "reduce").
    Entities shared across documents (same id) stitch the documents together.
    """
    settings = get_settings()
    rag_config = settings.load_rag_config()
    allowed_types = _resolve_allowed_types(kb_id, rag_config)

    try:
        # Collect (label, text) for every source document.
        documents: list[tuple[str, str]] = []
        uploads = [f for f in files if f is not None and f.filename]

        if uploads:
            staging_dir = os.path.join(settings.SESSION_STORAGE_DIR, "ontology_uploads", kb_id)
            os.makedirs(staging_dir, exist_ok=True)
            for upload in uploads:
                ext = os.path.splitext(upload.filename or "file")[1]
                stored_path = os.path.join(staging_dir, f"{uuid.uuid4().hex}{ext}")
                content = await upload.read()
                with open(stored_path, "wb") as handle:
                    handle.write(content)
                text = load_document_text(stored_path)
                if text.strip():
                    documents.append((upload.filename or stored_path, text))
        elif file_path and file_path.strip():
            text = load_document_text(file_path.strip())
            if text.strip():
                documents.append((file_path.strip(), text))
        else:
            raise HTTPException(
                status_code=400,
                detail="Provide one or more uploaded 'files' or a server 'file_path'.",
            )

        if not documents:
            raise HTTPException(status_code=422, detail="Documents produced no extractable text.")

        # Graph-aware: learn what's already in this KB's graph so the agent reuses
        # existing ids and links new entities to them (clean incremental updates).
        existing_entities = fetch_existing_entities(kb_id, rag_config)

        # MAP: extract an ontology from each document independently so no single
        # prompt is overloaded (this is what lets it scale to many documents).
        # Documents are processed concurrently (bounded) to speed up large batches.
        semaphore = asyncio.Semaphore(_MAP_CONCURRENCY)

        # Normalise the session prompt: treat empty string as absent.
        _session_prompt: str | None = custom_prompt.strip() if custom_prompt else None

        async def _extract(name: str, text: str) -> dict | None:
            async with semaphore:
                try:
                    return await asyncio.to_thread(
                        generate_ontology,
                        document_text=text,
                        kb_id=kb_id,
                        allowed_types=allowed_types,
                        existing_entities=existing_entities,
                        custom_prompt=_session_prompt,
                    )
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Ontology extraction failed for document %r: %s", name, exc)
                    return None

        results = await asyncio.gather(*[_extract(name, text) for name, text in documents])
        per_document: list[dict] = [r for r in results if r]

        if not per_document:
            raise HTTPException(status_code=500, detail="Ontology extraction failed for all documents.")

        # CANDIDATE MERGE: merge all per-document ontologies into one.
        # This happens BEFORE identity resolution (merges current upload only).
        candidate_ontology = (
            per_document[0]
            if len(per_document) == 1
            else merge_ontologies(per_document, kb_id=kb_id)
        )
        
        # V2 FLOW: Identity resolution + NEW/EXISTING status enrichment (shared
        # with batch ontology-building scripts via resolve_and_enrich_ontology).
        if candidate_ontology.get("ontology_version", 1) == 2:
            logger.info(f"Processing V2 ontology for kb={kb_id}")
            ontology = resolve_and_enrich_ontology(candidate_ontology, existing_entities, kb_id, rag_config=rag_config)
        else:
            # V1 ontology (legacy support)
            logger.warning(f"Processing V1 ontology for kb={kb_id}. Consider migrating to V2 schema.")
            ontology = candidate_ontology
            
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"Ontology generation failed: {exc}") from exc

    existing_ids = [str(e["id"]) for e in existing_entities if e.get("id")]
    context_preview = _build_context_preview(documents)
    return OntologyResponse(
        kb_id=kb_id,
        ontology=ontology,
        existing_entity_ids=existing_ids,
        context_preview=context_preview,
        document_count=len(documents),
        agent_prompt=build_extraction_prompt_preview(
            allowed_types=allowed_types,
            existing_entities=existing_entities,
        ),
    )


@router.get("/knowledge-bases/{kb_id}/ontology/prompt")
async def get_kb_ontology_prompt(kb_id: str) -> dict[str, str]:
    """Return the ontology-extraction prompt the agent will use for this KB.

    Lets the UI show the exact agent instructions on the upload page before any
    document is generated. Existing entities are best-effort so this stays fast
    and never fails the page.
    """
    rag_config = get_settings().load_rag_config()
    allowed_types = _resolve_allowed_types(kb_id, rag_config)
    try:
        existing_entities = fetch_existing_entities(kb_id, rag_config)
    except Exception:  # noqa: BLE001
        existing_entities = []
    return {
        "kb_id": kb_id,
        "agent_prompt": build_extraction_prompt_preview(
            allowed_types=allowed_types,
            existing_entities=existing_entities,
        ),
    }


@router.post("/knowledge-bases/{kb_id}/ontology/revise", response_model=OntologyResponse)
async def revise_kb_ontology(kb_id: str, request: ReviseRequest) -> OntologyResponse:
    """Apply human feedback to an ontology and return the revised version."""
    rag_config = get_settings().load_rag_config()
    allowed_types = _resolve_allowed_types(kb_id, rag_config)

    try:
        ontology = revise_ontology(
            current_ontology=request.ontology,
            feedback=request.feedback,
            kb_id=kb_id,
            document_text=request.document_text,
            allowed_types=allowed_types,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"Ontology revision failed: {exc}") from exc

    return OntologyResponse(kb_id=kb_id, ontology=ontology)


@router.post("/knowledge-bases/{kb_id}/ontology/merge", response_model=OntologyResponse)
async def merge_kb_ontologies(kb_id: str, request: MergeRequest) -> OntologyResponse:
    """Merge per-document ontologies (produced client-side) into one ontology.

    Used by the UI's client-orchestrated flow: each document is generated
    separately (so a progress bar can advance), then all results are merged and
    de-duplicated here as the single source of truth.
    """
    if not request.ontologies:
        raise HTTPException(status_code=400, detail="No ontologies to merge.")

    rag_config = get_settings().load_rag_config()
    try:
        merged = merge_ontologies(request.ontologies, kb_id=kb_id)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"Ontology merge failed: {exc}") from exc

    existing_entities = fetch_existing_entities(kb_id, rag_config)
    existing_ids = [str(e["id"]) for e in existing_entities if e.get("id")]
    return OntologyResponse(kb_id=kb_id, ontology=merged, existing_entity_ids=existing_ids)


@router.post("/knowledge-bases/{kb_id}/ontology/publish")
async def publish_kb_ontology(kb_id: str, request: PublishRequest) -> dict:
    """Publish an approved ontology into the KB's graph store."""
    rag_config = get_settings().load_rag_config()
    try:
        result = publish_ontology(
            ontology=request.ontology,
            kb_id=kb_id,
            rag_config=rag_config,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"Ontology publish failed: {exc}") from exc

    # Refresh the concept embeddings used for GraphRAG entity search so the newly
    # published concepts are immediately vector-searchable. Best-effort: a failure
    # here must not fail the publish itself.
    try:
        from daan.native_tools.rag_tool import RagTool

        embed_result = RagTool(rag_config).index_ontology_concepts(kb_id=kb_id)
        result["concepts_indexed"] = int(embed_result.get("concepts_indexed", 0) or 0)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Concept embedding refresh failed for kb_id=%s: %s", kb_id, exc)

    return result


@router.get("/knowledge-bases/{kb_id}/ontology/graph")
async def get_kb_ontology_graph(
    kb_id: str, limit: int = 25000
) -> dict[str, Any]:
    """Return the full published graph for a KB in a visualization-ready shape.

    Shape:
        {
          "nodes": [{id, caption, layer, description, color, size}, ...],
          "relationships": [{id, from, to, type, caption}, ...]
        }

    ``layer``/``color`` are derived from each node's ontology type and ``size``
    scales with the node's degree (more connections -> larger node). Document
    ``Chunk`` vertices are excluded.
    """
    rag_config = get_settings().load_rag_config()
    try:
        graph = fetch_full_graph(kb_id, rag_config, limit=limit)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"Failed to read ontology graph: {exc}") from exc
    return _to_visual_graph(graph)


@router.get("/knowledge-bases/{kb_id}/ontology/graph/node/{node_id}")
async def get_kb_ontology_node(kb_id: str, node_id: str, depth: int = 1) -> dict[str, Any]:
    """Return a single node plus its neighborhood (within ``depth`` hops).

    Powers click-to-expand exploration: the UI starts from one node and calls
    this each time a node is clicked to reveal its connected nodes/relationships,
    merging the result into the graph already on screen.

    Returns the same ``{nodes, relationships}`` shape as the full-graph endpoint,
    so the client can reuse one renderer. ``depth`` is clamped to 1..5.
    """
    rag_config = get_settings().load_rag_config()
    try:
        graph = fetch_node_neighborhood(kb_id, rag_config, node_id, depth=depth)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(
            status_code=500, detail=f"Failed to read node neighborhood: {exc}"
        ) from exc
    return _to_visual_graph(graph)


# Distinct colors assigned per ontology type (cycled if there are more types).
_GRAPH_PALETTE = [
    "#7c3aed",  # violet
    "#2563eb",  # blue
    "#0f766e",  # teal
    "#db2777",  # pink
    "#16a34a",  # green
    "#ea580c",  # orange
    "#0891b2",  # cyan
    "#9333ea",  # purple
    "#ca8a04",  # amber
    "#dc2626",  # red
]


def _to_visual_graph(graph: dict[str, list[dict[str, Any]]]) -> dict[str, Any]:
    """Map a ``{nodes, edges}`` graph into the visualization ``{nodes, relationships}`` shape."""
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])

    # Degree per node drives the visual size (more links -> bigger node).
    degree: dict[str, int] = {}
    for edge in edges:
        degree[edge["source"]] = degree.get(edge["source"], 0) + 1
        degree[edge["target"]] = degree.get(edge["target"], 0) + 1

    # Stable color per distinct ontology type.
    types = sorted({str(n.get("type") or "Entity") for n in nodes})
    color_by_type = {t: _GRAPH_PALETTE[i % len(_GRAPH_PALETTE)] for i, t in enumerate(types)}

    visual_nodes = []
    for node in nodes:
        node_type = str(node.get("type") or "Entity")
        node_degree = degree.get(node["id"], 0)
        # Base 34, +3 per connection, capped at 60.
        size = min(60, 34 + node_degree * 3)
        visual_nodes.append(
            {
                "id": node["id"],
                "caption": node.get("name") or node["id"],
                "layer": node_type.lower(),
                "description": node.get("description") or node.get("name") or "",
                "color": color_by_type.get(node_type, "#0f766e"),
                "size": size,
            }
        )

    visual_relationships = []
    for index, edge in enumerate(edges, start=1):
        edge_type = str(edge.get("type") or "RELATION")
        visual_relationships.append(
            {
                "id": f"r{index}",
                "from": edge["source"],
                "to": edge["target"],
                "type": edge_type,
                "caption": edge_type,
            }
        )

    return {"nodes": visual_nodes, "relationships": visual_relationships}


def _resolve_allowed_types(kb_id: str, rag_config: dict[str, Any]) -> dict[str, list[str]] | None:
    """Return the optional per-KB ontology vocabulary (open when not configured)."""
    for entry in rag_config.get("knowledge_bases", []) or []:
        if str(entry.get("id")) == str(kb_id):
            allowed = entry.get("ontology_types")
            return allowed if isinstance(allowed, dict) else None
    return None


def _build_context_preview(documents: list[tuple[str, str]], *, per_doc_chars: int = 800) -> str:
    """Build a short, labeled preview of the text extracted from each document.

    Lets the UI show what the LLM actually received (transparency), without
    returning the full (potentially large) document text.
    """
    sections: list[str] = []
    for name, text in documents:
        snippet = (text or "").strip()
        truncated = snippet[:per_doc_chars]
        suffix = "\n[...truncated...]" if len(snippet) > per_doc_chars else ""
        sections.append(f"=== {name} ===\n{truncated}{suffix}")
    return "\n\n".join(sections)
