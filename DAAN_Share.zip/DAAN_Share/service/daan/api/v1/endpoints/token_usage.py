"""Token usage analytics endpoints for dashboard cards and charts."""

from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from daan.core.database import get_db
from daan.core.dependencies import get_current_active_user
from daan.models.user import User
from daan.schemas.token_usage import (
    TokenUsageByUsecaseRequest,
    TokenUsageByUsecaseResponse,
    TokenUsageByUserRequest,
    TokenUsageByUserResponse,
    TokenUsageUsecaseOptionsResponse,
)
from daan.token_usage.access import get_accessible_usecase_ids, is_admin_user, user_has_access_to_usecase
from daan.token_usage.dashboard_service import (
    get_usecase_token_usage_dashboard,
    get_top_usecase_options,
    get_user_token_usage_dashboard,
)

router = APIRouter()


def _validate_date_range(start_date, end_date) -> None:
    if start_date > end_date:
        raise HTTPException(status_code=400, detail="start_date must be before or equal to end_date")


@router.post("/token-usage/by-user", response_model=TokenUsageByUserResponse)
def token_usage_by_user(
    payload: TokenUsageByUserRequest,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> TokenUsageByUserResponse:
    """Return all user-scope dashboard metrics in one response."""
    _validate_date_range(payload.start_date, payload.end_date)

    is_admin = is_admin_user(current_user)
    effective_user_id = payload.user_id

    if not is_admin:
        if effective_user_id is not None and effective_user_id != current_user.id:
            raise HTTPException(status_code=403, detail="Users can only view their own token usage")
        effective_user_id = current_user.id

    if effective_user_id is None:
        data = get_user_token_usage_dashboard(
            db,
            start_date=payload.start_date,
            end_date=payload.end_date,
            user_id=None,
        )
        return TokenUsageByUserResponse(**data)

    data = get_user_token_usage_dashboard(
        db,
        start_date=payload.start_date,
        end_date=payload.end_date,
        user_id=effective_user_id,
    )
    return TokenUsageByUserResponse(**data)


@router.post("/token-usage/by-usecase", response_model=TokenUsageByUsecaseResponse)
def token_usage_by_usecase(
    payload: TokenUsageByUsecaseRequest,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> TokenUsageByUsecaseResponse:
    """Return all use-case-scope dashboard metrics in one response."""
    _validate_date_range(payload.start_date, payload.end_date)

    accessible_usecase_ids: set[str] | None = None
    if payload.usecase_id and not user_has_access_to_usecase(db, current_user, payload.usecase_id):
        raise HTTPException(status_code=403, detail="Not authorized to view token usage for this use case")
    if not payload.usecase_id and not is_admin_user(current_user):
        accessible_usecase_ids = get_accessible_usecase_ids(db, current_user)

    data = get_usecase_token_usage_dashboard(
        db,
        start_date=payload.start_date,
        end_date=payload.end_date,
        usecase_id=payload.usecase_id,
        top_n=payload.top_n,
        accessible_usecase_ids=accessible_usecase_ids,
    )
    return TokenUsageByUsecaseResponse(**data)


@router.get("/token-usage/usecases/options", response_model=TokenUsageUsecaseOptionsResponse)
def token_usage_usecase_options(
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
    start_date: datetime | None = Query(None),
    end_date: datetime | None = Query(None),
    granularity: str = Query("day"),
    limit: int = Query(10, ge=1, le=10),
) -> TokenUsageUsecaseOptionsResponse:
    """Return top accessible use cases for the selector dropdown."""
    # Validate that both dates are provided together or both omitted
    if (start_date is None) != (end_date is None):
        raise HTTPException(status_code=400, detail="Both start_date and end_date must be provided together or both omitted")
    if start_date is not None and end_date is not None:
        _validate_date_range(start_date, end_date)
    if granularity != "day":
        raise HTTPException(status_code=400, detail="granularity must be 'day'")

    usecases = get_top_usecase_options(
        db,
        start_date=start_date,
        end_date=end_date,
        user=current_user,
        limit=limit,
    )
    return TokenUsageUsecaseOptionsResponse(usecases=usecases)