"""Agent endpoints."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query

from daan.agents.agent_service import get_agent_details
from daan.core.dependencies import get_current_active_user
from daan.schemas.usecase import AgentDetailResponse

router = APIRouter()


# GET /agents/{agent_id} — Get agent details
@router.get("/agents/{agent_id}", response_model=dict)
def get_agent_detail(
    current_user: Annotated[object, Depends(get_current_active_user)],
    agent_id: str,
    archetype: str = Query(None),
    usecase: str = Query(None),
) -> dict:
    """Get agent details (optionally filter by archetype/usecase)."""
    _ = current_user
    if archetype and usecase:
        try:
            agent = get_agent_details(archetype, usecase, agent_id)
            return {
                "archetype": archetype,
                "usecase": usecase,
                "agent": agent_id,
                "details": agent
            }
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
    raise HTTPException(status_code=400, detail="archetype and usecase required")
