"""Prompt endpoints."""

from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy.orm import Session
from sqlalchemy import text

from daan.core.database import get_db
from daan.core.dependencies import get_current_active_user
from daan.models.user import User
from daan.prompt_catalog.prompt_service import (
    delete_prompt,
    get_full_prompt,
    list_prompt_versions,
    list_prompts,
    save_prompt,
)
from daan.schemas.archetype import (
    PromptCreateUpdate,
    PromptDetailResponse,
    PromptSummaryResponse,
    PromptVersionResponse,
)
from daan.admin.user_service import can_edit_archetype, can_edit_archetype_by_id

router = APIRouter()


@router.get("/agents", response_model=list[PromptSummaryResponse])
def get_agents(
    current_user: Annotated[User, Depends(get_current_active_user)],
    response: Response,
    db: Session = Depends(get_db),
    offset: int = Query(0, ge=0, description="Pagination offset"),
    limit: int | None = Query(None, ge=1, le=100, description="Max rows to return"),
    search: str | None = Query(None, description="Optional agent name or ID search"),
    archetype: str | None = Query(None, description="Optional archetype filter."),
    role: str | None = Query(None, description="Optional role filter."),
    premium_mode: Literal["premium", "non_premium"] | None = Query(
        None,
        description="Optional premium filter inherited from mapped use cases.",
    ),
    only_active_usecases: bool = Query(
        False,
        description="When true, return only agents mapped to an active use case.",
    ),
) -> list[PromptSummaryResponse]:
    """List all agents from the database."""
    _ = current_user
    prompts, has_more = list_prompts(
        db,
        offset=offset,
        limit=limit,
        search=search,
        archetype=archetype,
        role=role,
        premium_mode=premium_mode,
        only_active_usecases=only_active_usecases,
    )
    response.headers["X-Has-More"] = "true" if has_more else "false"
    return [PromptSummaryResponse(**prompt) for prompt in prompts]


@router.post("/agents", response_model=PromptDetailResponse)
def create_new_agent(
    prompt: PromptCreateUpdate,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Session = Depends(get_db),
) -> PromptDetailResponse:
    """Create a new agent. Checks for 'edit' permission by archetype name."""
    if not prompt.archetype or not can_edit_archetype(db, current_user, prompt.archetype):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"You do not have edit permission for archetype {prompt.archetype}",
        )
    
    try:
        result = save_prompt(db, prompt, user=current_user)
        return PromptDetailResponse(**result)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.put("/agents/{agent_id}", response_model=PromptDetailResponse)
def update_existing_agent(
    agent_id: str,
    prompt: PromptCreateUpdate,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Session = Depends(get_db),
) -> PromptDetailResponse:
    """Update an existing agent. Checks for 'edit' permission."""
    try:
        existing_prompt = get_full_prompt(db, agent_id=agent_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    arch_to_check = existing_prompt.get("archetype")
    
    if not arch_to_check or not can_edit_archetype(db, current_user, arch_to_check):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"You do not have edit permission for archetype {arch_to_check}",
        )

    try:
        # Note: save_prompt needs to know the correct integer prompt_id or lookup by agent_id. Let's pass agent_id to explicitly do the right logic.
        result = save_prompt(db, prompt, agent_id=agent_id, user=current_user)
        return PromptDetailResponse(**result)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.delete("/agents/{agent_id}")
def delete_existing_agent(
    agent_id: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Session = Depends(get_db),
):
    """Delete an agent. Checks for 'edit' permission."""
    try:
        prompt_data = get_full_prompt(db, agent_id=agent_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    if not prompt_data.get("archetype") or not can_edit_archetype(db, current_user, prompt_data["archetype"]):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have edit permission for this agent's archetype",
        )
    
    deleted = delete_prompt(db, agent_id=agent_id, user=current_user)
    if not deleted:
        raise HTTPException(status_code=404, detail="Agent not found")
        
    return {"message": f"Agent with ID {agent_id} deleted successfully"}


@router.get("/agents/{agent_id}/prompt-versions", response_model=list[PromptVersionResponse])
def get_prompt_versions(
    agent_id: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Session = Depends(get_db),
) -> list[PromptVersionResponse]:
    """Return all prompt versions for an agent, newest first.

    The ``is_latest`` flag is ``true`` on the most recent version so the UI
    can highlight it without extra logic.
    """
    _ = current_user
    try:
        return [PromptVersionResponse(**v) for v in list_prompt_versions(db, agent_id)]
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
