"""REST endpoints for MCP credential management, server registry, and process info."""

import logging
from datetime import datetime
from typing import Annotated, Any, Union

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy import and_
from sqlalchemy.orm import Session

from daan.admin.mcp_service import get_credentials_service
from daan.core.credential_resolver import CredentialResolver, get_server_registry_config, list_registry_servers
from daan.core.database import get_db
from daan.core.dependencies import get_current_active_user
from daan.mcp_servers.core.credential_validator import get_credential_validator
from daan.core.exceptions import DAANException
from daan.models.user import User
from daan.models.user_mcp import UserMcpConfig, ValidationStatus
from daan.models.mcp_registry import McpServerRegistry, RegistryStatus
from daan.mcp_servers.core.mcp_manager import get_process_manager
from daan.schemas.mcp import (
    McpCredentialCreate,
    McpCredentialResponse,
    McpCredentialUpdate,
    McpCredentialValidate,
    McpCredentialValidationResult,
    McpCredentialWithSecrets,
    McpProcessInfo,
    McpServerDefinition,
    McpServerListResponse,
    McpStatistics,
    McpTestConnectionRequest,
    McpTestConnectionResult,
    McpToolInfo,
    McpToolsListResponse,
)

logger = logging.getLogger(__name__)
router = APIRouter()

ADMIN_ROLE_ID = 1

# MCP Admin usernames - users who can edit global MCP credentials
MCP_ADMIN_USERNAMES = {"mcp_admin"}  # Add more usernames here if needed

_MCP_HTTP_STATUS: dict[DAANException.ErrorCode, int] = {
    DAANException.ErrorCode.CREDENTIAL_NOT_FOUND: status.HTTP_404_NOT_FOUND,
    DAANException.ErrorCode.CREDENTIAL_ALREADY_EXISTS: status.HTTP_400_BAD_REQUEST,
    DAANException.ErrorCode.CREDENTIAL_EXPIRED: status.HTTP_410_GONE,
    DAANException.ErrorCode.RATE_LIMIT_EXCEEDED: status.HTTP_429_TOO_MANY_REQUESTS,
    DAANException.ErrorCode.DECRYPTION_FAILED: status.HTTP_500_INTERNAL_SERVER_ERROR,
    DAANException.ErrorCode.PROCESS_LIMIT_REACHED: status.HTTP_429_TOO_MANY_REQUESTS,
}


def _mcp_http_status(e: DAANException) -> int:
    return _MCP_HTTP_STATUS.get(e.error_code, status.HTTP_400_BAD_REQUEST)


def _is_admin(user: User) -> bool:
    return getattr(user, "role_id", None) == ADMIN_ROLE_ID


def _is_mcp_admin(user: User) -> bool:
    """Check if user is authorized to manage global MCP credentials."""
    return getattr(user, "username", "").lower() in MCP_ADMIN_USERNAMES


def _require_admin(user: User):
    """Raise 403 if user is not an admin."""
    if not _is_admin(user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error_code": "forbidden", "message": "Admin role required for this operation"},
        )


def _require_mcp_admin(user: User):
    """Raise 403 if user is not an MCP admin."""
    if not _is_mcp_admin(user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error_code": "forbidden", "message": "MCP admin permission required for this operation"},
        )


def _should_use_dynamic_registry_fallback(message: str | None) -> bool:
    """Return True when YAML-only validation cannot test a DB-registered server."""
    normalized = (message or "").lower()
    return "not found" in normalized or "no validation config" in normalized


def _test_dynamic_stdio_server(
    server_name: str,
    registry_entry: McpServerRegistry,
    credentials_env: dict[str, str],
) -> McpTestConnectionResult:
    """Test a DB-registered stdio server by spawning it and performing MCP initialize."""
    import json as _json
    import os
    import shutil
    import subprocess
    import sys
    import time as _time

    cmd = str(registry_entry.command or "").strip()
    args = registry_entry.args or []
    env_vars = dict(registry_entry.env_vars or {})
    env_vars.update({k: str(v) for k, v in credentials_env.items()})

    proc_env = {**os.environ, **env_vars}
    resolved_cmd = shutil.which(cmd, path=os.environ.get("PATH"))
    use_shell = sys.platform == "win32" and not resolved_cmd
    run_cmd = [resolved_cmd or cmd] + args
    start = _time.time()

    try:
        proc = subprocess.Popen(
            run_cmd if not use_shell else " ".join(run_cmd),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=proc_env,
            shell=use_shell,
        )

        init_msg = _json.dumps(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "DAAN6-Test", "version": "1.0.0"},
                },
            }
        ) + "\n"
        assert proc.stdin is not None
        assert proc.stdout is not None
        proc.stdin.write(init_msg.encode())
        proc.stdin.flush()

        init_line = proc.stdout.readline().decode().strip()
        proc.terminate()

        latency = int((_time.time() - start) * 1000)
        if not init_line:
            stderr_text = ""
            if proc.stderr is not None:
                stderr_text = proc.stderr.read().decode(errors="ignore").strip()
            return McpTestConnectionResult(
                server_name=server_name,
                connected=False,
                latency_ms=latency,
                message=stderr_text[:300] or "No response from subprocess",
                auth_method="stdio",
            )

        payload = _json.loads(init_line)
        if payload.get("error"):
            return McpTestConnectionResult(
                server_name=server_name,
                connected=False,
                latency_ms=latency,
                message=str(payload["error"])[:300],
                auth_method="stdio",
            )

        return McpTestConnectionResult(
            server_name=server_name,
            connected=True,
            latency_ms=latency,
            message=f"Connected ({latency}ms)",
            auth_method="stdio",
        )
    except FileNotFoundError:
        return McpTestConnectionResult(
            server_name=server_name,
            connected=False,
            latency_ms=0,
            message=f"Command '{cmd}' not found. Make sure {cmd} is installed.",
            auth_method="stdio",
        )
    except Exception as e:
        return McpTestConnectionResult(
            server_name=server_name,
            connected=False,
            latency_ms=int((_time.time() - start) * 1000),
            message=str(e)[:300],
            auth_method="stdio",
        )

def get_client_ip(request: Request) -> str:
    """Extract client IP address from request."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


@router.get("/mcp-admin-status")
def check_mcp_admin_status(
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> dict:
    """Check if the current user has MCP admin permissions.
    
    Returns:
        Dict with is_mcp_admin, is_admin boolean flags and username string
    """
    return {
        "is_mcp_admin": _is_mcp_admin(current_user),
        "is_admin": _is_admin(current_user),
        "username": current_user.username,
    }


@router.post("/credentials", response_model=McpCredentialResponse, status_code=status.HTTP_201_CREATED)
def create_mcp_credential(
    payload: McpCredentialCreate,
    request: Request,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> McpCredentialResponse:
    """Create new MCP server credentials.
    
    Regular users create personal credentials.
    MCP admins (specific usernames) can set is_global_default=True to create system-wide defaults.
    """
    try:
        if payload.is_global_default:
            _require_mcp_admin(current_user)

        service = get_credentials_service()
        ip_address = get_client_ip(request)

        config = service.create_credential(
            db=db,
            user_id=current_user.id,
            server_name=payload.server_name,
            credentials=payload.credentials,
            expires_at=payload.expires_at,
            server_metadata=payload.server_metadata,
            validate_credentials=True,
            ip_address=ip_address,
            correlation_id=request.headers.get("X-Correlation-ID"),
            is_global_default=payload.is_global_default,
        )

        return McpCredentialResponse.model_validate(config)

    except DAANException as e:
        raise HTTPException(status_code=_mcp_http_status(e), detail=e.to_dict())
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error_code": "internal_error", "message": str(e)},
        )


@router.get("/credentials", response_model=list[McpCredentialResponse])
def list_mcp_credentials(
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
    include_inactive: bool = Query(False, description="Include inactive credentials"),
) -> list[McpCredentialResponse]:
    """List all MCP credentials for the current user.
    
    Returns a merged view of:
    - User's custom credentials (is_global=False)
    - Global default credentials from DB (is_global=True) for servers not customized by user

    Args:
        current_user: Authenticated user
        db: Database session
        include_inactive: Whether to include inactive credentials

    Returns:
        List of MCP credential responses
    """
    try:
        service = get_credentials_service()
        
        # Get user's custom credentials
        user_configs = service.list_credentials(
            db=db,
            user_id=current_user.id,
            include_inactive=include_inactive,
        )
        user_server_map = {config.mcp_server_name: config for config in user_configs}
        
        # Get all global defaults from DB
        global_query = db.query(UserMcpConfig).filter(
            UserMcpConfig.is_global_default == True,
            UserMcpConfig.is_active == True,
            UserMcpConfig.deleted_at == None,
        )
        global_configs = {cfg.mcp_server_name: cfg for cfg in global_query.all()}
        
        # Get all servers from registry
        registry_servers = list_registry_servers()
        
        result = []
        for server_name in registry_servers:
            registry_config = get_server_registry_config(server_name)
            if not registry_config:
                continue

            # Always build metadata from registry
            registry_metadata = {
                "display_name": registry_config.get("display_name", _format_display_name(server_name)),
                "description": registry_config.get("description", ""),
                "transport": registry_config.get("transport", "stdio"),
            }

            if server_name in user_server_map:
                config = user_server_map[server_name]
                response = McpCredentialResponse.model_validate(config)
                response.is_global = False
                response.server_metadata = registry_metadata
                result.append(response)
            elif server_name in global_configs:
                config = global_configs[server_name]
                response = McpCredentialResponse.model_validate(config)
                response.is_global = True
                response.server_metadata = registry_metadata
                result.append(response)
            else:
                result.append(McpCredentialResponse(
                    id=0,
                    user_id=current_user.id,
                    mcp_server_name=server_name,
                    is_active=registry_config.get("enabled", True),
                    validation_status="not_configured",
                    last_validation_at=None,
                    last_accessed_at=None,
                    access_count=0,
                    expires_at=None,
                    credential_version=1,
                    server_metadata=registry_metadata,
                    created_at=datetime.now(),
                    updated_at=datetime.now(),
                    is_global=True,
                ))
        
        result.sort(key=lambda r: (r.server_metadata or {}).get("display_name", r.mcp_server_name).lower())

        # Include DB-registered servers not in YAML
        seen_servers = {r.mcp_server_name for r in result}
        for server_name, config in user_server_map.items():
            if server_name not in seen_servers:
                response = McpCredentialResponse.model_validate(config)
                response.is_global = False
                # Prefer the user's own registry row; only fall back to a global row
                # so we don't accidentally borrow display_name/description from a
                # collision-named global entry created by someone else.
                db_entry = db.query(McpServerRegistry).filter(
                    McpServerRegistry.server_name == server_name,
                    McpServerRegistry.created_by_user_id == current_user.id,
                ).first() or db.query(McpServerRegistry).filter(
                    McpServerRegistry.server_name == server_name,
                    McpServerRegistry.is_global == True,
                ).first()
                response.server_metadata = {
                    "display_name": db_entry.display_name if db_entry else _format_display_name(server_name),
                    "description": db_entry.description if db_entry else "",
                    "transport": db_entry.transport.value if db_entry and db_entry.transport else "stdio",
                }
                result.append(response)
                seen_servers.add(server_name)

        # Include global defaults for DB-registered servers not yet listed
        for server_name, config in global_configs.items():
            if server_name not in seen_servers:
                response = McpCredentialResponse.model_validate(config)
                response.is_global = True
                # Global credential — anchor to a global registry row when one exists,
                # else fall back to any row owned by the same admin.
                db_entry = db.query(McpServerRegistry).filter(
                    McpServerRegistry.server_name == server_name,
                    McpServerRegistry.is_global == True,
                ).first() or db.query(McpServerRegistry).filter(
                    McpServerRegistry.server_name == server_name,
                    McpServerRegistry.created_by_user_id == config.user_id,
                ).first()
                response.server_metadata = {
                    "display_name": db_entry.display_name if db_entry else _format_display_name(server_name),
                    "description": db_entry.description if db_entry else "",
                    "transport": db_entry.transport.value if db_entry and db_entry.transport else "stdio",
                }
                result.append(response)

        return result

    except Exception as e:
        logger.error(f"Error listing MCP credentials: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error_code": "internal_error", "message": str(e)},
        )


@router.get("/credentials/{server_name}", response_model=Union[McpCredentialWithSecrets, McpCredentialResponse])
def get_mcp_credential(
    server_name: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
    decrypt: bool = Query(False, description="Return decrypted credentials (use with caution)"),
    fetch_global: bool = Query(False, description="Force fetch global default instead of user custom"),
) -> McpCredentialResponse | McpCredentialWithSecrets:
    """Get specific MCP credential for the current user.
    
    Returns user's custom credential if exists, otherwise falls back to global default from DB.
    When fetch_global=true, always returns the global default credential.
    """
    try:
        resolver = CredentialResolver(db, current_user.id)

        # If not explicitly requesting global, check user's own config first
        if not fetch_global:
            user_config = db.query(UserMcpConfig).filter(
                and_(
                    UserMcpConfig.user_id == current_user.id,
                    UserMcpConfig.mcp_server_name == server_name,
                    UserMcpConfig.is_global_default == False,
                    UserMcpConfig.is_active == True,
                    UserMcpConfig.deleted_at == None,
                )
            ).first()

            if user_config:
                if decrypt:
                    creds = resolver._decrypt(user_config)
                    response_dict = McpCredentialResponse.model_validate(user_config).model_dump()
                    response_dict["credentials"] = creds
                    response_dict["is_global"] = False
                    return McpCredentialWithSecrets(**response_dict)
                response = McpCredentialResponse.model_validate(user_config)
                response.is_global = False
                return response

        # Fall back to global default
        global_config = db.query(UserMcpConfig).filter(
            and_(
                UserMcpConfig.mcp_server_name == server_name,
                UserMcpConfig.is_global_default == True,
                UserMcpConfig.is_active == True,
                UserMcpConfig.deleted_at == None,
            )
        ).first()

        if global_config:
            if decrypt:
                creds = resolver._decrypt(global_config)
                response_dict = McpCredentialResponse.model_validate(global_config).model_dump()
                response_dict["credentials"] = creds
                response_dict["is_global"] = True
                return McpCredentialWithSecrets(**response_dict)
            response = McpCredentialResponse.model_validate(global_config)
            response.is_global = True
            return response

        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error_code": "credential_not_found", "message": f"No credentials for '{server_name}'"},
        )

    except HTTPException:
        raise
    except DAANException as e:
        raise HTTPException(status_code=_mcp_http_status(e), detail=e.to_dict())
    except Exception as e:
        logger.error(f"Error getting MCP credential for {server_name}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error_code": "internal_error", "message": str(e)},
        )


@router.put("/credentials/{server_name}", response_model=McpCredentialResponse)
def update_mcp_credential(
    server_name: str,
    payload: McpCredentialUpdate,
    request: Request,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
    is_global: bool = Query(False, description="Update global default (MCP admin only)"),
) -> McpCredentialResponse:
    """Update MCP server credentials.
    
    Regular users can only update their own custom credentials.
    MCP admins can update global defaults by passing is_global=true.
    """
    try:
        if is_global:
            _require_mcp_admin(current_user)
            # Find the global config to get its owner user_id
            global_cfg = db.query(UserMcpConfig).filter(
                and_(
                    UserMcpConfig.mcp_server_name == server_name,
                    UserMcpConfig.is_global_default == True,
                )
            ).first()
            if not global_cfg:
                # No global default yet — check if admin has a personal credential to promote
                personal_cfg = db.query(UserMcpConfig).filter(
                    and_(
                        UserMcpConfig.user_id == current_user.id,
                        UserMcpConfig.mcp_server_name == server_name,
                        UserMcpConfig.deleted_at.is_(None),
                    )
                ).first()
                if personal_cfg:
                    personal_cfg.is_global_default = True
                    db.commit()
                    target_user_id = current_user.id
                else:
                    # No credential exists at all — create a new global one
                    service = get_credentials_service()
                    config = service.create_credential(
                        db=db,
                        user_id=current_user.id,
                        server_name=server_name,
                        credentials=payload.credentials or {},
                        expires_at=payload.expires_at,
                        server_metadata=payload.server_metadata,
                        is_global_default=True,
                    )
                    response = McpCredentialResponse.model_validate(config)
                    response.is_global = True
                    return response
            else:
                target_user_id = global_cfg.user_id
        else:
            target_user_id = current_user.id

        service = get_credentials_service()
        ip_address = get_client_ip(request)

        config = service.update_credential(
            db=db,
            user_id=target_user_id,
            server_name=server_name,
            credentials=payload.credentials,
            expires_at=payload.expires_at,
            server_metadata=payload.server_metadata,
            is_active=payload.is_active,
            validate_credentials=True,
            ip_address=ip_address,
            correlation_id=request.headers.get("X-Correlation-ID"),
        )

        return McpCredentialResponse.model_validate(config)

    except DAANException as e:
        raise HTTPException(status_code=_mcp_http_status(e), detail=e.to_dict())
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error_code": "internal_error", "message": str(e)},
        )


@router.delete("/credentials/{server_name}", status_code=status.HTTP_204_NO_CONTENT)
def delete_mcp_credential(
    server_name: str,
    request: Request,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
    hard_delete: bool = Query(False, description="Permanently delete (vs soft delete)"),
) -> None:
    """Delete MCP server credentials for the current user.

    Args:
        server_name: Name of the MCP server
        request: FastAPI request object
        current_user: Authenticated user
        db: Database session
        hard_delete: Whether to permanently delete or just mark as deleted

    Raises:
        HTTPException: If credential not found
    """
    try:
        service = get_credentials_service()
        ip_address = get_client_ip(request)

        service.delete_credential(
            db=db,
            user_id=current_user.id,
            server_name=server_name,
            soft_delete=not hard_delete,
            ip_address=ip_address,
            correlation_id=request.headers.get("X-Correlation-ID"),
        )

    except DAANException as e:
        # DELETE is idempotent: if the credential never existed, desired state is already met
        if e.error_code == DAANException.ErrorCode.CREDENTIAL_NOT_FOUND:
            return
        raise HTTPException(status_code=_mcp_http_status(e), detail=e.to_dict())
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error_code": "internal_error", "message": str(e)},
        )


@router.post("/credentials/{server_name}/validate", response_model=McpCredentialValidationResult)
def validate_mcp_credential(
    server_name: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> McpCredentialValidationResult:
    """Validate MCP server credentials against the server registry.

    This endpoint checks if the stored credentials have all required fields
    according to the server definition, but does not test actual connectivity.

    Args:
        server_name: Name of the MCP server
        current_user: Authenticated user
        db: Database session

    Returns:
        Validation result

    Raises:
        HTTPException: If credential not found
    """
    try:
        from datetime import datetime

        service = get_credentials_service()
        validator = get_credential_validator()

        # Get and decrypt credentials
        config, decrypted_credentials = service.get_credential(
            db=db,
            user_id=current_user.id,
            server_name=server_name,
            decrypt=True,
            check_expiry=False,  # Allow validation of expired credentials
        )

        if not decrypted_credentials:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={"error_code": "decryption_failed", "message": "Failed to decrypt credentials"},
            )

        # Validate against registry
        is_valid, missing_fields, extra_fields = validator.validate_credentials(
            server_name=server_name,
            credentials=decrypted_credentials,
            strict=False,
        )

        message = "Credentials are valid"
        if missing_fields:
            message = f"Missing required fields: {', '.join(missing_fields)}"
        elif extra_fields:
            message = f"Valid (extra fields present: {', '.join(extra_fields)})"

        # Persist validation result to DB
        checked_at = datetime.now()
        config.validation_status = ValidationStatus.VALID if is_valid else ValidationStatus.INVALID
        config.last_validation_at = checked_at
        db.commit()

        return McpCredentialValidationResult(
            server_name=server_name,
            is_valid=is_valid,
            validation_message=message,
            validation_status=config.validation_status.value,
            checked_at=checked_at,
        )

    except DAANException as e:
        raise HTTPException(status_code=_mcp_http_status(e), detail=e.to_dict())
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error_code": "internal_error", "message": str(e)},
        )


@router.post("/credentials/{server_name}/test-connection", response_model=McpTestConnectionResult)
def test_mcp_connection_saved(
    server_name: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> McpTestConnectionResult:
    """Test real connectivity using resolved credentials (user's or global default)."""
    try:
        from daan.mcp_servers.core.connection_tester import test_connection

        # For DB-registered HTTP servers, test directly using base_url (skip YAML tester)
        registry_entry = db.query(McpServerRegistry).filter(
            McpServerRegistry.server_name == server_name,
            (McpServerRegistry.created_by_user_id == current_user.id)
            | (McpServerRegistry.is_global == True),
        ).first()
        if registry_entry and registry_entry.base_url:
            base_url = (registry_entry.base_url or "").strip()
            auth_scheme = registry_entry.auth_scheme.value if registry_entry.auth_scheme else "none"
            import time
            import httpx
            import ssl
            start = time.time()
            headers = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}

            # Resolve credentials for auth (skip for no-auth servers)
            if auth_scheme != "none":
                resolver = CredentialResolver(db, current_user.id)
                try:
                    decrypted_credentials = resolver.resolve(server_name)
                except DAANException:
                    return McpTestConnectionResult(
                        server_name=server_name, connected=False, latency_ms=0,
                        message="No credentials configured for this server",
                        auth_method="unknown",
                    )
                from daan.mcp_servers.core.mcp_auth import build_auth_headers
                headers.update(build_auth_headers(auth_scheme, decrypted_credentials))

            try:
                ssl_ctx = ssl.create_default_context()
                resp = httpx.post(
                    base_url,
                    json={"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "DAAN6-Test", "version": "1.0.0"}}},
                    headers=headers,
                    timeout=15.0,
                    verify=ssl_ctx,
                )
                latency = int((time.time() - start) * 1000)
                if resp.status_code == 200:
                    registry_entry.status = RegistryStatus.VALIDATED
                    registry_entry.updated_at = datetime.now()
                    db.commit()
                    return McpTestConnectionResult(
                        server_name=server_name, connected=True,
                        latency_ms=latency, message=f"Connected ({latency}ms)",
                        auth_method=auth_scheme,
                    )
                else:
                    return McpTestConnectionResult(
                        server_name=server_name, connected=False,
                        latency_ms=latency, message=f"HTTP {resp.status_code}: {resp.text[:200]}",
                        auth_method=auth_scheme,
                    )
            except Exception as e:
                return McpTestConnectionResult(
                    server_name=server_name, connected=False,
                    latency_ms=int((time.time() - start) * 1000),
                    message=str(e)[:300], auth_method=auth_scheme,
                )
        elif registry_entry and registry_entry.auth_scheme.value == "none":
            return McpTestConnectionResult(
                server_name=server_name, connected=True,
                latency_ms=0, message="No external connection required (auth: none)",
                auth_method="none",
            )

        resolver = CredentialResolver(db, current_user.id)
        try:
            decrypted_credentials = resolver.resolve(server_name)
        except DAANException:
            return McpTestConnectionResult(
                server_name=server_name,
                connected=False,
                latency_ms=0,
                message="No credentials configured for this server",
                auth_method="unknown",
            )

        result = test_connection(server_name, decrypted_credentials)

        # If YAML-based tester fails for DB-registered servers, try direct HTTP test
        if not result.connected and _should_use_dynamic_registry_fallback(result.message):
            registry_entry = db.query(McpServerRegistry).filter(
                McpServerRegistry.server_name == server_name,
                (McpServerRegistry.created_by_user_id == current_user.id)
                | (McpServerRegistry.is_global == True),
            ).first()
            if registry_entry and registry_entry.base_url:
                import time as _time
                import httpx
                import ssl
                base_url = (registry_entry.base_url or "").strip()
                start = _time.time()
                try:
                    ssl_ctx = ssl.create_default_context()
                    headers = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
                    # Add auth headers from resolved credentials
                    auth_scheme = registry_entry.auth_scheme.value if registry_entry.auth_scheme else "none"
                    # Build auth header — try the most likely credential key
                    token_value = decrypted_credentials.get("access_token") or decrypted_credentials.get("api_key") or decrypted_credentials.get("bearer_token") or decrypted_credentials.get("token")
                    if auth_scheme == "bearer" and token_value:
                        headers["Authorization"] = f"Bearer {token_value}"
                    elif auth_scheme == "api_key" and token_value:
                        headers["X-API-Key"] = token_value
                    elif auth_scheme == "basic" and decrypted_credentials.get("username"):
                        import base64
                        basic = base64.b64encode(f"{decrypted_credentials['username']}:{decrypted_credentials.get('password', '')}".encode()).decode()
                        headers["Authorization"] = f"Basic {basic}"

                    resp = httpx.post(
                        base_url,
                        json={"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "DAAN6-Test", "version": "1.0.0"}}},
                        headers=headers,
                        timeout=15.0,
                        verify=ssl_ctx,
                    )
                    latency = int((_time.time() - start) * 1000)

                    # If 401 with api_key, retry as Bearer (many services accept both)
                    if resp.status_code == 401 and auth_scheme == "api_key" and token_value:
                        headers["Authorization"] = f"Bearer {token_value}"
                        if "X-API-Key" in headers:
                            del headers["X-API-Key"]
                        resp = httpx.post(
                            base_url,
                            json={"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "DAAN6-Test", "version": "1.0.0"}}},
                            headers=headers,
                            timeout=15.0,
                            verify=ssl_ctx,
                        )
                        latency = int((_time.time() - start) * 1000)
                        if resp.status_code == 200:
                            auth_scheme = "bearer"

                    if resp.status_code == 200:
                        registry_entry.status = RegistryStatus.VALIDATED
                        registry_entry.updated_at = datetime.now()
                        db.commit()
                        result = McpTestConnectionResult(
                            server_name=server_name, connected=True,
                            latency_ms=latency, message=f"Connected ({latency}ms)",
                            auth_method=auth_scheme,
                        )
                    else:
                        result = McpTestConnectionResult(
                            server_name=server_name, connected=False,
                            latency_ms=latency, message=f"HTTP {resp.status_code}: {resp.text[:200]}",
                            auth_method=auth_scheme,
                        )
                except Exception as e:
                    result = McpTestConnectionResult(
                        server_name=server_name, connected=False,
                        latency_ms=int((_time.time() - start) * 1000),
                        message=str(e)[:300], auth_method=auth_scheme,
                    )
            elif registry_entry and registry_entry.command:
                # Prefer DB env_mapping over YAML-only resolve_as_env (YAML has no entry for DB-only servers)
                required_creds_meta = registry_entry.required_credentials or {}
                credentials_env: dict[str, str] = {}
                for field, value in decrypted_credentials.items():
                    meta = required_creds_meta.get(field) or {}
                    env_name = meta.get("env_mapping") or field.upper()
                    credentials_env[env_name] = str(value)
                result = _test_dynamic_stdio_server(server_name, registry_entry, credentials_env)

        # Update validation status on the user's own config (if exists)
        user_config = db.query(UserMcpConfig).filter(
            and_(
                UserMcpConfig.user_id == current_user.id,
                UserMcpConfig.mcp_server_name == server_name,
                UserMcpConfig.is_global_default == False,
                UserMcpConfig.is_active == True,
            )
        ).first()
        if user_config:
            user_config.validation_status = (
                ValidationStatus.VALID if result.connected else ValidationStatus.CONNECTION_FAILED
            )
            user_config.last_validation_at = datetime.now()
            db.commit()

        # On successful connection, update registry status to VALIDATED
        if result.connected:
            registry_entry = db.query(McpServerRegistry).filter(
                McpServerRegistry.server_name == server_name,
                (McpServerRegistry.created_by_user_id == current_user.id)
                | (McpServerRegistry.is_global == True),
            ).first()
            if registry_entry and registry_entry.status != RegistryStatus.VALIDATED:
                registry_entry.status = RegistryStatus.VALIDATED
                registry_entry.updated_at = datetime.now()
                db.commit()

        return McpTestConnectionResult(
            server_name=server_name,
            connected=result.connected,
            latency_ms=result.latency_ms,
            message=result.message,
            auth_method=result.auth_method,
            server_info=result.server_info,
        )

    except DAANException as e:
        raise HTTPException(status_code=_mcp_http_status(e), detail=e.to_dict())
    except Exception as e:
        return McpTestConnectionResult(
            server_name=server_name,
            connected=False,
            latency_ms=0,
            message=str(e)[:300],
            auth_method="unknown",
        )


@router.post("/credentials/test-connection", response_model=McpTestConnectionResult)
def test_mcp_connection_inline(
    request: McpTestConnectionRequest,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> McpTestConnectionResult:
    """Test connectivity with inline credentials (pre-save, not persisted)."""
    try:
        from daan.mcp_servers.core.connection_tester import test_connection

        result = test_connection(request.server_name, request.credentials)

        # If YAML tester fails, try direct HTTP for DB-registered servers
        if not result.connected and _should_use_dynamic_registry_fallback(result.message):
            registry_entry = db.query(McpServerRegistry).filter(
                McpServerRegistry.server_name == request.server_name,
                (McpServerRegistry.created_by_user_id == current_user.id)
                | (McpServerRegistry.is_global == True),
            ).first()
            if registry_entry and registry_entry.base_url:
                import time
                import httpx
                import ssl
                base_url = (registry_entry.base_url or "").strip()
                auth_scheme = registry_entry.auth_scheme.value if registry_entry.auth_scheme else "none"
                start = time.time()
                headers = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
                token_value = request.credentials.get("access_token") or request.credentials.get("api_key") or request.credentials.get("bearer_token") or request.credentials.get("token")
                if auth_scheme == "bearer" and token_value:
                    headers["Authorization"] = f"Bearer {token_value}"
                elif auth_scheme == "api_key" and token_value:
                    headers["X-API-Key"] = token_value
                elif auth_scheme == "basic" and request.credentials.get("username"):
                    import base64
                    basic = base64.b64encode(f"{request.credentials['username']}:{request.credentials.get('password', '')}".encode()).decode()
                    headers["Authorization"] = f"Basic {basic}"
                try:
                    ssl_ctx = ssl.create_default_context()
                    resp = httpx.post(
                        base_url,
                        json={"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "DAAN6-Test", "version": "1.0.0"}}},
                        headers=headers,
                        timeout=15.0,
                        verify=ssl_ctx,
                    )
                    latency = int((time.time() - start) * 1000)
                    if resp.status_code == 200:
                        return McpTestConnectionResult(
                            server_name=request.server_name, connected=True,
                            latency_ms=latency, message=f"Connected ({latency}ms)",
                            auth_method=auth_scheme,
                        )
                    else:
                        return McpTestConnectionResult(
                            server_name=request.server_name, connected=False,
                            latency_ms=latency, message=f"HTTP {resp.status_code}: {resp.text[:200]}",
                            auth_method=auth_scheme,
                        )
                except Exception as e:
                    return McpTestConnectionResult(
                        server_name=request.server_name, connected=False,
                        latency_ms=int((time.time() - start) * 1000),
                        message=str(e)[:300], auth_method=auth_scheme,
                    )
            elif registry_entry and registry_entry.command:
                # stdio DB-registered server: map credential fields to env var names then spawn
                required_creds_meta = registry_entry.required_credentials or {}
                credentials_env: dict[str, str] = {}
                for field, value in request.credentials.items():
                    meta = required_creds_meta.get(field) or {}
                    # use registry-declared env_mapping; fall back to uppercasing the field name
                    env_name = meta.get("env_mapping") or field.upper()
                    credentials_env[env_name] = str(value)
                result = _test_dynamic_stdio_server(request.server_name, registry_entry, credentials_env)
                return McpTestConnectionResult(
                    server_name=request.server_name,
                    connected=result.connected,
                    latency_ms=result.latency_ms,
                    message=result.message,
                    auth_method=result.auth_method,
                    server_info=result.server_info,
                )

        return McpTestConnectionResult(
            server_name=request.server_name,
            connected=result.connected,
            latency_ms=result.latency_ms,
            message=result.message,
            auth_method=result.auth_method,
            server_info=result.server_info,
        )

    except Exception as e:
        return McpTestConnectionResult(
            server_name=request.server_name,
            connected=False,
            latency_ms=0,
            message=str(e)[:300],
            auth_method="unknown",
        )


@router.post("/servers/{server_name}/tools", response_model=McpToolsListResponse)
async def list_mcp_server_tools(
    server_name: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> McpToolsListResponse:
    """Spawn an MCP server subprocess and list its registered tools."""
    import asyncio
    import logging

    logger = logging.getLogger(__name__)

    try:
        from daan.mcp_servers.core.mcp_toolset_provider import get_mcp_toolset

        server_name = server_name.strip("[]").strip()

        # Resolve credentials so YAML-registered stdio servers get their auth env vars
        credentials_env: dict[str, str] | None = None
        try:
            credentials_env = CredentialResolver(db, current_user.id).resolve_as_env(server_name)
        except DAANException:
            credentials_env = None

        toolsets = get_mcp_toolset(server_name, credentials_env=credentials_env)
        if not toolsets:
            # Fallback: try listing tools via direct HTTP for DB-registered servers
            registry_entry = db.query(McpServerRegistry).filter(
                McpServerRegistry.server_name == server_name,
                (McpServerRegistry.created_by_user_id == current_user.id)
                | (McpServerRegistry.is_global == True),
            ).first()
            if registry_entry and registry_entry.base_url:
                import ssl
                import httpx
                base_url = (registry_entry.base_url or "").strip()
                headers = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
                # Resolve credentials for auth
                try:
                    resolver = CredentialResolver(db, current_user.id)
                    creds = resolver.resolve(server_name)
                    auth_scheme = registry_entry.auth_scheme.value if registry_entry.auth_scheme else "none"
                    token_value = creds.get("access_token") or creds.get("api_key") or creds.get("bearer_token") or creds.get("token")
                    if auth_scheme == "bearer" and token_value:
                        headers["Authorization"] = f"Bearer {token_value}"
                    elif auth_scheme == "api_key" and token_value:
                        headers["X-API-Key"] = token_value
                except Exception:
                    pass

                ssl_ctx = ssl.create_default_context()
                # MCP handshake: initialize → notifications/initialized → tools/list
                try:
                    init_resp = httpx.post(base_url, json={"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "DAAN6", "version": "1.0.0"}}}, headers=headers, timeout=15.0, verify=ssl_ctx)
                    if init_resp.status_code != 200:
                        return McpToolsListResponse(server_name=server_name, connected=False, tools=[], tool_count=0, error=f"HTTP {init_resp.status_code}: {init_resp.text[:200]}")
                    # Capture session ID if returned
                    session_id = init_resp.headers.get("mcp-session-id") or init_resp.headers.get("Mcp-Session-Id")
                    if session_id:
                        headers["Mcp-Session-Id"] = session_id
                except Exception as e:
                    return McpToolsListResponse(server_name=server_name, connected=False, tools=[], tool_count=0, error=str(e)[:300])

                # Send initialized notification (required by MCP protocol before calling methods)
                try:
                    httpx.post(base_url, json={"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}}, headers=headers, timeout=10.0, verify=ssl_ctx)
                except Exception:
                    pass

                # Now list tools
                try:
                    tools_resp = httpx.post(base_url, json={"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}, headers=headers, timeout=15.0, verify=ssl_ctx)
                    if tools_resp.status_code == 200:
                        import json as _json_mod
                        resp_text = tools_resp.text.strip()
                        if not resp_text:
                            return McpToolsListResponse(server_name=server_name, connected=False, tools=[], tool_count=0, error="Empty response from tools/list")
                        content_type = tools_resp.headers.get("content-type", "")
                        if "text/event-stream" in content_type:
                            # SSE format: extract JSON-RPC payload from "data:" lines
                            data = None
                            for sse_line in resp_text.splitlines():
                                if sse_line.startswith("data:"):
                                    payload = sse_line[5:].strip()
                                    if not payload:
                                        continue
                                    try:
                                        parsed = _json_mod.loads(payload)
                                        if isinstance(parsed, dict) and ("result" in parsed or "error" in parsed):
                                            data = parsed
                                            break
                                    except (ValueError, _json_mod.JSONDecodeError):
                                        continue
                            if not data:
                                return McpToolsListResponse(server_name=server_name, connected=False, tools=[], tool_count=0, error="No valid JSON-RPC response in SSE stream")
                        else:
                            data = tools_resp.json()
                        tools = data.get("result", {}).get("tools", [])
                        tools_list = [McpToolInfo(name=t.get("name", ""), description=t.get("description", "")) for t in tools]
                        return McpToolsListResponse(server_name=server_name, connected=True, tools=tools_list, tool_count=len(tools_list))
                    else:
                        return McpToolsListResponse(server_name=server_name, connected=False, tools=[], tool_count=0, error=f"HTTP {tools_resp.status_code}: {tools_resp.text[:200]}")
                except Exception as e:
                    return McpToolsListResponse(server_name=server_name, connected=False, tools=[], tool_count=0, error=str(e)[:300])

            # Fallback for STDIO servers: spawn subprocess and list tools
            if registry_entry and registry_entry.command and not registry_entry.base_url:
                import json as _json
                cmd = registry_entry.command
                args = registry_entry.args or []
                env_vars = dict(registry_entry.env_vars or {})
                # Prefer DB env_mapping (YAML has no entry for DB-only servers)
                try:
                    resolver = CredentialResolver(db, current_user.id)
                    decrypted = resolver.resolve(server_name)
                    required_creds_meta = registry_entry.required_credentials or {}
                    for field, value in decrypted.items():
                        meta = required_creds_meta.get(field) or {}
                        env_name = meta.get("env_mapping") or field.upper()
                        env_vars[env_name] = str(value)
                except Exception:
                    pass

                import subprocess
                import os
                import shutil
                import sys
                import threading
                proc_env = {**os.environ, **{k: str(v) for k, v in env_vars.items()}}
                # Resolve command: shutil.which handles .cmd/.bat on Windows
                resolved_cmd = shutil.which(cmd, path=os.environ.get("PATH"))
                use_shell = sys.platform == "win32" and not resolved_cmd
                run_cmd = [resolved_cmd or cmd] + args
                proc = None
                stderr_chunks: list[str] = []

                def _drain_stderr(stream):
                    try:
                        for raw in iter(stream.readline, b""):
                            if not raw:
                                break
                            stderr_chunks.append(raw.decode(errors="ignore"))
                    except Exception:
                        pass

                def _stderr_tail(limit: int = 1500) -> str:
                    text = "".join(stderr_chunks).strip()
                    return text[-limit:] if len(text) > limit else text

                def _fail(msg: str) -> McpToolsListResponse:
                    tail = _stderr_tail()
                    full = f"{msg} | stderr: {tail}" if tail else msg
                    return McpToolsListResponse(
                        server_name=server_name, connected=False, tools=[], tool_count=0, error=full[:1500],
                    )

                try:
                    proc = subprocess.Popen(
                        run_cmd if not use_shell else " ".join(run_cmd),
                        stdin=subprocess.PIPE,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        env=proc_env,
                        shell=use_shell,
                    )
                    threading.Thread(target=_drain_stderr, args=(proc.stderr,), daemon=True).start()

                    def _send(payload: dict) -> str | None:
                        try:
                            proc.stdin.write((_json.dumps(payload) + "\n").encode())
                            proc.stdin.flush()
                            return None
                        except BrokenPipeError:
                            return "child process exited before request could be sent (BrokenPipe)"
                        except Exception as exc:
                            return f"failed to write to child stdin: {exc}"

                    # Read JSON-RPC responses by id, skipping non-JSON log lines written to stdout.
                    # Uses a wall-clock deadline so a hung child cannot stall the endpoint.
                    def _read_json_response(target_id, deadline: float, max_lines: int = 500):
                        import time as _time
                        for _ in range(max_lines):
                            if _time.time() > deadline:
                                return None
                            raw = proc.stdout.readline()
                            if not raw:
                                return None
                            line = raw.decode(errors="ignore").strip()
                            if not line:
                                continue
                            try:
                                obj = _json.loads(line)
                            except Exception:
                                continue
                            if isinstance(obj, dict) and obj.get("id") == target_id:
                                return obj
                        return None

                    import time as _time
                    handshake_deadline = _time.time() + 20.0

                    err = _send({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "DAAN6", "version": "1.0.0"}}})
                    if err:
                        return _fail(err)

                    init_obj = _read_json_response(1, handshake_deadline)
                    if not init_obj:
                        rc = proc.poll()
                        if rc is not None:
                            return _fail(f"child exited with code {rc} before initialize response")
                        return _fail("no initialize response from subprocess within 20s")

                    err = _send({"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}})
                    if err:
                        return _fail(err)

                    err = _send({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
                    if err:
                        return _fail(err)

                    tools_obj = _read_json_response(2, _time.time() + 20.0)

                    if tools_obj:
                        tools = tools_obj.get("result", {}).get("tools", [])
                        tools_list = [McpToolInfo(name=t.get("name", ""), description=t.get("description", "")) for t in tools]
                        return McpToolsListResponse(server_name=server_name, connected=True, tools=tools_list, tool_count=len(tools_list))
                    rc = proc.poll()
                    if rc is not None:
                        return _fail(f"child exited with code {rc} before tools/list response")
                    return _fail("no tools/list response from subprocess within 20s")
                except FileNotFoundError:
                    return _fail(f"Command '{cmd}' not found. Make sure {cmd} is installed and on PATH.")
                except Exception as e:
                    return _fail(str(e)[:300])
                finally:
                    if proc is not None:
                        try:
                            proc.terminate()
                            try:
                                proc.wait(timeout=2)
                            except Exception:
                                proc.kill()
                        except Exception:
                            pass

            return McpToolsListResponse(
                server_name=server_name,
                connected=False,
                tools=[],
                tool_count=0,
                error=f"Server '{server_name}' not found in registry",
            )

        tools_list: list[McpToolInfo] = []
        # Remote MCP servers (especially OAuth-based like Atlassian) may need more time
        timeout_seconds = 120.0 if server_name in ["atlassian-mcp", "azure-devops-mcp"] else 30.0
        
        for toolset in toolsets:
            try:
                tools = await asyncio.wait_for(toolset.get_tools(), timeout=timeout_seconds)
                for tool in tools:
                    tools_list.append(
                        McpToolInfo(
                            name=getattr(tool, "name", str(tool)),
                            description=getattr(tool, "description", "") or "",
                        )
                    )
            except asyncio.TimeoutError:
                logger.warning(f"Timeout waiting for tools from '{server_name}' (waited {timeout_seconds}s)")
                return McpToolsListResponse(
                    server_name=server_name,
                    connected=False,
                    tools=[],
                    tool_count=0,
                    error=f"MCP server did not respond within {timeout_seconds} seconds. OAuth-based servers may require authentication setup.",
                )
            except Exception as e:
                logger.error(f"Failed to get tools from '{server_name}': {e}")
                return McpToolsListResponse(
                    server_name=server_name,
                    connected=False,
                    tools=[],
                    tool_count=0,
                    error=str(e),
                )

        return McpToolsListResponse(
            server_name=server_name,
            connected=True,
            tools=tools_list,
            tool_count=len(tools_list),
        )

    except Exception as e:
        logger.error(f"Error listing tools for '{server_name}': {e}")
        return McpToolsListResponse(
            server_name=server_name,
            connected=False,
            tools=[],
            tool_count=0,
            error=str(e),
        )


@router.get("/servers", response_model=McpServerListResponse)
def list_mcp_servers(
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> McpServerListResponse:
    """List all available MCP servers from the registry."""
    try:
        validator = get_credential_validator()
        server_names = validator.list_servers()

        # Check which servers have global defaults in DB
        global_servers = set(
            row[0] for row in db.query(UserMcpConfig.mcp_server_name).filter(
                UserMcpConfig.is_global_default == True,
                UserMcpConfig.is_active == True,
                UserMcpConfig.deleted_at == None,
            ).all()
        )

        servers = []
        seen_names = set()
        for server_name in server_names:
            server_def = validator.get_server_definition(server_name)
            if server_def:
                seen_names.add(server_name)
                servers.append(
                    McpServerDefinition(
                        server_name=server_name,
                        display_name=server_def.get("display_name", server_name),
                        description=server_def.get("description", ""),
                        transport=server_def.get("transport", "stdio"),
                        required_fields=server_def.get("required_fields", []),
                        optional_fields=server_def.get("optional_fields", []),
                        field_descriptions=server_def.get("field_descriptions", {}),
                        validation_config=server_def.get("validation"),
                        connection_config=server_def.get("connection"),
                        resource_limits=server_def.get("resource_limits"),
                        has_global_credentials=server_name in global_servers,
                    )
                )

        # Include dynamically discovered servers from the DB registry.
        # Dedupe by (server_name, is_global) — a user's own row wins over a global row
        # with the same server_name so config-page lookups return the intended definition.
        db_servers = db.query(McpServerRegistry).filter(
            McpServerRegistry.server_name.notin_(seen_names),
            (McpServerRegistry.created_by_user_id == current_user.id)
            | (McpServerRegistry.is_global == True),
        ).all()

        db_servers_sorted = sorted(
            db_servers,
            key=lambda s: (s.created_by_user_id != current_user.id, s.id or 0),
        )
        db_seen: set[tuple[str, bool]] = set()
        for entry in db_servers_sorted:
            key = (entry.server_name, bool(entry.is_global))
            if key in db_seen:
                continue
            db_seen.add(key)
            req_creds = entry.required_credentials or {}
            servers.append(
                McpServerDefinition(
                    server_name=entry.server_name,
                    display_name=entry.display_name or entry.server_name,
                    description=entry.description or "",
                    transport=entry.transport.value if entry.transport else "stdio",
                    required_fields=list(req_creds.keys()),
                    optional_fields=[],
                    field_descriptions={k: v.get("description", k) if isinstance(v, dict) else str(v) for k, v in req_creds.items()},
                    has_global_credentials=entry.server_name in global_servers,
                    is_global=bool(entry.is_global),
                )
            )

        return McpServerListResponse(servers=servers, total=len(servers))

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error_code": "internal_error", "message": str(e)},
        )


@router.get("/servers/{server_name}", response_model=McpServerDefinition)
def get_mcp_server_definition(
    server_name: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[Session, Depends(get_db)],
) -> McpServerDefinition:
    """Get detailed definition of a specific MCP server."""
    try:
        validator = get_credential_validator()
        server_def = validator.get_server_definition(server_name)

        if not server_def:
            # Fallback to DB registry for dynamically discovered servers
            entry = db.query(McpServerRegistry).filter(
                McpServerRegistry.server_name == server_name,
                (McpServerRegistry.created_by_user_id == current_user.id)
                | (McpServerRegistry.is_global == True),
            ).first()
            if not entry:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail={
                        "error_code": "server_not_found",
                        "message": f"Server '{server_name}' not found in registry",
                    },
                )
            req_creds = entry.required_credentials or {}
            return McpServerDefinition(
                server_name=entry.server_name,
                display_name=entry.display_name or entry.server_name,
                description=entry.description or "",
                transport=entry.transport.value if entry.transport else "stdio",
                required_fields=list(req_creds.keys()),
                optional_fields=[],
                field_descriptions={k: v.get("description", k) if isinstance(v, dict) else str(v) for k, v in req_creds.items()},
            )

        return McpServerDefinition(
            server_name=server_name,
            display_name=server_def.get("display_name", server_name),
            description=server_def.get("description", ""),
            transport=server_def.get("transport", "stdio"),
            required_fields=server_def.get("required_fields", []),
            optional_fields=server_def.get("optional_fields", []),
            field_descriptions=server_def.get("field_descriptions", {}),
            validation_config=server_def.get("validation"),
            connection_config=server_def.get("connection"),
            resource_limits=server_def.get("resource_limits"),
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error_code": "internal_error", "message": str(e)},
        )


@router.get("/processes", response_model=list[McpProcessInfo])
def list_mcp_processes(
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> list[McpProcessInfo]:
    """List active MCP server processes for the current user.

    Returns:
        List of active MCP processes
    """
    try:
        manager = get_process_manager()
        processes = manager.get_user_processes(current_user.id)

        return [
            McpProcessInfo(
                process_id=proc.process_id,
                server_name=proc.server_name,
                state=proc.state.value,
                created_at=proc.created_at,
                last_accessed_at=proc.last_accessed_at,
                access_count=proc.access_count,
                uptime_seconds=proc.get_uptime(),
            )
            for proc in processes
        ]

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error_code": "internal_error", "message": str(e)},
        )


@router.get("/statistics", response_model=McpStatistics)
def get_mcp_statistics(
    _: Annotated[User, Depends(get_current_active_user)],
) -> McpStatistics:
    """Get MCP process manager statistics.

    Returns:
        Process manager statistics
    """
    try:
        manager = get_process_manager()
        stats = manager.get_statistics()

        return McpStatistics(**stats)

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error_code": "internal_error", "message": str(e)},
        )

# ═══════════════════════════════════════════════════════════════════════════════
# Utility helpers
# ═══════════════════════════════════════════════════════════════════════════════


def _format_display_name(server_name: str) -> str:
    """Format server name as Title Case: 'azure-devops-mcp' -> 'Azure Devops Mcp'."""
    return " ".join(word.capitalize() for word in server_name.split("-"))
