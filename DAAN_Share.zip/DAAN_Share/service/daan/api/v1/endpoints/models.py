"""LLM model discovery endpoints backed by the LiteLLM gateway."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException

from daan.core.dependencies import get_current_active_user
from daan.llm.llm_provider import (
    LLMProviderError,
    get_default_litellm_model_id,
    list_litellm_models,
)

router = APIRouter()


@router.get("/llm/models", response_model=list[dict])
def get_llm_models(
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> list[dict]:
    """Return LiteLLM-registered models (id, model_name, provider, mode)."""
    _ = current_user
    try:
        return list_litellm_models()
    except LLMProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.get("/llm/default-model", response_model=dict)
def get_default_llm_model(
    current_user: Annotated[object, Depends(get_current_active_user)],
) -> dict:
    """Return the configured default LiteLLM model id."""
    _ = current_user
    try:
        return {"id": get_default_litellm_model_id()}
    except LLMProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
