"""REST endpoints for MCP server discovery and registry management."""

import logging
from typing import Annotated

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from sqlalchemy import and_, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from daan.core.database import get_async_db
from daan.core.dependencies import get_current_active_user
from daan.models.mcp_registry import McpServerRegistry, RegistryStatus
from daan.models.user import User
from daan.schemas.mcp import (
    McpDiscoveryFileRequest,
    McpDiscoveryNpmRequest,
    McpDiscoveryResult,
    McpDiscoveryUrlRequest,
    McpRegistryEntryResponse,
    McpRegistryListResponse,
)
from daan.mcp_servers.core.mcp_discovery import McpDiscoveryError, McpDiscoveryManager, slugify_server_name

logger = logging.getLogger(__name__)
router = APIRouter()

# MCP Admin usernames - users who can create global servers
MCP_ADMIN_USERNAMES = {"mcp_admin"}


def _is_mcp_admin(user: User) -> bool:
    """Check if user is authorized to manage global MCP servers."""
    return getattr(user, "username", "").lower() in MCP_ADMIN_USERNAMES


def _require_mcp_admin(user: User):
    """Raise 403 if user is not an MCP admin."""
    if not _is_mcp_admin(user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error_code": "forbidden",
                "message": "MCP admin permission required for this operation",
            },
        )


@router.post(
    "/discover/url",
    response_model=McpDiscoveryResult,
    status_code=status.HTTP_200_OK,
)
async def discover_from_url(
    payload: McpDiscoveryUrlRequest,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_async_db)],
) -> McpDiscoveryResult:
    """Register MCP server from remote URL.

    Saves the server configuration to the registry without connecting.
    Use the test-connection endpoint to verify connectivity afterward.
    """
    if payload.is_global:
        _require_mcp_admin(current_user)

    discovery_service = McpDiscoveryManager(db)

    try:
        from urllib.parse import urlparse

        parsed = urlparse(payload.url.strip())
        if not parsed.scheme or not parsed.netloc:
            return McpDiscoveryResult(
                success=False,
                error="Invalid URL format",
                error_type="validation_error",
            )
        if parsed.scheme not in ("http", "https"):
            return McpDiscoveryResult(
                success=False,
                error="Only HTTP/HTTPS URLs are supported",
                error_type="validation_error",
            )

        # Derive server name: prefer user-supplied display_name so slug reflects intent
        # ("test mcp" -> "test-mcp"). Fall back to hostname+path when omitted.
        if payload.display_name:
            server_name = slugify_server_name(payload.display_name)
        else:
            domain = parsed.netloc.replace(".", "-")
            path = parsed.path.strip("/").replace("/", "-")
            server_name = f"{domain}-{path}" if path else domain
            server_name = slugify_server_name(server_name)
        server_name = server_name[:100]

        display_name = payload.display_name or parsed.netloc.split(".")[0].replace("-", " ").title()

        # Map auth_type to auth_scheme
        auth_scheme_map = {
            "none": "none",
            "api_key": "api_key",
            "bearer": "bearer",
            "basic": "basic",
            "custom_header": "api_key",
        }
        auth_scheme = auth_scheme_map.get(payload.auth_type, "none")

        # Build required_credentials from auth_type
        required_credentials = None
        if payload.auth_type == "bearer":
            required_credentials = {
                "access_token": {
                    "type": "string",
                    "description": "Bearer token",
                    "secret": True,
                }
            }
        elif payload.auth_type == "api_key":
            header_name = (payload.auth_credentials or {}).get("header_name", "X-API-Key")
            required_credentials = {
                "api_key": {
                    "type": "string",
                    "description": f"API Key (sent as {header_name})",
                    "env_mapping": "API_KEY",
                    "secret": True,
                }
            }
        elif payload.auth_type == "basic":
            required_credentials = {
                "username": {
                    "type": "string",
                    "description": "Username",
                },
                "password": {
                    "type": "string",
                    "description": "Password",
                    "secret": True,
                },
            }
        elif payload.auth_type == "custom_header":
            required_credentials = {
                "header_value": {
                    "type": "string",
                    "description": "Header value",
                    "secret": True,
                }
            }

        # Merge auth-derived credentials with user-defined env keys
        if payload.required_credentials:
            required_credentials = {**(required_credentials or {}), **payload.required_credentials}

        discovery_result = {
            "server_name": server_name,
            "display_name": display_name,
            "description": f"Remote MCP server at {parsed.netloc}",
            "transport": "http",
            "base_url": payload.url.strip(),
            "auth_scheme": auth_scheme,
            "required_credentials": required_credentials,
            "status": "discovered",
            "discovered_from": payload.url,
            "discovery_method": "url_registration",
        }

        registry_entry = await discovery_service.save_to_registry(
            discovery_result=discovery_result,
            user_id=current_user.id,
            is_global=payload.is_global,
        )

        return McpDiscoveryResult(
            success=True,
            server_name=registry_entry.server_name,
            display_name=registry_entry.display_name,
            description=registry_entry.description,
            transport=registry_entry.transport.value,
            auth_scheme=registry_entry.auth_scheme.value,
            status=registry_entry.status.value,
            registry_id=registry_entry.id,
        )

    except McpDiscoveryError as e:
        logger.warning(
            f"URL discovery failed for {payload.url}: {e}",
            extra={"user_id": current_user.id, "error_type": e.error_type},
        )
        return McpDiscoveryResult(
            success=False,
            error=str(e),
            error_type=e.error_type,
        )
    except Exception as e:
        logger.error(
            f"Failed to register URL server {payload.url}: {e}",
            exc_info=True,
            extra={"user_id": current_user.id},
        )
        return McpDiscoveryResult(
            success=False,
            error=f"Registration failed: {str(e)}",
            error_type="unknown",
        )


@router.post(
    "/discover/npm",
    response_model=McpDiscoveryResult,
    status_code=status.HTTP_200_OK,
)
async def discover_from_npm(
    payload: McpDiscoveryNpmRequest,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_async_db)],
) -> McpDiscoveryResult:
    """Discover MCP server from npm package.

    Queries npm registry for package metadata and registers the server.
    Note: Cannot introspect tools without running the server.

    Args:
        payload: Discovery request with npm package name
        current_user: Authenticated user
        db: Database session

    Returns:
        Discovery result with package metadata
    """
    # Check admin permission if registering as global
    if payload.is_global:
        _require_mcp_admin(current_user)

    discovery_service = McpDiscoveryManager(db)

    try:
        # Discover server from npm
        discovery_result = await discovery_service.discover_from_npm_package(
            package_name=payload.package_name,
            user_id=current_user.id,
        )

        # Override runner command if specified (e.g., 'uvx' for Python packages)
        if payload.runner_type and payload.runner_type in ('npx', 'uvx'):
            discovery_result["command"] = payload.runner_type

        # Override display name if provided
        if payload.display_name:
            discovery_result["display_name"] = payload.display_name
            # Slug from user-supplied name so URL/config identity matches what the user typed.
            slug = slugify_server_name(payload.display_name)
            if slug:
                discovery_result["server_name"] = slug

        # Merge custom args and env vars from payload
        if payload.custom_args:
            # Prepend custom args to default args
            base_args = discovery_result.get("args", [])
            discovery_result["args"] = payload.custom_args + base_args
        
        if payload.env_vars:
            discovery_result["env_vars"] = payload.env_vars
        
        if payload.required_credentials:
            discovery_result["required_credentials"] = payload.required_credentials

        # Save to registry
        registry_entry = await discovery_service.save_to_registry(
            discovery_result=discovery_result,
            user_id=current_user.id,
            is_global=payload.is_global,
        )

        # Build response
        return McpDiscoveryResult(
            success=True,
            server_name=registry_entry.server_name,
            display_name=registry_entry.display_name,
            description=registry_entry.description,
            transport=registry_entry.transport.value,
            auth_scheme=registry_entry.auth_scheme.value,
            status=registry_entry.status.value,
            registry_id=registry_entry.id,
        )

    except McpDiscoveryError as e:
        logger.warning(
            f"npm discovery failed for package {payload.package_name}: {e}",
            extra={"user_id": current_user.id, "error_type": e.error_type},
        )
        return McpDiscoveryResult(
            success=False,
            error=str(e),
            error_type=e.error_type,
        )
    except Exception as e:
        logger.error(
            f"Unexpected error during npm discovery: {e}",
            exc_info=True,
            extra={"user_id": current_user.id},
        )
        return McpDiscoveryResult(
            success=False,
            error=f"Discovery failed: {str(e)}",
            error_type="unknown",
        )
    finally:
        await discovery_service.close()


@router.post(
    "/discover/file",
    response_model=McpDiscoveryResult,
    status_code=status.HTTP_200_OK,
)
async def discover_from_file(
    file: UploadFile = File(..., description="Python MCP server file"),
    server_name: str = Form(..., min_length=1, max_length=100),
    description: str | None = Form(None),
    custom_args: str | None = Form(None, description="JSON array of custom args"),
    env_vars: str | None = Form(None, description="JSON object of env vars"),
    required_credentials: str | None = Form(None, description="JSON object of credential definitions"),
    is_global: bool = Form(False),
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_async_db),
) -> McpDiscoveryResult:
    """Register custom uploaded Python file as MCP server.

    Args:
        file: Uploaded Python file
        server_name: Name for the server
        description: Optional description
        is_global: Register as global server (MCP admin only)
        current_user: Authenticated user
        db: Database session

    Returns:
        Discovery result with registration status
    """
    # Check admin permission if registering as global
    if is_global:
        _require_mcp_admin(current_user)

    # Validate file type
    if not file.filename or not file.filename.endswith(".py"):
        return McpDiscoveryResult(
            success=False,
            error="Only Python (.py) files are supported",
            error_type="validation_error",
        )

    discovery_service = McpDiscoveryManager(db)

    try:
        # Read file content
        file_content = await file.read()

        # Parse JSON strings if provided
        import json
        parsed_custom_args = None
        parsed_env_vars = None
        parsed_required_credentials = None
        
        if custom_args:
            try:
                parsed_custom_args = json.loads(custom_args)
            except json.JSONDecodeError:
                return McpDiscoveryResult(
                    success=False,
                    error="Invalid JSON format for custom_args",
                    error_type="validation_error",
                )
        
        if env_vars:
            try:
                parsed_env_vars = json.loads(env_vars)
            except json.JSONDecodeError:
                return McpDiscoveryResult(
                    success=False,
                    error="Invalid JSON format for env_vars",
                    error_type="validation_error",
                )
        
        if required_credentials:
            try:
                parsed_required_credentials = json.loads(required_credentials)
            except json.JSONDecodeError:
                return McpDiscoveryResult(
                    success=False,
                    error="Invalid JSON format for required_credentials",
                    error_type="validation_error",
                )

        # Register custom file server
        discovery_result = await discovery_service.register_custom_file_server(
            file_content=file_content,
            server_name=server_name,
            user_id=current_user.id,
            description=description,
        )

        # Merge custom configuration from payload
        if parsed_custom_args:
            base_args = discovery_result.get("args", [])
            discovery_result["args"] = parsed_custom_args + base_args
        
        if parsed_env_vars:
            discovery_result["env_vars"] = parsed_env_vars
        
        if parsed_required_credentials:
            discovery_result["required_credentials"] = parsed_required_credentials

        # Save to registry
        registry_entry = await discovery_service.save_to_registry(
            discovery_result=discovery_result,
            user_id=current_user.id,
            is_global=is_global,
        )

        # Build response
        return McpDiscoveryResult(
            success=True,
            server_name=registry_entry.server_name,
            display_name=registry_entry.display_name,
            description=registry_entry.description,
            transport=registry_entry.transport.value,
            auth_scheme=registry_entry.auth_scheme.value,
            status=registry_entry.status.value,
            registry_id=registry_entry.id,
        )

    except McpDiscoveryError as e:
        logger.warning(
            f"File upload failed for {file.filename}: {e}",
            extra={"user_id": current_user.id, "error_type": e.error_type},
        )
        return McpDiscoveryResult(
            success=False,
            error=str(e),
            error_type=e.error_type,
        )
    except Exception as e:
        logger.error(
            f"Unexpected error during file upload: {e}",
            exc_info=True,
            extra={"user_id": current_user.id},
        )
        return McpDiscoveryResult(
            success=False,
            error=f"File registration failed: {str(e)}",
            error_type="unknown",
        )
    finally:
        await discovery_service.close()


@router.get(
    "/registry",
    response_model=McpRegistryListResponse,
    status_code=status.HTTP_200_OK,
)
async def list_registry_servers(
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_async_db)],
    include_global: bool = True,
    category: str | None = None,
) -> McpRegistryListResponse:
    """List all MCP servers available to the user.

    Returns personal servers and optionally global servers.

    Args:
        current_user: Authenticated user
        db: Database session
        include_global: Include global servers in results
        category: Optional category filter

    Returns:
        List of registry entries
    """
    # Build query
    conditions = []

    # Personal servers or global servers
    if include_global:
        conditions.append(
            or_(
                McpServerRegistry.created_by_user_id == current_user.id,
                McpServerRegistry.is_global == True,
            )
        )
    else:
        conditions.append(McpServerRegistry.created_by_user_id == current_user.id)

    # Category filter
    if category:
        conditions.append(McpServerRegistry.category == category)

    # Execute query
    stmt = select(McpServerRegistry).where(and_(*conditions))
    result = await db.execute(stmt)
    servers = result.scalars().all()

    # Count personal vs global
    personal_count = sum(
        1 for s in servers if s.created_by_user_id == current_user.id
    )
    global_count = sum(1 for s in servers if s.is_global)

    # Build response
    server_responses = [
        McpRegistryEntryResponse(
            id=s.id,
            server_name=s.server_name,
            display_name=s.display_name,
            description=s.description,
            transport=s.transport.value,
            base_url=s.base_url,
            npm_package=s.npm_package,
            command=s.command,
            auth_scheme=s.auth_scheme.value,
            category=s.category,
            status=s.status.value,
            is_global=s.is_global,
            is_public=s.is_public,
            created_by_user_id=s.created_by_user_id,
            tools_count=len(s.available_tools or []),
            resources_count=len(s.available_resources or []),
            prompts_count=len(s.available_prompts or []),
            created_at=s.created_at,
            updated_at=s.updated_at,
        )
        for s in servers
    ]

    return McpRegistryListResponse(
        servers=server_responses,
        total=len(server_responses),
        personal_count=personal_count,
        global_count=global_count,
    )


@router.get(
    "/registry/{registry_id}",
    response_model=McpRegistryEntryResponse,
    status_code=status.HTTP_200_OK,
)
async def get_registry_server(
    registry_id: int,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_async_db)],
) -> McpRegistryEntryResponse:
    """Get details of a specific registry entry.

    Args:
        registry_id: Registry entry ID
        current_user: Authenticated user
        db: Database session

    Returns:
        Registry entry details
    """
    # Query registry entry
    stmt = select(McpServerRegistry).where(McpServerRegistry.id == registry_id)
    result = await db.execute(stmt)
    server = result.scalar_one_or_none()

    if not server:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Registry entry not found",
        )

    # Check access: user must own it or it must be global
    if server.created_by_user_id != current_user.id and not server.is_global:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied to this registry entry",
        )

    # Build response
    return McpRegistryEntryResponse(
        id=server.id,
        server_name=server.server_name,
        display_name=server.display_name,
        description=server.description,
        transport=server.transport.value,
        base_url=server.base_url,
        npm_package=server.npm_package,
        command=server.command,
        auth_scheme=server.auth_scheme.value,
        category=server.category,
        status=server.status.value,
        is_global=server.is_global,
        is_public=server.is_public,
        created_by_user_id=server.created_by_user_id,
        tools_count=len(server.available_tools or []),
        resources_count=len(server.available_resources or []),
        prompts_count=len(server.available_prompts or []),
        created_at=server.created_at,
        updated_at=server.updated_at,
    )


@router.delete(
    "/registry/{registry_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_registry_server(
    registry_id: int,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_async_db)],
) -> None:
    """Delete a registry entry.

    Regular users can only delete their own entries.
    MCP admins can delete any entry.

    Args:
        registry_id: Registry entry ID
        current_user: Authenticated user
        db: Database session
    """
    # Query registry entry
    stmt = select(McpServerRegistry).where(McpServerRegistry.id == registry_id)
    result = await db.execute(stmt)
    server = result.scalar_one_or_none()

    if not server:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Registry entry not found",
        )

    # Check permission
    is_owner = server.created_by_user_id == current_user.id
    is_admin = _is_mcp_admin(current_user)

    if not is_owner and not is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only delete your own registry entries",
        )

    # Global servers require MCP admin
    if server.is_global and not is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only MCP admins can delete global servers",
        )

    # Delete
    await db.delete(server)
    await db.commit()
