"""UseCase endpoints — read-only use case and archetype configuration data."""

import csv
import io
import json
import zipfile
from typing import Annotated, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from daan.core.database import get_db
from daan.core.dependencies import get_current_active_user
from daan.models.user import User
from daan.schemas.archetype import ArchetypeRolesResponse
from daan.agents.dag_validator import validate_dag, validate_stage_dag
from daan.schemas.usecase import (
    CategoryCreateRequest,
    PaginatedUseCasesResponse,
    UploadedAgentSpec,
    UploadedUseCaseSpec,
    UseCaseCreateRequest,
    UseCaseCreateResponse,
    UseCaseDetailResponse,
    UseCaseDuplicateRequest,
    UseCaseResponse,
    UseCaseUpdateRequest,
    UseCaseUploadResponse,
    UsecaseInputSuggestionsRequest,
    UsecaseInputSuggestionsResponse,
)
from daan.usecases.usecase_service import (
    add_category,
    create_usecase,
    delete_usecase,
    duplicate_usecase,
    get_usecase_details,
    get_usecase_input_suggestions,
    list_agents_for_usecase_db,
    list_all_usecases_paginated,
    list_archetype_roles,
    list_distinct_categories,
    list_usecases,
    update_usecase,
    unmap_agent_from_usecase,
)

router = APIRouter()


class _DagAgentItem(BaseModel):
    client_node_id: Optional[str] = None
    agent_id: str
    agent_type: str
    depend_on: Optional[str] = None
    depends_on: Optional[str] = None
    copy_from_agent_id: Optional[str] = None
    execution_order: Optional[int] = None


class _ValidateDagRequest(BaseModel):
    dag: Optional[str] = None
    agents: list[_DagAgentItem]


@router.post("/usecases/validate-dag")
def validate_dag_endpoint(request: _ValidateDagRequest) -> dict:
    """Stateless DAG validation for the workflow builder.

    Rules enforced:
    1. All dynamic_agents must precede all action_agents.
    2. Action agents must appear only after at least one upstream stage.

    ``depend_on`` / ``depends_on`` are still accepted in the payload for
    backward compatibility, but the validator treats the submitted DAG as the
    canonical orchestration source and does not enforce dependency-field links.
    """
    try:
        payload = [a.model_dump() for a in request.agents]
        if request.dag:
            validate_stage_dag(request.dag, payload)
        else:
            validate_dag(payload)
        return {"valid": True}
    except ValueError as exc:
        return {"valid": False, "error": str(exc)}


@router.get("/usecases/categories", response_model=list[str])
def list_categories_route(
    current_user: Annotated[object, Depends(get_current_active_user)],
    archetype: Optional[str] = Query(None, description="Deprecated; kept for compatibility and ignored"),
) -> list[str]:
    """Return the shared category (skill) catalog, identical for every portfolio."""
    _ = current_user
    _ = archetype
    return list_distinct_categories()


@router.post("/usecases/categories", response_model=str, status_code=status.HTTP_201_CREATED)
def add_category_route(
    request: CategoryCreateRequest,
    current_user: Annotated[User, Depends(get_current_active_user)],
) -> str:
    """Register a new category in the shared catalog."""
    _ = current_user
    try:
        return add_category(request.name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/usecases", response_model=UseCaseCreateResponse, status_code=status.HTTP_201_CREATED)
def create_usecase_route(
    request: UseCaseCreateRequest,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Session = Depends(get_db),
) -> UseCaseCreateResponse:
    """Create a new use case tile for an archetype."""
    try:
        return UseCaseCreateResponse(**create_usecase(db, current_user, request))
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/usecases/{usecase_id}/duplicate", response_model=UseCaseCreateResponse, status_code=status.HTTP_201_CREATED)
def duplicate_usecase_route(
    usecase_id: str,
    request: UseCaseDuplicateRequest,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Session = Depends(get_db),
) -> UseCaseCreateResponse:
    """Duplicate an existing use case (with copied agents/prompts) into a target archetype."""
    try:
        return UseCaseCreateResponse(**duplicate_usecase(db, current_user, usecase_id, request))
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


# GET /usecases-all?page={page}&page_size={size}&premium_mode={mode} — All use cases across every archetype (paginated)
@router.get("/usecases-all", response_model=PaginatedUseCasesResponse)
def list_all_usecases_route(
    current_user: Annotated[object, Depends(get_current_active_user)],
    page: int | None = Query(None, ge=1, description="Optional 1-based page number."),
    page_size: int | None = Query(None, ge=1, le=600, description="Optional page size (max 600). Omit to return all use cases."),
    premium_mode: Optional[str] = Query(
        None,
        description="Optional tier filter: 'premium' or 'non_premium'. Omit for all tiers.",
    ),
    search: Optional[str] = Query(
        None,
        description="Optional case-insensitive substring to filter by name, task, role, category, or archetype.",
    ),
) -> PaginatedUseCasesResponse:
    """List all use cases across every archetype, optionally paginated."""
    _ = current_user
    try:
        return PaginatedUseCasesResponse(**list_all_usecases_paginated(page, page_size, premium_mode, search))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


# GET /usecases?archetype={archetype}&premium_mode={mode} — List usecases for an archetype
@router.get("/usecases", response_model=list[UseCaseResponse])
def list_usecases_route(
    current_user: Annotated[object, Depends(get_current_active_user)],
    archetype: str = Query(None),
    premium_mode: str = Query(
        "non_premium",
        description="Tier filter: 'non_premium' (default) returns only non-premium use cases, 'premium' returns only premium use cases.",
    ),
) -> list[UseCaseResponse]:
    """List usecases for an archetype, filtered by premium tier."""
    _ = current_user
    if archetype:
        try:
            return [UseCaseResponse(**usecase) for usecase in list_usecases(archetype, premium_mode)]
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
    return []


_CSV_REQUIRED_COLS = {
    "agent_name", "agent_type", "role", "inputs", "output",
    "actions", "depends_on", "mcp_tools", "local_tools", "prompt",
}


def _parse_csv_bytes(content: bytes) -> dict:
    text = content.decode("utf-8-sig")  # utf-8-sig strips Excel BOM
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        raise HTTPException(status_code=400, detail="CSV file is empty or has no header row.")
    headers = {h.strip().lower() for h in reader.fieldnames if h}
    missing = _CSV_REQUIRED_COLS - headers
    if missing:
        raise HTTPException(
            status_code=400,
            detail=f"CSV missing required columns: {', '.join(sorted(missing))}",
        )
    rows = list(reader)
    if not rows:
        raise HTTPException(status_code=400, detail="CSV has no data rows.")
    first = rows[0]
    usecase: dict = {
        "name": (first.get("usecase_name") or "").strip(),
        "task": (first.get("usecase_task") or "").strip(),
        "role": (first.get("usecase_role") or "").strip(),
        "category": (first.get("usecase_category") or "").strip(),
    }
    agents = [
        {
            "agent_name":  (row.get("agent_name")  or "").strip(),
            "agent_type":  (row.get("agent_type")  or "action_agent").strip() or "action_agent",
            "role":        (row.get("role")        or "").strip(),
            "inputs":      (row.get("inputs")      or "—").strip() or "—",
            "output":      (row.get("output")      or "—").strip() or "—",
            "actions":     (row.get("actions")     or "—").strip() or "—",
            "depends_on":  (row.get("depends_on")  or "—").strip() or "—",
            "mcp_tools":   (row.get("mcp_tools")   or "—").strip() or "—",
            "local_tools": (row.get("local_tools") or "—").strip() or "—",
            "prompt":      (row.get("prompt")      or "").strip(),
        }
        for row in rows
    ]
    return {"useCase": usecase, "agents": agents}


def _parse_zip_bytes(content: bytes) -> dict:
    try:
        zf = zipfile.ZipFile(io.BytesIO(content))
    except zipfile.BadZipFile as exc:
        raise HTTPException(status_code=400, detail="Invalid or corrupt ZIP file.") from exc
    json_names = [
        n for n in zf.namelist()
        if n.lower().endswith(".json") and not n.startswith("__MACOSX/")
    ]
    if not json_names:
        raise HTTPException(status_code=400, detail="ZIP must contain exactly one .json spec file.")
    if len(json_names) > 1:
        raise HTTPException(
            status_code=400,
            detail=f"ZIP contains multiple .json files ({json_names}). Include exactly one.",
        )
    try:
        inner = json.loads(zf.read(json_names[0]))
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail=f"Invalid JSON inside ZIP: {exc.msg}") from exc
    if not isinstance(inner, dict):
        raise HTTPException(status_code=400, detail="JSON inside ZIP must be a root object.")
    return inner


# POST /usecases/upload — literal route, MUST be before /usecases/{usecase_id}
# so FastAPI does not match "upload" as a path parameter and return 405.
@router.post("/usecases/upload", response_model=UseCaseUploadResponse)
async def upload_usecase_spec(
    current_user: Annotated[User, Depends(get_current_active_user)],
    file: UploadFile = File(...),
) -> UseCaseUploadResponse:
    """Parse and validate an uploaded spec file (.json, .csv, or .zip). No DB writes — parse-and-return only."""
    _ = current_user

    MAX_BYTES = 1 * 1024 * 1024
    content = await file.read(MAX_BYTES + 1)
    if len(content) > MAX_BYTES:
        raise HTTPException(status_code=400, detail="File too large. Maximum allowed size is 1 MB.")

    ext = (file.filename or "").rsplit(".", 1)[-1].lower()
    if ext == "csv":
        data = _parse_csv_bytes(content)
    elif ext == "zip":
        data = _parse_zip_bytes(content)
    else:
        try:
            data = json.loads(content)
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=400, detail=f"Invalid JSON file: {exc.msg}") from exc
        if not isinstance(data, dict):
            raise HTTPException(status_code=400, detail="JSON root must be an object.")

    raw_uc = data.get("useCase") or data.get("usecase")
    if not isinstance(raw_uc, dict):
        raise HTTPException(
            status_code=400,
            detail='Missing or invalid "useCase" field. Expected keys: usecaseid, name, task, role, category.',
        )

    raw_agents = data.get("agents")
    if not isinstance(raw_agents, list):
        raise HTTPException(
            status_code=400,
            detail='Missing or invalid "agents" field. Expected an array of agent objects.',
        )

    # usecaseid is always stripped — the real ID is auto-generated by _generate_next_usecase_id
    # when the use case is first persisted to the DB.
    usecase_spec = UploadedUseCaseSpec(
        usecaseid="",
        name=str(raw_uc.get("name") or ""),
        task=str(raw_uc.get("task") or ""),
        role=str(raw_uc.get("role") or ""),
        category=str(raw_uc.get("category") or ""),
    )

    # Build a remap table: whatever agent_id the JSON author wrote → that agent's name.
    # Using agent names in depends_on makes the dependency immediately readable in the UI
    # and matches the format the canvas already uses to draw edges (it resolves by name).
    # The agent_id field itself still gets a collision-free positional placeholder (UPLOAD_TEMP_n).
    # If an agent has no name we fall back to the positional placeholder so the graph is preserved.
    id_remap: dict[str, str] = {}
    for idx, a in enumerate(raw_agents):
        if not isinstance(a, dict):
            raise HTTPException(status_code=400, detail=f"agents[{idx}] must be an object.")
        raw_id = str(a.get("agent_id") or "").strip()
        agent_name = str(a.get("agent_name") or "").strip()
        if raw_id:
            # Prefer the human-readable name; fall back to positional temp ID
            id_remap[raw_id] = agent_name if agent_name else f"UPLOAD_TEMP_{idx + 1}"

    def _rewrite_depends_on(raw_depends: str) -> str:
        """Replace any hardcoded agent_id token in depends_on with the agent's name."""
        if not raw_depends or raw_depends == "\u2014":
            return "\u2014"
        tokens = [t.strip() for t in raw_depends.split(",") if t.strip()]
        rewritten = [id_remap.get(t, t) for t in tokens]
        return ", ".join(rewritten)

    agent_specs: list[UploadedAgentSpec] = []
    for idx, a in enumerate(raw_agents):
        temp_id = f"UPLOAD_TEMP_{idx + 1}"
        raw_depends = str(a.get("depends_on") or "\u2014")
        agent_specs.append(
            UploadedAgentSpec(
                id=idx + 1,
                # agent_id: positional temp ID — never the hardcoded value from the JSON
                agent_id=temp_id,
                # prompt_id: always None — the real DB PK is assigned after GeneratedPrompt insert
                prompt_id=None,
                archetype=str(a.get("archetype") or ""),
                # use_case_id: always empty — the real ID is auto-generated when the UC is created
                use_case_id="",
                role=str(a.get("role") or ""),
                agent_name=str(a.get("agent_name") or ""),
                agent_type=str(a.get("agent_type") or "action_agent"),
                inputs=str(a.get("inputs") or "\u2014"),
                output=str(a.get("output") or "\u2014"),
                actions=str(a.get("actions") or "\u2014"),
                depends_on=_rewrite_depends_on(raw_depends),
                mcp_tools=str(a.get("mcp_tools") or "\u2014"),
                local_tools=str(a.get("local_tools") or "\u2014"),
                prompt=str(a.get("prompt") or ""),
            )
        )

    return UseCaseUploadResponse(useCase=usecase_spec, agents=agent_specs)


# GET /usecases/{usecase_id} — Get usecase details (optionally include agents)
@router.get("/usecases/{usecase_id}", response_model=UseCaseDetailResponse)
def get_usecase_detail_route(
    current_user: Annotated[object, Depends(get_current_active_user)],
    usecase_id: str,
    archetype: str = Query(None),
) -> UseCaseDetailResponse:
    """Get usecase details (optionally include agents)."""
    _ = current_user
    if archetype:
        try:
            return UseCaseDetailResponse(**get_usecase_details(archetype, usecase_id))
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
    raise HTTPException(status_code=400, detail="archetype required")


# GET /usecases-all-details?archetype={archetype}&premium_mode={mode} — List all use cases with full details
@router.get("/usecases-all-details", response_model=list[UseCaseDetailResponse])
def list_all_usecases_full_details_route(
    current_user: Annotated[object, Depends(get_current_active_user)],
    archetype: Optional[str] = Query(None),
    premium_mode: str = Query(
        "non_premium",
        description="Tier filter: 'non_premium' (default) returns only non-premium use cases, 'premium' returns only premium use cases.",
    ),
) -> list[UseCaseDetailResponse]:
    """List all use cases with agent and prompt details for an archetype."""
    _ = current_user
    if not archetype:
        raise HTTPException(status_code=400, detail="archetype parameter is required")
   
    try:
        # Get list of all usecase IDs for the archetype (already tier-filtered)
        usecases = list_usecases(archetype, premium_mode)
        all_details = []
        for uc in usecases:
            uc_id = uc["usecaseid"]
            details = get_usecase_details(archetype, uc_id)
            all_details.append(UseCaseDetailResponse(**details))
        return all_details
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(exc)}")
 



# GET /usecases/{usecase_id}/agents — List agents for a usecase
@router.get("/usecases/{usecase_id}/agents", response_model=list[dict])
def list_agents_for_usecase_route(
    current_user: Annotated[object, Depends(get_current_active_user)],
    usecase_id: str,
    archetype: str = Query(None),
) -> list[dict]:
    """List agents for a usecase."""
    _ = current_user
    if archetype:
        try:
            return list_agents_for_usecase_db(archetype, usecase_id)
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
    raise HTTPException(status_code=400, detail="archetype required")


# PUT /usecases/{usecase_id} — Update metadata and/or agent order for an existing use case
@router.put("/usecases/{usecase_id}", response_model=UseCaseCreateResponse)
def update_usecase_route(
    usecase_id: str,
    request: UseCaseUpdateRequest,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Session = Depends(get_db),
) -> UseCaseCreateResponse:
    """Update an existing use case's metadata and/or ordered agent list."""
    try:
        return UseCaseCreateResponse(**update_usecase(db, usecase_id, request, current_user))
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/usecases/{usecase_id}/input-suggestions", response_model=UsecaseInputSuggestionsResponse)
def usecase_input_suggestions(
    usecase_id: str,
    req: UsecaseInputSuggestionsRequest,
    current_user: object = Depends(get_current_active_user),
):
    """Generate LLM-powered input suggestions for a use case."""
    _ = current_user
    llm_suggestion = get_usecase_input_suggestions(
        req.archetype,
        req.usecase,
        provider_name=req.provider,
    )
    return {"llm_suggestion": llm_suggestion}


@router.delete("/usecases/{usecase_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_usecase_route(
    usecase_id: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Session = Depends(get_db),
):
    """Delete a use case and its agent/archetype mappings."""
    try:
        delete_usecase(db, current_user, usecase_id)
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.delete(
    "/usecases/{usecase_id}/agents/{agent_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def unmap_agent_route(
    usecase_id: str,
    agent_id: str,
    current_user: Annotated[User, Depends(get_current_active_user)],
    db: Session = Depends(get_db),
):
    """Remove an agent from a use case without deleting the agent itself."""
    try:
        unmap_agent_from_usecase(db, current_user, usecase_id, agent_id)
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
