"""Team management API endpoints.

All team management operations require global admin (admin or developer role).
This is the same permission model as User Management.
"""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from daan.admin.team_service import (
    add_member,
    create_team,
    delete_team,
    get_team_detail,
    get_user_teams,
    list_teams,
    remove_member,
    update_team,
)
from daan.core.database import get_db
from daan.core.dependencies import require_admin, require_admin_or_developer
from daan.models.user import User
from daan.schemas.team import (
    TeamCreate,
    TeamDetailResponse,
    TeamMemberAdd,
    TeamResponse,
    TeamUpdate,
)

import logging

_logger = logging.getLogger(__name__)

router = APIRouter()


# ---------------------------------------------------------------------------
# Team listing  (admin only)
# ---------------------------------------------------------------------------

@router.get("", response_model=list[TeamResponse])
def get_all_teams(
    _: Annotated[User, Depends(require_admin_or_developer)],
    db: Annotated[Session, Depends(get_db)],
) -> list[TeamResponse]:
    """List all teams. Admin or developer."""
    return list_teams(db)


# ---------------------------------------------------------------------------
# Create / Delete  (admin only)
# ---------------------------------------------------------------------------

@router.post("", response_model=TeamDetailResponse, status_code=status.HTTP_201_CREATED)
def create_new_team(
    payload: TeamCreate,
    _: Annotated[User, Depends(require_admin)],
    db: Annotated[Session, Depends(get_db)],
) -> TeamDetailResponse:
    """Create a new team. Admin only."""
    try:
        team = create_team(db, payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return get_team_detail(db, team.id, include_virtual_key=True)


@router.delete("/{team_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_existing_team(
    team_id: int,
    _: Annotated[User, Depends(require_admin)],
    db: Annotated[Session, Depends(get_db)],
) -> None:
    """Delete a team. Admin only. Cannot delete the global default team."""
    try:
        delete_team(db, team_id)
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


# ---------------------------------------------------------------------------
# Get / Edit team detail  (admin only)
# ---------------------------------------------------------------------------

@router.get("/{team_id}", response_model=TeamDetailResponse)
def get_team(
    team_id: int,
    _: Annotated[User, Depends(require_admin_or_developer)],
    db: Annotated[Session, Depends(get_db)],
) -> TeamDetailResponse:
    """Get full team detail including members and decrypted virtual key. Admin or developer."""
    try:
        return get_team_detail(db, team_id, include_virtual_key=True)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.put("/{team_id}", response_model=TeamDetailResponse)
def update_existing_team(
    team_id: int,
    payload: TeamUpdate,
    _: Annotated[User, Depends(require_admin)],
    db: Annotated[Session, Depends(get_db)],
) -> TeamDetailResponse:
    """Update team name, description or virtual key. Admin only."""
    try:
        update_team(db, team_id, payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return get_team_detail(db, team_id, include_virtual_key=True)


# ---------------------------------------------------------------------------
# Member management  (admin only)
# ---------------------------------------------------------------------------

@router.get("/{team_id}/members", response_model=list[dict])
def get_members(
    team_id: int,
    _: Annotated[User, Depends(require_admin_or_developer)],
    db: Annotated[Session, Depends(get_db)],
) -> list[dict]:
    """List team members. Admin or developer."""
    try:
        members = get_team_detail(db, team_id, include_virtual_key=False)["members"]
        return [m.model_dump() for m in members]
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.post("/{team_id}/members", status_code=status.HTTP_201_CREATED)
def add_team_member(
    team_id: int,
    payload: TeamMemberAdd,
    _: Annotated[User, Depends(require_admin)],
    db: Annotated[Session, Depends(get_db)],
) -> dict:
    """Add a user to a team. Admin only."""
    try:
        add_member(db, team_id, payload.user_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"message": "Member added successfully"}


@router.delete("/{team_id}/members/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_team_member(
    team_id: int,
    user_id: int,
    _: Annotated[User, Depends(require_admin)],
    db: Annotated[Session, Depends(get_db)],
) -> None:
    """Remove a user from a team. Admin only."""
    try:
        remove_member(db, team_id, user_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


# ---------------------------------------------------------------------------
# User's own teams  (admin only for now, could be opened to users for their own)
# ---------------------------------------------------------------------------

@router.get("/user/{username}/teams", response_model=list[dict])
def get_teams_for_user(
    username: str,
    _: Annotated[User, Depends(require_admin_or_developer)],
    db: Annotated[Session, Depends(get_db)],
) -> list[dict]:
    """Get all teams a user belongs to. Admin or developer."""
    from daan.admin.user_service import get_user_by_username

    user = get_user_by_username(db, username)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    return get_user_teams(db, user.id)
