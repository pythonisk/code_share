"""Central API router composition."""

from fastapi import APIRouter, Depends

from daan.api.v1.endpoints.rag_router import router as rag_router
from daan.api.v1.endpoints.quality_observability import router as quality_observability_router
from daan.api.v1.endpoints.ontology_router import router as ontology_router
from daan.api.v1.endpoints import usecase_export_router
from daan.core.dependencies import get_current_active_user
from daan.api.v1.endpoints import (
	agents,
	archetypes,
	audit,
	chat,
	mcp_credentials,
	mcp_discovery,
	metadata,
	models,
	prompts,
	sessions,
	teams,
	token_usage,
	usecases,
	users,
    workflow,
	knowledge_graph,
)

api_router = APIRouter()
api_router.include_router(users.router, prefix="/users", tags=["Users"])
api_router.include_router(teams.router, prefix="/teams", tags=["Teams"])
api_router.include_router(archetypes.router, prefix="/archetypes", tags=["Archetypes"])
api_router.include_router(usecases.router, prefix="", tags=["UseCases"])
api_router.include_router(agents.router, prefix="", tags=["Agents"])
api_router.include_router(prompts.router, prefix="", tags=["Agents"])
api_router.include_router(sessions.router, prefix="/sessions", tags=["Sessions"])
api_router.include_router(sessions.unfiltered_router, prefix="", tags=["Sessions"])
api_router.include_router(token_usage.router, prefix="", tags=["TokenUsage"])
api_router.include_router(quality_observability_router, prefix="", tags=["Quality Observability"])
api_router.include_router(workflow.router, prefix="/workflow", tags=["Workflow"])
api_router.include_router(mcp_credentials.router, prefix="/mcp", tags=["MCP Credentials"])
api_router.include_router(mcp_discovery.router, prefix="/mcp", tags=["MCP Discovery"])
api_router.include_router(rag_router, prefix="/rag", tags=["RAG"])
api_router.include_router(ontology_router, prefix="/rag", tags=["Ontology"])
api_router.include_router(knowledge_graph.router, prefix="/knowledge-graph", tags=["Knowledge Graph"])
api_router.include_router(
	rag_router,
	prefix="/rag",
	tags=["RAG"],
	dependencies=[Depends(get_current_active_user)],
)
api_router.include_router(
	ontology_router,
	prefix="/rag",
	tags=["Ontology"],
	dependencies=[Depends(get_current_active_user)],
)
api_router.include_router(chat.router, prefix="/chat", tags=["Chat"])
api_router.include_router(audit.router, prefix="", tags=["Audit"])
api_router.include_router(metadata.router, prefix="", tags=["Metadata"])
api_router.include_router(models.router, prefix="", tags=["LLM Models"])
api_router.include_router(usecase_export_router.router, prefix="", tags=["UseCases"])
