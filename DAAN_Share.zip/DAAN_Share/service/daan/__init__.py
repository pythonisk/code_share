"""DAAN Framework Service Package"""

__version__ = "5.0.0"
__author__ = "DAAN Development Team"
__description__ = "Data Archetype Agent Network FastAPI Service"