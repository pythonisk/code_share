"""Compact dbt MCP server with dbt Cloud and ADO push tools."""

import base64
import glob
import json
import logging
import os
import posixpath
import random
import re
import sys
import time
from datetime import datetime
from typing import Any, Dict, Optional

import requests
import yaml
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

logging.basicConfig(level=logging.INFO, stream=sys.stderr)
logger = logging.getLogger(__name__)

load_dotenv()
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
load_dotenv(os.path.join(_REPO_ROOT, "config", ".env"))

dbt_mcp = FastMCP("dbt Cloud MCP Server", "1.0.0")
mcp = dbt_mcp

API_VERSION = "7.1"
ZERO_SHA = "0000000000000000000000000000000000000000"


def _ts() -> str:
    return datetime.now().isoformat()


def _bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}


def _dbt_headers(token: str) -> Dict[str, str]:
    return {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Token {token}",
    }


def _dbt_request(method: str, url: str, token: str, body: Optional[dict] = None) -> Dict[str, Any]:
    try:
        resp = requests.request(method, url, headers=_dbt_headers(token), json=body, timeout=60, verify=False)
        try:
            payload = resp.json()
        except Exception:
            payload = {"raw_text": resp.text}
        key = "data" if resp.status_code < 400 else "error"
        return {
            "success": resp.status_code < 400,
            "status_code": resp.status_code,
            "url": url,
            key: payload,
            "timestamp": _ts(),
        }
    except Exception as exc:
        return {
            "success": False,
            "status_code": None,
            "url": url,
            "error": str(exc),
            "timestamp": _ts(),
        }


class DbtCloudConfig:
    def __init__(self) -> None:
        self.base_url = os.getenv("DBT_CLOUD_BASE_URL", "https://cloud.getdbt.com").rstrip("/")
        self.account_id = os.getenv("DBT_CLOUD_ACCOUNT_ID", "").strip()
        self.job_id = os.getenv("DBT_CLOUD_JOB_ID", "").strip()
        self.token = os.getenv("DBT_CLOUD_TOKEN", "").strip()
        logger.debug(
            "DBT CONFIG | base_url=%s account_id=%s job_id=%s token=%s",
            self.base_url,
            self.account_id,
            self.job_id,
            "***" if self.token else "EMPTY",
        )


    def validate(self) -> Dict[str, Any]:
        missing = [
            name
            for name, value in {
                "DBT_CLOUD_BASE_URL": self.base_url,
                "DBT_CLOUD_ACCOUNT_ID": self.account_id,
                "DBT_CLOUD_JOB_ID": self.job_id,
                "DBT_CLOUD_TOKEN": self.token,
            }.items()
            if not value
        ]
        return {"ok": not missing, "missing": missing}


@dbt_mcp.tool()
def DbtCloudTestAuthTool() -> Dict[str, Any]:
    cfg = DbtCloudConfig()
    status = cfg.validate()
    return {
        "success": status["ok"],
        "missing": status["missing"],
        "base_url": cfg.base_url,
        "account_id": cfg.account_id,
        "job_id": cfg.job_id,
        "timestamp": _ts(),
    }


@dbt_mcp.tool()
def DbtCloudTriggerJobRunTool(
    cause: str = "Triggered by DAAN",
    git_branch: Optional[str] = None,
    git_sha: Optional[str] = None,
) -> Dict[str, Any]:
    cfg = DbtCloudConfig()
    status = cfg.validate()
    if not status["ok"]:
        return {"success": False, "error": f"Missing env vars: {status['missing']}"}
    body = {"cause": cause}
    if git_branch:
        body["git_branch"] = git_branch
    if git_sha:
        body["git_sha"] = git_sha
    url = f"{cfg.base_url}/api/v2/accounts/{cfg.account_id}/jobs/{cfg.job_id}/run/"
    return _dbt_request("POST", url, cfg.token, body)


@dbt_mcp.tool()
def DbtCloudGetRunStatusTool(run_id: int) -> Dict[str, Any]:
    cfg = DbtCloudConfig()
    status = cfg.validate()
    if not status["ok"]:
        return {"success": False, "error": f"Missing env vars: {status['missing']}"}
    url = f"{cfg.base_url}/api/v2/accounts/{cfg.account_id}/runs/{run_id}/"
    return _dbt_request("GET", url, cfg.token)


@dbt_mcp.tool()
def DbtCloudGetRunArtifactTool(run_id: int, artifact_path: str) -> Dict[str, Any]:
    cfg = DbtCloudConfig()
    status = cfg.validate()
    if not status["ok"]:
        return {"success": False, "error": f"Missing env vars: {status['missing']}"}
    url = f"{cfg.base_url}/api/v2/accounts/{cfg.account_id}/runs/{run_id}/artifacts/{artifact_path}"
    return _dbt_request("GET", url, cfg.token)


def _resolve_local_project_root(local_project_root: str) -> str:
    if local_project_root:
        return os.path.abspath(local_project_root)
    candidates = [
        os.getenv("LOCAL_DBT_PROJECT_ROOT", ""),
        os.getenv("DBT_LOCAL_PROJECT_DIR", ""),
        "my_dbt_project",
        "/tmp/dbt_project",
    ]
    resolved = []
    for candidate in candidates:
        if not candidate:
            continue
        resolved.append(candidate if os.path.isabs(candidate) else os.path.abspath(os.path.join(_REPO_ROOT, candidate)))
    for candidate in resolved:
        if os.path.isdir(candidate):
            return candidate
    return resolved[0] if resolved else os.path.abspath(os.path.join(_REPO_ROOT, "my_dbt_project"))


def _ado_headers(pat: str) -> Dict[str, str]:
    token = base64.b64encode(f":{pat}".encode()).decode()
    return {
        "Authorization": f"Basic {token}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }


def _ado_repo_web_url(org: str, project: str, repo: str) -> str:
    return f"https://dev.azure.com/{org}/{project}/_git/{repo}"


def _ado_folder_web_url(org: str, project: str, repo: str, folder_name: str) -> str:
    clean_folder = (folder_name or "").strip().lstrip("/")
    if not clean_folder:
        return _ado_repo_web_url(org, project, repo)
    return f"{_ado_repo_web_url(org, project, repo)}?path=/{clean_folder}"


def _ado_urls(org: str, project: str, repo: str) -> Dict[str, str]:
    root = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}"
    return {
        "refs": f"{root}/refs?api-version={API_VERSION}",
        "pushes": f"{root}/pushes?api-version={API_VERSION}",
    }


def _get_ref_object_id(headers: Dict[str, str], urls: Dict[str, str], branch_name: str) -> str:
    try:
        url = f"{urls['refs']}&filter=heads/{branch_name}"
        resp = requests.get(url, headers=headers, timeout=60)
        resp.raise_for_status()
        for ref in resp.json().get("value", []):
            if ref.get("name") == f"refs/heads/{branch_name}":
                return ref.get("objectId", ZERO_SHA)
    except Exception as exc:
        logger.warning("ADO ref lookup failed for %s: %s", branch_name, exc)
    return ZERO_SHA


def _item_exists(headers: Dict[str, str], org: str, project: str, repo: str, path: str, branch_name: str) -> bool:
    base = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/items"
    params = {
        "path": path if path.startswith("/") else f"/{path}",
        "versionDescriptor.version": branch_name,
        "versionDescriptor.versionType": "branch",
        "api-version": API_VERSION,
    }
    try:
        resp = requests.get(base, headers=headers, params=params, timeout=30)
        return resp.status_code == 200
    except Exception:
        return False


def _collect_changes(local_project_root: str):
    project_root = _resolve_local_project_root(local_project_root)
    file_list = []
    # Intentionally do not include root files like dbt_project.yml/packages.yml
    # from local mode because they frequently cause PR merge conflicts.

    include_dirs = ["macros", "seeds", "snapshots", "analyses"]
    for item in os.listdir(project_root):
        item_path = os.path.join(project_root, item)
        if os.path.isdir(item_path) and (item.startswith("dbt_modelling_") or item.startswith("dbt_testing_")):
            include_dirs.append(item)

    for folder_name in include_dirs:
        folder_dir = os.path.join(project_root, folder_name)
        if not os.path.isdir(folder_dir):
            continue
        for path in glob.glob(os.path.join(folder_dir, "**", "*.*"), recursive=True):
            if not os.path.isfile(path):
                continue
            rel = path.replace(project_root, "").replace("\\", "/")
            if not rel.startswith("/"):
                rel = f"/{rel}"
            if any(ext in rel.lower() for ext in (".sql/", ".yml/", ".yaml/")):
                continue
            with open(path, "r", encoding="utf-8") as handle:
                file_list.append((rel, handle.read()))

    dedup = {path: content for path, content in file_list}
    file_list = [(path, dedup[path]) for path in sorted(dedup)]
    has_timestamped = any(
        len(path.split("/")) > 1 and path.split("/")[1].startswith(("dbt_modelling_", "dbt_testing_"))
        for path, _ in file_list
    )
    if not has_timestamped:
        raise FileNotFoundError("No timestamped dbt folders found")
    return project_root, file_list


def _infer_repo_path_from_filename(filename: str) -> str:
    """Return only the exact file name (no nested folders)."""
    cleaned = (filename or "").strip().replace("\\", "/")
    return posixpath.basename(cleaned)


def _choose_timestamp_folder_prefix(files: Dict[str, str], folder_prefix: str = "") -> str:
    """Infer whether generated output is modelling or testing oriented."""
    cleaned_prefix = (folder_prefix or "").strip().lower().replace("-", "_")
    if cleaned_prefix in {"dbt_modelling", "dbt_testing"}:
        return cleaned_prefix

    filenames = [
        posixpath.basename((path or "").strip().replace("\\", "/")).lower()
        for path in files.keys()
    ]
    sql_filenames = [name for name in filenames if name.endswith(".sql")]
    if any(
        name.startswith("test_") or "validation" in name or "validate" in name or "lookup" in name
        for name in sql_filenames
    ):
        return "dbt_testing"
    if sql_filenames and all(
        name.startswith("test_") or "test" in name or "validation" in name or "lookup" in name
        for name in sql_filenames
    ):
        return "dbt_testing"
    if filenames and all(name in {"schema.yml", "schema.yaml"} for name in filenames):
        return "dbt_testing"
    return "dbt_modelling"


def _extract_files_from_markdown(markdown_text: str) -> Dict[str, str]:
    """Extract SQL/YAML files from model output markdown.

    Supported patterns:
    - **Filename**: `models/.../file.sql` + fenced code block
    - **file.sql** + fenced code block
    - Filename: models/.../file.sql + fenced code block
    - Standalone file mentions in bullet/lists (placeholder content when code is missing)
    """
    if not markdown_text:
        return {}

    files: Dict[str, str] = {}
    pattern_map = [
        # **Filename**: `path/file.sql` + fenced block
        re.compile(
            r"\*\*Filename\*\*\s*:\s*`?(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`?\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
        # Filename: path/file.sql + fenced block
        re.compile(
            r"(?:^|\n)\s*Filename\s*:\s*`?(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`?\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
        # File: path/file.sql + fenced block
        re.compile(
            r"(?:^|\n)\s*(?:\*\*)?File(?:\*\*)?\s*:\s*`?(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`?\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
        # **File: `path/file.sql`** + fenced block
        re.compile(
            r"(?:^|\n)\s*\*\*File\s*:\s*`?(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`?\*\*\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
        # **file.sql** or **schema.yml** + optional colon + fenced block
        re.compile(
            r"\*\*(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))\*\*\s*:?(?:\s*\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
        # `file.sql` + fenced block
        re.compile(
            r"`(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
        # Prose-introduced schema.yml followed by fenced YAML block
        re.compile(
            r"schema\.ya?ml[^\n]*?(?:\r?\n)+\s*```yaml\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
    ]

    for pattern in pattern_map:
        for match in pattern.finditer(markdown_text):
            raw_name = (match.groupdict().get("filename") or "schema.yml").strip()
            code = (match.group("code") or "").strip()
            if not raw_name or not code:
                continue
            normalized_name = _infer_repo_path_from_filename(raw_name)
            if normalized_name.lower().endswith((".yml", ".yaml")):
                code = _sanitize_yaml_content(code)
            files[normalized_name] = code + "\n"

    # Recover file names embedded inside SQL comments, e.g.
    # -- tests/derived_logic/my_test.sql
    commented_path_pattern = re.compile(
        r"\s*```(?P<lang>[A-Za-z0-9_\-]*)\s*\r?\n(?P<code>.*?)\r?\n\s*```",
        re.IGNORECASE | re.DOTALL,
    )
    sql_comment_path_pattern = re.compile(
        r"^\s*--\s*(?P<filename>(?:tests|models|macros|analyses|seeds|snapshots)/[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))\s*$",
        re.IGNORECASE | re.MULTILINE,
    )
    for block in commented_path_pattern.finditer(markdown_text):
        code = (block.group("code") or "").strip()
        if not code:
            continue
        comment_match = sql_comment_path_pattern.search(code)
        if not comment_match:
            continue
        raw_name = (comment_match.group("filename") or "").strip()
        normalized_name = _infer_repo_path_from_filename(raw_name)
        if normalized_name in files:
            continue
        files[normalized_name] = code + "\n"

    # Also collect standalone filename mentions from deliverable lists.
    mention_pattern = re.compile(
        r"(?:^|\n)\s*(?:[-*]|\d+\.)?\s*`?(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`?\s*(?=$|\n)",
        re.IGNORECASE,
    )
    mentioned: set[str] = set()
    for match in mention_pattern.finditer(markdown_text):
        raw_name = (match.group("filename") or "").strip()
        if raw_name:
            mentioned.add(_infer_repo_path_from_filename(raw_name))

    # Build safe placeholders for mentioned-but-not-coded files so push still includes them.
    for filename in sorted(mentioned):
        if filename in files:
            continue
        lower = filename.lower()
        if lower == "dialect_adapters.sql":
            files[filename] = (
                "{% macro substr_safe(column_name, start_pos, length) %}\n"
                "  substr({{ column_name }}, {{ start_pos }}, {{ length }})\n"
                "{% endmacro %}\n"
            )
        elif lower in {"schema.yml", "schema.yaml"}:
            # Keep generated placeholder valid YAML.
            files[filename] = _sanitize_yaml_content("version: 2\nmodels: []\n")
        elif lower.endswith(".sql"):
            files[filename] = (
                "-- Placeholder generated because file was listed by LLM without code block.\n"
                f"-- file: {filename}\n"
            )

    return files


def _default_dbt_project_yml(project_name_hint: str = "") -> str:
    """Return a minimal dbt_project.yml for bootstrap/repair.

    Project/profile names are derived from environment or repository context.
    """
    raw_name = (os.getenv("DBT_PROJECT_NAME") or project_name_hint or "dbt_project").strip()
    project_name = re.sub(r"[^a-zA-Z0-9_]", "_", raw_name).strip("_") or "sttm_agent_validation"
    profile = (os.getenv("DBT_PROFILE_NAME") or project_name).strip()

    rendered = (
        f'name: "{project_name}"\n'
        'version: "1.0.0"\n'
        "config-version: 2\n\n"
        f'profile: "{profile}"\n\n'
        'model-paths: ["models"]\n'
        'seed-paths: ["seeds"]\n'
        'macro-paths: ["macros"]\n'
        'snapshot-paths: ["snapshots"]\n'
        'analysis-paths: ["analyses"]\n'
        'test-paths: ["tests"]\n\n'
        'clean-targets:\n'
        '  - "target"\n'
        '  - "dbt_packages"\n\n'
        f"models:\n  {project_name}:\n    +materialized: view\n"
    )
    return _sanitize_yaml_content(rendered)


def _sanitize_yaml_content(content: str) -> str:
    """Best-effort YAML sanitizer for LLM-generated snippets.

    Fixes common unquoted comparison expressions like:
      condition: (slda >= 0)
    """
    text = (content or "").replace("\r\n", "\n")
    try:
        yaml.safe_load(text)
        return text
    except Exception:
        pass

    fixed_lines: list[str] = []
    line_re = re.compile(r"^(?P<prefix>\s*(?:-\s*)?[A-Za-z0-9_\-]+:\s*)(?P<value>.+?)\s*$")
    for line in text.split("\n"):
        m = line_re.match(line)
        if not m:
            fixed_lines.append(line)
            continue
        value = m.group("value").strip()
        needs_quote = (
            value
            and not value.startswith(("'", '"', "[", "{", "|", ">", "&", "*", "!"))
            and re.search(r"(>=|<=|==|!=|>|<)", value) is not None
        )
        if needs_quote:
            escaped = value.replace('"', '\\"')
            fixed_lines.append(f"{m.group('prefix')}\"{escaped}\"")
        else:
            fixed_lines.append(line)

    fixed_text = "\n".join(fixed_lines)
    try:
        yaml.safe_load(fixed_text)
        return fixed_text
    except Exception:
        return text


def _is_valid_dbt_project_yaml(content: str) -> bool:
    """Validate dbt_project.yml structure expected by dbt."""
    try:
        data = yaml.safe_load(content or "")
    except Exception:
        return False
    if not isinstance(data, dict):
        return False

    list_keys = ["model-paths", "seed-paths", "macro-paths", "snapshot-paths", "analysis-paths", "test-paths", "clean-targets"]
    for key in list_keys:
        if key in data and not isinstance(data.get(key), list):
            return False
    if "config-version" in data and not isinstance(data.get("config-version"), int):
        return False
    if "name" in data and not isinstance(data.get("name"), str):
        return False
    if "profile" in data and not isinstance(data.get("profile"), str):
        return False
    # model-paths: ["."] causes dbt to scan the entire repo root including
    # timestamp folders, breaking compile on any bad schema.yml found there.
    model_paths = data.get("model-paths") or []
    if "." in model_paths:
        return False
    return True


def _list_branch_paths(headers: Dict[str, str], org: str, project: str, repo: str, branch_name: str, scope_path: str = "/") -> list[str]:
    """List repository item paths for a branch under a scope path."""
    base = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/items"
    params = {
        "scopePath": scope_path,
        "recursionLevel": "Full",
        "versionDescriptor.version": branch_name,
        "versionDescriptor.versionType": "branch",
        "includeContentMetadata": "true",
        "api-version": API_VERSION,
    }
    try:
        resp = requests.get(base, headers=headers, params=params, timeout=60)
        if resp.status_code != 200:
            return []
        payload = resp.json() if resp.content else {}
        return [str(v.get("path", "")) for v in payload.get("value", []) if isinstance(v, dict) and v.get("path")]
    except Exception:
        return []


def _collect_existing_yaml_repairs(headers: Dict[str, str], org: str, project: str, repo: str, branch_name: str) -> list[tuple[str, str]]:
    """Repair malformed YAML files already present in timestamped dbt folders."""
    repairs: list[tuple[str, str]] = []
    for path in _list_branch_paths(headers, org, project, repo, branch_name, "/"):
        lower = path.lower()
        if not lower.startswith(("/dbt_modelling_", "/dbt_testing_")):
            continue
        if not lower.endswith((".yml", ".yaml")):
            continue

        content = _get_file_content(headers, org, project, repo, path, branch_name)
        if not content:
            continue
        sanitized = _sanitize_yaml_content(content)
        if sanitized != content:
            try:
                yaml.safe_load(sanitized)
                repairs.append((path, sanitized if sanitized.endswith("\n") else sanitized + "\n"))
            except Exception:
                continue
    return repairs


def _get_file_content(headers: Dict[str, str], org: str, project: str, repo: str, path: str, branch_name: str) -> str:
    """Fetch raw file content from ADO branch path."""
    base = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/items"
    params = {
        "path": path if path.startswith("/") else f"/{path}",
        "versionDescriptor.version": branch_name,
        "versionDescriptor.versionType": "branch",
        "includeContent": "true",
        "api-version": API_VERSION,
    }
    try:
        resp = requests.get(base, headers=headers, params=params, timeout=30)
        if resp.status_code != 200:
            return ""
        return resp.text or ""
    except Exception:
        return ""


def _load_latest_agent_output_markdown(require_code_blocks: bool = True, require_sql_files: bool = False) -> str:
    """Best-effort load of latest agent output markdown across all sessions.

    By default, prefers outputs that include fenced code blocks so that
    downstream extraction can recover SQL/YAML files reliably.
    If require_sql_files=True, selects the latest output that extracts at
    least one SQL file.
    """
    session_root = os.path.join(_REPO_ROOT, "session_storage")
    if not os.path.isdir(session_root):
        return ""

    latest_path = ""
    latest_mtime = -1.0
    try:
        for sid in os.listdir(session_root):
            agents_root = os.path.join(session_root, sid, "agents")
            if not os.path.isdir(agents_root):
                continue
            for agent_name in os.listdir(agents_root):
                out_path = os.path.join(agents_root, agent_name, "output.md")
                if not os.path.isfile(out_path):
                    continue
                if require_code_blocks:
                    try:
                        with open(out_path, "r", encoding="utf-8") as fh:
                            preview = fh.read()
                        if "```" not in preview:
                            continue
                        if require_sql_files:
                            extracted = _extract_files_from_markdown(preview)
                            if not any(name.lower().endswith(".sql") for name in extracted.keys()):
                                continue
                    except Exception:
                        continue
                mtime = os.path.getmtime(out_path)
                if mtime > latest_mtime:
                    latest_mtime = mtime
                    latest_path = out_path
    except Exception:
        return ""

    # Fallback to latest output even if no code blocks were found.
    if not latest_path and require_code_blocks:
        return _load_latest_agent_output_markdown(require_code_blocks=False, require_sql_files=False)

    if not latest_path:
        return ""

    try:
        with open(latest_path, "r", encoding="utf-8") as fh:
            return fh.read()
    except Exception:
        return ""


def _build_changes(headers: Dict[str, str], org: str, project: str, repo: str, branch: str, file_list, branch_exists: bool):
    changes = []
    for rel_path, content in file_list:
        change_type = "edit" if branch_exists and _item_exists(headers, org, project, repo, rel_path, branch) else "add"
        changes.append(
            {
                "changeType": change_type,
                "item": {"path": rel_path},
                "newContent": {"content": content, "contentType": "rawtext"},
            }
        )
    return changes


def _push_once(headers: Dict[str, str], urls: Dict[str, str], old_object_id: str, branch: str, changes, commit_message: str):
    body = {
        "refUpdates": [{"name": f"refs/heads/{branch}", "oldObjectId": old_object_id}],
        "commits": [{"comment": commit_message, "changes": changes}],
    }
    return requests.post(urls["pushes"], headers=headers, data=json.dumps(body), timeout=120)


def _create_branch_from_base(headers: Dict[str, str], org: str, project: str, repo: str, branch: str, base_branch: str) -> str:
    urls = _ado_urls(org, project, repo)
    base_object_id = _get_ref_object_id(headers, urls, base_branch)
    if base_object_id == ZERO_SHA:
        raise RuntimeError(f"Base branch '{base_branch}' not found")
    url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/refs?api-version={API_VERSION}"
    body = [{"name": f"refs/heads/{branch}", "oldObjectId": ZERO_SHA, "newObjectId": base_object_id}]
    resp = requests.post(url, headers=headers, data=json.dumps(body), timeout=60)
    if resp.status_code not in (200, 201):
        raise RuntimeError(f"Failed to create branch '{branch}': {resp.status_code} {resp.text[:300]}")
    return base_object_id


def _reset_branch_to_base(headers: Dict[str, str], org: str, project: str, repo: str, branch: str, base_branch: str) -> str:
    urls = _ado_urls(org, project, repo)
    current_object_id = _get_ref_object_id(headers, urls, branch)
    if current_object_id == ZERO_SHA:
        return _create_branch_from_base(headers, org, project, repo, branch, base_branch)
    base_object_id = _get_ref_object_id(headers, urls, base_branch)
    if base_object_id == ZERO_SHA:
        raise RuntimeError(f"Base branch '{base_branch}' not found")
    if current_object_id == base_object_id:
        return base_object_id
    url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/refs?api-version={API_VERSION}"
    body = [{"name": f"refs/heads/{branch}", "oldObjectId": current_object_id, "newObjectId": base_object_id}]
    resp = requests.post(url, headers=headers, data=json.dumps(body), timeout=60)
    if resp.status_code not in (200, 201):
        raise RuntimeError(f"Failed to reset branch '{branch}': {resp.status_code} {resp.text[:300]}")
    return base_object_id


def _is_stale_ref_error(response: requests.Response) -> bool:
    if response.status_code != 409:
        return False
    try:
        payload = response.json()
    except Exception:
        return False
    message = payload.get("message", "")
    type_key = payload.get("typeKey", "")
    return "TF401028" in message or "GitReferenceStaleException" in type_key


def get_existing_pr(org: str, project: str, repo: str, pat: str, source_branch: str, target_branch: str):
    headers = _ado_headers(pat)
    url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/pullrequests?api-version={API_VERSION}"
    params = {
        "searchCriteria.sourceRefName": f"refs/heads/{source_branch}",
        "searchCriteria.targetRefName": f"refs/heads/{target_branch}",
        "searchCriteria.status": "active",
    }
    resp = requests.get(url, headers=headers, params=params, timeout=120)
    resp.raise_for_status()
    prs = resp.json().get("value", [])
    return prs[0] if prs else None


def create_pr(org: str, project: str, repo: str, pat: str, source_branch: str, target_branch: str, title: str, description: str):
    headers = _ado_headers(pat)
    url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/pullrequests?api-version={API_VERSION}"
    body = {
        "sourceRefName": f"refs/heads/{source_branch}",
        "targetRefName": f"refs/heads/{target_branch}",
        "title": title,
        "description": description,
    }
    resp = requests.post(url, headers=headers, data=json.dumps(body), timeout=120)
    resp.raise_for_status()
    return resp.json()


def complete_pr(org: str, project: str, repo: str, pat: str, pr_id: int, squash: bool = True, delete_source: bool = True, last_merge_source: Optional[str] = None):
    headers = _ado_headers(pat)
    url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/pullrequests/{pr_id}?api-version={API_VERSION}"
    body: Dict[str, Any] = {
        "status": "completed",
        "completionOptions": {
            "squashMerge": bool(squash),
            "deleteSourceBranch": bool(delete_source),
            "mergeStrategy": "squash" if squash else "noFastForward",
        },
    }
    if last_merge_source:
        body["lastMergeSourceCommit"] = {"commitId": last_merge_source}
    resp = requests.patch(url, headers=headers, data=json.dumps(body), timeout=120)
    resp.raise_for_status()
    return resp.json()


def get_pr(org: str, project: str, repo: str, pat: str, pr_id: int):
    headers = _ado_headers(pat)
    url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/pullrequests/{pr_id}?api-version={API_VERSION}"
    resp = requests.get(url, headers=headers, timeout=60)
    resp.raise_for_status()
    return resp.json()


def wait_for_pr_completion(org: str, project: str, repo: str, pat: str, pr_id: int, timeout_sec: int = 600, poll_every: int = 5):
    deadline = time.time() + timeout_sec
    while time.time() < deadline:
        pr = get_pr(org, project, repo, pat, pr_id)
        if (pr.get("status") or "").lower() in {"completed", "abandoned"}:
            return pr
        time.sleep(poll_every)
    raise TimeoutError(f"PR {pr_id} not completed within {timeout_sec}s")


def trigger_dbt_cloud_run_from_env(git_branch: Optional[str] = None, cause: Optional[str] = None) -> Dict[str, Any]:
    cfg = DbtCloudConfig()
    status = cfg.validate()
    if not status["ok"]:
        return {"success": False, "skipped": True, "reason": "missing_env_vars", "missing": status["missing"]}
    body = {"cause": cause or "Triggered after ADO PR merge by DAAN"}
    if git_branch:
        body["git_branch"] = git_branch
    url = f"{cfg.base_url}/api/v2/accounts/{cfg.account_id}/jobs/{cfg.job_id}/run/"
    return _dbt_request("POST", url, cfg.token, body)


def push_dbt_project(
    org: str,
    project: str,
    repo: str,
    branch: str,
    pat: str,
    local_project_root: str,
    base_branch: str = "DBT_Repo",
    reset_source_branch_to_base: bool = True,
    commit_message: str = "Automated: add/update dbt project",
) -> Dict[str, Any]:
    headers = _ado_headers(pat)
    urls = _ado_urls(org, project, repo)
    old_object_id = _get_ref_object_id(headers, urls, branch)
    branch_exists = old_object_id != ZERO_SHA

    if reset_source_branch_to_base:
        old_object_id = _reset_branch_to_base(headers, org, project, repo, branch, base_branch)
        branch_exists = True
    elif not branch_exists:
        old_object_id = _create_branch_from_base(headers, org, project, repo, branch, base_branch)
        branch_exists = True

    project_root, file_list = _collect_changes(local_project_root)
    changes = _build_changes(headers, org, project, repo, branch, file_list, branch_exists)

    push_payload = None
    last_resp = None
    for attempt in range(1, 16):
        resp = _push_once(headers, urls, old_object_id, branch, changes, commit_message)
        if resp.status_code in (200, 201):
            push_payload = resp.json()
            break
        if _is_stale_ref_error(resp):
            last_resp = resp
            old_object_id = _get_ref_object_id(headers, urls, branch)
            changes = _build_changes(headers, org, project, repo, branch, file_list, old_object_id != ZERO_SHA)
            time.sleep(min((2 ** (attempt - 1)) + random.uniform(0, 1.0), 30))
            continue
        resp.raise_for_status()
    if push_payload is None:
        if last_resp is not None:
            last_resp.raise_for_status()
        raise RuntimeError("Push failed")

    repo_url = _ado_repo_web_url(org, project, repo)
    result: Dict[str, Any] = {
        "push": push_payload,
        "local_project_root": project_root,
        "source_branch": branch,
        "target_branch": base_branch,
        "repo_url": repo_url,
    }

    if branch == base_branch:
        return result

    pr = get_existing_pr(org, project, repo, pat, branch, base_branch) or create_pr(
        org,
        project,
        repo,
        pat,
        branch,
        base_branch,
        f"Automated dbt update: {branch} -> {base_branch}",
        "Automated PR created by DAAN dbt pipeline.",
    )
    pr_id = pr.get("pullRequestId")
    result["pr"] = {
        "id": pr_id,
        "status": pr.get("status"),
        "url": repo_url,
        "pr_api_url": pr.get("url"),
        "source": branch,
        "target": base_branch,
    }

    if _bool(os.getenv("ADO_AUTO_COMPLETE"), False):
        source_commit = (((push_payload or {}).get("commits") or [{}])[0]).get("commitId")
        complete_pr(org, project, repo, pat, pr_id, squash=True, delete_source=True, last_merge_source=source_commit)
        final_pr = wait_for_pr_completion(org, project, repo, pat, pr_id)
        result["pr"]["status"] = final_pr.get("status")
        result["pr"]["mergeStatus"] = final_pr.get("mergeStatus")
        if (final_pr.get("status") or "").lower() != "completed":
            raise RuntimeError(f"PR #{pr_id} did not complete")
        if _bool(os.getenv("DBT_AUTO_TRIGGER_AFTER_MERGE"), False):
            result["dbt_cloud_trigger"] = trigger_dbt_cloud_run_from_env(
                git_branch=base_branch,
                cause=f"Auto-triggered by DAAN after PR merge ({branch} -> {base_branch})",
            )

    return result


@dbt_mcp.tool()
def DbtAdoPushProjectTool(
    org: str = "",
    project: str = "",
    repo: str = "",
    branch: str = "",
    pat: str = "",
    local_project_root: str = "",
    base_branch: str = "",
    reset_source_branch_to_base: bool = True,
    commit_message: str = "Automated: add/update dbt project",
) -> Dict[str, Any]:
    return {
        "success": False,
        "error": (
            "DbtAdoPushProjectTool (local-folder mode) is disabled. "
            "Use DbtAdoPushFilesTool with the required `files` argument."
        ),
    }


@dbt_mcp.tool()
def DbtAdoPushFilesTool(
    files: Dict[str, str] | None = None,
    reviewed_output: str = "",
    commit_message: str = "Automated: add/update dbt models",
    folder_prefix: str = "",
    org: str = "",
    project: str = "",
    repo: str = "",
    branch: str = "",
    base_branch: str = "",
    pat: str = "",
) -> Dict[str, Any]:
    """Push dbt SQL/YAML file content directly to ADO — no local disk needed.

    Pass the file content produced by the dynamic agent directly.
        Keys can be file names or paths, but only the exact file name is used.
        Final push path is always:
            "dbt_<mode>_<timestamp>/<exact_filename>"

    All ADO credentials are read from env vars (ADO_ORG, ADO_PROJECT,
    ADO_REPO, ADO_BRANCH, ADO_BASE_BRANCH, ADO_PAT) — no UI input needed.
    """
    _org = org or os.getenv("ADO_ORG", "")
    _project = project or os.getenv("ADO_PROJECT", "")
    _repo = repo or os.getenv("ADO_REPO", "")
    _branch = branch or os.getenv("ADO_BRANCH", "")
    _base_branch = base_branch or os.getenv("ADO_BASE_BRANCH", "")
    _pat = pat or os.getenv("ADO_PAT", "")

    missing = [k for k, v in {
        "ADO_ORG": _org, "ADO_PROJECT": _project,
        "ADO_REPO": _repo, "ADO_BRANCH": _branch,
        "ADO_BASE_BRANCH": _base_branch, "ADO_PAT": _pat,
    }.items() if not v]
    if missing:
        return {"success": False, "error": f"Missing ADO credentials: {missing}"}

    normalized_files = dict(files or {})
    extracted_from_reviewed = _extract_files_from_markdown(reviewed_output) if reviewed_output else {}

    if not normalized_files:
        normalized_files = dict(extracted_from_reviewed)

    # If caller passed only YAML (common with some orchestrator payloads),
    # enrich with SQL files parsed from reviewed output.
    sql_count = sum(1 for name in normalized_files.keys() if str(name).lower().endswith(".sql"))
    if extracted_from_reviewed and sql_count == 0:
        normalized_files.update(extracted_from_reviewed)
        sql_count = sum(1 for name in normalized_files.keys() if str(name).lower().endswith(".sql"))

    # Final fallback: use latest code-bearing agent output if SQL is still missing.
    if sql_count == 0:
        fallback_extracted = _extract_files_from_markdown(
            _load_latest_agent_output_markdown(require_sql_files=True)
        )
        if not any(name.lower().endswith(".sql") for name in fallback_extracted.keys()):
            fallback_extracted = _extract_files_from_markdown(_load_latest_agent_output_markdown())
        if fallback_extracted:
            normalized_files.update(fallback_extracted)

    if not normalized_files:
        return {
            "success": False,
            "error": "No files provided and no extractable SQL/YAML blocks found in reviewed output.",
        }

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    timestamped_folder = f"{_choose_timestamp_folder_prefix(normalized_files, folder_prefix)}_{timestamp}"

    headers = _ado_headers(_pat)
    urls = _ado_urls(_org, _project, _repo)

    # dbt_project.yml should be a permanent root file.
    # If it already exists in base branch, skip it to avoid merge conflicts.
    # If it is missing in base branch, allow one-time creation at repository root.
    base_has_dbt_project = _item_exists(headers, _org, _project, _repo, "/dbt_project.yml", _base_branch)
    repair_dbt_project = False
    if base_has_dbt_project:
        existing_dbt_project = _get_file_content(headers, _org, _project, _repo, "/dbt_project.yml", _base_branch)
        if not _is_valid_dbt_project_yaml(existing_dbt_project):
            logger.warning("Base branch /dbt_project.yml is invalid YAML; scheduling auto-repair")
            repair_dbt_project = True

    # packages.yml is intentionally skipped from generated payloads to avoid
    # root-level conflicts unless introduced as a deliberate manual change.
    _ROOT_CONFIG_FILES = {"packages.yml"}

    # Always enforce: /<timestamp_folder>/<exact_filename>
    file_list: list[tuple[str, str]] = []
    saw_dbt_project_in_payload = False
    for rel_path, content in normalized_files.items():
        rel_path = rel_path.lstrip("/").replace("\\", "/")
        rel_path = posixpath.normpath(rel_path)
        if rel_path in {"", ".", ".."} or rel_path.startswith("../"):
            logger.info("Skipping unsafe file path: %s", rel_path)
            continue

        filename = posixpath.basename(rel_path)
        basename = filename.lower()
        if basename == "dbt_project.yml":
            saw_dbt_project_in_payload = True
            if base_has_dbt_project:
                logger.info("Skipping dbt_project.yml (already exists in base branch): %s", rel_path)
                continue
            # One-time bootstrap: create at repo root so dbt Cloud can run dbt deps.
            file_list.append(("/dbt_project.yml", content))
            base_has_dbt_project = True
            continue

        if basename in _ROOT_CONFIG_FILES:
            logger.info("Skipping config file to avoid PR conflict: %s", rel_path)
            continue

        file_list.append((f"/models/{timestamped_folder}/{filename}", content))

    # One-time bootstrap via code: if base branch is missing dbt_project.yml and
    # agent payload did not provide one, auto-create a minimal root config.
    if not base_has_dbt_project and not saw_dbt_project_in_payload:
        logger.info("Base branch missing /dbt_project.yml; auto-creating minimal bootstrap config")
        file_list.append(("/dbt_project.yml", _default_dbt_project_yml(project_name_hint=_repo)))
        base_has_dbt_project = True
        # Ensure models/ directory exists alongside the new dbt_project.yml.
        if not _item_exists(headers, _org, _project, _repo, "/models/.gitkeep", _base_branch):
            file_list.append(("/models/.gitkeep", ""))

    # Repair malformed permanent config if present in base branch.
    if repair_dbt_project:
        file_list.append(("/dbt_project.yml", _default_dbt_project_yml(project_name_hint=_repo)))
        # Ensure models/ directory exists so dbt compile does not fail with
        # "model-paths: ["models"]" pointing at a missing directory.
        if not _item_exists(headers, _org, _project, _repo, "/models/.gitkeep", _base_branch):
            file_list.append(("/models/.gitkeep", ""))

    # Repair malformed YAML already present in existing timestamp folders.
    for repair_path, repair_content in _collect_existing_yaml_repairs(headers, _org, _project, _repo, _base_branch):
        if not any(existing_path == repair_path for existing_path, _ in file_list):
            file_list.append((repair_path, repair_content))

    if not file_list:
        return {"success": False, "error": "No pushable files after filtering root-level config files."}
    dedup_file_list = {}

    for path, content in file_list:
        dedup_file_list[path] = content

    file_list = [
        (path, content)
        for path, content in dedup_file_list.items()
    ]

    # Reset feature branch to base so no stale files exist
    old_object_id = _reset_branch_to_base(headers, _org, _project, _repo, _branch, _base_branch)

    changes = []
    for rel_path, content in file_list:
        change_type = "edit" if _item_exists(headers, _org, _project, _repo, rel_path, _branch) else "add"
        changes.append({
            "changeType": change_type,
            "item": {"path": rel_path},
            "newContent": {"content": content, "contentType": "rawtext"},
        })
    logger.debug(
        "FILES TO PUSH = %s",
        [p for p, _ in file_list]
    )
    push_payload = None
    last_resp = None
    for attempt in range(1, 16):
        resp = _push_once(headers, urls, old_object_id, _branch, changes, commit_message)
        if resp.status_code in (200, 201):
            push_payload = resp.json()
            break
        if _is_stale_ref_error(resp):
            last_resp = resp
            old_object_id = _get_ref_object_id(headers, urls, _branch)
            time.sleep(min((2 ** (attempt - 1)) + random.uniform(0, 1.0), 30))
            continue
        return {
            "success": False,
            "status_code": resp.status_code,
            "response_body": resp.text,
            "files": [c["item"]["path"] for c in changes],
            "change_count": len(changes),
            "branch": _branch,
            "base_branch": _base_branch,
        }
    if push_payload is None:
        if last_resp is not None:
            last_resp.raise_for_status()
        raise RuntimeError("Push failed")

    repo_url = _ado_repo_web_url(_org, _project, _repo)
    result: Dict[str, Any] = {
        "success": True,
        "source_branch": _branch,
        "target_branch": _base_branch,
        "files_pushed": [p for p, _ in file_list],
        "timestamped_folder": timestamped_folder,
        "timestamped_folder_url": _ado_folder_web_url(_org, _project, _repo, timestamped_folder),
        "timestamp": _ts(),
        "repo_url": repo_url,
    }

    pr = get_existing_pr(_org, _project, _repo, _pat, _branch, _base_branch) or create_pr(
        _org, _project, _repo, _pat, _branch, _base_branch,
        f"Automated dbt update: {_branch} -> {_base_branch}",
        "Automated PR created by DAAN dbt pipeline.",
    )
    pr_id = pr.get("pullRequestId")
    result["pr"] = {
        "id": pr_id,
        "status": pr.get("status"),
        "url": repo_url,
        "pr_api_url": pr.get("url"),
        "source": _branch,
        "target": _base_branch,
    }

    if _bool(os.getenv("ADO_AUTO_COMPLETE"), False):
        source_commit = (((push_payload or {}).get("commits") or [{}])[0]).get("commitId")
        complete_pr(_org, _project, _repo, _pat, pr_id, squash=True, delete_source=True, last_merge_source=source_commit)
        final_pr = wait_for_pr_completion(_org, _project, _repo, _pat, pr_id)
        result["pr"]["status"] = final_pr.get("status")
        result["pr"]["mergeStatus"] = final_pr.get("mergeStatus")
        if _bool(os.getenv("DBT_AUTO_TRIGGER_AFTER_MERGE"), False):
            result["dbt_cloud_trigger"] = trigger_dbt_cloud_run_from_env(
                git_branch=_base_branch,
                cause=f"Auto-triggered by DAAN after PR merge ({_branch} -> {_base_branch})",
            )
    return result


if __name__ == "__main__":
    logger.info("Starting dbt Cloud MCP Server...")
    dbt_mcp.run(transport="stdio")
