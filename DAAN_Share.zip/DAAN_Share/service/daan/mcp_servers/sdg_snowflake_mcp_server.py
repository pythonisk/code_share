"""SDG Snowflake MCP Server — UC_CP_026

Provides 4 tools that bridge Snowflake and the existing SyntheticDataTool pipeline:

  1. sdg_validate_connection   — health-check Snowflake credentials
  2. sdg_list_tables           — discover tables + row counts in a schema
  3. sdg_extract_schema_and_samples
                               — pull schema metadata + sample rows from Snowflake
                                 and write them to session_storage/{session_id}/inputs/
                                 in the exact format SyntheticDataTool.execute_generation
                                 already reads (no changes to that tool)
  4. sdg_upload_synthetic_data — read generated CSVs from session_storage/{session_id}/sdg/
                                 and bulk-upload them to Snowflake

Credentials are read from SDG_SNOWFLAKE_* environment variables so this server
is isolated from the generic SNOWFLAKE_* vars used by the existing snowflake-mcp-server.

Launch (stdio transport, same pattern as other DAAN MCP servers):
    python -c "import daan.mcp_servers.sdg_snowflake_mcp_server as m; m.mcp.run(transport='stdio')"
"""

from __future__ import annotations

import csv
import json
import logging
import os
import re
import sys
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from mcp.server.fastmcp import FastMCP

# Keep stdio stdout clean — suppress noisy library output
# Note: env vars are injected by mcp_toolset_provider at subprocess launch;
# do NOT call load_dotenv() here — any output to stdout breaks the MCP stdio protocol.
for _noisy in ("snowflake", "snowflake.connector", "mcp", "mcp.server"):
    logging.getLogger(_noisy).setLevel(logging.WARNING)

logger = logging.getLogger(__name__)

sdg_snowflake_mcp = FastMCP("SDG Snowflake MCP Server", "1.0.0")
mcp = sdg_snowflake_mcp  # entry point used by mcp_server_registry.yml

# ---------------------------------------------------------------------------
# Resolve session-storage root the same way SyntheticDataTool does
# ---------------------------------------------------------------------------
_PROJECT_ROOT = Path(__file__).resolve().parents[3]
_TRACE_LOCK = threading.Lock()
_TRACE_FILE = _PROJECT_ROOT / "system logs" / "sdg_snowflake_mcp_trace.log"
_SNOWFLAKE_CONNECTOR = None
_SNOWFLAKE_IMPORT_ERROR: Exception | None = None
_SNOWFLAKE_WRITE_PANDAS = None
_SNOWFLAKE_WRITE_PANDAS_IMPORT_ERROR: Exception | None = None
_SYNTHETIC_TABLE_SUFFIX = "_SYNTHETIC"
_UUID_LIKE_SESSION_ID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE)


def _session_storage_root() -> Path:
    storage_raw = os.getenv("SESSION_STORAGE_DIR", "session_storage")
    return Path(storage_raw) if os.path.isabs(storage_raw) else _PROJECT_ROOT / storage_raw


def _resolve_runtime_session_id(session_id: str) -> str:
    normalized = str(session_id or "").strip()
    if not normalized:
        return normalized

    storage_root = _session_storage_root()

    # Real runtime session ids are UUID-like folder names. If we already have one,
    # keep it unchanged.
    if _UUID_LIKE_SESSION_ID.fullmatch(normalized):
        return normalized

    # Some planner/execution prompts can pass the use case id instead of the live
    # runtime session id. Recover by locating the latest real session for this use case.
    if normalized.upper().startswith("UC_"):
        matched_sessions: list[tuple[float, str]] = []
        for child in storage_root.iterdir() if storage_root.exists() else []:
            if not child.is_dir() or child.name.upper() == normalized.upper():
                continue
            if not _UUID_LIKE_SESSION_ID.fullmatch(child.name):
                continue
            session_log = child / "session.log"
            if not session_log.is_file():
                continue
            try:
                content = session_log.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            if f"usecase_id='{normalized}'" in content or f'"usecase_id": "{normalized}"' in content:
                matched_sessions.append((session_log.stat().st_mtime, child.name))

        if matched_sessions:
            resolved = max(matched_sessions, key=lambda item: item[0])[1]
            _trace_event(
                "session_id.resolved",
                supplied_session_id=normalized,
                resolved_session_id=resolved,
            )
            return resolved

    return normalized


def _session_inputs_dir(session_id: str) -> Path:
    storage_root = _session_storage_root()
    return storage_root / _resolve_runtime_session_id(session_id) / "inputs"


def _session_sdg_output_dir(session_id: str) -> Path:
    storage_root = _session_storage_root()
    return storage_root / _resolve_runtime_session_id(session_id) / "sdg" / "output" / "SDV" / "output"


def _trace_event(event: str, **details: Any) -> None:
    payload = {
        "ts": _ts(),
        "pid": os.getpid(),
        "event": event,
    }
    for key, value in details.items():
        if value is None:
            continue
        payload[key] = _sanitize(value)

    line = json.dumps(payload, ensure_ascii=True)

    try:
        print(line, file=sys.stderr, flush=True)
    except Exception:
        pass

    try:
        _TRACE_FILE.parent.mkdir(parents=True, exist_ok=True)
        with _TRACE_LOCK:
            with _TRACE_FILE.open("a", encoding="utf-8") as handle:
                handle.write(line + "\n")
    except Exception:
        pass


def _sql_preview(sql: str, limit: int = 160) -> str:
    normalized = re.sub(r"\s+", " ", str(sql or "")).strip()
    if len(normalized) <= limit:
        return normalized
    return normalized[: limit - 3] + "..."


def _preload_snowflake_modules() -> None:
    global _SNOWFLAKE_CONNECTOR
    global _SNOWFLAKE_IMPORT_ERROR
    global _SNOWFLAKE_WRITE_PANDAS
    global _SNOWFLAKE_WRITE_PANDAS_IMPORT_ERROR

    if _SNOWFLAKE_CONNECTOR is None and _SNOWFLAKE_IMPORT_ERROR is None:
        try:
            _trace_event("snowflake.module_import.start", module="snowflake.connector")
            import snowflake.connector as snowflake_connector  # type: ignore

            _SNOWFLAKE_CONNECTOR = snowflake_connector
            _trace_event("snowflake.module_import.done", module="snowflake.connector")
        except Exception as exc:
            _SNOWFLAKE_IMPORT_ERROR = exc
            _trace_event("snowflake.module_import.error", module="snowflake.connector", error=exc)

    if _SNOWFLAKE_WRITE_PANDAS is None and _SNOWFLAKE_WRITE_PANDAS_IMPORT_ERROR is None:
        try:
            _trace_event("snowflake.module_import.start", module="snowflake.connector.pandas_tools.write_pandas")
            from snowflake.connector.pandas_tools import write_pandas  # type: ignore

            _SNOWFLAKE_WRITE_PANDAS = write_pandas
            _trace_event("snowflake.module_import.done", module="snowflake.connector.pandas_tools.write_pandas")
        except Exception as exc:
            _SNOWFLAKE_WRITE_PANDAS_IMPORT_ERROR = exc
            _trace_event(
                "snowflake.module_import.error",
                module="snowflake.connector.pandas_tools.write_pandas",
                error=exc,
            )

# ---------------------------------------------------------------------------
# Minimal Snowflake connector using SDG_SNOWFLAKE_* credentials
# ---------------------------------------------------------------------------

class _SDGSnowflakeConn:
    """Lightweight connector that reads SDG_SNOWFLAKE_* env vars."""

    def __init__(self) -> None:
        self.account = os.getenv("SDG_SNOWFLAKE_ACCOUNT", "").strip()
        self.user = os.getenv("SDG_SNOWFLAKE_USER", "").strip()
        self.password = os.getenv("SDG_SNOWFLAKE_PASSWORD", "").strip()
        self.warehouse = os.getenv("SDG_SNOWFLAKE_WAREHOUSE", "").strip()
        self.database = os.getenv("SDG_SNOWFLAKE_DATABASE", "").strip()
        self.schema = os.getenv("SDG_SNOWFLAKE_SCHEMA", "PUBLIC").strip()
        self.role = os.getenv("SDG_SNOWFLAKE_ROLE", "SYSADMIN").strip()
        self._conn = None

    def missing_vars(self) -> List[str]:
        required = {
            "SDG_SNOWFLAKE_ACCOUNT": self.account,
            "SDG_SNOWFLAKE_USER": self.user,
            "SDG_SNOWFLAKE_PASSWORD": self.password,
            "SDG_SNOWFLAKE_WAREHOUSE": self.warehouse,
        }
        return [k for k, v in required.items() if not v]

    def connect(self) -> None:
        _trace_event("snowflake.connect.import_socket.start")
        import socket
        _trace_event("snowflake.connect.import_socket.done")
        if _SNOWFLAKE_IMPORT_ERROR is not None:
            _trace_event("snowflake.connect.import_connector.error", error=_SNOWFLAKE_IMPORT_ERROR)
            raise RuntimeError(f"snowflake.connector unavailable: {_SNOWFLAKE_IMPORT_ERROR}") from _SNOWFLAKE_IMPORT_ERROR
        if _SNOWFLAKE_CONNECTOR is None:
            raise RuntimeError("snowflake.connector unavailable: import did not initialize")
        _trace_event("snowflake.connect.import_connector.done", source="startup_cache")

        # Apply a hard socket-level timeout BEFORE the connector call so
        # DNS resolution and TCP handshake are also bounded.  Without this
        # the OS may block for 60-120 s even when login_timeout=30 is set,
        # which exceeds the MCP StdioConnectionParams(timeout=60) and causes
        # "Timed out while waiting for response to ClientRequest".
        _prev_timeout = socket.getdefaulttimeout()
        _trace_event("snowflake.connect.socket_timeout.set", previous_timeout=_prev_timeout)
        socket.setdefaulttimeout(20)
        try:
            _trace_event(
                "snowflake.connect.start",
                account=self.account,
                user=self.user,
                warehouse=self.warehouse,
                database=self.database,
                schema=self.schema,
                role=self.role,
            )
            self._conn = _SNOWFLAKE_CONNECTOR.connect(
                account=self.account,
                user=self.user,
                password=self.password,
                warehouse=self.warehouse,
                database=self.database,
                schema=self.schema,
                role=self.role,
                login_timeout=20,    # fail fast if auth hangs
                network_timeout=20,  # fail fast if queries hang
            )
            _trace_event("snowflake.connect.success")
        except Exception as exc:
            _trace_event("snowflake.connect.error", error=exc)
            raise
        finally:
            socket.setdefaulttimeout(_prev_timeout)

    def close(self) -> None:
        if self._conn:
            try:
                _trace_event("snowflake.close.start")
                self._conn.close()
                _trace_event("snowflake.close.success")
            except Exception:
                pass
            self._conn = None

    def query(self, sql: str, params=None) -> List[Dict[str, Any]]:
        _trace_event("snowflake.query.start", sql=_sql_preview(sql), has_params=params is not None)
        cur = self._conn.cursor()
        try:
            cur.execute(sql, params)
            if cur.description is None:
                _trace_event("snowflake.query.success", sql=_sql_preview(sql), row_count=0, has_description=False)
                return []
            cols = [d[0].upper() for d in cur.description]
            rows = [dict(zip(cols, row)) for row in cur.fetchall()]
            _trace_event("snowflake.query.success", sql=_sql_preview(sql), row_count=len(rows), has_description=True)
            return rows
        except Exception as exc:
            _trace_event("snowflake.query.error", sql=_sql_preview(sql), error=exc)
            raise
        finally:
            cur.close()

    def execute(self, sql: str) -> None:
        _trace_event("snowflake.execute.start", sql=_sql_preview(sql))
        cur = self._conn.cursor()
        try:
            cur.execute(sql)
            _trace_event("snowflake.execute.success", sql=_sql_preview(sql))
        except Exception as exc:
            _trace_event("snowflake.execute.error", sql=_sql_preview(sql), error=exc)
            raise
        finally:
            cur.close()


def _ts() -> str:
    return datetime.now().isoformat()


def _ok(**kw: Any) -> Dict[str, Any]:
    return {"status": "success", "timestamp": _ts(), **kw}


def _err(message: str, **kw: Any) -> Dict[str, Any]:
    return {"status": "error", "message": _sanitize(message), "timestamp": _ts(), **kw}


def _sanitize(text: str) -> str:
    """Remove credential values from error messages."""
    s = str(text)
    for val in [
        os.getenv("SDG_SNOWFLAKE_PASSWORD", ""),
        os.getenv("SDG_SNOWFLAKE_USER", ""),
        os.getenv("SDG_SNOWFLAKE_ACCOUNT", ""),
    ]:
        if val:
            s = s.replace(val, "***")
    return s[:500]


_preload_snowflake_modules()


# ---------------------------------------------------------------------------
# Tool 1: Validate connection
# ---------------------------------------------------------------------------

@sdg_snowflake_mcp.tool()
def sdg_validate_connection() -> Dict[str, Any]:
    """Validate SDG_SNOWFLAKE_* credentials and confirm Snowflake connectivity.

    Returns a success/error dict. Call this first to confirm the environment
    is correctly configured before running sdg_list_tables or sdg_extract_schema_and_samples.
    """
    _trace_event("tool.sdg_validate_connection.enter")
    conn = _SDGSnowflakeConn()
    missing = conn.missing_vars()
    if missing:
        _trace_event("tool.sdg_validate_connection.exit", status="error", last_step="missing_vars", missing=missing)
        return _err(f"Missing environment variables: {', '.join(missing)}")
    try:
        conn.connect()
        _trace_event("tool.sdg_validate_connection.step", last_step="connect")
        rows = conn.query("SELECT CURRENT_DATABASE(), CURRENT_SCHEMA(), CURRENT_WAREHOUSE(), CURRENT_ROLE()")
        _trace_event("tool.sdg_validate_connection.step", last_step="current_context_query", row_count=len(rows))
        info = rows[0] if rows else {}
        conn.close()
        result = _ok(
            message="Snowflake connection successful",
            database=info.get("CURRENT_DATABASE()") or conn.database,
            schema=info.get("CURRENT_SCHEMA()") or conn.schema,
            warehouse=info.get("CURRENT_WAREHOUSE()") or conn.warehouse,
            role=info.get("CURRENT_ROLE()") or conn.role,
        )
        _trace_event("tool.sdg_validate_connection.exit", status="success", last_step="close")
        return result
    except Exception as exc:
        conn.close()
        _trace_event("tool.sdg_validate_connection.exit", status="error", last_step="exception", error=exc)
        return _err(f"Connection failed: {exc}")


# ---------------------------------------------------------------------------
# Tool 2: List tables
# ---------------------------------------------------------------------------

@sdg_snowflake_mcp.tool()
def sdg_list_tables(database: str = "", schema: str = "") -> Dict[str, Any]:
    """List all base tables in a Snowflake database/schema with their row counts.

    Args:
        database: Snowflake database name (defaults to SDG_SNOWFLAKE_DATABASE).
        schema:   Snowflake schema name  (defaults to SDG_SNOWFLAKE_SCHEMA).

    Returns:
        dict with 'tables' list — each entry has 'table_name' and 'row_count'.
    """
    _trace_event("tool.sdg_list_tables.enter", database=database, schema=schema)
    conn = _SDGSnowflakeConn()
    missing = conn.missing_vars()
    if missing:
        _trace_event("tool.sdg_list_tables.exit", status="error", last_step="missing_vars", missing=missing)
        return _err(f"Missing environment variables: {', '.join(missing)}")

    db = (database or conn.database).strip().upper()
    sc = (schema or conn.schema).strip().upper()

    if not db:
        _trace_event("tool.sdg_list_tables.exit", status="error", last_step="missing_database")
        return _err("database is required (or set SDG_SNOWFLAKE_DATABASE)")

    try:
        conn.connect()
        _trace_event("tool.sdg_list_tables.step", last_step="connect", database=db, schema=sc)
        rows = conn.query(
            f"SELECT TABLE_NAME, ROW_COUNT "
            f"FROM {db}.INFORMATION_SCHEMA.TABLES "
            f"WHERE TABLE_SCHEMA = '{sc}' AND TABLE_TYPE = 'BASE TABLE' "
            f"ORDER BY TABLE_NAME"
        )
        _trace_event("tool.sdg_list_tables.step", last_step="table_query", row_count=len(rows))
        conn.close()
        tables = [
            {"table_name": r["TABLE_NAME"], "row_count": int(r.get("ROW_COUNT") or 0)}
            for r in rows
        ]
        result = _ok(database=db, schema=sc, table_count=len(tables), tables=tables)
        _trace_event("tool.sdg_list_tables.exit", status="success", last_step="close", table_count=len(tables))
        return result
    except Exception as exc:
        conn.close()
        _trace_event("tool.sdg_list_tables.exit", status="error", last_step="exception", error=exc)
        return _err(f"Failed to list tables: {exc}")


# ---------------------------------------------------------------------------
# Tool 3: Extract schema + samples → write session inputs/
# ---------------------------------------------------------------------------

@sdg_snowflake_mcp.tool()
def sdg_extract_schema_and_samples(
    tables_json: str,
    row_counts_json: str,
    session_id: str,
    sample_size: int = 10000,
    database: str = "",
    schema: str = "",
) -> Dict[str, Any]:
    """Extract schema metadata and sample rows from Snowflake for selected tables.

    Writes files to session_storage/{session_id}/inputs/ so that
    SyntheticDataTool.execute_generation() can run without any changes:
      - requirements.csv        (table_name, row_count)
      - <TABLE_NAME>.csv        (sample rows — used for ML pattern learning)

    Args:
        tables_json:    JSON array of table names, e.g. '["ORDERS","CUSTOMERS"]'.
        row_counts_json: JSON object mapping table to desired synthetic row count,
                         e.g. '{"ORDERS": 5000, "CUSTOMERS": 1000}'.
        session_id:     DAAN session UUID — determines where files are written.
        sample_size:    Max rows to fetch per table for ML training (default 10000).
        database:       Snowflake database (defaults to SDG_SNOWFLAKE_DATABASE).
        schema:         Snowflake schema   (defaults to SDG_SNOWFLAKE_SCHEMA).

    Returns:
        dict with status, inputs_dir, tables_written list.
    """
    _trace_event(
        "tool.sdg_extract_schema_and_samples.enter",
        session_id=session_id,
        sample_size=sample_size,
        database=database,
        schema=schema,
    )
    # Parse inputs
    try:
        tables: List[str] = json.loads(tables_json)
        row_counts: Dict[str, int] = json.loads(row_counts_json)
    except (json.JSONDecodeError, TypeError) as exc:
        _trace_event("tool.sdg_extract_schema_and_samples.exit", status="error", last_step="parse_inputs", error=exc)
        return _err(f"Invalid JSON arguments: {exc}")

    if not tables:
        _trace_event("tool.sdg_extract_schema_and_samples.exit", status="error", last_step="validate_tables")
        return _err("tables_json must be a non-empty array")
    if not session_id or not session_id.strip():
        _trace_event("tool.sdg_extract_schema_and_samples.exit", status="error", last_step="validate_session_id")
        return _err("session_id is required")

    conn = _SDGSnowflakeConn()
    missing = conn.missing_vars()
    if missing:
        _trace_event("tool.sdg_extract_schema_and_samples.exit", status="error", last_step="missing_vars", missing=missing)
        return _err(f"Missing environment variables: {', '.join(missing)}")

    db = (database or conn.database).strip().upper()
    sc = (schema or conn.schema).strip().upper()

    if not db:
        _trace_event("tool.sdg_extract_schema_and_samples.exit", status="error", last_step="missing_database")
        return _err("database is required (or set SDG_SNOWFLAKE_DATABASE)")

    # Prepare inputs directory
    inputs_dir = _session_inputs_dir(session_id.strip())
    inputs_dir.mkdir(parents=True, exist_ok=True)
    _trace_event("tool.sdg_extract_schema_and_samples.step", last_step="inputs_dir_ready", inputs_dir=inputs_dir)

    try:
        conn.connect()
        _trace_event("tool.sdg_extract_schema_and_samples.step", last_step="connect", database=db, schema=sc)
        tables_written: List[str] = []

        for table_name in tables:
            tbl = table_name.strip().upper()
            try:
                _trace_event("tool.sdg_extract_schema_and_samples.step", last_step="extract_table_start", table=tbl)
                _extract_single_table(conn, db, sc, tbl, sample_size, inputs_dir, row_counts)
                tables_written.append(tbl)
                _trace_event("tool.sdg_extract_schema_and_samples.step", last_step="extract_table_done", table=tbl)
                logger.info("Extracted %s → %s", tbl, inputs_dir)
            except Exception as exc:
                logger.error("Failed to extract table %s: %s", tbl, exc)
                _trace_event(
                    "tool.sdg_extract_schema_and_samples.exit",
                    status="error",
                    last_step="extract_table_failed",
                    table=tbl,
                    error=exc,
                    tables_written=tables_written,
                )
                return _err(f"Failed to extract table {tbl}: {exc}", tables_written=tables_written)

        # Write requirements.csv
        req_path = inputs_dir / "requirements.csv"
        with req_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["table_name", "row_count"])
            for tbl in tables_written:
                row_count = (
                    row_counts.get(tbl)
                    or row_counts.get(tbl.upper())
                    or row_counts.get(tbl.lower())
                    or 1000
                )
                writer.writerow([tbl, row_count])
        _trace_event("tool.sdg_extract_schema_and_samples.step", last_step="requirements_csv_written", requirements_csv=req_path)

        conn.close()
        result = _ok(
            inputs_dir=str(inputs_dir),
            tables_written=tables_written,
            requirements_csv=str(req_path),
            message=(
                f"Extracted {len(tables_written)} table(s) to {inputs_dir}. "
                "Ready for SnowflakeSyntheticDataTool.execute_generation()."
            ),
        )
        _trace_event(
            "tool.sdg_extract_schema_and_samples.exit",
            status="success",
            last_step="close",
            tables_written=tables_written,
        )
        return result

    except Exception as exc:
        conn.close()
        _trace_event("tool.sdg_extract_schema_and_samples.exit", status="error", last_step="exception", error=exc)
        return _err(f"Extraction failed: {exc}")


def _extract_single_table(
    conn: _SDGSnowflakeConn,
    db: str,
    sc: str,
    table_name: str,
    sample_size: int,
    inputs_dir: Path,
    row_counts: Dict[str, int],
) -> None:
    """Fetch sample rows for one table and write <TABLE_NAME>.csv to inputs_dir."""
    _trace_event("tool.sdg_extract_single_table.enter", table=table_name, database=db, schema=sc, sample_size=sample_size)

    # Fetch column list first so we know what exists
    col_rows = conn.query(
        f"SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, ORDINAL_POSITION "
        f"FROM {db}.INFORMATION_SCHEMA.COLUMNS "
        f"WHERE TABLE_SCHEMA = '{sc}' AND TABLE_NAME = '{table_name}' "
        f"ORDER BY ORDINAL_POSITION"
    )
    _trace_event("tool.sdg_extract_single_table.step", table=table_name, last_step="column_query", row_count=len(col_rows))
    if not col_rows:
        raise ValueError(f"No columns found for {sc}.{table_name} in {db}")

    column_names = [r["COLUMN_NAME"] for r in col_rows]

    # Sample rows
    quoted_cols = ", ".join(f'"{c}"' for c in column_names)
    sample_rows = conn.query(
        f'SELECT {quoted_cols} FROM "{db}"."{sc}"."{table_name}" LIMIT {sample_size}'
    )
    _trace_event("tool.sdg_extract_single_table.step", table=table_name, last_step="sample_query", row_count=len(sample_rows))

    # Write CSV
    csv_path = inputs_dir / f"{table_name}.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=column_names)
        writer.writeheader()
        for row in sample_rows:
            # Normalise key casing — Snowflake returns uppercase column names
            normalised = {c: row.get(c, row.get(c.upper(), "")) for c in column_names}
            writer.writerow(normalised)
    _trace_event("tool.sdg_extract_single_table.exit", table=table_name, last_step="csv_written", csv_path=csv_path)


# ---------------------------------------------------------------------------
# Tool 4: Upload synthetic data to Snowflake
# ---------------------------------------------------------------------------

@sdg_snowflake_mcp.tool()
def sdg_upload_synthetic_data(
    session_id: str,
    target_db: str = "",
    target_schema: str = "PUBLIC",
) -> Dict[str, Any]:
    """Upload generated synthetic CSVs from session storage to Snowflake.

    Reads CSVs from session_storage/{session_id}/sdg/output/SDV/output/
    (the same directory SyntheticDataTool writes to) and bulk-uploads them
    to a target Snowflake database (default: <SOURCE_DB>_SYNTHETIC).

    Args:
        session_id:    DAAN session UUID.
        target_db:     Destination database name. Defaults to <SDG_SNOWFLAKE_DATABASE>_SYNTHETIC.
        target_schema: Destination schema name.  Defaults to PUBLIC.

    Returns:
        dict with status, tables_uploaded, rows_uploaded per table.
    """
    _trace_event("tool.sdg_upload_synthetic_data.enter", session_id=session_id, target_db=target_db, target_schema=target_schema)
    if not session_id or not session_id.strip():
        _trace_event("tool.sdg_upload_synthetic_data.exit", status="error", last_step="validate_session_id")
        return _err("session_id is required")

    conn = _SDGSnowflakeConn()
    missing = conn.missing_vars()
    if missing:
        _trace_event("tool.sdg_upload_synthetic_data.exit", status="error", last_step="missing_vars", missing=missing)
        return _err(f"Missing environment variables: {', '.join(missing)}")

    output_dir = _session_sdg_output_dir(session_id.strip())
    if not output_dir.exists():
        _trace_event("tool.sdg_upload_synthetic_data.exit", status="error", last_step="missing_output_dir", output_dir=output_dir)
        return _err(
            f"Output directory not found: {output_dir}. "
            "Run SyntheticDataTool.execute_generation() first."
        )

    csv_files = list(output_dir.glob("*.csv"))
    if not csv_files:
        _trace_event("tool.sdg_upload_synthetic_data.exit", status="error", last_step="missing_csv_files", output_dir=output_dir)
        return _err(f"No CSV files found in {output_dir}")

    dest_db = (target_db or f"{conn.database}_SYNTHETIC").strip().upper()
    dest_sc = (target_schema or "PUBLIC").strip().upper()

    try:
        import pandas as pd
    except ImportError as exc:
        _trace_event("tool.sdg_upload_synthetic_data.exit", status="error", last_step="import_pandas", error=exc)
        return _err(f"Required package not available: {exc}")

    if _SNOWFLAKE_WRITE_PANDAS_IMPORT_ERROR is not None:
        _trace_event(
            "tool.sdg_upload_synthetic_data.exit",
            status="error",
            last_step="import_write_pandas",
            error=_SNOWFLAKE_WRITE_PANDAS_IMPORT_ERROR,
        )
        return _err(f"Required package not available: {_SNOWFLAKE_WRITE_PANDAS_IMPORT_ERROR}")
    if _SNOWFLAKE_WRITE_PANDAS is None:
        _trace_event(
            "tool.sdg_upload_synthetic_data.exit",
            status="error",
            last_step="import_write_pandas",
            error="write_pandas did not initialize",
        )
        return _err("Required package not available: write_pandas did not initialize")

    try:
        conn.connect()
        _trace_event("tool.sdg_upload_synthetic_data.step", last_step="connect", dest_db=dest_db, dest_schema=dest_sc)

        # Create database + schema if they do not exist
        conn.execute(f'CREATE DATABASE IF NOT EXISTS "{dest_db}"')
        conn.execute(f'CREATE SCHEMA IF NOT EXISTS "{dest_db}"."{dest_sc}"')
        conn.execute(f'USE DATABASE "{dest_db}"')
        conn.execute(f'USE SCHEMA "{dest_sc}"')
        _trace_event("tool.sdg_upload_synthetic_data.step", last_step="destination_prepared", csv_count=len(csv_files))

        tables_uploaded: List[Dict[str, Any]] = []

        for csv_path in sorted(csv_files):
            source_table_name = csv_path.stem.upper()
            target_table_name = f"{source_table_name}{_SYNTHETIC_TABLE_SUFFIX}"
            try:
                _trace_event(
                    "tool.sdg_upload_synthetic_data.step",
                    last_step="upload_table_start",
                    source_table=source_table_name,
                    target_table=target_table_name,
                    csv_path=csv_path,
                )
                df = pd.read_csv(csv_path)
                # write_pandas requires the connection object directly
                success, nchunks, nrows, _ = _SNOWFLAKE_WRITE_PANDAS(
                    conn=conn._conn,
                    df=df,
                    table_name=target_table_name,
                    database=dest_db,
                    schema=dest_sc,
                    auto_create_table=True,
                    overwrite=True,
                    quote_identifiers=False,
                )
                _trace_event(
                    "tool.sdg_upload_synthetic_data.step",
                    last_step="upload_table_done",
                    source_table=source_table_name,
                    target_table=target_table_name,
                    success=success,
                    nchunks=nchunks,
                    nrows=nrows,
                )
                tables_uploaded.append({
                    "source_table": source_table_name,
                    "target_table": target_table_name,
                    "rows": nrows,
                    "chunks": nchunks,
                    "success": success,
                })
                logger.info("Uploaded %s → %s.%s.%s (%d rows)", csv_path.name, dest_db, dest_sc, target_table_name, nrows)
            except Exception as exc:
                logger.error("Failed to upload %s: %s", target_table_name, exc)
                _trace_event(
                    "tool.sdg_upload_synthetic_data.exit",
                    status="error",
                    last_step="upload_table_failed",
                    source_table=source_table_name,
                    target_table=target_table_name,
                    error=exc,
                )
                conn.close()
                return _err(
                    f"Upload failed for table {target_table_name}: {exc}",
                    tables_uploaded=tables_uploaded,
                )

        conn.close()
        total_rows = sum(t["rows"] for t in tables_uploaded)
        result = _ok(
            message=f"Uploaded {len(tables_uploaded)} table(s) ({total_rows} total rows) to {dest_db}.{dest_sc}",
            target_database=dest_db,
            target_schema=dest_sc,
            tables_uploaded=tables_uploaded,
            total_rows=total_rows,
        )
        _trace_event("tool.sdg_upload_synthetic_data.exit", status="success", last_step="close", table_count=len(tables_uploaded), total_rows=total_rows)
        return result

    except Exception as exc:
        conn.close()
        _trace_event("tool.sdg_upload_synthetic_data.exit", status="error", last_step="exception", error=exc)
        return _err(f"Upload failed: {exc}")
