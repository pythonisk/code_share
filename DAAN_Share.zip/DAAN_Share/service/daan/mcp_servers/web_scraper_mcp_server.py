"""
Web Scraper MCP Server - HTML Newsroom & Link Utilities
Scrapes dated items from HTML newsroom listing pages using per-site CSS selectors,
resolves and verifies canonical links, and checks for paywall responses.
No credentials required.
"""

import hashlib
import logging
import urllib.parse
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
from typing import Any

import requests
from mcp.server.fastmcp import FastMCP

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

mcp = FastMCP("Web Scraper MCP Server", "1.0.0")

_DEFAULT_TIMEOUT = 20
_DEFAULT_USER_AGENT = "DAAN-NewsletterBot/1.0 (internal; polite crawler)"
_MAX_EXCERPT_CHARS = 500
_DEFAULT_LOOKBACK_DAYS = 30
_PAYWALL_STATUS_CODES = {402, 403, 401}
_PAYWALL_URL_SIGNALS = {"paywall", "subscribe", "subscription", "premium", "login-required"}

try:
    from bs4 import BeautifulSoup
    _BS4_AVAILABLE = True
except ImportError:
    _BS4_AVAILABLE = False
    logger.warning("beautifulsoup4 not installed — HTML scraping tools will be unavailable")


def _bs4_required() -> dict:
    return {"success": False, "error": "beautifulsoup4 is not installed. Run: pip install beautifulsoup4"}


def _strip_tracking_params(url: str) -> str:
    _TRACKING = {"utm_source", "utm_medium", "utm_campaign", "utm_content",
                 "utm_term", "ref", "referrer", "source"}
    try:
        parsed = urllib.parse.urlparse(url)
        qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        clean_qs = {k: v for k, v in qs.items() if k.lower() not in _TRACKING}
        clean = parsed._replace(query=urllib.parse.urlencode(clean_qs, doseq=True))
        return urllib.parse.urlunparse(clean)
    except Exception:
        return url


def _absolute_url(base: str, href: str) -> str:
    if not href:
        return ""
    return urllib.parse.urljoin(base, href)


def _parse_date(raw: str | None) -> str | None:
    """Parse common date string formats into UTC ISO 8601. Returns None on failure."""
    if not raw:
        return None
    raw = raw.strip()
    for fmt in (
        "%B %d, %Y", "%b %d, %Y", "%d %B %Y", "%d %b %Y",
        "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y",
    ):
        try:
            dt = datetime.strptime(raw, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc).isoformat()
        except ValueError:
            pass
    try:
        from email.utils import parsedate_to_datetime
        dt = parsedate_to_datetime(raw)
        return dt.astimezone(timezone.utc).isoformat()
    except Exception:
        return None


def _content_hash(url: str, title: str) -> str:
    return hashlib.sha256(f"{url}|{title}".encode()).hexdigest()[:16]


def _fetch_html(url: str) -> dict[str, Any]:
    """GET a page and return structured fetch metadata without raising."""
    try:
        resp = requests.get(
            url,
            headers={"User-Agent": _DEFAULT_USER_AGENT},
            timeout=_DEFAULT_TIMEOUT,
            allow_redirects=True,
            verify=False,
        )
        status_code = int(resp.status_code)
        final_url = str(resp.url or url)
        if status_code == 200:
            return {
                "success": True,
                "html": resp.text,
                "final_url": final_url,
                "status_code": status_code,
                "error": None,
            }
        return {
            "success": False,
            "html": None,
            "final_url": final_url,
            "status_code": status_code,
            "error": f"HTTP {status_code}",
        }
    except requests.exceptions.RequestException as exc:
        logger.warning("fetch_html failed url=%s error=%s", url, exc)
        return {
            "success": False,
            "html": None,
            "final_url": url,
            "status_code": None,
            "error": str(exc),
        }


def _is_paywall(url: str, status_code: int, final_url: str) -> bool:
    if status_code in _PAYWALL_STATUS_CODES:
        return True
    combined = (url + final_url).lower()
    return any(sig in combined for sig in _PAYWALL_URL_SIGNALS)


# ── MCP Tools ─────────────────────────────────────────────────────────────────

@mcp.tool()
def scrape_newsroom(
    listing_url: str,
    source_id: str,
    source_category: str,
    item_selector: str,
    title_selector: str,
    date_selector: str,
    link_selector: str,
    date_from: str | None = None,
    date_to: str | None = None,
    date_attr: str | None = None,
    link_attr: str = "href",
    section_hint: str | None = None,
    source_weight: float = 1.0,
    paywall: bool = False,
    max_items_per_source: int = 25,
) -> dict[str, Any]:
    """
    Scrape a newsroom listing page and return normalised 13-field items within a date window.

    Per-site selectors keep layout logic in configuration, not in agent prompts.
    All selectors are CSS selectors interpreted by BeautifulSoup.

    Args:
        listing_url: URL of the newsroom index/listing page.
        source_id: Stable source key (e.g. 'accenture_newsroom').
        source_category: One of: platform_vendor, competitor, analyst, trade_press.
        item_selector: CSS selector that matches each news item container.
        title_selector: CSS selector for the headline, relative to item container.
        date_selector: CSS selector for the date element, relative to item container.
        link_selector: CSS selector for the anchor tag, relative to item container.
        date_from: ISO 8601 start date. Defaults to 30 days ago.
        date_to: ISO 8601 end date. Defaults to now.
        date_attr: If set, read the date from this HTML attribute instead of text.
        link_attr: Attribute on the link element that holds the URL (default: href).
        section_hint: Optional newsletter section name to attach to every item.
        source_weight: Editorial weight for this source (default 1.0).
        paywall: Whether this source is paywalled (default false).
        max_items_per_source: Cap per source, keeping most recent (default 25).
    """
    if not _BS4_AVAILABLE:
        return _bs4_required()

    now = datetime.now(timezone.utc)
    try:
        df = datetime.fromisoformat(date_from).astimezone(timezone.utc) if date_from \
            else now - timedelta(days=_DEFAULT_LOOKBACK_DAYS)
        dt = datetime.fromisoformat(date_to).astimezone(timezone.utc) if date_to else now
    except ValueError as exc:
        return {"success": False, "items": [], "error": f"Invalid date: {exc}"}

    fetch_result = _fetch_html(listing_url)
    html = fetch_result.get("html")
    final_url = str(fetch_result.get("final_url") or listing_url)
    if html is None:
        return {
            "success": False,
            "items": [],
            "error": str(fetch_result.get("error") or f"Failed to fetch {listing_url}"),
        }

    soup = BeautifulSoup(html, "html.parser")
    containers = soup.select(item_selector)

    if not containers:
        # Detect JS-rendered pages by checking for common framework markers
        js_hints = []
        root_el = soup.select_one("#__next") or soup.select_one("#app") or soup.select_one("#root")
        if root_el and len(root_el.get_text(strip=True)) < 50:
            js_hints.append("empty React/Vue/Next.js mount point detected")
        noscript_el = soup.select_one("noscript")
        if noscript_el and "javascript" in noscript_el.get_text().lower():
            js_hints.append("<noscript> tag mentions JavaScript requirement")

        warning = f"No elements matched item_selector='{item_selector}'. "
        if js_hints:
            warning += f"Page likely requires JavaScript rendering ({'; '.join(js_hints)}). "
            warning += "Consider using the RSS feed for this source instead."
        else:
            warning += "Check the selector or whether the page uses JavaScript rendering."

        return {
            "success": True,
            "items": [],
            "item_count": 0,
            "skipped": True,
            "warning": warning,
            "js_rendered_likely": bool(js_hints),
        }

    items = []
    for container in containers:
        title_el = container.select_one(title_selector)
        date_el = container.select_one(date_selector)
        link_el = container.select_one(link_selector)

        if not title_el or not date_el:
            continue

        title = title_el.get_text(strip=True)
        date_raw = date_el.get(date_attr) if date_attr else date_el.get_text(strip=True)
        now_utc = datetime.now(timezone.utc)
        pub_iso = _parse_date(date_raw)
        if pub_iso:
            pub_dt = datetime.fromisoformat(pub_iso)
            if pub_dt < df or pub_dt > dt:
                continue
            date_confidence = "high"
        else:
            # Spec: never discard for missing date; fall back to retrieved_at
            pub_iso = now_utc.isoformat()
            date_confidence = "low"

        href = (link_el.get(link_attr) or "") if link_el else ""
        canonical = _strip_tracking_params(_absolute_url(final_url, href))

        excerpt = ""
        # try a sibling paragraph for excerpt
        excerpt_el = container.select_one("p")
        if excerpt_el:
            excerpt = excerpt_el.get_text(strip=True)[:_MAX_EXCERPT_CHARS]

        items.append({
            "source_id": source_id,
            "source_category": source_category,
            "publisher": source_id,
            "title": title,
            "published_at": pub_iso,
            "canonical_url": canonical,
            "excerpt": excerpt,
            "retrieved_at": datetime.now(timezone.utc).isoformat(),
            "content_hash": _content_hash(canonical, title),
            "section_hint": section_hint,
            "date_confidence": date_confidence,
            "paywall": paywall,
            "source_weight": source_weight,
        })

    # Cap per source, keeping most recent
    if len(items) > max_items_per_source:
        items.sort(key=lambda x: x["published_at"], reverse=True)
        items = items[:max_items_per_source]

    logger.info("scrape_newsroom source=%s items=%d", source_id, len(items))
    return {"success": True, "items": items, "item_count": len(items)}


@mcp.tool()
def fetch_link_excerpt(
    url: str,
    excerpt_selector: str | None = None,
) -> dict[str, Any]:
    """
    Fetch the opening text from a news article URL to use as excerpt.

    Follows the article link returned by scrape_newsroom and extracts the first
    paragraph(s), up to 500 characters. Useful when the listing page provides
    no excerpt.

    Args:
        url: Canonical article URL.
        excerpt_selector: CSS selector for the body text element.
                          Defaults to the first <p> inside <article> or <main>.
    """
    if not _BS4_AVAILABLE:
        return _bs4_required()

    fetch_result = _fetch_html(url)
    html = fetch_result.get("html")
    final_url = str(fetch_result.get("final_url") or url)
    if html is None:
        return {"success": False, "excerpt": "", "error": f"Failed to fetch {url}"}

    soup = BeautifulSoup(html, "html.parser")

    if excerpt_selector:
        el = soup.select_one(excerpt_selector)
        text = el.get_text(strip=True) if el else ""
    else:
        # prefer article > p, then main > p, then first body p
        for scope in ("article p", "main p", "p"):
            el = soup.select_one(scope)
            if el:
                text = el.get_text(strip=True)
                break
        else:
            text = ""

    return {
        "success": True,
        "excerpt": text[:_MAX_EXCERPT_CHARS],
        "final_url": _strip_tracking_params(final_url),
    }


@mcp.tool()
def verify_link(url: str) -> dict[str, Any]:
    """
    HEAD-check a URL and report reachability, final URL, and paywall status.

    Used by the Classifier agent to filter out paywalled or broken links
    before items reach the Summariser.

    Args:
        url: The canonical URL to check.
    """
    try:
        resp = requests.head(
            url,
            allow_redirects=True,
            timeout=_DEFAULT_TIMEOUT,
            verify=False,
            headers={"User-Agent": _DEFAULT_USER_AGENT},
        )
        status = resp.status_code
        final_url = _strip_tracking_params(resp.url)
        paywall = _is_paywall(url, status, final_url)
        return {
            "success": True,
            "reachable": status < 400,
            "status_code": status,
            "final_url": final_url,
            "paywall": paywall,
            "url": url,
        }
    except requests.exceptions.RequestException as exc:
        return {
            "success": False,
            "reachable": False,
            "status_code": None,
            "final_url": url,
            "paywall": False,
            "error": str(exc),
            "url": url,
        }


@mcp.tool()
def verify_links_batch(urls: list[str]) -> dict[str, Any]:
    """
    HEAD-check multiple URLs in parallel and return reachability and paywall status for each.

    Args:
        urls: List of canonical URLs to check.
    """
    results: list[dict] = [None] * len(urls)  # type: ignore[list-item]

    def _check(idx: int, url: str) -> tuple[int, dict]:
        return idx, verify_link(url)

    with ThreadPoolExecutor(max_workers=min(10, len(urls) or 1)) as pool:
        futures = {pool.submit(_check, i, u): i for i, u in enumerate(urls)}
        for future in as_completed(futures):
            idx, result = future.result()
            results[idx] = result

    reachable_count = sum(1 for r in results if r.get("reachable"))
    paywall_count = sum(1 for r in results if r.get("paywall"))

    return {
        "success": True,
        "results": results,
        "total": len(urls),
        "reachable_count": reachable_count,
        "paywall_count": paywall_count,
        "unreachable_count": len(urls) - reachable_count,
    }


@mcp.tool()
def discover_feed_from_page(page_url: str) -> dict[str, Any]:
    """
    Discover RSS or Atom feed URLs advertised in a page's <link> tags.

    Useful for finding the real feed address from a feed hub page (e.g. Register C).

    Args:
        page_url: URL of the HTML page to inspect for feed autodiscovery links.
    """
    if not _BS4_AVAILABLE:
        return _bs4_required()

    fetch_result = _fetch_html(page_url)
    html = fetch_result.get("html")
    final_url = str(fetch_result.get("final_url") or page_url)
    if html is None:
        return {
            "success": False,
            "feeds": [],
            "error": str(fetch_result.get("error") or f"Failed to fetch {page_url}"),
        }

    soup = BeautifulSoup(html, "html.parser")
    feeds = []

    # Standard <link rel="alternate" type="application/rss+xml"> autodiscovery
    for link in soup.find_all("link", rel="alternate"):
        link_type = link.get("type", "")
        if "rss" in link_type or "atom" in link_type:
            href = link.get("href", "")
            if href:
                feeds.append({
                    "url": _absolute_url(final_url, href),
                    "title": link.get("title", ""),
                    "type": link_type,
                    "source": "link_autodiscovery",
                })

    # Also scan anchor hrefs for obvious feed paths
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if any(sig in href.lower() for sig in ("/rss", "/feed", "/atom", ".rss", ".xml")):
            abs_href = _absolute_url(final_url, href)
            if not any(f["url"] == abs_href for f in feeds):
                feeds.append({
                    "url": abs_href,
                    "title": a.get_text(strip=True)[:100],
                    "type": "inferred_from_anchor",
                    "source": "anchor_scan",
                })

    logger.info("discover_feed_from_page url=%s feeds_found=%d", page_url, len(feeds))
    return {
        "success": True,
        "feeds": feeds,
        "feed_count": len(feeds),
        "page_url": final_url,
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")
