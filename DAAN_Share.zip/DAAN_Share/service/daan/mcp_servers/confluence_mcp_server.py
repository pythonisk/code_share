"""
Confluence MCP Server - Documentation and Page Management Operations
This module provides Model Context Protocol (MCP) server functionality for Confluence operations.
"""

import os
import json
import requests
from typing import Dict, List, Any, Optional
from datetime import datetime
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Initialize FastMCP server for Confluence
confluence_mcp = FastMCP("Confluence MCP Server", "1.0.0")

# Alias for generic MCP server launching
mcp = confluence_mcp


class ConfluenceConnection:
    """
    Manages Confluence API connections and operations.
    """
    
    def __init__(self):
        self.base_url = None
        self.username = None
        self.api_token = None
        self.headers = None
        
    def connect(self, base_url: str, username: str, api_token: str) -> Dict[str, Any]:
        """
        Establish connection to Confluence server.
        
        Args:
            base_url: Confluence server URL (e.g., 'https://yourcompany.atlassian.net/wiki')
            username: Username or email for authentication
            api_token: API token for authentication
            
        Returns:
            Dict containing connection status and details
        """
        try:
            # Store connection details
            self.base_url = base_url
            self.username = username
            self.api_token = api_token
            
            # Set up auth headers for REST API calls
            self.headers = {
                "Authorization": f"Basic {self._get_basic_auth(username, api_token)}",
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            
            # Test connection by fetching current user
            test_url = f"{self.base_url}/rest/api/user/current"
            response = requests.get(test_url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                logger.info(f"Connected to Confluence: {base_url}")
                return {
                    "status": "success",
                    "message": f"Connected to Confluence server: {base_url}",
                    "connection_details": {
                        "base_url": base_url,
                        "username": username
                    },
                    "timestamp": datetime.now().isoformat()
                }
            else:
                logger.error(f"Connection test failed: {response.status_code}")
                return {
                    "status": "error",
                    "message": f"Connection test failed: {response.status_code}",
                    "timestamp": datetime.now().isoformat()
                }
                
        except Exception as e:
            logger.error(f"Confluence connection failed: {str(e)}")
            return {
                "status": "error",
                "message": f"Failed to connect to Confluence: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def _get_basic_auth(self, username: str, api_token: str) -> str:
        """Generate Basic Auth header value."""
        import base64
        credentials = f"{username}:{api_token}"
        return base64.b64encode(credentials.encode()).decode()
    
    def create_page(self, space_key: str, title: str, content: str, 
                   parent_page_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a new Confluence page.
        
        Args:
            space_key: Confluence space key (e.g., 'DAAN')
            title: Page title
            content: Page content (can be plain text or XHTML)
            parent_page_id: Parent page ID for hierarchical pages (optional)
            
        Returns:
            Dict containing created page details
        """
        try:
            if not self.base_url or not self.headers:
                return {
                    "status": "error",
                    "message": "No active connection. Please connect first."
                }
            
            # Build page body
            page_body = {
                "type": "page",
                "title": title,
                "space": {"key": space_key},
                "body": {
                    "storage": {
                        "value": content,
                        "representation": "storage"
                    }
                }
            }
            
            # Add parent page if specified
            if parent_page_id:
                page_body["ancestors"] = [{"id": parent_page_id}]
            
            # Create the page
            url = f"{self.base_url}/rest/api/content"
            response = requests.post(url, json=page_body, headers=self.headers, timeout=10)
            
            if response.status_code in [200, 201]:
                page_data = response.json()
                page_id = page_data.get('id')
                page_url = f"{self.base_url}{page_data.get('_links', {}).get('webui', '')}"
                
                logger.info(f"Successfully created page: {title} (ID: {page_id})")
                
                return {
                    "status": "success",
                    "message": f"Page created successfully: {title}",
                    "page": {
                        "id": page_id,
                        "title": title,
                        "space_key": space_key,
                        "url": page_url
                    },
                    "timestamp": datetime.now().isoformat()
                }
            else:
                error_msg = response.text
                logger.error(f"Failed to create page: {error_msg}")
                return {
                    "status": "error",
                    "message": f"Failed to create page: {error_msg}",
                    "timestamp": datetime.now().isoformat()
                }
                
        except Exception as e:
            logger.error(f"Error creating page: {str(e)}")
            return {
                "status": "error",
                "message": f"Error creating page: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def update_page(self, page_id: str, title: str, content: str, version: int) -> Dict[str, Any]:
        """
        Update an existing Confluence page.
        
        Args:
            page_id: Confluence page ID
            title: New page title
            content: New page content
            version: Current version number (required for update)
            
        Returns:
            Dict containing updated page details
        """
        try:
            if not self.base_url or not self.headers:
                return {
                    "status": "error",
                    "message": "No active connection. Please connect first."
                }
            
            # Build update body
            update_body = {
                "type": "page",
                "title": title,
                "body": {
                    "storage": {
                        "value": content,
                        "representation": "storage"
                    }
                },
                "version": {
                    "number": version + 1
                }
            }
            
            # Update the page
            url = f"{self.base_url}/rest/api/content/{page_id}"
            response = requests.put(url, json=update_body, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                page_data = response.json()
                logger.info(f"Successfully updated page: {title} (ID: {page_id})")
                
                return {
                    "status": "success",
                    "message": f"Page updated successfully: {title}",
                    "page": {
                        "id": page_id,
                        "title": title,
                        "version": page_data.get('version', {}).get('number')
                    },
                    "timestamp": datetime.now().isoformat()
                }
            else:
                error_msg = response.text
                logger.error(f"Failed to update page: {error_msg}")
                return {
                    "status": "error",
                    "message": f"Failed to update page: {error_msg}",
                    "timestamp": datetime.now().isoformat()
                }
                
        except Exception as e:
            logger.error(f"Error updating page: {str(e)}")
            return {
                "status": "error",
                "message": f"Error updating page: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def get_page(self, page_id: str) -> Dict[str, Any]:
        """
        Retrieve details of a Confluence page.
        
        Args:
            page_id: Confluence page ID
            
        Returns:
            Dict containing page details
        """
        try:
            if not self.base_url or not self.headers:
                return {
                    "status": "error",
                    "message": "No active connection. Please connect first."
                }
            
            # Get the page
            url = f"{self.base_url}/rest/api/content/{page_id}?expand=body.storage,version"
            response = requests.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                page_data = response.json()
                logger.info(f"Successfully retrieved page: {page_data.get('title')}")
                
                return {
                    "status": "success",
                    "message": "Page retrieved successfully",
                    "page": {
                        "id": page_data.get('id'),
                        "title": page_data.get('title'),
                        "content": page_data.get('body', {}).get('storage', {}).get('value'),
                        "version": page_data.get('version', {}).get('number'),
                        "space_key": page_data.get('space', {}).get('key'),
                        "url": f"{self.base_url}{page_data.get('_links', {}).get('webui', '')}"
                    },
                    "timestamp": datetime.now().isoformat()
                }
            else:
                error_msg = response.text
                logger.error(f"Failed to get page: {error_msg}")
                return {
                    "status": "error",
                    "message": f"Failed to get page: {error_msg}",
                    "timestamp": datetime.now().isoformat()
                }
                
        except Exception as e:
            logger.error(f"Error retrieving page: {str(e)}")
            return {
                "status": "error",
                "message": f"Error retrieving page: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def search_pages(self, space_key: str, query: str, limit: int = 25) -> Dict[str, Any]:
        """
        Search for Confluence pages in a space.
        
        Args:
            space_key: Confluence space key
            query: Search query (e.g., 'title ~ "User Stories"')
            limit: Maximum number of results
            
        Returns:
            Dict containing search results
        """
        try:
            if not self.base_url or not self.headers:
                return {
                    "status": "error",
                    "message": "No active connection. Please connect first."
                }
            
            # Build CQL query
            cql = f'type=page AND space.key="{space_key}" AND {query}'
            
            # Search for pages
            url = f"{self.base_url}/rest/api/content/search?cql={cql}&limit={limit}"
            response = requests.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                results = response.json()
                pages = []
                for item in results.get('results', []):
                    pages.append({
                        "id": item.get('id'),
                        "title": item.get('title'),
                        "space_key": item.get('space', {}).get('key'),
                        "url": f"{self.base_url}{item.get('_links', {}).get('webui', '')}"
                    })
                
                logger.info(f"Found {len(pages)} pages matching query")
                
                return {
                    "status": "success",
                    "message": f"Found {len(pages)} pages",
                    "pages": pages,
                    "timestamp": datetime.now().isoformat()
                }
            else:
                error_msg = response.text
                logger.error(f"Search failed: {error_msg}")
                return {
                    "status": "error",
                    "message": f"Search failed: {error_msg}",
                    "timestamp": datetime.now().isoformat()
                }
                
        except Exception as e:
            logger.error(f"Error searching pages: {str(e)}")
            return {
                "status": "error",
                "message": f"Error searching pages: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def disconnect(self) -> Dict[str, Any]:
        """
        Close the Confluence connection.
        
        Returns:
            Dict containing disconnection status
        """
        try:
            self.base_url = None
            self.username = None
            self.api_token = None
            self.headers = None
            
            logger.info("Successfully disconnected from Confluence")
            
            return {
                "status": "success",
                "message": "Successfully disconnected from Confluence",
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error during disconnection: {str(e)}")
            return {
                "status": "error",
                "message": f"Error during disconnection: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }


# Global connection instance
_confluence_conn = ConfluenceConnection()


# ─────────────────────────────────────────────────────────────────
# MCP Tools for Confluence Operations
# ─────────────────────────────────────────────────────────────────

@confluence_mcp.tool()
def ConfluenceConnectTool(
    base_url: Optional[str] = None,
    username: Optional[str] = None,
    api_token: Optional[str] = None
) -> Dict[str, Any]:
    """
    Confluence Connection Tool - Establishes connection to Confluence server.
    
    Description:
    This tool connects to a Confluence server using the provided credentials (username and API token).
    It establishes a persistent connection for page management and documentation operations.
    
    Use this tool when you need to:
    - Connect to Confluence for documentation management
    - Establish a session for multiple Confluence operations
    - Initialize documentation workflows
    
    Arguments:
    - base_url (str): Confluence server URL (e.g., 'https://yourcompany.atlassian.net/wiki')
    - username (str): Username or email for authentication
    - api_token (str): API token for authentication
    
    Returns:
    - Dict[str, Any]: Connection status with server details
    
    Example:
        result = ConfluenceConnectTool(
            base_url="https://mycompany.atlassian.net/wiki",
            username="user@example.com",
            api_token="your_api_token_here"
        )
    """
    # Evaluate environment variables at call time
    if base_url is None:
        base_url = os.getenv("CONFLUENCE_BASE_URL", "")
    if username is None:
        username = os.getenv("CONFLUENCE_USERNAME") or os.getenv("JIRA_USERNAME", "")
    if api_token is None:
        api_token = os.getenv("CONFLUENCE_API_TOKEN") or os.getenv("JIRA_API_TOKEN", "")
    
    return _confluence_conn.connect(base_url, username, api_token)


@confluence_mcp.tool()
def ConfluenceCreatePageTool(
    space_key: str,
    title: str,
    content: str,
    parent_page_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Confluence Create Page Tool - Creates a new Confluence page.
    
    Description:
    This tool creates a new page in Confluence with the specified content.
    Supports hierarchical pages by specifying a parent page ID.
    
    Use this tool when you need to:
    - Create new documentation pages
    - Publish user stories or requirements
    - Create project documentation
    - Build knowledge base articles
    
    Arguments:
    - space_key (str): Confluence space key (e.g., 'DAAN', 'DOC')
    - title (str): Page title
    - content (str): Page content (plain text or XHTML/storage format)
    - parent_page_id (str, optional): Parent page ID for hierarchical pages
    
    Returns:
    - Dict[str, Any]: Created page details including ID and URL
    
    Example:
        result = ConfluenceCreatePageTool(
            space_key="DAAN",
            title="User Stories - Sprint 5",
            content="This page contains all user stories for Sprint 5..."
        )
    
    Note: Connection must be established using ConfluenceConnectTool before using this tool.
    """
    return _confluence_conn.create_page(space_key, title, content, parent_page_id)


@confluence_mcp.tool()
def ConfluenceUpdatePageTool(
    page_id: str,
    title: str,
    content: str,
    version: int
) -> Dict[str, Any]:
    """
    Confluence Update Page Tool - Updates an existing Confluence page.
    
    Description:
    This tool updates the content of an existing Confluence page.
    Requires the current version number to prevent conflicts.
    
    Use this tool when you need to:
    - Update existing documentation
    - Modify published content
    - Maintain living documentation
    
    Arguments:
    - page_id (str): Confluence page ID to update
    - title (str): New page title
    - content (str): New page content
    - version (int): Current version number (required for update)
    
    Returns:
    - Dict[str, Any]: Updated page details
    
    Example:
        result = ConfluenceUpdatePageTool(
            page_id="123456",
            title="User Stories - Sprint 5 (Updated)",
            content="Updated content here...",
            version=1
        )
    
    Note: Connection must be established using ConfluenceConnectTool before using this tool.
    """
    return _confluence_conn.update_page(page_id, title, content, version)


@confluence_mcp.tool()
def ConfluenceGetPageTool(page_id: str) -> Dict[str, Any]:
    """
    Confluence Get Page Tool - Retrieves details of a Confluence page.
    
    Description:
    This tool retrieves the full content and metadata of a Confluence page.
    
    Use this tool when you need to:
    - Retrieve existing page content
    - Get page details for updates
    - Access published documentation
    
    Arguments:
    - page_id (str): Confluence page ID
    
    Returns:
    - Dict[str, Any]: Page details including content, version, and URL
    
    Example:
        result = ConfluenceGetPageTool(page_id="123456")
    
    Note: Connection must be established using ConfluenceConnectTool before using this tool.
    """
    return _confluence_conn.get_page(page_id)


@confluence_mcp.tool()
def ConfluenceSearchPagesTool(
    space_key: str,
    query: str,
    limit: int = 25
) -> Dict[str, Any]:
    """
    Confluence Search Pages Tool - Searches for Confluence pages.
    
    Description:
    This tool searches for pages in a Confluence space using CQL queries.
    
    Use this tool when you need to:
    - Find existing documentation
    - Locate pages by title or content
    - Search for user stories or requirements
    
    Arguments:
    - space_key (str): Confluence space key to search in
    - query (str): Search query (e.g., 'title ~ "User Stories"' or 'text ~ "authentication"')
    - limit (int, optional): Maximum number of results (default: 25)
    
    Returns:
    - Dict[str, Any]: List of matching pages with IDs and URLs
    
    Example:
        result = ConfluenceSearchPagesTool(
            space_key="DAAN",
            query='title ~ "User Stories"',
            limit=10
        )
    
    Note: Connection must be established using ConfluenceConnectTool before using this tool.
    """
    return _confluence_conn.search_pages(space_key, query, limit)


@confluence_mcp.tool()
def ConfluenceDisconnectTool() -> Dict[str, Any]:
    """
    Confluence Disconnect Tool - Closes the Confluence connection.
    
    Description:
    This tool properly closes the active Confluence connection.
    
    Use this tool when you need to:
    - End a Confluence session
    - Clean up resources
    - Switch to a different connection
    
    Arguments:
    - None
    
    Returns:
    - Dict[str, Any]: Disconnection status
    
    Example:
        result = ConfluenceDisconnectTool()
    """
    return _confluence_conn.disconnect()


if __name__ == "__main__":
    logger.info("Starting Confluence MCP Server...")
    confluence_mcp.run(transport="stdio")
