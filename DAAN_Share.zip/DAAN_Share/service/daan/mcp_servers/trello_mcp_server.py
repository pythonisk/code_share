
"""
Trello MCP Server - Project Management and Board Operations
This module provides Model Context Protocol (MCP) server functionality for Trello operations.
"""

import os
import requests
import logging
import urllib3
from typing import Dict, Any, List, Optional
from datetime import datetime

# Suppress SSL warnings for corporate proxy environments
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from dotenv import find_dotenv, load_dotenv
from mcp.server.fastmcp import FastMCP

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

load_dotenv(find_dotenv(), verbose=True, override=True)

# Initialize FastMCP server for Trello
mcp = FastMCP("Trello MCP Server", "0.1.0")


class TrelloConnection:
    """
    Manages Trello API connections and operations.
    Encapsulates credentials and API interactions in a class-based architecture.
    """

    def __init__(self):
        """Initialize Trello connection with environment credentials."""
        self.api_key = None
        self.api_token = None
        self.board_id = None
        self.base_url = None
        self._full_board_id = None
        self._validate_and_load_credentials()

    def _validate_and_load_credentials(self) -> bool:
        """Load and validate Trello environment variables."""
        try:
            self.api_key = os.environ['TRELLO_API_KEY']
            self.api_token = os.environ['TRELLO_API_TOKEN']
            self.board_id = os.environ['TRELLO_BOARD_ID']
            self.base_url = os.getenv('DLAI_TRELLO_BASE_URL', 'https://api.trello.com')

            logger.debug(f"✅ Trello credentials loaded: KEY={self.api_key[:10]}..., TOKEN={self.api_token[:10]}..., BOARD_ID={self.board_id}")
            return True
        except KeyError as e:
            logger.error(f"❌ Missing environment variable: {e}")
            self.api_key = self.api_token = self.board_id = None
            return False

    def is_authenticated(self) -> bool:
        """Check if Trello credentials are properly loaded."""
        return all([self.api_key, self.api_token, self.board_id, self.base_url])

    def get_auth_params(self) -> dict:
        """Get authentication parameters for API requests."""
        return {
            'key': self.api_key,
            'token': self.api_token
        }

    def _make_request(self, url: str, method: str = 'GET', params: dict = None, data: dict = None) -> dict:
        """Make a Trello API request and return structured response."""
        if not self.is_authenticated():
            return {
                "success": False,
                "data": None,
                "error": "Missing Trello credentials",
                "message": "Please ensure TRELLO_API_KEY, TRELLO_API_TOKEN, and TRELLO_BOARD_ID are set."
            }

        try:
            # Add auth params to request
            if params is None:
                params = {}
            params.update(self.get_auth_params())

            # verify=False to handle corporate proxy/firewall SSL interception
            if method.upper() == 'GET':
                response = requests.get(url, params=params, timeout=10, verify=False)
            elif method.upper() == 'POST':
                response = requests.post(url, json=data, params=params, timeout=10, verify=False)
            elif method.upper() == 'PUT':
                response = requests.put(url, json=data, params=params, timeout=10, verify=False)
            else:
                return {"success": False, "data": None, "error": f"Unsupported HTTP method: {method}"}

            response.raise_for_status()
            return {
                "success": True,
                "data": response.json(),
                "error": None
            }
        except requests.exceptions.RequestException as e:
            error_detail = f"API request failed: {str(e)}"
            try:
                if hasattr(e, 'response') and hasattr(e.response, 'text'):
                    error_detail += f" | Response: {e.response.text[:200]}"
            except:
                pass
            logger.error(f"❌ Trello API Error: {error_detail}")
            return {
                "success": False,
                "data": None,
                "error": error_detail
            }

    def get_all_board_cards(self) -> dict:
        """Retrieve all cards from the project board."""
        url = f"{self.base_url}/1/boards/{self.board_id}/cards"
        params = {
            'fields': 'name,idList,due,dateLastActivity,labels,desc',
            'attachments': 'true',
            'actions': 'commentCard'
        }

        result = self._make_request(url, params=params)
        if result["success"]:
            return {
                "success": True,
                "data": {
                    "cards": result["data"],
                    "total_cards": len(result["data"])
                },
                "error": None,
                "message": f"Retrieved {len(result['data'])} cards from the board."
            }
        return {
            "success": False,
            "data": None,
            "error": result["error"],
            "message": "Failed to retrieve board cards."
        }

    def get_card_details(self, card_id: str) -> dict:
        """Retrieve detailed information about a specific card."""
        if not card_id:
            return {
                "success": False,
                "data": None,
                "error": "Missing required parameter: card_id",
                "message": "Please provide a valid card ID."
            }

        url = f"{self.base_url}/1/cards/{card_id}"
        result = self._make_request(url)

        if result["success"]:
            return {
                "success": True,
                "data": {"card": result["data"]},
                "error": None,
                "message": f"Retrieved details for card: {result['data'].get('name', 'Unknown')}"
            }
        return {
            "success": False,
            "data": None,
            "error": result["error"],
            "message": f"Failed to retrieve card details for ID: {card_id}"
        }

    def get_board_columns(self) -> dict:
        """Retrieve all available columns/lists from the project board."""
        url = f"{self.base_url}/1/boards/{self.board_id}/lists"
        params = {'fields': 'id,name,pos'}

        logger.debug(f"📍 GetBoardColumns: Calling {url}")
        result = self._make_request(url, params=params)

        if result["success"]:
            columns = [{"id": col["id"], "name": col["name"], "position": col["pos"]} for col in result["data"]]
            logger.info(f"✅ GetBoardColumns: Retrieved {len(columns)} columns")
            return {
                "success": True,
                "data": {
                    "columns": columns,
                    "total_columns": len(columns)
                },
                "error": None,
                "message": f"Found {len(columns)} columns on the board."
            }
        logger.error(f"❌ GetBoardColumns: {result['error']}")
        return {
            "success": False,
            "data": None,
            "error": result["error"],
            "message": f"Failed to retrieve board columns. Details: {result['error']}"
        }

    def create_board_card(self, title: str, description: str, column_name: str, due_date: str = None) -> dict:
        """Create a new card in the specified board column."""
        if not title or not description or not column_name:
            return {
                "success": False,
                "data": None,
                "error": "Missing required parameters",
                "message": "Please provide title, description, and column_name."
            }

        # Get column ID by name
        columns_result = self.get_board_columns()
        if not columns_result["success"]:
            return {
                "success": False,
                "data": None,
                "error": "Failed to retrieve board columns",
                "message": columns_result.get("message", "Unable to access board columns.")
            }

        # Find the target column
        target_column_id = None
        available_columns = []
        for column in columns_result["data"]["columns"]:
            available_columns.append(column["name"])
            if column["name"].lower() == column_name.lower():
                target_column_id = column["id"]
                break

        if not target_column_id:
            return {
                "success": False,
                "data": None,
                "error": f"Column '{column_name}' not found",
                "message": f"Available columns: {', '.join(available_columns)}"
            }

        # Prepare card data
        card_data = {
            'idList': target_column_id,
            'name': title,
            'desc': description
        }

        # Add due date if provided
        if due_date:
            try:
                due_datetime = datetime.strptime(due_date, "%Y-%m-%d")
                card_data['due'] = due_datetime.isoformat() + "Z"
            except ValueError:
                return {
                    "success": False,
                    "data": None,
                    "error": "Invalid due date format",
                    "message": "Due date must be in YYYY-MM-DD format (e.g., '2024-12-01')."
                }

        # Create the card
        url = f"{self.base_url}/1/cards"
        result = self._make_request(url, method='POST', data=card_data)

        if result["success"]:
            return {
                "success": True,
                "data": {
                    "card_id": result["data"].get("id"),
                    "card_title": result["data"].get("name"),
                    "card_url": result["data"].get("url"),
                    "column_name": column_name,
                    "due_date": due_date
                },
                "error": None,
                "message": f"Card '{title}' created successfully in column '{column_name}'."
            }
        return {
            "success": False,
            "data": None,
            "error": result["error"],
            "message": "Unable to create the card. Please check your connection and try again."
        }

    def create_board_column(self, column_name: str, position: str = "bottom") -> dict:
        """Create a new column/list on the project board."""
        if not column_name:
            return {
                "success": False,
                "data": None,
                "error": "Missing required parameter: column_name",
                "message": "Please provide a valid column name."
            }

        # Prepare column data
        column_data = {
            'name': column_name,
            'idBoard': self.board_id
        }

        # Set position
        if position.lower() == "top":
            column_data['pos'] = "top"
        elif position.lower() == "bottom":
            column_data['pos'] = "bottom"
        else:
            try:
                column_data['pos'] = int(position)
            except ValueError:
                column_data['pos'] = "bottom"

        # Create the column
        url = f"{self.base_url}/1/lists"
        result = self._make_request(url, method='POST', data=column_data)

        if result["success"]:
            return {
                "success": True,
                "data": {
                    "column_id": result["data"].get("id"),
                    "column_name": result["data"].get("name"),
                    "position": result["data"].get("pos"),
                    "board_id": result["data"].get("idBoard")
                },
                "error": None,
                "message": f"Column '{column_name}' created successfully."
            }
        return {
            "success": False,
            "data": None,
            "error": result["error"],
            "message": "Unable to create the column. Please check your connection and try again."
        }

    def move_card(self, card_id: str, target_column_name: str) -> dict:
        """Move a card to a different column."""
        if not card_id or not target_column_name:
            return {
                "success": False,
                "data": None,
                "error": "Missing required parameters",
                "message": "Please provide card_id and target_column_name."
            }

        # Get the target column ID by name
        columns_result = self.get_board_columns()
        if not columns_result["success"]:
            return {
                "success": False,
                "data": None,
                "error": "Failed to retrieve board columns",
                "message": columns_result.get("message", "Unable to access board columns.")
            }

        # Find the target column
        target_column_id = None
        available_columns = []
        for column in columns_result["data"]["columns"]:
            available_columns.append(column["name"])
            if column["name"].lower() == target_column_name.lower():
                target_column_id = column["id"]
                break

        if not target_column_id:
            return {
                "success": False,
                "data": None,
                "error": f"Column '{target_column_name}' not found",
                "message": f"Available columns: {', '.join(available_columns)}"
            }

        # Move the card
        url = f"{self.base_url}/1/cards/{card_id}"
        card_data = {'idList': target_column_id}

        result = self._make_request(url, method='PUT', data=card_data)

        if result["success"]:
            return {
                "success": True,
                "data": {
                    "card_id": result["data"].get("id"),
                    "card_name": result["data"].get("name"),
                    "new_column_id": result["data"].get("idList"),
                    "target_column_name": target_column_name
                },
                "error": None,
                "message": f"Card moved successfully to column '{target_column_name}'."
            }
        return {
            "success": False,
            "data": None,
            "error": result["error"],
            "message": "Unable to move the card. Please check the card ID and try again."
        }

    def add_card_attachment(self, card_id: str, attachment_url: str, name: str = None) -> dict:
        """Add an attachment (URL) to a Trello card."""
        if not card_id or not attachment_url:
            return {
                "success": False,
                "data": None,
                "error": "Missing required parameters",
                "message": "Please provide card_id and attachment_url."
            }

        url = f"{self.base_url}/1/cards/{card_id}/attachments"
        payload = {"url": attachment_url}
        if name:
            payload["name"] = name

        result = self._make_request(url, method='POST', data=payload)

        if result["success"]:
            return {
                "success": True,
                "data": {
                    "attachment_id": result["data"].get("id"),
                    "name": result["data"].get("name"),
                    "url": result["data"].get("url"),
                    "card_id": card_id
                },
                "error": None,
                "message": "Attachment added successfully."
            }
        return {
            "success": False,
            "data": None,
            "error": result["error"],
            "message": "Unable to add the attachment. Please check the card ID and URL."
        }

    def get_board_url(self) -> dict:
        """Retrieve the shareable URL of the configured board."""
        url = f"{self.base_url}/1/boards/{self.board_id}"
        result = self._make_request(url, params={'fields': 'url,name'})
        if result["success"]:
            return {
                "success": True,
                "data": {"board_url": result["data"].get("url"), "board_name": result["data"].get("name")},
                "error": None
            }
        return {"success": False, "data": None, "error": result["error"]}

    def get_board_labels(self) -> dict:
        """Retrieve all labels defined on the board."""
        url = f"{self.base_url}/1/boards/{self.board_id}/labels"
        result = self._make_request(url, params={'fields': 'id,name,color'})
        if result["success"]:
            labels = [{"id": l["id"], "name": l["name"], "color": l["color"]} for l in result["data"]]
            return {
                "success": True,
                "data": {"labels": labels, "total_labels": len(labels)},
                "error": None,
                "message": f"Found {len(labels)} labels on the board."
            }
        return {
            "success": False,
            "data": None,
            "error": result["error"],
            "message": "Failed to retrieve board labels."
        }

    def _resolve_full_board_id(self) -> str:
        """Return the full 24-char board id. /1/labels rejects the board short link
        (e.g. 'bBLCG8ec') with 'Invalid id', even though it works in URL paths."""
        if self._full_board_id:
            return self._full_board_id
        result = self._make_request(f"{self.base_url}/1/boards/{self.board_id}", params={'fields': 'id'})
        self._full_board_id = result["data"].get("id") if result["success"] else self.board_id
        return self._full_board_id

    def create_label(self, name: str, color: str = "blue") -> dict:
        """Create a new label on the board."""
        url = f"{self.base_url}/1/labels"
        payload = {"idBoard": self._resolve_full_board_id(), "name": name, "color": color}
        result = self._make_request(url, method='POST', data=payload)
        if result["success"]:
            return {
                "success": True,
                "data": {"id": result["data"].get("id"), "name": result["data"].get("name"), "color": result["data"].get("color")},
                "error": None
            }
        return {"success": False, "data": None, "error": result["error"]}

    def _resolve_label_ids(self, label_names: List[str]) -> tuple[list[str], list[str]]:
        """Map label names to Trello label IDs, creating any label that doesn't exist yet."""
        existing = self.get_board_labels()
        by_name = {}
        if existing["success"]:
            by_name = {l["name"].lower(): l["id"] for l in existing["data"]["labels"] if l.get("name")}

        label_ids = []
        warnings = []
        for name in label_names:
            key = name.lower().strip()
            if not key:
                continue
            if key in by_name:
                label_ids.append(by_name[key])
                continue
            created = self.create_label(name, color=DEFAULT_LABEL_COLORS.get(name, "purple"))
            if created["success"]:
                label_ids.append(created["data"]["id"])
                by_name[key] = created["data"]["id"]
            else:
                warnings.append(f"Could not create/find label '{name}': {created.get('error')}")
        return label_ids, warnings

    def add_labels_to_card(self, card_id: str, label_names: List[str]) -> dict:
        """Attach labels (by name) to a card, creating any missing labels first."""
        if not card_id or not label_names:
            return {
                "success": False,
                "data": None,
                "error": "Missing required parameters",
                "message": "Please provide card_id and label_names."
            }

        label_ids, warnings = self._resolve_label_ids(label_names)
        if not label_ids:
            return {
                "success": False,
                "data": None,
                "error": "No labels could be resolved",
                "message": "; ".join(warnings) or "Unable to resolve any of the requested labels."
            }

        url = f"{self.base_url}/1/cards/{card_id}"
        result = self._make_request(url, method='PUT', data={'idLabels': ','.join(label_ids)})
        if result["success"]:
            return {
                "success": True,
                "data": {"card_id": card_id, "applied_labels": label_names, "warnings": warnings},
                "error": None,
                "message": f"Applied {len(label_ids)} label(s) to card."
            }
        return {"success": False, "data": None, "error": result["error"], "message": "Unable to apply labels to the card."}

    def add_checklist_with_items(self, card_id: str, items: List[str], checklist_name: str = "Acceptance Criteria") -> dict:
        """Create a checklist on a card and populate it with the given items in one call."""
        if not card_id or not items:
            return {
                "success": False,
                "data": None,
                "error": "Missing required parameters",
                "message": "Please provide card_id and a non-empty items list."
            }

        checklist_result = self._make_request(
            f"{self.base_url}/1/checklists", method='POST',
            data={'idCard': card_id, 'name': checklist_name}
        )
        if not checklist_result["success"]:
            return {
                "success": False,
                "data": None,
                "error": checklist_result["error"],
                "message": "Unable to create the checklist on this card."
            }

        checklist_id = checklist_result["data"].get("id")
        added, failed = [], []
        for item in items:
            item_result = self._make_request(
                f"{self.base_url}/1/checklists/{checklist_id}/checkItems", method='POST',
                data={'name': item}
            )
            if item_result["success"]:
                added.append(item)
            else:
                failed.append({"item": item, "error": item_result["error"]})

        return {
            "success": True,
            "data": {
                "checklist_id": checklist_id,
                "checklist_name": checklist_name,
                "items_added": added,
                "items_failed": failed
            },
            "error": None,
            "message": f"Added {len(added)}/{len(items)} checklist item(s)."
        }

    def publish_user_story_cards(self, cards: List[Dict[str, Any]], skip_duplicates: bool = True) -> dict:
        """Publish a full batch of user-story cards (title, description, labels, checklist, epic_tag)
        to Trello in one call, looping over every entry instead of relying on the caller to do so."""
        if not cards:
            return {"success": False, "data": None, "error": "No cards provided", "message": "cards list is empty."}

        existing_titles = set()
        if skip_duplicates:
            all_cards = self.get_all_board_cards()
            if all_cards["success"]:
                existing_titles = {c.get("name", "").strip().lower() for c in all_cards["data"]["cards"]}

        board_url_result = self.get_board_url()
        board_url = board_url_result["data"]["board_url"] if board_url_result["success"] else None

        created_cards = []
        skipped_cards = []
        warnings = []

        for card in cards:
            title = (card.get("title") or "").strip()
            description = card.get("description") or ""
            column_name = card.get("list") or "To Do"
            epic_tag = card.get("epic_tag")
            labels = card.get("labels") or []
            checklist_items = card.get("checklist") or []

            if not title:
                warnings.append("Skipped a card with no title.")
                continue

            if skip_duplicates and title.strip().lower() in existing_titles:
                skipped_cards.append({"title": title, "reason": "duplicate title already on board"})
                continue

            if epic_tag:
                description = f"Epic: {epic_tag}\n\n{description}"

            create_result = self.create_board_card(title, description, column_name)
            if not create_result["success"]:
                warnings.append(f"Failed to create card '{title}': {create_result.get('error')}")
                continue

            card_id = create_result["data"]["card_id"]
            card_report = {
                "id": card.get("id"),
                "title": title,
                "card_id": card_id,
                "card_url": create_result["data"].get("card_url"),
                "column_name": column_name,
                "epic_tag": epic_tag,
                "labels_applied": [],
                "checklist_created": False,
            }

            if labels:
                label_result = self.add_labels_to_card(card_id, labels)
                if label_result["success"]:
                    card_report["labels_applied"] = labels
                else:
                    # Surface the underlying per-label create/resolve error (kept in
                    # 'message'), not just the generic 'No labels could be resolved'.
                    detail = label_result.get("message") or label_result.get("error")
                    warnings.append(f"Card '{title}': labels not applied ({detail}).")

            if checklist_items:
                checklist_result = self.add_checklist_with_items(card_id, checklist_items)
                if checklist_result["success"]:
                    card_report["checklist_created"] = True
                    card_report["checklist_items_added"] = len(checklist_result["data"]["items_added"])
                else:
                    warnings.append(f"Card '{title}': checklist not created ({checklist_result.get('error')}).")

            existing_titles.add(title.strip().lower())
            created_cards.append(card_report)

        return {
            "success": True,
            "data": {
                "created_cards": created_cards,
                "skipped_cards": skipped_cards,
                "board_url": board_url,
                "summary": {
                    "total_input_cards": len(cards),
                    "created": len(created_cards),
                    "skipped_duplicates": len(skipped_cards),
                    "failed": len(cards) - len(created_cards) - len(skipped_cards)
                },
                "warnings": warnings
            },
            "error": None,
            "message": f"Created {len(created_cards)}/{len(cards)} card(s); {len(skipped_cards)} skipped as duplicates."
        }


DEFAULT_LABEL_COLORS = {
    "Feature": "green",
    "Technical": "blue",
    "Bug": "red",
    "High Priority": "red",
    "Medium Priority": "yellow",
    "Low Priority": "sky",
    "Small Complexity": "lime",
    "Medium Complexity": "orange",
    "Large Complexity": "purple",
}


# Create global Trello connection instance
trello_connection = TrelloConnection()


# Current Date Tool
@mcp.tool()
def CurrentDateTool() -> str:
    """
    Description: Current Date and Time Provider - Returns today's date and current timestamp for scheduling, planning, and time-based operations.
    Use this when you need to set due dates, create timestamps, schedule tasks, or perform any date-related calculations for project management.

    Arguments: None

    Returns: str - Today's date and current time formatted as 'DD-MMM-YYYY HH:MM:SS' (e.g., '29-Oct-2025 14:30:45').
    """
    import time
    return time.strftime("%d-%b-%Y %H:%M:%S")

# Project Board Data Fetcher Tool
@mcp.tool()
def GetAllBoardCards() -> dict:
    """
    Retrieves all cards from the project management board.
    
    Returns: dict - Structured response with success status, cards data, and any error messages.
    """
    return trello_connection.get_all_board_cards()


# Get Card Details Tool
@mcp.tool()
def GetCardDetails(card_id: str) -> dict:
    """
    Retrieves detailed information about a specific card/task.
    
    Args:
        card_id (str): The unique identifier of the card to fetch.
    
    Returns: dict - Structured response with card details or error information.
    """
    return trello_connection.get_card_details(card_id)


# Get Board Columns Tool
@mcp.tool()
def GetBoardColumns() -> dict:
    """
    Retrieves all available columns/lists from the project board.
    
    Returns: dict - Structured response with columns data or error information.
    """
    return trello_connection.get_board_columns()


# Create Board Card Tool
@mcp.tool()
def CreateBoardCard(title: str, description: str, column_name: str, due_date: str = None) -> dict:
    """
    Creates a new card in the specified board column.
    
    Args:
        title (str): The title of the card to create.
        description (str): The description/content of the card.
        column_name (str): The name of the column to place the card in.
        due_date (str, optional): Due date in YYYY-MM-DD format.
    
    Returns: dict - Structured response with card creation status and details.
    """
    return trello_connection.create_board_card(title, description, column_name, due_date)


# Create Board Column Tool
@mcp.tool()
def CreateBoardColumn(column_name: str, position: str = "bottom") -> dict:
    """
    Creates a new column/list on the project board.
    
    Args:
        column_name (str): The name of the new column to create.
        position (str, optional): Position of the column ("top", "bottom", or specific position number).
    
    Returns: dict - Structured response with column creation status and details.
    """
    return trello_connection.create_board_column(column_name, position)


# Move Card Tool
@mcp.tool()
def MoveCard(card_id: str, target_column_name: str) -> dict:
    """
    Moves a card to a different column (changes card status/stage).
    
    Args:
        card_id (str): The ID of the card to move.
        target_column_name (str): The name of the column to move the card to.
    
    Returns: dict - Structured response with move operation status and details.
    """
    return trello_connection.move_card(card_id, target_column_name)


# Update Card Status Tool
@mcp.tool()
def UpdateCardStatus(card_id: str, new_status: str) -> dict:
    """
    Updates a card's status by moving it to the appropriate column.
    Common statuses: "To Do", "In Progress", "Done", "Backlog", "Review", etc.
    
    Args:
        card_id (str): The ID of the card to update.
        new_status (str): The new status (column name) for the card.
    
    Returns: dict - Structured response with status update operation details.
    """
    return trello_connection.move_card(card_id, new_status)


# Add Card Attachment Tool
@mcp.tool()
def AddCardAttachment(card_id: str, attachment_url: str, name: str = None) -> dict:
    """
    Adds an attachment (URL) to a Trello card. Useful to create Epic <-> Story relationships.
    
    Args:
        card_id (str): Trello card ID to attach to.
        attachment_url (str): URL to attach (e.g., another Trello card URL).
        name (str, optional): Optional label/name shown in the Trello UI for this attachment.
    
    Returns: dict - Structured response with attachment creation status and details.
    """
    return trello_connection.add_card_attachment(card_id, attachment_url, name)


# Get Board Labels Tool
@mcp.tool()
def GetBoardLabels() -> dict:
    """
    Retrieves all labels defined on the project board (id, name, color).

    Returns: dict - Structured response with the board's labels or error information.
    """
    return trello_connection.get_board_labels()


# Add Labels To Card Tool
@mcp.tool()
def AddLabelsToCard(card_id: str, label_names: List[str]) -> dict:
    """
    Attaches one or more labels (by name, e.g. "Feature", "High Priority", "Medium Complexity")
    to a card. Labels that don't yet exist on the board are created automatically.

    Args:
        card_id (str): Trello card ID to label.
        label_names (List[str]): Label names to attach to the card.

    Returns: dict - Structured response with the labels applied and any warnings.
    """
    return trello_connection.add_labels_to_card(card_id, label_names)


# Add Checklist With Items Tool
@mcp.tool()
def AddChecklistToCard(card_id: str, items: List[str], checklist_name: str = "Acceptance Criteria") -> dict:
    """
    Creates a checklist on a card and adds all given items to it in one call.
    Use this for acceptance criteria (e.g. Given/When/Then items) generated for a user story.

    Args:
        card_id (str): Trello card ID to add the checklist to.
        items (List[str]): Checklist item text values (e.g. acceptance criteria).
        checklist_name (str, optional): Name of the checklist. Defaults to "Acceptance Criteria".

    Returns: dict - Structured response with the created checklist ID and items added/failed.
    """
    return trello_connection.add_checklist_with_items(card_id, items, checklist_name)


# Publish Full Batch Of User Story Cards Tool
@mcp.tool()
def PublishUserStoryCards(cards: List[Dict[str, Any]], skip_duplicates: bool = True) -> dict:
    """
    Publishes an ENTIRE batch of user-story cards to Trello in a single call - looping over
    every card internally so none are skipped. Each card dict may include: title (required),
    description, list (target column name, defaults to "To Do"), labels (list of label names),
    checklist (list of acceptance-criteria strings), epic_tag, id.

    Use this instead of calling CreateBoardCard once per card, since it also applies labels,
    creates the checklist, skips duplicates already on the board, and returns the full
    summary report (created cards, skipped cards, board URL, counts, warnings).

    Args:
        cards (List[Dict[str, Any]]): The full "cards" array from the user story generation JSON.
        skip_duplicates (bool, optional): Skip creating a card if a card with the same title
            already exists on the board. Defaults to True.

    Returns: dict - Structured response with created_cards, skipped_cards, board_url,
        summary statistics, and warnings.
    """
    return trello_connection.publish_user_story_cards(cards, skip_duplicates)


@mcp.tool()
def GetDefaultColumns() -> Dict[str, Any]:
    """Get default columns for epic and story creation."""
    columns_result = trello_connection.get_board_columns()
    if not columns_result.get("success"):
        return {
            "success": False,
            "error": columns_result.get("message") or columns_result.get("error") or "Failed to retrieve board columns",
        }

    columns = (columns_result.get("data") or {}).get("columns", [])
    epic_column = columns[0]["name"] if columns else "To Do"
    story_column = columns[1]["name"] if len(columns) > 1 else epic_column
    return {
        "success": True,
        "epic_column": epic_column,
        "story_column": story_column,
        "columns": columns,
    }


@mcp.tool()
def CreateStoryCard(title: str, description: str, column_name: str, due_date: str = None) -> Dict[str, Any]:
    """Create a story card in the specified column."""
    return trello_connection.create_board_card(
        title=title,
        description=description,
        column_name=column_name,
        due_date=due_date,
    )


@mcp.tool()
def LinkEpicAndStory(
    epic_card_id: str,
    epic_card_url: str,
    story_card_id: str,
    story_card_url: str,
    story_attachment_name: str,
    epic_summary: str,
) -> Dict[str, Any]:
    """Link an epic card to a story card via attachments."""
    epic_attach_result = trello_connection.add_card_attachment(
        card_id=epic_card_id,
        attachment_url=story_card_url,
        name=story_attachment_name,
    )

    story_attach_result = trello_connection.add_card_attachment(
        card_id=story_card_id,
        attachment_url=epic_card_url,
        name=f"Parent Epic - {epic_summary}",
    )

    return {
        "epic_to_story": bool(epic_attach_result.get("success")),
        "story_to_epic": bool(story_attach_result.get("success")),
        "epic_attach_result": epic_attach_result,
        "story_attach_result": story_attach_result,
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")

