"""
Test Automation MCP Server — SQL Validation & Test Execution

Executes SQL-based test cases against Bronze (Source) and Silver (Target) databases.
Returns structured PASS / FAIL results that feed into the DAAN Final Report.

Auth: credentials are injected as environment variables by mcp_toolset_provider
      from the database via CredentialResolver:
        SOURCE_DB_URI  — SQLAlchemy URI for the Bronze / Source database
        TARGET_DB_URI  — SQLAlchemy URI for the Silver / Target database

Tools exposed:
    validate_db_connection        — verify Source + Target DB connections are reachable
    run_sql_query                 — execute any SELECT and return results as JSON
    run_count_check               — TC-001: compare row counts between Source and Target
    run_duplicate_check           — TC-002: find duplicate PKs in a table
    run_null_check                — TC-003..TC-040: count NULLs for a column
    run_data_accuracy_check       — TC-005/TC-006: verify transformation logic
    run_column_match_check        — TC-007: compare column values across joined tables
    run_full_validation_suite     — runs ALL checks and returns one consolidated PASS/FAIL table
"""

import json
import logging
import os
import warnings
from datetime import datetime
from typing import Any, Dict, List, Optional

import pandas as pd
import urllib3
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP
from sqlalchemy import create_engine, text

try:
    import duckdb
    _DUCKDB_AVAILABLE = True
except ImportError:
    _DUCKDB_AVAILABLE = False

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore")

load_dotenv()
logger = logging.getLogger(__name__)

test_automation_mcp = FastMCP("Test Automation MCP Server", "1.0.0")
# Alias required by mcp_toolset_provider convention
mcp = test_automation_mcp

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ts() -> str:
    return datetime.now().isoformat()


def _ok(**kw) -> Dict[str, Any]:
    return {"status": "success", "timestamp": _ts(), **kw}


def _err(msg: str, **kw) -> Dict[str, Any]:
    return {"status": "error", "message": msg, "timestamp": _ts(), **kw}


def _get_source_uri() -> str:
    """Read SOURCE_DB_URI injected by mcp_toolset_provider from DB credentials."""
    uri = os.getenv("SOURCE_DB_URI", "").strip()
    if not uri:
        raise ValueError(
            "SOURCE_DB_URI not set. Configure it in the MCP Management UI "
            "for 'test-automation-mcp-server'."
        )
    return uri


def _get_target_uri() -> str:
    """Read TARGET_DB_URI injected by mcp_toolset_provider from DB credentials."""
    uri = os.getenv("TARGET_DB_URI", "").strip()
    if not uri:
        raise ValueError(
            "TARGET_DB_URI not set. Configure it in the MCP Management UI "
            "for 'test-automation-mcp-server'."
        )
    return uri


def _is_file_mode(uri: str) -> bool:
    """Return True when the URI is a directory path (FILE mode via DuckDB)."""
    return os.path.isdir(uri)


def _run_query(sql: str, db_uri: str, label: str = "query") -> pd.DataFrame:
    """Execute a SELECT statement and return a DataFrame.

    FILE mode  — db_uri is a folder path: every CSV in the folder is registered
                 as a DuckDB view named after the file stem (e.g. source_file.csv
                 becomes table \"source_file\"). Queries run entirely in-process.
    DB mode    — db_uri is a SQLAlchemy URI (mssql+pyodbc, snowflake, postgresql …)
                 uses SQLAlchemy + pandas as before.
    """
    if _is_file_mode(db_uri):
        if not _DUCKDB_AVAILABLE:
            raise RuntimeError(
                "duckdb is not installed. Run: pip install duckdb"
            )
        con = duckdb.connect()
        try:
            for fname in os.listdir(db_uri):
                fpath = os.path.join(db_uri, fname).replace("\\", "/")
                stem = os.path.splitext(fname)[0]
                if fname.lower().endswith(".csv"):
                    con.execute(
                        f'CREATE OR REPLACE VIEW "{stem}" AS '
                        f"SELECT * FROM read_csv_auto('{fpath}')"
                    )
            df = con.execute(sql).df()
            logger.info("[%s] FILE mode — %d rows returned", label, len(df))
            return df
        except Exception as exc:
            raise RuntimeError(f"DuckDB query failed ({label}): {exc}") from exc
        finally:
            con.close()

    # --- DB mode (SQLAlchemy) ---
    connect_args: Dict[str, Any] = {}
    if "mssql" in db_uri or "pyodbc" in db_uri:
        connect_args["connect_args"] = {"TrustServerCertificate": "yes"}
    try:
        engine = create_engine(db_uri, **(connect_args if connect_args else {}))
        with engine.connect() as conn:
            df = pd.read_sql(text(sql), conn)
        logger.info("[%s] DB mode — %d rows returned", label, len(df))
        return df
    except Exception as exc:
        raise RuntimeError(f"Query failed ({label}): {exc}") from exc


def _pass_fail(condition: bool) -> str:
    return "PASS" if condition else "FAIL"


def _df_to_records(df: pd.DataFrame, max_rows: int = 100) -> List[Dict]:
    """Convert a DataFrame to a JSON-serialisable list, capping at max_rows."""
    return df.head(max_rows).where(pd.notnull(df), None).to_dict(orient="records")


# ---------------------------------------------------------------------------
# Tool: validate_db_connection
# ---------------------------------------------------------------------------

@test_automation_mcp.tool()
def validate_db_connection() -> Dict[str, Any]:
    """
    Verify that both Source (Bronze) and Target (Silver) DB connections are reachable.
    Uses SOURCE_DB_URI and TARGET_DB_URI injected from DB credentials via env vars.

    Returns connection status for each DB, including a simple row count to confirm access.
    """
    results = {}

    for label, uri_fn, probe_sql in [
        ("source", _get_source_uri, "SELECT 1 AS probe"),
        ("target", _get_target_uri, "SELECT 1 AS probe"),
    ]:
        try:
            uri = uri_fn()
            df = _run_query(probe_sql, uri, label=label)
            results[label] = {"connected": True, "uri_prefix": uri.split("@")[0][:40] + "..."}
        except Exception as exc:
            results[label] = {"connected": False, "error": str(exc)}

    all_ok = all(v["connected"] for v in results.values())
    return _ok(all_connected=all_ok, connections=results) if all_ok else _err(
        "One or more connections failed", connections=results
    )


# ---------------------------------------------------------------------------
# Tool: run_sql_query
# ---------------------------------------------------------------------------

@test_automation_mcp.tool()
def run_sql_query(
    sql: str,
    target: str = "source",
    max_rows: int = 200,
) -> Dict[str, Any]:
    """
    Execute any SELECT statement against the Source or Target database and return results.

    Args:
        sql:      A valid SELECT statement. Must not contain DML (INSERT/UPDATE/DELETE/DROP).
        target:   'source' to query SOURCE_DB_URI (Bronze), 'target' for TARGET_DB_URI (Silver).
        max_rows: Cap the number of rows returned (default 200).

    Returns:
        rows:       List of dicts (up to max_rows).
        row_count:  Total rows returned by the query.
        columns:    List of column names.
    """
    # Guard against DML injection
    forbidden = ("insert", "update", "delete", "drop", "truncate", "alter", "create")
    if any(kw in sql.lower() for kw in forbidden):
        return _err("DML statements are not allowed. Only SELECT queries are permitted.")

    try:
        uri = _get_source_uri() if target.lower() == "source" else _get_target_uri()
        df = _run_query(sql, uri, label=f"run_sql_query/{target}")
        return _ok(
            target=target,
            row_count=len(df),
            columns=list(df.columns),
            rows=_df_to_records(df, max_rows),
        )
    except Exception as exc:
        return _err(str(exc), target=target, sql=sql[:200])


# ---------------------------------------------------------------------------
# Tool: run_count_check  (TC-001)
# ---------------------------------------------------------------------------

@test_automation_mcp.tool()
def run_count_check(
    source_table: str,
    target_table: str,
    source_filter: Optional[str] = None,
    target_filter: Optional[str] = None,
) -> Dict[str, Any]:
    """
    TC-001: Compare total row counts between the Source (Bronze) and Target (Silver) tables.

    Args:
        source_table:   Fully-qualified Source table name, e.g. 'ODS.Logical.vODS_jjLocation'.
        target_table:   Fully-qualified Target table name, e.g. 'EDW.[Location].[TEDW_D_LOCATION_TYPE_2]'.
        source_filter:  Optional WHERE clause (without the word WHERE), e.g. 'IsActive = 1'.
        target_filter:  Optional WHERE clause for target.

    Returns:
        source_count, target_count, difference, result (PASS/FAIL).
        PASS = counts match exactly.
    """
    src_where = f" WHERE {source_filter}" if source_filter else ""
    tgt_where = f" WHERE {target_filter}" if target_filter else ""

    try:
        src_uri = _get_source_uri()
        tgt_uri = _get_target_uri()

        src_df = _run_query(f"SELECT COUNT(*) AS cnt FROM {source_table}{src_where}", src_uri, "count_source")
        tgt_df = _run_query(f"SELECT COUNT(*) AS cnt FROM {target_table}{tgt_where}", tgt_uri, "count_target")

        src_count = int(src_df["cnt"].iloc[0])
        tgt_count = int(tgt_df["cnt"].iloc[0])
        diff = abs(src_count - tgt_count)
        passed = src_count == tgt_count

        return _ok(
            test_case="TC-001 Row Count Check",
            source_table=source_table,
            target_table=target_table,
            source_count=src_count,
            target_count=tgt_count,
            difference=diff,
            result=_pass_fail(passed),
            details=f"Source={src_count}, Target={tgt_count}, Diff={diff}",
        )
    except Exception as exc:
        return _err(str(exc), test_case="TC-001 Row Count Check")


# ---------------------------------------------------------------------------
# Tool: run_duplicate_check  (TC-002)
# ---------------------------------------------------------------------------

@test_automation_mcp.tool()
def run_duplicate_check(
    table_name: str,
    pk_column: str,
    target: str = "source",
) -> Dict[str, Any]:
    """
    TC-002: Find duplicate primary key values in a table.

    Args:
        table_name:  Fully-qualified table name.
        pk_column:   Primary key column name, e.g. 'LocationId' or 'LOCATION_NUM'.
        target:      'source' (Bronze) or 'target' (Silver).

    Returns:
        duplicate_count, sample_duplicates (up to 20 rows), result (PASS/FAIL).
        PASS = zero duplicates found.
    """
    sql = (
        f"SELECT {pk_column}, COUNT(*) AS occurrence_count "
        f"FROM {table_name} "
        f"GROUP BY {pk_column} "
        f"HAVING COUNT(*) > 1 "
        f"ORDER BY occurrence_count DESC"
    )
    try:
        uri = _get_source_uri() if target.lower() == "source" else _get_target_uri()
        df = _run_query(sql, uri, f"duplicate_check/{target}")
        dup_count = len(df)
        passed = dup_count == 0

        return _ok(
            test_case="TC-002 Duplicate PK Check",
            table=table_name,
            pk_column=pk_column,
            target=target,
            duplicate_count=dup_count,
            sample_duplicates=_df_to_records(df, 20),
            result=_pass_fail(passed),
            details=f"{dup_count} duplicate PK value(s) found in {table_name}",
        )
    except Exception as exc:
        return _err(str(exc), test_case="TC-002 Duplicate PK Check")


# ---------------------------------------------------------------------------
# Tool: run_null_check  (TC-003 … TC-040)
# ---------------------------------------------------------------------------

@test_automation_mcp.tool()
def run_null_check(
    table_name: str,
    column_name: str,
    target: str = "target",
) -> Dict[str, Any]:
    """
    TC-003 to TC-040: Count NULL values in a Required column of the Target (Silver) table.

    Args:
        table_name:   Fully-qualified table name.
        column_name:  Column to check for NULLs, e.g. 'LOCATION_NUM'.
        target:       'source' (Bronze) or 'target' (Silver). Defaults to 'target' (Silver).

    Returns:
        total_rows, null_count, null_percentage, result (PASS/FAIL).
        PASS = zero NULLs found (column is fully populated).
    """
    sql_total = f"SELECT COUNT(*) AS total FROM {table_name}"
    sql_nulls = f"SELECT COUNT(*) AS nulls FROM {table_name} WHERE {column_name} IS NULL"

    try:
        uri = _get_source_uri() if target.lower() == "source" else _get_target_uri()
        total = int(_run_query(sql_total, uri, "null_check/total")["total"].iloc[0])
        nulls = int(_run_query(sql_nulls, uri, "null_check/nulls")["nulls"].iloc[0])
        pct = round((nulls / total * 100), 2) if total > 0 else 0.0
        passed = nulls == 0

        return _ok(
            test_case=f"NULL Check — {column_name}",
            table=table_name,
            column=column_name,
            target=target,
            total_rows=total,
            null_count=nulls,
            null_percentage=pct,
            result=_pass_fail(passed),
            details=f"{nulls}/{total} rows have NULL in {column_name} ({pct}%)",
        )
    except Exception as exc:
        return _err(str(exc), test_case=f"NULL Check — {column_name}")


# ---------------------------------------------------------------------------
# Tool: run_data_accuracy_check  (TC-005 / TC-006)
# ---------------------------------------------------------------------------

@test_automation_mcp.tool()
def run_data_accuracy_check(
    source_table: str,
    target_table: str,
    bronze_pk: str,
    silver_pk: str,
    source_sql_expression: str,
    target_column: str,
    test_case_name: str = "TC-006 Data Accuracy Check",
) -> Dict[str, Any]:
    """
    TC-005 / TC-006: Verify that a derived or transformed column in Silver matches the expected
    expression computed from Bronze data.

    Example: LOCATION_ADDRESS in Silver should equal CONCAT(ADD_1, '', ADD_2, '', ADD_3)
             from Bronze. This tool JOINs the two tables on their PKs and counts mismatches.

    Args:
        source_table:          Bronze table, e.g. 'ODS.Logical.vODS_jjLocation'.
        target_table:          Silver table, e.g. 'EDW.[Location].[TEDW_D_LOCATION_TYPE_2]'.
        bronze_pk:             PK in Bronze, e.g. 'LocationId'.
        silver_pk:             PK in Silver, e.g. 'LOCATION_NUM'.
        source_sql_expression: SQL expression on Bronze columns, e.g.
                               "CONCAT(b.ADD_1, ' ', b.ADD_2, ' ', b.ADD_3)".
        target_column:         Silver column to compare against, e.g. 's.LOCATION_ADDRESS'.
        test_case_name:        Label for this test case.

    Returns:
        mismatch_count, sample_mismatches (up to 20 rows), result (PASS/FAIL).
        PASS = zero mismatches.
    """
    # Use the source DB URI for the join (both tables accessible from source connection)
    # If Bronze and Silver are on different servers, adjust source_sql accordingly.
    mismatch_sql = f"""
        SELECT
            b.{bronze_pk}                       AS bronze_pk,
            {source_sql_expression}             AS bronze_computed,
            s.{target_column}                   AS silver_value
        FROM {source_table} b
        INNER JOIN {target_table} s
            ON CAST(b.{bronze_pk} AS VARCHAR) = CAST(s.{silver_pk} AS VARCHAR)
        WHERE
            (
                {source_sql_expression} <> s.{target_column}
                OR (
                    {source_sql_expression} IS NULL
                    AND s.{target_column} IS NOT NULL
                )
                OR (
                    {source_sql_expression} IS NOT NULL
                    AND s.{target_column} IS NULL
                )
            )
    """

    try:
        uri = _get_source_uri()
        df = _run_query(mismatch_sql, uri, "accuracy_check")
        mismatch_count = len(df)
        passed = mismatch_count == 0

        return _ok(
            test_case=test_case_name,
            source_expression=source_sql_expression,
            target_column=target_column,
            mismatch_count=mismatch_count,
            sample_mismatches=_df_to_records(df, 20),
            result=_pass_fail(passed),
            details=f"{mismatch_count} mismatch(es) found between computed expression and {target_column}",
        )
    except Exception as exc:
        return _err(str(exc), test_case=test_case_name)


# ---------------------------------------------------------------------------
# Tool: run_column_match_check  (TC-007)
# ---------------------------------------------------------------------------

@test_automation_mcp.tool()
def run_column_match_check(
    source_table: str,
    target_table: str,
    bronze_pk: str,
    silver_pk: str,
    columns_to_compare: str,
) -> Dict[str, Any]:
    """
    TC-007: Join Bronze and Silver on their PKs and verify that mapped columns have
    matching values across ALL rows.

    Args:
        source_table:        Bronze table name.
        target_table:        Silver table name.
        bronze_pk:           PK column in Bronze.
        silver_pk:           PK column in Silver.
        columns_to_compare:  JSON string of a list of dicts:
                             [{"bronze": "LocationCity", "silver": "LOCATION_CITY"}, ...]

    Returns:
        Per-column mismatch counts, overall result (PASS/FAIL), sample_mismatches.
        PASS = all compared columns have zero mismatches.
    """
    try:
        pairs: List[Dict[str, str]] = json.loads(columns_to_compare)
    except (json.JSONDecodeError, TypeError) as exc:
        return _err(f"columns_to_compare must be valid JSON: {exc}")

    results_per_column = []
    all_passed = True

    for pair in pairs:
        b_col = pair.get("bronze", "")
        s_col = pair.get("silver", "")
        if not b_col or not s_col:
            continue

        mismatch_sql = f"""
            SELECT
                b.{bronze_pk}  AS bronze_pk,
                b.{b_col}      AS bronze_value,
                s.{s_col}      AS silver_value
            FROM {source_table} b
            INNER JOIN {target_table} s
                ON CAST(b.{bronze_pk} AS VARCHAR) = CAST(s.{silver_pk} AS VARCHAR)
            WHERE
                (b.{b_col} <> s.{s_col})
                OR (b.{b_col} IS NULL AND s.{s_col} IS NOT NULL)
                OR (b.{b_col} IS NOT NULL AND s.{s_col} IS NULL)
        """
        try:
            uri = _get_source_uri()
            df = _run_query(mismatch_sql, uri, f"col_match/{b_col}->{s_col}")
            mismatch_count = len(df)
            col_passed = mismatch_count == 0
            if not col_passed:
                all_passed = False

            results_per_column.append({
                "bronze_column": b_col,
                "silver_column": s_col,
                "mismatch_count": mismatch_count,
                "result": _pass_fail(col_passed),
                "sample": _df_to_records(df, 5),
            })
        except Exception as exc:
            all_passed = False
            results_per_column.append({
                "bronze_column": b_col,
                "silver_column": s_col,
                "mismatch_count": -1,
                "result": "ERROR",
                "error": str(exc),
            })

    return _ok(
        test_case="TC-007 Column Data Match",
        source_table=source_table,
        target_table=target_table,
        columns_checked=len(results_per_column),
        column_results=results_per_column,
        result=_pass_fail(all_passed),
        details=f"{sum(1 for r in results_per_column if r['result'] == 'FAIL')} column(s) failed out of {len(results_per_column)}",
    )


# ---------------------------------------------------------------------------
# Tool: run_full_validation_suite  (all TCs in one call)
# ---------------------------------------------------------------------------

@test_automation_mcp.tool()
def run_full_validation_suite(
    source_table: str,
    target_table: str,
    bronze_pk: str,
    silver_pk: str,
    required_columns: str,
    columns_to_compare: Optional[str] = None,
    address_expression: Optional[str] = None,
    address_target_column: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Run the complete JJill validation suite in a single call and return a consolidated
    PASS/FAIL summary table.

    Executes:
      TC-001  Row Count Check
      TC-002  Duplicate PK Check (Bronze)
      TC-002b Duplicate PK Check (Silver)
      TC-003..TC-N  NULL Check for every column in required_columns
      TC-006  Data Accuracy / Transformation Check (if address_expression provided)
      TC-007  Column Data Match (if columns_to_compare provided)

    Args:
        source_table:          Bronze table, e.g. 'ODS.Logical.vODS_jjLocation'.
        target_table:          Silver table, e.g. 'EDW.[Location].[TEDW_D_LOCATION_TYPE_2]'.
        bronze_pk:             PK in Bronze, e.g. 'LocationId'.
        silver_pk:             PK in Silver, e.g. 'LOCATION_NUM'.
        required_columns:      JSON string list of Silver columns to NULL-check,
                               e.g. '["LOCATION_NUM","LOCATION_DESC","LOCATION_ADDRESS",...]'.
        columns_to_compare:    Optional JSON list of bronze/silver column pairs for TC-007.
        address_expression:    Optional Bronze SQL expression for TC-006 accuracy check,
                               e.g. "CONCAT(b.ADD_1, ' ', b.ADD_2, ' ', b.ADD_3)".
        address_target_column: Optional Silver column for TC-006, e.g. 's.LOCATION_ADDRESS'.

    Returns:
        summary:   List of {test_case, result, details} for all checks.
        passed:    Count of PASSed checks.
        failed:    Count of FAILed checks.
        errors:    Count of ERRORed checks.
        overall:   'PASS' if all checks passed, otherwise 'FAIL'.
    """
    summary = []

    # --- TC-001 Row Count ---
    r = run_count_check(source_table, target_table)
    summary.append({
        "test_case": r.get("test_case", "TC-001"),
        "result": r.get("result", r.get("status", "ERROR")),
        "details": r.get("details", r.get("message", "")),
    })

    # --- TC-002 Duplicate PK (Bronze) ---
    r = run_duplicate_check(source_table, bronze_pk, target="source")
    summary.append({
        "test_case": f"TC-002 Duplicate Check — Bronze ({bronze_pk})",
        "result": r.get("result", r.get("status", "ERROR")),
        "details": r.get("details", r.get("message", "")),
    })

    # --- TC-002b Duplicate PK (Silver) ---
    r = run_duplicate_check(target_table, silver_pk, target="target")
    summary.append({
        "test_case": f"TC-002b Duplicate Check — Silver ({silver_pk})",
        "result": r.get("result", r.get("status", "ERROR")),
        "details": r.get("details", r.get("message", "")),
    })

    # --- TC-003..N NULL Checks ---
    try:
        cols: List[str] = json.loads(required_columns)
    except (json.JSONDecodeError, TypeError):
        cols = []
        summary.append({
            "test_case": "NULL Checks",
            "result": "ERROR",
            "details": "required_columns must be a valid JSON list of column names",
        })

    for idx, col in enumerate(cols, start=3):
        r = run_null_check(target_table, col, target="target")
        summary.append({
            "test_case": f"TC-{idx:03d} NULL Check — {col}",
            "result": r.get("result", r.get("status", "ERROR")),
            "details": r.get("details", r.get("message", "")),
        })

    # --- TC-006 Accuracy Check (optional) ---
    if address_expression and address_target_column:
        r = run_data_accuracy_check(
            source_table, target_table, bronze_pk, silver_pk,
            address_expression, address_target_column,
            test_case_name="TC-006 Data Accuracy — LOCATION_ADDRESS",
        )
        summary.append({
            "test_case": r.get("test_case", "TC-006"),
            "result": r.get("result", r.get("status", "ERROR")),
            "details": r.get("details", r.get("message", "")),
        })

    # --- TC-007 Column Match (optional) ---
    if columns_to_compare:
        r = run_column_match_check(
            source_table, target_table, bronze_pk, silver_pk, columns_to_compare
        )
        summary.append({
            "test_case": r.get("test_case", "TC-007"),
            "result": r.get("result", r.get("status", "ERROR")),
            "details": r.get("details", r.get("message", "")),
        })

    passed = sum(1 for s in summary if s["result"] == "PASS")
    failed = sum(1 for s in summary if s["result"] == "FAIL")
    errors = sum(1 for s in summary if s["result"] == "ERROR")
    overall = "PASS" if failed == 0 and errors == 0 else "FAIL"

    return _ok(
        summary=summary,
        total_checks=len(summary),
        passed=passed,
        failed=failed,
        errors=errors,
        overall=overall,
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run(transport="stdio")
