﻿"""
Databricks MCP Server — Workspace & Notebook Operations

Exposes Databricks workspace operations as FastMCP tools so ADK agents can
upload generated PySpark notebooks, list clusters, list notebooks, and run jobs.

Auth priority (first match wins) for connect_to_databricks:
  1. token                      — Personal Access Token  ('dapi...')
  2. client_id + client_secret  — OAuth M2M Service Principal
  3. profile                    — section in ~/.databrickscfg

DatabricksValidateConnectionTool falls back to DATABRICKS_HOST + DATABRICKS_TOKEN env vars.
"""

import base64
import configparser
import logging
import os
import warnings
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import requests
import urllib3
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

load_dotenv()
logger = logging.getLogger(__name__)

databricks_mcp = FastMCP("Databricks MCP Server", "1.0.0")
# Alias required by mcp_toolset_provider._get_repo_local_mcp_toolset convention.
mcp = databricks_mcp

# Per-workspace connection registry (process-local, cleared on restart)
_CONNECTIONS: Dict[str, "_Conn"] = {}


# ---------------------------------------------------------------------------
# Response helpers
# ---------------------------------------------------------------------------

def _ts() -> str:
    return datetime.now().isoformat()


def _ok(**kw) -> Dict[str, Any]:
    return {"status": "success", "timestamp": _ts(), **kw}


def _err(msg: str, **kw) -> Dict[str, Any]:
    return {"status": "error", "message": msg, "timestamp": _ts(), **kw}


def _http_err(exc: requests.HTTPError, **kw) -> Dict[str, Any]:
    return _err(f"HTTP {exc.response.status_code}: {exc.response.text[:300]}", **kw)


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------

def _cli_profile_token(profile: str) -> Optional[str]:
    """Read PAT from ~/.databrickscfg for the given profile section."""
    p = Path.home() / ".databrickscfg"
    if not p.exists():
        return None
    cfg = configparser.ConfigParser()
    cfg.read(p)
    sec = profile if cfg.has_section(profile) else "DEFAULT"
    return cfg.get(sec, "token", fallback=None)


def _oauth_m2m_token(
    workspace_url: str,
    client_id: str,
    client_secret: str,
    verify_ssl: bool = False,
    http_timeout: int = 15,
) -> str:
    """Exchange client_id + client_secret for a short-lived OAuth 2.0 access token."""
    resp = requests.post(
        workspace_url.rstrip("/") + "/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(client_id, client_secret),
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        verify=verify_ssl,
        timeout=http_timeout,
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


# ---------------------------------------------------------------------------
# Connection class
# ---------------------------------------------------------------------------

class _Conn:
    """Holds an authenticated requests.Session for one Databricks workspace."""

    def __init__(self):
        self.workspace_url: Optional[str] = None
        self._session: Optional[requests.Session] = None
        self._timeout: int = 30
        self._ok: bool = False

    def _req(self, method: str, path: str, **kw) -> requests.Response:
        url = self.workspace_url.rstrip("/") + path
        return self._session.request(method, url, timeout=self._timeout, **kw)

    def get(self, path: str, params: Optional[Dict] = None) -> requests.Response:
        return self._req("GET", path, params=params)

    def post(self, path: str, body: Dict) -> requests.Response:
        return self._req("POST", path, json=body)

    def guard(self) -> Optional[Dict[str, Any]]:
        if not self._ok:
            return _err("Not connected. Call connect_to_databricks first.")
        return None

    def connect(
        self,
        workspace_url: str,
        token: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        profile: Optional[str] = None,
        http_timeout: int = 30,
        verify_ssl: bool = False,
    ) -> Dict[str, Any]:
        self.workspace_url = workspace_url.rstrip("/")
        self._timeout = http_timeout

        try:
            if token:
                bearer, auth_method = token, "pat"
            elif client_id and client_secret:
                bearer = _oauth_m2m_token(workspace_url, client_id, client_secret, verify_ssl, http_timeout)
                auth_method = "oauth_m2m"
            elif profile:
                bearer, auth_method = _cli_profile_token(profile), "cli_profile"
            else:
                bearer, auth_method = None, "none"
        except requests.HTTPError as exc:
            self._ok = False
            return _err(
                f"OAuth M2M token exchange failed (HTTP {exc.response.status_code}): {exc.response.text[:300]}",
                auth_method="oauth_m2m",
            )
        except Exception as exc:
            self._ok = False
            return _err(f"Credential resolution failed: {exc}")

        s = requests.Session()
        s.verify = verify_ssl
        if bearer:
            s.headers["Authorization"] = f"Bearer {bearer}"
        self._session = s

        try:
            r = self.get("/api/2.0/preview/scim/v2/Me")
            r.raise_for_status()
            me = r.json()
            self._ok = True
            return _ok(
                message=f"Connected to {workspace_url}",
                auth_method=auth_method,
                workspace_url=workspace_url,
                # Note: user identity is intentionally omitted from this response.
                # Do NOT use any user email or username as a workspace upload path.
                # Always use the workspace_path parameter or let the tool choose the default.
            )
        except requests.HTTPError as exc:
            self._ok = False
            return _http_err(exc, auth_method=auth_method)
        except Exception as exc:
            self._ok = False
            return _err(f"Connection failed: {exc}")


def _conn(workspace_url: str) -> _Conn:
    """Return (or create) the connection object for a workspace URL."""
    key = workspace_url.rstrip("/")
    if key not in _CONNECTIONS:
        _CONNECTIONS[key] = _Conn()
    return _CONNECTIONS[key]


# ---------------------------------------------------------------------------
# Internal helpers (used by tests)
# ---------------------------------------------------------------------------

def _resolve_host(host_override: str) -> str:
    """Return a bare hostname (no protocol, no trailing slash)."""
    host = (host_override or os.getenv("DATABRICKS_HOST", "")).strip()
    for prefix in ("https://", "http://"):
        if host.startswith(prefix):
            host = host[len(prefix):]
            break
    return host.strip("/")


_DEFAULT_UPLOAD_DIR = os.getenv("DATABRICKS_WORKSPACE_FOLDER", "/Workspace")


def _sanitize_path_segment(name: str) -> str:
    """Replace non-alphanumeric characters with underscores for safe path segments."""
    import re
    sanitized = re.sub(r"[^a-zA-Z0-9_-]", "_", name.strip()).strip("_")
    return sanitized or "unknown"


def _build_notebook_path(workspace_dir: str, source_name: str, target_name: str) -> str:
    """Construct a full notebook path using the pattern sourcename_targetname_timestamp.

    If *workspace_dir* is provided it is used as the parent directory;
    otherwise the default upload directory is used and created automatically.
    The notebook filename is always ``{source}_{target}_{YYYYmmdd_HHMMSS}``.
    """
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    src = _sanitize_path_segment(source_name or "source")
    tgt = _sanitize_path_segment(target_name or "target")
    filename = f"{src}_{tgt}_{ts}"
    base = workspace_dir.rstrip("/") if workspace_dir and workspace_dir.strip() else _DEFAULT_UPLOAD_DIR
    return f"{base}/{filename}"


def _ensure_workspace_dir(host: str, token: str, notebook_path: str) -> None:
    """Best-effort creation of parent directories in the Databricks Workspace."""
    parent = "/".join(notebook_path.rsplit("/", 1)[:-1])
    if not parent:
        return
    try:
        requests.post(
            f"https://{host}/api/2.0/workspace/mkdirs",
            headers={"Authorization": f"Bearer {token}"},
            json={"path": parent},
            timeout=30,
            verify=False,
        )
    except Exception as exc:
        logger.warning("Could not create workspace directory %s: %s", parent, exc)


# ---------------------------------------------------------------------------
# MCP Tools — Connection
# ---------------------------------------------------------------------------

@databricks_mcp.tool()
def connect_to_databricks(
    workspace_url: str,
    token: Optional[str] = None,
    client_id: Optional[str] = None,
    client_secret: Optional[str] = None,
    profile: Optional[str] = None,
    http_timeout: int = 30,
    verify_ssl: bool = False,
) -> Dict[str, Any]:
    """
    Connect to a Databricks workspace. Must be called before all other session tools.

    Auth priority (first match wins):
      1. token                       — PAT ('dapi...')
      2. client_id + client_secret   — OAuth M2M Service Principal
      3. profile                     — ~/.databrickscfg section name

    Args:
        workspace_url:  e.g. 'https://adb-XXXX.azuredatabricks.net'
        token:          Personal Access Token.
        client_id:      Service Principal Application ID (UUID).
        client_secret:  Service Principal secret.
        profile:        ~/.databrickscfg profile name.
        http_timeout:   Request timeout in seconds (default 30).
        verify_ssl:     Set False for corporate proxy environments (default False).
    """
    return _conn(workspace_url).connect(
        workspace_url,
        token=token, client_id=client_id, client_secret=client_secret,
        profile=profile, http_timeout=http_timeout, verify_ssl=verify_ssl,
    )


@databricks_mcp.tool()
def get_workspace_info(workspace_url: str) -> Dict[str, Any]:
    """Return workspace URL for a connected workspace.

    Note: user identity details are omitted intentionally — do NOT derive
    an upload path from a user's email address.  Use the workspace_path
    parameter on upload tools, or leave it blank to use the default folder.
    """
    c = _conn(workspace_url)
    if err := c.guard():
        return err
    try:
        return _ok(workspace_url=workspace_url)
    except Exception as exc:
        return _err(str(exc))


# ---------------------------------------------------------------------------
# MCP Tools — Clusters
# ---------------------------------------------------------------------------

@databricks_mcp.tool()
def list_clusters(workspace_url: str) -> Dict[str, Any]:
    """List all interactive clusters (id, name, state, spark_version)."""
    c = _conn(workspace_url)
    if err := c.guard():
        return err
    try:
        r = c.get("/api/2.0/clusters/list")
        r.raise_for_status()
        _fields = ("cluster_id", "cluster_name", "state", "spark_version", "node_type_id", "num_workers", "autoscale")
        clusters = [{f: x.get(f) for f in _fields} for x in r.json().get("clusters", [])]
        return _ok(count=len(clusters), clusters=clusters)
    except Exception as exc:
        return _err(str(exc))


# ---------------------------------------------------------------------------
# MCP Tools — Workspace / Notebooks
# ---------------------------------------------------------------------------

@databricks_mcp.tool()
def list_notebooks(workspace_url: str, workspace_path: str = "/") -> Dict[str, Any]:
    """List notebooks and folders under a workspace directory path."""
    c = _conn(workspace_url)
    if err := c.guard():
        return err
    try:
        r = c.get("/api/2.0/workspace/list", params={"path": workspace_path})
        r.raise_for_status()
        _fields = ("path", "object_type", "language", "object_id")
        items = [{f: o.get(f) for f in _fields} for o in r.json().get("objects", [])]
        return _ok(workspace_path=workspace_path, count=len(items), items=items)
    except Exception as exc:
        return _err(str(exc))


@databricks_mcp.tool()
def upload_notebook(
    workspace_url: str,
    notebook_content: str,
    language: str = "PYTHON",
    overwrite: bool = True,
    workspace_path: str = "",
    source_name: str = "",
    target_name: str = "",
) -> Dict[str, Any]:
    """
    Upload a notebook source file to the Databricks workspace.

    The notebook filename is always built as ``{source_name}_{target_name}_{timestamp}``.

    Args:
        workspace_url:    Connected workspace URL.
        notebook_content: Raw source code string.
        language:         PYTHON | SQL | SCALA | R (default PYTHON).
        overwrite:        Overwrite existing notebook (default True).
        workspace_path:   Optional base directory in the workspace
                          (e.g. '/Workspace/Shared/MyProject').  When omitted
                          files are placed in the default upload folder
                          (/Workspace/Shared/DAAN_MCP/uploads).
        source_name:      Source system / table name — used in the filename.
        target_name:      Target system / table name — used in the filename.
    """
    resolved_path = _build_notebook_path(workspace_path, source_name, target_name)
    c = _conn(workspace_url)
    if err := c.guard():
        return err
    try:
        r = c.post("/api/2.0/workspace/import", {
            "path": resolved_path,
            "format": "SOURCE",
            "language": language.upper(),
            "content": base64.b64encode(notebook_content.encode()).decode(),
            "overwrite": overwrite,
        })
        r.raise_for_status()
        return _ok(
            message=f"Notebook uploaded to {resolved_path}",
            workspace_path=resolved_path,
            language=language.upper(),
        )
    except requests.HTTPError as exc:
        return _http_err(exc)
    except Exception as exc:
        return _err(str(exc))


# ---------------------------------------------------------------------------
# MCP Tools — Jobs / Runs
# ---------------------------------------------------------------------------

@databricks_mcp.tool()
def run_notebook(
    workspace_url: str,
    notebook_path: str,
    cluster_id: str,
    parameters: Optional[Dict[str, str]] = None,
    timeout_seconds: int = 3600,
    run_name: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Submit a one-off notebook run via the Runs Submit API.

    Args:
        workspace_url:   Connected workspace URL.
        notebook_path:   Absolute workspace path of the notebook.
        cluster_id:      Existing interactive cluster ID.
        parameters:      Notebook widget key-value pairs (optional).
        timeout_seconds: Max run duration in seconds (default 3600).
        run_name:        Optional display name for the run.
    """
    c = _conn(workspace_url)
    if err := c.guard():
        return err
    try:
        r = c.post("/api/2.1/jobs/runs/submit", {
            "run_name": run_name or f"mcp_run_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "timeout_seconds": timeout_seconds,
            "tasks": [{
                "task_key": "notebook_run",
                "existing_cluster_id": cluster_id,
                "notebook_task": {
                    "notebook_path": notebook_path,
                    "base_parameters": parameters or {},
                },
            }],
        })
        r.raise_for_status()
        return _ok(
            message="Run submitted",
            run_id=r.json().get("run_id"),
            notebook_path=notebook_path,
            cluster_id=cluster_id,
        )
    except requests.HTTPError as exc:
        return _http_err(exc)
    except Exception as exc:
        return _err(str(exc))


@databricks_mcp.tool()
def get_run_status(workspace_url: str, run_id: int) -> Dict[str, Any]:
    """Get the status and result of a submitted run by run_id."""
    c = _conn(workspace_url)
    if err := c.guard():
        return err
    try:
        r = c.get("/api/2.1/jobs/runs/get", params={"run_id": run_id})
        r.raise_for_status()
        data = r.json()
        state = data.get("state", {})
        return _ok(
            run_id=run_id,
            life_cycle_state=state.get("life_cycle_state"),
            result_state=state.get("result_state"),
            state_message=state.get("state_message"),
            run_page_url=data.get("run_page_url"),
        )
    except requests.HTTPError as exc:
        return _http_err(exc)
    except Exception as exc:
        return _err(str(exc))


@databricks_mcp.tool()
def list_jobs(workspace_url: str, limit: int = 25) -> Dict[str, Any]:
    """List Databricks jobs (name, job_id, created_time)."""
    c = _conn(workspace_url)
    if err := c.guard():
        return err
    try:
        r = c.get("/api/2.1/jobs/list", params={"limit": limit})
        r.raise_for_status()
        jobs = r.json().get("jobs", [])
        simplified = [
            {
                "job_id": j.get("job_id"),
                "name": j.get("settings", {}).get("name"),
                "created_time": j.get("created_time"),
            }
            for j in jobs
        ]
        return _ok(count=len(simplified), jobs=simplified)
    except Exception as exc:
        return _err(str(exc))


# ---------------------------------------------------------------------------
# MCP Tool: Simple connection validation (env-var based)
# ---------------------------------------------------------------------------

@databricks_mcp.tool()
def DatabricksValidateConnectionTool(
    server_hostname: str = "",
    access_token: str = "",
) -> Dict[str, Any]:
    """
    Validate Databricks credentials (no connect() call required).

    Args:
        server_hostname: Workspace hostname; falls back to DATABRICKS_HOST env var.
        access_token:    PAT; falls back to DATABRICKS_TOKEN env var.
    """
    host = _resolve_host(server_hostname)
    token = (access_token or os.getenv("DATABRICKS_TOKEN", "")).strip()

    if not host or not token:
        return _err("Missing credentials — set DATABRICKS_HOST and DATABRICKS_TOKEN.")

    try:
        resp = requests.get(
            f"https://{host}/api/2.0/workspace/list",
            headers={"Authorization": f"Bearer {token}"},
            params={"path": "/"},
            timeout=15,
            verify=False,
        )
    except requests.RequestException as exc:
        return _err(f"Network error: {exc}")

    if resp.status_code == 200:
        return _ok(
            message=f"Connected to Databricks workspace: {host}",
            workspace_url=f"https://{host}",
        )

    return _err(f"Connection failed [{resp.status_code}]: {resp.text}")


if __name__ == "__main__":
    logger.info("Starting Databricks MCP Server…")
    mcp.run(transport="stdio")
