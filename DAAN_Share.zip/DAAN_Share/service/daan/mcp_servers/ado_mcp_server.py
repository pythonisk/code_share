"""Azure DevOps MCP server for repository push and PR operations."""

import base64
import glob
import html
import json
import logging
import os
import posixpath
import random
import re
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import quote

import requests
import yaml
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

logging.basicConfig(level=logging.INFO, stream=sys.stderr)
logger = logging.getLogger(__name__)

load_dotenv()
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
load_dotenv(os.path.join(_REPO_ROOT, "config", ".env"))

ado_mcp = FastMCP("Azure DevOps MCP Server", "1.0.0")
mcp = ado_mcp

API_VERSION = "7.1"
ZERO_SHA = "0000000000000000000000000000000000000000"
_SOURCE_CALL_PATTERN = re.compile(r"source\(\s*['\"]([^'\"]+)['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\)", re.IGNORECASE)
_LEGACY_TEST_ARGUMENT_KEYS = {"values", "field", "to", "column_name", "model"}


def _ts() -> str:
    return datetime.now().isoformat()


def _bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}

def _trigger_dbt_cloud_run(git_branch: str, cause: str) -> Dict[str, Any]:
    """Kick off a dbt Cloud job run using DBT_CLOUD_* environment configuration."""
    base_url = os.getenv("DBT_CLOUD_BASE_URL", "https://cloud.getdbt.com").rstrip("/")
    account_id = os.getenv("DBT_CLOUD_ACCOUNT_ID", "").strip()
    job_id = os.getenv("DBT_CLOUD_JOB_ID", "").strip()
    token = os.getenv("DBT_CLOUD_TOKEN", "").strip()

    missing = [
        name for name, value in {
            "DBT_CLOUD_ACCOUNT_ID": account_id,
            "DBT_CLOUD_JOB_ID": job_id,
            "DBT_CLOUD_TOKEN": token,
        }.items() if not value
    ]
    if missing:
        return {"success": False, "skipped": True, "reason": "missing_env_vars", "missing": missing}

    url = f"{base_url}/api/v2/accounts/{account_id}/jobs/{job_id}/run/"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Token {token}",
    }
    body: Dict[str, Any] = {"cause": cause}
    if git_branch:
        body["git_branch"] = git_branch

    try:
        resp = requests.post(url, headers=headers, json=body, timeout=60, verify=False)
        try:
            payload = resp.json()
        except Exception:
            payload = {"raw_text": resp.text}
        key = "data" if resp.status_code < 400 else "error"
        return {"success": resp.status_code < 400, "status_code": resp.status_code, key: payload}
    except Exception as exc:
        return {"success": False, "error": str(exc)}

def _ado_headers(pat: str) -> Dict[str, str]:
    token = base64.b64encode(f":{pat}".encode()).decode()
    return {
        "Authorization": f"Basic {token}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }


def _ado_repo_web_url(org: str, project: str, repo: str) -> str:
    return f"https://dev.azure.com/{org}/{project}/_git/{repo}"


def _ado_folder_web_url(org: str, project: str, repo: str, folder_name: str) -> str:
    clean_folder = (folder_name or "").strip().lstrip("/")
    if not clean_folder:
        return _ado_repo_web_url(org, project, repo)
    return f"{_ado_repo_web_url(org, project, repo)}?path=/{clean_folder}"


def _ado_urls(org: str, project: str, repo: str) -> Dict[str, str]:
    root = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}"
    return {
        "refs": f"{root}/refs?api-version={API_VERSION}",
        "pushes": f"{root}/pushes?api-version={API_VERSION}",
    }


def _get_ref_object_id(headers: Dict[str, str], urls: Dict[str, str], branch_name: str) -> str:
    try:
        url = f"{urls['refs']}&filter=heads/{branch_name}"
        resp = requests.get(url, headers=headers, timeout=60)
        resp.raise_for_status()
        for ref in resp.json().get("value", []):
            if ref.get("name") == f"refs/heads/{branch_name}":
                return ref.get("objectId", ZERO_SHA)
    except Exception as exc:
        logger.warning("ADO ref lookup failed for %s: %s", branch_name, exc)
    return ZERO_SHA


def _list_branch_names(headers: Dict[str, str], org: str, project: str, repo: str) -> list[str]:
    """Return branch names (without refs/heads/) for a repository."""
    base = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/refs"
    params = {
        "filter": "heads/",
        "api-version": API_VERSION,
    }
    try:
        resp = requests.get(base, headers=headers, params=params, timeout=60)
        if resp.status_code != 200:
            return []
        data = resp.json() if resp.content else {}
        names: list[str] = []
        for ref in data.get("value", []):
            raw = str(ref.get("name") or "")
            if raw.startswith("refs/heads/"):
                names.append(raw[len("refs/heads/") :])
        return sorted(set(names))
    except Exception:
        return []


def _get_repo_default_branch(headers: Dict[str, str], org: str, project: str, repo: str) -> str:
    """Fetch repo default branch (without refs/heads/)."""
    url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}?api-version={API_VERSION}"
    try:
        resp = requests.get(url, headers=headers, timeout=60)
        if resp.status_code != 200:
            return ""
        payload = resp.json() if resp.content else {}
        default_ref = str(payload.get("defaultBranch") or "")
        if default_ref.startswith("refs/heads/"):
            return default_ref[len("refs/heads/") :]
        return default_ref
    except Exception:
        return ""


def _resolve_base_branch(headers: Dict[str, str], org: str, project: str, repo: str, base_branch: str) -> tuple[str, str]:
    """Resolve configured base branch to a valid branch name.

    Returns:
        (resolved_branch, note)
    """
    urls = _ado_urls(org, project, repo)
    requested = (base_branch or "").strip()

    if requested and _get_ref_object_id(headers, urls, requested) != ZERO_SHA:
        return requested, ""

    default_branch = _get_repo_default_branch(headers, org, project, repo)
    if default_branch and _get_ref_object_id(headers, urls, default_branch) != ZERO_SHA:
        note = (
            f"Configured base branch '{requested or '<empty>'}' not found; "
            f"using repository default branch '{default_branch}'."
        )
        logger.warning(note)
        return default_branch, note

    branch_names = _list_branch_names(headers, org, project, repo)
    for candidate in ("main", "master", "develop", "development"):
        if candidate in branch_names:
            note = (
                f"Configured base branch '{requested or '<empty>'}' not found; "
                f"using fallback branch '{candidate}'."
            )
            logger.warning(note)
            return candidate, note

    sample = ", ".join(branch_names[:20]) if branch_names else "<none>"
    raise RuntimeError(
        f"Base branch '{requested or '<empty>'}' not found and no fallback branch was resolvable. "
        f"Available branches (sample): {sample}"
    )


def _item_exists(headers: Dict[str, str], org: str, project: str, repo: str, path: str, branch_name: str) -> bool:
    base = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/items"
    params = {
        "path": path if path.startswith("/") else f"/{path}",
        "versionDescriptor.version": branch_name,
        "versionDescriptor.versionType": "branch",
        "api-version": API_VERSION,
    }
    try:
        resp = requests.get(base, headers=headers, params=params, timeout=30)
        return resp.status_code == 200
    except Exception:
        return False


def _build_changes(headers: Dict[str, str], org: str, project: str, repo: str, branch: str, file_list, branch_exists: bool):
    changes = []
    for rel_path, content in file_list:
        change_type = "edit" if branch_exists and _item_exists(headers, org, project, repo, rel_path, branch) else "add"
        changes.append(
            {
                "changeType": change_type,
                "item": {"path": rel_path},
                "newContent": {"content": content, "contentType": "rawtext"},
            }
        )
    return changes


def _push_once(headers: Dict[str, str], urls: Dict[str, str], old_object_id: str, branch: str, changes, commit_message: str):
    body = {
        "refUpdates": [{"name": f"refs/heads/{branch}", "oldObjectId": old_object_id}],
        "commits": [{"comment": commit_message, "changes": changes}],
    }
    return requests.post(urls["pushes"], headers=headers, data=json.dumps(body), timeout=120)


def _create_branch_from_base(headers: Dict[str, str], org: str, project: str, repo: str, branch: str, base_branch: str) -> str:
    urls = _ado_urls(org, project, repo)
    base_object_id = _get_ref_object_id(headers, urls, base_branch)
    if base_object_id == ZERO_SHA:
        raise RuntimeError(f"Base branch '{base_branch}' not found")
    url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/refs?api-version={API_VERSION}"
    body = [{"name": f"refs/heads/{branch}", "oldObjectId": ZERO_SHA, "newObjectId": base_object_id}]
    resp = requests.post(url, headers=headers, data=json.dumps(body), timeout=60)
    if resp.status_code not in (200, 201):
        raise RuntimeError(f"Failed to create branch '{branch}': {resp.status_code} {resp.text[:300]}")
    return base_object_id


def _reset_branch_to_base(headers: Dict[str, str], org: str, project: str, repo: str, branch: str, base_branch: str) -> str:
    urls = _ado_urls(org, project, repo)
    current_object_id = _get_ref_object_id(headers, urls, branch)
    if current_object_id == ZERO_SHA:
        return _create_branch_from_base(headers, org, project, repo, branch, base_branch)
    base_object_id = _get_ref_object_id(headers, urls, base_branch)
    if base_object_id == ZERO_SHA:
        raise RuntimeError(f"Base branch '{base_branch}' not found")
    if current_object_id == base_object_id:
        return base_object_id
    url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/refs?api-version={API_VERSION}"
    body = [{"name": f"refs/heads/{branch}", "oldObjectId": current_object_id, "newObjectId": base_object_id}]
    resp = requests.post(url, headers=headers, data=json.dumps(body), timeout=60)
    if resp.status_code not in (200, 201):
        raise RuntimeError(f"Failed to reset branch '{branch}': {resp.status_code} {resp.text[:300]}")
    return base_object_id


def _is_stale_ref_error(response: requests.Response) -> bool:
    if response.status_code != 409:
        return False
    try:
        payload = response.json()
    except Exception:
        return False
    message = payload.get("message", "")
    type_key = payload.get("typeKey", "")
    return "TF401028" in message or "GitReferenceStaleException" in type_key


def get_existing_pr(org: str, project: str, repo: str, pat: str, source_branch: str, target_branch: str):
    headers = _ado_headers(pat)
    url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/pullrequests?api-version={API_VERSION}"
    params = {
        "searchCriteria.sourceRefName": f"refs/heads/{source_branch}",
        "searchCriteria.targetRefName": f"refs/heads/{target_branch}",
        "searchCriteria.status": "active",
    }
    resp = requests.get(url, headers=headers, params=params, timeout=120)
    resp.raise_for_status()
    prs = resp.json().get("value", [])
    return prs[0] if prs else None


def create_pr(org: str, project: str, repo: str, pat: str, source_branch: str, target_branch: str, title: str, description: str):
    headers = _ado_headers(pat)
    url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/pullrequests?api-version={API_VERSION}"
    body = {
        "sourceRefName": f"refs/heads/{source_branch}",
        "targetRefName": f"refs/heads/{target_branch}",
        "title": title,
        "description": description,
    }
    resp = requests.post(url, headers=headers, data=json.dumps(body), timeout=120)
    resp.raise_for_status()
    return resp.json()


def complete_pr(org: str, project: str, repo: str, pat: str, pr_id: int, squash: bool = True, delete_source: bool = False, last_merge_source: Optional[str] = None):
    headers = _ado_headers(pat)
    url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/pullrequests/{pr_id}?api-version={API_VERSION}"
    body: Dict[str, Any] = {
        "status": "completed",
        "completionOptions": {
            "squashMerge": bool(squash),
            "deleteSourceBranch": bool(delete_source),
            "mergeStrategy": "squash" if squash else "noFastForward",
        },
    }
    if last_merge_source:
        body["lastMergeSourceCommit"] = {"commitId": last_merge_source}
    resp = requests.patch(url, headers=headers, data=json.dumps(body), timeout=120)
    resp.raise_for_status()
    return resp.json()


def get_pr(org: str, project: str, repo: str, pat: str, pr_id: int):
    headers = _ado_headers(pat)
    url = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/pullrequests/{pr_id}?api-version={API_VERSION}"
    resp = requests.get(url, headers=headers, timeout=60)
    resp.raise_for_status()
    return resp.json()


def wait_for_pr_completion(org: str, project: str, repo: str, pat: str, pr_id: int, timeout_sec: int = 600, poll_every: int = 5):
    deadline = time.time() + timeout_sec
    while time.time() < deadline:
        pr = get_pr(org, project, repo, pat, pr_id)
        if (pr.get("status") or "").lower() in {"completed", "abandoned"}:
            return pr
        time.sleep(poll_every)
    raise TimeoutError(f"PR {pr_id} not completed within {timeout_sec}s")


def _infer_repo_path_from_filename(filename: str) -> str:
    """Return only the exact file name (no nested folders)."""
    cleaned = (filename or "").strip().replace("\\", "/")
    return posixpath.basename(cleaned)


def _choose_timestamp_folder_prefix(files: Dict[str, str], folder_prefix: str = "") -> str:
    """Infer whether generated output is modelling or testing oriented."""
    cleaned_prefix = (folder_prefix or "").strip().lower().replace("-", "_")
    if cleaned_prefix in {"dbt_modelling", "dbt_testing"}:
        return cleaned_prefix

    filenames = [
        posixpath.basename((path or "").strip().replace("\\", "/")).lower()
        for path in files.keys()
    ]
    sql_filenames = [name for name in filenames if name.endswith(".sql")]
    if any(
        name.startswith("test_") or "validation" in name or "validate" in name or "lookup" in name
        for name in sql_filenames
    ):
        return "dbt_testing"
    if sql_filenames and all(
        name.startswith("test_") or "test" in name or "validation" in name or "lookup" in name
        for name in sql_filenames
    ):
        return "dbt_testing"
    if filenames and all(name in {"schema.yml", "schema.yaml"} for name in filenames):
        return "dbt_testing"
    return "dbt_modelling"


def _sanitize_yaml_content(content: str) -> str:
    """Best-effort YAML sanitizer for LLM-generated snippets."""
    text = (content or "").replace("\r\n", "\n")
    try:
        yaml.safe_load(text)
        return text
    except Exception:
        pass

# Unquoted comparison operators are the common failure in generated schema tests.
    fixed_lines: list[str] = []
    line_re = re.compile(r"^(?P<prefix>\s*(?:-\s*)?[A-Za-z0-9_\-]+:\s*)(?P<value>.+?)\s*$")
    for line in text.split("\n"):
        m = line_re.match(line)
        if not m:
            fixed_lines.append(line)
            continue
        value = m.group("value").strip()
        if (
            value
            and not value.startswith(("'", '"', "[", "{", "|", ">", "&", "*", "!"))
            and re.search(r"(>=|<=|==|!=|>|<)", value)
        ):
            escaped = value.replace('"', '\\"')
            fixed_lines.append(f'{m.group("prefix")}"{escaped}"')
        else:
            fixed_lines.append(line)
    return "\n".join(fixed_lines)


def _is_valid_dbt_project_yaml(content: str) -> bool:
    """Validate dbt_project.yml structure expected by dbt."""
    try:
        data = yaml.safe_load(content or "")
    except Exception:
        return False
    if not isinstance(data, dict):
        return False

    list_keys = ["model-paths", "seed-paths", "macro-paths", "snapshot-paths", "analysis-paths", "test-paths", "clean-targets"]
    for key in list_keys:
        if key in data and not isinstance(data.get(key), list):
            return False
    if "config-version" in data and not isinstance(data.get("config-version"), int):
        return False
    if "name" in data and not isinstance(data.get("name"), str):
        return False
    if "profile" in data and not isinstance(data.get("profile"), str):
        return False
    required_string_keys = ["name", "version", "profile"]
    for key in required_string_keys:
        value = data.get(key)
        if not isinstance(value, str) or not value.strip():
            return False
    if data.get("config-version") != 2:
        return False
    model_paths = data.get("model-paths") or []
    if "." in model_paths:
        return False
    return True


def _default_dbt_project_yml(project_name_hint: str = "") -> str:
    """Return a minimal dbt_project.yml for bootstrap/repair."""
    raw_name = (os.getenv("DBT_PROJECT_NAME") or project_name_hint or "dbt_project").strip()
    project_name = (re.sub(r"[^a-zA-Z0-9_]", "_", raw_name).strip("_") or "sttm_agent_validation")
    profile_name = (
        os.getenv("DBT_PROFILE")
        or os.getenv("DBT_PROFILE_NAME")
        or os.getenv("DBT_CLOUD_PROFILE")
        or "default"
    ).strip()

    rendered = (
        f'name: "{project_name}"\n'
        'version: "1.0.0"\n'
        "config-version: 2\n\n"
        f'profile: "{profile_name}"\n\n'
        'model-paths: ["models"]\n'
        'seed-paths: ["seeds"]\n'
        'macro-paths: ["macros"]\n'
        'snapshot-paths: ["snapshots"]\n'
        'analysis-paths: ["analyses"]\n'
        'test-paths: ["tests"]\n\n'
        'clean-targets:\n'
        '  - "target"\n'
        '  - "dbt_packages"\n'
    )
    return _sanitize_yaml_content(rendered)


def _normalize_test_entry(test_entry: Any) -> Any:
    """Migrate deprecated top-level generic test arguments under `arguments`."""
    if not isinstance(test_entry, dict) or len(test_entry) != 1:
        return test_entry

    test_name, config = next(iter(test_entry.items()))
    if not isinstance(config, dict):
        return test_entry

    moved_arguments = {key: config.pop(key) for key in list(config.keys()) if key in _LEGACY_TEST_ARGUMENT_KEYS}
    if moved_arguments:
        existing_arguments_raw = config.get("arguments")
        merged_arguments = dict(moved_arguments)
        if isinstance(existing_arguments_raw, dict):
            for key, value in existing_arguments_raw.items():
                merged_arguments[str(key)] = value
        config["arguments"] = merged_arguments
    return {test_name: config}


def _normalize_schema_tests(node: Any) -> Any:
    """Recursively normalize dbt schema test definitions."""
    if isinstance(node, list):
        return [_normalize_schema_tests(item) for item in node]
    if isinstance(node, dict):
        normalized: dict[str, Any] = {}
        for key, value in node.items():
            if key == "tests" and isinstance(value, list):
                normalized[key] = [_normalize_test_entry(_normalize_schema_tests(item)) for item in value]
            else:
                normalized[key] = _normalize_schema_tests(value)
        return normalized
    return node


def _extract_source_refs(files: Dict[str, str]) -> Dict[str, set[str]]:
    """Extract dbt source() references from generated SQL files."""
    refs: Dict[str, set[str]] = {}
    for filename, content in files.items():
        if not str(filename).lower().endswith(".sql"):
            continue
        for source_name, table_name in _SOURCE_CALL_PATTERN.findall(content or ""):
            refs.setdefault(source_name, set()).add(table_name)
    return refs


def _extract_ref_targets(files: Dict[str, str]) -> set[str]:
    """Extract dbt ref() targets from generated SQL files."""
    targets: set[str] = set()
    pattern = re.compile(r"ref\(\s*['\"]([^'\"]+)['\"]\s*\)", re.IGNORECASE)
    for filename, content in files.items():
        if not str(filename).lower().endswith(".sql"):
            continue
        for model_name in pattern.findall(content or ""):
            if model_name:
                targets.add(model_name)
    return targets


def _extract_defined_models(files: Dict[str, str]) -> set[str]:
    """Infer model names from SQL filenames in the extracted payload."""
    models: set[str] = set()
    for filename in files.keys():
        name = posixpath.basename(str(filename))
        lower = name.lower()
        if lower.endswith(".sql"):
            models.add(lower[:-4])
    return models


def _count_unresolved_refs(files: Dict[str, str]) -> int:
    """Count ref() targets that are not provided by the same extracted artifact set."""
    defined_models = _extract_defined_models(files)
    ref_targets = {target.lower() for target in _extract_ref_targets(files)}
    return sum(1 for target in ref_targets if target not in defined_models)


def _load_best_agent_output_markdown(require_code_blocks: bool = True, require_sql_files: bool = False) -> str:
    """Load the newest internally consistent agent output markdown across all sessions."""
    session_root = os.path.join(_REPO_ROOT, "session_storage")
    if not os.path.isdir(session_root):
        return ""

    candidates: list[tuple[int, float, str, str]] = []
    try:
        for sid in os.listdir(session_root):
            agents_root = os.path.join(session_root, sid, "agents")
            if not os.path.isdir(agents_root):
                continue
            for agent_name in os.listdir(agents_root):
                out_path = os.path.join(agents_root, agent_name, "output.md")
                if not os.path.isfile(out_path):
                    continue
                try:
                    with open(out_path, "r", encoding="utf-8") as fh:
                        preview = fh.read()
                except Exception:
                    continue

                if require_code_blocks and "```" not in preview:
                    continue

                extracted = _extract_files_from_markdown(preview)
                if require_sql_files and not any(name.lower().endswith(".sql") for name in extracted.keys()):
                    continue

                unresolved_refs = _count_unresolved_refs(extracted) if extracted else 9999
                mtime = os.path.getmtime(out_path)
                candidates.append((unresolved_refs, -mtime, preview, out_path))
    except Exception:
        return ""

    if not candidates and require_code_blocks:
        return _load_best_agent_output_markdown(require_code_blocks=False, require_sql_files=False)

    if not candidates:
        return ""

    candidates.sort(key=lambda item: (item[0], item[1]))
    return candidates[0][2]


def _merge_schema_sources(schema_data: Dict[str, Any], source_refs: Dict[str, set[str]]) -> Dict[str, Any]:
    """Ensure schema.yml declares all sources used by generated staging models."""
    existing_sources = schema_data.get("sources")
    if not isinstance(existing_sources, list):
        existing_sources = []

    source_index: Dict[str, Dict[str, Any]] = {}
    for source in existing_sources:
        if isinstance(source, dict) and isinstance(source.get("name"), str):
            source_index[source["name"]] = source

    for source_name, table_names in source_refs.items():
        source_entry = source_index.get(source_name)
        if source_entry is None:
            source_entry = {"name": source_name, "tables": []}
            existing_sources.append(source_entry)
            source_index[source_name] = source_entry

        tables = source_entry.get("tables")
        if not isinstance(tables, list):
            tables = []
            source_entry["tables"] = tables

        existing_table_names = {
            table.get("name") for table in tables if isinstance(table, dict) and isinstance(table.get("name"), str)
        }
        for table_name in sorted(table_names):
            if table_name not in existing_table_names:
                tables.append({"name": table_name})

    if existing_sources:
        schema_data["sources"] = existing_sources
    return schema_data


def _get_configured_source_location() -> tuple[str, str]:
    """Return configured source database/schema defaults for published dbt sources."""
    database_name = (
        os.getenv("DBT_SOURCE_DATABASE")
        or os.getenv("SOURCE_DATABASE_NAME")
        or os.getenv("SNOWFLAKE_DATABASE")
        or ""
    ).strip()
    schema_name = (
        os.getenv("DBT_SOURCE_SCHEMA")
        or os.getenv("SOURCE_SCHEMA_NAME")
        or os.getenv("SNOWFLAKE_SCHEMA")
        or ""
    ).strip()
    return database_name, schema_name


def _strip_unresolved_source_vars(schema_data: Dict[str, Any]) -> Dict[str, Any]:
    """Remove source database/schema vars that are not supplied at dbt runtime."""
    existing_sources = schema_data.get("sources")
    if not isinstance(existing_sources, list):
        return schema_data

    unresolved_patterns = {
        "{{ var('database_name') }}",
        '{{ var("database_name") }}',
        "{{var('database_name')}}",
        '{{var("database_name")}}',
        "{{ var('schema_name') }}",
        '{{ var("schema_name") }}',
        "{{var('schema_name')}}",
        '{{var("schema_name")}}',
    }

    for source in existing_sources:
        if not isinstance(source, dict):
            continue
        for key in ("database", "schema"):
            value = source.get(key)
            if isinstance(value, str) and value.strip() in unresolved_patterns:
                source.pop(key, None)

    return schema_data


def _fill_source_location_defaults(schema_data: Dict[str, Any]) -> Dict[str, Any]:
    """Fill source database/schema placeholders from configured defaults when available."""
    existing_sources = schema_data.get("sources")
    if not isinstance(existing_sources, list):
        return schema_data

    default_database, default_schema = _get_configured_source_location()
    placeholder_values = {
        "",
        "my_database",
        "my_schema",
        "<your_database_name>",
        "<your_schema_name>",
    }

    for source in existing_sources:
        if not isinstance(source, dict):
            continue

        raw_database = source.get("database")
        raw_schema = source.get("schema")

        if default_database and (not isinstance(raw_database, str) or raw_database.strip() in placeholder_values):
            source["database"] = default_database
        if default_schema and (not isinstance(raw_schema, str) or raw_schema.strip() in placeholder_values):
            source["schema"] = default_schema

    return schema_data


def _normalize_snowflake_compatibility(content: str) -> str:
    """Replace warehouse-incompatible type aliases with Snowflake-safe equivalents."""
    if not content:
        return content

    normalized = content
    replacements = [
        (r"\bint4\b", "integer"),
        (r"\bint8\b", "bigint"),
        (r"\bserial4\b", "integer"),
        (r"\bserial8\b", "bigint"),
    ]
    for pattern, replacement in replacements:
        normalized = re.sub(pattern, replacement, normalized, flags=re.IGNORECASE)
    return normalized


def _prepare_dbt_files(files: Dict[str, str]) -> Dict[str, str]:
    """Normalize generated dbt artifacts before publishing them to the repo."""
    prepared = {
        name: _normalize_snowflake_compatibility(content)
        for name, content in dict(files or {}).items()
    }
    schema_keys = [
        name for name in prepared.keys()
        if posixpath.basename(str(name)).lower() in {"schema.yml", "schema.yaml"}
    ]
    source_refs = _extract_source_refs(prepared)
    for schema_key in schema_keys:
        try:
            schema_data = yaml.safe_load(prepared[schema_key] or "")
        except Exception:
            continue
        if not isinstance(schema_data, dict):
            continue

        schema_data = _normalize_schema_tests(schema_data)
        schema_data = _strip_unresolved_source_vars(schema_data)
        schema_data = _fill_source_location_defaults(schema_data)
        schema_data = _merge_schema_sources(schema_data, source_refs)
        rendered = yaml.safe_dump(schema_data, sort_keys=False, allow_unicode=False)
        prepared[schema_key] = _sanitize_yaml_content(rendered if rendered.endswith("\n") else rendered + "\n")

    dbt_project_key = next(
        (name for name in prepared.keys() if posixpath.basename(str(name)).lower() == "dbt_project.yml"),
        None,
    )
    if dbt_project_key:
        prepared[dbt_project_key] = _sanitize_yaml_content(prepared[dbt_project_key])
    return prepared


def _target_repo_path(rel_path: str, timestamped_folder: str = "") -> str:
    """Map extracted dbt artifacts into stable repository paths expected by dbt.

    The timestamped folder is nested *inside* the dbt directory (models/, tests/, macros/)
    because dbt scans model-paths recursively; a top-level run folder would be invisible to it.
    """
    cleaned = (rel_path or "").strip().replace("\\", "/")
    filename = posixpath.basename(cleaned)
    lower = filename.lower()

    if lower == "dbt_project.yml":
        return "/dbt_project.yml"

    stamp = (timestamped_folder or "").strip().strip("/")

    def _under(top: str, *rest: str) -> str:
        parts = [p for p in (top, stamp, *rest, filename) if p]
        return "/" + "/".join(parts)

    if lower == "dialect_adapters.sql":
        return _under("macros")
    if lower.startswith(("test_", "assert_")) or any(token in lower for token in ("validation", "lookup")):
        return _under("tests")
    if lower.startswith(("stg_", "base_")):
        return _under("models", "staging")
    if lower.startswith("int_"):
        return _under("models", "intermediate")
    if lower.startswith(("fct_", "dim_", "mart_")):
        return _under("models", "marts")
    return _under("models")


def _extract_files_from_markdown(markdown_text: str) -> Dict[str, str]:
    """Extract SQL/YAML files from model output markdown.
    ADO-specific: flat file structure (basename only) with placeholder
    generation for mentioned files without code blocks.
    """
    if not markdown_text:
        return {}

    files: Dict[str, str] = {}
    
    # Regex patterns for extracting files from various markdown formats
    pattern_map = [
        # **Filename**: `path/to/file.sql`
        re.compile(
            r"\*\*Filename\*\*\s*:\s*`?(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`?\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
        # Filename: path/to/file.sql (no bold)
        re.compile(
            r"(?:^|\n)\s*Filename\s*:\s*`?(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`?\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
        # **File**: `path/to/file.sql` or File: `path/to/file.sql`
        re.compile(
            r"(?:^|\n)\s*(?:\*\*)?File(?:\*\*)?\s*:\s*`?(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`?\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
        # **File: `path/to/file.sql`**
        re.compile(
            r"(?:^|\n)\s*\*\*File\s*:\s*`?(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`?\*\*\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
        # **path/to/file.sql**
        re.compile(
            r"\*\*(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))\*\*\s*:?(?:\s*\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
        # `path/to/file.sql`
        re.compile(
            r"`(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`\s*(?:\r?\n)+\s*```(?:[A-Za-z0-9_\-]+)?\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
        # schema.yml / schema.yaml (without explicit filename)
        re.compile(
            r"schema\.ya?ml[^\n]*?(?:\r?\n)+\s*```yaml\s*\r?\n(?P<code>.*?)\r?\n\s*```",
            re.IGNORECASE | re.DOTALL,
        ),
    ]

    for pattern in pattern_map:
        for match in pattern.finditer(markdown_text):
            raw_name = (match.groupdict().get("filename") or "schema.yml").strip()
            code = (match.group("code") or "").strip()
            if not raw_name or not code:
                continue
            # ADO uses flat structure - just the basename
            normalized_name = _infer_repo_path_from_filename(raw_name)
            if normalized_name.lower().endswith((".yml", ".yaml")):
                code = _sanitize_yaml_content(code)
            files[normalized_name] = code + "\n"

    # Check for SQL files with path in comment
    commented_path_pattern = re.compile(
        r"\s*```(?P<lang>[A-Za-z0-9_\-]*)\s*\r?\n(?P<code>.*?)\r?\n\s*```",
        re.IGNORECASE | re.DOTALL,
    )
    sql_comment_path_pattern = re.compile(
        r"^\s*--\s*(?P<filename>(?:tests|models|macros|analyses|seeds|snapshots)/[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))\s*$",
        re.IGNORECASE | re.MULTILINE,
        )
    for block in commented_path_pattern.finditer(markdown_text):
        code = (block.group("code") or "").strip()
        if not code:
            continue
        comment_match = sql_comment_path_pattern.search(code)
        if not comment_match:
            continue
        raw_name = (comment_match.group("filename") or "").strip()
        normalized_name = _infer_repo_path_from_filename(raw_name)
        if normalized_name in files:
            continue
        files[normalized_name] = code + "\n"

    # Extract mentioned files (for placeholder generation)
    mention_pattern = re.compile(
        r"(?:^|\n)\s*(?:[-*]|\d+\.)?\s*`?(?P<filename>[A-Za-z0-9_\-./]+\.(?:sql|yml|yaml))`?\s*(?=$|\n)",
        re.IGNORECASE,
    )
    mentioned: set[str] = set()
    for match in mention_pattern.finditer(markdown_text):
        raw_name = (match.group("filename") or "").strip()
        if raw_name:
            mentioned.add(_infer_repo_path_from_filename(raw_name))

    # Generate placeholders for mentioned files without code blocks
    for filename in sorted(mentioned):
        if filename in files:
            continue
        lower = filename.lower()
        if lower == "dialect_adapters.sql":
            files[filename] = (
                "{% macro substr_safe(column_name, start_pos, length) %}\n"
                "  substr({{ column_name }}, {{ start_pos }}, {{ length }})\n"
                "{% endmacro %}\n"
            )
        elif lower in {"schema.yml", "schema.yaml"}:
            files[filename] = _sanitize_yaml_content("version: 2\nmodels: []\n")
        elif lower.endswith(".sql"):
            files[filename] = (
                "-- Placeholder generated because file was listed by LLM without code block.\n"
                f"-- file: {filename}\n"
            )

    return files


def _load_latest_agent_output_markdown(require_code_blocks: bool = True, require_sql_files: bool = False) -> str:
    """Best-effort load of latest agent output markdown across all sessions."""
    session_root = os.path.join(_REPO_ROOT, "session_storage")
    if not os.path.isdir(session_root):
        return ""

    latest_path = ""
    latest_mtime = -1.0
    try:
        for sid in os.listdir(session_root):
            agents_root = os.path.join(session_root, sid, "agents")
            if not os.path.isdir(agents_root):
                continue
            for agent_name in os.listdir(agents_root):
                out_path = os.path.join(agents_root, agent_name, "output.md")
                if not os.path.isfile(out_path):
                    continue
                if require_code_blocks:
                    try:
                        with open(out_path, "r", encoding="utf-8") as fh:
                            preview = fh.read()
                        if "```" not in preview:
                            continue
                        if require_sql_files:
                            extracted = _extract_files_from_markdown(preview)
                            if not any(name.lower().endswith(".sql") for name in extracted.keys()):
                                continue
                    except Exception:
                        continue
                mtime = os.path.getmtime(out_path)
                if mtime > latest_mtime:
                    latest_mtime = mtime
                    latest_path = out_path
    except Exception:
        return ""

    if not latest_path and require_code_blocks:
        return _load_latest_agent_output_markdown(require_code_blocks=False, require_sql_files=False)

    if not latest_path:
        return ""

    try:
        with open(latest_path, "r", encoding="utf-8") as fh:
            return fh.read()
    except Exception:
        return ""


def _list_branch_paths(headers: Dict[str, str], org: str, project: str, repo: str, branch_name: str, scope_path: str = "/") -> list[str]:
    """List repository item paths for a branch under a scope path."""
    base = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/items"
    params = {
        "scopePath": scope_path,
        "recursionLevel": "Full",
        "versionDescriptor.version": branch_name,
        "versionDescriptor.versionType": "branch",
        "includeContentMetadata": "true",
        "api-version": API_VERSION,
    }
    try:
        resp = requests.get(base, headers=headers, params=params, timeout=60)
        if resp.status_code != 200:
            return []
        payload = resp.json() if resp.content else {}
        return [str(v.get("path", "")) for v in payload.get("value", []) if isinstance(v, dict) and v.get("path")]
    except Exception:
        return []


def _get_file_content(headers: Dict[str, str], org: str, project: str, repo: str, path: str, branch_name: str) -> str:
    """Fetch raw file content from ADO branch path."""
    base = f"https://dev.azure.com/{org}/{project}/_apis/git/repositories/{repo}/items"
    params = {
        "path": path if path.startswith("/") else f"/{path}",
        "versionDescriptor.version": branch_name,
        "versionDescriptor.versionType": "branch",
        "includeContent": "true",
        "api-version": API_VERSION,
    }
    try:
        resp = requests.get(base, headers=headers, params=params, timeout=30)
        if resp.status_code != 200:
            return ""
        return resp.text or ""
    except Exception:
        return ""


def _collect_existing_yaml_repairs(headers: Dict[str, str], org: str, project: str, repo: str, branch_name: str) -> list[tuple[str, str]]:
    """Repair malformed YAML files already present in timestamped dbt folders."""
    repairs: list[tuple[str, str]] = []
    for path in _list_branch_paths(headers, org, project, repo, branch_name, "/"):
        lower = path.lower()
        if not lower.startswith(("/dbt_modelling_", "/dbt_testing_")):
            continue
        if not lower.endswith((".yml", ".yaml")):
            continue

        content = _get_file_content(headers, org, project, repo, path, branch_name)
        if not content:
            continue
        sanitized = _sanitize_yaml_content(content)
        if sanitized != content:
            try:
                yaml.safe_load(sanitized)
                repairs.append((path, sanitized if sanitized.endswith("\n") else sanitized + "\n"))
            except Exception:
                continue
    return repairs


@ado_mcp.tool()
def AdoPushFilesTool(
    files: Dict[str, str] | None = None,
    reviewed_output: str = "",
    commit_message: str = "Automated: add/update files",
    folder_prefix: str = "",
    org: str = "",
    project: str = "",
    repo: str = "",
    branch: str = "",
    base_branch: str = "",
    pat: str = "",
) -> Dict[str, Any]:
    """Push file content directly to Azure DevOps repository.

    All ADO credentials are read from env vars (ADO_ORG, ADO_PROJECT,
    ADO_REPO, ADO_BRANCH, ADO_BASE_BRANCH, ADO_PAT) — no UI input needed.
    """
    _org = org or os.getenv("ADO_ORG", "")
    _project = project or os.getenv("ADO_PROJECT", "")
    _repo = repo or os.getenv("ADO_REPO", "")
    _branch = branch or os.getenv("ADO_BRANCH", "")
    _base_branch = base_branch or os.getenv("ADO_BASE_BRANCH", "")
    _pat = pat or os.getenv("ADO_PAT", "")
    logger.error(
    "ADO TOOL INPUTS | org=%s project=%s repo=%s branch=%s base=%s pat=%s",
    org,
    project,
    repo,
    branch,
    base_branch,
    "***" if pat else "EMPTY",
    )

    logger.error(
        "ADO ENV INPUTS | ADO_ORG=%s ADO_PROJECT=%s ADO_REPO=%s ADO_BRANCH=%s ADO_BASE_BRANCH=%s ADO_PAT=%s",
        _org,
        _project,
        _repo,
        _branch,
        _base_branch,
        "***" if _pat else "EMPTY",
    )

    missing = [k for k, v in {
        "ADO_ORG": _org, "ADO_PROJECT": _project,
        "ADO_REPO": _repo, "ADO_BRANCH": _branch,
        "ADO_BASE_BRANCH": _base_branch, "ADO_PAT": _pat,
    }.items() if not v]
    if missing:
        return {"success": False, "error": f"Missing ADO credentials: {missing}"}

    normalized_files = dict(files or {})
    extracted_from_reviewed = _extract_files_from_markdown(reviewed_output) if reviewed_output else {}

    if not normalized_files:
        normalized_files = dict(extracted_from_reviewed)

    sql_count = sum(1 for name in normalized_files.keys() if str(name).lower().endswith(".sql"))
    if extracted_from_reviewed and sql_count == 0:
        normalized_files.update(extracted_from_reviewed)
        sql_count = sum(1 for name in normalized_files.keys() if str(name).lower().endswith(".sql"))

    if sql_count == 0:
        fallback_extracted = _extract_files_from_markdown(
            _load_best_agent_output_markdown(require_sql_files=True)
        )
        if not any(name.lower().endswith(".sql") for name in fallback_extracted.keys()):
            fallback_extracted = _extract_files_from_markdown(_load_best_agent_output_markdown())
        if fallback_extracted:
            normalized_files.update(fallback_extracted)

    if not normalized_files:
        return {
            "success": False,
            "error": "No files provided and no extractable SQL/YAML blocks found in reviewed output.",
        }

    normalized_files = _prepare_dbt_files(normalized_files)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    timestamped_folder = f"{_choose_timestamp_folder_prefix(normalized_files, folder_prefix)}_{timestamp}"

    headers = _ado_headers(_pat)
    _base_branch, base_branch_note = _resolve_base_branch(headers, _org, _project, _repo, _base_branch)
    urls = _ado_urls(_org, _project, _repo)

    base_has_dbt_project = _item_exists(headers, _org, _project, _repo, "/dbt_project.yml", _base_branch)
    repair_dbt_project = False
    if base_has_dbt_project:
        existing_dbt_project = _get_file_content(headers, _org, _project, _repo, "/dbt_project.yml", _base_branch)
        if not _is_valid_dbt_project_yaml(existing_dbt_project):
            logger.warning("Base branch /dbt_project.yml is invalid YAML; scheduling auto-repair")
            repair_dbt_project = True

    _ROOT_CONFIG_FILES = {"packages.yml"}

    file_list: list[tuple[str, str]] = []
    saw_dbt_project_in_payload = False
    for rel_path, content in normalized_files.items():
        rel_path = rel_path.lstrip("/").replace("\\", "/")
        rel_path = posixpath.normpath(rel_path)
        if rel_path in {"", ".", ".."} or rel_path.startswith("../"):
            logger.info("Skipping unsafe file path: %s", rel_path)
            continue

        filename = posixpath.basename(rel_path)
        basename = filename.lower()
        if basename == "dbt_project.yml":
            saw_dbt_project_in_payload = True
            if base_has_dbt_project:
                logger.info("Skipping dbt_project.yml (already exists in base branch): %s", rel_path)
                continue
            file_list.append(("/dbt_project.yml", content))
            base_has_dbt_project = True
            continue

        if basename in _ROOT_CONFIG_FILES:
            logger.info("Skipping config file to avoid PR conflict: %s", rel_path)
            continue

        file_list.append((_target_repo_path(rel_path, timestamped_folder), content))

    if not base_has_dbt_project and not saw_dbt_project_in_payload:
        logger.info("Base branch missing /dbt_project.yml; auto-creating minimal bootstrap config")
        file_list.append(("/dbt_project.yml", _default_dbt_project_yml(project_name_hint=_repo)))
        base_has_dbt_project = True
        if not _item_exists(headers, _org, _project, _repo, "/models/.gitkeep", _base_branch):
            file_list.append(("/models/.gitkeep", ""))

    if repair_dbt_project:
        file_list.append(("/dbt_project.yml", _default_dbt_project_yml(project_name_hint=_repo)))
        if not _item_exists(headers, _org, _project, _repo, "/models/.gitkeep", _base_branch):
            file_list.append(("/models/.gitkeep", ""))

    for repair_path, repair_content in _collect_existing_yaml_repairs(headers, _org, _project, _repo, _base_branch):
        if not any(existing_path == repair_path for existing_path, _ in file_list):
            file_list.append((repair_path, repair_content))

    if not file_list:
        return {"success": False, "error": "No pushable files after filtering root-level config files."}

    old_object_id = _reset_branch_to_base(headers, _org, _project, _repo, _branch, _base_branch)

    changes = []
    for rel_path, content in file_list:
        change_type = "edit" if _item_exists(headers, _org, _project, _repo, rel_path, _branch) else "add"
        changes.append({
            "changeType": change_type,
            "item": {"path": rel_path},
            "newContent": {"content": content, "contentType": "rawtext"},
        })

    push_payload = None
    last_resp = None
    for attempt in range(1, 16):
        resp = _push_once(headers, urls, old_object_id, _branch, changes, commit_message)
        logger.error(
            "ADO PUSH | status=%s | response=%s",
            resp.status_code,
            resp.text
        )
        if resp.status_code in (200, 201):
            push_payload = resp.json()
            break
        if _is_stale_ref_error(resp):
            last_resp = resp
            old_object_id = _get_ref_object_id(headers, urls, _branch)
            time.sleep(min((2 ** (attempt - 1)) + random.uniform(0, 1.0), 30))
            continue
        resp.raise_for_status()
    if push_payload is None:
        if last_resp is not None:
            last_resp.raise_for_status()
        raise RuntimeError("Push failed")

    repo_url = _ado_repo_web_url(_org, _project, _repo)
    result: Dict[str, Any] = {
        "success": True,
        "source_branch": _branch,
        "target_branch": _base_branch,
        "files_pushed": [p for p, _ in file_list],
        "timestamped_folder": timestamped_folder,
        "timestamped_folder_url": _ado_folder_web_url(_org, _project, _repo, timestamped_folder),
        "timestamp": _ts(),
        "repo_url": repo_url,
    }
    if base_branch_note:
        result["base_branch_resolution"] = base_branch_note

    pr = get_existing_pr(_org, _project, _repo, _pat, _branch, _base_branch) or create_pr(
        _org, _project, _repo, _pat, _branch, _base_branch,
        f"Automated update: {_branch} -> {_base_branch}",
        "Automated PR created by DAAN workflow.",
    )
    pr_id = pr.get("pullRequestId")
    result["pr"] = {
        "id": pr_id,
        "status": pr.get("status"),
        "url": repo_url,
        "pr_api_url": pr.get("url"),
        "source": _branch,
        "target": _base_branch,
    }

    if _bool(os.getenv("ADO_AUTO_COMPLETE"), False):
        source_commit = (((push_payload or {}).get("commits") or [{}])[0]).get("commitId")
        complete_pr(_org, _project, _repo, _pat, pr_id, squash=True, delete_source=False, last_merge_source=source_commit)
        final_pr = wait_for_pr_completion(_org, _project, _repo, _pat, pr_id)
        result["pr"]["status"] = final_pr.get("status")
        result["pr"]["mergeStatus"] = final_pr.get("mergeStatus")
        if (final_pr.get("status") or "").lower() == "completed" and _bool(os.getenv("DBT_AUTO_TRIGGER_AFTER_MERGE"), False):
            result["dbt_cloud_trigger"] = _trigger_dbt_cloud_run(
                git_branch=_base_branch,
                cause=f"Auto-triggered by DAAN after PR merge ({_branch} -> {_base_branch})",
            )

    return result


# ── Azure DevOps Work Item Synchronization Tools ──────────────────────────

def _wi_type(kind: str) -> str:
    """Map a generic kind string to ADO work item type."""
    kind_to_type = {
        "epic": "Epic",
        "feature": "Feature",
        "issue": "Issue",
        "task": "Task",
        "user_story": "User Story",
        "story": "User Story",
        "bug": "Bug",
    }
    k = (kind or "").strip().lower()
    return kind_to_type.get(k, (kind or "Task").strip().title() or "Task")


def _description_html(description: str, acceptance_criteria: list | None = None) -> str:
    """Format description and acceptance criteria as HTML for ADO."""
    parts: list[str] = []
    if description:
        parts.append(f"<div>{html.escape(description)}</div>")
    if acceptance_criteria:
        lis = "".join(f"<li>{html.escape(str(c))}</li>" for c in acceptance_criteria)
        parts.append(f"<div><b>Acceptance Criteria</b><ul>{lis}</ul></div>")
    return "".join(parts)


def _parent_url(org: str, project: str, parent_id: str) -> str:
    """Build ADO parent work item URL for linking."""
    return (
        f"https://dev.azure.com/{org}/{quote(project)}"
        f"/_apis/wit/workItems/{parent_id}"
    )


def _web_url(org: str, project: str, item_id: str) -> str:
    """Build web URL for an ADO work item."""
    return f"https://dev.azure.com/{org}/{quote(project)}/_workitems/edit/{item_id}"


def _wi_org_from_env() -> str:
    """Resolve the ADO organization for work-item operations from env vars."""
    org = (os.getenv("ADO_ORG") or "").strip()
    return org


def ado_is_configured() -> tuple[bool, str]:
    """Return ``(ok, reason)`` — whether ADO work-item credentials are present.

    Consumed by the publish orchestrator to decide whether the deterministic
    sync path can run for an agent targeting Azure DevOps.
    """
    org = _wi_org_from_env()
    project = (os.getenv("ADO_PROJECT") or "").strip()
    pat = (os.getenv("ADO_PAT") or "").strip()
    missing = [
        n for n, v in (
            ("ADO_ORG", org),
            ("ADO_PROJECT", project),
            ("ADO_PAT", pat),
        ) if not v
    ]
    if missing:
        return False, f"Missing ADO config: {', '.join(missing)}"
    return True, ""


@ado_mcp.tool()
def AdoCreateWorkItemTool(
    title: str,
    kind: str,
    description: str = "",
    acceptance_criteria: list | None = None,
    parent_id: str | None = None,
    org: str = "",
    project: str = "",
    pat: str = "",
) -> Dict[str, Any]:
    """Create a new work item in Azure DevOps.
    
    Supports Epic, Feature, Issue, Task, User Story, and Bug types.
    Optionally links to a parent Epic when parent_id is provided.
    """
    _org = org or os.getenv("ADO_ORG", "").strip()
    _project = project or os.getenv("ADO_PROJECT", "").strip()
    _pat = pat or os.getenv("ADO_PAT", "").strip()
    
    if not all([_org, _project, _pat, title]):
        return {"success": False, "error": "Missing required parameters: org, project, pat, title"}
    
    wi_type = _wi_type(kind)
    url = (
        f"https://dev.azure.com/{_org}/{quote(_project)}"
        f"/_apis/wit/workitems/${quote(wi_type)}?api-version={API_VERSION}"
    )
    
    body: list[dict[str, Any]] = [
        {"op": "add", "path": "/fields/System.Title", "value": str(title)[:255]},
    ]
    
    desc_html = _description_html(description or "", acceptance_criteria or [])
    if desc_html:
        body.append({"op": "add", "path": "/fields/System.Description", "value": desc_html})
    
    if parent_id:
        body.append({
            "op": "add",
            "path": "/relations/-",
            "value": {
                "rel": "System.LinkTypes.Hierarchy-Reverse",
                "url": _parent_url(_org, _project, str(parent_id)),
            },
        })
    
    try:
        headers = _ado_headers(_pat)
        headers["Content-Type"] = "application/json-patch+json"
        resp = requests.post(url, headers=headers, json=body, timeout=60)
        resp.raise_for_status()
        payload = resp.json()
        item_id = str(payload.get("id"))
        return {
            "success": True,
            "item_id": item_id,
            "title": title,
            "kind": kind,
            "url": _web_url(_org, _project, item_id),
        }
    except Exception as exc:
        error_msg = str(exc)
        if hasattr(exc, "response"):
            try:
                error_msg = f"HTTP {exc.response.status_code}: {exc.response.text[:300]}"
            except Exception:
                pass
        return {"success": False, "error": error_msg}


@ado_mcp.tool()
def AdoUpdateWorkItemTool(
    item_id: str,
    title: str | None = None,
    description: str | None = None,
    acceptance_criteria: list | None = None,
    parent_id: str | None = None,
    org: str = "",
    project: str = "",
    pat: str = "",
) -> Dict[str, Any]:
    """Update an existing work item in Azure DevOps.
    
    Updates title, description, and/or acceptance criteria.
    If parent_id is provided, ensures the parent link exists (self-healing for orphans).
    """
    _org = org or os.getenv("ADO_ORG", "").strip()
    _project = project or os.getenv("ADO_PROJECT", "").strip()
    _pat = pat or os.getenv("ADO_PAT", "").strip()
    
    if not all([_org, _project, _pat, item_id]):
        return {"success": False, "error": "Missing required parameters: org, project, pat, item_id"}
    
    url = (
        f"https://dev.azure.com/{_org}/{quote(_project)}"
        f"/_apis/wit/workitems/{item_id}?api-version={API_VERSION}"
    )
    
    body: list[dict[str, Any]] = []
    if title is not None:
        body.append({"op": "add", "path": "/fields/System.Title", "value": str(title)[:255]})
    
    if description is not None or acceptance_criteria is not None:
        desc_html = _description_html(description or "", acceptance_criteria or [])
        if desc_html:
            body.append({"op": "add", "path": "/fields/System.Description", "value": desc_html})
    
    if not body and not parent_id:
        return {"success": False, "error": "No updates provided (title, description, or parent_id required)"}
    
    try:
        headers = _ado_headers(_pat)
        headers["Content-Type"] = "application/json-patch+json"
        
        if body:
            resp = requests.patch(url, headers=headers, json=body, timeout=60)
            resp.raise_for_status()
        
        # Self-heal: ensure parent link exists if provided.
        if parent_id:
            get_url = f"{url}&$expand=relations"
            get = requests.get(get_url, headers=headers, timeout=60)
            get.raise_for_status()
            has_parent = False
            for rel in (get.json().get("relations") or []):
                if rel.get("rel") == "System.LinkTypes.Hierarchy-Reverse":
                    has_parent = True
                    break
            
            if not has_parent:
                parent_body = [{
                    "op": "add",
                    "path": "/relations/-",
                    "value": {
                        "rel": "System.LinkTypes.Hierarchy-Reverse",
                        "url": _parent_url(_org, _project, str(parent_id)),
                    },
                }]
                resp = requests.patch(url, headers=headers, json=parent_body, timeout=60)
                resp.raise_for_status()
        
        return {
            "success": True,
            "item_id": item_id,
            "title": title or "(unchanged)",
            "parent_healed": parent_id is not None,
            "url": _web_url(_org, _project, item_id),
        }
    except Exception as exc:
        error_msg = str(exc)
        if hasattr(exc, "response"):
            try:
                error_msg = f"HTTP {exc.response.status_code}: {exc.response.text[:300]}"
            except Exception:
                pass
        logger.warning("Update failed for item %s: %s", item_id, error_msg)
        return {"success": False, "error": error_msg}


@ado_mcp.tool()
def AdoDeleteWorkItemTool(
    item_id: str,
    org: str = "",
    project: str = "",
    pat: str = "",
) -> Dict[str, Any]:
    """Delete a work item from Azure DevOps.
    
    First attempts to set state to 'Removed' (soft-delete for Agile/Scrum).
    Falls back to hard DELETE for process templates that don't support Removed state.
    Items are recoverable from the project recycle bin.
    """
    _org = org or os.getenv("ADO_ORG", "").strip()
    _project = project or os.getenv("ADO_PROJECT", "").strip()
    _pat = pat or os.getenv("ADO_PAT", "").strip()
    
    if not all([_org, _project, _pat, item_id]):
        return {"success": False, "error": "Missing required parameters: org, project, pat, item_id"}
    
    base_url = (
        f"https://dev.azure.com/{_org}/{quote(_project)}"
        f"/_apis/wit/workitems/{item_id}"
    )
    
    headers = _ado_headers(_pat)
    headers["Content-Type"] = "application/json-patch+json"
    
    # Try soft-delete first (set state to Removed).
    try:
        resp = requests.patch(
            f"{base_url}?api-version={API_VERSION}",
            headers=headers,
            json=[{"op": "add", "path": "/fields/System.State", "value": "Removed"}],
            timeout=60,
        )
        if resp.status_code != 400:
            resp.raise_for_status()
            return {"success": True, "item_id": item_id, "method": "soft-delete (Removed state)"}
    except Exception as exc:
        logger.warning("Soft-delete failed for item %s: %s", item_id, str(exc)[:200])
    
    # Fall back to hard delete (recycle bin).
    try:
        resp = requests.delete(
            f"{base_url}?api-version={API_VERSION}",
            headers=headers,
            timeout=60,
        )
        resp.raise_for_status()
        return {"success": True, "item_id": item_id, "method": "hard-delete (recycle bin)"}
    except Exception as exc:
        error_msg = str(exc)
        if hasattr(exc, "response"):
            try:
                error_msg = f"HTTP {exc.response.status_code}: {exc.response.text[:300]}"
            except Exception:
                pass
        return {"success": False, "error": error_msg}


@ado_mcp.tool()
def AdoRenameAndLinkWorkItemTool(
    item_id: str,
    new_title: str | None = None,
    parent_id: str | None = None,
    org: str = "",
    project: str = "",
    pat: str = "",
) -> Dict[str, Any]:
    """Rename (retitle) and/or link a work item to a parent in Azure DevOps.
    
    Combines rename + parent-linking into a single operation.
    Useful for renaming stories while ensuring their parent Epic is correctly linked.
    """
    _org = org or os.getenv("ADO_ORG", "").strip()
    _project = project or os.getenv("ADO_PROJECT", "").strip()
    _pat = pat or os.getenv("ADO_PAT", "").strip()
    
    if not all([_org, _project, _pat, item_id]) or (new_title is None and parent_id is None):
        return {"success": False, "error": "Missing required parameters: org, project, pat, item_id, and (new_title or parent_id)"}
    
    url = (
        f"https://dev.azure.com/{_org}/{quote(_project)}"
        f"/_apis/wit/workitems/{item_id}?api-version={API_VERSION}"
    )
    
    headers = _ado_headers(_pat)
    headers["Content-Type"] = "application/json-patch+json"
    
    body: list[dict[str, Any]] = []
    if new_title:
        body.append({"op": "add", "path": "/fields/System.Title", "value": str(new_title)[:255]})
    
    try:
        if body:
            resp = requests.patch(url, headers=headers, json=body, timeout=60)
            resp.raise_for_status()
        
        # Ensure parent link if provided.
        if parent_id:
            get_url = f"{url}&$expand=relations"
            get = requests.get(get_url, headers=headers, timeout=60)
            get.raise_for_status()
            has_parent = False
            for rel in (get.json().get("relations") or []):
                if rel.get("rel") == "System.LinkTypes.Hierarchy-Reverse":
                    has_parent = True
                    break
            
            if not has_parent:
                parent_body = [{
                    "op": "add",
                    "path": "/relations/-",
                    "value": {
                        "rel": "System.LinkTypes.Hierarchy-Reverse",
                        "url": _parent_url(_org, _project, str(parent_id)),
                    },
                }]
                resp = requests.patch(url, headers=headers, json=parent_body, timeout=60)
                resp.raise_for_status()
        
        return {
            "success": True,
            "item_id": item_id,
            "renamed": new_title is not None,
            "new_title": new_title or "(unchanged)",
            "parent_linked": parent_id is not None,
            "url": _web_url(_org, _project, item_id),
        }
    except Exception as exc:
        error_msg = str(exc)
        if hasattr(exc, "response"):
            try:
                error_msg = f"HTTP {exc.response.status_code}: {exc.response.text[:300]}"
            except Exception:
                pass
        return {"success": False, "error": error_msg}


if __name__ == "__main__":
    logger.info("Starting Azure DevOps MCP Server...")
    ado_mcp.run(transport="stdio")
