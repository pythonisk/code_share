"""
Testing Automation MCP Server — Denodo to Fabric Migration Validation

Exposes SQL execution and API invocation tools so DAAN5 agents can
validate data migration from Denodo to Microsoft Fabric.

Auth / connection resolution (first match wins per system):

  Fabric SQL:
    1. FABRIC_SQL_ENDPOINT env var      — JDBC-style connection string
    2. FABRIC_TENANT_ID + FABRIC_CLIENT_ID + FABRIC_CLIENT_SECRET — service-principal OAuth
    3. FABRIC_BEARER_TOKEN env var      — direct bearer token

  Denodo:
    1. DENODO_JDBC_URL env var          — JDBC connection string
    2. DENODO_HOST + DENODO_PORT + DENODO_DATABASE + DENODO_USER + DENODO_PASSWORD

  API:
    Passed per-call via tool parameters; no global credential store for APIs.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

import requests
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

load_dotenv()
logger = logging.getLogger(__name__)

ta_mcp = FastMCP("Testing Automation MCP Server", "1.0.0")

# Required by mcp_toolset_provider convention.
mcp = ta_mcp

_FABRIC_SCOPE = "https://analysis.windows.net/powerbi/api/.default"
_FABRIC_SQLDW_SCOPE = "https://database.windows.net/.default"


# ---------------------------------------------------------------------------
# Timestamp helper
# ---------------------------------------------------------------------------

def _ts() -> str:
    return datetime.utcnow().isoformat(timespec="seconds") + "Z"


def _ok(**kw) -> Dict[str, Any]:
    return {"status": "success", "timestamp": _ts(), **kw}


def _err(msg: str, **kw) -> Dict[str, Any]:
    return {"status": "error", "message": msg, "timestamp": _ts(), **kw}


# ---------------------------------------------------------------------------
# Fabric SQL helpers
# ---------------------------------------------------------------------------

def _get_fabric_token(
    bearer_token: Optional[str] = None,
    tenant_id: Optional[str] = None,
    client_id: Optional[str] = None,
    client_secret: Optional[str] = None,
) -> Optional[str]:
    """Resolve a bearer token for Fabric SQL (Azure SQL DW scope)."""
    token = bearer_token or os.getenv("FABRIC_BEARER_TOKEN", "")
    if token:
        return token.strip()

    t = (tenant_id or os.getenv("FABRIC_TENANT_ID", "")).strip()
    c = (client_id or os.getenv("FABRIC_CLIENT_ID", "")).strip()
    s = (client_secret or os.getenv("FABRIC_CLIENT_SECRET", "")).strip()
    if not (t and c and s):
        return None

    resp = requests.post(
        f"https://login.microsoftonline.com/{t}/oauth2/v2.0/token",
        data={
            "grant_type": "client_credentials",
            "client_id": c,
            "client_secret": s,
            "scope": _FABRIC_SQLDW_SCOPE,
        },
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json().get("access_token")


def _run_fabric_sql(
    sql: str,
    endpoint: str,
    token: str,
    database: str,
    timeout: int = 120,
) -> Dict[str, Any]:
    """Execute SQL against a Fabric SQL analytics endpoint (REST API path)."""
    url = f"https://{endpoint}/v1/workspaces/query"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    payload = {"query": sql, "database": database}
    resp = requests.post(url, headers=headers, json=payload, timeout=timeout)
    resp.raise_for_status()
    data = resp.json()
    rows = data.get("rows", data.get("results", []))
    columns = data.get("columns", [])
    return {"rows": rows, "columns": columns, "row_count": len(rows)}


# ---------------------------------------------------------------------------
# Denodo helpers
# ---------------------------------------------------------------------------

def _get_denodo_session() -> requests.Session:
    """Build an authenticated requests.Session for Denodo REST API."""
    user = os.getenv("DENODO_USER", "")
    password = os.getenv("DENODO_PASSWORD", "")
    token = os.getenv("DENODO_BEARER_TOKEN", "")

    session = requests.Session()
    if token:
        session.headers["Authorization"] = f"Bearer {token}"
    elif user and password:
        session.auth = (user, password)
    return session


def _denodo_base_url() -> str:
    host = os.getenv("DENODO_HOST", "localhost")
    port = os.getenv("DENODO_PORT", "9090")
    database = os.getenv("DENODO_DATABASE", "")
    db_path = f"/{database}" if database else ""
    return f"http://{host}:{port}/denodo-data-catalog/api{db_path}"


def _run_denodo_sql(sql: str, timeout: int = 120) -> Dict[str, Any]:
    """Execute a SQL query against Denodo via its REST data-service endpoint."""
    base = _denodo_base_url()
    session = _get_denodo_session()
    url = f"{base}/views/query"
    payload = {"query": sql}
    resp = session.post(url, json=payload, timeout=timeout)
    resp.raise_for_status()
    data = resp.json()
    rows = data.get("elements", data.get("rows", []))
    columns = data.get("name", data.get("columns", []))
    return {"rows": rows, "columns": columns, "row_count": len(rows)}


# ---------------------------------------------------------------------------
# MCP Tool: execute_fabric_sql
# ---------------------------------------------------------------------------

@ta_mcp.tool()
def execute_fabric_sql(
    query: str,
    sql_endpoint: Optional[str] = None,
    database: Optional[str] = None,
    bearer_token: Optional[str] = None,
    tenant_id: Optional[str] = None,
    client_id: Optional[str] = None,
    client_secret: Optional[str] = None,
    timeout_seconds: int = 120,
) -> Dict[str, Any]:
    """
    Execute a SQL query against a Microsoft Fabric SQL analytics endpoint.

    Connection is resolved from parameters, then environment variables:
      FABRIC_SQL_ENDPOINT, FABRIC_DATABASE,
      FABRIC_BEARER_TOKEN  -or-  FABRIC_TENANT_ID + FABRIC_CLIENT_ID + FABRIC_CLIENT_SECRET

    Args:
        query:           SQL query to execute (ANSI SQL).
        sql_endpoint:    Fabric SQL endpoint hostname (overrides FABRIC_SQL_ENDPOINT).
        database:        Target database name (overrides FABRIC_DATABASE).
        bearer_token:    Direct bearer token (overrides FABRIC_BEARER_TOKEN).
        tenant_id:       Azure tenant ID for service-principal auth.
        client_id:       Service-principal client ID.
        client_secret:   Service-principal client secret.
        timeout_seconds: HTTP request timeout in seconds.

    Returns:
        dict with rows, columns, row_count on success; error dict on failure.
    """
    endpoint = (sql_endpoint or os.getenv("FABRIC_SQL_ENDPOINT", "")).strip()
    db = (database or os.getenv("FABRIC_DATABASE", "")).strip()

    if not endpoint:
        return _err("Fabric SQL endpoint not configured. Set FABRIC_SQL_ENDPOINT or pass sql_endpoint.")
    if not db:
        return _err("Fabric database not specified. Set FABRIC_DATABASE or pass database.")

    try:
        token = _get_fabric_token(bearer_token, tenant_id, client_id, client_secret)
        if not token:
            return _err("No Fabric auth credentials available. Configure FABRIC_BEARER_TOKEN or service-principal env vars.")

        result = _run_fabric_sql(query, endpoint, token, db, timeout_seconds)
        logger.info("Fabric SQL executed successfully. Rows returned: %d", result["row_count"])
        return _ok(**result)

    except requests.HTTPError as exc:
        logger.error("Fabric SQL HTTP error: %s", exc)
        return _err(f"Fabric SQL HTTP error: {exc.response.status_code} — {exc.response.text[:500]}")
    except Exception as exc:
        logger.exception("Unexpected error during Fabric SQL execution")
        return _err(f"Unexpected error: {exc}")


# ---------------------------------------------------------------------------
# MCP Tool: execute_denodo_sql
# ---------------------------------------------------------------------------

@ta_mcp.tool()
def execute_denodo_sql(
    query: str,
    host: Optional[str] = None,
    port: Optional[str] = None,
    database: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    timeout_seconds: int = 120,
) -> Dict[str, Any]:
    """
    Execute a SQL query against a Denodo Virtual DataPort (VDP) database.

    Connection is resolved from parameters, then environment variables:
      DENODO_HOST, DENODO_PORT, DENODO_DATABASE, DENODO_USER, DENODO_PASSWORD

    Args:
        query:           SQL query to execute.
        host:            Denodo server hostname (overrides DENODO_HOST).
        port:            Denodo REST API port (overrides DENODO_PORT).
        database:        Target VDP database name (overrides DENODO_DATABASE).
        username:        Denodo user (overrides DENODO_USER).
        password:        Denodo password (overrides DENODO_PASSWORD).
        timeout_seconds: HTTP request timeout in seconds.

    Returns:
        dict with rows, columns, row_count on success; error dict on failure.
    """
    if host:
        os.environ["DENODO_HOST"] = host
    if port:
        os.environ["DENODO_PORT"] = port
    if database:
        os.environ["DENODO_DATABASE"] = database
    if username:
        os.environ["DENODO_USER"] = username
    if password:
        os.environ["DENODO_PASSWORD"] = password

    try:
        result = _run_denodo_sql(query, timeout_seconds)
        logger.info("Denodo SQL executed successfully. Rows returned: %d", result["row_count"])
        return _ok(**result)

    except requests.HTTPError as exc:
        logger.error("Denodo SQL HTTP error: %s", exc)
        return _err(f"Denodo HTTP error: {exc.response.status_code} — {exc.response.text[:500]}")
    except Exception as exc:
        logger.exception("Unexpected error during Denodo SQL execution")
        return _err(f"Unexpected error: {exc}")


# ---------------------------------------------------------------------------
# MCP Tool: call_fabric_api
# ---------------------------------------------------------------------------

@ta_mcp.tool()
def call_fabric_api(
    endpoint_url: str,
    method: str = "GET",
    params: Optional[Dict[str, Any]] = None,
    body: Optional[Dict[str, Any]] = None,
    bearer_token: Optional[str] = None,
    tenant_id: Optional[str] = None,
    client_id: Optional[str] = None,
    client_secret: Optional[str] = None,
    timeout_seconds: int = 60,
) -> Dict[str, Any]:
    """
    Invoke a Microsoft Fabric REST API endpoint.

    Auth is resolved from parameters, then environment variables (FABRIC_*).

    Args:
        endpoint_url:    Full URL of the Fabric REST API endpoint.
        method:          HTTP method: GET, POST, PUT (default: GET).
        params:          URL query parameters as a dict.
        body:            Request body as a dict (for POST/PUT).
        bearer_token:    Direct bearer token.
        tenant_id / client_id / client_secret: Service-principal auth.
        timeout_seconds: HTTP request timeout.

    Returns:
        dict with http_status, response_body, response_headers on success.
    """
    try:
        token = _get_fabric_token(bearer_token, tenant_id, client_id, client_secret)
        if not token:
            return _err("No Fabric auth credentials. Configure FABRIC_BEARER_TOKEN or service-principal env vars.")

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        resp = requests.request(
            method.upper(),
            endpoint_url,
            headers=headers,
            params=params or {},
            json=body,
            timeout=timeout_seconds,
        )
        return _ok(
            http_status=resp.status_code,
            response_body=resp.json() if resp.content else {},
            response_headers=dict(resp.headers),
        )

    except requests.HTTPError as exc:
        return _err(f"Fabric API HTTP error: {exc.response.status_code} — {exc.response.text[:500]}")
    except Exception as exc:
        logger.exception("Unexpected error calling Fabric API")
        return _err(f"Unexpected error: {exc}")


# ---------------------------------------------------------------------------
# MCP Tool: call_denodo_api
# ---------------------------------------------------------------------------

@ta_mcp.tool()
def call_denodo_api(
    endpoint_path: str,
    method: str = "GET",
    params: Optional[Dict[str, Any]] = None,
    body: Optional[Dict[str, Any]] = None,
    host: Optional[str] = None,
    port: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    bearer_token: Optional[str] = None,
    timeout_seconds: int = 60,
) -> Dict[str, Any]:
    """
    Invoke a Denodo REST data-service API endpoint.

    Connection resolved from parameters, then DENODO_* environment variables.

    Args:
        endpoint_path:   Path relative to the Denodo base URL (e.g. '/views/employees').
        method:          HTTP method: GET, POST (default: GET).
        params:          URL query parameters as a dict.
        body:            Request body as a dict (for POST).
        host / port:     Override DENODO_HOST / DENODO_PORT.
        username / password / bearer_token: Auth credentials.
        timeout_seconds: HTTP request timeout.

    Returns:
        dict with http_status, response_body on success.
    """
    _h = (host or os.getenv("DENODO_HOST", "localhost")).strip()
    _p = (port or os.getenv("DENODO_PORT", "9090")).strip()
    base = f"http://{_h}:{_p}/denodo-data-catalog/api"
    url = base + endpoint_path

    session = requests.Session()
    _tok = bearer_token or os.getenv("DENODO_BEARER_TOKEN", "")
    _usr = username or os.getenv("DENODO_USER", "")
    _pwd = password or os.getenv("DENODO_PASSWORD", "")

    if _tok:
        session.headers["Authorization"] = f"Bearer {_tok}"
    elif _usr and _pwd:
        session.auth = (_usr, _pwd)
    else:
        return _err("No Denodo auth credentials. Set DENODO_USER+DENODO_PASSWORD or DENODO_BEARER_TOKEN.")

    try:
        resp = session.request(
            method.upper(), url, params=params or {}, json=body, timeout=timeout_seconds
        )
        return _ok(
            http_status=resp.status_code,
            response_body=resp.json() if resp.content else {},
        )

    except requests.HTTPError as exc:
        return _err(f"Denodo API HTTP error: {exc.response.status_code} — {exc.response.text[:500]}")
    except Exception as exc:
        logger.exception("Unexpected error calling Denodo API")
        return _err(f"Unexpected error: {exc}")


# ---------------------------------------------------------------------------
# Server entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    ta_mcp.run(transport="stdio")
