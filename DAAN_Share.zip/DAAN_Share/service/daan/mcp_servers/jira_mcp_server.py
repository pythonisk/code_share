"""
JIRA MCP Server - Issue Tracking and Project Management Operations
This module provides Model Context Protocol (MCP) server functionality for JIRA operations.
"""

import os
import json
import threading
import requests
from typing import Dict, List, Any, Optional
from datetime import datetime
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Initialize FastMCP server for JIRA
jira_mcp = FastMCP("JIRA MCP Server", "1.0.0")

# Alias for generic MCP server launching.
# Other MCP server modules in this repo expose `mcp`.
mcp = jira_mcp


class JIRAConnection:
    """
    Manages JIRA API connections and operations.
    """
    
    def __init__(self):
        self.jira_client = None
        self.server_url = None
        self.username = None
        
    def connect(self, server_url: str, username: str, api_token: str,
                verify_ssl: bool = True) -> Dict[str, Any]:
        """
        Establish connection to JIRA server.
        
        Args:
            server_url: JIRA server URL (e.g., 'https://yourcompany.atlassian.net')
            username: Username or email for authentication
            api_token: API token for authentication
            verify_ssl: Whether to verify SSL certificates
            
        Returns:
            Dict containing connection status and details
        """
        try:
            from jira import JIRA

            # Initialize JIRA client with minimal setup
            jira = JIRA(options={"server": server_url}, basic_auth=(username, api_token))
            
            # Store connection details
            self.jira_client = jira
            self.server_url = server_url
            self.username = username

            logger.info(f"Connected to JIRA: {server_url}")

            return {
                "status": "success",
                "message": f"Connected to JIRA server: {server_url}",
                "connection_details": {
                    "server_url": server_url,
                    "username": username
                },
                "timestamp": datetime.now().isoformat()
            }

        except Exception as e:
            logger.error(f"JIRA connection failed: {str(e)}")
            return {
                "status": "error",
                "message": f"Failed to connect to JIRA: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def create_issue(self, project_key: str, summary: str, issue_type: str,
                    description: Optional[str] = None, 
                    assignee: Optional[str] = None,
                    priority: Optional[str] = None,
                    labels: Optional[List[str]] = None,
                    custom_fields: Optional[Dict[str, Any]] = None,
                    parent_key: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a new JIRA issue.
        
        Args:
            project_key: JIRA project key (e.g., 'PROJ')
            summary: Issue summary/title
            issue_type: Issue type (e.g., 'Task', 'Story', 'Bug')
            description: Detailed issue description
            assignee: Username of assignee
            priority: Issue priority (e.g., 'High', 'Medium', 'Low')
            labels: List of labels to add
            custom_fields: Dictionary of custom field values
            parent_key: Parent issue key for creating child issues under Epic (e.g., 'PROJ-1')
            
        Returns:
            Dict containing created issue details
        """
        try:
            if not self.jira_client:
                return {
                    "status": "error",
                    "message": "No active connection. Please connect first."
                }
            
            # Build issue fields dictionary
            fields = {
                'project': {'key': project_key},
                'summary': summary,
                'issuetype': {'name': issue_type},
            }
            
            if description:
                # JIRA Python library expects a plain string for description
                # For Cloud, it will handle conversion to ADF format internally
                # Just pass the plain text with newlines preserved
                fields['description'] = description
                logger.info(f"Setting JIRA description ({len(description)} chars)")
            
            # Jira Cloud requires accountId for assignee; for Server, name may work
            if assignee:
                fields['assignee'] = {'accountId': assignee}
            
            if priority:
                fields['priority'] = {'name': priority}
            
            if labels:
                fields['labels'] = labels
            
            if parent_key:
                fields['parent'] = {'key': parent_key}
                logger.info(f"Setting parent issue: {parent_key}")
            
            # Add custom fields
            if custom_fields:
                fields.update(custom_fields)
            
            # Create the issue
            new_issue = self.jira_client.create_issue(fields=fields)
            
            logger.info(f"Successfully created issue: {new_issue.key}")
            
            return {
                "status": "success",
                "message": f"Issue created successfully: {new_issue.key}",
                "issue": {
                    "key": new_issue.key,
                    "id": new_issue.id,
                    "summary": summary,
                    "issue_type": issue_type,
                    "url": f"{self.server_url}/browse/{new_issue.key}"
                },
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Failed to create issue: {str(e)}")
            return {
                "status": "error",
                "message": f"Failed to create issue: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def get_issue(self, issue_key: str, fields: Optional[str] = None) -> Dict[str, Any]:
        """
        Retrieve details of a JIRA issue.
        
        Args:
            issue_key: JIRA issue key (e.g., 'PROJ-123')
            fields: Comma-separated list of fields to retrieve (default: all)
            
        Returns:
            Dict containing issue details
        """
        try:
            if not self.jira_client:
                return {
                    "status": "error",
                    "message": "No active connection. Please connect first."
                }
            
            # Get the issue
            issue = self.jira_client.issue(issue_key, fields=fields)
            
            # Extract relevant fields
            issue_data = {
                "key": issue.key,
                "id": issue.id,
                "summary": issue.fields.summary,
                "description": getattr(issue.fields, 'description', None),
                "status": issue.fields.status.name,
                "issue_type": issue.fields.issuetype.name,
                "priority": issue.fields.priority.name if hasattr(issue.fields, 'priority') and issue.fields.priority else None,
                "assignee": issue.fields.assignee.displayName if issue.fields.assignee else None,
                "reporter": issue.fields.reporter.displayName if issue.fields.reporter else None,
                "created": issue.fields.created,
                "updated": issue.fields.updated,
                "labels": issue.fields.labels if hasattr(issue.fields, 'labels') else [],
                "url": f"{self.server_url}/browse/{issue.key}"
            }
            
            logger.info(f"Successfully retrieved issue: {issue_key}")
            
            return {
                "status": "success",
                "message": f"Issue retrieved successfully: {issue_key}",
                "issue": issue_data,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Failed to get issue: {str(e)}")
            return {
                "status": "error",
                "message": f"Failed to get issue {issue_key}: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def update_issue(self, issue_key: str, fields: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update an existing JIRA issue.
        
        Args:
            issue_key: JIRA issue key (e.g., 'PROJ-123')
            fields: Dictionary of fields to update
            
        Returns:
            Dict containing update status
        """
        try:
            if not self.jira_client:
                return {
                    "status": "error",
                    "message": "No active connection. Please connect first."
                }
            
            # Get the issue
            issue = self.jira_client.issue(issue_key)
            
            # Update fields
            issue.update(fields=fields)
            
            logger.info(f"Successfully updated issue: {issue_key}")
            
            return {
                "status": "success",
                "message": f"Issue updated successfully: {issue_key}",
                "issue_key": issue_key,
                "updated_fields": list(fields.keys()),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Failed to update issue: {str(e)}")
            return {
                "status": "error",
                "message": f"Failed to update issue {issue_key}: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def search_issues(self, jql: str, max_results: int = 50, 
                     fields: Optional[str] = None) -> Dict[str, Any]:
        """
        Search for JIRA issues using JQL.
        
        Args:
            jql: JQL (JIRA Query Language) query string
            max_results: Maximum number of results to return
            fields: Comma-separated list of fields to retrieve
            
        Returns:
            Dict containing search results
        """
        try:
            if not self.jira_client:
                return {
                    "status": "error",
                    "message": "No active connection. Please connect first."
                }
            
            # Execute search
            issues = self.jira_client.search_issues(jql, maxResults=max_results, fields=fields)
            
            # Format results
            results = []
            for issue in issues:
                issue_data = {
                    "key": issue.key,
                    "summary": issue.fields.summary,
                    "status": issue.fields.status.name,
                    "issue_type": issue.fields.issuetype.name,
                    "assignee": issue.fields.assignee.displayName if issue.fields.assignee else None,
                    "url": f"{self.server_url}/browse/{issue.key}"
                }
                results.append(issue_data)
            
            logger.info(f"Search returned {len(results)} issues")
            
            return {
                "status": "success",
                "message": f"Search completed. Found {len(results)} issues",
                "query": jql,
                "count": len(results),
                "issues": results,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Search failed: {str(e)}")
            return {
                "status": "error",
                "message": f"Search failed: {str(e)}",
                "query": jql,
                "timestamp": datetime.now().isoformat()
            }
    
    def add_comment(self, issue_key: str, comment: str) -> Dict[str, Any]:
        """
        Add a comment to a JIRA issue.
        
        Args:
            issue_key: JIRA issue key (e.g., 'PROJ-123')
            comment: Comment text to add
            
        Returns:
            Dict containing comment creation status
        """
        try:
            if not self.jira_client:
                return {
                    "status": "error",
                    "message": "No active connection. Please connect first."
                }
            
            # Add comment
            new_comment = self.jira_client.add_comment(issue_key, comment)
            
            logger.info(f"Successfully added comment to issue: {issue_key}")
            
            return {
                "status": "success",
                "message": f"Comment added successfully to {issue_key}",
                "issue_key": issue_key,
                "comment_id": new_comment.id,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Failed to add comment: {str(e)}")
            return {
                "status": "error",
                "message": f"Failed to add comment to {issue_key}: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def transition_issue(self, issue_key: str, transition_name: str,
                        comment: Optional[str] = None) -> Dict[str, Any]:
        """
        Transition a JIRA issue to a different status.
        
        Args:
            issue_key: JIRA issue key (e.g., 'PROJ-123')
            transition_name: Name of the transition (e.g., 'Done', 'In Progress')
            comment: Optional comment to add with transition
            
        Returns:
            Dict containing transition status
        """
        try:
            if not self.jira_client:
                return {
                    "status": "error",
                    "message": "No active connection. Please connect first."
                }
            
            # Get available transitions
            transitions = self.jira_client.transitions(issue_key)
            
            # Find the matching transition
            transition_id = None
            for t in transitions:
                if t['name'].lower() == transition_name.lower():
                    transition_id = t['id']
                    break
            
            if not transition_id:
                available = [t['name'] for t in transitions]
                return {
                    "status": "error",
                    "message": f"Transition '{transition_name}' not found. Available transitions: {available}",
                    "available_transitions": available,
                    "timestamp": datetime.now().isoformat()
                }
            
            # Perform transition
            fields = {}
            if comment:
                fields['comment'] = [{'add': {'body': comment}}]
            
            self.jira_client.transition_issue(issue_key, transition_id, fields=fields)
            
            logger.info(f"Successfully transitioned issue {issue_key} to {transition_name}")
            
            return {
                "status": "success",
                "message": f"Issue {issue_key} transitioned to {transition_name}",
                "issue_key": issue_key,
                "transition": transition_name,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Failed to transition issue: {str(e)}")
            return {
                "status": "error",
                "message": f"Failed to transition issue {issue_key}: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def get_project_info(self, project_key: str) -> Dict[str, Any]:
        """
        Get information about a JIRA project.
        
        Args:
            project_key: JIRA project key (e.g., 'PROJ')
            
        Returns:
            Dict containing project details
        """
        try:
            if not self.jira_client:
                return {
                    "status": "error",
                    "message": "No active connection. Please connect first."
                }
            
            # Get project
            project = self.jira_client.project(project_key)
            
            project_data = {
                "key": project.key,
                "id": project.id,
                "name": project.name,
                "description": getattr(project, 'description', None),
                "lead": project.lead.displayName if hasattr(project, 'lead') and project.lead else None,
                "url": f"{self.server_url}/browse/{project.key}"
            }
            
            logger.info(f"Successfully retrieved project info: {project_key}")
            
            return {
                "status": "success",
                "message": f"Project information retrieved: {project_key}",
                "project": project_data,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Failed to get project info: {str(e)}")
            return {
                "status": "error",
                "message": f"Failed to get project info for {project_key}: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def disconnect(self) -> Dict[str, Any]:
        """
        Close the JIRA connection.
        
        Returns:
            Dict containing disconnection status
        """
        try:
            if self.jira_client:
                self.jira_client.close()
                self.jira_client = None
            
            logger.info("Successfully disconnected from JIRA")
            
            return {
                "status": "success",
                "message": "Successfully disconnected from JIRA",
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error during disconnection: {str(e)}")
            return {
                "status": "error",
                "message": f"Error during disconnection: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }


# Global connection instance
_jira_conn = JIRAConnection()


# ─────────────────────────────────────────────────────────────────
# MCP Tools for JIRA Operations
# ─────────────────────────────────────────────────────────────────
# These are the core standard MCP tools exposed to agents.
# Each tool wraps a corresponding Layer 1 method from JIRAConnection.

@jira_mcp.tool()
def JIRAConnectTool(
    server_url: Optional[str] = None,
    username: Optional[str] = None,
    api_token: Optional[str] = None,
    verify_ssl: Optional[bool] = None
) -> Dict[str, Any]:
    """
    JIRA Connection Tool - Establishes connection to JIRA server.
    
    Description:
    This tool connects to a JIRA server using the provided credentials (username and API token).
    It establishes a persistent connection that can be used for subsequent JIRA operations.
    Supports both cloud and on-premise JIRA instances.
    
    Use this tool when you need to:
    - Connect to JIRA for issue management operations
    - Establish a session for multiple JIRA queries
    - Verify JIRA server connectivity
    - Initialize JIRA operations in workflows
    
    Arguments:
    - server_url (str): JIRA server URL (e.g., 'https://yourcompany.atlassian.net')
    - username (str): Username or email for authentication
    - api_token (str): API token for authentication (generate from JIRA account settings)
    - verify_ssl (bool): Whether to verify SSL certificates (default: True)
    
    Returns:
    - Dict[str, Any]: Connection status with server details and timestamp
    
    Example:
        result = JIRAConnectTool(
            server_url="https://mycompany.atlassian.net",
            username="user@example.com",
            api_token="your_api_token_here",
            verify_ssl=True
        )
    """
    if server_url is None:
        server_url = os.getenv("JIRA_SERVER_URL") or os.getenv("JIRA_BASE_URL", "")
    if username is None:
        username = os.getenv("JIRA_USERNAME") or os.getenv("JIRA_EMAIL", "")
    if api_token is None:
        api_token = os.getenv("JIRA_API_TOKEN", "")
    if verify_ssl is None:
        verify_ssl = os.getenv("JIRA_VERIFY_SSL", "true").lower() == "true"
    
    return _jira_conn.connect(server_url, username, api_token, verify_ssl)


@jira_mcp.tool()
def JIRACreateIssueTool(
    project_key: str,
    summary: str,
    issue_type: str,
    description: Optional[str] = None,
    assignee: Optional[str] = None,
    priority: Optional[str] = None,
    labels: Optional[List[str]] = None,
    parent_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    JIRA Create Issue Tool - Creates a new JIRA issue.
    
    Description:
    This tool creates a new issue in JIRA with the specified details. It supports
    standard fields like summary, description, assignee, priority, and labels.
    Can also create child issues under Epics by specifying parent_key.
    
    Use this tool when you need to:
    - Create new tasks, bugs, or stories in JIRA
    - Log issues discovered during testing or operations
    - Create work items from automated workflows
    - Generate tickets from external systems
    - Create child issues under Epic parent issues
    
    Arguments:
    - project_key (str): JIRA project key (e.g., 'PROJ', 'DEV')
    - summary (str): Issue title/summary (required)
    - issue_type (str): Type of issue (e.g., 'Task', 'Story', 'Bug', 'Epic')
    - description (str, optional): Detailed description of the issue
    - assignee (str, optional): Username of the person to assign the issue to
    - priority (str, optional): Issue priority (e.g., 'High', 'Medium', 'Low')
    - labels (List[str], optional): List of labels to add to the issue
    - parent_key (str, optional): Parent issue key to create child issue under Epic (e.g., 'PROJ-1')
    
    Returns:
    - Dict[str, Any]: Created issue details including key, ID, and URL
    
    Example:
        result = JIRACreateIssueTool(
            project_key="KAN",
            summary="Test Story",
            issue_type="Story",
            description="Testing Jira MCP",
        )
        
        # Create story under epic
        result = JIRACreateIssueTool(
            project_key="KAN",
            summary="Authentication Story",
            issue_type="Story",
            description="Testing story creation",
        )
    
    Note: Connection must be established using JIRAConnectTool before using this tool.
    """
    return _jira_conn.create_issue(project_key, summary, issue_type, description, 
                                   assignee, priority, labels, None, parent_key)


@jira_mcp.tool()
def JIRAGetIssueTool(issue_key: str, fields: Optional[str] = None) -> Dict[str, Any]:
    """
    JIRA Get Issue Tool - Retrieves details of a JIRA issue.
    
    Description:
    This tool fetches comprehensive details of a specific JIRA issue by its key.
    Returns information including status, assignee, description, comments, and more.
    
    Use this tool when you need to:
    - Get current status and details of an issue
    - Check issue assignments and progress
    - Retrieve issue metadata for reporting
    - Verify issue existence before operations
    
    Arguments:
    - issue_key (str): JIRA issue key (e.g., 'PROJ-123', 'DEV-456')
    - fields (str, optional): Comma-separated list of specific fields to retrieve (default: all)
    
    Returns:
    - Dict[str, Any]: Issue details including key, summary, status, assignee, dates, and URL
    
    Example:
        result = JIRAGetIssueTool(
            issue_key="PROJ-123",
            fields="summary,status,assignee"
        )
    
    Note: Connection must be established using JIRAConnectTool before using this tool.
    """
    return _jira_conn.get_issue(issue_key, fields)


@jira_mcp.tool()
def JIRAUpdateIssueTool(issue_key: str, fields: Dict[str, Any]) -> Dict[str, Any]:
    """
    JIRA Update Issue Tool - Updates an existing JIRA issue.
    
    Description:
    This tool updates one or more fields of an existing JIRA issue. Supports updating
    summary, description, assignee, priority, labels, and custom fields.
    
    Use this tool when you need to:
    - Modify issue details or descriptions
    - Change issue assignments or priorities
    - Update issue labels or custom fields
    - Make bulk updates to issue metadata
    
    Arguments:
    - issue_key (str): JIRA issue key to update (e.g., 'PROJ-123')
    - fields (Dict[str, Any]): Dictionary of fields to update with their new values
    
    Returns:
    - Dict[str, Any]: Update status including issue key and updated field names
    
    Example:
        result = JIRAUpdateIssueTool(
            issue_key="PROJ-123",
            fields={
                "summary": "Updated issue title",
                "priority": {"name": "High"},
                "labels": ["urgent", "backend"]
            }
        )
    
    Note: Connection must be established using JIRAConnectTool before using this tool.
    """
    return _jira_conn.update_issue(issue_key, fields)


@jira_mcp.tool()
def JIRASearchIssuesTool(jql: str, max_results: int = 50, 
                        fields: Optional[str] = None) -> Dict[str, Any]:
    """
    JIRA Search Issues Tool - Searches for issues using JQL (JIRA Query Language).
    
    Description:
    This tool executes a JQL query to search for JIRA issues matching specified criteria.
    Returns a list of issues with their key details. Supports complex queries with
    filters, sorting, and field selection.
    
    Use this tool when you need to:
    - Find issues matching specific criteria
    - Generate reports on issue status or progress
    - Locate issues by assignee, project, or labels
    - Perform bulk analysis on multiple issues
    
    Arguments:
    - jql (str): JQL query string (e.g., 'project = PROJ AND status = "In Progress"')
    - max_results (int): Maximum number of results to return (default: 50)
    - fields (str, optional): Comma-separated list of fields to retrieve per issue
    
    Returns:
    - Dict[str, Any]: Search results including count, query, and list of matching issues
    
    Example:
        # Find all open bugs in project
        result = JIRASearchIssuesTool(
            jql='project = PROJ AND type = Bug AND status != Done',
            max_results=100
        )
        
        # Find issues assigned to user
        result = JIRASearchIssuesTool(
            jql='assignee = "john.doe" AND status = "In Progress"',
            max_results=20
        )
    
    Note: Connection must be established using JIRAConnectTool before using this tool.
    """
    return _jira_conn.search_issues(jql, max_results, fields)


@jira_mcp.tool()
def JIRAAddCommentTool(issue_key: str, comment: str) -> Dict[str, Any]:
    """
    JIRA Add Comment Tool - Adds a comment to a JIRA issue.
    
    Description:
    This tool adds a text comment to an existing JIRA issue. Useful for providing
    updates, additional context, or documentation on issues.
    
    Use this tool when you need to:
    - Add progress updates to issues
    - Document findings or decisions
    - Communicate with team members on issues
    - Log automated process updates
    
    Arguments:
    - issue_key (str): JIRA issue key (e.g., 'PROJ-123')
    - comment (str): Comment text to add to the issue
    
    Returns:
    - Dict[str, Any]: Comment creation status including issue key and comment ID
    
    Example:
        result = JIRAAddCommentTool(
            issue_key="PROJ-123",
            comment="Investigation complete. Root cause identified in authentication module."
        )
    
    Note: Connection must be established using JIRAConnectTool before using this tool.
    """
    return _jira_conn.add_comment(issue_key, comment)


@jira_mcp.tool()
def JIRATransitionIssueTool(issue_key: str, transition_name: str,
                           comment: Optional[str] = None) -> Dict[str, Any]:
    """
    JIRA Transition Issue Tool - Transitions a JIRA issue to a different status.
    
    Description:
    This tool moves an issue through its workflow by applying a transition (e.g., from
    "To Do" to "In Progress", or from "In Progress" to "Done"). Optionally adds a comment
    explaining the transition.
    
    Use this tool when you need to:
    - Update issue status through workflow
    - Mark issues as complete or in progress
    - Move issues between workflow states
    - Automate issue lifecycle management
    
    Arguments:
    - issue_key (str): JIRA issue key (e.g., 'PROJ-123')
    - transition_name (str): Name of transition to apply (e.g., 'Done', 'In Progress', 'Start Progress')
    - comment (str, optional): Optional comment to add with the transition
    
    Returns:
    - Dict[str, Any]: Transition status including issue key and new status
    
    Example:
        result = JIRATransitionIssueTool(
            issue_key="PROJ-123",
            transition_name="Done",
            comment="All tests passed. Ready for deployment."
        )
    
    Note: Connection must be established using JIRAConnectTool before using this tool.
    Note: Available transitions depend on the issue's current status and workflow configuration.
    """
    return _jira_conn.transition_issue(issue_key, transition_name, comment)


@jira_mcp.tool()
def JIRAGetProjectInfoTool(project_key: str) -> Dict[str, Any]:
    """
    JIRA Get Project Info Tool - Retrieves information about a JIRA project.
    
    Description:
    This tool fetches detailed information about a JIRA project including its name,
    description, lead, and configuration details.
    
    Use this tool when you need to:
    - Get project metadata and configuration
    - Verify project existence before operations
    - Retrieve project lead information
    - Understand project structure
    
    Arguments:
    - project_key (str): JIRA project key (e.g., 'PROJ', 'DEV')
    
    Returns:
    - Dict[str, Any]: Project details including key, name, description, lead, and URL
    
    Example:
        result = JIRAGetProjectInfoTool(project_key="PROJ")
    
    Note: Connection must be established using JIRAConnectTool before using this tool.
    """
    return _jira_conn.get_project_info(project_key)


@jira_mcp.tool()
def JIRADisconnectTool() -> Dict[str, Any]:
    """
    JIRA Disconnect Tool - Closes the active JIRA connection.
    
    Description:
    This tool properly closes the active JIRA connection and releases resources.
    It should be called when JIRA operations are complete to ensure clean resource management.
    
    Use this tool when you need to:
    - Close an active JIRA connection
    - Clean up resources after completing operations
    - Switch to a different JIRA server connection
    - End a JIRA session
    
    Arguments:
    - None
    
    Returns:
    - Dict[str, Any]: Disconnection status with message and timestamp
    
    Example:
        result = JIRADisconnectTool()
    """
    return _jira_conn.disconnect()


# ═════════════════════════════════════════════════════════════════════════════
#  DETERMINISTIC PUBLISH TOOLS
#  ---------------------------------------------------------------------------
#  These tools mirror the ADO deterministic work-item tools so the backend-
#  agnostic publish engine (daan.publish) can push EVERY parsed user story to
#  Jira in code — with the LLM completely out of the loop — instead of relying
#  on the agent to iterate and call the create tool per story (which silently
#  dropped stories once the model stopped early).
#
#  They are fully self-contained: credentials are resolved from environment
#  variables first, then from the database via CredentialResolver
#  (so the in-process deterministic path works without
#  the subprocess env injection). All Jira specifics live here; the publish
#  engine only wires these four callables via one entry in ``_MCP_BACKENDS``.
#
#  Epic-per-session: the publish engine loads a session's previously-created
#  resources from the Knowledge Graph and reconciles against them, so every
#  story in one session is linked to that session's single epic, and a new
#  session produces a new epic — no hardcoding in the workflow layer.
# ═════════════════════════════════════════════════════════════════════════════

_EPIC_KINDS = {"epic", "feature"}

# Cached authenticated client for the in-process deterministic path.
_publish_client = None
_publish_client_lock = threading.Lock()
_epic_link_field_cache: dict[str, Optional[str]] = {}


def _jira_publish_config() -> Dict[str, Any]:
    """Resolve Jira publish credentials: env vars first, then DB via CredentialResolver."""
    cfg: Dict[str, Any] = {
        "base_url": (os.getenv("JIRA_BASE_URL") or os.getenv("JIRA_SERVER_URL") or "").strip(),
        "username": (os.getenv("JIRA_USERNAME") or os.getenv("JIRA_EMAIL") or "").strip(),
        "api_token": (os.getenv("JIRA_API_TOKEN") or "").strip(),
        "project_key": (os.getenv("JIRA_PROJECT_KEY") or "").strip(),
        "verify_ssl": (os.getenv("JIRA_VERIFY_SSL", "true").lower() == "true"),
    }
    if not all([cfg["base_url"], cfg["username"], cfg["api_token"], cfg["project_key"]]):
        try:
            from daan.core.credential_resolver import CredentialResolver
            from daan.core.database import SessionLocal
            from daan.flow.context_vars import get_daan_user_id

            user_id = get_daan_user_id() or 0
            db = SessionLocal()
            try:
                resolver = CredentialResolver(db, user_id)
                creds = resolver.resolve("jira-mcp-server")
                cfg["base_url"] = cfg["base_url"] or str(creds.get("jira_base_url") or "").strip()
                cfg["username"] = cfg["username"] or str(creds.get("jira_username") or "").strip()
                cfg["api_token"] = cfg["api_token"] or str(creds.get("jira_api_token") or "").strip()
                cfg["project_key"] = cfg["project_key"] or str(creds.get("jira_project_key") or "").strip()
                if not os.getenv("JIRA_VERIFY_SSL") and creds.get("jira_verify_ssl") is not None:
                    cfg["verify_ssl"] = str(creds.get("jira_verify_ssl")).lower() == "true"
            finally:
                db.close()
        except Exception as exc:
            logger.debug("Could not read Jira credentials from DB: %s", exc)
    return cfg


def _get_publish_client():
    """Return a cached authenticated JIRA client for the deterministic path."""
    global _publish_client  # noqa: PLW0603
    if _publish_client is not None:
        return _publish_client
    with _publish_client_lock:
        if _publish_client is not None:
            return _publish_client
        from jira import JIRA

        cfg = _jira_publish_config()
        _publish_client = JIRA(
            options={"server": cfg["base_url"], "verify": cfg["verify_ssl"]},
            basic_auth=(cfg["username"], cfg["api_token"]),
        )
        return _publish_client


def _jira_issue_type(kind: str) -> str:
    """Map a generic kind to a Jira issue type name."""
    k = (kind or "").strip().lower()
    if k in _EPIC_KINDS:
        return "Epic"
    if k in {"bug", "defect"}:
        return "Bug"
    if k in {"task", "subtask", "sub_task", "sub-task"}:
        return "Task"
    return "Story"


def _is_issue_type_error(exc: Exception) -> bool:
    """True when a create error indicates the issue type is invalid/unavailable."""
    msg = str(exc).lower()
    return "issuetype" in msg or "issue type" in msg


def _jira_description(description: str, acceptance_criteria: Optional[List[Any]]) -> str:
    """Compose a plain-text description with an acceptance-criteria section."""
    parts: List[str] = []
    if description:
        parts.append(str(description))
    if acceptance_criteria:
        parts.append("")
        parts.append("Acceptance Criteria:")
        for c in acceptance_criteria:
            parts.append(f"- {c}")
    return "\n".join(parts).strip()


def _find_epic_link_field(client) -> Optional[str]:
    """Return the custom-field id for classic 'Epic Link', or None (cached)."""
    if "epic_link" in _epic_link_field_cache:
        return _epic_link_field_cache["epic_link"]
    field_id = None
    try:
        for f in client.fields():
            if str(f.get("name", "")).strip().lower() == "epic link":
                field_id = f.get("id")
                break
    except Exception as exc:  # noqa: BLE001
        logger.debug("Epic Link field lookup failed: %s", exc)
    _epic_link_field_cache["epic_link"] = field_id
    return field_id


def _link_issue_to_epic(client, issue_key: str, epic_key: str) -> bool:
    """Link a story to its epic, handling both team- and company-managed projects."""
    if not epic_key:
        return False
    try:
        issue = client.issue(issue_key)
    except Exception:
        return False
    # Team-managed (next-gen) and modern company-managed: the unified parent field.
    try:
        issue.update(fields={"parent": {"key": epic_key}})
        return True
    except Exception as exc:  # noqa: BLE001
        logger.debug("parent-field epic link failed for %s: %s", issue_key, exc)
    # Classic company-managed: the 'Epic Link' custom field.
    try:
        epic_field = _find_epic_link_field(client)
        if epic_field:
            issue.update(fields={epic_field: epic_key})
            return True
    except Exception as exc:  # noqa: BLE001
        logger.debug("Epic-Link-field link failed for %s: %s", issue_key, exc)
    return False


def jira_is_configured() -> tuple[bool, str]:
    """Return ``(ok, reason)`` — whether Jira publish credentials are present.

    Consumed by the publish orchestrator to decide whether the deterministic
    sync path can run for an agent targeting Jira.
    """
    cfg = _jira_publish_config()
    missing = [
        name for name, val in (
            ("jira_base_url", cfg["base_url"]),
            ("jira_username", cfg["username"]),
            ("jira_api_token", cfg["api_token"]),
            ("jira_project_key", cfg["project_key"]),
        ) if not val
    ]
    if missing:
        return False, f"Missing Jira config: {', '.join(missing)}"
    return True, ""


@jira_mcp.tool()
def JiraCreateWorkItemTool(
    title: str,
    kind: str,
    description: str = "",
    acceptance_criteria: Optional[List[Any]] = None,
    parent_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Create a Jira issue (Epic or Story) for deterministic publishing.

    Epics are created stand-alone; stories are linked to their session epic via
    ``parent_id`` (the epic's Jira key). Returns ``{success, item_id, url, error}``.
    """
    cfg = _jira_publish_config()
    if not cfg["project_key"]:
        return {"success": False, "error": "Missing Jira project key (set JIRA_PROJECT_KEY env var or configure in MCP Management)"}
    if not title:
        return {"success": False, "error": "Missing required parameter: title"}
    try:
        client = _get_publish_client()
    except Exception as exc:
        return {"success": False, "error": f"Jira connection failed: {exc}"}

    issue_type = _jira_issue_type(kind)
    is_epic = issue_type == "Epic"
    fields: Dict[str, Any] = {
        "project": {"key": cfg["project_key"]},
        "summary": str(title)[:250],
        "issuetype": {"name": issue_type},
    }
    desc = _jira_description(description or "", acceptance_criteria or [])
    if desc:
        fields["description"] = desc
    if parent_id and not is_epic:
        fields["parent"] = {"key": str(parent_id)}

    def _browse_url(key: str) -> str:
        return f"{cfg['base_url'].rstrip('/')}/browse/{key}"

    try:
        issue = client.create_issue(fields=fields)
        return {"success": True, "item_id": issue.key, "title": title, "kind": kind, "type": issue_type, "url": _browse_url(issue.key)}
    except Exception as exc:
        # Fallback 1: project rejects the inline parent field (classic Epic Link) —
        # create without parent, then link separately.
        if parent_id and not is_epic and "parent" in fields:
            try:
                fields_no_parent = {k: v for k, v in fields.items() if k != "parent"}
                issue = client.create_issue(fields=fields_no_parent)
                _link_issue_to_epic(client, issue.key, str(parent_id))
                return {"success": True, "item_id": issue.key, "title": title, "kind": kind, "type": issue_type, "url": _browse_url(issue.key)}
            except Exception as exc2:
                exc = exc2
        # Fallback 2: the mapped issue type genuinely does not exist in this
        # project → fall back to 'Task'. Gated on the error actually being about
        # the issue type so unrelated failures are surfaced (not masked as Task).
        if not is_epic and fields.get("issuetype", {}).get("name") != "Task" and _is_issue_type_error(exc):
            try:
                fields_task = {k: v for k, v in fields.items() if k != "parent"}
                fields_task["issuetype"] = {"name": "Task"}
                issue = client.create_issue(fields=fields_task)
                if parent_id:
                    _link_issue_to_epic(client, issue.key, str(parent_id))
                return {"success": True, "item_id": issue.key, "title": title, "kind": kind, "type": "Task", "url": _browse_url(issue.key)}
            except Exception as exc3:
                exc = exc3
        return {"success": False, "error": str(exc)}


@jira_mcp.tool()
def JiraUpdateWorkItemTool(
    item_id: str,
    title: Optional[str] = None,
    description: Optional[str] = None,
    acceptance_criteria: Optional[List[Any]] = None,
    parent_id: Optional[str] = None,
    kind: Optional[str] = None,
) -> Dict[str, Any]:
    """Update an existing Jira issue; self-heals the epic link when provided.

    When ``kind`` is supplied and differs from the issue's current type (e.g. a
    story created as ``Task`` in an earlier run before the ``Story`` type
    existed), the issue type is corrected best-effort so re-runs migrate items
    to the right type instead of leaving them as ``Task``.
    """
    if not item_id:
        return {"success": False, "error": "Missing required parameter: item_id"}
    cfg = _jira_publish_config()
    try:
        client = _get_publish_client()
    except Exception as exc:
        return {"success": False, "error": f"Jira connection failed: {exc}"}
    try:
        issue = client.issue(item_id)
        fields: Dict[str, Any] = {}
        if title is not None:
            fields["summary"] = str(title)[:250]
        if description is not None or acceptance_criteria is not None:
            desc = _jira_description(description or "", acceptance_criteria or [])
            if desc:
                fields["description"] = desc
        # Correct the issue type when it drifted from the desired kind.
        if kind:
            desired_type = _jira_issue_type(kind)
            try:
                current_type = str(getattr(issue.fields.issuetype, "name", "") or "")
            except Exception:
                current_type = ""
            if desired_type and desired_type.lower() != current_type.lower():
                fields["issuetype"] = {"name": desired_type}
        if fields:
            try:
                issue.update(fields=fields)
            except Exception as exc_upd:
                # An issue-type change can be rejected (e.g. team-managed
                # projects / incompatible required fields). Retry the rest of
                # the update without it rather than failing the whole item.
                if "issuetype" in fields:
                    logger.warning("Jira issue-type change rejected for %s: %s", item_id, exc_upd)
                    fields.pop("issuetype", None)
                    if fields:
                        issue.update(fields=fields)
                else:
                    raise
        if parent_id:
            _link_issue_to_epic(client, item_id, str(parent_id))
        result_type = ""
        try:
            result_type = str(client.issue(item_id).fields.issuetype.name or "")
        except Exception:
            result_type = _jira_issue_type(kind) if kind else ""
        return {
            "success": True,
            "item_id": item_id,
            "title": title or "(unchanged)",
            "type": result_type,
            "url": f"{cfg['base_url'].rstrip('/')}/browse/{item_id}",
        }
    except Exception as exc:
        logger.warning("Jira update failed for %s: %s", item_id, exc)
        return {"success": False, "error": str(exc)}


@jira_mcp.tool()
def JiraDeleteWorkItemTool(item_id: str) -> Dict[str, Any]:
    """Delete a Jira issue (used when a story is removed between runs)."""
    if not item_id:
        return {"success": False, "error": "Missing required parameter: item_id"}
    try:
        client = _get_publish_client()
    except Exception as exc:
        return {"success": False, "error": f"Jira connection failed: {exc}"}
    try:
        client.issue(item_id).delete()
        return {"success": True, "item_id": item_id, "method": "deleted"}
    except Exception as exc:
        logger.warning("Jira delete failed for %s: %s", item_id, exc)
        return {"success": False, "error": str(exc)}


if __name__ == "__main__":
    logger.info("Starting JIRA MCP Server...")
    jira_mcp.run(transport="stdio")
