"""ServiceNow MCP Server.

Exposes 5 tools backed by the real ServiceNow Table API:
- list_incidents
- get_incident
- update_incident
- add_comment
- publish_triage_decision

Environment variables (provided via DB credentials):
- SERVICENOW_BASE_URL (preferred) or BASE_URL
- SERVICENOW_USERNAME (preferred) or USERNAME
- SERVICENOW_PASSWORD (preferred) or PASSWORD
- SERVICENOW_VERIFY_SSL (preferred) or VERIFY_SSL
"""

from __future__ import annotations

import atexit
import json
import os
import signal
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests

# ---------------------------------------------------------------------------
# Bootstrap path so the server runs standalone or as a subprocess
# ---------------------------------------------------------------------------
_HERE = Path(__file__).resolve()
_SERVICE_DIR = _HERE.parents[2]  # …/service  (file sits at service/daan/mcp_servers/)
if str(_SERVICE_DIR) not in sys.path:
    sys.path.insert(0, str(_SERVICE_DIR))

from mcp.server.fastmcp import FastMCP  # noqa: E402  (after path fixup)
from daan.flow.session_service import append_jsonl_artifact  # noqa: E402


def _log(message: str) -> None:
    """Write diagnostics to stderr so MCP stdio payloads on stdout stay clean."""
    timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    print(f"[{timestamp}] [servicenow-mcp] {message}", file=sys.stderr, flush=True)


def _register_shutdown_logging() -> None:
    def _handle_signal(signum: int, _frame) -> None:
        _log(f"Shutdown signal received: {signal.Signals(signum).name}")
        raise SystemExit(0)

    atexit.register(lambda: _log("Server stopped"))

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, _handle_signal)
        except (ValueError, AttributeError):
            pass


def _get_env(primary: str, fallback: str) -> str:
    return str(os.getenv(primary) or os.getenv(fallback) or "").strip()


def _parse_bool(value: str, default: bool = True) -> bool:
    if not value:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


BASE_URL = _get_env("SERVICENOW_BASE_URL", "BASE_URL").rstrip("/")
USERNAME = _get_env("SERVICENOW_USERNAME", "USERNAME")
PASSWORD = _get_env("SERVICENOW_PASSWORD", "PASSWORD")
VERIFY_SSL = _parse_bool(_get_env("SERVICENOW_VERIFY_SSL", "VERIFY_SSL"), default=True)
REQUEST_TIMEOUT_SECONDS = float(os.getenv("SERVICENOW_TIMEOUT_SECONDS", "120"))
DAAN_SESSION_ID = str(os.getenv("DAAN_SESSION_ID") or "").strip()
_PUBLISH_EVENTS_PATH = "artifacts/servicenow_publish_events.jsonl"


def _auth_ready() -> tuple[bool, str | None]:
    if not BASE_URL:
        _log("AUTH CHECK FAILED: Missing BASE_URL/SERVICENOW_BASE_URL")
        return False, "Missing BASE_URL/SERVICENOW_BASE_URL"
    if not USERNAME:
        _log("AUTH CHECK FAILED: Missing USERNAME/SERVICENOW_USERNAME")
        return False, "Missing USERNAME/SERVICENOW_USERNAME"
    if not PASSWORD:
        _log("AUTH CHECK FAILED: Missing PASSWORD/SERVICENOW_PASSWORD")
        return False, "Missing PASSWORD/SERVICENOW_PASSWORD"
    return True, None


def _api_get(path: str, *, params: dict[str, Any] | None = None) -> dict[str, Any]:
    ok, error = _auth_ready()
    if not ok:
        return {"error": error}

    url = f"{BASE_URL}{path}"
    try:
        response = requests.get(
            url,
            params=params,
            auth=(USERNAME, PASSWORD),
            timeout=REQUEST_TIMEOUT_SECONDS,
            verify=VERIFY_SSL,
        )
        if response.status_code >= 400:
            return {
                "error": f"ServiceNow GET failed ({response.status_code})",
                "details": response.text[:500],
            }
        return response.json()
    except Exception as exc:
        return {"error": f"ServiceNow GET exception: {exc}"}


def _api_patch(path: str, payload: dict[str, Any]) -> dict[str, Any]:
    ok, error = _auth_ready()
    if not ok:
        return {"error": error}

    url = f"{BASE_URL}{path}"
    try:
        response = requests.patch(
            url,
            json=payload,
            auth=(USERNAME, PASSWORD),
            timeout=REQUEST_TIMEOUT_SECONDS,
            verify=VERIFY_SSL,
        )
        if response.status_code >= 400:
            return {
                "error": f"ServiceNow PATCH failed ({response.status_code})",
                "details": response.text[:500],
            }
        return response.json()
    except Exception as exc:
        return {"error": f"ServiceNow PATCH exception: {exc}"}


def _extract_text(value: Any) -> str:
    if isinstance(value, dict):
        return str(value.get("display_value") or value.get("value") or "")
    return str(value or "")


def _write_publish_event(tool_name: str, payload: dict[str, Any]) -> None:
    if not DAAN_SESSION_ID:
        return

    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "tool": tool_name,
        **payload,
    }
    try:
        append_jsonl_artifact(DAAN_SESSION_ID, _PUBLISH_EVENTS_PATH, record)
    except Exception as exc:
        _log(f"Failed to persist publish event for {tool_name}: {exc!r}")


# Fields fetched from ServiceNow for every incident query
_INCIDENT_FIELDS = (
    "sys_id,number,short_description,description,priority,impact,urgency,state,category,assigned_to,opened_at"
)


def _normalize_incident(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": _extract_text(row.get("number") or row.get("sys_id")),
        "sys_id": _extract_text(row.get("sys_id")),
        "number": _extract_text(row.get("number")),
        "short_description": _extract_text(row.get("short_description")),
        "description": _extract_text(row.get("description")),
        "priority": _extract_text(row.get("priority")),
        "impact": _extract_text(row.get("impact")),
        "urgency": _extract_text(row.get("urgency")),
        "state": _extract_text(row.get("state")),
        "category": _extract_text(row.get("category")),
        "assigned_to": _extract_text(row.get("assigned_to")),
        "opened_at": _extract_text(row.get("opened_at")),
        "comments": [],
    }


def _read_incident_snapshot(incident_id: str, sys_id: str | None = None) -> dict[str, Any] | None:
    path = f"/api/now/table/incident/{sys_id}" if sys_id else "/api/now/table/incident"
    params: dict[str, Any] = {
        "sysparm_fields": _INCIDENT_FIELDS,
        "sysparm_display_value": "all",
        "sysparm_exclude_reference_link": "true",
    }
    if not sys_id:
        params["sysparm_query"] = f"number={incident_id}^ORsys_id={incident_id}"
        params["sysparm_limit"] = 1

    data = _api_get(path, params=params)
    if "error" in data:
        return None

    result = data.get("result")
    if isinstance(result, list):
        if not result:
            return None
        row = result[0]
    elif isinstance(result, dict):
        row = result
    else:
        return None

    return _normalize_incident(row)


def _resolve_incident_sys_id(incident_id: str) -> tuple[str | None, str | None]:
    query = f"number={incident_id}^ORsys_id={incident_id}"
    data = _api_get(
        "/api/now/table/incident",
        params={
            "sysparm_query": query,
            "sysparm_limit": 1,
            "sysparm_fields": "sys_id,number",
        },
    )
    if "error" in data:
        return None, str(data.get("error"))
    result = data.get("result") or []
    if not result:
        return None, f"Incident '{incident_id}' not found"
    row = result[0]
    return str(row.get("sys_id") or ""), None


def _normalize_priority(priority: str) -> str:
    p = str(priority or "").strip().upper()
    mapping = {
        "P1": "1",
        "P2": "2",
        "P3": "3",
        "P4": "4",
        "P5": "5",
    }
    return mapping.get(p, str(priority or "").strip())


def _priority_from_impact_urgency(impact: str, urgency: str) -> str:
    """Derive ServiceNow numeric priority from impact and urgency when possible."""
    i = str(impact or "").strip()
    u = str(urgency or "").strip()
    matrix = {
        ("1", "1"): "1",
        ("1", "2"): "2",
        ("1", "3"): "3",
        ("2", "1"): "2",
        ("2", "2"): "3",
        ("2", "3"): "4",
        ("3", "1"): "3",
        ("3", "2"): "4",
        ("3", "3"): "5",
    }
    return matrix.get((i, u), "")


def _extract_level(value: str) -> str:
    """Extract numeric level from values like 'P2', '2', or '2 - Medium'."""
    text = str(value or "").strip().upper()
    if not text:
        return ""
    if text.startswith("P") and len(text) > 1 and text[1].isdigit():
        return text[1]
    if text[0].isdigit():
        return text[0]
    for ch in text:
        if ch.isdigit():
            return ch
    return text


def _safe_parse_json(value: str) -> dict[str, Any]:
    """Parse a JSON object string into a dict; return {} when invalid."""
    payload = str(value or "").strip()
    if not payload:
        return {}
    try:
        parsed = json.loads(payload)
    except (ValueError, TypeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _coerce_publish_rows(decisions: Any) -> tuple[list[dict[str, Any]], str | None]:
    """Normalize publish input into a list of incident decision rows."""
    parsed: Any
    if isinstance(decisions, (list, dict)):
        parsed = decisions
    else:
        raw = str(decisions or "").strip()
        if not raw:
            return [], "Input cannot be empty. Provide a JSON array or object with a results/incidents/items list."

        try:
            parsed = json.loads(raw)
        except (ValueError, TypeError) as exc:
            return [], f"Invalid JSON input: {exc}"

    rows: list[dict[str, Any]] = []
    if isinstance(parsed, list):
        rows = [r for r in parsed if isinstance(r, dict)]
    elif isinstance(parsed, dict):
        for key in ("results", "incidents", "items"):
            candidate = parsed.get(key)
            if isinstance(candidate, list):
                rows = [r for r in candidate if isinstance(r, dict)]
                break
        if not rows and all(k in parsed for k in ("incident_id",)):
            rows = [parsed]
    else:
        return [], "JSON root must be an array or an object."

    if not rows:
        return [], "No incident rows found. Expected a list under results/incidents/items."

    return rows, None


def _pick_text(row: dict[str, Any], keys: tuple[str, ...]) -> str:
    """Pick the first non-empty string-like value from a row."""
    for key in keys:
        value = row.get(key)
        if value in (None, ""):
            continue
        text = str(value).strip()
        if text:
            return text
    return ""


def _default_comment(
    incident_id: str,
    impact: str,
    urgency: str,
    priority: str,
    category: str,
) -> str:
    """Build a deterministic fallback work note when none is provided."""
    return (
        f"Automated triage decision published for {incident_id}. "
        f"impact={impact or '-'}; urgency={urgency or '-'}; "
        f"priority={priority or '-'}; category={category or '-'}"
    )


# ---------------------------------------------------------------------------
# MCP server
# ---------------------------------------------------------------------------
mcp_app = FastMCP("servicenow-mcp")


@mcp_app.tool()
def list_incidents(offset: int = 0, limit: int = 50, state: str = "1") -> str:
    """List ServiceNow incidents with pagination.

    Returns a JSON array of incident objects.
    Returns an empty JSON array [] when offset exceeds total incidents — use
    this as the loop-termination signal.

    Args:
        offset: Starting index (0-based).
        limit:  Maximum number of incidents to return.
        state:  ServiceNow state filter. Default '1' = New. Pass '' to fetch all states.
    """
    params: dict[str, Any] = {
        "sysparm_offset": max(int(offset or 0), 0),
        "sysparm_limit": max(int(limit or 10), 1),
        "sysparm_fields": _INCIDENT_FIELDS,
        "sysparm_display_value": "all",
        "sysparm_exclude_reference_link": "true",
    }
    state_filter = str(state or "").strip()
    if state_filter:
        params["sysparm_query"] = f"state={state_filter}"

    data = _api_get("/api/now/table/incident", params=params)
    if "error" in data:
        return json.dumps({"error": data.get("error"), "details": data.get("details", "")})

    rows = data.get("result") or []
    normalized = [_normalize_incident(row) for row in rows if isinstance(row, dict)]
    return json.dumps(normalized, ensure_ascii=False)


@mcp_app.tool()
def get_incident(incident_id: str) -> str:
    """Get a single ServiceNow incident by ID.

    Args:
        incident_id: The incident ID, e.g. 'INC0010001'.
    """
    data = _api_get(
        "/api/now/table/incident",
        params={
            "sysparm_query": f"number={incident_id}^ORsys_id={incident_id}",
            "sysparm_limit": 1,
            "sysparm_fields": _INCIDENT_FIELDS,
            "sysparm_display_value": "all",
            "sysparm_exclude_reference_link": "true",
        },
    )
    if "error" in data:
        return json.dumps({"error": data.get("error"), "details": data.get("details", "")})
    result = data.get("result") or []
    if not result:
        return json.dumps({"error": f"Incident '{incident_id}' not found"})
    return json.dumps(_normalize_incident(result[0]), ensure_ascii=False)


@mcp_app.tool()
def update_incident(
    incident_id: str,
    impact: str = "",
    urgency: str = "",
    priority: str = "",
    category: str = "",
) -> str:
    """Update a ServiceNow incident. Prefer impact+urgency — ServiceNow derives priority from these.

    Args:
        incident_id: The incident ID to update (e.g. 'INC0010001').
        impact:      Impact value: '1' (High), '2' (Medium), '3' (Low).
        urgency:     Urgency value: '1' (High), '2' (Medium), '3' (Low).
        priority:    Optional priority fallback — used only when impact+urgency are not provided.
        category:    Optional new category value.
    """
    sys_id, resolve_error = _resolve_incident_sys_id(incident_id)
    if resolve_error or not sys_id:
        _write_publish_event(
            "update_incident",
            {
                "incident_id": incident_id,
                "status": "error",
                "verified": False,
                "error": resolve_error or f"Incident '{incident_id}' not found",
                "requested_priority": str(priority or "").strip(),
                "requested_impact": str(impact or "").strip(),
                "requested_urgency": str(urgency or "").strip(),
                "requested_category": str(category or "").strip(),
            },
        )
        return json.dumps(
            {
                "status": "error",
                "update_status": "error",
                "incident_id": incident_id,
                "error": resolve_error or f"Incident '{incident_id}' not found",
            }
        )

    payload: dict[str, Any] = {}
    if impact:
        payload["impact"] = str(impact).strip()
    if urgency:
        payload["urgency"] = str(urgency).strip()
    if priority and not (impact and urgency):
        # Only use direct priority write when neither impact nor urgency provided
        payload["priority"] = _normalize_priority(priority)
    if category:
        payload["category"] = category

    if not payload:
        _write_publish_event(
            "update_incident",
            {
                "incident_id": incident_id,
                "sys_id": sys_id,
                "status": "error",
                "verified": False,
                "error": "No fields to update. Provide at least impact, urgency, or priority.",
                "requested_priority": str(priority or "").strip(),
                "requested_impact": str(impact or "").strip(),
                "requested_urgency": str(urgency or "").strip(),
                "requested_category": str(category or "").strip(),
            },
        )
        return json.dumps(
            {
                "status": "error",
                "update_status": "error",
                "incident_id": incident_id,
                "error": "No fields to update. Provide at least impact, urgency, or priority.",
            }
        )

    previous = _read_incident_snapshot(incident_id, sys_id=sys_id) or {}

    data = _api_patch(f"/api/now/table/incident/{sys_id}", payload)
    if "error" in data:
        _write_publish_event(
            "update_incident",
            {
                "incident_id": incident_id,
                "sys_id": sys_id,
                "status": "error",
                "verified": False,
                "error": str(data.get("error") or ""),
                "details": str(data.get("details") or ""),
                "requested_priority": str(priority or "").strip(),
                "requested_impact": str(impact or "").strip(),
                "requested_urgency": str(urgency or "").strip(),
                "requested_category": str(category or "").strip(),
            },
        )
        return json.dumps(
            {
                "status": "error",
                "update_status": "error",
                "incident_id": incident_id,
                "error": data.get("error"),
                "details": data.get("details", ""),
            }
        )

    visible = _read_incident_snapshot(incident_id, sys_id=sys_id) or {}
    previous_priority = str(previous.get("priority") or "").strip()
    previous_impact = str(previous.get("impact") or "").strip()
    previous_urgency = str(previous.get("urgency") or "").strip()
    previous_category = str(previous.get("category") or "").strip()
    requested_priority = str(priority or "").strip()
    requested_impact = str(impact or "").strip()
    requested_urgency = str(urgency or "").strip()
    requested_category = str(category or "").strip()
    if not requested_priority and requested_impact and requested_urgency:
        requested_priority = _priority_from_impact_urgency(requested_impact, requested_urgency)

    visible_priority = str(visible.get("priority") or "").strip()
    visible_impact = str(visible.get("impact") or "").strip()
    visible_urgency = str(visible.get("urgency") or "").strip()
    visible_category = str(visible.get("category") or "").strip()

    priority_ok = (not requested_priority) or (
        _extract_level(visible_priority) == _extract_level(requested_priority)
    )
    impact_ok = (not requested_impact) or (
        _extract_level(visible_impact) == _extract_level(requested_impact)
    )
    urgency_ok = (not requested_urgency) or (
        _extract_level(visible_urgency) == _extract_level(requested_urgency)
    )
    category_ok = (not requested_category) or (visible_category == requested_category)
    verified = priority_ok and impact_ok and urgency_ok and category_ok
    status = "success" if verified else "mismatch"

    _write_publish_event(
        "update_incident",
        {
            "incident_id": incident_id,
            "sys_id": sys_id,
            "status": status,
            "verified": verified,
            "requested_priority": requested_priority,
            "visible_priority": visible_priority,
            "previous_priority": previous_priority,
            "requested_impact": requested_impact,
            "visible_impact": visible_impact,
            "previous_impact": previous_impact,
            "requested_urgency": requested_urgency,
            "visible_urgency": visible_urgency,
            "previous_urgency": previous_urgency,
            "requested_category": requested_category,
            "visible_category": visible_category,
            "previous_category": previous_category,
        },
    )

    return json.dumps(
        {
            "status": "updated",
            "update_status": status,
            "incident_id": incident_id,
            "sys_id": sys_id,
            "impact": visible.get("impact", payload.get("impact", "")),
            "urgency": visible.get("urgency", payload.get("urgency", "")),
            "priority": visible.get("priority", ""),
            "category": visible.get("category", payload.get("category", "")),
        },
        ensure_ascii=False,
    )


@mcp_app.tool()
def add_comment(incident_id: str, comment: str) -> str:
    """Add a work note / comment to a ServiceNow incident.

    Args:
        incident_id: The incident ID to comment on.
        comment:     The comment text to append.
    """
    sys_id, resolve_error = _resolve_incident_sys_id(incident_id)
    if resolve_error or not sys_id:
        _write_publish_event(
            "add_comment",
            {
                "incident_id": incident_id,
                "status": "error",
                "verified": False,
                "error": resolve_error or f"Incident '{incident_id}' not found",
                "comment_length": len(comment),
            },
        )
        return json.dumps(
            {
                "status": "error",
                "comment_status": "error",
                "incident_id": incident_id,
                "error": resolve_error or f"Incident '{incident_id}' not found",
            }
        )

    data = _api_patch(
        f"/api/now/table/incident/{sys_id}",
        {"work_notes": comment},
    )
    if "error" in data:
        _write_publish_event(
            "add_comment",
            {
                "incident_id": incident_id,
                "sys_id": sys_id,
                "status": "error",
                "verified": False,
                "error": str(data.get("error") or ""),
                "details": str(data.get("details") or ""),
                "comment_length": len(comment),
            },
        )
        return json.dumps(
            {
                "status": "error",
                "comment_status": "error",
                "incident_id": incident_id,
                "error": data.get("error"),
                "details": data.get("details", ""),
            }
        )

    comment_excerpt = " ".join(str(comment or "").split())[:200]
    _write_publish_event(
        "add_comment",
        {
            "incident_id": incident_id,
            "sys_id": sys_id,
            "status": "success",
            "verified": True,
            "comment_length": len(comment),
            "comment_excerpt": comment_excerpt,
        },
    )
    return json.dumps(
        {
            "status": "comment_added",
            "comment_status": "success",
            "incident_id": incident_id,
            "sys_id": sys_id,
            "comment_length": len(comment),
            "comment_excerpt": comment_excerpt,
        },
        ensure_ascii=False,
    )


@mcp_app.tool()
def publish_triage_decision(decisions: Any) -> str:
    """Apply triage decisions for incidents with enforced update+comment behavior.

    This high-level tool publishes each incident in one PATCH call that includes
    both field updates and the work note/comment, then returns strict
    per-incident JSON.

    Args:
        decisions: JSON array, JSON object, or stringified JSON payload where each row
                   contains incident_id plus recommended impact/urgency/priority and comment.
    """
    rows, parse_error = _coerce_publish_rows(decisions)
    if parse_error:
        return json.dumps(
            {
                "status": "error",
                "error": parse_error,
                "results": [],
            },
            ensure_ascii=False,
        )

    results: list[dict[str, Any]] = []
    for idx, row in enumerate(rows, start=1):
        incident_id = _pick_text(row, ("incident_id", "id", "number"))
        if not incident_id:
            results.append(
                {
                    "incident_id": "",
                    "update_status": "error",
                    "comment_status": "error",
                    "incident_status": "failed",
                    "error": f"Missing incident_id on row {idx}",
                }
            )
            continue

        requested_impact    = _pick_text(row, ("recommended_impact",   "impact",    "requested_impact"))
        requested_urgency   = _pick_text(row, ("recommended_urgency",  "urgency",   "requested_urgency"))
        requested_priority  = _pick_text(row, ("recommended_priority", "priority",  "requested_priority"))
        requested_category  = _pick_text(row, ("recommended_category", "category",  "requested_category"))
        comment_text = _pick_text(
            row,
            (
                "comment",
                "work_note",
                "work_notes",
                "comment_text",
                "recommended_comment",
                "publish_comment",
                "reasoning",
            ),
        )

        # ── Resolve sys_id ONCE per incident (avoids duplicate GET in add_comment) ──
        sys_id, resolve_error = _resolve_incident_sys_id(incident_id)
        if resolve_error or not sys_id:
            _write_publish_event("update_incident", {
                "incident_id": incident_id,
                "status": "error",
                "verified": False,
                "error": resolve_error or f"Incident '{incident_id}' not found",
                "requested_priority": requested_priority,
                "requested_impact": requested_impact,
                "requested_urgency": requested_urgency,
                "requested_category": requested_category,
            })
            results.append({
                "incident_id": incident_id,
                "update_status": "error",
                "comment_status": "error",
                "incident_status": "failed",
                "update_error": resolve_error or "not found",
                "comment_error": "skipped — incident not found",
            })
            continue

        if not comment_text:
            comment_text = _default_comment(
                incident_id,
                requested_impact,
                requested_urgency,
                requested_priority,
                requested_category,
            )

        # ── Publish: 1 PATCH including both incident fields and work note ──
        patch_payload: dict[str, Any] = {"work_notes": comment_text}
        if requested_impact:
            patch_payload["impact"] = str(requested_impact).strip()
        if requested_urgency:
            patch_payload["urgency"] = str(requested_urgency).strip()
        if requested_priority and not (requested_impact and requested_urgency):
            patch_payload["priority"] = _normalize_priority(requested_priority)
        if requested_category:
            patch_payload["category"] = requested_category

        patch_data = _api_patch(f"/api/now/table/incident/{sys_id}", patch_payload)

        update_ok     = "error" not in patch_data
        update_status = "success" if update_ok else "error"
        comment_ok = update_ok
        comment_status = "success" if comment_ok else "error"
        comment_excerpt = " ".join(comment_text.split())[:200]
        result_row = patch_data.get("result") or {}
        _write_publish_event("update_incident", {
            "incident_id": incident_id,
            "sys_id": sys_id,
            "status": update_status,
            "verified": update_ok,
            "requested_priority": requested_priority,
            "visible_priority": _extract_text(result_row.get("priority")) if isinstance(result_row, dict) else "",
            "requested_impact": requested_impact,
            "visible_impact": _extract_text(result_row.get("impact")) if isinstance(result_row, dict) else "",
            "requested_urgency": requested_urgency,
            "visible_urgency": _extract_text(result_row.get("urgency")) if isinstance(result_row, dict) else "",
            "requested_category": requested_category,
            "visible_category": _extract_text(result_row.get("category")) if isinstance(result_row, dict) else "",
            "error": str(patch_data.get("error") or "").strip(),
        })
        _write_publish_event("add_comment", {
            "incident_id": incident_id,
            "sys_id": sys_id,
            "status": comment_status,
            "verified": comment_ok,
            "comment_length": len(comment_text),
            "comment_excerpt": comment_excerpt,
            "error": str(patch_data.get("error") or "").strip(),
        })

        incident_status = "success" if update_ok and comment_ok else "failed"
        results.append(
            {
                "incident_id": incident_id,
                "priority_updated": _extract_text(result_row.get("priority")) if isinstance(result_row, dict) else "",
                "impact_updated":   _extract_text(result_row.get("impact"))   if isinstance(result_row, dict) else "",
                "urgency_updated":  _extract_text(result_row.get("urgency"))  if isinstance(result_row, dict) else "",
                "category_updated": _extract_text(result_row.get("category")) if isinstance(result_row, dict) else "",
                "requested_priority": requested_priority,
                "requested_impact":   requested_impact,
                "requested_urgency":  requested_urgency,
                "requested_category": requested_category,
                "update_status":  update_status,
                "comment_status": comment_status,
                "incident_status": incident_status,
                "update_error":  str(patch_data.get("error") or "").strip(),
                "comment_error": str(patch_data.get("error") or "").strip(),
            }
        )

    success_count = sum(1 for r in results if str(r.get("incident_status") or "") == "success")
    failed_count = len(results) - success_count
    missing_ids = [
        r["incident_id"] for r in results
        if str(r.get("incident_status") or "") != "success" and r.get("incident_id")
    ]
    output = {
        "status": "success" if failed_count == 0 else "partial_success",
        "summary": {
            "incidents_total": len(results),
            "incidents_succeeded": success_count,
            "incidents_failed": failed_count,
            "missing_incident_ids": missing_ids,
        },
        "results": results,
    }
    _write_publish_event(
        "publish_triage_decision",
        {
            "status": output["status"],
            "incidents_total": len(results),
            "incidents_succeeded": success_count,
            "incidents_failed": failed_count,
            "missing_incident_ids": missing_ids,
        },
    )
    return json.dumps(output, ensure_ascii=False)


@mcp_app.tool()
def generate_publish_summary(raw_output: str = "") -> str:
    """Generate a formatted markdown summary of all ServiceNow publish events for this session.

    Call this as the FINAL step after processing all incidents.
    It reads every update_incident and add_comment event recorded during this session,
    combines them with the raw JSON output, and returns a structured per-incident report.

    Args:
        raw_output: The raw JSON string you have built so far (results array). Pass your
                    accumulated JSON here so fallback fields can fill any gaps.

    Returns:
        Formatted markdown report — use this as your final output.
    """
    if not DAAN_SESSION_ID:
        return raw_output or "No session ID — cannot read publish events."

    try:
        from daan.flow.session_service import read_jsonl_artifact
        events = read_jsonl_artifact(DAAN_SESSION_ID, _PUBLISH_EVENTS_PATH)
    except Exception as exc:
        _log(f"generate_publish_summary: could not read events: {exc!r}")
        events = []

    return build_servicenow_publish_output(events, raw_output or "")


# ---------------------------------------------------------------------------
# Output shaping helpers (internal — not exposed as MCP tools)
#
# These helpers were previously in workflow.py. Kept here so that any caller
# that reads publish-event artifacts can format ServiceNow publish results
# without touching the generic workflow endpoint.
# ---------------------------------------------------------------------------

def _normalize_priority_for_compare(value: str) -> str:
    """Normalize priority strings like 'P2', '2', '2 - High' to a single digit."""
    text = str(value or "").strip()
    if not text:
        return ""
    upper = text.upper()
    if upper.startswith("P") and len(upper) >= 2 and upper[1].isdigit():
        return upper[1]
    if text[0].isdigit():
        return text[0]
    return text


def _extract_action_result_fallback(raw_output: str) -> dict[str, dict[str, Any]]:
    """Parse action-agent raw JSON output into per-incident fallback fields.

    Used when publish-event artifacts are incomplete or absent.
    """
    import json as _json

    payload = str(raw_output or "").strip()
    if not payload:
        return {}
    try:
        parsed = _json.loads(payload)
    except (ValueError, TypeError):
        return {}

    rows: list[dict[str, Any]] = []
    if isinstance(parsed, dict) and isinstance(parsed.get("results"), list):
        rows = [r for r in parsed["results"] if isinstance(r, dict)]
    elif isinstance(parsed, list):
        rows = [r for r in parsed if isinstance(r, dict)]
    else:
        return {}

    fallback: dict[str, dict[str, Any]] = {}
    for row in rows:
        incident_id = str(row.get("incident_id") or row.get("id") or "").strip()
        if not incident_id:
            continue
        priority_updated = str(row.get("priority_updated") or "").strip()
        priority_previous = str(row.get("priority_previous") or "").strip()
        visible_priority = (
            priority_updated
            if priority_updated and priority_updated != "NOT_UPDATED"
            else priority_previous
        )
        fallback[incident_id] = {
            "requested_priority": str(
                row.get("recommended_priority") or row.get("requested_priority") or ""
            ).strip(),
            "visible_priority": visible_priority,
            "priority_updated": priority_updated,
            "priority_previous": priority_previous,
            "requested_impact": str(
                row.get("recommended_impact") or row.get("requested_impact") or ""
            ).strip(),
            "visible_impact": str(
                row.get("impact_updated") or row.get("impact_previous") or ""
            ).strip(),
            "requested_urgency": str(
                row.get("recommended_urgency") or row.get("requested_urgency") or ""
            ).strip(),
            "visible_urgency": str(
                row.get("urgency_updated") or row.get("urgency_previous") or ""
            ).strip(),
            "not_updated": priority_updated == "NOT_UPDATED",
        }
    return fallback


def build_servicenow_publish_output(
    events: list[dict[str, Any]], raw_output: str
) -> str:
    """Build a structured markdown report from ServiceNow publish events.

    Combines publish-event artifacts with raw action-agent JSON output as
    fallback. Returns the raw output unchanged when no events or fallback data
    exist (safe no-op for non-ServiceNow runs).
    """
    import json as _json

    fallback_by_incident = _extract_action_result_fallback(raw_output)
    if not events and not fallback_by_incident:
        return raw_output

    grouped: dict[str, dict[str, dict[str, Any]]] = {}
    for event in events:
        incident_id = str(event.get("incident_id") or "").strip()
        tool_name = str(event.get("tool") or "").strip()
        if not incident_id or not tool_name:
            continue
        grouped.setdefault(incident_id, {})[tool_name] = event

    incident_ids = sorted(set(grouped.keys()) | set(fallback_by_incident.keys()))
    update_events = [
        grouped[i]["update_incident"]
        for i in incident_ids
        if grouped.get(i, {}).get("update_incident")
    ]
    comment_events = [
        grouped[i]["add_comment"]
        for i in incident_ids
        if grouped.get(i, {}).get("add_comment")
    ]

    verified_updates = 0
    effective_update_count = 0
    for incident_id in incident_ids:
        update_event = grouped.get(incident_id, {}).get("update_incident") or {}
        fallback = fallback_by_incident.get(incident_id) or {}
        requested = str(
            update_event.get("requested_priority") or fallback.get("requested_priority") or ""
        ).strip()
        visible = str(
            update_event.get("visible_priority")
            or update_event.get("priority")
            or fallback.get("visible_priority")
            or ""
        ).strip()
        has_update_signal = bool(update_event) or bool(fallback)
        if has_update_signal:
            effective_update_count += 1
            if bool(update_event.get("verified")):
                verified_updates += 1
            elif (
                requested
                and visible
                and _normalize_priority_for_compare(requested)
                == _normalize_priority_for_compare(visible)
            ):
                verified_updates += 1

    successful_comments = sum(
        1
        for e in comment_events
        if str(e.get("status") or "").strip().lower() == "success"
    )
    error_events = [
        e
        for tool_map in grouped.values()
        for e in tool_map.values()
        if str(e.get("status") or "").strip().lower() == "error"
    ]
    mismatched_updates = [
        e
        for e in update_events
        if str(e.get("status") or "").strip().lower() == "mismatch"
    ]

    overall_status = "SUCCESS"
    if (
        error_events
        or mismatched_updates
        or verified_updates != len(update_events)
        or successful_comments != len(comment_events)
    ):
        overall_status = "PARTIAL_SUCCESS"

    lines = [
        "# ServiceNow Publish Results",
        "",
        "## Summary",
        f"- Overall status: {overall_status}",
        f"- Incidents targeted: {len(incident_ids)}",
        f"- Incidents with publish evidence: {len(grouped)}",
        f"- Priority updates verified: {verified_updates}/{effective_update_count}",
        f"- Comments added successfully: {successful_comments}/{len(comment_events)}",
        f"- Errors: {len(error_events)}",
        "",
        "## Per-Incident Results",
        "| Incident | Previous Priority | Requested Priority | Visible Priority | Comment Added |",
        "| --- | --- | --- | --- | --- |",
    ]

    for incident_id in incident_ids:
        update_event = grouped.get(incident_id, {}).get("update_incident") or {}
        comment_event = grouped.get(incident_id, {}).get("add_comment") or {}
        fallback = fallback_by_incident.get(incident_id) or {}
        previous_priority = str(
            update_event.get("previous_priority") or fallback.get("priority_previous") or "-"
        )
        requested_priority = str(
            update_event.get("requested_priority") or fallback.get("requested_priority") or "-"
        )
        visible_priority = str(
            update_event.get("visible_priority")
            or update_event.get("priority")
            or fallback.get("visible_priority")
            or "-"
        )
        comment_status = str(comment_event.get("status") or "not_run").strip()
        lines.append(
            f"| {incident_id} | {previous_priority} | {requested_priority}"
            f" | {visible_priority} | {'yes' if comment_status == 'success' else 'no'} |"
        )

    lines.extend(["", "## Event Details"])
    for incident_id in incident_ids:
        update_event = grouped.get(incident_id, {}).get("update_incident") or {}
        comment_event = grouped.get(incident_id, {}).get("add_comment") or {}
        fallback = fallback_by_incident.get(incident_id) or {}
        previous_priority = str(
            update_event.get("previous_priority") or fallback.get("priority_previous") or "-"
        )
        requested_priority = str(
            update_event.get("requested_priority") or fallback.get("requested_priority") or "-"
        )
        visible_priority = str(
            update_event.get("visible_priority")
            or update_event.get("priority")
            or fallback.get("visible_priority")
            or "-"
        )
        detail_status = str(
            update_event.get("status")
            or ("not_updated" if fallback.get("not_updated") else "not_run")
        )
        lines.append(f"### {incident_id}")
        lines.append(
            f"- Priority update: previous `{previous_priority}`; "
            f"requested `{requested_priority}`; visible `{visible_priority}`; "
            f"status `{detail_status}`."
        )
        if update_event.get("requested_category") or update_event.get("visible_category"):
            lines.append(
                f"- Category: requested `{update_event.get('requested_category') or '-'}`; "
                f"visible `{update_event.get('visible_category') or '-'}`."
            )
        if comment_event:
            lines.append(
                f"- Work note: status `{comment_event.get('status') or 'not_run'}`; "
                f"length `{comment_event.get('comment_length') or 0}`; "
                f"excerpt: {comment_event.get('comment_excerpt') or '-'}"
            )
        if update_event.get("error"):
            lines.append(f"- Update error: {update_event['error']}")
        if comment_event.get("error"):
            lines.append(f"- Comment error: {comment_event['error']}")
        lines.append("")

    if raw_output.strip():
        lines.extend(["## Raw Action-Agent Output", raw_output.strip()])

    return "\n".join(lines).strip() + "\n"


if __name__ == "__main__":
    _register_shutdown_logging()
    ok, error = _auth_ready()
    if ok:
        _log(f"Server starting with ServiceNow base_url={BASE_URL} verify_ssl={VERIFY_SSL}")
    else:
        _log(f"Server starting with missing configuration: {error}")
    try:
        mcp_app.run()
    except Exception as exc:
        _log(f"Server crashed: {exc!r}")
        raise
