"""Minimal Snowflake MCP server focused on deterministic SQL execution."""

from __future__ import annotations

import logging
import os
import re
import time
from contextlib import contextmanager
from datetime import datetime
from typing import Any, Dict, Iterable, Iterator, List, Tuple

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

load_dotenv()
logger = logging.getLogger(__name__)

# Stdio MCP transport must keep stdout clean. Reduce noisy library logging,
# especially Snowflake connector startup messages on Windows.
for logger_name in (
    "snowflake",
    "snowflake.connector",
    "snowflake.connector.connection",
    "mcp",
    "mcp.server",
):
    logging.getLogger(logger_name).setLevel(logging.WARNING)

snowflake_mcp = FastMCP("Snowflake MCP Server", "2.0.0")
mcp = snowflake_mcp

MAX_RETRIES = 3
RETRY_DELAY_SECONDS = 2
MAX_RESULT_ROWS = 50
MAX_HISTORY = 200
QUERY_HISTORY: List[Dict[str, Any]] = []
SQL_FENCE_RE = re.compile(r"```sql\s*(.*?)```", re.IGNORECASE | re.DOTALL)
GENERIC_FENCE_RE = re.compile(r"```\s*(.*?)```", re.DOTALL)
SQL_START_RE = re.compile(
    r"(?is)\b("
    r"select|with|show|describe|desc|explain|use\s+(database|schema|role|warehouse)|create|alter|drop|truncate|"
    r"insert|update|delete|merge|copy|call"
    r")\b"
)
SQL_LINE_START_RE = re.compile(
    r"(?im)^[ \t]*("
    r"select|with|show|describe|desc|explain|use\s+(database|schema|role|warehouse)|create|alter|drop|truncate|"
    r"insert|update|delete|merge|copy|call"
    r")\b"
)
FETCH_PREFIXES = ("select", "with", "show", "describe", "desc", "explain")
DDL_PREFIXES = ("create", "alter", "drop", "truncate", "use")
DML_PREFIXES = ("insert", "update", "delete", "merge", "copy", "call")


def _ts() -> str:
    return datetime.now().isoformat()


def _ok(**kw: Any) -> Dict[str, Any]:
    return {"status": "success", "timestamp": _ts(), **kw}


def _err(message: str, **kw: Any) -> Dict[str, Any]:
    return {"status": "error", "message": message, "timestamp": _ts(), **kw}


def _audit_log(action: str, status: str, detail: str, **extra: Any) -> None:
    QUERY_HISTORY.append(
        {
            "action": action,
            "status": status,
            "detail": detail[:500],
            "timestamp": _ts(),
            **extra,
        }
    )
    if len(QUERY_HISTORY) > MAX_HISTORY:
        del QUERY_HISTORY[0]


def _with_retry(fn, *args, max_retries: int = MAX_RETRIES, **kwargs):
    delay = RETRY_DELAY_SECONDS
    last_exc = None
    for attempt in range(1, max_retries + 1):
        try:
            return fn(*args, **kwargs)
        except Exception as exc:
            last_exc = exc
            message = str(exc).lower()
            is_transient = any(
                fragment in message
                for fragment in ("timeout", "network", "connection reset", "broken pipe", "502", "503", "429")
            )
            if not is_transient or attempt == max_retries:
                raise
            logger.warning("Retrying Snowflake call in %ss after transient error: %s", delay, exc)
            time.sleep(delay)
            delay *= 2
    raise last_exc


def _env_credentials() -> Dict[str, str | None]:
    return {
        "account": os.getenv("SNOWFLAKE_ACCOUNT", "").strip(),
        "user": os.getenv("SNOWFLAKE_USER", "").strip(),
        "password": os.getenv("SNOWFLAKE_PASSWORD", "").strip(),
        "warehouse": os.getenv("SNOWFLAKE_WAREHOUSE", "").strip(),
        "database": os.getenv("SNOWFLAKE_DATABASE", "").strip(),
        "schema": os.getenv("SNOWFLAKE_SCHEMA", "").strip(),
        "role": os.getenv("SNOWFLAKE_ROLE", "").strip() or None,
    }


def _sanitize_error_message(message: str) -> str:
    sanitized = re.sub(r"\s+", " ", str(message or "")).strip()
    for value in _env_credentials().values():
        if value:
            sanitized = sanitized.replace(str(value), "***")
    return sanitized[:500]


def _statement_preview(statement: str, limit: int = 160) -> str:
    compact = re.sub(r"\s+", " ", statement).strip()
    if len(compact) <= limit:
        return compact
    return compact[: limit - 3] + "..."


def validate_snowflake_env() -> Dict[str, Any]:
    required = ["SNOWFLAKE_ACCOUNT", "SNOWFLAKE_USER", "SNOWFLAKE_PASSWORD", "SNOWFLAKE_WAREHOUSE"]
    optional = ["SNOWFLAKE_DATABASE", "SNOWFLAKE_SCHEMA", "SNOWFLAKE_ROLE"]
    missing_required = [name for name in required if not os.getenv(name)]
    missing_optional = [name for name in optional if not os.getenv(name)]
    if missing_required:
        return _err(
            f"Missing required env vars: {', '.join(missing_required)}",
            missing_required=missing_required,
            missing_optional=missing_optional,
        )
    return _ok(
        message="Snowflake environment is valid",
        missing_optional=missing_optional,
    )


def _looks_like_sql(text: str) -> bool:
    return bool(SQL_START_RE.search(text or ""))


def _extract_sql_text(content: str) -> str:
    text = (content or "").strip()
    if not text:
        return ""

    sql_blocks = [block.strip() for block in SQL_FENCE_RE.findall(text) if block.strip()]
    if sql_blocks:
        return "\n\n".join(sql_blocks)

    generic_blocks = [block.strip() for block in GENERIC_FENCE_RE.findall(text) if block.strip()]
    generic_sql_blocks = [block for block in generic_blocks if _looks_like_sql(block)]
    if generic_sql_blocks:
        return "\n\n".join(generic_sql_blocks)

    match = SQL_LINE_START_RE.search(text)
    if match:
        return text[match.start():].strip()
    return text


def _split_sql_statements(sql: str) -> List[str]:
    statements: List[str] = []
    buffer: List[str] = []
    in_single_quote = False
    in_double_quote = False
    in_line_comment = False
    in_block_comment = False
    in_dollar_block = False
    index = 0

    while index < len(sql):
        current = sql[index]
        nxt = sql[index + 1] if index + 1 < len(sql) else ""

        if in_line_comment:
            buffer.append(current)
            if current == "\n":
                in_line_comment = False
            index += 1
            continue

        if in_block_comment:
            buffer.append(current)
            if current == "*" and nxt == "/":
                buffer.append(nxt)
                in_block_comment = False
                index += 2
            else:
                index += 1
            continue

        if not in_single_quote and not in_double_quote and current == "-" and nxt == "-":
            buffer.extend([current, nxt])
            in_line_comment = True
            index += 2
            continue

        if not in_single_quote and not in_double_quote and current == "/" and nxt == "*":
            buffer.extend([current, nxt])
            in_block_comment = True
            index += 2
            continue

        if not in_single_quote and not in_double_quote and current == "$" and nxt == "$":
            buffer.extend([current, nxt])
            in_dollar_block = not in_dollar_block
            index += 2
            continue

        if not in_double_quote and current == "'":
            if in_single_quote and nxt == "'":
                buffer.extend([current, nxt])
                index += 2
                continue
            in_single_quote = not in_single_quote
            buffer.append(current)
            index += 1
            continue

        if not in_single_quote and current == '"':
            in_double_quote = not in_double_quote
            buffer.append(current)
            index += 1
            continue

        if current == ";" and not in_single_quote and not in_double_quote and not in_dollar_block:
            statement = "".join(buffer).strip()
            if statement:
                statements.append(statement)
            buffer = []
            index += 1
            continue

        buffer.append(current)
        index += 1

    final_statement = "".join(buffer).strip()
    if final_statement:
        statements.append(final_statement)
    return statements


def _strip_leading_comments(statement: str) -> str:
    text = (statement or "").lstrip()
    while True:
        if text.startswith("--"):
            newline = text.find("\n")
            text = "" if newline == -1 else text[newline + 1 :].lstrip()
            continue
        if text.startswith("/*"):
            end = text.find("*/")
            text = "" if end == -1 else text[end + 2 :].lstrip()
            continue
        return text


def _classify_statement(statement: str) -> Tuple[str, bool]:
    stripped = _strip_leading_comments(statement).lower()
    if not stripped:
        return "empty", False
    for prefix in FETCH_PREFIXES:
        if stripped.startswith(prefix):
            return prefix, True
    for prefix in DDL_PREFIXES:
        if stripped.startswith(prefix):
            return prefix, False
    for prefix in DML_PREFIXES:
        if stripped.startswith(prefix):
            return prefix, False
    return "other", False


def _statement_payload(statement: str, index: int, statement_type: str, fetch_results: bool) -> Dict[str, Any]:
    return {
        "statement_index": index,
        "statement_type": statement_type,
        "statement_preview": _statement_preview(statement),
        "fetch_results": fetch_results,
    }


@contextmanager
def _snowflake_connection() -> Iterator[Any]:
    env = _env_credentials()
    validation = validate_snowflake_env()
    if validation["status"] == "error":
        raise ValueError(validation["message"])

    def _connect():
        import snowflake.connector

        kwargs: Dict[str, Any] = {
            "account": env["account"],
            "user": env["user"],
            "password": env["password"],
            "warehouse": env["warehouse"],
            "login_timeout": 30,
            "network_timeout": 30,
        }
        if env["database"]:
            kwargs["database"] = env["database"]
        if env["schema"]:
            kwargs["schema"] = env["schema"]
        if env["role"]:
            kwargs["role"] = env["role"]
        return snowflake.connector.connect(**kwargs)

    connection = _with_retry(_connect)
    try:
        # Explicitly set database/schema context on every connection so that
        # unqualified SQL (e.g. CREATE VIEW foo AS ...) resolves correctly.
        # snowflake.connector.connect(schema=...) sets it at connect time, but
        # issuing USE statements here guarantees it even if the connector
        # silently ignores unknown schemas at login.
        with connection.cursor() as _setup_cur:
            if env["database"]:
                _setup_cur.execute(f"USE DATABASE {env['database']}")
            if env["schema"]:
                _setup_cur.execute(f"USE SCHEMA {env['schema']}")
        yield connection
    finally:
        try:
            connection.close()
        except Exception:
            logger.debug("Snowflake connection close failed", exc_info=True)


def _format_rows(columns: Iterable[str], rows: Iterable[tuple[Any, ...]]) -> List[Dict[str, Any]]:
    column_list = list(columns)
    return [dict(zip(column_list, row)) for row in rows]


def _execute_single_statement(cursor: Any, statement: str, index: int, max_rows: int) -> Dict[str, Any]:
    statement_type, fetch_results = _classify_statement(statement)
    payload = _statement_payload(statement, index, statement_type, fetch_results)
    cursor.execute(statement)

    query_id = getattr(cursor, "sfqid", None)
    payload["query_id"] = query_id

    if fetch_results:
        columns = [desc[0] for desc in (cursor.description or [])]
        sample_rows = cursor.fetchmany(max_rows)
        has_more_rows = bool(cursor.fetchone())
        payload["columns"] = columns
        payload["sample_rows"] = _format_rows(columns, sample_rows)
        payload["row_count"] = len(sample_rows)
        payload["rows_truncated"] = has_more_rows
    else:
        payload["rows_affected"] = getattr(cursor, "rowcount", None)

    payload["status"] = "success"
    return payload


def _execute_statements(statements: List[str], max_rows: int, stop_on_error: bool = False) -> Dict[str, Any]:
    results: List[Dict[str, Any]] = []
    failed = False

    with _snowflake_connection() as connection:
        cursor = connection.cursor()
        try:
            for index, statement in enumerate(statements, start=1):
                try:
                    result = _execute_single_statement(cursor, statement, index, max_rows)
                    if not result["fetch_results"]:
                        connection.commit()
                    results.append(result)
                    _audit_log("snowflake_execute_statement", "success", result["statement_preview"], statement_index=index)
                except Exception as exc:
                    failed = True
                    try:
                        connection.rollback()
                    except Exception:
                        logger.debug("Snowflake rollback failed", exc_info=True)
                    error_message = _sanitize_error_message(exc)
                    result = {
                        **_statement_payload(statement, index, *_classify_statement(statement)),
                        "status": "error",
                        "error": error_message,
                    }
                    results.append(result)
                    _audit_log("snowflake_execute_statement", "error", error_message, statement_index=index)
                    if stop_on_error:
                        break
        finally:
            cursor.close()

    successful_statements = sum(1 for result in results if result["status"] == "success")
    response: Dict[str, Any] = {
        "status": "error" if failed else "success",
        "statement_count": len(statements),
        "successful_statements": successful_statements,
        "failed_statements": len(results) - successful_statements,
        "results": results,
    }
    if failed:
        response["message"] = "Snowflake execution stopped at the first failing statement"
    else:
        response["message"] = "Snowflake execution completed successfully"
    return response


@snowflake_mcp.tool()
def snowflake_validate_env() -> Dict[str, Any]:
    """Validate required Snowflake environment variables for MCP execution."""
    return validate_snowflake_env()


@snowflake_mcp.tool()
def snowflake_health() -> Dict[str, Any]:
    """Validate environment and connector availability without executing SQL."""
    validation = validate_snowflake_env()
    if validation["status"] == "error":
        return validation
    try:
        import snowflake.connector  # noqa: F401
    except Exception as exc:
        return _err("snowflake-connector-python is not available", error=_sanitize_error_message(exc))
    return _ok(message="Snowflake MCP server is ready")


@snowflake_mcp.tool()
def snowflake_execute_sql(content: str, max_rows: int = MAX_RESULT_ROWS, stop_on_error: bool = False) -> Dict[str, Any]:
    """Extract, split, classify, and execute Snowflake SQL from mixed content.

    Args:
        content: Raw text containing SQL (fenced blocks, inline SQL, or plain SQL).
        max_rows: Maximum rows to return for SELECT statements.
        stop_on_error: If True, halt execution at the first failing statement.
                       If False (default), continue executing all statements
                       and collect all results including errors.
    """
    validation = validate_snowflake_env()
    if validation["status"] == "error":
        return validation

    extracted_sql = _extract_sql_text(content)
    if not extracted_sql:
        return _err("No SQL content found in request")

    statements = _split_sql_statements(extracted_sql)
    if not statements:
        return _err("No executable SQL statements found after parsing")

    try:
        result = _execute_statements(statements, max(1, min(max_rows, 500)), stop_on_error=stop_on_error)
        result["extracted_sql"] = extracted_sql
        return result
    except Exception as exc:
        error_message = _sanitize_error_message(exc)
        _audit_log("snowflake_execute_sql", "error", error_message)
        return _err("Snowflake execution failed", error=error_message)


@snowflake_mcp.tool()
def snowflake_execute_statements(statements: List[str], max_rows: int = MAX_RESULT_ROWS, stop_on_error: bool = False) -> Dict[str, Any]:
    """Execute a pre-split list of Snowflake SQL statements.

    Args:
        statements: List of SQL statements to execute.
        max_rows: Maximum rows to return for SELECT statements.
        stop_on_error: If True, halt execution at the first failing statement.
                       If False (default), continue executing remaining statements
                       and collect all results including errors.
    """
    validation = validate_snowflake_env()
    if validation["status"] == "error":
        return validation

    normalized: List[str] = []
    for statement in statements or []:
        for part in _split_sql_statements(statement or ""):
            if part.strip():
                normalized.append(part.strip())

    if not normalized:
        return _err("No executable SQL statements were provided")

    try:
        return _execute_statements(normalized, max(1, min(max_rows, 500)), stop_on_error=stop_on_error)
    except Exception as exc:
        error_message = _sanitize_error_message(exc)
        _audit_log("snowflake_execute_statements", "error", error_message)
        return _err("Snowflake batch execution failed", error=error_message)


if __name__ == "__main__":
    logger.info("Starting Snowflake MCP Server...")
    snowflake_mcp.run(transport="stdio")
