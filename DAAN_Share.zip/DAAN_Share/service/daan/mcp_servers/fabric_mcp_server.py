"""
Microsoft Fabric MCP Server — Notebook Upload Operations

Exposes Fabric workspace operations as FastMCP tools so ADK agents can
upload generated PySpark notebooks to Microsoft Fabric.

Auth priority (first match wins) for every tool call:
  1. bearer_token parameter           — direct bearer token
  2. FABRIC_BEARER_TOKEN env var      — direct bearer token from env
  3. tenant_id + client_id + client_secret parameters — service-principal OAuth
  4. FABRIC_TENANT_ID + FABRIC_CLIENT_ID + FABRIC_CLIENT_SECRET env vars — service-principal OAuth

Required (parameter or env var):
  workspace_id / FABRIC_WORKSPACE_ID  — target Fabric workspace GUID
"""

import base64
import json
import logging
import os
from datetime import datetime
from typing import Any, Dict, Optional

import requests
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

load_dotenv()
logger = logging.getLogger(__name__)

fabric_mcp = FastMCP("Microsoft Fabric MCP Server", "1.0.0")

# Alias required by mcp_toolset_provider._get_repo_local_mcp_toolset convention.
mcp = fabric_mcp

_API = "https://api.fabric.microsoft.com/v1"
_SCOPE = "https://api.fabric.microsoft.com/.default"


# ---------------------------------------------------------------------------
# Response helpers
# ---------------------------------------------------------------------------

def _ts() -> str:
    return datetime.now().isoformat()


def _ok(**kw) -> Dict[str, Any]:
    return {"status": "success", "timestamp": _ts(), **kw}


def _err(msg: str, **kw) -> Dict[str, Any]:
    return {"status": "error", "message": msg, "timestamp": _ts(), **kw}


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------

def _get_token(
    bearer_token: Optional[str],
    tenant_id: Optional[str],
    client_id: Optional[str],
    client_secret: Optional[str],
) -> Optional[str]:
    """Resolve a Fabric bearer token from parameters, then env vars."""
    # 1. Direct bearer token (param → env)
    token = bearer_token or os.getenv("FABRIC_BEARER_TOKEN", "")
    if token:
        return token.strip()

    # 2. Service-principal OAuth (param → env)
    t = (tenant_id or os.getenv("FABRIC_TENANT_ID", "")).strip()
    c = (client_id or os.getenv("FABRIC_CLIENT_ID", "")).strip()
    s = (client_secret or os.getenv("FABRIC_CLIENT_SECRET", "")).strip()
    if not (t and c and s):
        return None

    resp = requests.post(
        f"https://login.microsoftonline.com/{t}/oauth2/v2.0/token",
        data={
            "grant_type": "client_credentials",
            "client_id": c,
            "client_secret": s,
            "scope": _SCOPE,
        },
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json().get("access_token")


# ---------------------------------------------------------------------------
# Notebook helpers
# ---------------------------------------------------------------------------

def _to_ipynb_b64(code: str, display_name: str) -> str:
    """Encode PySpark source as a Fabric-compatible .ipynb base64 payload."""
    nb = {
        "nbformat": 4,
        "nbformat_minor": 5,
        "metadata": {
            "kernelspec": {
                "display_name": "Synapse PySpark",
                "language": "Python",
                "name": "synapse_pyspark",
            },
            "language_info": {"name": "python"},
            "save_output": True,
            "spark_compute": {"compute_id": "/trident/default"},
            "notebook_display_name": display_name,
        },
        "cells": [
            {
                "cell_type": "code",
                "id": "main",
                "metadata": {},
                "outputs": [],
                "source": code.splitlines(keepends=True),
                "execution_count": None,
            }
        ],
    }
    return base64.b64encode(json.dumps(nb).encode()).decode()


def _find_existing_notebook(wid: str, display_name: str, token: str) -> Optional[str]:
    """Return the item ID of an existing notebook with the given display name, or None."""
    r = requests.get(
        f"{_API}/workspaces/{wid}/items",
        headers={"Authorization": f"Bearer {token}"},
        timeout=30,
    )
    if r.status_code == 200:
        for item in r.json().get("value", []):
            if (
                item.get("type", "").lower() == "notebook"
                and item.get("displayName") == display_name
            ):
                return item["id"]
    return None


# ---------------------------------------------------------------------------
# MCP Tools
# ---------------------------------------------------------------------------

@fabric_mcp.tool()
def FabricUploadPySparkNotebookTool(
    pyspark_code: str,
    display_name: str,
    workspace_id: Optional[str] = None,
    bearer_token: Optional[str] = None,
    tenant_id: Optional[str] = None,
    client_id: Optional[str] = None,
    client_secret: Optional[str] = None,
    overwrite: bool = True,
) -> Dict[str, Any]:
    """
    Upload a Fabric-compatible PySpark notebook to a Microsoft Fabric workspace.

    All credentials are resolved from parameters first, then env vars — no hardcoding.

    Args:
        pyspark_code  : Raw PySpark source (synapse_pyspark kernel compatible).
        display_name  : Notebook display name in the Fabric workspace.
        workspace_id  : Fabric workspace GUID (or FABRIC_WORKSPACE_ID env var).
        bearer_token  : Direct bearer token (or FABRIC_BEARER_TOKEN env var).
        tenant_id     : Azure AD tenant ID for service-principal auth (or FABRIC_TENANT_ID).
        client_id     : App client ID for service-principal auth (or FABRIC_CLIENT_ID).
        client_secret : App client secret for service-principal auth (or FABRIC_CLIENT_SECRET).
        overwrite     : Update the notebook if one with the same name already exists.

    Returns:
        Dict with status, display_name, item_id, workspace_id, notebook_url, operation, timestamp.
    """
    wid = (workspace_id or os.getenv("FABRIC_WORKSPACE_ID", "")).strip()
    if not wid:
        return _err("workspace_id is required (pass as parameter or set FABRIC_WORKSPACE_ID env var).")

    try:
        token = _get_token(bearer_token, tenant_id, client_id, client_secret)
    except Exception as exc:
        return _err(f"Authentication failed: {exc}")

    if not token:
        return _err(
            "No auth token available. "
            "Set FABRIC_BEARER_TOKEN, or set FABRIC_TENANT_ID + FABRIC_CLIENT_ID + FABRIC_CLIENT_SECRET."
        )

    b64 = _to_ipynb_b64(pyspark_code, display_name)
    parts = [{"path": "notebook-content.ipynb", "payload": b64, "payloadType": "InlineBase64"}]
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    existing_id = _find_existing_notebook(wid, display_name, token) if overwrite else None

    if existing_id:
        resp = requests.post(
            f"{_API}/workspaces/{wid}/items/{existing_id}/updateDefinition",
            headers=headers,
            json={"definition": {"format": "ipynb", "parts": parts}},
            timeout=60,
        )
        item_id, operation = existing_id, "updated"
    else:
        resp = requests.post(
            f"{_API}/workspaces/{wid}/items",
            headers=headers,
            json={
                "displayName": display_name,
                "type": "Notebook",
                "definition": {"format": "ipynb", "parts": parts},
            },
            timeout=60,
        )
        item_id = resp.json().get("id") if resp.status_code in (200, 201) else None
        operation = "created"

    if resp.status_code in (200, 201, 202):
        notebook_url = (
            f"https://app.fabric.microsoft.com/groups/{wid}/synapsenotebooks/{item_id}"
            if item_id
            else f"https://app.fabric.microsoft.com/groups/{wid}"
        )
        logger.info("Fabric: notebook '%s' %s (id=%s).", display_name, operation, item_id)
        return _ok(
            message=f"Notebook '{display_name}' {operation} successfully.",
            display_name=display_name,
            item_id=item_id,
            workspace_id=wid,
            notebook_url=notebook_url,
            operation=operation,
        )

    return _err(
        f"Fabric API returned HTTP {resp.status_code}: {resp.text[:300]}",
        workspace_id=wid,
    )


if __name__ == "__main__":
    fabric_mcp.run(transport="stdio")
