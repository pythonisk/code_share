"""
RSS Feed MCP Server - Generic RSS/Atom Feed Ingestion
Polls any RSS or Atom feed and returns normalised items within a date window.
Uses feedparser for robust RSS 1.0/2.0/Atom parsing with malformed-feed tolerance.
No credentials required; no auth config needed in the registry.
"""

import hashlib
import html
import logging
import re
import urllib.parse
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
from typing import Any

import feedparser
import requests
from mcp.server.fastmcp import FastMCP

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

mcp = FastMCP("RSS Feed MCP Server", "1.0.0")

# ── Namespace map (used only by verify_feed_url for format detection) ─────────
_NS = {
    "atom": "http://www.w3.org/2005/Atom",
    "content": "http://purl.org/rss/1.0/modules/content/",
    "dc": "http://purl.org/dc/elements/1.1/",
    "media": "http://search.yahoo.com/mrss/",
    "feedburner": "http://rssnamespace.org/feedburner/ext/1.0",
}

_DEFAULT_TIMEOUT = 20
_DEFAULT_USER_AGENT = "DAAN-NewsletterBot/1.0 (internal; polite crawler)"
_MAX_EXCERPT_CHARS = 500
_DEFAULT_LOOKBACK_DAYS = 30

_TRACKING_PARAMS = frozenset({
    "utm_source", "utm_medium", "utm_campaign", "utm_content",
    "utm_term", "ref", "referrer", "source",
})


def _strip_tracking_params(url: str) -> str:
    """Remove common tracking query parameters from a URL."""
    try:
        parsed = urllib.parse.urlparse(url)
        qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        clean_qs = {k: v for k, v in qs.items() if k.lower() not in _TRACKING_PARAMS}
        clean = parsed._replace(query=urllib.parse.urlencode(clean_qs, doseq=True))
        return urllib.parse.urlunparse(clean)
    except Exception:
        return url


def _strip_html(text: str) -> str:
    """Remove HTML tags and decode entities."""
    return html.unescape(re.sub(r"<[^>]+>", "", text)).strip() if text else ""


def _content_hash(url: str, title: str) -> str:
    return hashlib.sha256(f"{url}|{title}".encode()).hexdigest()[:16]


def _entry_date_utc(entry: feedparser.FeedParserDict) -> datetime | None:
    """Extract published or updated date from a feedparser entry as UTC datetime."""
    for attr in ("published_parsed", "updated_parsed"):
        tp = getattr(entry, attr, None)
        if tp:
            try:
                from calendar import timegm
                return datetime.fromtimestamp(timegm(tp), tz=timezone.utc)
            except (ValueError, OverflowError):
                continue
    return None


def _entry_link(entry: feedparser.FeedParserDict) -> str:
    """Extract the best canonical link, preferring feedburner:origLink."""
    orig = entry.get("feedburner_origlink", "")
    if orig:
        return _strip_tracking_params(orig)
    link = entry.get("link", "")
    return _strip_tracking_params(link) if link else ""


def _entry_excerpt(entry: feedparser.FeedParserDict) -> str:
    """Extract excerpt from summary or content:encoded, stripping HTML."""
    summary = entry.get("summary", "")
    if not summary:
        content_list = entry.get("content", [])
        if content_list:
            summary = content_list[0].get("value", "")
    return _strip_html(summary)[:_MAX_EXCERPT_CHARS]


def _entry_publisher(entry: feedparser.FeedParserDict, fallback: str) -> str:
    """Extract author name from entry."""
    author = entry.get("author", "")
    if not author:
        authors = entry.get("authors", [])
        if authors and authors[0].get("name"):
            author = authors[0]["name"]
    return author.strip() if author else fallback


def _parse_entries(feed: feedparser.FeedParserDict, date_from: datetime, date_to: datetime,
                   source_id: str, source_category: str) -> list[dict]:
    """Convert feedparser entries into normalised items within a date window."""
    items = []
    for entry in feed.entries:
        now_utc = datetime.now(timezone.utc)
        pub_dt = _entry_date_utc(entry)
        if pub_dt:
            if pub_dt < date_from or pub_dt > date_to:
                continue
            date_confidence = "high"
        else:
            # Spec: never silently discard for missing date; fall back to retrieved_at
            pub_dt = now_utc
            date_confidence = "low"

        title = entry.get("title", "").strip()
        link = _entry_link(entry)

        items.append({
            "source_id": source_id,
            "source_category": source_category,
            "publisher": _entry_publisher(entry, source_id),
            "title": title,
            "published_at": pub_dt.isoformat(),
            "canonical_url": link,
            "excerpt": _entry_excerpt(entry),
            "retrieved_at": now_utc.isoformat(),
            "content_hash": _content_hash(link or title, title),
            "section_hint": None,
            "date_confidence": date_confidence,
            "paywall": False,
            "source_weight": 1.0,
        })
    return items


def _fetch_feed(feed_url: str, date_from: datetime, date_to: datetime,
                source_id: str, source_category: str,
                etag: str | None, last_modified: str | None) -> dict[str, Any]:
    """Fetch and parse a single RSS or Atom feed URL."""
    headers = {
        "User-Agent": _DEFAULT_USER_AGENT,
        "Accept": "application/rss+xml, application/atom+xml, text/xml, */*",
    }
    if etag:
        headers["If-None-Match"] = etag
    if last_modified:
        headers["If-Modified-Since"] = last_modified

    try:
        resp = requests.get(feed_url, headers=headers, timeout=_DEFAULT_TIMEOUT, verify=False)
    except requests.exceptions.RequestException as exc:
        return {"success": False, "items": [], "error": str(exc),
                "etag": None, "last_modified": None}

    if resp.status_code == 304:
        return {"success": True, "items": [], "not_modified": True,
                "etag": etag, "last_modified": last_modified}

    if resp.status_code != 200:
        return {"success": False, "items": [],
                "error": f"HTTP {resp.status_code}", "etag": None, "last_modified": None}

    new_etag = resp.headers.get("ETag")
    new_lm = resp.headers.get("Last-Modified")

    feed = feedparser.parse(resp.content)
    if feed.bozo and not feed.entries:
        exc_msg = str(feed.bozo_exception)[:200] if feed.bozo_exception else "malformed feed"
        return {"success": False, "items": [], "error": f"Parse error: {exc_msg}",
                "etag": new_etag, "last_modified": new_lm}

    items = _parse_entries(feed, date_from, date_to, source_id, source_category)

    result: dict[str, Any] = {"success": True, "items": items, "etag": new_etag, "last_modified": new_lm}
    if feed.bozo:
        result["parser_warning"] = str(feed.bozo_exception)[:200] if feed.bozo_exception else "feed not fully well-formed"
    return result


# ── MCP Tools ─────────────────────────────────────────────────────────────────

@mcp.tool()
def fetch_feed_items(
    feed_url: str,
    source_id: str,
    source_category: str,
    date_from: str | None = None,
    date_to: str | None = None,
    etag: str | None = None,
    last_modified: str | None = None,
) -> dict[str, Any]:
    """
    Fetch items from a single RSS or Atom feed within a date window.

    Returns normalised items conforming to the 13-field newsletter item contract:
    {source_id, source_category, publisher, title, published_at, canonical_url,
     excerpt, retrieved_at, content_hash, section_hint, date_confidence, paywall,
     source_weight}.

    Args:
        feed_url: Full URL of the RSS or Atom feed.
        source_id: Stable key identifying this source (e.g. 'databricks_blog').
        source_category: One of: platform_vendor, competitor, analyst,
                         trade_press, internal.
        date_from: ISO 8601 start date (inclusive). Defaults to 30 days ago.
        date_to: ISO 8601 end date (inclusive). Defaults to now.
        etag: ETag from the previous poll for conditional GET (optional).
        last_modified: Last-Modified header from previous poll (optional).
    """
    now = datetime.now(timezone.utc)
    try:
        df = datetime.fromisoformat(date_from).astimezone(timezone.utc) if date_from \
            else now - timedelta(days=_DEFAULT_LOOKBACK_DAYS)
        dt = datetime.fromisoformat(date_to).astimezone(timezone.utc) if date_to else now
    except ValueError as exc:
        return {"success": False, "items": [], "error": f"Invalid date format: {exc}"}

    result = _fetch_feed(feed_url, df, dt, source_id, source_category, etag, last_modified)
    result["item_count"] = len(result.get("items", []))
    logger.info("feed=%s items=%d success=%s", feed_url, result["item_count"], result["success"])
    return result


@mcp.tool()
def fetch_multiple_feeds(
    feeds: list[dict[str, Any]],
    date_from: str | None = None,
    date_to: str | None = None,
) -> dict[str, Any]:
    """
    Fetch items from multiple RSS/Atom feeds in a single call.

    Each entry in `feeds` must have:
      - feed_url (str)
      - source_id (str)
      - source_category (str)
    Optionally:
      - etag (str)
      - last_modified (str)
      - section_hint (str) — propagated onto every item from this feed
      - source_weight (float) — editorial weight, propagated onto items (default 1.0)
      - paywall (bool) — whether this source is paywalled (default false)
      - max_items_per_source (int) — cap per source, keeping most recent (default 25)

    Returns aggregated items from all feeds, per-feed status, and run_stats
    with coverage_degraded flag.
    """
    now = datetime.now(timezone.utc)
    try:
        df = datetime.fromisoformat(date_from).astimezone(timezone.utc) if date_from \
            else now - timedelta(days=_DEFAULT_LOOKBACK_DAYS)
        dt = datetime.fromisoformat(date_to).astimezone(timezone.utc) if date_to else now
    except ValueError as exc:
        return {"success": False, "all_items": [], "feed_results": [],
                "error": f"Invalid date format: {exc}"}

    all_items: list[dict] = []
    feed_results: list[dict] = []

    # Separate valid feeds from invalid ones
    valid_feeds: list[dict] = []
    for feed_cfg in feeds:
        url = feed_cfg.get("feed_url", "")
        sid = feed_cfg.get("source_id", "unknown")
        if not url:
            feed_results.append({"source_id": sid, "success": False,
                                  "error": "feed_url missing", "item_count": 0})
        else:
            valid_feeds.append(feed_cfg)

    _DEFAULT_MAX_ITEMS_PER_SOURCE = 25

    def _fetch_one(feed_cfg: dict) -> dict:
        url = feed_cfg["feed_url"]
        sid = feed_cfg.get("source_id", "unknown")
        cat = feed_cfg.get("source_category", "unknown")
        hint = feed_cfg.get("section_hint")
        weight = float(feed_cfg.get("source_weight", 1.0))
        is_paywall = bool(feed_cfg.get("paywall", False))
        cap = int(feed_cfg.get("max_items_per_source", _DEFAULT_MAX_ITEMS_PER_SOURCE))

        res = _fetch_feed(url, df, dt, sid, cat,
                          feed_cfg.get("etag"), feed_cfg.get("last_modified"))

        items = res.get("items", [])
        for item in items:
            if hint:
                item["section_hint"] = hint
            item["source_weight"] = weight
            item["paywall"] = is_paywall

        # Cap per source, keeping most recent
        if len(items) > cap:
            items.sort(key=lambda x: x["published_at"], reverse=True)
            res["items"] = items[:cap]

        return {"feed_cfg": feed_cfg, "res": res}

    with ThreadPoolExecutor(max_workers=min(8, len(valid_feeds) or 1)) as pool:
        futures = {pool.submit(_fetch_one, fc): fc for fc in valid_feeds}
        for future in as_completed(futures):
            result = future.result()
            res = result["res"]
            fc = result["feed_cfg"]
            all_items.extend(res.get("items", []))
            feed_results.append({
                "source_id": fc.get("source_id", "unknown"),
                "feed_url": fc["feed_url"],
                "success": res["success"],
                "item_count": len(res.get("items", [])),
                "not_modified": res.get("not_modified", False),
                "etag": res.get("etag"),
                "last_modified": res.get("last_modified"),
                "error": res.get("error"),
            })

    sources_attempted = len(valid_feeds)
    sources_returning = sum(1 for r in feed_results if r.get("success") and r.get("item_count", 0) > 0)
    failed_sources = [{"source_id": r["source_id"], "error": r.get("error", "unknown")}
                      for r in feed_results if not r.get("success")]
    coverage_degraded = (sources_returning < 0.7 * sources_attempted) if sources_attempted > 0 else False

    logger.info("fetch_multiple_feeds: total_items=%d feeds=%d coverage_degraded=%s",
                len(all_items), len(feeds), coverage_degraded)
    return {
        "success": True,
        "all_items": all_items,
        "total_item_count": len(all_items),
        "feed_results": feed_results,
        "run_stats": {
            "sources_attempted": sources_attempted,
            "sources_returning_items": sources_returning,
            "failed_sources": failed_sources,
            "items_retrieved": len(all_items),
            "coverage_degraded": coverage_degraded,
        },
    }


@mcp.tool()
def verify_feed_url(feed_url: str) -> dict[str, Any]:
    """
    Verify that a URL returns a valid RSS or Atom feed.

    Returns feed format, title, and the most recent item date.
    Useful for validating Register C unverified leads.
    """
    headers = {
        "User-Agent": _DEFAULT_USER_AGENT,
        "Accept": "application/rss+xml, application/atom+xml, text/xml, */*",
    }
    try:
        resp = requests.get(feed_url, headers=headers, timeout=_DEFAULT_TIMEOUT, verify=False)
    except requests.exceptions.RequestException as exc:
        return {"success": False, "valid": False, "error": str(exc)}

    if resp.status_code != 200:
        return {"success": False, "valid": False, "error": f"HTTP {resp.status_code}"}

    feed = feedparser.parse(resp.content)
    if feed.bozo and not feed.entries:
        exc_msg = str(feed.bozo_exception)[:200] if feed.bozo_exception else "malformed feed"
        return {"success": False, "valid": False, "error": f"Parse error: {exc_msg}"}

    fmt = feed.version or "unknown"
    if "rss" in fmt:
        fmt = "rss"
    elif "atom" in fmt:
        fmt = "atom"

    title = feed.feed.get("title", "")

    dates = []
    for entry in feed.entries:
        dt = _entry_date_utc(entry)
        if dt:
            dates.append(dt.isoformat())

    latest = max(dates) if dates else None

    result: dict[str, Any] = {
        "success": True,
        "valid": True,
        "format": fmt,
        "feed_title": title,
        "item_count_in_feed": len(feed.entries),
        "latest_item_date": latest,
        "feed_url": feed_url,
    }
    if feed.bozo:
        result["parser_warning"] = str(feed.bozo_exception)[:200] if feed.bozo_exception else "feed not fully well-formed"
    return result


if __name__ == "__main__":
    mcp.run(transport="stdio")
