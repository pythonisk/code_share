"""
Azure Data Factory MCP Server - Resource Deployment and Management Operations

This module provides Model Context Protocol (MCP) server functionality for Azure Data Factory operations.
Exposes ADF deployment tools so ADK agents can create/update dataflows and pipelines.

"""

import json
import logging
import os
from datetime import datetime
from typing import Any, Dict, Optional

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

load_dotenv()
logger = logging.getLogger(__name__)

# Initialize FastMCP server for Azure Data Factory
adf_mcp = FastMCP("Azure Data Factory MCP Server", "1.0.0")
# Alias required by mcp_toolset_provider._get_repo_local_mcp_toolset convention.
mcp = adf_mcp


def _ts() -> str:
    return datetime.now().isoformat()


def _ok(**kw) -> Dict[str, Any]:
    return {"status": "success", "timestamp": _ts(), **kw}


def _err(msg: str, **kw) -> Dict[str, Any]:
    return {"status": "error", "message": msg, "timestamp": _ts(), **kw}


def _build_adf_portal_url(
    subscription_id: str,
    resource_group: str,
    factory_name: str,
    resource_type: str,
    resource_name: str,
) -> str:
    """Build Azure Data Factory portal URL for a specific resource.
    
    Args:
        subscription_id: Azure subscription ID
        resource_group: Resource group name
        factory_name: Data factory name
        resource_type: Resource type (e.g., 'dataflow', 'pipeline')
        resource_name: Name of the resource
    
    Returns:
        Full Azure portal URL for the resource
    """
    from urllib.parse import quote
    
    factory_path = f"/subscriptions/{subscription_id}/resourceGroups/{resource_group}/providers/Microsoft.DataFactory/factories/{factory_name}"
    encoded_factory = quote(factory_path, safe='')
    
    return f"https://adf.azure.com/en/authoring/{resource_type}/{resource_name}?factory={encoded_factory}"


# ---------------------------------------------------------------------------
# Connection class
# ---------------------------------------------------------------------------

class ADFConnection:
    """
    Manages Azure Data Factory connections and operations using Azure SDK.
    This is the connection class used to perform deployment operations.
    """

    def __init__(self):
        self.client = None
        self.subscription_id = None
        self.resource_group = None
        self.factory_name = None
        self.credential = None

    def connect(
        self,
        subscription_id: str,
        resource_group: str,
        factory_name: str,
        tenant_id: str,
        client_id: str,
        client_secret: str,
        verify_ssl: bool = False,
    ) -> Dict[str, Any]:
        """Establish connection to Azure Data Factory using service principal."""
        try:
            from azure.identity import ClientSecretCredential
            from azure.mgmt.datafactory import DataFactoryManagementClient

            self.credential = ClientSecretCredential(
                tenant_id=tenant_id,
                client_id=client_id,
                client_secret=client_secret,
                connection_verify=verify_ssl,
            )

            self.subscription_id = subscription_id
            self.resource_group = resource_group
            self.factory_name = factory_name

            self.client = DataFactoryManagementClient(
                credential=self.credential,
                subscription_id=subscription_id,
                connection_verify=verify_ssl,
            )

            factory = self.client.factories.get(
                resource_group_name=resource_group,
                factory_name=factory_name,
            )

            logger.info("Successfully connected to ADF: %s", factory_name)

            return _ok(
                message=f"Connected to Azure Data Factory: {factory_name}",
                connection_details={
                    "subscription_id": subscription_id,
                    "resource_group": resource_group,
                    "factory_name": factory_name,
                    "factory_location": factory.location,
                    "factory_provisioning_state": factory.provisioning_state,
                },
            )

        except Exception as e:
            logger.error("Failed to connect to ADF: %s", e)
            return _err(f"Failed to connect to Azure Data Factory: {e}")

    def create_or_update_dataflow(
        self,
        dataflow_name: str,
        dataflow_definition: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Create or update a data flow in Azure Data Factory."""
        if not self.client:
            return _err("No active connection. Please connect first.")

        try:
            from azure.mgmt.datafactory.models import DataFlowResource

            clean_definition = {
                k: v for k, v in dataflow_definition.items() if k not in ("name", "type")
            }

            dataflow_resource = DataFlowResource(**clean_definition)

            result = self.client.data_flows.create_or_update(
                resource_group_name=self.resource_group,
                factory_name=self.factory_name,
                data_flow_name=dataflow_name,
                data_flow=dataflow_resource,
            )

            logger.info("Successfully created/updated data flow: %s", dataflow_name)

            # Generate Azure portal link for the data flow
            portal_url = _build_adf_portal_url(
                subscription_id=self.subscription_id,
                resource_group=self.resource_group,
                factory_name=self.factory_name,
                resource_type="dataflow",
                resource_name=dataflow_name,
            )

            return _ok(
                message=f"Data flow '{dataflow_name}' created/updated successfully.\n\n[View in Azure Data Factory]({portal_url})",
                dataflow_details={
                    "name": result.name,
                    "id": result.id,
                    "type": result.type,
                    "etag": result.etag,
                    "portal_url": portal_url,
                },
            )

        except Exception as e:
            logger.error("Failed to create/update data flow: %s", e)
            return _err(f"Failed to create/update data flow: {e}", dataflow_name=dataflow_name)

    def create_or_update_pipeline(
        self,
        pipeline_name: str,
        pipeline_definition: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Create or update a pipeline in Azure Data Factory."""
        if not self.client:
            return _err("No active connection. Please connect first.")

        try:
            from azure.mgmt.datafactory.models import PipelineResource

            clean_definition = {
                k: v for k, v in pipeline_definition.items() if k not in ("name", "type")
            }
            payload = (
                clean_definition.get("properties")
                if isinstance(clean_definition.get("properties"), dict)
                else clean_definition
            )

            pipeline_resource = PipelineResource(**payload)

            result = self.client.pipelines.create_or_update(
                resource_group_name=self.resource_group,
                factory_name=self.factory_name,
                pipeline_name=pipeline_name,
                pipeline=pipeline_resource,
            )

            logger.info("Successfully created/updated pipeline: %s", pipeline_name)

            # Generate Azure portal link for the pipeline
            portal_url = _build_adf_portal_url(
                subscription_id=self.subscription_id,
                resource_group=self.resource_group,
                factory_name=self.factory_name,
                resource_type="pipeline",
                resource_name=pipeline_name,
            )

            return _ok(
                message=f"Pipeline '{pipeline_name}' created/updated successfully.\n\n[View in Azure Data Factory]({portal_url})",
                pipeline_details={
                    "name": result.name,
                    "id": result.id,
                    "type": result.type,
                    "etag": result.etag,
                    "portal_url": portal_url,
                },
            )

        except Exception as e:
            logger.error("Failed to create/update pipeline: %s", e)
            return _err(f"Failed to create/update pipeline: {e}", pipeline_name=pipeline_name)

    def disconnect(self) -> Dict[str, Any]:
        """Close the ADF connection."""
        self.client = None
        self.credential = None
        self.subscription_id = None
        self.resource_group = None
        self.factory_name = None
        logger.info("Successfully disconnected from ADF")
        return _ok(message="Successfully disconnected from Azure Data Factory")


# ---------------------------------------------------------------------------
# MCP Tools — Global connection instance for MCP server mode
# ---------------------------------------------------------------------------

_adf_conn = ADFConnection()


@adf_mcp.tool()
def ADFConnectTool(
    subscription_id: str,
    resource_group: str,
    factory_name: str,
    tenant_id: str,
    client_id: str,
    client_secret: str,
    verify_ssl: bool = False,
) -> Dict[str, Any]:
    """
    Azure Data Factory Connection Tool - Establishes connection to ADF using service principal.

    Use this tool when you need to:
    - Connect to Azure Data Factory for resource management
    - Establish a session for deploying dataflows and pipelines
    - Verify ADF connectivity and permissions

    Arguments:
    - subscription_id (str): Azure subscription ID
    - resource_group (str): Resource group containing the data factory
    - factory_name (str): Name of the Azure Data Factory
    - tenant_id (str): Azure Active Directory tenant ID
    - client_id (str): Service principal application/client ID
    - client_secret (str): Service principal client secret
    - verify_ssl (bool): Set False for corporate proxy/SSL issues (default False)

    Returns:
    - Dict[str, Any]: Connection status with factory details and timestamp
    """
    return _adf_conn.connect(
        subscription_id=subscription_id,
        resource_group=resource_group,
        factory_name=factory_name,
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=client_secret,
        verify_ssl=verify_ssl,
    )





@adf_mcp.tool()
def ADFDeployDataFlowTool(dataflow_name: str, dataflow_definition: str) -> Dict[str, Any]:
    """
    Azure Data Factory Data Flow Deployment Tool - Creates or updates a mapping data flow in ADF.

    Use this tool when you need to:
    - Deploy generated data flow JSON from code generation agents
    - Create transformation logic for data processing
    - Define ETL operations (derive, filter, select, join, etc.)
    - Update existing data flow configurations

    Arguments:
    - dataflow_name (str): Name of the data flow to create/update
    - dataflow_definition (str): JSON string containing the data flow definition

    Returns:
    - Dict[str, Any]: Operation status with data flow details
    """
    try:
        dataflow_dict = (
            json.loads(dataflow_definition)
            if isinstance(dataflow_definition, str)
            else dataflow_definition
        )
        return _adf_conn.create_or_update_dataflow(dataflow_name, dataflow_dict)
    except json.JSONDecodeError as e:
        return _err(f"Invalid JSON in dataflow_definition: {e}")


@adf_mcp.tool()
def ADFDeployPipelineTool(pipeline_name: str, pipeline_definition: str) -> Dict[str, Any]:
    """
    Azure Data Factory Pipeline Deployment Tool - Creates or updates a pipeline in ADF.

    Use this tool when you need to:
    - Deploy generated pipeline JSON from code generation agents
    - Create pipelines that execute data flows
    - Orchestrate ETL/ELT workflows
    - Update existing pipeline configurations

    IMPORTANT: Ensure the pipeline references the correct deployed dataflow name.

    Arguments:
    - pipeline_name (str): Name of the pipeline to create/update
    - pipeline_definition (str): JSON string containing the pipeline definition

    Returns:
    - Dict[str, Any]: Operation status with pipeline details
    """
    try:
        pipeline_dict = (
            json.loads(pipeline_definition)
            if isinstance(pipeline_definition, str)
            else pipeline_definition
        )
        return _adf_conn.create_or_update_pipeline(pipeline_name, pipeline_dict)
    except json.JSONDecodeError as e:
        return _err(f"Invalid JSON in pipeline_definition: {e}")


if __name__ == "__main__":
    logger.info("Starting Azure Data Factory MCP Server…")
    mcp.run(transport="stdio")
