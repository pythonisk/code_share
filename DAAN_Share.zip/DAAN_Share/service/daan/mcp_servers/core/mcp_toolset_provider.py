import os
import sys
import importlib.util
import shutil
import ssl
from pathlib import Path
from typing import Any

import httpx
import yaml
from dotenv import load_dotenv

from google.adk.tools.mcp_tool import (
    McpToolset,
    SseConnectionParams,
    StreamableHTTPConnectionParams,
)
from google.adk.tools.mcp_tool.mcp_session_manager import StdioConnectionParams
from mcp import StdioServerParameters

from daan.mcp_servers.core.mcp_auth import build_auth_headers


# Ensure config/.env values are available to MCP subprocess env substitution.
_ENV_PATH = Path(__file__).resolve().parents[4] / "config" / ".env"
if _ENV_PATH.exists():
    load_dotenv(dotenv_path=_ENV_PATH, override=False)

_WORKSPACE_ROOT = Path(__file__).resolve().parents[4]
_REGISTRY_PATH = Path(__file__).resolve().parents[4] / "config" / "mcp_servers_registry.yml"
_DEFAULT_STDIO_TIMEOUT_SECONDS = 60.0

# MCP httpx factory defaults (mirror mcp.shared._httpx_utils).
_MCP_HTTP_TIMEOUT_SECONDS = 30.0
_MCP_HTTP_SSE_READ_TIMEOUT_SECONDS = 300.0
# ADK's connection_params.timeout gates list_tools/call_tool; its 5s default is too
# low for remote MCP servers behind a corporate proxy, so use a higher default.
_DEFAULT_HTTP_TOOL_TIMEOUT_SECONDS = 30.0
_SYSTEM_SSL_CONTEXT: ssl.SSLContext | None = None


def _get_system_ssl_context() -> ssl.SSLContext:
    """Cached TLS context that trusts the OS/system CA store (corporate proxies)."""
    global _SYSTEM_SSL_CONTEXT
    if _SYSTEM_SSL_CONTEXT is None:
        _SYSTEM_SSL_CONTEXT = ssl.create_default_context()
    return _SYSTEM_SSL_CONTEXT


def _system_store_http_client_factory(
    headers: dict[str, str] | None = None,
    timeout: "httpx.Timeout | None" = None,
    auth: "httpx.Auth | None" = None,
) -> httpx.AsyncClient:
    """MCP httpx client factory verifying against the system CA store.

    ADK's default factory verifies with certifi, which omits corporate proxy root
    CAs and fails with CERTIFICATE_VERIFY_FAILED. This mirrors the default factory
    but swaps in ssl.create_default_context() (same store the test-connection path uses).
    """
    kwargs: dict[str, Any] = {
        "follow_redirects": True,
        "verify": _get_system_ssl_context(),
    }
    kwargs["timeout"] = timeout if timeout is not None else httpx.Timeout(
        _MCP_HTTP_TIMEOUT_SECONDS, read=_MCP_HTTP_SSE_READ_TIMEOUT_SECONDS
    )
    if headers is not None:
        kwargs["headers"] = headers
    if auth is not None:
        kwargs["auth"] = auth
    return httpx.AsyncClient(**kwargs)



def _parse_positive_timeout(value: Any) -> float | None:
    try:
        timeout = float(value)
    except (TypeError, ValueError):
        return None
    if timeout <= 0:
        return None
    return timeout


def _resolve_stdio_timeout_seconds(
    server_name: str,
    config: dict[str, Any] | None = None,
) -> float:
    normalized_name = str(server_name or "").strip()
    env_key = f"{normalized_name.upper().replace('-', '_')}_TIMEOUT_SECONDS"
    effective_config = config
    if effective_config is None and normalized_name:
        effective_config = load_mcp_config_by_name(normalized_name)

    for candidate in (
        (effective_config or {}).get("timeout_seconds"),
        os.getenv(env_key),
        os.getenv("DAAN_MCP_STDIO_TIMEOUT_SECONDS"),
    ):
        resolved = _parse_positive_timeout(candidate)
        if resolved is not None:
            return resolved
    return _DEFAULT_STDIO_TIMEOUT_SECONDS




async def initialize_mcp_toolset(
    mcp_server_name: str,
    extra_env: dict[str, object] | None = None,
    credentials_env: dict[str, str] | None = None,
    credentials: dict[str, Any] | None = None,
    db: Any | None = None,
    user_id: int | None = None,
) -> list:
    """Establish a connection to an MCP server and retrieve its available tools.
    
    Args:
        mcp_server_name: Name of the MCP server from registry
        extra_env: Additional env vars (e.g., session ID)
        credentials_env: Pre-resolved {ENV_VAR_NAME: value} from CredentialResolver
        credentials: Raw decrypted credentials dict for http/sse header auth
        db: Optional SQLAlchemy session for DB-registered servers
        user_id: Owning user id for DB registry scoping
    
    Returns:
        List containing initialized McpToolset object(s), or empty list if connection failed.
    """
    toolsets = get_mcp_toolset(
        mcp_server_name,
        extra_env=extra_env,
        credentials_env=credentials_env,
        credentials=credentials,
        db=db,
        user_id=user_id,
    )
    
    if not toolsets:
        return []
    
    initialized = []
    for toolset in toolsets:
        try:
            tools = await toolset.get_tools()
            print(f"MCP '{mcp_server_name}' connected - {len(tools)} tool(s) available")
            initialized.append(toolset)
        except Exception as e:
            print(f"MCP '{mcp_server_name}' connection failed: {e}")
    
    return initialized


def load_mcp_config_by_name(
    mcp_server_name: str,
    db: Any | None = None,
    user_id: int | None = None,
) -> dict | None:
    """Load server definition from the YAML registry, falling back to the DB registry.

    Args:
        mcp_server_name: Name of the MCP server (e.g., "jira-mcp-server")
        db: Optional SQLAlchemy session for resolving UI-onboarded servers.
        user_id: Owning user id used to scope the DB registry lookup.

    Returns:
        Configuration dict with transport, command, args, env_mapping etc.,
        or None if the server is not found in either registry.
    """
    config_path = _REGISTRY_PATH
    
    if not config_path.exists():
        print(f"MCP registry file not found: {config_path}")
        return None
    
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config_data = yaml.safe_load(f) or {}
    except Exception as e:
        print(f"Error loading MCP registry file: {e}")
        return None
    
    servers = config_data.get("servers", {})
    server_config = servers.get(mcp_server_name)
    
    if not server_config:
        db_config = load_mcp_config_from_db(mcp_server_name, db, user_id)
        if db_config is not None:
            return db_config
        print(f"MCP server '{mcp_server_name}' is not defined in config/mcp_servers_registry.yml")
        return None
    
    config = dict(server_config)
    config.setdefault("name", mcp_server_name)
    return config


def load_mcp_config_from_db(
    mcp_server_name: str,
    db: Any | None = None,
    user_id: int | None = None,
) -> dict | None:
    """Load a UI-onboarded server definition from the DB registry (McpServerRegistry).

    Maps DB columns into the same normalized shape the YAML loader produces so the
    rest of the pipeline is transport-agnostic. Returns None when unavailable.
    """
    if db is None:
        return None

    try:
        from daan.models.mcp_registry import McpServerRegistry

        base = db.query(McpServerRegistry).filter(
            McpServerRegistry.server_name == mcp_server_name
        )
        # Prefer the user's own definition, then fall back to a global one
        # (mirrors CredentialResolver so server-def and creds resolve in the same scope).
        entry = None
        if user_id is not None:
            entry = base.filter(
                McpServerRegistry.created_by_user_id == user_id
            ).first()
        if entry is None:
            entry = base.filter(McpServerRegistry.is_global == True).first()  # noqa: E712
    except Exception as e:
        print(f"Error loading MCP server '{mcp_server_name}' from DB registry: {e}")
        return None

    if entry is None:
        return None

    transport = entry.transport.value if entry.transport else ""
    auth_scheme = entry.auth_scheme.value if entry.auth_scheme else "none"

    # DB uses 'http' for streamable HTTP; the normalizer expects 'streamable_http'.
    normalized_transport = "streamable_http" if transport == "http" else transport

    config: dict[str, Any] = {
        "name": mcp_server_name,
        "transport": normalized_transport,
        "auth_scheme": auth_scheme,
        "required_credentials": entry.required_credentials or {},
        "source": "db_registry",
    }
    if entry.base_url:
        config["url"] = entry.base_url
    if entry.command:
        config["command"] = entry.command
    if entry.args:
        config["args"] = entry.args
    if entry.env_vars:
        config["env"] = entry.env_vars
    return config



def _normalize_mcp_server_config(mcp_server_config):
    """Validate and normalize an MCP server configuration from the registry.
    
    Checks that required fields are present and valid, then transforms 
    the config into a standard internal format.
    
    Returns:
        Normalized dict with transport-specific fields, or None if invalid.
    """
    if not isinstance(mcp_server_config, dict):
        print("MCP server entry is not a valid configuration object")
        return None

    server_name = str(mcp_server_config.get("name") or "").strip()
    transport = str(mcp_server_config.get("transport") or "").strip().lower()

    if not server_name:
        print("MCP server must have a 'name' field")
        return None

    if not transport:
        print(f"MCP server '{server_name}' must specify a 'transport' type (stdio, streamable_http, or sse)")
        return None

    if transport in {"streamable_http", "http", "https", "sse"}:
        server_url = str(mcp_server_config.get("url") or "").strip()
        if not server_url:
            env_key = f"{server_name.upper().replace('-', '_')}_URL"
            server_url = str(os.getenv(env_key, "")).strip()
        if not server_url:
            print(f"MCP server '{server_name}' ({transport}) requires a 'url' field or {env_key} environment variable")
            return None
        resolved_transport = "sse" if transport == "sse" else "streamable_http"
        return {
            "name": server_name,
            "transport": resolved_transport,
            "url": server_url,
            "auth_scheme": str(mcp_server_config.get("auth_scheme") or "none"),
        }

    if transport == "stdio":
        command = str(mcp_server_config.get("command") or "").strip()
        if not command:
            print(f"MCP server '{server_name}' (stdio) requires a 'command' field (e.g., 'npx', 'python')")
            return None

        python_executable = str(mcp_server_config.get("python_executable") or "").strip()

        # Resolve to the actual executable path so subprocess can find it.
        # For Python-based repo-local MCP servers, force the current interpreter
        # so the subprocess uses the same environment and installed packages.
        if command.lower() == "python":
            if python_executable:
                candidate = Path(python_executable)
                if not candidate.is_absolute():
                    candidate = (_WORKSPACE_ROOT / candidate).resolve()
                if candidate.exists():
                    resolved_command = str(candidate)
                else:
                    print(
                        f"Configured python_executable for MCP server '{server_name}' was not found: {candidate}. Falling back to current interpreter."
                    )
                    resolved_command = sys.executable
            else:
                resolved_command = sys.executable
        else:
            # This is especially important on Windows where 'npx' resolves to
            # 'npx.ps1', but subprocess needs the actual 'npx.cmd' or '.exe' path.
            resolved_command = shutil.which(command) or command
        command = resolved_command

        args = mcp_server_config.get("args") or []
        if isinstance(args, str):
            args = [args]
        elif not isinstance(args, list):
            print(f"MCP server '{server_name}' 'args' field must be a list or string")
            return None

        env = mcp_server_config.get("env") or {}
        if not isinstance(env, dict):
            print(f"MCP server '{server_name}' 'env' field must be a dictionary")
            return None

        return {
            "name": server_name,
            "transport": "stdio",
            "command": command,
            "args": args,
            "env": env,
        }

    print(
        f"Transport type '{transport}' for MCP server '{server_name}' is not supported (use 'stdio' or 'streamable_http')"
    )
    return None


def _inject_credentials_to_env(subprocess_env: dict, server_name: str, credentials_env: dict[str, str] | None = None) -> dict:
    """Inject pre-resolved credential env vars into subprocess environment.
    
    Args:
        subprocess_env: Dictionary to inject credentials into
        server_name: Name of the MCP server (for special-case handling)
        credentials_env: Pre-resolved {ENV_VAR_NAME: value} dict from CredentialResolver.resolve_as_env()
    
    Returns:
        Updated subprocess_env dict with credentials injected
    """
    if not credentials_env:
        return subprocess_env

    for env_key, env_value in credentials_env.items():
        if env_value:
            subprocess_env[env_key] = str(env_value)

    # Map legacy bare keys (BASE_URL, USERNAME…) to SERVICENOW_* prefixed names.
    # Only read from credentials_env — never from subprocess_env, which carries OS
    # vars like the Windows %USERNAME% that would silently overwrite the real value.
    if server_name == "servicenow-mcp":
        alias_map = {
            "BASE_URL": "SERVICENOW_BASE_URL",
            "USERNAME": "SERVICENOW_USERNAME",
            "PASSWORD": "SERVICENOW_PASSWORD",
            "VERIFY_SSL": "SERVICENOW_VERIFY_SSL",
        }
        for src, dest in alias_map.items():
            value = credentials_env.get(src)
            if value:
                subprocess_env[dest] = value

    return subprocess_env


def _prepare_stdio_subprocess_env(
    base_env: dict[str, str],
    server_name: str,
    extra_env: dict[str, object] | None = None,
    credentials_env: dict[str, str] | None = None,
) -> dict[str, str]:
    """Normalize stdio MCP subprocess environment across configured and repo-local loaders."""
    subprocess_env = dict(base_env)
    if extra_env:
        subprocess_env.update({k: str(v) for k, v in extra_env.items()})

    service_path = str((_WORKSPACE_ROOT / "service").resolve())
    workspace_path = str(_WORKSPACE_ROOT.resolve())
    existing_pythonpath = str(subprocess_env.get("PYTHONPATH", "")).strip()
    pythonpath_entries = [p for p in existing_pythonpath.split(os.pathsep) if p]
    for candidate in (service_path, workspace_path):
        if candidate not in pythonpath_entries:
            pythonpath_entries.insert(0, candidate)
    subprocess_env["PYTHONPATH"] = os.pathsep.join(pythonpath_entries)

    subprocess_env.setdefault("PYTHONIOENCODING", "utf-8")
    subprocess_env.setdefault("PYTHONUTF8", "1")

    return _inject_credentials_to_env(subprocess_env, server_name, credentials_env=credentials_env)


def get_mcp_toolset(
    mcp_server_name: str,
    extra_env: dict[str, object] | None = None,
    credentials_env: dict[str, str] | None = None,
    credentials: dict[str, Any] | None = None,
    db: Any | None = None,
    user_id: int | None = None,
):
    """Load an MCP server by name from the registry and return a McpToolset connector.
    
    Args:
        mcp_server_name: Name of the MCP server (e.g., 'jira-mcp-server')
        extra_env: Additional env vars (e.g., session ID)
        credentials_env: Pre-resolved {ENV_VAR_NAME: value} dict (stdio transport)
        credentials: Raw decrypted credentials dict (http/sse header auth)
        db: Optional SQLAlchemy session for DB-registered servers
        user_id: Owning user id for DB registry scoping
    
    Returns:
        List of McpToolset instances ready to connect, or empty list if not found/invalid.
    """
    config = load_mcp_config_by_name(mcp_server_name, db=db, user_id=user_id)
    if config is None:
        return _get_repo_local_mcp_toolset(mcp_server_name, extra_env=extra_env, credentials_env=credentials_env)
    
    normalized = _normalize_mcp_server_config(config)
    if normalized is None:
        return []

    if normalized["transport"] in {"streamable_http", "sse"}:
        headers = build_auth_headers(normalized.get("auth_scheme"), credentials) or None
        tool_timeout = (
            _parse_positive_timeout((config.get("connection") or {}).get("timeout"))
            or _DEFAULT_HTTP_TOOL_TIMEOUT_SECONDS
        )
        try:
            if normalized["transport"] == "sse":
                connection_params = SseConnectionParams(
                    url=normalized["url"],
                    headers=headers,
                    timeout=tool_timeout,
                    httpx_client_factory=_system_store_http_client_factory,
                )
            else:
                connection_params = StreamableHTTPConnectionParams(
                    url=normalized["url"],
                    headers=headers,
                    timeout=tool_timeout,
                    httpx_client_factory=_system_store_http_client_factory,
                )
            return [McpToolset(connection_params=connection_params)]
        except Exception as e:
            print(f"Failed to create {normalized['transport']} connection for MCP '{mcp_server_name}': {e}")
            return []

    if normalized["transport"] == "stdio":
        command = normalized["command"]
        args = normalized["args"]
        # Substitute {ENV_VAR_NAME} placeholders in args from resolved credentials (e.g. positional org args)
        if credentials_env and args:
            import re as _re
            _placeholder_re = _re.compile(r"\{([A-Z_][A-Z0-9_]*)\}")
            def _sub_arg(a):
                if not isinstance(a, str) or "{" not in a:
                    return a
                return _placeholder_re.sub(
                    lambda m: str(credentials_env.get(m.group(1), m.group(0))),
                    a,
                )
            args = [_sub_arg(a) for a in args]
        timeout_seconds = _resolve_stdio_timeout_seconds(mcp_server_name, config)
        merged_extra_env = dict(normalized.get("env") or {})
        if extra_env:
            merged_extra_env.update(extra_env)

        subprocess_env = _prepare_stdio_subprocess_env(
            base_env=dict(os.environ),
            server_name=mcp_server_name,
            extra_env=merged_extra_env,
            credentials_env=credentials_env,
        )
        
        try:
            return [
                McpToolset(
                    connection_params=StdioConnectionParams(
                        server_params=StdioServerParameters(
                            command=command,
                            args=args,
                            env=subprocess_env,
                        ),
                        timeout=timeout_seconds,
                    )
                )
            ]
        except Exception as e:
            print(f"Failed to create subprocess connection for MCP '{mcp_server_name}': {e}")
            return []

    return []


def _get_repo_local_mcp_toolset(
    mcp_server_name: str,
    extra_env: dict[str, object] | None = None,
    credentials_env: dict[str, str] | None = None,
) -> list[McpToolset]:
    """Load an MCP server from a Python module in the repository.
    
    Convention: MCP server name 'trello-mcp-server' maps to module 'daan.mcp_servers.trello_mcp_server'.
    The module must export an object named `mcp` with a .run(transport='stdio') method.
    """
    server_name = str(mcp_server_name or "").strip()
    if not server_name:
        return []

    module_basename = server_name.replace("-", "_")
    module_qualname = f"daan.mcp_servers.{module_basename}"

    try:
        spec = importlib.util.find_spec(module_qualname)
    except Exception:
        spec = None

    if spec is None:
        return []

    # Start with full system environment (needed for local Python modules to find system tools)
    subprocess_env = _prepare_stdio_subprocess_env(
        base_env=dict(os.environ),
        server_name=server_name,
        extra_env=extra_env,
        credentials_env=credentials_env,
    )

    # Keep imports robust regardless of the FastAPI process working directory.
    # Do not hardcode paths; instead, ensure cwd and its parent are on sys.path.
    startup_code = (
        "import os, sys, importlib; "
        "sys.path.insert(0, os.getcwd()); "
        "sys.path.insert(0, os.path.abspath(os.path.join(os.getcwd(), '..'))); "
        f"mod = importlib.import_module('{module_qualname}'); "
        "mcp = getattr(mod, 'mcp', None); "
        "\nif mcp is None: raise SystemExit('Module does not export `mcp`'); "
        "\nmcp.run(transport='stdio')"
    )

    try:
        toolset = McpToolset(
            connection_params=StdioConnectionParams(
                server_params=StdioServerParameters(
                    command=sys.executable,
                    args=["-c", startup_code],
                    env=subprocess_env,
                ),
                timeout=_resolve_stdio_timeout_seconds(server_name),
            )
        )
    except Exception as e:
        print(f"Failed to load repository MCP module '{server_name}': {e}")
        return []

    print(f"Loaded MCP module '{module_qualname}' from repository as fallback for '{server_name}'")
    return [toolset]


async def initialize_mcp_for_agents(
    action_agents: list[dict],
    session_id: str | None = None,
    credential_resolver=None,
) -> dict[str, dict[str, object]]:
    """Initialize MCP servers for action agents using DB-backed credentials.
    
    Args:
        action_agents: List of agent config dicts with mcp_servers field
        session_id: Current session ID for tracking
        credential_resolver: CredentialResolver instance (from daan.core.credential_resolver)
            If None, credentials won't be injected (backward-compatible).
    
    Returns:
        Dictionary keyed by MCP server name with resolved toolsets.
    """
    result: dict[str, dict[str, object]] = {}
    runtime_env = {"DAAN_SESSION_ID": session_id} if str(session_id or "").strip() else None
    resolver_db = getattr(credential_resolver, "_db", None)
    resolver_user_id = getattr(credential_resolver, "_user_id", None)

    for agent in action_agents:
        mcp_servers = agent.get("mcp_servers") or agent.get("mcp_tools") or []
        if isinstance(mcp_servers, str):
            mcp_servers = [s.strip() for s in mcp_servers.strip("[]").split(",") if s.strip()]

        for primary_server in mcp_servers:
            if not primary_server or primary_server in result:
                continue

            # Resolve credentials from DB (env vars for stdio, raw dict for http/sse headers)
            credentials_env = None
            credentials = None
            if credential_resolver:
                try:
                    credentials = credential_resolver.resolve(primary_server)
                    credentials_env = credential_resolver.resolve_as_env(primary_server)
                except Exception as e:
                    print(f"No credentials for MCP '{primary_server}': {e}")
            
            # Step 1: Attempt primary server
            try:
                toolsets = await initialize_mcp_toolset(
                    primary_server,
                    extra_env=runtime_env,
                    credentials_env=credentials_env,
                    credentials=credentials,
                    db=resolver_db,
                    user_id=resolver_user_id,
                )
                if toolsets:
                    result[primary_server] = {
                        "requested_server": primary_server,
                        "resolved_server": primary_server,
                        "toolsets": toolsets,
                        "source": "primary",
                    }
                    continue
            except Exception as e:
                print(f"Cannot connect to primary MCP '{primary_server}': {e}")
            
            # Step 2: Read fallback from registry
            config = load_mcp_config_by_name(primary_server, db=resolver_db, user_id=resolver_user_id)
            fallback_server = config.get("fallback_local_mcp") if config else None
            
            if not fallback_server:
                print(f"No fallback defined for MCP '{primary_server}' in registry")
                continue
            
            # Resolve fallback credentials
            fallback_creds_env = None
            fallback_creds = None
            if credential_resolver:
                try:
                    fallback_creds = credential_resolver.resolve(fallback_server)
                    fallback_creds_env = credential_resolver.resolve_as_env(fallback_server)
                except Exception:
                    pass

            # Step 3: Try fallback
            try:
                print(f"Trying fallback '{fallback_server}' for '{primary_server}'")
                initialized = await initialize_mcp_toolset(
                    fallback_server,
                    extra_env=runtime_env,
                    credentials_env=fallback_creds_env,
                    credentials=fallback_creds,
                    db=resolver_db,
                    user_id=resolver_user_id,
                )
                if not initialized:
                    print(f"Could not load fallback MCP '{fallback_server}' via registry; trying repo-local loader")
                    toolsets = _get_repo_local_mcp_toolset(
                        fallback_server, extra_env=runtime_env, credentials_env=fallback_creds_env
                    )
                    if not toolsets:
                        print(f"Could not load fallback MCP '{fallback_server}'")
                        continue

                    initialized = []
                    for toolset in toolsets:
                        try:
                            tools = await toolset.get_tools()
                            print(f"Fallback MCP '{fallback_server}' connected - {len(tools)} tool(s) available")
                            initialized.append(toolset)
                        except Exception as e:
                            print(f"Failed to authenticate fallback '{fallback_server}': {e}")
                
                if initialized:
                    result[primary_server] = {
                        "requested_server": primary_server,
                        "resolved_server": fallback_server,
                        "toolsets": initialized,
                        "source": "fallback",
                    }
                    print(f"Using fallback MCP '{fallback_server}' for '{primary_server}'")
            except Exception as e:
                print(f"Fallback '{fallback_server}' also failed: {e}")

    return result
