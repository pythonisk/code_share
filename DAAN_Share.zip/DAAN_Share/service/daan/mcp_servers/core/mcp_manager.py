"""Lifecycle manager for stdio-based MCP server subprocesses."""

import asyncio
import logging
import time
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from typing import Any

from daan.core.exceptions import DAANException

logger = logging.getLogger(__name__)


class ProcessState(Enum):
    """State of an MCP process."""

    STARTING = "starting"
    RUNNING = "running"
    IDLE = "idle"
    FAILED = "failed"
    TERMINATED = "terminated"


@dataclass
class McpProcess:
    """Represents an active MCP server process."""

    process_id: str
    user_id: int
    server_name: str
    process: asyncio.subprocess.Process | None
    state: ProcessState
    created_at: datetime
    last_accessed_at: datetime
    access_count: int = 0
    memory_mb: float = 0.0
    error_count: int = 0
    last_error: str | None = None

    def is_alive(self) -> bool:
        """Check if process is still running."""
        if self.process is None:
            return False
        return self.process.returncode is None

    def update_access(self):
        """Update last access time and increment counter."""
        self.last_accessed_at = datetime.now()
        self.access_count += 1

    def is_idle(self, idle_timeout: int) -> bool:
        """Check if process has been idle for too long.

        Args:
            idle_timeout: Idle timeout in seconds

        Returns:
            True if idle timeout exceeded
        """
        if self.state != ProcessState.RUNNING:
            return False

        idle_duration = (datetime.now() - self.last_accessed_at).total_seconds()
        return idle_duration > idle_timeout

    def get_uptime(self) -> float:
        """Get process uptime in seconds."""
        return (datetime.now() - self.created_at).total_seconds()


class McpProcessManager:
    """Manager for MCP server processes.

    Handles process lifecycle, connection pooling, and resource management.
    """

    def __init__(
        self,
        max_connections_per_user: int = 3,
        idle_timeout: int = 1800,  # 30 minutes
        cleanup_interval: int = 300,  # 5 minutes
        max_memory_mb: int = 512,
    ):
        """Initialize MCP process manager.

        Args:
            max_connections_per_user: Maximum concurrent connections per user
            idle_timeout: Kill processes idle longer than this (seconds)
            cleanup_interval: Interval for cleanup task (seconds)
            max_memory_mb: Maximum memory per process (MB)
        """
        self.max_connections_per_user = max_connections_per_user
        self.idle_timeout = idle_timeout
        self.cleanup_interval = cleanup_interval
        self.max_memory_mb = max_memory_mb

        # Process registry: {process_id: McpProcess}
        self._processes: dict[str, McpProcess] = {}

        # User process tracking: {user_id: set[process_id]}
        self._user_processes: defaultdict[int, set[str]] = defaultdict(set)

        # Cleanup task
        self._cleanup_task: asyncio.Task | None = None
        self._running = False

        logger.info(
            f"McpProcessManager initialized (max_per_user={max_connections_per_user}, "
            f"idle_timeout={idle_timeout}s)"
        )

    async def start(self):
        """Start the process manager and cleanup task."""
        if self._running:
            logger.warning("Process manager already running")
            return

        self._running = True
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
        logger.info("Process manager started")

    async def stop(self):
        """Stop the process manager and terminate all processes."""
        if not self._running:
            return

        self._running = False

        # Cancel cleanup task
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass

        # Terminate all processes
        for process_id in list(self._processes.keys()):
            await self.terminate_process(process_id)

        logger.info("Process manager stopped")

    async def start_process(
        self,
        user_id: int,
        server_name: str,
        script_path: str,
        env: dict[str, str] | None = None,
    ) -> str:
        """Start a new MCP server process.

        Args:
            user_id: User ID
            server_name: Name of the MCP server
            script_path: Path to the server script
            env: Environment variables for the process

        Returns:
            Process ID

        Raises:
            ProcessLimitReachedException: If user has reached max connections
            McpException: If process fails to start
        """
        # Check user connection limit
        user_process_count = len(self._user_processes[user_id])
        if user_process_count >= self.max_connections_per_user:
            raise DAANException.process_limit_reached(
                limit=self.max_connections_per_user,
                current=user_process_count,
            )

        # Generate unique process ID
        process_id = f"{user_id}_{server_name}_{int(time.time() * 1000)}"

        try:
            logger.info(f"Starting MCP process: {process_id} ({script_path})")

            # Start subprocess
            process = await asyncio.create_subprocess_exec(
                "python",
                script_path,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )

            # Create process record
            mcp_process = McpProcess(
                process_id=process_id,
                user_id=user_id,
                server_name=server_name,
                process=process,
                state=ProcessState.STARTING,
                created_at=datetime.now(),
                last_accessed_at=datetime.now(),
            )

            # Register process
            self._processes[process_id] = mcp_process
            self._user_processes[user_id].add(process_id)

            # Wait for process to be ready (simple check)
            await asyncio.sleep(1)

            if mcp_process.is_alive():
                mcp_process.state = ProcessState.RUNNING
                logger.info(f"MCP process started successfully: {process_id}")
            else:
                mcp_process.state = ProcessState.FAILED
                stderr = await process.stderr.read() if process.stderr else b""
                error_msg = stderr.decode("utf-8", errors="ignore")
                logger.error(f"MCP process failed to start: {error_msg}")
                raise DAANException(
                    f"Process failed to start: {error_msg[:200]}",
                    error_code=DAANException.ErrorCode.PROCESS_START_FAILED,
                )

            return process_id

        except Exception as e:
            logger.error(f"Failed to start MCP process: {e}")
            # Cleanup on failure
            if process_id in self._processes:
                await self.terminate_process(process_id)
            raise

    async def terminate_process(self, process_id: str):
        """Terminate an MCP process.

        Args:
            process_id: Process ID to terminate
        """
        if process_id not in self._processes:
            logger.warning(f"Process not found: {process_id}")
            return

        mcp_process = self._processes[process_id]

        try:
            if mcp_process.is_alive() and mcp_process.process:
                logger.info(f"Terminating process: {process_id}")
                mcp_process.process.terminate()

                # Wait for graceful termination
                try:
                    await asyncio.wait_for(mcp_process.process.wait(), timeout=5.0)
                except asyncio.TimeoutError:
                    # Force kill if not terminated
                    logger.warning(f"Force killing process: {process_id}")
                    mcp_process.process.kill()
                    await mcp_process.process.wait()

            mcp_process.state = ProcessState.TERMINATED

        except Exception as e:
            logger.error(f"Error terminating process {process_id}: {e}")

        finally:
            # Remove from registry
            self._user_processes[mcp_process.user_id].discard(process_id)
            del self._processes[process_id]

    async def get_process(self, process_id: str) -> McpProcess | None:
        """Get process by ID.

        Args:
            process_id: Process ID

        Returns:
            McpProcess if found, None otherwise
        """
        return self._processes.get(process_id)

    def get_user_processes(self, user_id: int) -> list[McpProcess]:
        """Get all processes for a user.

        Args:
            user_id: User ID

        Returns:
            List of user's MCP processes
        """
        process_ids = self._user_processes.get(user_id, set())
        return [self._processes[pid] for pid in process_ids if pid in self._processes]

    def get_process_count(self, user_id: int | None = None) -> int:
        """Get total process count or per-user count.

        Args:
            user_id: User ID (optional, None for total count)

        Returns:
            Process count
        """
        if user_id is None:
            return len(self._processes)
        return len(self._user_processes.get(user_id, set()))

    async def _cleanup_loop(self):
        """Background task to cleanup idle processes."""
        logger.info("Cleanup loop started")

        while self._running:
            try:
                await asyncio.sleep(self.cleanup_interval)
                await self._cleanup_idle_processes()

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in cleanup loop: {e}")

        logger.info("Cleanup loop stopped")

    async def _cleanup_idle_processes(self):
        """Cleanup processes that have been idle too long."""
        now = datetime.now()
        to_terminate: list[str] = []

        for process_id, mcp_process in self._processes.items():
            # Check if process is still alive
            if not mcp_process.is_alive():
                logger.info(f"Process died: {process_id}")
                to_terminate.append(process_id)
                continue

            # Check idle timeout
            if mcp_process.is_idle(self.idle_timeout):
                logger.info(
                    f"Process idle timeout exceeded: {process_id} "
                    f"(idle for {(now - mcp_process.last_accessed_at).total_seconds()}s)"
                )
                to_terminate.append(process_id)

        # Terminate idle processes
        for process_id in to_terminate:
            await self.terminate_process(process_id)

        if to_terminate:
            logger.info(f"Cleaned up {len(to_terminate)} idle/dead processes")

    def get_statistics(self) -> dict[str, Any]:
        """Get process manager statistics.

        Returns:
            Dictionary with statistics
        """
        total_processes = len(self._processes)
        active_users = len([u for u, procs in self._user_processes.items() if procs])

        state_counts = defaultdict(int)
        total_uptime = 0.0

        for proc in self._processes.values():
            state_counts[proc.state.value] += 1
            total_uptime += proc.get_uptime()

        avg_uptime = total_uptime / total_processes if total_processes > 0 else 0

        return {
            "total_processes": total_processes,
            "active_users": active_users,
            "state_counts": dict(state_counts),
            "avg_uptime_seconds": avg_uptime,
            "max_connections_per_user": self.max_connections_per_user,
            "idle_timeout_seconds": self.idle_timeout,
        }


# Global instance
_process_manager: McpProcessManager | None = None


def get_process_manager(
    max_connections_per_user: int = 3,
    idle_timeout: int = 1800,
) -> McpProcessManager:
    """Get or create the global MCP process manager.

    Args:
        max_connections_per_user: Maximum concurrent connections per user
        idle_timeout: Idle timeout in seconds

    Returns:
        McpProcessManager instance
    """
    global _process_manager

    if _process_manager is None:
        _process_manager = McpProcessManager(
            max_connections_per_user=max_connections_per_user,
            idle_timeout=idle_timeout,
        )

    return _process_manager
