"""MCP credential validator using server registry.

This module validates credentials against the MCP server registry configuration
to ensure all required fields are present and properly formatted.
"""

import logging
from pathlib import Path
from typing import Any

import yaml

from daan.core.exceptions import DAANException

logger = logging.getLogger(__name__)


class McpCredentialValidator:
    """Validator for MCP credentials based on server registry.

    Loads server definitions from YAML and validates credentials
    against required/optional fields.
    """

    def __init__(self, registry_path: str | Path | None = None):
        """Initialize validator with server registry.

        Args:
            registry_path: Path to mcp_servers_registry.yml
        """
        self.registry_path = registry_path
        self._registry: dict[str, Any] | None = None
        self._load_registry()

    def _load_registry(self):
        """Load server registry from YAML file."""
        if self.registry_path is None:
            # Extra .parent hop because this module lives in mcp_servers/core/ (one level deeper).
            config_dir = Path(__file__).parent.parent.parent.parent.parent / "config"
            self.registry_path = config_dir / "mcp_servers_registry.yml"

        try:
            with open(self.registry_path, "r", encoding="utf-8") as f:
                self._registry = yaml.safe_load(f)
                logger.info(f"Loaded MCP server registry from {self.registry_path}")
        except FileNotFoundError:
            logger.warning(f"Server registry not found at {self.registry_path}")
            self._registry = {"servers": {}}
        except Exception as e:
            logger.error(f"Failed to load server registry: {e}")
            self._registry = {"servers": {}}

    def get_server_definition(self, server_name: str) -> dict[str, Any] | None:
        """Get server definition from registry.

        Args:
            server_name: Name of the MCP server

        Returns:
            Server definition dictionary or None if not found
        """
        if not self._registry:
            return None

        return self._registry.get("servers", {}).get(server_name)

    def list_servers(self) -> list[str]:
        """List all available server names.

        Returns:
            List of server names
        """
        if not self._registry:
            return []

        return list(self._registry.get("servers", {}).keys())

    def validate_credentials(
        self,
        server_name: str,
        credentials: dict[str, Any],
        strict: bool = True,
    ) -> tuple[bool, list[str], list[str]]:
        """Validate credentials against server definition.

        Args:
            server_name: Name of the MCP server
            credentials: Credentials dictionary to validate
            strict: If True, raise exception on validation failure

        Returns:
            Tuple of (is_valid, missing_fields, extra_fields)

        Raises:
            ValidationFailedException: If strict=True and validation fails
            InvalidCredentialFormatException: If server not found or invalid format
        """
        # Get server definition
        server_def = self.get_server_definition(server_name)

        if server_def is None:
            # Server not in YAML registry (may be dynamically registered in DB)
            logger.info(f"Server '{server_name}' not in YAML registry, skipping field validation")
            return True, [], []

        # Get required and optional fields
        required_fields = set(server_def.get("required_fields", []))
        optional_fields = set(server_def.get("optional_fields", []))
        all_valid_fields = required_fields | optional_fields

        # Check for missing required fields
        provided_fields = set(credentials.keys())
        missing_fields = list(required_fields - provided_fields)

        # Check for extra fields (not in required or optional)
        extra_fields = list(provided_fields - all_valid_fields)

        # Validation result
        is_valid = len(missing_fields) == 0

        if strict and not is_valid:
            raise DAANException.invalid_credential_format(
                server_name=server_name,
                missing_fields=missing_fields,
            )

        if missing_fields:
            logger.warning(f"Missing required fields for {server_name}: {missing_fields}")

        if extra_fields:
            logger.info(f"Extra fields provided for {server_name}: {extra_fields}")

        return is_valid, missing_fields, extra_fields

    def get_field_description(self, server_name: str, field_name: str) -> str | None:
        """Get description for a credential field.

        Args:
            server_name: Name of the MCP server
            field_name: Name of the credential field

        Returns:
            Field description or None
        """
        server_def = self.get_server_definition(server_name)

        if server_def is None:
            return None

        descriptions = server_def.get("field_descriptions", {})
        return descriptions.get(field_name)

    def get_validation_config(self, server_name: str) -> dict[str, Any] | None:
        """Get validation configuration for a server.

        Args:
            server_name: Name of the MCP server

        Returns:
            Validation config dictionary or None
        """
        server_def = self.get_server_definition(server_name)

        if server_def is None:
            return None

        return server_def.get("validation")

    def get_connection_config(self, server_name: str) -> dict[str, Any]:
        """Get connection configuration for a server.

        Args:
            server_name: Name of the MCP server

        Returns:
            Connection config dictionary (with defaults)
        """
        server_def = self.get_server_definition(server_name)

        # Default connection config
        defaults = self._registry.get("defaults", {}).get("connection", {})

        if server_def is None:
            return defaults.copy()

        # Merge server-specific config with defaults
        server_config = server_def.get("connection", {})
        return {**defaults, **server_config}

    def get_resource_limits(self, server_name: str) -> dict[str, Any]:
        """Get resource limits for a server.

        Args:
            server_name: Name of the MCP server

        Returns:
            Resource limits dictionary (with defaults)
        """
        server_def = self.get_server_definition(server_name)

        # Default resource limits
        defaults = self._registry.get("defaults", {}).get("resource_limits", {})

        if server_def is None:
            return defaults.copy()

        # Merge server-specific limits with defaults
        server_limits = server_def.get("resource_limits", {})
        return {**defaults, **server_limits}

    def reload_registry(self):
        """Reload server registry from file.

        Use this to pick up changes without restarting the service.
        """
        self._load_registry()
        logger.info("Server registry reloaded")


# Global instance
_validator: McpCredentialValidator | None = None


def get_credential_validator(registry_path: str | Path | None = None) -> McpCredentialValidator:
    """Get or create the global credential validator.

    Args:
        registry_path: Path to mcp_servers_registry.yml

    Returns:
        McpCredentialValidator instance
    """
    global _validator

    if _validator is None:
        _validator = McpCredentialValidator(registry_path=registry_path)

    return _validator
