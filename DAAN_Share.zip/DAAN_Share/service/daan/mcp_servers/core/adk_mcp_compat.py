"""Compatibility imports for Google ADK MCP APIs.

Google ADK has changed where MCP symbols are exported between versions.
DAAN only needs:
- McpToolset (or MCPToolset)
- StreamableHTTPConnectionParams
- StdioConnectionParams

This module centralizes the import fallbacks so DAAN can run against a wider
range of installed `google-adk` versions.
"""

from __future__ import annotations


def _import_adk_mcp_symbols():
    last_error: Exception | None = None

    # Prefer the public re-exports.
    try:
        from google.adk.tools.mcp_tool import (  # type: ignore
            McpToolset,
            StreamableHTTPConnectionParams,
        )
        from google.adk.tools.mcp_tool.mcp_session_manager import (  # type: ignore
            StdioConnectionParams,
        )

        return McpToolset, StreamableHTTPConnectionParams, StdioConnectionParams
    except Exception as e:  # pragma: no cover
        last_error = e

    # Older layouts sometimes keep the classes in submodules without re-exporting.
    try:  # pragma: no cover
        from google.adk.tools.mcp_tool.mcp_toolset import (  # type: ignore
            McpToolset,
            StreamableHTTPConnectionParams,
        )
        from google.adk.tools.mcp_tool.mcp_session_manager import (  # type: ignore
            StdioConnectionParams,
        )

        return McpToolset, StreamableHTTPConnectionParams, StdioConnectionParams
    except Exception as e:  # pragma: no cover
        last_error = e

    # Some versions expose MCPToolset instead of McpToolset.
    try:  # pragma: no cover
        from google.adk.tools.mcp_tool.mcp_toolset import (  # type: ignore
            MCPToolset as McpToolset,
            StreamableHTTPConnectionParams,
        )
        from google.adk.tools.mcp_tool.mcp_session_manager import (  # type: ignore
            StdioConnectionParams,
        )

        return McpToolset, StreamableHTTPConnectionParams, StdioConnectionParams
    except Exception as e:  # pragma: no cover
        last_error = e

    raise ImportError(
        "Unable to import ADK MCP symbols (McpToolset / *ConnectionParams). "
        "This usually means the backend is running with a different Python environment "
        "than the repo's `.venv`, or `google-adk` is an incompatible version. "
        "Try starting the service with `.venv` and ensure `google-adk` is installed there. "
        f"Last import error: {last_error}"
    )


McpToolset, StreamableHTTPConnectionParams, StdioConnectionParams = _import_adk_mcp_symbols()
