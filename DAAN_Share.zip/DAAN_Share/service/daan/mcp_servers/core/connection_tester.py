"""Unified connection tester for MCP servers.

Tests real connectivity to external services using decrypted credentials.
Reads auth_scheme config from mcp_servers_registry.yml.
Supports 4 auth schemes: bearer, basic, oauth2_client_credentials, connector.
"""

import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import requests
import yaml

logger = logging.getLogger(__name__)

_REGISTRY_PATH = Path(__file__).resolve().parents[4] / "config" / "mcp_servers_registry.yml"
_registry_cache: dict[str, Any] | None = None


def _load_registry() -> dict[str, Any]:
    """Load and cache the server registry YAML."""
    global _registry_cache
    if _registry_cache is None:
        with open(_REGISTRY_PATH, "r", encoding="utf-8") as f:
            _registry_cache = yaml.safe_load(f)
    return _registry_cache


def _get_server_validation_config(server_name: str) -> dict[str, Any] | None:
    """Get the validation block for a server from the registry."""
    registry = _load_registry()
    servers = registry.get("servers", {})
    server = servers.get(server_name)
    if not server:
        return None
    return server.get("validation")


@dataclass
class TestConnectionResult:
    connected: bool
    latency_ms: int
    message: str
    auth_method: str
    server_info: dict[str, Any] | None = None


def test_connection(server_name: str, credentials: dict[str, Any]) -> TestConnectionResult:
    """Test real connectivity to an external service using provided credentials."""
    config = _get_server_validation_config(server_name)
    if not config:
        return TestConnectionResult(
            connected=False, latency_ms=0,
            message=f"No validation config found for server '{server_name}' in registry",
            auth_method="unknown",
        )

    scheme = config.get("auth_scheme", "none")
    timeout = config.get("timeout", 30)
    start = time.time()

    try:
        if scheme == "bearer":
            result = _test_bearer(config, credentials, timeout)
        elif scheme == "basic":
            result = _test_basic(config, credentials, timeout)
        elif scheme == "oauth2_client_credentials":
            result = _test_oauth2(config, credentials, timeout)
        elif scheme == "query_param":
            result = _test_query_param(config, credentials, timeout)
        elif scheme == "connector":
            result = _test_connector(config, credentials, timeout)
        elif scheme == "none":
            result = TestConnectionResult(
                connected=True, latency_ms=0,
                message="No external connection required",
                auth_method="none",
            )
        else:
            result = TestConnectionResult(
                connected=False, latency_ms=0,
                message=f"Unknown auth_scheme: {scheme}",
                auth_method=scheme,
            )
    except requests.Timeout:
        result = TestConnectionResult(
            connected=False, latency_ms=int((time.time() - start) * 1000),
            message=f"Connection timed out after {timeout}s",
            auth_method=scheme,
        )
    except requests.ConnectionError as exc:
        result = TestConnectionResult(
            connected=False, latency_ms=int((time.time() - start) * 1000),
            message=f"Connection refused: {exc}",
            auth_method=scheme,
        )
    except Exception as exc:
        result = TestConnectionResult(
            connected=False, latency_ms=int((time.time() - start) * 1000),
            message=str(exc)[:300],
            auth_method=scheme,
        )

    result.latency_ms = int((time.time() - start) * 1000)
    return result


def _resolve_endpoint(endpoint: str, credentials: dict[str, Any]) -> str:
    """Substitute {field} placeholders in endpoint with credential values."""
    for key, val in credentials.items():
        endpoint = endpoint.replace(f"{{{key}}}", str(val))
    return endpoint


def _test_bearer(config: dict, creds: dict, timeout: int) -> TestConnectionResult:
    # Clean all credential values first (strip quotes/backticks)
    cleaned_creds = {}
    for key, value in creds.items():
        if isinstance(value, str):
            cleaned_creds[key] = value.strip().strip("'\"` ")
        else:
            cleaned_creds[key] = value
    
    host = config.get("base_url") or cleaned_creds.get(config["host_field"], "").rstrip("/")
    token = cleaned_creds[config["token_field"]]
    
    endpoint = _resolve_endpoint(config["endpoint"], cleaned_creds)
    params = config.get("params")
    prefix = config.get("auth_header_prefix", "Bearer")

    # Ensure host has scheme
    if host and not host.startswith("http"):
        host = f"https://{host}"

    full_url = f"{host}{endpoint}"
    logger.info("Testing bearer connection: %s (cleaned host: %s, endpoint: %s)", full_url, host, endpoint)

    resp = requests.get(
        full_url,
        headers={"Authorization": f"{prefix} {token}"},
        params=params,
        timeout=timeout,
        verify=False,
    )
    
    logger.info("Response status: %s for URL: %s", resp.status_code, full_url)

    if resp.status_code == 200:
        return TestConnectionResult(
            connected=True, latency_ms=0,
            message=f"Connected ({resp.status_code}ms) — {full_url}",
            auth_method="bearer",
            server_info={"status_code": 200},
        )
    return TestConnectionResult(
        connected=False, latency_ms=0,
        message=f"HTTP {resp.status_code}: {resp.text[:200]}",
        auth_method="bearer",
        server_info={"url": full_url, "status_code": resp.status_code},
    )


def _test_basic(config: dict, creds: dict, timeout: int) -> TestConnectionResult:
    # Clean all credential values first
    cleaned_creds = {}
    for key, value in creds.items():
        if isinstance(value, str):
            cleaned_creds[key] = value.strip().strip("'\"` ")
        else:
            cleaned_creds[key] = value
    
    host_field = config["host_field"]
    host = cleaned_creds.get(host_field, "").rstrip("/")
    if config.get("host_prefix") and not host.startswith("http"):
        host = config["host_prefix"] + host

    username = cleaned_creds.get(config.get("username_field", ""), "") if config.get("username_field") else ""
    password = cleaned_creds[config["password_field"]]
    endpoint = _resolve_endpoint(config["endpoint"], cleaned_creds)

    resp = requests.get(
        f"{host}{endpoint}",
        auth=(username, password),
        timeout=timeout,
        verify=False,
    )

    if resp.status_code == 200:
        return TestConnectionResult(
            connected=True, latency_ms=0,
            message=f"Connected to {host}",
            auth_method="basic",
            server_info={"status_code": 200},
        )
    return TestConnectionResult(
        connected=False, latency_ms=0,
        message=f"HTTP {resp.status_code}: {resp.text[:200]}",
        auth_method="basic",
    )


def _test_oauth2(config: dict, creds: dict, timeout: int) -> TestConnectionResult:
    # Clean all credential values first
    cleaned_creds = {}
    for key, value in creds.items():
        if isinstance(value, str):
            cleaned_creds[key] = value.strip().strip("'\"` ")
        else:
            cleaned_creds[key] = value
    
    tenant_id = cleaned_creds[config["tenant_field"]]
    client_id = cleaned_creds[config["client_id_field"]]
    client_secret = cleaned_creds[config["client_secret_field"]]

    # Azure AD token exchange
    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    token_resp = requests.post(
        token_url,
        data={
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": "https://management.azure.com/.default",
        },
        timeout=timeout,
        verify=False,
    )

    if token_resp.status_code != 200:
        return TestConnectionResult(
            connected=False, latency_ms=0,
            message=f"OAuth token exchange failed: HTTP {token_resp.status_code}",
            auth_method="oauth2_client_credentials",
        )

    access_token = token_resp.json()["access_token"]

    # Verify by calling Azure ARM
    sub_id = cleaned_creds[config["subscription_field"]]
    rg = cleaned_creds[config["resource_group_field"]]
    factory = cleaned_creds[config["factory_field"]]
    arm_url = (
        f"https://management.azure.com/subscriptions/{sub_id}"
        f"/resourceGroups/{rg}/providers/Microsoft.DataFactory"
        f"/factories/{factory}?api-version=2018-06-01"
    )

    resp = requests.get(
        arm_url,
        headers={"Authorization": f"Bearer {access_token}"},
        timeout=timeout,
        verify=False,
    )

    if resp.status_code == 200:
        return TestConnectionResult(
            connected=True, latency_ms=0,
            message=f"Connected to ADF factory '{factory}'",
            auth_method="oauth2_client_credentials",
            server_info={"factory": factory, "resource_group": rg},
        )
    return TestConnectionResult(
        connected=False, latency_ms=0,
        message=f"ARM API returned HTTP {resp.status_code}: {resp.text[:200]}",
        auth_method="oauth2_client_credentials",
    )


def _test_query_param(config: dict, creds: dict, timeout: int) -> TestConnectionResult:
    # Clean all credential values first
    cleaned_creds = {}
    for key, value in creds.items():
        if isinstance(value, str):
            cleaned_creds[key] = value.strip().strip("'\"` ")
        else:
            cleaned_creds[key] = value
    
    base_url = config.get("base_url", "").strip().strip("'\"` ")
    endpoint = config["endpoint"]
    key = cleaned_creds[config["key_field"]]
    token = cleaned_creds[config["token_field"]]

    resp = requests.get(
        f"{base_url}{endpoint}",
        params={"key": key, "token": token},
        timeout=timeout,
        verify=False,
    )

    if resp.status_code == 200:
        return TestConnectionResult(
            connected=True, latency_ms=0,
            message="Connected to Trello",
            auth_method="query_param",
            server_info={"status_code": 200},
        )
    return TestConnectionResult(
        connected=False, latency_ms=0,
        message=f"HTTP {resp.status_code}: {resp.text[:200]}",
        auth_method="query_param",
    )


def _test_connector(config: dict, creds: dict, timeout: int) -> TestConnectionResult:
    driver = config.get("driver", "")
    if driver == "snowflake":
        return _test_snowflake(creds, timeout)
    elif driver == "bigquery":
        return _test_bigquery(creds, timeout)
    return TestConnectionResult(
        connected=False, latency_ms=0,
        message=f"Unknown connector driver: {driver}",
        auth_method="connector",
    )


def _test_snowflake(creds: dict, timeout: int) -> TestConnectionResult:
    import socket
    import sys

    try:
        import snowflake.connector  # type: ignore
    except ImportError:
        return TestConnectionResult(
            connected=False, latency_ms=0,
            message=(
                f"snowflake-connector-python not installed in this Python environment. "
                f"Python interpreter: {sys.executable}"
            ),
            auth_method="connector",
        )

    # Normalize credential keys - handle both prefixed and unprefixed formats
    # For SDG Snowflake: sdg_snowflake_account -> account
    # For regular Snowflake: snowflake_account -> account
    normalized = {}
    for key, value in creds.items():
        # Strip quotes/backticks and remove prefixes
        clean_value = str(value).strip().strip("'\"` ") if value else ""
        if key.startswith("sdg_snowflake_"):
            normalized[key.replace("sdg_snowflake_", "")] = clean_value
        elif key.startswith("snowflake_"):
            normalized[key.replace("snowflake_", "")] = clean_value
        else:
            normalized[key] = clean_value

    prev_timeout = socket.getdefaulttimeout()
    socket.setdefaulttimeout(timeout)
    try:
        conn = snowflake.connector.connect(
            account=normalized.get("account", ""),
            user=normalized.get("user", ""),
            password=normalized.get("password", ""),
            warehouse=normalized.get("warehouse", ""),
            database=normalized.get("database", ""),
            schema=normalized.get("schema", "PUBLIC"),
            role=normalized.get("role", ""),
            login_timeout=timeout,
            network_timeout=timeout,
        )
        cur = conn.cursor()
        cur.execute("SELECT CURRENT_DATABASE(), CURRENT_WAREHOUSE(), CURRENT_ROLE()")
        row = cur.fetchone()
        cur.close()
        conn.close()

        return TestConnectionResult(
            connected=True, latency_ms=0,
            message=f"Connected to Snowflake (DB={row[0]}, WH={row[1]})",
            auth_method="connector",
            server_info={"database": row[0], "warehouse": row[1], "role": row[2]},
        )
    except Exception as exc:
        return TestConnectionResult(
            connected=False, latency_ms=0,
            message=f"Snowflake connection failed: {str(exc)[:200]}",
            auth_method="connector",
        )
    finally:
        socket.setdefaulttimeout(prev_timeout)


def _test_bigquery(creds: dict, timeout: int) -> TestConnectionResult:
    """Test BigQuery connection using service account credentials."""
    import sys
    
    try:
        from google.cloud import bigquery
        from google.oauth2 import service_account
        import json
    except ImportError as e:
        return TestConnectionResult(
            connected=False, latency_ms=0,
            message=(
                f"google-cloud-bigquery not installed in this Python environment. "
                f"Python interpreter: {sys.executable}. "
                f"Install with: pip install google-cloud-bigquery"
            ),
            auth_method="connector",
        )

    # Normalize credential keys - remove bigquery_ prefix and strip quotes
    normalized = {}
    for key, value in creds.items():
        # Strip quotes/backticks from all values
        clean_value = str(value).strip().strip("'\"` ") if value else ""
        if key.startswith("bigquery_"):
            normalized[key.replace("bigquery_", "")] = clean_value
        else:
            normalized[key] = clean_value

    try:
        # Build service account info dict
        service_account_info = {
            "type": normalized.get("type", "service_account"),
            "project_id": normalized.get("project_id", ""),
            "private_key_id": normalized.get("private_key_id", ""),
            "private_key": normalized.get("private_key", "").replace("\\n", "\n"),  # Handle escaped newlines
            "client_email": normalized.get("client_email", ""),
            "client_id": normalized.get("client_id", ""),
            "auth_uri": normalized.get("auth_uri", "https://accounts.google.com/o/oauth2/auth"),
            "token_uri": normalized.get("token_uri", "https://oauth2.googleapis.com/token"),
            "auth_provider_x509_cert_url": normalized.get("auth_provider_x509_cert_url", "https://www.googleapis.com/oauth2/v1/certs"),
            "client_x509_cert_url": normalized.get("client_x509_cert_url", ""),
            "universe_domain": normalized.get("universe_domain", "googleapis.com"),
        }

        # Create credentials from service account info
        credentials = service_account.Credentials.from_service_account_info(service_account_info)
        
        # Create BigQuery client
        project_id = normalized.get("project_id", "")
        client = bigquery.Client(credentials=credentials, project=project_id)
        
        # Test connection with a simple query
        query = "SELECT 1 as test"
        query_job = client.query(query, timeout=timeout)
        result = list(query_job.result(timeout=timeout))
        
        return TestConnectionResult(
            connected=True, latency_ms=0,
            message=f"Connected to BigQuery project: {project_id}",
            auth_method="connector",
            server_info={"project_id": project_id, "client_email": normalized.get("client_email", "")},
        )
    except Exception as exc:
        return TestConnectionResult(
            connected=False, latency_ms=0,
            message=f"BigQuery connection failed: {str(exc)[:300]}",
            auth_method="connector",
        )
