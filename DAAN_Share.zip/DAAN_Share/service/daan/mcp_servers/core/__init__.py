"""Infrastructure modules used by the MCP feature (discovery, validation, runtime provisioning)."""
