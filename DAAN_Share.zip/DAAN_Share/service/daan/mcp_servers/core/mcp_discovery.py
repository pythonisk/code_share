"""MCP Server Discovery Service.

This service handles auto-discovery and introspection of MCP servers from:
- Remote URLs (HTTP/SSE transport)
- npm packages (stdio transport)
- Custom uploaded Python files
"""

import re
import time
from datetime import datetime
from typing import Any
from urllib.parse import urlparse

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from daan.models.mcp_registry import (
    AuthScheme,
    McpDiscoveryLog,
    McpServerRegistry,
    RegistryStatus,
    TransportType,
)


def slugify_server_name(text: str, max_length: int = 100) -> str:
    """Produce a stable, collision-resistant slug for MCP server_name.

    Lowercases, replaces any run of non-alphanumeric chars with a single '-',
    strips leading/trailing '-', and truncates. Empty input returns empty.
    """
    if not text:
        return ""
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", text).strip("-").lower()
    return slug[:max_length]


class McpDiscoveryError(Exception):
    """Base exception for discovery errors."""

    def __init__(self, message: str, error_type: str = "unknown"):
        super().__init__(message)
        self.error_type = error_type


class McpDiscoveryManager:
    """Discovery manager for MCP servers.

    Handles:
    1. Remote URL introspection (HTTP/SSE)
    2. npm package metadata discovery
    3. Custom file upload handling
    4. Capability introspection (tools, resources, prompts)
    5. Registry persistence and logging
    """

    MCP_PROTOCOL_VERSION = "2024-11-05"
    DEFAULT_TIMEOUT = 30.0

    def __init__(self, db: AsyncSession):
        """Initialize discovery service.

        Args:
            db: Database session for persisting results
        """
        self.db = db
        import ssl
        ssl_ctx = ssl.create_default_context()
        self.http_client = httpx.AsyncClient(
            timeout=self.DEFAULT_TIMEOUT,
            follow_redirects=True,
            verify=ssl_ctx,
        )

    async def close(self):
        """Close HTTP client connections."""
        await self.http_client.aclose()

    async def discover_from_url(
        self,
        url: str,
        user_id: int,
        test_credentials: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Discover MCP server from remote URL.

        Args:
            url: Remote MCP server endpoint URL
            user_id: User ID initiating discovery
            test_credentials: Optional credentials for authentication testing

        Returns:
            Discovery result dictionary with server metadata and capabilities

        Raises:
            McpDiscoveryError: If discovery fails
        """
        start_time = time.time()
        log_data = {
            "user_id": user_id,
            "input_url": url,
            "discovery_method": "url_introspection",
            "success": False,
        }

        try:
            # Validate URL format
            parsed = urlparse(url)
            if not parsed.scheme or not parsed.netloc:
                raise McpDiscoveryError("Invalid URL format", "validation_error")

            if parsed.scheme not in ("http", "https"):
                raise McpDiscoveryError(
                    "Only HTTP/HTTPS URLs supported", "validation_error"
                )

            # Prepare headers with optional credentials
            headers = {"Content-Type": "application/json"}
            if test_credentials:
                headers.update(self._build_auth_headers(test_credentials))

            # Step 1: Send MCP 'initialize' request
            init_response = await self._send_mcp_request(
                url=url,
                method="initialize",
                params={
                    "protocolVersion": self.MCP_PROTOCOL_VERSION,
                    "capabilities": {},
                    "clientInfo": {
                        "name": "DAAN6-Discovery",
                        "version": "1.0.0",
                    },
                },
                headers=headers,
            )

            server_info = init_response.get("result", {}).get("serverInfo", {})
            server_name = server_info.get("name", self._generate_server_name(url))
            display_name = server_info.get("name", server_name)

            # Step 2: Detect authentication scheme
            auth_scheme = self._detect_auth_scheme(
                init_response.get("_response_headers", {}), test_credentials
            )

            # Step 3: Introspect capabilities
            tools = await self._list_tools(url, headers)
            resources = await self._list_resources(url, headers)
            prompts = await self._list_prompts(url, headers)

            # Step 4: Build discovery result
            result = {
                "server_name": server_name,
                "display_name": display_name,
                "description": server_info.get("description"),
                "transport": TransportType.HTTP.value,
                "base_url": url,
                "auth_scheme": auth_scheme.value,
                "available_tools": tools,
                "available_resources": resources,
                "available_prompts": prompts,
                "status": RegistryStatus.VALIDATED.value,
                "discovered_from": url,
                "discovery_method": "url_introspection",
                "last_introspection_at": datetime.utcnow(),
            }

            # Log success
            log_data.update(
                {
                    "success": True,
                    "server_name": server_name,
                    "response_data": {
                        "server_info": server_info,
                        "tools_count": len(tools or []),
                        "resources_count": len(resources or []),
                        "prompts_count": len(prompts or []),
                    },
                    "duration_ms": int((time.time() - start_time) * 1000),
                }
            )

            return result

        except McpDiscoveryError:
            raise
        except httpx.TimeoutException as e:
            raise McpDiscoveryError(f"Connection timeout: {e}", "timeout") from e
        except httpx.ConnectError as e:
            raise McpDiscoveryError(f"Connection failed: {e}", "connection_error") from e
        except httpx.HTTPStatusError as e:
            raise McpDiscoveryError(
                f"HTTP error {e.response.status_code}", "http_error"
            ) from e
        except Exception as e:
            raise McpDiscoveryError(f"Discovery failed: {e}", "unknown") from e
        finally:
            # Always log the attempt
            await self._log_discovery_attempt(log_data)

    async def discover_from_npm_package(
        self,
        package_name: str,
        user_id: int,
    ) -> dict[str, Any]:
        """Discover MCP server from npm package.

        Args:
            package_name: npm package identifier (e.g., '@modelcontextprotocol/server-postgres')
            user_id: User ID initiating discovery

        Returns:
            Discovery result dictionary with package metadata

        Raises:
            McpDiscoveryError: If discovery fails
        """
        start_time = time.time()
        log_data = {
            "user_id": user_id,
            "input_package": package_name,
            "discovery_method": "npm_registry",
            "success": False,
        }

        try:
            # Query npm registry API
            registry_url = f"https://registry.npmjs.org/{package_name}"
            response = await self.http_client.get(registry_url)
            response.raise_for_status()

            package_data = response.json()

            # Extract metadata
            latest_version = package_data.get("dist-tags", {}).get("latest", "")
            version_data = package_data.get("versions", {}).get(latest_version, {})

            server_name = package_name.split("/")[-1]  # Remove scope prefix
            # Collision-resistant slug from FULL package name (e.g. @azure-devops/mcp -> azure-devops-mcp).
            server_name = slugify_server_name(package_name) or server_name
            display_name = version_data.get("description", server_name)
            description = version_data.get("description")
            homepage = package_data.get("homepage")
            repository = package_data.get("repository", {})
            if isinstance(repository, dict):
                repository_url = repository.get("url", "")
            else:
                repository_url = str(repository)

            # Detect transport type (npx is most common for MCP servers)
            transport = TransportType.STDIO
            command = "npx"
            args = [package_name]

            # Build discovery result
            result = {
                "server_name": server_name,
                "display_name": display_name,
                "description": description,
                "transport": transport.value,
                "npm_package": package_name,
                "command": command,
                "args": args,
                "auth_scheme": AuthScheme.NONE.value,
                "documentation_url": repository_url,
                "homepage_url": homepage,
                "status": RegistryStatus.DISCOVERED.value,
                "discovered_from": package_name,
                "discovery_method": "npm_registry",
            }

            # Log success
            log_data.update(
                {
                    "success": True,
                    "server_name": server_name,
                    "response_data": {
                        "package": package_name,
                        "version": latest_version,
                        "description": description,
                    },
                    "duration_ms": int((time.time() - start_time) * 1000),
                }
            )

            return result

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                raise McpDiscoveryError(
                    f"Package '{package_name}' not found in npm registry",
                    "not_found",
                ) from e
            raise McpDiscoveryError(
                f"npm registry error: {e.response.status_code}", "npm_error"
            ) from e
        except Exception as e:
            raise McpDiscoveryError(
                f"npm discovery failed: {e}", "unknown"
            ) from e
        finally:
            await self._log_discovery_attempt(log_data)

    async def register_custom_file_server(
        self,
        file_content: bytes,
        server_name: str,
        user_id: int,
        description: str | None = None,
        env_vars: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Register custom Python file as MCP server.

        Args:
            file_content: Uploaded Python file content
            server_name: User-provided server name
            user_id: User ID initiating registration
            description: Optional server description
            env_vars: Optional environment variables

        Returns:
            Discovery result dictionary

        Raises:
            McpDiscoveryError: If file validation fails
        """
        start_time = time.time()
        log_data = {
            "user_id": user_id,
            "input_file_name": f"{server_name}.py",
            "discovery_method": "file_upload",
            "success": False,
        }

        try:
            # Basic validation: check if file contains MCP server code
            file_text = file_content.decode("utf-8")
            if "mcp" not in file_text.lower() and "server" not in file_text.lower():
                raise McpDiscoveryError(
                    "File does not appear to be an MCP server",
                    "validation_error",
                )

            # Sanitize server name
            clean_name = re.sub(r"[^a-zA-Z0-9_-]", "_", server_name)

            # Build discovery result
            result = {
                "server_name": clean_name,
                "display_name": server_name,
                "description": description or "Custom uploaded MCP server",
                "transport": TransportType.STDIO.value,
                "command": "python",
                "args": [f"{clean_name}.py"],
                "env_vars": env_vars,
                "auth_scheme": AuthScheme.NONE.value,
                "status": RegistryStatus.DISCOVERED.value,
                "discovered_from": "file_upload",
                "discovery_method": "file_upload",
                "file_content": file_text,  # Store for later use
            }

            # Log success
            log_data.update(
                {
                    "success": True,
                    "server_name": clean_name,
                    "response_data": {"file_size": len(file_content)},
                    "duration_ms": int((time.time() - start_time) * 1000),
                }
            )

            return result

        except UnicodeDecodeError as e:
            raise McpDiscoveryError(
                "File must be valid UTF-8 text", "validation_error"
            ) from e
        except Exception as e:
            raise McpDiscoveryError(
                f"File registration failed: {e}", "unknown"
            ) from e
        finally:
            await self._log_discovery_attempt(log_data)

    async def save_to_registry(
        self,
        discovery_result: dict[str, Any],
        user_id: int,
        is_global: bool = False,
    ) -> McpServerRegistry:
        """Save discovered server to registry.

        Args:
            discovery_result: Discovery result from discover_* methods
            user_id: User ID creating the registry entry
            is_global: Whether server should be globally accessible

        Returns:
            Created or updated McpServerRegistry entry

        Raises:
            ValueError: If discovery result is invalid
        """
        server_name = discovery_result.get("server_name")
        if not server_name:
            raise ValueError("server_name is required in discovery result")

        # Block collisions with YAML-defined servers and with globals owned by other users.
        # A user's own row with the same name is fine — it will be updated below.
        try:
            from daan.mcp_servers.core.credential_validator import get_credential_validator

            yaml_names = set(get_credential_validator().list_servers() or [])
        except Exception:
            yaml_names = set()

        if server_name in yaml_names:
            raise McpDiscoveryError(
                f"A built-in MCP server named '{server_name}' already exists. "
                "Pick a different display name.",
                "conflict",
            )

        global_stmt = select(McpServerRegistry).where(
            McpServerRegistry.server_name == server_name,
            McpServerRegistry.is_global == True,  # noqa: E712
            McpServerRegistry.created_by_user_id != user_id,
        )
        global_result = await self.db.execute(global_stmt)
        colliding_global = global_result.scalar_one_or_none()
        if colliding_global is not None:
            raise McpDiscoveryError(
                f"A global MCP server named '{server_name}' already exists. "
                "Pick a different display name.",
                "conflict",
            )

        # Check if server already exists for this user
        stmt = select(McpServerRegistry).where(
            McpServerRegistry.server_name == server_name,
            McpServerRegistry.created_by_user_id == user_id,
        )
        result = await self.db.execute(stmt)
        existing = result.scalar_one_or_none()

        if existing:
            # Update existing entry
            for key, value in discovery_result.items():
                if hasattr(existing, key) and key != "id":
                    setattr(existing, key, value)
            existing.updated_at = datetime.utcnow()
            registry_entry = existing
        else:
            # Create new entry
            registry_entry = McpServerRegistry(
                server_name=server_name,
                display_name=discovery_result.get("display_name", server_name),
                description=discovery_result.get("description"),
                transport=TransportType(discovery_result["transport"]),
                base_url=discovery_result.get("base_url"),
                npm_package=discovery_result.get("npm_package"),
                command=discovery_result.get("command"),
                args=discovery_result.get("args"),
                env_vars=discovery_result.get("env_vars"),
                auth_scheme=AuthScheme(
                    discovery_result.get("auth_scheme", AuthScheme.NONE.value)
                ),
                required_credentials=discovery_result.get("required_credentials"),
                available_tools=discovery_result.get("available_tools"),
                available_resources=discovery_result.get("available_resources"),
                available_prompts=discovery_result.get("available_prompts"),
                category=discovery_result.get("category"),
                icon_url=discovery_result.get("icon_url"),
                documentation_url=discovery_result.get("documentation_url"),
                homepage_url=discovery_result.get("homepage_url"),
                status=RegistryStatus(
                    discovery_result.get("status", RegistryStatus.DISCOVERED.value)
                ),
                is_global=is_global,
                is_public=discovery_result.get("is_public", False),
                created_by_user_id=user_id,
                discovered_from=discovery_result.get("discovered_from"),
                discovery_method=discovery_result.get("discovery_method"),
                last_introspection_at=discovery_result.get("last_introspection_at"),
            )
            self.db.add(registry_entry)

        await self.db.commit()
        await self.db.refresh(registry_entry)
        return registry_entry

    async def _send_mcp_request(
        self,
        url: str,
        method: str,
        params: dict[str, Any],
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Send JSON-RPC request to MCP server.

        Args:
            url: Server endpoint URL
            method: MCP method name (e.g., 'initialize', 'tools/list')
            params: Method parameters
            headers: Optional HTTP headers

        Returns:
            JSON-RPC response

        Raises:
            httpx.HTTPError: On HTTP errors
            ValueError: On invalid JSON-RPC response
        """
        request_payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params,
        }

        response = await self.http_client.post(
            url, json=request_payload, headers=headers or {}
        )
        response.raise_for_status()

        response_data = response.json()

        # Check for JSON-RPC error
        if "error" in response_data:
            error = response_data["error"]
            raise ValueError(
                f"MCP error {error.get('code')}: {error.get('message')}"
            )

        # Attach response headers for auth detection
        response_data["_response_headers"] = dict(response.headers)

        return response_data

    async def _list_tools(
        self, url: str, headers: dict[str, str]
    ) -> list[dict[str, Any]] | None:
        """List available tools from MCP server."""
        try:
            response = await self._send_mcp_request(
                url, "tools/list", {}, headers
            )
            tools = response.get("result", {}).get("tools", [])
            return [
                {
                    "name": tool.get("name"),
                    "description": tool.get("description"),
                    "inputSchema": tool.get("inputSchema"),
                }
                for tool in tools
            ]
        except Exception:
            return None

    async def _list_resources(
        self, url: str, headers: dict[str, str]
    ) -> list[dict[str, Any]] | None:
        """List available resources from MCP server."""
        try:
            response = await self._send_mcp_request(
                url, "resources/list", {}, headers
            )
            resources = response.get("result", {}).get("resources", [])
            return [
                {
                    "uri": resource.get("uri"),
                    "name": resource.get("name"),
                    "description": resource.get("description"),
                    "mimeType": resource.get("mimeType"),
                }
                for resource in resources
            ]
        except Exception:
            return None

    async def _list_prompts(
        self, url: str, headers: dict[str, str]
    ) -> list[dict[str, Any]] | None:
        """List available prompts from MCP server."""
        try:
            response = await self._send_mcp_request(
                url, "prompts/list", {}, headers
            )
            prompts = response.get("result", {}).get("prompts", [])
            return [
                {
                    "name": prompt.get("name"),
                    "description": prompt.get("description"),
                    "arguments": prompt.get("arguments"),
                }
                for prompt in prompts
            ]
        except Exception:
            return None

    def _build_auth_headers(
        self, credentials: dict[str, Any]
    ) -> dict[str, str]:
        """Build HTTP auth headers from test credentials."""
        headers: dict[str, str] = {}

        if "bearer_token" in credentials:
            headers["Authorization"] = f"Bearer {credentials['bearer_token']}"
        elif "api_key" in credentials:
            headers["X-API-Key"] = credentials["api_key"]
        elif "username" in credentials and "password" in credentials:
            import base64

            auth_str = f"{credentials['username']}:{credentials['password']}"
            encoded = base64.b64encode(auth_str.encode()).decode()
            headers["Authorization"] = f"Basic {encoded}"
        elif "header_name" in credentials and "header_value" in credentials:
            headers[credentials["header_name"]] = credentials["header_value"]

        return headers

    def _detect_auth_scheme(
        self,
        response_headers: dict[str, str],
        test_credentials: dict[str, Any] | None,
    ) -> AuthScheme:
        """Detect auth scheme from response headers or provided credentials."""
        if test_credentials:
            if "bearer_token" in test_credentials:
                return AuthScheme.BEARER
            if "api_key" in test_credentials:
                return AuthScheme.API_KEY
            if "username" in test_credentials:
                return AuthScheme.BASIC
            if "header_name" in test_credentials:
                return AuthScheme.CUSTOM_HEADER

        auth_header = response_headers.get("www-authenticate", "").lower()
        if "bearer" in auth_header:
            return AuthScheme.BEARER
        if "basic" in auth_header:
            return AuthScheme.BASIC

        return AuthScheme.NONE

    def _generate_server_name(self, url: str) -> str:
        """Generate unique server name from URL."""
        parsed = urlparse(url)
        base = parsed.netloc.replace(".", "-")
        path = parsed.path.strip("/").replace("/", "-")
        if path:
            base = f"{base}-{path}"
        return slugify_server_name(base)

    async def _log_discovery_attempt(self, log_data: dict[str, Any]):
        """Persist discovery attempt to audit log."""
        try:
            log_entry = McpDiscoveryLog(
                user_id=log_data.get("user_id"),
                server_name=log_data.get("server_name"),
                input_url=log_data.get("input_url"),
                input_package=log_data.get("input_package"),
                input_file_name=log_data.get("input_file_name"),
                discovery_method=log_data.get("discovery_method"),
                success=log_data.get("success", False),
                error_message=log_data.get("error_message"),
                error_type=log_data.get("error_type"),
                response_data=log_data.get("response_data"),
                duration_ms=log_data.get("duration_ms"),
            )
            self.db.add(log_entry)
            await self.db.commit()
        except Exception:
            await self.db.rollback()
