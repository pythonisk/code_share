"""Shared MCP authentication helpers.

Single source of truth for turning decrypted credentials into HTTP/SSE auth
headers. Reused by the runtime toolset provider, the test-connection endpoint,
and the discovery service so header behavior stays consistent everywhere.
"""

from __future__ import annotations

import base64
from typing import Any

# Credential dict keys that may hold a bearer/api token, in priority order.
_TOKEN_KEYS = ("access_token", "api_key", "bearer_token", "token")


def _clean(value: Any) -> Any:
    """Strip surrounding quotes/backticks/whitespace from string credential values."""
    if isinstance(value, str):
        return value.strip().strip("'\"` ")
    return value


def extract_token(credentials: dict[str, Any]) -> str | None:
    """Return the first non-empty token-like value from a credentials dict."""
    for key in _TOKEN_KEYS:
        value = _clean(credentials.get(key))
        if value:
            return str(value)
    return None


def build_auth_headers(
    auth_scheme: str | None,
    credentials: dict[str, Any] | None,
) -> dict[str, str]:
    """Build HTTP/SSE auth headers for a remote MCP server.

    Args:
        auth_scheme: One of none/bearer/api_key/basic/oauth/oauth2/custom.
        credentials: Decrypted credentials dict (from CredentialResolver.resolve()).

    Returns:
        Header dict (possibly empty) to attach to the MCP connection.
    """
    creds = {k: _clean(v) for k, v in (credentials or {}).items()}
    scheme = str(auth_scheme or "none").strip().lower()
    headers: dict[str, str] = {}

    if scheme in ("bearer", "oauth", "oauth2"):
        token = extract_token(creds)
        if token:
            headers["Authorization"] = f"Bearer {token}"
    elif scheme == "api_key":
        token = extract_token(creds)
        if token:
            headers["X-API-Key"] = token
    elif scheme == "basic":
        username = creds.get("username")
        if username:
            password = creds.get("password", "")
            encoded = base64.b64encode(f"{username}:{password}".encode()).decode()
            headers["Authorization"] = f"Basic {encoded}"
    elif scheme in ("custom", "custom_header"):
        header_name = creds.get("header_name")
        header_value = creds.get("header_value")
        if header_name and header_value:
            headers[str(header_name)] = str(header_value)

    return headers
