"""Context Mapper — context extraction for use case agents."""

import logging
from daan.agents.core.context_mapper import context_map as _context_map

logger = logging.getLogger(__name__)


class ContextMapper:
    """Delegates to context_mapper module."""

    @staticmethod
    def run(agents: list, usecase_details: dict = None, session_id: str = "") -> list:
        logger.info("Planner Agent generating context", extra={
            "session_id": session_id, 
            "agent_count": len(agents or []), 
            "has_usecase_details": bool(usecase_details)
        })
        
        result = ContextMapper.run_detailed(
            agents=agents,
            usecase_details=usecase_details,
            session_id=session_id,
        )
        
        logger.info("Context mapping completed", extra={
            "session_id": session_id, 
            "mapped_agents": len(result["agents"])
        })
        return result["agents"]

    @staticmethod
    def run_detailed(agents: list, usecase_details: dict = None, session_id: str = "", uploaded_file_count: int = None) -> dict:
        logger.debug("Detailed context mapping started", extra={
            "session_id": session_id, 
            "agent_count": len(agents or []), 
            "usecase_provided": bool(usecase_details)
        })
        
        result = _context_map(
            usecase_details=usecase_details or {},
            agents=agents,
            session_id=session_id,
            uploaded_file_count=uploaded_file_count,
        )
        
        logger.debug("Detailed context mapping completed", extra={
            "session_id": session_id, 
            "result_keys": list(result.keys()) if result else [],
            "agents_processed": len(result.get("agents", []) if result else [])
        })
        return result


# Backward-compatible alias
PlannerAgent = ContextMapper