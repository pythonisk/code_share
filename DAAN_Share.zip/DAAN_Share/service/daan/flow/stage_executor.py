"""Generic, domain-agnostic stage executor.

Runs a workflow one stage at a time. Stage order and execution mode come from
the use case ``dag`` string; each agent's input is assembled from the outputs of
the agents it declares in ``depends_on``. The executor makes no assumptions about
agent type, integration, or output format — an agent's output is opaque text.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from daan.agents.dag_validator import parse_dag_stages
from daan.flow.dynamic_flow_builder.dynamic_adk_flow import _parse_depends_on

logger = logging.getLogger(__name__)


# ── Planning ────────────────────────────────────────────────────────────

def build_stage_plan(agents: list[dict[str, Any]], dag_str: str) -> list[dict[str, Any]]:
    """Return ordered stage descriptors from the dag string.

    Each descriptor is ``{"type", "agents", "loop_agents"}``. When no dag is
    provided, every agent becomes its own sequential stage in listed order.
    """
    agent_ids = [
        str(a.get("agent_id") or "").strip()
        for a in agents
        if str(a.get("agent_id") or "").strip()
    ]
    known = set(agent_ids)

    stages = parse_dag_stages(dag_str) if dag_str else []
    if not stages:
        return [{"type": "sequential", "agents": [aid], "loop_agents": []} for aid in agent_ids]

    plan: list[dict[str, Any]] = []
    for stage in stages:
        stage_agents = [aid for aid in stage.get("agents", []) if aid in known]
        if not stage_agents:
            continue
        plan.append({
            "type": str(stage.get("type") or "sequential"),
            "agents": stage_agents,
            "loop_agents": [aid for aid in stage.get("loop_agents", []) if aid in known],
        })
    return plan


def next_pending_stage(
    plan: list[dict[str, Any]],
    completed_ids: set[str],
) -> tuple[int, dict[str, Any]] | tuple[None, None]:
    """Return ``(index, stage)`` of the first stage with any un-run agent."""
    for index, stage in enumerate(plan):
        if any(aid not in completed_ids for aid in stage["agents"]):
            return index, stage
    return None, None


def has_more_stages(plan: list[dict[str, Any]], completed_ids: set[str]) -> bool:
    index, _ = next_pending_stage(plan, completed_ids)
    return index is not None


# ── Input assembly ──────────────────────────────────────────────────────

def build_agent_input(agent_cfg: dict[str, Any], outputs_by_id: dict[str, str]) -> str:
    """Assemble one agent's input from its ``depends_on`` parents' outputs.

    Parent outputs are concatenated as clearly labelled plain-text sections. When
    the agent declares no parents, its own mapped ``context`` is used (which is
    empty when the run has no uploaded input — the agent then sources its own data
    via its tools).
    """
    parts: list[str] = []
    for dep in _parse_depends_on(agent_cfg.get("depends_on") or agent_cfg.get("depend_on")):
        text = str((outputs_by_id or {}).get(dep) or "").strip()
        if text:
            parts.append(f"### Output from {dep}\n{text}")
    if parts:
        return "\n\n".join(parts)
    return str(agent_cfg.get("context") or "").strip()


def split_into_items(text: str) -> list[Any]:
    """Split an agent's input into loop items, tolerant of format.

    JSON array → its elements; ``---``-separated blocks → those blocks; otherwise
    the whole text is treated as a single item. Never requires JSON.
    """
    raw = str(text or "").strip()
    if not raw:
        return []
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, list):
            return parsed
    except (json.JSONDecodeError, ValueError):
        pass
    if "\n\n---\n\n" in raw:
        return [seg.strip() for seg in raw.split("\n\n---\n\n") if seg.strip()]
    return [raw]


def _parent_outputs(agent_cfg: dict[str, Any], outputs_by_id: dict[str, str]) -> dict[str, str]:
    """Return the subset of prior outputs this agent declares in ``depends_on``."""
    result: dict[str, str] = {}
    for dep in _parse_depends_on(agent_cfg.get("depends_on") or agent_cfg.get("depend_on")):
        text = str((outputs_by_id or {}).get(dep) or "").strip()
        if text:
            result[dep] = text
    return result


def _agent_can_self_fetch(agent_cfg: dict[str, Any]) -> bool:
    """True when the agent has a tool it can page through with offset/limit."""
    for key in ("local_tools", "mcp_tools", "mcp_servers"):
        value = agent_cfg.get(key)
        if isinstance(value, list) and any(str(v).strip() for v in value):
            return True
        if isinstance(value, str) and value.strip() and value.strip() != "[]":
            return True
    return False


# ── Execution of a single stage ─────────────────────────────────────────

async def run_stage_async(
    *,
    session_id: str,
    stage: dict[str, Any],
    agents_by_id: dict[str, dict[str, Any]],
    outputs_by_id: dict[str, str],
    mcp_by_agent: dict[str, Any] | None,
    batch_size: int,
    credential_resolver: Any = None,
) -> tuple[dict[str, str], dict[str, dict[str, int]], dict[str, str], dict[str, str], list[tuple[str, BaseException]]]:
    """Run every agent in one stage concurrently and collect their outputs.

    Action agents are delegated to the existing action runner (structured payload,
    idempotency and publish reconciliation preserved), fed by their ``depends_on``
    parents' outputs. Loop agents batch over their assembled input when present,
    otherwise fetch via their tools. Every other agent runs once. Returns per-agent
    outputs/usage/model/provider plus ``(agent_id, exception)`` for any failures.
    """
    from daan.agents.agent_type_utils import is_action_agent
    from daan.flow.agent_runner import _run_pipeline_async, run_action_agents_async
    from daan.flow.loop_runner import _run_single_agent_loop

    stage_type = str(stage.get("type") or "sequential")
    loop_ids = {str(a).strip() for a in (stage.get("loop_agents") or []) if str(a).strip()}

    def _is_loop(agent_id: str) -> bool:
        return stage_type in ("loop", "parallel_loop") or agent_id in loop_ids

    async def _run_one(agent_id: str) -> tuple[str, str, dict[str, int], str, str]:
        cfg = agents_by_id[agent_id]
        mcp = (mcp_by_agent or {}).get(agent_id)

        if is_action_agent(cfg.get("agent_type")):
            outs, usage_by, model_by, provider_by, _msg = await run_action_agents_async(
                [cfg],
                session_id,
                _parent_outputs(cfg, outputs_by_id),
                pre_loaded_mcp_toolsets=mcp,
                credential_resolver=credential_resolver,
            )
            text = str(outs.get(agent_id) or next(iter(outs.values()), "")).strip()
            usage = usage_by.get(agent_id) or next(iter(usage_by.values()), {})
            model_name = model_by.get(agent_id) or next(iter(model_by.values()), "")
            provider_name = provider_by.get(agent_id) or next(iter(provider_by.values()), "")
            return agent_id, text, usage, model_name, provider_name

        input_text = build_agent_input(cfg, outputs_by_id)

        if _is_loop(agent_id):
            items = split_into_items(input_text)
            has_parents = bool(
                _parse_depends_on(cfg.get("depends_on") or cfg.get("depend_on"))
            )
            # A single unsplittable blob is not a real item list. Only an ENTRY
            # loop agent (no upstream parents) with its own tool self-pages via
            # offset/limit; a downstream loop agent keeps slicing its single
            # upstream output exactly as before.
            if len(items) > 1:
                parent_items = items
            elif not has_parents and _agent_can_self_fetch(cfg):
                parent_items = None
            else:
                parent_items = items or None
            rid, text, usage, model_name, provider_name = await _run_single_agent_loop(
                session_id, cfg, mcp, batch_size, parent_items=parent_items,
                credential_resolver=credential_resolver,
            )
            return rid, text, usage, model_name, provider_name

        outputs, usage_by, model_by, provider_by = await _run_pipeline_async(
            agents=[cfg],
            input_message=input_text or "No additional context provided.",
            session_id=f"{session_id}__{agent_id}",
            pipeline_name=f"stage_{agent_id}",
            pre_loaded_mcp_toolsets=mcp,
            data_session_id=session_id,
        )
        text = str(outputs.get(agent_id) or next(iter(outputs.values()), "")).strip()
        usage = usage_by.get(agent_id) or next(iter(usage_by.values()), {})
        model_name = model_by.get(agent_id) or next(iter(model_by.values()), "")
        provider_name = provider_by.get(agent_id) or next(iter(provider_by.values()), "")
        return agent_id, text, usage, model_name, provider_name

    stage_agent_ids = list(stage["agents"])
    results = await asyncio.gather(
        *[_run_one(aid) for aid in stage_agent_ids], return_exceptions=True
    )

    outputs: dict[str, str] = {}
    usage_by_agent: dict[str, dict[str, int]] = {}
    model_by_agent: dict[str, str] = {}
    provider_by_agent: dict[str, str] = {}
    errors: list[tuple[str, BaseException]] = []

    for agent_id, result in zip(stage_agent_ids, results):
        if isinstance(result, BaseException):
            errors.append((agent_id, result))
            logger.error(
                "Stage agent %s failed: %s",
                agent_id, result,
                extra={"session_id": session_id, "agent_id": agent_id},
            )
            continue
        rid, text, usage, model_name, provider_name = result
        outputs[rid] = text
        usage_by_agent[rid] = {
            "prompt_tokens": int((usage or {}).get("prompt_tokens") or 0),
            "completion_tokens": int((usage or {}).get("completion_tokens") or 0),
            "total_tokens": int((usage or {}).get("total_tokens") or 0),
        }
        if model_name:
            model_by_agent[rid] = model_name
        if provider_name:
            provider_by_agent[rid] = provider_name

    return outputs, usage_by_agent, model_by_agent, provider_by_agent, errors
