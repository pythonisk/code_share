"""
Module-level ContextVars for request-scoped data.

Using Python's contextvars makes data accessible to deeply nested
callees (e.g. native tool functions) without threading them through
every function signature.  Each asyncio Task and each thread gets its
own context, so concurrent requests cannot bleed into each other.
"""

from contextvars import ContextVar

# Set to the active DAAN session UUID before running any ADK pipeline.
# Tools such as SyntheticDataTool read this to locate session storage.
daan_session_id: ContextVar[str | None] = ContextVar("daan_session_id", default=None)

# Set to the id of the authenticated user driving the current request. Read when
# building LiteLLM tags so every LLM call is attributable to a user.
daan_user_id: ContextVar[str | None] = ContextVar("daan_user_id", default=None)


def set_daan_user_id(user_id: object) -> None:
    """Set the current-request user id (stringified) for the active context."""
    daan_user_id.set(str(user_id) if user_id not in (None, "") else None)


def get_daan_user_id() -> str | None:
    """Return the current-request user id, or None when unauthenticated."""
    return daan_user_id.get()
