"""Batch loop execution for a single agent, used by the stage executor.

Two loop modes per agent, chosen by the executor from the agent's input:

- **Input-driven mode** (``parent_items`` provided): the runner slices the items
  into batches of ``batch_size`` and injects each slice directly. Terminates when
  all items are processed.
- **Fetch mode** (``parent_items`` is None): the runner injects
  ``batch_offset``/``batch_size`` and the agent fetches its own data via its MCP
  tool. Terminates when the agent responds with ``NO_MORE_DATA`` (or an empty
  list).

An agent can switch itself into input-driven mode mid-loop by emitting
``YIELD_BATCHES:<json_array>`` on any iteration.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

_MAX_ITERATIONS = 100
_TERMINATION_SIGNAL = "NO_MORE_DATA"
_ACCEPTED_TERMINATION_SIGNALS = frozenset({_TERMINATION_SIGNAL})
_YIELD_BATCHES_SIGNAL = "YIELD_BATCHES:"
_MAX_ITERATION_RETRIES = 1


def _is_mcp_tool_failure(exc: BaseException) -> bool:
    """Return True if the exception indicates MCP tool or session failure."""
    from daan.flow.agent_runner import _is_mcp_tool_failure as _check_mcp_failure
    return _check_mcp_failure(exc)


def _agent_has_mcp_tools(agent_config: dict[str, Any]) -> bool:
    raw = agent_config.get("mcp_tools") or agent_config.get("mcp_server") or agent_config.get("mcp_servers") or ""
    if isinstance(raw, list):
        return any(str(s).strip() for s in raw)
    return bool(str(raw).strip().strip("[]"))


async def _fresh_mcp_toolsets(
    agent_config: dict[str, Any],
    session_id: str,
    credential_resolver: Any,
) -> dict[str, Any] | None:
    """Build a fresh MCP toolset for one loop iteration.

    ADK closes stdio subprocess sessions when a pipeline run ends, so every
    iteration needs its own toolset. Delegates to the shared async initializer
    used by the action-agent path (with fallback-server resolution).
    """
    if not credential_resolver or not _agent_has_mcp_tools(agent_config):
        return None
    try:
        from daan.mcp_servers.core.mcp_toolset_provider import initialize_mcp_for_agents
        return await initialize_mcp_for_agents(
            [agent_config],
            session_id=session_id,
            credential_resolver=credential_resolver,
        )
    except Exception as exc:
        agent_id = str(agent_config.get("agent_id") or agent_config.get("agent_name") or "unknown")
        logger.warning(
            "Fresh MCP init failed for loop agent %s: %s",
            agent_id, exc,
            extra={"session_id": session_id, "agent_id": agent_id},
        )
        return None


def _safe_sid(value: str) -> str:
    return re.sub(r"\W+", "_", value or "agent")


def _is_exact_termination_signal(text: str) -> bool:
    normalized = text.strip()
    if normalized.upper() in _ACCEPTED_TERMINATION_SIGNALS:
        return True
    # An empty JSON array means no more data — treat it as termination in MCP mode
    return normalized == "[]"


def _is_valid_json_array(text: str) -> bool:
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return False
    return isinstance(parsed, list)


async def _run_single_agent_loop(
    session_id: str,
    agent_config: dict[str, Any],
    pre_loaded_mcp_toolsets: dict[str, Any] | None,
    batch_size: int,
    parent_items: list | None = None,
    credential_resolver: Any = None,
) -> tuple[str, str, dict[str, int], str, str]:
    """Run one agent through all batches, returning (agent_id, merged_output).

    Supports two modes:
    - MCP mode (``parent_items`` is None): injects batch_offset/batch_size each
      iteration; agent uses its MCP tool to fetch data.  Terminates on
            ``NO_MORE_DATA``. The legacy token ``NO_MORE_INCIDENTS`` is also
            accepted.
    - Input-driven mode (``parent_items`` provided): slices the list each
      iteration and injects the slice directly.  Terminates when slice is empty.

    Either mode can be switched to input-driven mid-loop via ``YIELD_BATCHES:``.

    Args:
        session_id:             Parent DAAN workflow session ID.
        agent_config:           Agent config dict.
        pre_loaded_mcp_toolsets: Pre-initialised MCP toolsets.
        batch_size:             Number of items per iteration.
        parent_items:           Optional pre-fetched item list to slice (input-driven mode).

    Returns:
        Tuple of ``(agent_id, merged_text, usage_totals, model_name, provider_name)``
        where ``merged_text`` is all iteration outputs joined by a separator.
    """
    from daan.flow.agent_runner import _run_pipeline_async  # noqa: PLC0415

    agent_id = str(agent_config.get("agent_id") or agent_config.get("agent_name") or "unknown")
    safe_id = _safe_sid(agent_id)
    accumulated: list[str] = []
    batch_offset = 0
    usage_totals = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    model_name = ""
    provider_name = ""

    for iteration in range(_MAX_ITERATIONS):
        adk_session_id = f"{session_id}__{safe_id}__i{iteration}"

        # ── Build input message ────────────────────────────────────────────
        if parent_items is not None:
            batch = parent_items[batch_offset : batch_offset + batch_size]
            if not batch:
                logger.info(
                    "Agent %s input-driven loop completed: all %d items processed",
                    agent_id,
                    len(parent_items),
                    extra={"session_id": session_id, "agent_id": agent_id},
                )
                break
            input_message = (
                f"Process the following batch of {len(batch)} item(s):\n"
                f"{json.dumps(batch, ensure_ascii=False)}"
            )
        else:
            input_message = (
                f"Batch parameters: batch_offset={batch_offset}, batch_size={batch_size}.\n"
                f"Use your MCP tool with offset={batch_offset} and limit={batch_size} to fetch the next batch.\n"
                f"If the tool returns an empty list (no data returned), respond ONLY with exactly: {_TERMINATION_SIGNAL}"
            )

        outputs = None
        iteration_usage_by_agent: dict[str, dict[str, int]] = {}
        iteration_model_by_agent: dict[str, str] = {}
        iteration_provider_by_agent: dict[str, str] = {}

        # ADK closes stdio MCP subprocesses at the end of each pipeline run, so
        # every iteration needs its own toolset when a resolver is available.
        # Falls back to the caller-supplied toolset only on the first iteration.
        toolsets_for_attempt = await _fresh_mcp_toolsets(agent_config, session_id, credential_resolver)
        if toolsets_for_attempt is None:
            toolsets_for_attempt = pre_loaded_mcp_toolsets

        for attempt in range(_MAX_ITERATION_RETRIES + 1):
            try:
                outputs, iteration_usage_by_agent, iteration_model_by_agent, iteration_provider_by_agent = await _run_pipeline_async(
                    agents=[agent_config],
                    input_message=input_message,
                    session_id=adk_session_id,
                    pipeline_name=f"{safe_id}_loop_iter{iteration}",
                    pre_loaded_mcp_toolsets=toolsets_for_attempt,
                    data_session_id=session_id,
                )
                break
            except Exception as exc:
                if attempt < _MAX_ITERATION_RETRIES and _is_mcp_tool_failure(exc):
                    logger.info(
                        "MCP failure at agent %s iteration %d, retrying with fresh toolset: %s",
                        agent_id, iteration, exc,
                        extra={"session_id": session_id, "agent_id": agent_id, "iteration": iteration},
                    )
                    retry_toolsets = await _fresh_mcp_toolsets(agent_config, session_id, credential_resolver)
                    if retry_toolsets:
                        toolsets_for_attempt = retry_toolsets
                        continue
                raise RuntimeError(
                    f"Loop agent '{agent_id}' failed at iteration {iteration}: {exc}"
                ) from exc

        if outputs is None:
            raise RuntimeError(
                f"Loop agent '{agent_id}' did not return outputs at iteration {iteration}."
            )

        iteration_usage = iteration_usage_by_agent.get(agent_id) or next(iter(iteration_usage_by_agent.values()), {})
        usage_totals["prompt_tokens"] += int((iteration_usage or {}).get("prompt_tokens") or 0)
        usage_totals["completion_tokens"] += int((iteration_usage or {}).get("completion_tokens") or 0)
        usage_totals["total_tokens"] += int((iteration_usage or {}).get("total_tokens") or 0)
        model_name = iteration_model_by_agent.get(agent_id) or next(iter(iteration_model_by_agent.values()), model_name)
        provider_name = iteration_provider_by_agent.get(agent_id) or next(iter(iteration_provider_by_agent.values()), provider_name)

        text = (outputs.get(agent_id) or "").strip()

        if not text:
            raise RuntimeError(
                f"Loop agent '{agent_id}' returned empty output at iteration {iteration}."
            )

        logger.debug(
            "Agent %s iteration %d output length: %d",
            agent_id,
            iteration,
            len(text),
            extra={"session_id": session_id, "agent_id": agent_id, "iteration": iteration},
        )

        # ── Self-feed detection: agent yields a full array for the runner to slice ──
        if text.startswith(_YIELD_BATCHES_SIGNAL):
            raw = text[len(_YIELD_BATCHES_SIGNAL):].strip()
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, list):
                    parent_items = parsed
                    batch_offset = 0
                    logger.info(
                        "Agent %s yielded %d items; switching to input-driven batch mode",
                        agent_id,
                        len(parent_items),
                        extra={"session_id": session_id, "agent_id": agent_id},
                    )
                    continue
            except json.JSONDecodeError:
                pass
            # Parse failed → fall through and treat as normal output

        # ── Termination signal (MCP mode only) ────────────────────────────
        if parent_items is None and _is_exact_termination_signal(text):
            logger.info(
                "Agent %s MCP loop terminated after %d iterations (batches processed: %d) - received termination signal: '%s'",
                agent_id,
                iteration,
                len(accumulated),
                text[:50],
                extra={"session_id": session_id, "agent_id": agent_id},
            )
            break

        if not _is_valid_json_array(text):
            logger.warning(
                "Agent %s iteration %d returned non-JSON output (length=%d); accumulating as-is.",
                agent_id, iteration, len(text),
                extra={"session_id": session_id, "agent_id": agent_id},
            )

        accumulated.append(text)
        batch_offset += batch_size
        logger.debug(
            "Agent %s completed iteration %d (offset %d → %d)",
            agent_id,
            iteration,
            batch_offset - batch_size,
            batch_offset,
            extra={"session_id": session_id, "agent_id": agent_id},
        )

    merged = "\n\n---\n\n".join(accumulated) if accumulated else ""
    return agent_id, merged, usage_totals, model_name, provider_name
