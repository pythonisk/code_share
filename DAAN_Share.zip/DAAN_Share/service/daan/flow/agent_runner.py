"""Execute ADK agents and collect their text output."""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from pathlib import Path
import re
from typing import Any
import os

from google.adk.runners import InMemoryRunner
from google.adk.agents.run_config import RunConfig, StreamingMode
from daan.mcp_servers.core.adk_mcp_compat import McpToolset
from google.genai import types

from daan.agents.dynamic_builders.dynamic_adk_agent import create_adk_agent
from daan.flow.dynamic_flow_builder.dynamic_adk_flow import create_pipeline_agent
from daan.flow.context_vars import daan_session_id
from daan.flow.session_service import get_artifacts_dir
from daan.llm.cost_tracking import extract_model_provider_from_event, extract_usage_from_event
from daan.utils.azure_devops_work_items import extract_azure_devops_work_items
from daan.core.observers.reasoning_observer import get_bus

logger = logging.getLogger(__name__)

APP_NAME = "daan_workflow"


def _emit_partial_event_to_bus(bus: Any, event: Any, agent_key: str) -> None:
    """Forward a streamed ADK partial event's parts into the reasoning bus.

    Thought parts (Haiku's `enabled` mode surfaces reasoning here) go out as
    `thought` events for live display; function-calls become `action`; plain
    answer text becomes `token` (hidden in the panel).
    """
    try:
        content = getattr(event, "content", None)
        parts = getattr(content, "parts", None) or []
        for part in parts:
            if getattr(part, "thought", False):
                text = getattr(part, "text", "") or ""
                if text:
                    bus.emit("thought", {
                        "agent_id": agent_key,
                        "text": text,
                        "token_count": max(1, len(text) // 4),
                    })
                continue
            fc = getattr(part, "function_call", None)
            if fc is not None:
                bus.emit("action", {
                    "agent_id": agent_key,
                    "tool": str(getattr(fc, "name", "") or ""),
                    "args": getattr(fc, "args", None) or {},
                })
                continue
            text = getattr(part, "text", "") or ""
            if text:
                bus.emit("token", {
                    "agent_id": agent_key,
                    "text": text,
                })
    except Exception as exc:
        logger.debug("Failed to emit partial event to reasoning bus: %s", exc)
_GENERIC_TOOL_RESPONSE_KEYS: frozenset[str] = frozenset({
    "status", "summary", "results", "items", "all_items", "publish_items",
    "feed_results", "run_stats", "incident_id", "success", "error", "data",
    "rows", "total", "total_item_count", "reachable_count", "paywall_count",
    "unreachable_count", "not_modified", "etag", "last_modified", "item_count",
    # Single-record tool-response fields (link excerpt / verification tools).
    "excerpt", "final_url", "url", "reachable", "paywall", "paywalled",
    "redirected", "redirect", "content_hash",
})

# Fields that are standard agent metadata and should NOT be forwarded as
# extra runtime context into the action-agent input payload.
_STANDARD_AGENT_FIELDS: frozenset[str] = frozenset({
    "agent_id", "agent_name", "name", "role", "agent_type", "prompt",
    "instruction", "inputs", "input_context", "output", "output_format",
    "actions", "agent_actions", "output_validators", "guardrails", "mcp_tools", "mcp_server",
    "local_tools", "depends_on", "depend_on", "context", "description", "task",
    "archetype", "usecase", "prompt_file_path", "applied_learning_history",
})
async def _ensure_runner_session(runner: InMemoryRunner, session_id: str) -> None:
    """Ensure the ADK runner has a backing session for the given session_id."""
    try:
        await runner.session_service.create_session(
            app_name=APP_NAME,
            user_id="daan_user",
            session_id=session_id,
        )
    except Exception as exc:
        message = str(exc).lower()
        if "already exists" in message or "duplicate" in message:
            return
        raise

def _collect_extra_context(agents: list[dict[str, Any]]) -> dict[str, Any]:
    """Extract non-standard fields (e.g. credentials) from agent configs."""
    extra: dict[str, Any] = {}
    for agent in agents:
        for k, v in agent.items():
            if k not in _STANDARD_AGENT_FIELDS and v not in (None, "", [], {}):
                extra[k] = v
    return extra


def _parse_mcp_server_names(mcp_tools_raw: Any) -> list[str]:
    """Normalize MCP server references from agent config into server names."""
    if isinstance(mcp_tools_raw, list):
        return [str(s).strip() for s in mcp_tools_raw if str(s).strip()]

    cleaned = str(mcp_tools_raw or "").strip().strip("[]")
    return [s.strip() for s in re.split(r"[,;\s]+", cleaned) if s.strip()]


def _agent_has_mcp_tools(agent_cfg: dict[str, Any]) -> bool:
    return bool(_parse_mcp_server_names(agent_cfg.get("mcp_tools") or agent_cfg.get("mcp_servers") or ""))


def _parse_json_text(value: Any) -> Any:
    if not isinstance(value, str):
        return None
    text = value.strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def _unwrap_embedded_text_payload(value: Any) -> Any:
    """Best-effort unwrap for ADK content-part envelopes and nested JSON text."""
    candidates: list[Any] = [value]
    seen_ids: set[int] = set()

    while candidates:
        candidate = candidates.pop(0)
        candidate_id = id(candidate)
        if candidate_id in seen_ids:
            continue
        seen_ids.add(candidate_id)

        if isinstance(candidate, list):
            text_parts = [
                str(item.get("text") or "").strip()
                for item in candidate
                if isinstance(item, dict) and str(item.get("text") or "").strip()
            ]
            if text_parts:
                parsed = _parse_json_text("".join(text_parts))
                if parsed is not None:
                    candidates.append(parsed)
                    continue
            return candidate

        if isinstance(candidate, dict):
            for nested_key in ("result", "output", "content", "response", "text", "value"):
                if nested_key in candidate:
                    nested = candidate.get(nested_key)
                    parsed = _parse_json_text(nested)
                    if parsed is not None:
                        candidates.append(parsed)
                    elif nested not in (None, ""):
                        candidates.append(nested)
            return candidate

        parsed = _parse_json_text(candidate)
        if parsed is not None:
            candidates.append(parsed)
            continue

        return candidate

    return value


def _extract_output_payload(output_text: str) -> Any:
    parsed = _parse_json_text(output_text)
    if parsed is None:
        return None
    return _unwrap_embedded_text_payload(parsed)


def _normalize_output_text(output_text: str) -> str:
    payload = _extract_output_payload(output_text)
    if isinstance(payload, (dict, list)):
        return json.dumps(payload, ensure_ascii=False)
    return output_text


def _payload_has_non_tool_keys(payload: Any) -> bool:
    return isinstance(payload, dict) and any(key not in _GENERIC_TOOL_RESPONSE_KEYS for key in payload.keys())


def _format_tool_payload_for_display(payload: Any) -> str:
    """Render a raw MCP tool result as a human-readable summary when we
    recognize its shape, falling back to pretty-printed JSON otherwise.

    This is what a user actually sees when the model's own final answer gets
    replaced by the last tool call's result (see _should_prefer_tool_payload).
    Without this, publishing tools (e.g. Trello card creation) would surface
    raw JSON to the user instead of a readable "card created: <link>" report.
    """
    data = payload.get("data") if isinstance(payload, dict) and "data" in payload else payload

    if isinstance(data, dict) and "created_cards" in data:
        lines: list[str] = []
        created = data.get("created_cards") or []
        skipped = data.get("skipped_cards") or []
        summary = data.get("summary") or {}
        board_url = data.get("board_url")

        lines.append(f"✅ Created {len(created)} card(s) on the Trello board:")
        for card in created:
            title = card.get("title") or "Untitled card"
            url = card.get("card_url") or ""
            lines.append(f"- **{title}** — {url}" if url else f"- **{title}**")

        if skipped:
            lines.append(f"\n⏭️ Skipped {len(skipped)} duplicate(s):")
            for card in skipped:
                lines.append(f"- {card.get('title', 'Untitled card')} ({card.get('reason', 'duplicate')})")

        warnings = data.get("warnings") or []
        if warnings:
            lines.append("\n⚠️ Warnings:")
            for warning in warnings:
                lines.append(f"- {warning}")

        if board_url:
            lines.append(f"\nBoard: {board_url}")
        if summary:
            lines.append(
                f"\nSummary: {summary.get('created', len(created))} created, "
                f"{summary.get('skipped_duplicates', len(skipped))} skipped, "
                f"{summary.get('failed', 0)} failed (of {summary.get('total_input_cards', len(created) + len(skipped))} total)."
            )
        return "\n".join(lines)

    if isinstance(data, dict) and "card_id" in data and "card_title" in data:
        title = data.get("card_title") or "Untitled card"
        url = data.get("card_url") or ""
        column = data.get("column_name")
        suffix = f" (in **{column}**)" if column else ""
        return f"✅ Card created: **{title}**{suffix}\n{url}" if url else f"✅ Card created: **{title}**{suffix}"

    return json.dumps(payload, ensure_ascii=False)


def _wrap_azure_devops_work_items_as_payload(payloads: list[Any]) -> list[dict[str, Any]] | None:
    """Combine every Azure DevOps work item seen during the run into one payload.

    An action agent can create several work items in a single run, but only the
    most recent tool result is otherwise surfaced. This gathers them all and
    returns one combined payload, or None when there are no work items (so other
    agents are unaffected).
    """
    work_items = extract_azure_devops_work_items(payloads)
    if not work_items:
        return None
    return [{"type": "text", "text": json.dumps(work_items, ensure_ascii=False)}]


def _beautify_echoed_tool_output(output_text: str) -> str | None:
    """Turn an agent's answer into readable text when it just echoes a raw tool result.

    Some tool results aren't captured as structured payloads, so the agent may
    surface them verbatim as raw JSON. This formats those into a readable
    summary, and returns None when the output isn't a recognized tool result.
    """
    payload = _extract_output_payload(output_text)
    if not isinstance(payload, dict):
        return None
    data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
    if isinstance(data, dict) and (
        "created_cards" in data or ("card_id" in data and "card_title" in data)
    ):
        return _format_tool_payload_for_display(payload)
    return None


def _payload_is_business_output(payload: Any) -> bool:
    """True when a payload looks like a genuine agent answer rather than a bare
    tool-response echo (e.g. a single fetch_link_excerpt / verify_links result)."""
    if isinstance(payload, dict):
        return _payload_has_non_tool_keys(payload)
    if isinstance(payload, list):
        return any(_payload_has_non_tool_keys(element) for element in payload)
    return False


def _extract_structured_tool_payload(response: Any) -> dict[str, Any] | list[Any] | None:
    candidates: list[Any] = [_unwrap_embedded_text_payload(response)]
    seen_ids: set[int] = set()

    while candidates:
        candidate = candidates.pop(0)
        candidate_id = id(candidate)
        if candidate_id in seen_ids:
            continue
        seen_ids.add(candidate_id)

        if isinstance(candidate, list):
            return candidate

        if isinstance(candidate, dict):
            if any(
                key in candidate
                for key in ("status", "summary", "results", "items")
            ):
                return candidate
            for nested_key in ("result", "output", "content", "response", "text", "value"):
                if nested_key in candidate:
                    candidates.append(candidate.get(nested_key))
            continue

        parsed = _parse_json_text(candidate)
        if parsed is not None:
            candidates.append(parsed)

    return None


def _tool_payload_has_meaningful_results(payload: Any) -> bool:
    if isinstance(payload, list):
        return len(payload) > 0

    if not isinstance(payload, dict):
        return False

    for key in ("results", "items", "all_items", "data", "rows", "publish_items"):
        value = payload.get(key)
        if isinstance(value, list) and value:
            return True

    sections = payload.get("sections")
    if isinstance(sections, dict) and any(isinstance(items, list) and items for items in sections.values()):
        return True

    summary = payload.get("summary")
    if isinstance(summary, dict):
        for key in ("updated", "count", "total"):
            try:
                if int(summary.get(key) or 0) > 0:
                    return True
            except (TypeError, ValueError):
                continue

    return False


def _payload_primary_list_count(payload: Any) -> int:
    if isinstance(payload, list):
        return len(payload)

    if not isinstance(payload, dict):
        return 0

    for key in ("all_items", "items", "results", "data", "rows", "publish_items"):
        value = payload.get(key)
        if isinstance(value, list):
            return len(value)

    summary = payload.get("summary")
    if isinstance(summary, dict):
        for key in ("incidents_total", "incidents_succeeded", "updated", "count", "total"):
            try:
                return int(summary.get(key) or 0)
            except (TypeError, ValueError):
                continue

    run_stats = payload.get("run_stats")
    if isinstance(run_stats, dict):
        for key in ("items_retrieved", "total_items", "total_item_count", "count", "total"):
            try:
                return int(run_stats.get(key) or 0)
            except (TypeError, ValueError):
                continue

    for key in ("total_item_count", "count", "total"):
        try:
            return int(payload.get(key) or 0)
        except (TypeError, ValueError):
            continue

    return 0


def _should_prefer_tool_payload(output_text: str, tool_payload: Any) -> bool:
    if not _tool_payload_has_meaningful_results(tool_payload):
        return False

    tool_count = _payload_primary_list_count(tool_payload)

    parsed_output = _extract_output_payload(output_text)
    if parsed_output is None:
        return True
    if isinstance(parsed_output, list):
        return tool_count > len(parsed_output) or len(parsed_output) == 0
    if not isinstance(parsed_output, dict):
        return True
    if _payload_has_non_tool_keys(parsed_output):
        return False

    output_count = _payload_primary_list_count(parsed_output)
    if tool_count > output_count:
        return True

    output_results = parsed_output.get("results")
    if isinstance(output_results, list) and output_results:
        return False

    output_summary = parsed_output.get("summary")
    output_total = 0
    if isinstance(output_summary, dict):
        try:
            output_total = int(output_summary.get("incidents_total") or output_summary.get("total") or 0)
        except (TypeError, ValueError):
            output_total = 0

    status_text = str(parsed_output.get("status") or "").strip().lower()
    return status_text in {"", "error"} or output_total == 0


def _extract_tool_error_from_response(response: Any) -> str:
    parsed = _extract_structured_tool_payload(response)
    if isinstance(parsed, dict):
        error_text = str(parsed.get("error") or "").strip()
        status_text = str(parsed.get("status") or "").strip().lower()
        if error_text:
            return error_text
        if status_text == "error":
            return str(parsed)
    return ""


def _load_credentials_from_mcp_config(
    agents: list[dict[str, Any]],
    pre_loaded_mcp_toolsets: dict[str, Any] | None = None,
    credential_resolver=None,
) -> dict[str, Any]:
    """Load credentials for MCP servers used by these agents.

    Uses CredentialResolver (DB-backed) when available. Injects credentials into the
    action-agent input payload so no credentials need to be entered via the UI.
    """
    credentials: dict[str, Any] = {}

    if not credential_resolver:
        return credentials

    for agent in agents:
        mcp_tools_raw = agent.get("mcp_tools") or agent.get("mcp_servers") or ""
        server_names = _parse_mcp_server_names(mcp_tools_raw)

        for server_name in server_names:
            try:
                resolved = credential_resolver.resolve(server_name)
                MCP_ENV_MAPPING = {
                    "ado_org": "ADO_ORG",
                    "ado_project": "ADO_PROJECT",
                    "ado_repo": "ADO_REPO",
                    "ado_branch": "ADO_BRANCH",
                    "ado_base_branch": "ADO_BASE_BRANCH",
                    "ado_pat": "ADO_PAT",

                    "dbt_cloud_base_url": "DBT_CLOUD_BASE_URL",
                    "dbt_cloud_account_id": "DBT_CLOUD_ACCOUNT_ID",
                    "dbt_cloud_job_id": "DBT_CLOUD_JOB_ID",
                    "dbt_cloud_token": "DBT_CLOUD_TOKEN",

                }
                for k, v in resolved.items():
                    if v not in (None, ""):
                        credentials[k] = v
                        
                        mapped_name = MCP_ENV_MAPPING.get(k)
                        if mapped_name:
                            credentials[mapped_name] = v
                            # Important
                            os.environ[mapped_name] = str(v)
            except Exception:
                # Also check resolved fallback server
                preloaded_entry = (pre_loaded_mcp_toolsets or {}).get(server_name)
                if isinstance(preloaded_entry, dict):
                    resolved_server = str(preloaded_entry.get("resolved_server") or "").strip()
                    if resolved_server and resolved_server != server_name:
                        try:
                            resolved = credential_resolver.resolve(resolved_server)
                            for k, v in resolved.items():
                                if v not in (None, ""):
                                    credentials[k] = v
                        except Exception:
                            pass
    return credentials


def _normalize_dynamic_outputs_for_action(dynamic_agent_outputs: dict[str, str]) -> dict[str, Any]:
    """Best-effort structured view of dynamic outputs for action agents.

    Loop and parallel stages may persist multi-batch JSON arrays joined with the
    standard ``\n\n---\n\n`` separator. This helper merges those arrays into a
    machine-readable list when possible, while preserving the original raw text
    as a fallback for outputs that are not array-shaped JSON.
    """
    normalized: dict[str, Any] = {}

    for agent_id in sorted((dynamic_agent_outputs or {}).keys()):
        raw_text = str((dynamic_agent_outputs or {}).get(agent_id) or "").strip()
        if not raw_text:
            normalized[agent_id] = []
            continue

        batches = [segment.strip() for segment in raw_text.split("\n\n---\n\n") if segment.strip()]
        merged_items: list[Any] = []
        parse_failed = False

        for batch in batches:
            try:
                parsed = json.loads(batch)
            except json.JSONDecodeError:
                parse_failed = True
                break

            if isinstance(parsed, list):
                merged_items.extend(parsed)
            else:
                parse_failed = True
                break

        normalized[agent_id] = raw_text if parse_failed else merged_items

    return normalized


def _build_action_input_payload(
    session_id: str,
    agents: list[dict[str, Any]],
    dynamic_agent_outputs: dict[str, str],
    pre_loaded_mcp_toolsets: dict[str, Any] | None = None,
    credential_resolver=None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Build a compact action-agent input payload with structured-first outputs.

    When structured normalization succeeds, avoid duplicating the same upstream
    content into ``dynamic_agent_outputs`` and ``reviewed_output``. This keeps
    action-agent prompts smaller and reduces pressure to copy large payloads
    back into tool arguments.
    """
    structured_dynamic_outputs = _normalize_dynamic_outputs_for_action(dynamic_agent_outputs or {})

    fallback_dynamic_outputs: dict[str, str] = {}
    reviewed_parts: list[str] = []
    for agent_id in sorted((dynamic_agent_outputs or {}).keys()):
        raw_text = str((dynamic_agent_outputs or {}).get(agent_id) or "").strip()
        if not raw_text:
            continue

        structured_value = structured_dynamic_outputs.get(agent_id)
        if isinstance(structured_value, list):
            continue

        fallback_dynamic_outputs[agent_id] = raw_text
        reviewed_parts.append(f"--- Output from {agent_id} ---\n{raw_text}")

    extra_context = {
        **_collect_extra_context(agents),
        **_load_credentials_from_mcp_config(agents, pre_loaded_mcp_toolsets, credential_resolver=credential_resolver),
        **_default_repo_dbt_context(),
    }

    input_payload: dict[str, Any] = {
        "session_id": session_id,
        "dynamic_agent_outputs_structured": structured_dynamic_outputs,
        **extra_context,
    }
    if fallback_dynamic_outputs:
        input_payload["dynamic_agent_outputs"] = fallback_dynamic_outputs
    if reviewed_parts:
        input_payload["reviewed_output"] = "\n\n".join(reviewed_parts).strip()

    return input_payload, structured_dynamic_outputs


def _iter_exception_messages(exc: BaseException) -> list[str]:
    """Collect messages from an exception, including ExceptionGroup and causes."""
    messages: list[str] = []

    def _walk(e: BaseException) -> None:
        text = str(e).strip()
        if text:
            messages.append(text)
        else:
            messages.append(repr(e))

        try:
            if isinstance(e, BaseExceptionGroup):  # type: ignore[name-defined]
                for sub in e.exceptions:
                    _walk(sub)
        except Exception:
            pass

        cause = getattr(e, "__cause__", None)
        if isinstance(cause, BaseException):
            _walk(cause)
        context = getattr(e, "__context__", None)
        if isinstance(context, BaseException):
            _walk(context)

    _walk(exc)
    # de-dupe while preserving order
    deduped: list[str] = []
    seen: set[str] = set()
    for m in messages:
        if m not in seen:
            seen.add(m)
            deduped.append(m)
    return deduped


def _is_mcp_session_failure(exc: BaseException) -> bool:
    """Return True if the exception indicates MCP session creation failed."""
    joined = " | ".join(_iter_exception_messages(exc)).lower()
    return (
        "failed to create mcp session" in joined
        or "mcp session" in joined and "failed" in joined
        or "google_adk" in joined and "mcp_tool" in joined
        or "timed out" in joined and "mcp" in joined
        or "failed to get tools from mcp" in joined
    )


def _is_mcp_tool_failure(exc: BaseException) -> bool:
    """Return True if the exception indicates MCP transport, auth, or tool runtime failure."""
    joined = " | ".join(_iter_exception_messages(exc)).lower()
    mcp_failure_indicators = [
        "failed to get tools from mcp server",
        "failed to authenticate fallback",
        "clientrequest",
        "mcp_tool",
        "mcp server",
        "mcp session",
        "session runner task",
        "failed to close mcp session",
    ]
    return _is_mcp_session_failure(exc) or any(
        indicator in joined for indicator in mcp_failure_indicators
    )


def _should_retry_with_fallback_provider(exc: BaseException) -> bool:
    """Return True only for provider-scoped failures that are not MCP failures."""
    return _is_llm_failure(exc) and not _is_mcp_tool_failure(exc)


def _strip_mcp_tools_from_agents(agents: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return shallow-copied agent configs with MCP tool references removed."""
    stripped: list[dict[str, Any]] = []
    for cfg in agents:
        copied = dict(cfg)
        # dynamic agent builder reads `mcp_tools`
        if "mcp_tools" in copied:
            copied["mcp_tools"] = []
        stripped.append(copied)
    return stripped


def _sanitize_action_agent_depends_on(
    agents: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Remove depends_on references that point outside this action-agent run."""
    action_agent_ids = {
        str(a.get("agent_id") or "").strip() for a in agents if a.get("agent_id")
    }

    sanitized_agents: list[dict[str, Any]] = []
    for agent_cfg in agents:
        cfg = dict(agent_cfg)
        depends_on = cfg.get("depends_on")

        if isinstance(depends_on, list):
            cfg["depends_on"] = [
                str(d).strip() for d in depends_on if str(d).strip() in action_agent_ids
            ]
        elif isinstance(depends_on, str):
            deps = [
                d.strip()
                for d in depends_on.strip().strip("[]").split(",")
                if d.strip()
            ]
            cfg["depends_on"] = [d for d in deps if d in action_agent_ids]

        sanitized_agents.append(cfg)

    return sanitized_agents


def _safe_name(value: str) -> str:
    """Convert a string into a stable identifier (mirrors dynamic agent builder)."""
    candidate = re.sub(r"\W+", "_", value or "dynamic_agent")
    if not candidate:
        candidate = "dynamic_agent"
    if not candidate[0].isalpha() and candidate[0] != "_":
        candidate = "_" + candidate
    return candidate


def _author_to_agent_id_map(agents: list[dict[str, Any]]) -> dict[str, str]:
    """Map ADK event.author (safe agent name) -> stable agent_id."""
    mapping: dict[str, str] = {}
    for agent_cfg in agents:
        agent_id = str(agent_cfg.get("agent_id") or "").strip()
        agent_name = str(agent_cfg.get("agent_name") or agent_id or "dynamic_agent")
        author_key = _safe_name(agent_name)
        if agent_id:
            mapping[author_key] = agent_id
    return mapping

def _default_repo_dbt_context() -> dict[str, Any]:
    """Build default repo/dbt context from environment variables when present."""
    import os

    repo_details = {
        "repo_name": os.getenv("ADO_REPO", ""),
        "branch_name": os.getenv("ADO_BRANCH", ""),
        "organization": os.getenv("ADO_ORG", ""),
        "project": os.getenv("ADO_PROJECT", ""),
        "base_branch": os.getenv("ADO_BASE_BRANCH", ""),
        "authentication_token": os.getenv("ADO_PAT", ""),
    }
    dbt_cloud_config = {
        "job_id": os.getenv("DBT_CLOUD_JOB_ID", ""),
        "project_id": os.getenv("DBT_CLOUD_PROJECT_ID", ""),
        "authentication_token": os.getenv("DBT_CLOUD_TOKEN", ""),
        "base_url": os.getenv("DBT_CLOUD_BASE_URL", ""),
    }
    local_project_root_path = os.getenv("DBT_LOCAL_PROJECT_DIR", "")

    # Keep only meaningful values while preserving expected object shape.
    repo_details = {k: v for k, v in repo_details.items() if v not in (None, "")}
    dbt_cloud_config = {k: v for k, v in dbt_cloud_config.items() if v not in (None, "")}

    payload: dict[str, Any] = {}
    if repo_details:
        payload["repo_details"] = repo_details
    if dbt_cloud_config:
        payload["dbt_cloud_config"] = dbt_cloud_config
    if local_project_root_path:
        payload["local_project_root_path"] = local_project_root_path
    return payload

def _next_available_artifact_path(artifacts_dir: Path, file_name: str) -> Path:
    candidate = artifacts_dir / file_name
    if not candidate.exists():
        return candidate

    stem = candidate.stem
    suffix = candidate.suffix
    index = 2
    while True:
        retry = artifacts_dir / f"{stem}_{index}{suffix}"
        if not retry.exists():
            return retry
        index += 1


def _materialize_json_artifacts_from_outputs(session_id: str, outputs: dict[str, str]) -> int:
    """Persist titled JSON markdown blocks from agent outputs into artifacts/."""
    if not outputs:
        return 0

    pattern = re.compile(
        r"^###\s+([^\r\n]+?\.json)\s*$\s*```json\s*(.*?)\s*```",
        re.IGNORECASE | re.MULTILINE | re.DOTALL,
    )

    artifacts: list[tuple[str, Any]] = []
    for _agent_id, text in sorted(outputs.items()):
        if not text:
            continue
        for match in pattern.finditer(text):
            file_name = Path(match.group(1).strip()).name
            if not file_name.lower().endswith(".json"):
                continue
            try:
                payload = json.loads(match.group(2).strip())
            except json.JSONDecodeError:
                continue
            artifacts.append((file_name, payload))

    if not artifacts:
        return 0

    artifacts_dir = get_artifacts_dir(session_id, create=True)
    created = 0
    for file_name, payload in artifacts:
        artifact_path = _next_available_artifact_path(artifacts_dir, file_name)
        artifact_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2, default=str),
            encoding="utf-8",
        )
        created += 1

    logger.info("Materialized JSON artifacts from dynamic output", extra={
        "session_id": session_id,
        "created_count": created,
    })
    return created


def _should_materialize_for_sttm_usecase(agents: list[dict[str, Any]], pipeline_name: str) -> bool:
    """Run artifact materialization only for STTM use case in dynamic pipeline."""
    if pipeline_name != "dynamic_agents_pipeline":
        return False

    for agent in agents or []:
        usecase_id = str(agent.get("usecase_id") or "").strip().upper()
        local_tools = agent.get("local_tools")
        local_tools_text = ",".join(str(x) for x in local_tools) if isinstance(local_tools, list) else str(local_tools or "")
        if usecase_id == "UC_CP_020" or "SttmToJsonConverter" in local_tools_text:
            return True
    return False


def _close_mcp_toolsets(agent: Any) -> None:
    """Best-effort cleanup for MCP toolsets attached to ADK agents.

    When an MCP session fails to initialize, ADK may leave background tasks
    running long enough to emit TaskGroup warnings. Closing toolsets prevents
    that from leaking between retries within a single request.
    """

    def _close_from_tools(tools: Any) -> None:
        if not isinstance(tools, list):
            return
        for tool in tools:
            if isinstance(tool, McpToolset):
                try:
                    close_result = tool.close()
                    # If close() returns a coroutine, run it
                    if asyncio.iscoroutine(close_result):
                        try:
                            loop = asyncio.get_event_loop()
                            if loop.is_running():
                                # If loop is already running, create a task
                                asyncio.create_task(close_result)
                            else:
                                loop.run_until_complete(close_result)
                        except RuntimeError:
                            # No event loop, use asyncio.run
                            asyncio.run(close_result)
                except Exception as e:
                    logger.debug("Ignoring MCP toolset close error: %s", e)

    # SequentialAgent exposes .sub_agents; each Agent exposes .tools.
    try:
        child_agents = getattr(agent, "sub_agents", None)
        if isinstance(child_agents, list):
            for child in child_agents:
                _close_from_tools(getattr(child, "tools", None))
        else:
            _close_from_tools(getattr(agent, "tools", None))
    except Exception as e:
        logger.debug("Ignoring MCP toolset cleanup error: %s", e)


async def _run_pipeline_async(
    agents: list[dict[str, Any]],
    input_message: str,
    session_id: str,
    pipeline_name: str = "pipeline",
    pre_loaded_mcp_toolsets: dict[str, Any] | None = None,
    data_session_id: str | None = None,
) -> tuple[dict[str, str], dict[str, dict[str, int]], dict[str, str], dict[str, str]]:
    """
    Build a SequentialAgent pipeline from agent configs and run it.

    Returns a dict of ``{agent_name: output_text}`` collected from the
    events produced by the runner.
    """
    if not agents:
        return {}

    import time
    start_time = time.time()
    
    logger.info("Pipeline execution started", extra={
        "session_id": session_id, 
        "pipeline_name": pipeline_name, 
        "agent_count": len(agents)
    })

    daan_session_id.set(session_id)
    author_map = _author_to_agent_id_map(agents)

    import os
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    data_sid = data_session_id or session_id
    session_data_dir = os.path.join(project_root, "session_storage", data_sid, "inputs")

    pipeline = create_pipeline_agent(
        session_id=session_id,
        agents=agents,
        pipeline_name=pipeline_name,
        pre_loaded_mcp_toolsets=pre_loaded_mcp_toolsets,
        tool_kwargs={"data_dir": session_data_dir},
    )
    # Track whether this is already a fallback retry to prevent infinite loops
    _is_fallback_retry = any(a.get("_fallback_retry") for a in agents)

    runner = InMemoryRunner(agent=pipeline, app_name=APP_NAME)
    # ADK defaults to auto_create_session=False, which raises SessionNotFoundError
    # for new session_ids. DAAN runs are stateless per invocation, so auto-create
    # is the desired behavior.
    runner.auto_create_session = True

    # Incoming-branch alternative (kept for reference): manually create the ADK session.
    # We prefer `auto_create_session=True` because it is the runner-supported mechanism
    # and avoids failure modes like trying to create the same session twice.
    #
    # If you ever need strict session lifecycle control, you can switch to this:
    # await runner.session_service.create_session(
    #     app_name=APP_NAME,
    #     user_id="daan_user",
    #     session_id=session_id,
    # )

    user_message = types.Content(
        role="user",
        parts=[types.Part(text=input_message)],
    )

    outputs: dict[str, str] = {}
    usage_by_agent: dict[str, dict[str, int]] = {}
    model_by_agent: dict[str, str] = {}
    provider_by_agent: dict[str, str] = {}
    mcp_tool_errors_by_agent: dict[str, list[str]] = {}
    last_structured_tool_payload_by_agent: dict[str, dict[str, Any] | list[Any]] = {}
    all_structured_tool_payloads_by_agent: dict[str, list[Any]] = {}
    agents_with_mcp_tools = {
        str(agent.get("agent_id") or agent.get("agent_name") or "").strip()
        for agent in agents
        if _agent_has_mcp_tools(agent)
    }
    action_agent_ids = {
        str(agent.get("agent_id") or agent.get("agent_name") or "").strip()
        for agent in agents
        if str(agent.get("agent_type") or "").strip().lower() == "action_agent"
    }

    try:
        # SSE streaming lets us forward per-chunk parts to the reasoning bus
        # so the UI's Thinking Steps panel updates live during the run.
        run_config = RunConfig(streaming_mode=StreamingMode.SSE)
        # Bus is keyed by the base session_id (without any __AGENT_N suffix).
        reasoning_bus = get_bus(str(session_id).split("__", 1)[0])
        async for event in runner.run_async(
            user_id="daan_user",
            session_id=session_id,
            new_message=user_message,
            run_config=run_config,
        ):
            is_partial = getattr(event, "partial", False)
            author = (event.author or "unknown").strip()
            key = author_map.get(author) or author
            if reasoning_bus and is_partial:
                _emit_partial_event_to_bus(reasoning_bus, event, key)
            # Only accumulate output text from non-partial events. Streaming
            # partials may repeat cumulative text, corrupting captured output.
            if not is_partial and event.content and event.content.parts:
                text = "".join(
                    p.text for p in event.content.parts
                    if hasattr(p, "text") and p.text and not getattr(p, "thought", False)
                )
                if text:
                    # Accumulate — an agent may produce multiple events.
                    outputs[key] = outputs.get(key, "") + text
            function_responses = []
            try:
                function_responses = event.get_function_responses() or []
            except Exception:
                function_responses = []
            if key in agents_with_mcp_tools and function_responses:
                for function_response in function_responses:
                    response = getattr(function_response, "response", None)
                    structured_payload = _extract_structured_tool_payload(response)
                    if structured_payload is not None:
                        last_structured_tool_payload_by_agent[key] = structured_payload
                        all_structured_tool_payloads_by_agent.setdefault(key, []).append(structured_payload)
                    error_text = _extract_tool_error_from_response(response)
                    if error_text:
                        tool_name = str(getattr(function_response, "name", "") or "tool").strip() or "tool"
                        mcp_tool_errors_by_agent.setdefault(key, []).append(
                            f"{tool_name}: {error_text}"
                        )
            usage = extract_usage_from_event(event)
            model_name, provider_name = extract_model_provider_from_event(event)
            if model_name or provider_name:
                if model_name:
                    model_by_agent[key] = model_name
                if provider_name:
                    provider_by_agent[key] = provider_name
            if usage.get("prompt_tokens") or usage.get("completion_tokens") or usage.get("total_tokens"):
                prior = usage_by_agent.get(key, {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0})
                usage_by_agent[key] = {
                    "prompt_tokens": int(prior.get("prompt_tokens") or 0) + int(usage.get("prompt_tokens") or 0),
                    "completion_tokens": int(prior.get("completion_tokens") or 0) + int(usage.get("completion_tokens") or 0),
                    "total_tokens": int(prior.get("total_tokens") or 0) + int(usage.get("total_tokens") or 0),
                }
    except BaseException as exc:
        # Attempt fallback if this is an LLM failure and not already a fallback retry
        if not _is_fallback_retry and _should_retry_with_fallback_provider(exc):
            from daan.llm.llm_provider import get_fallback_provider_name
            fallback_provider = get_fallback_provider_name()
            if fallback_provider:
                logger.warning("Pipeline execution failed, retrying with fallback", extra={
                    "session_id": session_id, 
                    "pipeline_name": pipeline_name, 
                    "error": str(exc)[:200], 
                    "fallback_provider": fallback_provider
                })
                fallback_agents = _swap_provider_in_agents(agents, fallback_provider)
                # Reuse the already-initialized MCP toolsets so the fallback agent keeps
                # its DB-registered tools; the fallback run cleans them up itself.
                return await _run_pipeline_async(
                    fallback_agents,
                    input_message,
                    session_id,
                    f"{pipeline_name}_fallback",
                    pre_loaded_mcp_toolsets=pre_loaded_mcp_toolsets,
                )
        _close_mcp_toolsets(pipeline)
        logger.error("Pipeline execution failed", extra={
            "session_id": session_id, 
            "pipeline_name": pipeline_name, 
            "error": str(exc)[:200]
        })
        raise
    else:
        _close_mcp_toolsets(pipeline)
        
    duration_seconds = time.time() - start_time
    total_tokens = sum(sum(usage.values()) for usage in usage_by_agent.values())
    
    logger.info("Pipeline execution completed, duration: %s seconds", round(duration_seconds, 2), extra={
        "session_id": session_id, 
        "pipeline_name": pipeline_name, 
        "duration_seconds": round(duration_seconds, 2), 
        "total_tokens": total_tokens,
        "agent_outputs": len(outputs)
    })

    if _should_materialize_for_sttm_usecase(agents, pipeline_name):
        try:
            _materialize_json_artifacts_from_outputs(session_id, outputs)
        except Exception as exc:
            logger.warning("Artifact materialization skipped", extra={
                "session_id": session_id,
                "pipeline_name": pipeline_name,
                "error": str(exc)[:200],
            })

    if mcp_tool_errors_by_agent and any(
        str(agent.get("agent_type") or "").strip().lower() == "action_agent"
        for agent in agents
    ):
        error_parts: list[str] = []
        for agent_id, errors in sorted(mcp_tool_errors_by_agent.items()):
            error_parts.append(f"{agent_id}: {' | '.join(errors)}")
        raise RuntimeError(
            "MCP-backed action agent execution failed: " + " ; ".join(error_parts)
        )

    for agent_id in action_agent_ids:
        tool_payload = last_structured_tool_payload_by_agent.get(agent_id)
        output_text = str(outputs.get(agent_id) or "")
        # Ground truth: surface every work item created across all tool calls, not
        # just the last one (an action agent may create many items in one run).
        aggregated = _wrap_azure_devops_work_items_as_payload(
            all_structured_tool_payloads_by_agent.get(agent_id) or []
        )
        if aggregated is not None:
            outputs[agent_id] = _format_tool_payload_for_display(aggregated)
            continue
        if tool_payload is not None and _should_prefer_tool_payload(output_text, tool_payload):
            outputs[agent_id] = _format_tool_payload_for_display(tool_payload)
            continue
        beautified = _beautify_echoed_tool_output(output_text)
        if beautified is not None:
            outputs[agent_id] = beautified

    return outputs, usage_by_agent, model_by_agent, provider_by_agent


def _is_llm_failure(exc: BaseException) -> bool:
    """Return True if the exception indicates an LLM provider failure."""
    joined = " | ".join(_iter_exception_messages(exc)).lower()
    llm_failure_indicators = [
        "rate limit", "ratelimit", "429",
        "service unavailable", "503",
        "internal server error", "500",
        "api error", "api_error",
        "failed to get llm response",
        "litellm",
        "openai",
        "azure openai",
        "azure_openai",
        "gemini",
        "anthropic",
        "model provider",
    ]
    return any(indicator in joined for indicator in llm_failure_indicators)


def _swap_provider_in_agents(
    agents: list[dict[str, Any]], fallback_provider: str
) -> list[dict[str, Any]]:
    """Return shallow-copied agent configs with the provider swapped to fallback."""
    swapped: list[dict[str, Any]] = []
    for cfg in agents:
        copied = dict(cfg)
        copied["provider"] = fallback_provider
        copied["llm_provider"] = fallback_provider
        copied["_fallback_retry"] = True
        swapped.append(copied)
    return swapped


async def _run_single_agent_async(
    agent_config: dict[str, Any],
    input_message: str,
    session_id: str,
) -> tuple[str, dict[str, int], str, str]:
    """Run one ADK agent and return its final text output."""
    import time
    start_time = time.time()
    
    agent_id = agent_config.get("agent_id") or agent_config.get("agent_name") or "unknown_agent"
    
    logger.info("Agent execution started", extra={
        "session_id": session_id, 
        "agent_id": agent_id, 
        "agent_type": "single"
    })
    daan_session_id.set(session_id)
    
    import os
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    session_data_dir = os.path.join(project_root, "session_storage", session_id, "inputs")

    agent = create_adk_agent(session_id,agent_config, tool_kwargs={"data_dir": session_data_dir})
    _is_fallback_retry = bool(agent_config.get("_fallback_retry"))
    runner = InMemoryRunner(agent=agent, app_name=APP_NAME)
    runner.auto_create_session = True

    # Incoming-branch alternative (kept for reference): manually create the ADK session.
    # See notes in _run_pipeline_async.
    # await runner.session_service.create_session(
    #     app_name=APP_NAME,
    #     user_id="daan_user",
    #     session_id=session_id,
    # )

    user_message = types.Content(
        role="user",
        parts=[types.Part(text=input_message)],
    )

    output_parts: list[str] = []
    usage_totals: dict[str, int] = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    model_name = ""
    provider_name = ""
    last_structured_tool_payload: dict[str, Any] | list[Any] | None = None
    all_structured_tool_payloads: list[Any] = []
    last_business_output_text: str | None = None
    agent_has_mcp_tools = _agent_has_mcp_tools(agent_config)
    try:
        # SSE streaming so the reasoning bus receives per-chunk parts live.
        run_config = RunConfig(streaming_mode=StreamingMode.SSE)
        reasoning_bus = get_bus(str(session_id).split("__", 1)[0])
        bus_agent_id = str(agent_config.get("agent_id") or agent_config.get("agent_name") or "").strip()
        async for event in runner.run_async(
            user_id="daan_user",
            session_id=session_id,
            new_message=user_message,
            run_config=run_config,
        ):
            is_partial = getattr(event, "partial", False)
            if reasoning_bus and is_partial:
                _emit_partial_event_to_bus(reasoning_bus, event, bus_agent_id)
            if not is_partial and event.content and event.content.parts:
                text = "".join(
                    p.text for p in event.content.parts
                    if hasattr(p, "text") and p.text and not getattr(p, "thought", False)
                )
                if text:
                    output_parts.append(text)
                    event_payload = _extract_output_payload(text)
                    if _payload_is_business_output(event_payload):
                        last_business_output_text = json.dumps(event_payload, ensure_ascii=False)
            if agent_has_mcp_tools:
                function_responses = []
                try:
                    function_responses = event.get_function_responses() or []
                except Exception:
                    function_responses = []
                for function_response in function_responses:
                    response = getattr(function_response, "response", None)
                    structured_payload = _extract_structured_tool_payload(response)
                    if structured_payload is not None:
                        last_structured_tool_payload = structured_payload
            usage = extract_usage_from_event(event)
            event_model_name, event_provider_name = extract_model_provider_from_event(event)
            if event_model_name:
                model_name = event_model_name
            if event_provider_name:
                provider_name = event_provider_name
            usage_totals["prompt_tokens"] += int(usage.get("prompt_tokens") or 0)
            usage_totals["completion_tokens"] += int(usage.get("completion_tokens") or 0)
            usage_totals["total_tokens"] += int(usage.get("total_tokens") or 0)
    except BaseException as exc:
        _close_mcp_toolsets(agent)
        # Align feedback-agent rerun with pipeline fallback behavior.
        # Azure remains primary; fallback is attempted only for LLM failures.
        if not _is_fallback_retry and _should_retry_with_fallback_provider(exc):
            from daan.llm.llm_provider import get_fallback_provider_name

            fallback_provider = get_fallback_provider_name()
            if fallback_provider:
                logger.warning("Agent execution failed, retrying with fallback provider", extra={
                    "session_id": session_id, 
                    "agent_id": agent_id, 
                    "error": str(exc)[:200], 
                    "fallback_provider": fallback_provider
                })
                fallback_cfg = dict(agent_config)
                fallback_cfg["provider"] = fallback_provider
                fallback_cfg["llm_provider"] = fallback_provider
                fallback_cfg["_fallback_retry"] = True
                return await _run_single_agent_async(
                    fallback_cfg,
                    input_message,
                    session_id,
                )
        logger.error("Agent execution failed", extra={
            "session_id": session_id, 
            "agent_id": agent_id, 
            "error": str(exc)[:200]
        })
        raise
    else:
        _close_mcp_toolsets(agent)
        
    duration_seconds = time.time() - start_time
    
    logger.info("Agent execution completed, duration: %s seconds", round(duration_seconds, 2), extra={
        "session_id": session_id, 
        "agent_id": agent_id, 
        "duration_seconds": round(duration_seconds, 2), 
        "total_tokens": usage_totals.get("total_tokens", 0),
        "input_tokens": usage_totals.get("prompt_tokens", 0),
        "output_tokens": usage_totals.get("completion_tokens", 0)
    })

    output_text = _normalize_output_text("".join(output_parts))
    # Reliability guard: a tool-heavy agent can end its turn on a bare tool-response
    # echo (e.g. a single fetch_link_excerpt result). When that happens but the model
    # produced a genuine business answer earlier in the turn, persist the business
    # answer instead of the echo.
    aggregated = _wrap_azure_devops_work_items_as_payload(all_structured_tool_payloads)
    if aggregated is not None:
        output_text = _format_tool_payload_for_display(aggregated)
    elif (
        last_business_output_text is not None
        and not _payload_is_business_output(_extract_output_payload(output_text))
    ):
        output_text = last_business_output_text
    elif (
        last_structured_tool_payload is not None
        and _should_prefer_tool_payload(output_text, last_structured_tool_payload)
    ):
        output_text = _format_tool_payload_for_display(last_structured_tool_payload)
    else:
        beautified = _beautify_echoed_tool_output(output_text)
        if beautified is not None:
            output_text = beautified

    return output_text, usage_totals, model_name, provider_name



async def run_single_agent_async(
    agent_config: dict[str, Any],
    session_id: str,
    input_message: str,
) -> tuple[str, dict[str, int], str, str]:
    """Run one ADK agent and return its text output (async)."""
    agent_id = agent_config.get("agent_id") or agent_config.get("agent_name") or "<unknown>"
    
    logger.info("Agent run requested", extra={
        "session_id": session_id, 
        "agent_id": agent_id
    })
    return await _run_single_agent_async(agent_config, input_message, session_id)


# ═══════════════════════════════════════════════════════════════════════════
#  Idempotency helpers (Phase 1): capture / re-inject MCP-created resources
# ═══════════════════════════════════════════════════════════════════════════

# Matches a fenced code block whose body is a JSON object. The optional language
# tag (```daan-resources / ```json / no tag) is ignored — any fenced JSON object
# containing a "resources" array is treated as a resource manifest.
_RESOURCE_MANIFEST_RE = re.compile(
    r"```[^\S\r\n]*[A-Za-z0-9_-]*[^\S\r\n]*\r?\n(\{.*?\})\r?\n```",
    re.DOTALL,
)


def _action_agent_ids(agents: list[dict[str, Any]]) -> list[str]:
    """Return the non-empty agent_id values from a list of agent configs."""
    ids: list[str] = []
    for agent in agents or []:
        aid = str(agent.get("agent_id") or "").strip()
        if aid:
            ids.append(aid)
    return ids


def _extract_resource_manifest(text: str) -> list[dict[str, Any]]:
    """Parse resource-manifest entries emitted by an action agent.

    Agents append a fenced JSON block of the form
    ``{"resources": [{"local_key": ..., "type": ..., "id": ..., "url": ...}]}``.
    Returns the flattened list of resource dicts (empty when none found).
    """
    if not text:
        return []
    resources: list[dict[str, Any]] = []
    for match in _RESOURCE_MANIFEST_RE.finditer(text):
        try:
            data = json.loads(match.group(1))
        except (ValueError, TypeError):
            continue
        if isinstance(data, dict) and isinstance(data.get("resources"), list):
            resources.extend(r for r in data["resources"] if isinstance(r, dict))
    return resources


def _stable_local_key(prefix: str, identity: str) -> str:
    """Deterministic, content-derived local_key so the same item maps across runs."""
    digest = hashlib.sha1((identity or "").strip().lower().encode("utf-8")).hexdigest()[:10]
    return f"{prefix}-{digest}"


def _derive_child_items(reviewed_output: str) -> dict[str, Any]:
    """Parse the epic + child user stories into a deterministic desired-state list.

    Each item gets a STABLE ``local_key`` derived from its own content (Story ID
    when present, else a hash of its title) rather than a positional counter, so
    that on a re-run the same story maps to the same external work item — enabling
    correct add / update / remove reconciliation (Phase 2).

    Returns ``{}`` when no epic/story blocks are present (best-effort — callers
    simply skip injection and fall back to prior behaviour).
    """
    text = reviewed_output or ""
    if not text.strip():
        return {}
    try:
        from daan.utils.transformations.userstory import (
            extract_epic_and_story_blocks,
            extract_epic_summary,
            extract_story_summary,
            extract_story_id,
        )

        epic_block, story_blocks = extract_epic_and_story_blocks(text)
        if not epic_block and not story_blocks:
            return {}

        result: dict[str, Any] = {}
        if epic_block:
            epic_title = extract_epic_summary(epic_block, "Epic")
            result["epic"] = {
                "local_key": _stable_local_key("epic", epic_title),
                "title": epic_title,
                "kind": "epic",
            }

        children: list[dict[str, Any]] = []
        seen: set[str] = set()
        for idx, block in enumerate(story_blocks):
            title = extract_story_summary(block, f"Story {idx + 1}")
            story_id = extract_story_id(block, "")
            identity = story_id or title
            local_key = (
                f"story-{story_id.strip().lower()}"
                if story_id else _stable_local_key("story", identity)
            )
            if local_key in seen:
                continue
            seen.add(local_key)
            children.append({
                "local_key": local_key,
                "title": title,
                "kind": "user_story",
            })
        if children:
            result["children"] = children
        return result if result else {}
    except Exception as exc:  # noqa: BLE001 — never block the action run
        logger.warning("Could not derive child items for reconciliation: %s", exc)
        return {}


def _load_existing_resources_for_agents(
    session_id: str,
    agent_ids: list[str],
) -> dict[str, list[dict[str, Any]]]:
    """Load previously-created external resources for the given agents from the KG.

    Best-effort: any failure (KG locked/unavailable) returns an empty mapping so
    the action run proceeds normally.
    """
    if not session_id or not agent_ids:
        return {}
    result: dict[str, list[dict[str, Any]]] = {}
    try:
        from daan.knowledge_graph.connection import get_kg_connection
        from daan.knowledge_graph import queries as kg_queries

        conn = get_kg_connection()
        for aid in agent_ids:
            resources = kg_queries.get_external_resources(conn, session_id, aid)
            if resources:
                result[aid] = resources
    except Exception as exc:  # noqa: BLE001 — never block the action run
        logger.warning("Could not load existing external resources from KG: %s", exc)
    return result


def _persist_agent_resources(session_id: str, outputs: dict[str, str]) -> None:
    """Capture MCP-created resource identifiers from action outputs into the KG.

    Best-effort: parsing/KG failures are logged but never propagate.
    """
    if not session_id or not outputs:
        return
    try:
        from daan.knowledge_graph.connection import get_kg_connection
        from daan.knowledge_graph import kg_events

        conn = None
        for agent_id, text in outputs.items():
            manifest = _extract_resource_manifest(text)
            if not manifest:
                continue
            if conn is None:
                conn = get_kg_connection()
            seen_keys: set[str] = set()
            for resource in manifest:
                # Collapse manifest entries that reference the same external id
                # (the agent may re-emit one work item under several local_keys).
                ext_id = str(
                    resource.get("id")
                    or resource.get("key")
                    or resource.get("resource_key")
                    or ""
                ).strip()
                if ext_id:
                    if ext_id in seen_keys:
                        continue
                    seen_keys.add(ext_id)
                kg_events.upsert_external_resource(conn, session_id, agent_id, resource)
    except Exception as exc:  # noqa: BLE001 — never block the action run
        logger.warning("Could not persist external resources to KG: %s", exc)


def _run_deterministic_publish(
    session_id: str,
    agents: list[dict[str, Any]],
    reviewed_output: str,
    existing_resources: dict[str, list[dict[str, Any]]],
) -> tuple[dict[str, str], list[dict[str, Any]]]:
    """Integration B: reconcile publish targets in code, LLM out of the loop.

    For each action agent whose MCP target has a publish adapter and whose
    approved content parses into publishable items, run deterministic
    create/update/remove reconciliation and produce the resource manifest
    directly. Agents without an adapter (or unparseable content) are returned in
    ``remaining`` to run through the normal LLM pipeline.
    """
    deterministic_outputs: dict[str, str] = {}
    remaining: list[dict[str, Any]] = []
    for agent in agents or []:
        aid = str(agent.get("agent_id") or "").strip()
        result = None
        try:
            from daan.publish import sync_publish_target

            result = sync_publish_target(
                agent, reviewed_output, (existing_resources or {}).get(aid, [])
            )
        except Exception as exc:  # noqa: BLE001 — never block the action run
            logger.warning(
                "Deterministic publish sync errored for agent %s: %s", aid, exc
            )
            result = None

        if result and aid:
            deterministic_outputs[aid] = result["manifest_text"]
            logger.info(
                "Deterministic publish for agent %s via %s: %s",
                aid, result.get("adapter"), result.get("summary"),
                extra={"session_id": session_id},
            )
            for err in result.get("errors") or []:
                logger.warning("Publish item error (%s): %s", aid, err)
            # Persist the STRUCTURED resources directly to the KG. The display
            # manifest_text is formatted for humans and intentionally omits the
            # machine fields (local_key / kind / real external id), so a
            # parse-based persist would lose the data the reconciler needs on
            # re-runs. Persist the structured list instead.
            try:
                from daan.knowledge_graph.connection import get_kg_connection
                from daan.knowledge_graph import kg_events as _kg_events

                structured = result.get("resources") or []
                if structured:
                    pconn = get_kg_connection()
                    for resource in structured:
                        _kg_events.upsert_external_resource(pconn, session_id, aid, resource)
            except Exception as exc:  # noqa: BLE001 — never block the run
                logger.warning("Could not persist deterministic resources to KG: %s", exc)
            # Purge removed items from the KG so they are not reloaded as
            # "existing" (and re-removed / resurrected) on the next run.
            removed_keys = result.get("removed_keys") or []
            if removed_keys:
                try:
                    from daan.knowledge_graph.connection import get_kg_connection
                    from daan.knowledge_graph import kg_events

                    conn = get_kg_connection()
                    for rk in removed_keys:
                        kg_events.delete_external_resource(conn, session_id, aid, rk)
                except Exception as exc:  # noqa: BLE001 — never block the run
                    logger.warning("Could not purge removed resources from KG: %s", exc)
        else:
            remaining.append(agent)
    return deterministic_outputs, remaining


async def run_action_agents_async(
    agents: list[dict[str, Any]],
    session_id: str,
    dynamic_agent_outputs: dict[str, str],
    pre_loaded_mcp_toolsets: dict[str, Any] | None = None,
    extra_input: dict[str, Any] | None = None,
    credential_resolver=None,
) -> tuple[dict[str, str], dict[str, dict[str, int]], dict[str, str], dict[str, str], str]:
    """Async variant of run_action_agents (no asyncio.run / no new event loop)."""
    if not agents:
        return {}

    sanitized_agents = _sanitize_action_agent_depends_on(agents)
    input_payload, structured_dynamic_outputs = _build_action_input_payload(
        session_id,
        sanitized_agents,
        dynamic_agent_outputs or {},
        pre_loaded_mcp_toolsets=pre_loaded_mcp_toolsets,
        credential_resolver=credential_resolver,
    )
    input_message = (
        "ACTION_INPUT_GUIDANCE:\n"
        "- Prefer dynamic_agent_outputs_structured when an agent entry is a parsed JSON array.\n"
        "- Use dynamic_agent_outputs and reviewed_output as compatibility fallback when the structured entry is empty or remains raw text.\n"
        "- Keep tool-call arguments small; do not copy large upstream payloads into tool parameters unless the tool explicitly requires them.\n\n"
        "INPUT_JSON:\n"
        + json.dumps(input_payload, ensure_ascii=False)
    )

    reviewed_output = str(input_payload.get("reviewed_output") or "").strip()

    # Idempotency (Phase 1): if these action agents already created external
    # resources in a previous run of this session, hand the identifiers back so
    # the agent UPDATES them instead of creating duplicates.
    existing_resources = _load_existing_resources_for_agents(
        session_id, _action_agent_ids(sanitized_agents)
    )
    if existing_resources:
        input_payload["existing_resources"] = existing_resources

    # Phase 2: hand the agent a deterministic desired-state list of child items
    # (each with a stable, content-derived local_key) so it can reconcile
    # add/update/remove against existing_resources instead of re-numbering items
    # positionally (which caused the same work item to be re-created/duplicated).
    desired_child_items = _derive_child_items(reviewed_output)
    if desired_child_items:
        input_payload["desired_child_items"] = desired_child_items

    # Optional caller-supplied fields (e.g. a chat feedback_instruction that the
    # action agent should apply to the previously published resources).
    if extra_input:
        input_payload.update(extra_input)

    logger.info(
        "Prepared action-agent output handoff",
        extra={
            "session_id": session_id,
            "structured_agent_count": sum(
                1 for value in structured_dynamic_outputs.values() if isinstance(value, list)
            ),
            "raw_fallback_agent_count": sum(
                1 for value in structured_dynamic_outputs.values() if isinstance(value, str) and value.strip()
            ),
        },
    )

    input_message = (
        "ACTION_INPUT_GUIDANCE:\n"
        "- Prefer dynamic_agent_outputs_structured when an agent entry is a parsed JSON array.\n"
        "- Use dynamic_agent_outputs and reviewed_output as compatibility fallback when the structured entry is empty or remains raw text.\n"
        "- Keep tool-call arguments small; do not copy large upstream payloads into tool parameters unless the tool explicitly requires them.\n\n"
        "INPUT_JSON:\n"
        + json.dumps(input_payload, ensure_ascii=False)
    )

    # Integration B: run deterministic publish reconciliation (LLM out of the
    # loop) for any action agent whose MCP target has a publish adapter and
    # whose approved content parses into publishable items. This guarantees
    # add/update/remove actually reach the external system instead of the LLM
    # echoing a stale manifest. Remaining agents run through the LLM pipeline.
    direct_outputs: dict[str, str] = {}
    remaining_for_publish: list[dict[str, Any]] = []

    for agent in sanitized_agents:
        agent_id = str(agent.get("agent_id") or agent.get("agent_name") or "").strip()
        local_tools_text = str(agent.get("local_tools") or "")

        if "CreateUseCaseFromDefinitionTool.create_usecase_from_definition" in local_tools_text:
            from daan.native_tools.create_use_case_from_definition_tool import CreateUseCaseFromDefinitionTool

            result = CreateUseCaseFromDefinitionTool().create_usecase_from_definition(
                dynamic_agent_outputs_structured=structured_dynamic_outputs,
                reviewed_output=reviewed_output,
                session_id=session_id,
            )
            direct_outputs[agent_id] = json.dumps(result, ensure_ascii=False)
        else:
            remaining_for_publish.append(agent)

    if not remaining_for_publish:
        return direct_outputs, {}, {}, {}, input_message
    
    deterministic_outputs, remaining_agents = _run_deterministic_publish(
        session_id, remaining_for_publish, reviewed_output, existing_resources,
    )
    deterministic_outputs.update(direct_outputs)
    if not remaining_agents:
        return deterministic_outputs, {}, {}, {}, input_message

    logger.info("Running %d ActionAgent(s)", len(remaining_agents), extra={
        "session_id": session_id})
    
    # Try execution with pre-loaded MCP toolsets
    try:
        outputs, usage, model_by_agent, provider_by_agent = await _run_pipeline_async(
            remaining_agents,
            input_message,
            session_id,
            "action_agents_pipeline",
            pre_loaded_mcp_toolsets=pre_loaded_mcp_toolsets,
        )
        logger.info("Action agents async execution completed", extra={
            "session_id": session_id, 
            "agent_outputs": len(outputs),
            "total_usage": sum(sum(u.values()) for u in usage.values())
        })
        _persist_agent_resources(session_id, outputs)
        outputs.update(deterministic_outputs)
        return outputs, usage, model_by_agent, provider_by_agent, input_message
    except BaseException as exc:
        if _is_mcp_tool_failure(exc) and any(str(a.get("mcp_tools") or "").strip() for a in remaining_agents):
            logger.warning(
                "MCP failure details: %s",
                " | ".join(_iter_exception_messages(exc)),
                extra={"session_id": session_id},
            )
            
            # Retry with fresh MCP initialization if credential_resolver is available
            if credential_resolver and pre_loaded_mcp_toolsets:
                logger.info(
                    "Retrying action agents with fresh MCP connection for session %s",
                    session_id,
                    extra={"session_id": session_id},
                )
                try:
                    # Re-initialize MCP toolsets with credentials
                    from daan.mcp_servers.core.mcp_toolset_provider import initialize_mcp_for_agents
                    
                    fresh_mcp_toolsets = await initialize_mcp_for_agents(
                        remaining_agents, 
                        session_id=session_id, 
                        credential_resolver=credential_resolver
                    )
                    
                    # Retry the pipeline with fresh toolsets
                    outputs, usage, model_by_agent, provider_by_agent = await _run_pipeline_async(
                        remaining_agents,
                        input_message,
                        session_id,
                        "action_agents_pipeline_retry",
                        pre_loaded_mcp_toolsets=fresh_mcp_toolsets,
                    )
                    logger.info("Action agents retry succeeded", extra={
                        "session_id": session_id, 
                        "agent_outputs": len(outputs)
                    })
                    _persist_agent_resources(session_id, outputs)
                    outputs.update(deterministic_outputs)
                    return outputs, usage, model_by_agent, provider_by_agent, input_message
                except Exception as retry_exc:
                    logger.error(
                        "Action agents retry also failed: %s",
                        str(retry_exc)[:200],
                        extra={"session_id": session_id},
                    )
                    raise
        raise
