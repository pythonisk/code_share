"""Disk-backed session storage service.

Owns the lifecycle of session directories under SESSION_STORAGE_DIR:
    session_storage/{session_id}/
        inputs/           — uploaded input files
        context_map_output.json
        agents/{agent_id}/output.md
        agents/{agent_id}/feedback/001/output.md
        reporter_agent_output.md
        quality_assessment_output.md
"""

from __future__ import annotations

from datetime import datetime
import json
import logging
import os
import shutil
from pathlib import Path
from typing import Any

from daan.core.config import get_settings

logger = logging.getLogger(__name__)

# Canonical session output filenames (single source of truth for readers/writers).
REPORTER_OUTPUT_FILENAME = "reporter_agent_output.md"
QUALITY_OUTPUT_FILENAME = "quality_assessment_output.md"
REFINEMENT_OUTPUT_FILENAME = "refinement_agent_output.md"

_rag_session_manager = None

CONTEXT_MAP_OUTPUT_PATH = "context_map_output.json"
CHAT_AGENT_MANIFEST_PATH = "chat/session_manifest.json"
CHAT_AGENT_MESSAGES_PATH = "chat/messages.jsonl"


def _get_rag_session_manager():
    """Lazily initialize RagSessionManager only when RAG is configured."""
    global _rag_session_manager
    if _rag_session_manager is not None:
        return _rag_session_manager

    settings = get_settings()
    rag_config = settings.load_rag_config()
    if not rag_config:
        return None

    try:
        from daan.rag.rag_session_manager import RagSessionManager

        _rag_session_manager = RagSessionManager(rag_config)
    except Exception as exc:
        logger.warning("RAG session manager unavailable: %s", exc)
        _rag_session_manager = None
    return _rag_session_manager


def init_rag_session(session_id: str) -> None:
    """Initialize per-session RAG stores when available."""
    manager = _get_rag_session_manager()
    if manager is None:
        return
    try:
        manager.create_session_store(session_id)
        rag_dir = _storage_root() / session_id / "rag"
        rag_dir.mkdir(parents=True, exist_ok=True)
    except Exception as exc:
        logger.warning("Failed to initialize RAG session '%s': %s", session_id, exc)


def cleanup_rag_session(session_id: str) -> None:
    """Cleanup per-session RAG stores when available."""
    manager = _get_rag_session_manager()
    if manager is None:
        return
    try:
        manager.destroy_session_store(session_id)
    except Exception as exc:
        logger.warning("Failed to cleanup RAG session '%s': %s", session_id, exc)


def _storage_root() -> Path:
    settings = get_settings()
    path = Path(settings.SESSION_STORAGE_DIR)
    if not path.is_absolute():
        project_root = Path(__file__).resolve().parents[3]
        path = project_root / path
    return path


def create_session_dir(session_id: str) -> Path:
    """Create session_storage/{session_id}/ and inputs/ subfolder. Returns session dir."""
    session_dir = _storage_root() / session_id
    inputs_dir = session_dir / "inputs"
    inputs_dir.mkdir(parents=True, exist_ok=True)
    init_rag_session(session_id)
    
    # Log to both system and session logs
    logger.debug("Created session directory: %s", session_dir, extra={"session_id": session_id})
    return session_dir


def get_session_dir(session_id: str) -> Path | None:
    """Return session dir path if it exists, else None."""
    session_dir = _storage_root() / session_id
    if session_dir.is_dir():
        return session_dir
    return None


def list_session_dirs() -> list[Path]:
    """Return all session directories under session storage."""
    root = _storage_root()
    if not root.is_dir():
        return []
    return sorted(path for path in root.iterdir() if path.is_dir())


def get_inputs_dir(session_id: str) -> Path:
    """Return the inputs/ subfolder for a session."""
    return _storage_root() / session_id / "inputs"


def _normalize_context_map_payload(
    payload: dict[str, Any] | None,
    *,
    fallback_agents: list[dict[str, Any]] | None = None,
    fallback_usecase_details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    raw = payload if isinstance(payload, dict) else {}
    agents = raw.get("agents") if isinstance(raw.get("agents"), list) else list(fallback_agents or [])
    usecase_details = raw.get("usecase_details") if isinstance(raw.get("usecase_details"), dict) else dict(fallback_usecase_details or {})
    context_map = raw.get("context_map") if isinstance(raw.get("context_map"), dict) else {}
    dag = raw.get("dag")
    if not isinstance(dag, str):
        dag = str(usecase_details.get("dag") or "")
    token_usage = raw.get("token_usage") if isinstance(raw.get("token_usage"), dict) else {}
    return {
        "agents": agents,
        "usecase_details": usecase_details,
        "context_map": context_map,
        "dag": dag,
        "token_usage": token_usage,
    }


def get_context_map_output_path(session_id: str) -> Path:
    """Return the canonical session-level context artifact path."""
    return _storage_root() / session_id / CONTEXT_MAP_OUTPUT_PATH


def write_context_map_output(session_id: str, context_data: dict[str, Any]) -> str:
    """Write context_map_output.json to the session dir. Returns file path."""
    session_dir = _storage_root() / session_id
    session_dir.mkdir(parents=True, exist_ok=True)
    output_path = get_context_map_output_path(session_id)
    normalized_payload = _normalize_context_map_payload(context_data)
    output_path.write_text(json.dumps(normalized_payload, indent=2, default=str), encoding="utf-8")
    
    # Log to both system and session logs
    logger.info("Generated context map output", extra={"session_id": session_id})
    return str(output_path)


def write_json_artifact(session_id: str, relative_path: str, payload: dict[str, Any]) -> str:
    """Write a structured JSON artifact under a session directory."""
    session_dir = _storage_root() / session_id
    artifact_path = session_dir / relative_path
    artifact_path.parent.mkdir(parents=True, exist_ok=True)
    artifact_path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    logger.info(
        "Wrote session JSON artifact",
        extra={"session_id": session_id, "artifact_path": str(artifact_path)},
    )
    return str(artifact_path)


def read_json_artifact(session_id: str, relative_path: str, default: dict[str, Any] | None = None) -> dict[str, Any]:
    """Read a structured JSON artifact under a session directory."""
    try:
        artifact_path = _storage_root() / session_id / relative_path
        if not artifact_path.is_file():
            return dict(default or {})
        raw = artifact_path.read_text(encoding="utf-8")
        obj = json.loads(raw)
        return obj if isinstance(obj, dict) else dict(default or {})
    except Exception:
        return dict(default or {})


def append_jsonl_artifact(session_id: str, relative_path: str, record: dict[str, Any]) -> str:
    """Append one JSON line to a session artifact file."""
    session_dir = _storage_root() / session_id
    artifact_path = session_dir / relative_path
    artifact_path.parent.mkdir(parents=True, exist_ok=True)
    with open(artifact_path, "a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, default=str, ensure_ascii=False))
        handle.write("\n")
    logger.info(
        "Appended session JSONL artifact",
        extra={"session_id": session_id, "artifact_path": str(artifact_path)},
    )
    return str(artifact_path)


def read_jsonl_artifact(session_id: str, relative_path: str, *, limit: int = 200) -> list[dict[str, Any]]:
    """Read a session JSONL artifact best-effort."""
    try:
        artifact_path = _storage_root() / session_id / relative_path
        if not artifact_path.is_file():
            return []

        records: list[dict[str, Any]] = []
        with open(artifact_path, "r", encoding="utf-8") as handle:
            for raw_line in handle:
                if not raw_line.strip():
                    continue
                try:
                    item = json.loads(raw_line)
                except Exception:
                    continue
                if isinstance(item, dict):
                    records.append(item)

        if limit > 0:
            return records[-limit:]
        return records
    except Exception:
        return []


def write_chat_session_manifest(
    session_id: str,
    *,
    user_id: int | None,
    archetype: str,
    usecase_id: str,
    kb_id: str,
) -> str:
    existing = read_json_artifact(session_id, CHAT_AGENT_MANIFEST_PATH)
    created_at = str(existing.get("created_at") or "").strip() or datetime.utcnow().isoformat()
    return write_json_artifact(
        session_id,
        CHAT_AGENT_MANIFEST_PATH,
        {
            "mode": "chat_agent",
            "session_id": session_id,
            "user_id": user_id,
            "archetype": archetype,
            "usecase_id": usecase_id,
            "kb_id": kb_id,
            "context_artifact_path": CONTEXT_MAP_OUTPUT_PATH,
            "created_at": created_at,
            "updated_at": datetime.utcnow().isoformat(),
        },
    )


def read_chat_session_manifest(session_id: str) -> dict[str, Any]:
    manifest = read_json_artifact(session_id, CHAT_AGENT_MANIFEST_PATH)
    if str(manifest.get("mode") or "").strip() != "chat_agent":
        return {}
    return manifest


def append_chat_session_message(
    session_id: str,
    *,
    role: str,
    content: str,
    usecase_id: str | None = None,
    kb_id: str | None = None,
    references: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> str:
    return append_jsonl_artifact(
        session_id,
        CHAT_AGENT_MESSAGES_PATH,
        {
            "timestamp": datetime.utcnow().isoformat(),
            "session_id": session_id,
            "usecase_id": usecase_id,
            "kb_id": kb_id,
            "role": role,
            "content": content,
            "references": list(references or []),
            "metadata": dict(metadata or {}) if isinstance(metadata, dict) else None,
        },
    )


def read_chat_session_messages(session_id: str, *, limit: int = 200) -> list[dict[str, Any]]:
    return read_jsonl_artifact(session_id, CHAT_AGENT_MESSAGES_PATH, limit=limit)


def read_context_map_output(session_id: str) -> dict[str, Any]:
    """Read context_map_output.json for a session (best-effort).

    Returns an empty dict when missing/unreadable.
    """
    try:
        path = get_context_map_output_path(session_id)
        if not path.is_file():
            return _normalize_context_map_payload({})
        raw = path.read_text(encoding="utf-8")
        obj = json.loads(raw)
        return _normalize_context_map_payload(obj)
    except Exception:
        return _normalize_context_map_payload({})


def ensure_context_map_output(
    session_id: str,
    *,
    agents: list[dict[str, Any]],
    usecase_details: dict[str, Any],
) -> dict[str, Any]:
    """Return the canonical session-level context artifact, creating an empty one when absent."""
    path = get_context_map_output_path(session_id)
    if path.is_file():
        return read_context_map_output(session_id)

    payload = _normalize_context_map_payload(
        {
            "agents": agents,
            "usecase_details": usecase_details,
            "context_map": {},
        },
        fallback_agents=agents,
        fallback_usecase_details=usecase_details,
    )
    write_context_map_output(session_id, payload)
    return payload


def get_session_log_path(session_id: str) -> Path:
    """Return the path to session_storage/<session_id>/session.log.

    Raises ValueError for invalid session_id, and FileNotFoundError if missing.
    """

    sid = (session_id or "").strip()
    if not sid:
        raise ValueError("session_id is required")

    # Prevent path traversal and odd inputs.
    if Path(sid).name != sid:
        raise ValueError("invalid session_id")

    path = _storage_root() / sid / "session.log"
    if not path.exists() or not path.is_file():
        raise FileNotFoundError("session.log not found")
    return path


def read_session_log_tail(session_id: str, tail_lines: int = 200) -> tuple[list[str], bool]:
    """Read the last N lines from a session's session.log.

    Returns (lines, truncated) where truncated=True indicates there were more
    lines in the file than returned.
    """

    limit = int(tail_lines or 0)
    if limit < 1:
        limit = 1
    if limit > 2000:
        limit = 2000

    path = get_session_log_path(session_id)

    # Efficient tail reading: read backwards in chunks until enough newlines.
    chunk_size = 8192
    buf = b""
    truncated = False

    with open(path, "rb") as f:
        f.seek(0, os.SEEK_END)
        pos = f.tell()

        while pos > 0 and buf.count(b"\n") <= limit:
            read_size = chunk_size if pos >= chunk_size else pos
            pos -= read_size
            f.seek(pos)
            chunk = f.read(read_size)
            buf = chunk + buf

            # Bound buffer growth in worst-case files with huge lines.
            if len(buf) > 5_000_000:  # 5MB cap
                truncated = True
                break

        if pos > 0:
            truncated = True

    # Split and decode.
    raw_lines = buf.splitlines()
    raw_lines = raw_lines[-limit:]
    lines = [b.decode("utf-8", errors="replace") for b in raw_lines]

    return lines, truncated


def read_session_log(session_id: str, *, max_bytes: int = 25_000_000) -> tuple[list[str], bool]:
    """Read the entire session.log for a session.

    Returns (lines, truncated) where truncated=True indicates the file exceeded
    max_bytes and was cut.

    Note: returning the entire file can be large; max_bytes provides a safety cap.
    """

    if max_bytes < 1:
        max_bytes = 1

    path = get_session_log_path(session_id)

    with open(path, "rb") as f:
        data = f.read(int(max_bytes) + 1)

    truncated = len(data) > int(max_bytes)
    if truncated:
        data = data[: int(max_bytes)]

    raw_lines = data.splitlines()
    lines = [b.decode("utf-8", errors="replace") for b in raw_lines]
    return lines, truncated


def write_agent_output(
    session_id: str,
    agent_id: str,
    content: str,
    *,
    feedback_seq: int | None = None,
) -> str:
    """Write an agent output file for a session.

    Storage layout:
    - Base output:    session_storage/{session_id}/agents/{agent_id}/output.md
    - Feedback output: session_storage/{session_id}/agents/{agent_id}/feedback/00N/output.md

    Returns the absolute file path.
    """
    session_dir = _storage_root() / session_id
    session_dir.mkdir(parents=True, exist_ok=True)

    safe_agent_id = (agent_id or "").strip().replace("/", "_").replace("\\", "_") or "unknown_agent"

    if feedback_seq is not None:
        seq = int(feedback_seq)
        if seq < 1:
            seq = 1
        feedback_dir = session_dir / "agents" / safe_agent_id / "feedback" / f"{seq:03d}"
        feedback_dir.mkdir(parents=True, exist_ok=True)
        output_path = feedback_dir / "output.md"
    else:
        agent_dir = session_dir / "agents" / safe_agent_id
        agent_dir.mkdir(parents=True, exist_ok=True)
        output_path = agent_dir / "output.md"

    output_path.write_text(content, encoding="utf-8")
    
    # Log to both system and session logs
    logger.info("Saved agent output", extra={"session_id": session_id})
    return str(output_path)


# ── Proposal (draft) helpers for review-based edits ──────────────────────────
#
# A "proposal" is a non-destructive suggested edit to an agent's current output
# — analogous to a Copilot suggestion or a pending diff. It lives alongside
# ``output.md`` as ``proposal.md`` (content) and ``proposal.json`` (metadata:
# feedback text + timestamp). The original ``output.md`` is untouched until
# the user explicitly promotes the proposal via the Keep endpoint, at which
# point ``output.md`` is replaced and the proposal files are removed. Discard
# (Undo) simply deletes the proposal files.

def _agent_dir(session_id: str, agent_id: str) -> Path:
    safe_agent_id = (agent_id or "").strip().replace("/", "_").replace("\\", "_") or "unknown_agent"
    return _storage_root() / session_id / "agents" / safe_agent_id


def write_agent_proposal(
    session_id: str,
    agent_id: str,
    content: str,
    feedback_text: str,
) -> str:
    """Persist a suggested-edit proposal alongside the agent's current output.

    The proposal replaces any previous unresolved proposal for the same agent.
    Returns the absolute proposal file path.
    """
    from datetime import datetime, timezone

    agent_dir = _agent_dir(session_id, agent_id)
    agent_dir.mkdir(parents=True, exist_ok=True)
    proposal_path = agent_dir / "proposal.md"
    metadata_path = agent_dir / "proposal.json"
    proposal_path.write_text(content or "", encoding="utf-8")
    metadata = {
        "agent_id": agent_id,
        "feedback_text": feedback_text or "",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    metadata_path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    logger.info("Wrote agent proposal", extra={"session_id": session_id})
    return str(proposal_path)


def read_agent_proposal(session_id: str, agent_id: str) -> dict[str, Any] | None:
    """Return ``{content, feedback_text, created_at}`` for the pending proposal
    on ``agent_id`` or ``None`` when no proposal exists."""
    agent_dir = _agent_dir(session_id, agent_id)
    proposal_path = agent_dir / "proposal.md"
    metadata_path = agent_dir / "proposal.json"
    if not proposal_path.is_file():
        return None
    try:
        content = proposal_path.read_text(encoding="utf-8")
    except Exception:
        return None
    meta: dict[str, Any] = {}
    if metadata_path.is_file():
        try:
            meta = json.loads(metadata_path.read_text(encoding="utf-8")) or {}
        except Exception:
            meta = {}
    return {
        "content": content,
        "feedback_text": str(meta.get("feedback_text") or ""),
        "created_at": str(meta.get("created_at") or ""),
    }


def delete_agent_proposal(session_id: str, agent_id: str) -> bool:
    """Delete the pending proposal files for ``agent_id``. Returns True when
    at least one file was removed."""
    agent_dir = _agent_dir(session_id, agent_id)
    removed = False
    for name in ("proposal.md", "proposal.json"):
        path = agent_dir / name
        if path.is_file():
            try:
                path.unlink()
                removed = True
            except Exception:
                logger.warning("Failed to delete proposal file %s", path)
    return removed


def list_agent_proposals(session_id: str) -> list[dict[str, Any]]:
    """Return one entry per agent that currently has an unresolved proposal.

    Shape per entry::

        {
          "agent_id": str,
          "current_output": str,   # the current output.md contents (or latest feedback rerun)
          "proposed_output": str,  # the proposed replacement contents
          "feedback_text": str,
          "created_at": str,
        }
    """
    agents_root = _storage_root() / session_id / "agents"
    if not agents_root.is_dir():
        return []
    # Reuse read_run_deliverables to compute the "current" (latest) output per
    # agent, so proposals diff against the right baseline even after prior
    # feedback rounds.
    baseline_by_agent: dict[str, str] = {}
    try:
        for d in read_run_deliverables(session_id):
            aid = str(d.get("agent_id") or "").strip()
            if aid:
                baseline_by_agent[aid] = str(d.get("final_output") or d.get("base_output") or "")
    except Exception:
        baseline_by_agent = {}

    entries: list[dict[str, Any]] = []
    for agent_dir in sorted(p for p in agents_root.iterdir() if p.is_dir()):
        agent_id = agent_dir.name
        proposal = read_agent_proposal(session_id, agent_id)
        if not proposal:
            continue
        entries.append({
            "agent_id": agent_id,
            "current_output": baseline_by_agent.get(agent_id, ""),
            "proposed_output": proposal["content"],
            "feedback_text": proposal["feedback_text"],
            "created_at": proposal["created_at"],
        })
    return entries



    """Return a filesystem-safe filename (no path traversal)."""
    name = (filename or "").strip().replace("\\", "/")
    # Keep only basename
    name = name.split("/")[-1]
    if not name:
        return "uploaded_file"
    # Basic cleanup
    return name.replace("..", "_")


def _agent_feedback_dir(session_id: str, safe_agent_id: str, feedback_seq: int) -> Path:
    session_dir = _storage_root() / session_id
    session_dir.mkdir(parents=True, exist_ok=True)
    seq = int(feedback_seq)
    if seq < 1:
        seq = 1
    feedback_dir = session_dir / "agents" / safe_agent_id / "feedback" / f"{seq:03d}"
    feedback_dir.mkdir(parents=True, exist_ok=True)
    return feedback_dir


def write_agent_score(
    session_id: str,
    agent_id: str,
    score: dict[str, Any],
    *,
    feedback_seq: int | None = None,
) -> str:
    """Write an agent scoring payload as JSON.

    Storage layout:
    - Base score:     session_storage/{session_id}/agents/{agent_id}/score.json
    - Feedback score: session_storage/{session_id}/agents/{agent_id}/feedback/00N/score.json

    Returns the absolute file path.
    """

    session_dir = _storage_root() / session_id
    session_dir.mkdir(parents=True, exist_ok=True)
    safe_agent_id = (agent_id or "").strip().replace("/", "_").replace("\\", "_") or "unknown_agent"

    if feedback_seq is not None:
        feedback_dir = _agent_feedback_dir(session_id, safe_agent_id, int(feedback_seq))
        path = feedback_dir / "score.json"
    else:
        agent_dir = session_dir / "agents" / safe_agent_id
        agent_dir.mkdir(parents=True, exist_ok=True)
        path = agent_dir / "score.json"

    try:
        path.write_text(json.dumps(score or {}, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    except Exception:
        # Best-effort: if serialization fails, still write a minimal placeholder.
        path.write_text(json.dumps({"summary": "score serialization failed"}, indent=2), encoding="utf-8")

    logger.info("Agent evaluation complete", extra={"session_id": session_id})
    return str(path)


def read_agent_score(
    session_id: str,
    agent_id: str,
    *,
    feedback_seq: int | None = None,
) -> dict[str, Any] | None:
    """Read an agent score JSON payload (base or feedback)."""

    safe_agent_id = (agent_id or "").strip().replace("/", "_").replace("\\", "_") or "unknown_agent"
    session_dir = _storage_root() / session_id

    if feedback_seq is not None:
        path = session_dir / "agents" / safe_agent_id / "feedback" / f"{int(feedback_seq):03d}" / "score.json"
    else:
        path = session_dir / "agents" / safe_agent_id / "score.json"

    if not path.exists() or not path.is_file():
        return None

    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def write_feedback_sample_file(
    session_id: str,
    agent_id: str,
    feedback_seq: int,
    filename: str,
    content: bytes,
) -> str:
    """Persist a raw user-provided sample output file next to the feedback rerun artifacts."""

    safe_agent_id = (agent_id or "").strip().replace("/", "_").replace("\\", "_") or "unknown_agent"
    feedback_dir = _agent_feedback_dir(session_id, safe_agent_id, int(feedback_seq))
    sample_dir = feedback_dir / "sample_output"
    sample_dir.mkdir(parents=True, exist_ok=True)

    safe_name = _safe_filename(filename)
    path = sample_dir / safe_name
    path.write_bytes(content or b"")

    logger.debug(
        "Wrote feedback sample output file for %s (%s)",
        safe_agent_id,
        path,
        extra={"session_id": session_id},
    )
    return str(path)


def write_feedback_sample_schema(
    session_id: str,
    agent_id: str,
    feedback_seq: int,
    schema: dict[str, Any],
) -> str:
    """Persist extracted sample schema JSON next to feedback rerun artifacts."""

    safe_agent_id = (agent_id or "").strip().replace("/", "_").replace("\\", "_") or "unknown_agent"
    feedback_dir = _agent_feedback_dir(session_id, safe_agent_id, int(feedback_seq))
    path = feedback_dir / "sample_schema.json"
    path.write_text(json.dumps(schema or {}, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

    logger.debug(
        "Wrote feedback sample schema for %s (%s)",
        safe_agent_id,
        path,
        extra={"session_id": session_id},
    )
    return str(path)


def write_feedback_text(
    session_id: str,
    agent_id: str,
    feedback_seq: int,
    feedback_text: str,
) -> str:
    """Persist user-provided feedback text next to feedback rerun artifacts.

    Storage layout:
        session_storage/{session_id}/agents/{agent_id}/feedback/00N/feedback.txt

    Note: This function intentionally does NOT log the feedback body.
    """

    safe_agent_id = (agent_id or "").strip().replace("/", "_").replace("\\", "_") or "unknown_agent"
    feedback_dir = _agent_feedback_dir(session_id, safe_agent_id, int(feedback_seq))
    path = feedback_dir / "feedback.txt"

    text = str(feedback_text or "")
    max_chars = 200_000
    if len(text) > max_chars:
        text = text[:max_chars] + "\n\n[...truncated...]"

    path.write_text(text, encoding="utf-8")

    logger.debug(
        "Wrote feedback text for %s (%s)",
        safe_agent_id,
        path,
        extra={"session_id": session_id, "feedback_seq": int(feedback_seq), "feedback_length": len(feedback_text or "")},
    )
    return str(path)


def write_reporter_output(session_id: str, content: str) -> str:
    """Write the reporter output to the session dir. Returns file path."""
    session_dir = _storage_root() / session_id
    session_dir.mkdir(parents=True, exist_ok=True)
    output_path = session_dir / REPORTER_OUTPUT_FILENAME
    output_path.write_text(content, encoding="utf-8")
    # Log to both system and session logs
    logger.info("Generated agent report", extra={"session_id": session_id})
    return str(output_path)


def write_quality_output(session_id: str, content: str) -> str:
    """Write the quality assessment output to the session dir. Returns file path."""
    session_dir = _storage_root() / session_id
    session_dir.mkdir(parents=True, exist_ok=True)
    output_path = session_dir / QUALITY_OUTPUT_FILENAME
    output_path.write_text(content, encoding="utf-8")
    logger.info("Quality assessment complete", extra={"session_id": session_id})
    return str(output_path)


def write_refinement_output(session_id: str, content: str) -> str:
    """Write the refinement output to the session dir. Returns file path."""
    session_dir = _storage_root() / session_id
    session_dir.mkdir(parents=True, exist_ok=True)
    output_path = session_dir / REFINEMENT_OUTPUT_FILENAME
    output_path.write_text(content, encoding="utf-8")
    logger.info("Refinement complete", extra={"session_id": session_id})
    return str(output_path)

def write_session_token_usage(session_id: str, token_usage: dict[str, Any]) -> str:
    """Write session_token_usage.json to the session dir. Returns file path."""
    session_dir = _storage_root() / session_id
    session_dir.mkdir(parents=True, exist_ok=True)
    output_path = session_dir / "session_token_usage.json"
    output_path.write_text(json.dumps(token_usage, indent=2, default=str), encoding="utf-8")
    logger.info("Token usage tracked", extra={"session_id": session_id})
    return str(output_path)

def read_session_file(session_id: str, filename: str) -> str | None:
    """Read a file from the session dir. Returns content or None if not found."""
    session_dir = _storage_root() / session_id
    file_path = session_dir / filename
    # Guard against path traversal
    if not file_path.resolve().is_relative_to(session_dir.resolve()):
        return None
    if file_path.is_file():
        return file_path.read_text(encoding="utf-8")
    return None


def read_run_deliverables(session_id: str) -> list[dict[str, Any]]:
    """Return each agent's deliverable output for a finished run (from disk).

    For every ``agents/{agent_id}/`` directory this returns the base output and,
    when present, the post-feedback reruns (each with the feedback text that was
    provided and the regenerated output).  ``final_output`` is the most recent
    output for the agent (the latest feedback rerun if any, else the base).

    Shape per agent::

        {
          "agent_id": str,
          "base_output": str,
          "final_output": str,
          "feedback": [{"seq": int, "feedback_text": str, "output": str}],
        }
    """
    agents_dir = _storage_root() / session_id / "agents"
    if not agents_dir.is_dir():
        return []

    deliverables: list[dict[str, Any]] = []
    # Order agents by execution order (earliest produced first) using the base
    # output.md modification time, so the UI shows agents in the sequence they
    # actually ran rather than alphabetically by agent_id.
    def _exec_order(agent_dir: Path) -> float:
        base = agent_dir / "output.md"
        try:
            if base.is_file():
                return base.stat().st_mtime
            return agent_dir.stat().st_mtime
        except Exception:
            return float("inf")

    for agent_dir in sorted((p for p in agents_dir.iterdir() if p.is_dir()), key=_exec_order):
        agent_id = agent_dir.name

        base_output = ""
        base_path = agent_dir / "output.md"
        if base_path.is_file():
            try:
                base_output = base_path.read_text(encoding="utf-8")
            except Exception:
                base_output = ""

        def _mtime(p: Path) -> float:
            try:
                return p.stat().st_mtime if p.is_file() else -1.0
            except Exception:
                return -1.0

        feedback_items: list[dict[str, Any]] = []
        # Track the newest artifact so ``final_output`` reflects what actually
        # landed last, not simply the highest feedback seq (see note below).
        newest_output = base_output
        newest_mtime = _mtime(base_path)
        feedback_root = agent_dir / "feedback"
        if feedback_root.is_dir():
            for seq_dir in sorted(p for p in feedback_root.iterdir() if p.is_dir()):
                try:
                    seq = int(seq_dir.name)
                except ValueError:
                    continue
                fb_text = ""
                fb_text_path = seq_dir / "feedback.txt"
                if fb_text_path.is_file():
                    try:
                        fb_text = fb_text_path.read_text(encoding="utf-8")
                    except Exception:
                        fb_text = ""
                fb_output = ""
                fb_output_path = seq_dir / "output.md"
                if fb_output_path.is_file():
                    try:
                        fb_output = fb_output_path.read_text(encoding="utf-8")
                    except Exception:
                        fb_output = ""
                if fb_output and _mtime(fb_output_path) >= newest_mtime:
                    newest_output = fb_output
                    newest_mtime = _mtime(fb_output_path)
                feedback_items.append({
                    "seq": seq,
                    "feedback_text": fb_text,
                    "output": fb_output,
                })

        feedback_items.sort(key=lambda f: f["seq"])
        # ``final_output`` is the MOST RECENTLY WRITTEN artifact (by mtime), not
        # blindly the highest feedback seq. The base ``output.md`` can be newer
        # than a feedback rerun when the action agent is re-run via
        # ``/run-action-agents`` AFTER a feedback revision was recorded — in that
        # case the older feedback file would otherwise shadow the real latest
        # output and show resources that were since removed from the external
        # system.
        final_output = newest_output or base_output

        deliverables.append({
            "agent_id": agent_id,
            "base_output": base_output,
            "final_output": final_output,
            "feedback": feedback_items,
        })

    return deliverables



def get_artifacts_dir(session_id: str, *, create: bool = False) -> Path:
    """Return the artifacts/ directory for a session.

    Args:
        session_id: Session UUID.
        create: If True, create the directory if it doesn't exist.

    Returns:
        Path to session_storage/{session_id}/artifacts/
    """
    artifacts_dir = _storage_root() / session_id / "artifacts"
    if create:
        artifacts_dir.mkdir(parents=True, exist_ok=True)
    return artifacts_dir


def list_artifact_files(session_id: str) -> list[Path]:
    """Recursively list all files inside the session's artifacts/ dir."""
    artifacts_dir = get_artifacts_dir(session_id)
    if not artifacts_dir.is_dir():
        return []
    return sorted(p for p in artifacts_dir.rglob("*") if p.is_file())


def list_session_files(session_id: str) -> list[str]:
    """List all files (non-recursively) in the session dir."""
    session_dir = _storage_root() / session_id
    if not session_dir.is_dir():
        return []
    return [f.name for f in session_dir.iterdir() if f.is_file()]


def delete_session_dir(session_id: str) -> None:
    """Remove an entire session directory."""
    cleanup_rag_session(session_id)
    session_dir = _storage_root() / session_id
    if session_dir.is_dir():
        shutil.rmtree(str(session_dir))
