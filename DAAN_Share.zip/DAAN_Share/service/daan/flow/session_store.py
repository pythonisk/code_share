"""In-memory session store for multi-step workflow execution."""

from __future__ import annotations

import logging
import threading
from datetime import datetime
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)

from daan.agents.agent_type_utils import is_action_agent, is_chat_agent, is_dynamic_agent


class SessionState(str, Enum):
    INITIALIZED = "INITIALIZED"
    CONTEXT_MAPPED = "CONTEXT_MAPPED"
    AGENTS_RUNNING = "AGENTS_RUNNING"
    PARALLEL_AGENTS_RUNNING = "PARALLEL_AGENTS_RUNNING"
    AGENTS_DONE = "AGENTS_DONE"
    ACTIONS_RUNNING = "ACTIONS_RUNNING"
    ACTIONS_DONE = "ACTIONS_DONE"
    REFINING = "REFINING"
    REFINED = "REFINED"
    REPORTING = "REPORTING"
    REPORT_DONE = "REPORT_DONE"
    QUALITY_CHECK = "QUALITY_CHECK"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class WorkflowSession:
    """Holds all state for one workflow execution."""

    __slots__ = (
        "session_id",
        "user_id",
        "archetype",
        "usecase_id",
        "_state",
        "context_map_result",
        "base_dynamic_agent_outputs",
        "dynamic_agent_outputs",
        "dynamic_agent_output_paths",
        "action_agent_outputs",
        "action_agent_output_paths",
        "refinement_output",
        "refinement_output_path",
        "refinement_skipped",
        "refinement_scores",
        "feedback_count",
        "max_feedback",
        "feedback_seq_by_agent",
        "latest_feedback_id_by_agent",
        "latest_rerun_id_by_agent",
        "latest_report",
        "reporter_output_path",
        "latest_quality_assessment",
        "action_stage_quality_assessment",
        "dynamic_stage_quality_assessment",
        "quality_output_path",
        "context_map_output_path",
        "loop_progress",
        "agent_cost_records",
        "total_prompt_tokens",
        "total_completion_tokens",
        "total_tokens",
        "total_cost_usd",
        "provider_cost_totals",
        "created_at",
        "updated_at",
        "error",
    )

    def __init__(
        self,
        session_id: str,
        user_id: int | None,
        archetype: str,
        usecase_id: str,
        context_map_result: dict[str, Any] | None = None,
    ) -> None:
        self.session_id = session_id
        self.user_id = user_id
        self.archetype = archetype
        self.usecase_id = usecase_id
        self._state = SessionState.INITIALIZED
        self.context_map_result: dict[str, Any] = context_map_result or {}
        self.base_dynamic_agent_outputs: dict[str, str] = {}
        self.dynamic_agent_outputs: dict[str, str] = {}
        self.dynamic_agent_output_paths: dict[str, str] = {}
        self.action_agent_outputs: dict[str, str] = {}
        self.action_agent_output_paths: dict[str, str] = {}
        self.refinement_output: str | None = None
        self.refinement_output_path: str | None = None
        self.refinement_skipped: bool = False
        self.refinement_scores: dict[str, Any] | None = None
        self.feedback_count: int = 0
        self.max_feedback: int = 3
        self.feedback_seq_by_agent: dict[str, int] = {}
        self.latest_feedback_id_by_agent: dict[str, str] = {}
        self.latest_rerun_id_by_agent: dict[str, str] = {}
        self.latest_report: str | None = None
        self.reporter_output_path: str | None = None
        self.latest_quality_assessment: str | None = None
        self.action_stage_quality_assessment: str | None = None
        self.dynamic_stage_quality_assessment: str | None = None
        self.quality_output_path: str | None = None
        self.context_map_output_path: str | None = None
        self.loop_progress: dict = {}  # {current_batch, batch_size, agent_id}
        self.agent_cost_records: dict[str, list[dict[str, Any]]] = {}
        self.total_prompt_tokens: int = 0
        self.total_completion_tokens: int = 0
        self.total_tokens: int = 0
        self.total_cost_usd: float = 0.0
        self.provider_cost_totals: dict[str, float] = {}
        self.created_at: str = datetime.utcnow().isoformat()
        self.updated_at: str = self.created_at
        self.error: str | None = None
        
        logger.info("Workflow session initialized, SessionId: %s", session_id, extra={
            "session_id": session_id,
            "user_id": user_id,
            "has_context_map": bool(context_map_result)
        })

    @property
    def state(self) -> SessionState:
        return self._state
        
    @state.setter
    def state(self, new_state: SessionState) -> None:
        if self._state != new_state:
            old_state = self._state
            self._state = new_state
            self.touch()
            
            logger.info("Session state changed from %s to %s", old_state.value, new_state.value, extra={
                "session_id": self.session_id
            })

    def touch(self) -> None:
        self.updated_at = datetime.utcnow().isoformat()
        
        logger.debug("Session state updated to %s", self.state.value, extra={
            "session_id": self.session_id
        })

    @property
    def plan_result(self) -> dict[str, Any]:
        """Backward-compatible alias for context_map_result."""
        return self.context_map_result

    @plan_result.setter
    def plan_result(self, value: dict[str, Any]) -> None:
        self.context_map_result = value

    def get_dynamic_agents(self) -> list[dict[str, Any]]:
        """Return all dynamic agents."""
        return [
            a
            for a in self.context_map_result.get("agents", [])
            if is_dynamic_agent(a.get("agent_type"))
        ]

    def get_action_agents(self) -> list[dict[str, Any]]:
        """Return all action agents."""
        return [
            a
            for a in self.context_map_result.get("agents", [])
            if is_action_agent(a.get("agent_type"))
        ]

    def get_chat_agents(self) -> list[dict[str, Any]]:
        """Return all chat agents."""
        return [
            a
            for a in self.context_map_result.get("agents", [])
            if is_chat_agent(a.get("agent_type"))
        ]

    def get_agent_config(self, agent_id: str) -> dict[str, Any] | None:
        agent_id = (agent_id or "").strip()
        if not agent_id:
            return None

        for agent_cfg in self.context_map_result.get("agents", []):
            if str(agent_cfg.get("agent_id") or "").strip() == agent_id:
                return agent_cfg
        return None
    
    def record_agent_cost(self, agent_id: str, record: dict[str, Any]) -> None:
        """Append one cost record and update session-level totals."""
        aid = (agent_id or "").strip() or "unknown_agent"
        records = self.agent_cost_records.setdefault(aid, [])
        records.append(record)

        prompt_tokens = int(record.get("prompt_tokens") or 0)
        completion_tokens = int(record.get("completion_tokens") or 0)
        total_tokens = int(record.get("total_tokens") or (prompt_tokens + completion_tokens))
        cost_usd = record.get("cost_usd")

        self.total_prompt_tokens += max(prompt_tokens, 0)
        self.total_completion_tokens += max(completion_tokens, 0)
        self.total_tokens += max(total_tokens, 0)

        if cost_usd is not None:
            amount = float(cost_usd)
            self.total_cost_usd += amount
            provider = str(record.get("provider") or "unknown").strip() or "unknown"
            self.provider_cost_totals[provider] = self.provider_cost_totals.get(provider, 0.0) + amount

        logger.info("Agent tokens recorded ,Input tokens: %d, Output tokens: %d, provider: %s, run_type: %s", prompt_tokens, completion_tokens, str(record.get("provider") or "unknown"), str(record.get("run_type") or "unknown"), extra={
            "session_id": self.session_id,
            "user_id": self.user_id,
            "usecase_id": self.usecase_id,
            "model": record.get("model"),
        })

        try:
            from daan.token_usage.persistence import persist_token_usage_event

            persist_token_usage_event(session=self, record=record)
        except Exception as exc:
            logger.warning(
                "Token usage event persistence hook failed: %s",
                exc,
                extra={"session_id": self.session_id, "user_id": self.user_id, "usecase_id": self.usecase_id},
            )
        
        self.touch()


    def to_dict(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "user_id": self.user_id,
            "archetype": self.archetype,
            "usecase_id": self.usecase_id,
            "state": self._state.value,
            "feedback_count": self.feedback_count,
            "max_feedback": self.max_feedback,
            "base_dynamic_agent_outputs": self.base_dynamic_agent_outputs,
            "dynamic_agent_outputs": self.dynamic_agent_outputs,
            "dynamic_agent_output_paths": self.dynamic_agent_output_paths,
            "action_agent_outputs": self.action_agent_outputs,
            "action_agent_output_paths": self.action_agent_output_paths,
            "refinement_output_path": self.refinement_output_path,
            "refinement_skipped": self.refinement_skipped,
            "latest_feedback_id_by_agent": self.latest_feedback_id_by_agent,
            "latest_rerun_id_by_agent": self.latest_rerun_id_by_agent,
            "reporter_output_path": self.reporter_output_path,
            "quality_output_path": self.quality_output_path,
            "context_map_output_path": self.context_map_output_path,
            "loop_progress": self.loop_progress,
            "agent_cost_records": self.agent_cost_records,
            "total_prompt_tokens": self.total_prompt_tokens,
            "total_completion_tokens": self.total_completion_tokens,
            "total_tokens": self.total_tokens,
            "total_cost_usd": self.total_cost_usd,
            "provider_cost_totals": self.provider_cost_totals,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "error": self.error,
        }


# ── Global store (thread-safe) ─────────────────────────────────────────

_lock = threading.Lock()
_sessions: dict[str, WorkflowSession] = {}


def create_session(
    session_id: str,
    archetype: str,
    usecase_id: str,
    user_id: int | None = None,
    context_map_result: dict[str, Any] | None = None,
    # Backward-compatible alias
    plan_result: dict[str, Any] | None = None,
) -> WorkflowSession:
    effective = context_map_result or plan_result or {}
    
    logger.debug("Creating workflow session for usecase %s , SessionId: %s", usecase_id, session_id, extra={
        "session_id": session_id,
        "user_id": user_id,
        "has_context_map": bool(effective)
    })
    
    with _lock:
        session = WorkflowSession(session_id, user_id, archetype, usecase_id, effective)
        _sessions[session_id] = session
        
        logger.debug("Session created in store", extra={
            "session_id": session_id,
            "total_sessions": len(_sessions)
        })
        return session


def get_session(session_id: str) -> WorkflowSession | None:
    logger.debug("Session access requested", extra={
        "session_id": session_id
    })
    
    with _lock:
        session = _sessions.get(session_id)
        
        if session:
            logger.debug("Session found", extra={
                "session_id": session_id,
                "state": session.state.value,
                "archetype": session.archetype
            })
        else:
            logger.warning("Session not found", extra={
                "session_id": session_id,
                "available_sessions": len(_sessions)
            })
            
        return session


def delete_session(session_id: str) -> None:
    logger.info("Deleting session", extra={
        "session_id": session_id
    })
    
    with _lock:
        session = _sessions.pop(session_id, None)
        
        if session:
            logger.info("Session deleted from store", extra={
                "session_id": session_id,
                "remaining_sessions": len(_sessions),
                "final_state": session.state.value,
                "total_cost_usd": session.total_cost_usd,
                "total_tokens": session.total_tokens
            })
        else:
            logger.warning("Session deletion attempted but not found", extra={
                "session_id": session_id
            })
