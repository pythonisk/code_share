"""
Workflow pipeline factory for ADK agent orchestration.
Accepts agent configurations from API (no YAML file dependency).
"""

import re
from typing import Any

from google.adk.agents.sequential_agent import SequentialAgent

from daan.agents.dynamic_builders.dynamic_adk_agent import create_adk_agent


def _safe_name(value: str) -> str:
    """Convert a string to a safe identifier name."""
    candidate = re.sub(r"\W+", "_", value or "workflow_agent")
    if not candidate:
        candidate = "workflow_agent"
    if not candidate[0].isalpha() and candidate[0] != "_":
        candidate = f"_{candidate}"
    return candidate


def _parse_depends_on(value: str | list | None) -> list[str]:
    """Parse depends_on field from string or list format."""
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if v]
    
    value_str = str(value).strip()
    if not value_str or value_str in ('[]', ''):
        return []
    
    # Remove surrounding brackets if present
    if value_str.startswith('[') and value_str.endswith(']'):
        value_str = value_str[1:-1]
    
    return [item.strip() for item in value_str.split(',') if item.strip()]


def _validate_agent_dependencies(agents: list[dict[str, Any]]) -> None:
    """
    Validate that agent dependencies are satisfied in sequential order.
    
    Args:
        agents: List of agent configs with agent_id and depends_on fields
    """
    known_agent_ids = []
    for agent in agents:
        agent_id = agent.get("agent_id")
        if agent_id:
            if agent_id in known_agent_ids:
                raise ValueError(f"Duplicate agent_id found in pipeline: {agent_id}")
            known_agent_ids.append(agent_id)

    completed = set()
    agent_ids_in_list = {a.get("agent_id") for a in agents if a.get("agent_id")}
    
    for agent in agents:
        agent_id = agent.get("agent_id")
        depends_on = _parse_depends_on(agent.get("depends_on"))
        
        # Only validate dependencies that are actually part of this pipeline batch
        missing = [dep for dep in depends_on if dep in agent_ids_in_list and dep not in completed]
        if missing:
            label = agent_id or agent.get("agent_name") or "<unknown-agent>"
            raise ValueError(
                f"Pipeline agent '{label}' depends on agents not yet completed: {missing}. "
                "Reorder agents or fix depends_on."
            )
        if agent_id:
            completed.add(agent_id)


def create_pipeline_agent(
    session_id: str,
    agents: list[dict[str, Any]],
    pipeline_name: str = "Workflow Agent",
    pipeline_description: str | None = None,
    pre_loaded_mcp_toolsets: dict[str, Any] | None = None,
    tool_kwargs: dict[str, Any] | None = None,
) -> SequentialAgent:
    """
    Create a sequential pipeline agent from a list of agent configurations.
    
    Args:
        agents: List of agent config dicts from API (UseCaseAgentPromptResponse format):
            - agent_id: str
            - agent_name: str
            - prompt: str (the actual prompt content)
            - mcp_tools: str | list
            - local_tools: str | list
            - depends_on: str | list
            - output: str (output format key)
            - provider: str (optional)
        pipeline_name: Name for the pipeline agent
        pipeline_description: Description for the pipeline
        pre_loaded_mcp_toolsets: Pre-loaded MCP toolsets keyed by requested MCP server name
        tool_kwargs: Optional kwargs to pass to instantiated tools
    
    Returns:
        Configured SequentialAgent instance
    """
    tool_kwargs = tool_kwargs or {}
    if not agents:
        raise ValueError("Pipeline must include at least one agent")

    _validate_agent_dependencies(agents)

    print(f"Creating Workflow Sequential Pipeline: {pipeline_name}...")

    dynamic_agents = []
    for agent_config in agents:
        agent_name = agent_config.get("agent_name") or agent_config.get("agent_id") or "Agent"
        print(f"Loading {agent_name}...")
        
        # Create the ADK agent from JSON config
        stage_agent = create_adk_agent(
            session_id,
            agent_config, 
            pre_loaded_mcp_toolsets=pre_loaded_mcp_toolsets,
            tool_kwargs=tool_kwargs
        )
        
        # Set output key if specified
        output_key = agent_config.get("output") or agent_config.get("output_format")
        if output_key:
            stage_agent.output_key = output_key
        
        dynamic_agents.append(stage_agent)
        print(f"{agent_name} loaded successfully!")

    pipeline_agent = SequentialAgent(
        name=_safe_name(pipeline_name),
        sub_agents=dynamic_agents,
        description=pipeline_description or pipeline_name,
    )

    print("Workflow Sequential Pipeline created successfully!")
    return pipeline_agent


def create_pipeline_from_usecase(usecase_detail: dict[str, Any]) -> SequentialAgent:
    """
    Create a pipeline from a UseCaseDetailResponse dict.
    
    Args:
        usecase_detail: Dict with structure:
            - archetype: str
            - usecase: str
            - usecase_details: UseCaseResponse dict
            - agents: List[UseCaseAgentPromptResponse] dicts
    
    Returns:
        Configured SequentialAgent instance
    """
    usecase_info = usecase_detail.get("usecase_details", {})
    agents = usecase_detail.get("agents", [])
    
    pipeline_name = usecase_info.get("name") or usecase_detail.get("usecase", "Workflow")
    pipeline_description = usecase_info.get("task") or pipeline_name
    
    return create_pipeline_agent(
        agents=agents,
        pipeline_name=pipeline_name,
        pipeline_description=pipeline_description,
    )
