"""Archetype database-backed data access."""

from __future__ import annotations

from sqlalchemy.orm import Session
from daan.models.archetype import Archetype, UseCase, UseCaseArchetypeMapping

DEFAULT_ARCHETYPE_DESCRIPTIONS: dict[str, str] = {
    "Data Modernization": "Transform and migrate your data infrastructure with intelligent automation and modern cloud technologies.",
    "Platform Engineering": "Build and optimize scalable platform solutions for modern enterprises with automated deployment.",
    "Operations and Support": "Automate, monitor, and streamline IT operations and support workflows for maximum efficiency.",
    "Data Consumption": "Consume and visualize data with powerful analytics and reporting tools for actionable insights.",
    "BI Migration": "Migrate and modernize your Business Intelligence platforms with seamless transitions.",
    "Data Pipeline": "Streamline the design, development, and deployment of data workflows.",
    "Data Trust": "Ensure data integrity, security, compliance, and transparency.",
    "Customer Proposed Use Cases": "Interactive demonstrations showcasing the capabilities and features of all archetype solutions in action.",
}

def list_archetypes(db: Session = None) -> list[dict]:
    """List all arch types from the database."""
    if not db:
        return []
    
    db_types = db.query(Archetype).all()
    
    result = []
    for arch in db_types:
        roles_result = (
            db.query(UseCase.role)
            .join(UseCaseArchetypeMapping, UseCase.usecaseid == UseCaseArchetypeMapping.usecase_id)
            .filter(UseCaseArchetypeMapping.archetype_id == arch.id)
            .all()
        )
        roles = sorted({role_name.strip() for (role_name,) in roles_result if role_name and role_name.strip()}, key=str.casefold)
        
        result.append({
            "id": arch.id,
            "name": arch.name,
            "description": arch.description,
            "roles": roles,
        })
        
    return result


def create_default_archetypes(db: Session) -> None:
    """Initialize DB with default arch types from the static configuration."""
    existing = db.query(Archetype).first()
    if existing:
        return

    for name, description in DEFAULT_ARCHETYPE_DESCRIPTIONS.items():
        db_arch = Archetype(
            name=name,
            description=description
        )
        db.add(db_arch)
    db.commit()
