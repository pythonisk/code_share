"""Architecture Types module."""
