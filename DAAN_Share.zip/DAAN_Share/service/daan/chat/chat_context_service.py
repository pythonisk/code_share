"""Helpers for deriving session-local chat context from uploads and history."""

from __future__ import annotations

import json
import os
import re
import tempfile
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from fastapi import UploadFile

from daan.utils.file_to_json import FileToJsonConverter

MAX_UPLOADED_CONTEXT_CHARS = 24_000
MAX_HISTORY_CHARS = 8_000
MAX_SESSION_CONTEXT_HISTORY_CHARS = 20_000
MAX_SELECTED_UPLOADED_CONTEXT_CHARS = 12_000
MAX_RETRIEVAL_CONTEXT_CHARS = 2_000
_QUERY_STOPWORDS = {
    "a", "an", "and", "are", "about", "can", "do", "for", "from", "how", "i", "in",
    "is", "it", "me", "my", "of", "on", "or", "please", "show", "summarize", "summarise",
    "tell", "that", "the", "this", "to", "what", "with", "you",
}

_SESSION_CONTEXT_PATTERNS = (
    re.compile(r"\b(summary|summarize|summarise|recap|outline)\b.*\b(conversation|chat|discussion|session|messages?)\b", re.IGNORECASE),
    re.compile(r"\b(conversation|chat|discussion|session|messages?)\b.*\b(summary|summarize|summarise|recap|outline)\b", re.IGNORECASE),
    re.compile(r"\bwhat\s+(did|have)\s+we\s+(discuss|cover|talk\s+about)\b", re.IGNORECASE),
    re.compile(r"\b(previous|earlier|above|prior|past)\s+(message|messages|chat|conversation|discussion|session)\b", re.IGNORECASE),
    re.compile(r"\b(in|from)\s+this\s+(chat|conversation|session)\b", re.IGNORECASE),
    re.compile(r"\b(uploaded|attached)\s+(file|files|document|documents)\b.*\b(this\s+session|this\s+chat|current\s+session)\b", re.IGNORECASE),
)

_CONVERSATIONAL_CONTEXT_PATTERNS = (
    re.compile(r"\bwhat\s+are\s+its\b", re.IGNORECASE),
    re.compile(r"\bthis\s+(project|use\s*case|workflow|integration|task|request)\b", re.IGNORECASE),
    re.compile(r"\bthat\s+(project|use\s*case|workflow|integration|task|request)\b", re.IGNORECASE),
    re.compile(r"\bwhat\s+input\s+should\s+i\s+upload\b", re.IGNORECASE),
    re.compile(r"\bwhat\s+inputs\s+are\s+required\b", re.IGNORECASE),
    re.compile(r"\b(its|their|them|they|those|these)\b", re.IGNORECASE),
)

# Matches short greetings/small-talk only — never partial matches inside a longer,
# substantive question (the whole message, minus punctuation, must be one of these).
_GREETING_PATTERN = re.compile(
    r"^(hi+|hello+|hey+|yo|sup|howdy|good\s*(morning|afternoon|evening|day)|"
    r"how('?s| is| are) it going|how('?s| is| are) you( doing)?|"
    r"what'?s up|thanks?( you)?|thank\s*you( so much| very much)?|"
    r"ok(ay)?|cool|great|nice|bye|goodbye|see\s*you|good\s*night)[!.?\s]*$",
    re.IGNORECASE,
)


def is_greeting_or_smalltalk_query(query: str | None) -> bool:
    """Return True only for short greetings/small-talk with no real question content."""
    text = str(query or "").strip()
    if not text or len(text) > 40:
        return False
    return bool(_GREETING_PATTERN.match(text))


def is_session_context_query(query: str | None) -> bool:
    text = str(query or "").strip()
    if not text:
        return False
    return any(pattern.search(text) for pattern in _SESSION_CONTEXT_PATTERNS)


def build_chat_history_text(messages: Iterable[Any], limit: int = 8, query: str | None = None) -> str:
    """Return a compact, query-aware transcript of the most relevant chat messages."""
    session_context_query = is_session_context_query(query)
    recent_messages = list(messages) if session_context_query else list(messages)[-max(int(limit or 0), 0) :]
    query_terms = _query_terms(query)
    if query_terms and not session_context_query:
        scored_messages: list[tuple[int, int, Any]] = []
        for index, message in enumerate(recent_messages):
            content = str(getattr(message, "content", "") or "")
            score = _score_text_against_query(content, query_terms)
            if score > 0:
                scored_messages.append((score, index, message))
        if scored_messages:
            keep_count = min(len(recent_messages), max(4, limit))
            keep_indices = {
                index
                for _, index, _ in sorted(scored_messages, key=lambda item: (-item[0], -item[1]))[:keep_count]
            }
            recent_messages = [message for index, message in enumerate(recent_messages) if index in keep_indices]

    parts: list[str] = []

    for message in recent_messages:
        role = str(getattr(message, "role", "unknown") or "unknown").strip().upper()
        content = str(getattr(message, "content", "") or "").strip()
        if not content:
            continue
        parts.append(f"{role}: {content}")

    transcript = "\n\n".join(parts).strip()
    max_chars = MAX_SESSION_CONTEXT_HISTORY_CHARS if session_context_query else MAX_HISTORY_CHARS
    if len(transcript) > max_chars:
        transcript = transcript[-max_chars:]
    return transcript


def needs_conversational_context(query: str | None) -> bool:
    """Return True when retrieval should incorporate prior chat context.

    This is narrower than session-context detection: it targets referential or
    follow-up prompts whose meaning depends on an antecedent in recent history.
    """
    text = str(query or "").strip()
    if not text:
        return False
    if is_session_context_query(text):
        return False
    return any(pattern.search(text) for pattern in _CONVERSATIONAL_CONTEXT_PATTERNS)


def build_retrieval_chat_context(query: str | None, history_text: str | None) -> str:
    """Return the compact antecedent-bearing history for a follow-up query."""
    if not needs_conversational_context(query):
        return ""

    transcript = str(history_text or "").strip()
    if not transcript:
        return ""

    normalized_query = _normalize_for_dedup(str(query or ""))
    blocks = [block.strip() for block in transcript.split("\n\n") if block.strip()]
    if not blocks:
        return ""

    filtered_blocks: list[str] = []
    for block in blocks:
        block_text = block
        if ":" in block:
            _role, candidate = block.split(":", 1)
            block_text = candidate.strip()
        if normalized_query and _normalize_for_dedup(block_text) == normalized_query:
            continue
        filtered_blocks.append(block)

    if not filtered_blocks:
        return ""

    while len(filtered_blocks) > 1 and len("\n\n".join(filtered_blocks)) > MAX_RETRIEVAL_CONTEXT_CHARS:
        filtered_blocks.pop(0)

    retrieval_context = "\n\n".join(filtered_blocks).strip()
    if len(retrieval_context) > MAX_RETRIEVAL_CONTEXT_CHARS:
        retrieval_context = retrieval_context[-MAX_RETRIEVAL_CONTEXT_CHARS:]
    return retrieval_context


def build_contextual_retrieval_query(query: str, chat_context: str | None = None) -> str:
    """Expand a follow-up query with the minimum prior context needed for retrieval."""
    normalized_query = str(query or "").strip()
    if not normalized_query:
        return ""

    retrieval_context = build_retrieval_chat_context(normalized_query, chat_context)
    if not retrieval_context:
        return normalized_query

    return (
        f"Recent conversation context:\n{retrieval_context}\n\n"
        f"Current user request:\n{normalized_query}"
    )


def select_relevant_uploaded_context(
    query: str,
    uploaded_context_text: str | None,
    preferred_context_text: str | None = None,
) -> str:
    """Return the most query-relevant uploaded-file context blocks."""
    ranked_blocks = _rank_uploaded_context_blocks(
        query=query,
        uploaded_context_text=uploaded_context_text,
        preferred_context_text=preferred_context_text,
    )
    if not ranked_blocks:
        return ""

    selected: list[str] = []
    total_chars = 0
    for _, _, block_text in ranked_blocks:
        block = block_text.strip()
        if not block:
            continue
        block_len = len(block)
        if selected and total_chars + 2 + block_len > MAX_SELECTED_UPLOADED_CONTEXT_CHARS:
            continue
        if not selected and block_len > MAX_SELECTED_UPLOADED_CONTEXT_CHARS:
            block = block[:MAX_SELECTED_UPLOADED_CONTEXT_CHARS]
            block_len = len(block)
        selected.append(block)
        total_chars += block_len if not selected[:-1] else block_len + 2

    return "\n\n".join(selected)


async def extract_uploaded_context(files: list[UploadFile]) -> str:
    """Extract a merged text context blob from uploaded files."""
    converter = FileToJsonConverter()
    parts: list[str] = []

    for upload in files or []:
        filename = str(upload.filename or "").strip()
        if not filename:
            continue

        suffix = Path(filename).suffix or ".tmp"
        payload = await upload.read()
        if not payload:
            continue

        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as temp_file:
            temp_file.write(payload)
            temp_path = temp_file.name

        try:
            converted = converter.convert_file_to_json(temp_path)
            flattened = _flatten_to_text(converted.get("content"))
        finally:
            try:
                os.unlink(temp_path)
            except OSError:
                pass

        flattened = flattened.strip()
        if not flattened:
            continue
        parts.append(f"[Uploaded File: {filename}]\n{flattened}")

    merged = "\n\n".join(parts).strip()
    if len(merged) > MAX_UPLOADED_CONTEXT_CHARS:
        merged = merged[:MAX_UPLOADED_CONTEXT_CHARS]
    return merged


def append_uploaded_context(existing_context: str | None, new_context: str | None) -> str:
    """Append newly extracted upload context while preserving prior file context."""
    existing = str(existing_context or "").strip()
    new = str(new_context or "").strip()

    if not existing:
        merged = new
    elif not new:
        merged = existing
    else:
        merged = f"{existing}\n\n{new}"

    merged = _dedupe_text(merged)
    if len(merged) > MAX_UPLOADED_CONTEXT_CHARS:
        merged = merged[:MAX_UPLOADED_CONTEXT_CHARS]
    return merged


def _flatten_to_text(value: Any) -> str:
    """Flatten JSON-like converted file content into prompt-ready text."""
    if value is None:
        return ""
    if isinstance(value, str):
        return _dedupe_text(value)
    if isinstance(value, (int, float, bool)):
        return str(value)
    if isinstance(value, list):
        parts = [_flatten_to_text(item).strip() for item in value]
        return _dedupe_text("\n".join(part for part in parts if part))
    if isinstance(value, dict):
        if _looks_like_structured_document(value):
            return _render_structured_document(value)
        preferred_keys = (
            "text",
            "content",
            "structured_sections",
            "sections",
            "tables",
            "rows",
            "data",
            "summary",
        )
        parts: list[str] = []
        for key in preferred_keys:
            if key in value:
                rendered = _flatten_to_text(value.get(key)).strip()
                if rendered:
                    parts.append(f"{key}:\n{rendered}")
        if parts:
            return _dedupe_text("\n\n".join(parts))
        try:
            return json.dumps(value, ensure_ascii=False, default=str)
        except Exception:
            return str(value)
    return str(value)


def _looks_like_structured_document(value: dict[str, Any]) -> bool:
    return any(key in value for key in ("structured_sections", "sections", "tables", "summary"))


def _render_structured_document(value: dict[str, Any]) -> str:
    parts: list[str] = []

    summary_text = _flatten_to_text(value.get("summary")).strip() if "summary" in value else ""
    if summary_text:
        parts.append(f"summary:\n{summary_text}")

    sections = value.get("structured_sections") or value.get("sections")
    sections_text = _render_sections(sections).strip()
    if sections_text:
        parts.append(f"structured_sections:\n{sections_text}")

    tables_text = _render_tables(value.get("tables")).strip() if "tables" in value else ""
    if tables_text:
        parts.append(f"tables:\n{tables_text}")

    fallback_content = _flatten_to_text(value.get("content")).strip() if "content" in value else ""
    if fallback_content and not parts:
        parts.append(fallback_content)

    return _dedupe_text("\n\n".join(part for part in parts if part))


def _render_sections(value: Any) -> str:
    if not isinstance(value, dict):
        return _flatten_to_text(value)

    seen_contents: set[str] = set()
    parts: list[str] = []
    for heading, section in value.items():
        if not isinstance(section, dict):
            content = _flatten_to_text(section).strip()
        else:
            content = _flatten_to_text(section.get("content")).strip()
        normalized = _normalize_for_dedup(content)
        if content and normalized and normalized not in seen_contents:
            seen_contents.add(normalized)
            parts.append(f"{heading}:\n{content}")
        elif not content:
            heading_text = str(heading or "").strip()
            if heading_text:
                parts.append(heading_text)
    return _dedupe_text("\n\n".join(parts))


def _render_tables(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        blocks = [_flatten_to_text(item).strip() for item in value]
        return _dedupe_text("\n\n".join(block for block in blocks if block))
    if isinstance(value, dict):
        rows = _flatten_to_text(value.get("rows")).strip() if "rows" in value else ""
        data = _flatten_to_text(value.get("data")).strip() if "data" in value else ""
        parts = []
        if rows:
            parts.append(f"rows:\n{rows}")
        if data:
            parts.append(f"data:\n{data}")
        return _dedupe_text("\n\n".join(parts))
    return _dedupe_text(_flatten_to_text(value))


def _dedupe_text(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return ""

    lines = [line.strip() for line in text.splitlines()]
    deduped_lines: list[str] = []
    seen_lines: set[str] = set()
    blank_pending = False

    for line in lines:
        if not line:
            if deduped_lines and not blank_pending:
                deduped_lines.append("")
                blank_pending = True
            continue
        blank_pending = False
        normalized = _normalize_for_dedup(line)
        if normalized and normalized in seen_lines:
            continue
        if normalized:
            seen_lines.add(normalized)
        deduped_lines.append(line)

    blocks = [block.strip() for block in "\n".join(deduped_lines).split("\n\n")]
    deduped_blocks: list[str] = []
    seen_blocks: set[str] = set()
    for block in blocks:
        if not block:
            continue
        normalized = _normalize_for_dedup(block)
        if normalized and normalized in seen_blocks:
            continue
        if normalized:
            seen_blocks.add(normalized)
        deduped_blocks.append(block)

    return "\n\n".join(deduped_blocks)


def _normalize_for_dedup(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).casefold()


def _query_terms(query: str | None) -> set[str]:
    raw_terms = re.findall(r"[a-z0-9][a-z0-9_.\-/]*", str(query or "").casefold())
    return {term for term in raw_terms if len(term) > 2 and term not in _QUERY_STOPWORDS}


def _score_text_against_query(text: str, query_terms: set[str]) -> int:
    if not query_terms:
        return 0
    haystack = str(text or "").casefold()
    score = 0
    for term in query_terms:
        if term in haystack:
            score += 3 if len(term) > 6 else 2
    return score


def _rank_uploaded_context_blocks(
    query: str,
    uploaded_context_text: str | None,
    preferred_context_text: str | None,
) -> list[tuple[int, int, str]]:
    query_terms = _query_terms(query)
    blocks: list[tuple[str, bool]] = []
    seen_blocks: set[str] = set()

    for block_text, is_preferred in _iter_uploaded_blocks(preferred_context_text, True):
        normalized = _normalize_for_dedup(block_text)
        if normalized and normalized not in seen_blocks:
            seen_blocks.add(normalized)
            blocks.append((block_text, is_preferred))

    for block_text, is_preferred in _iter_uploaded_blocks(uploaded_context_text, False):
        normalized = _normalize_for_dedup(block_text)
        if normalized and normalized not in seen_blocks:
            seen_blocks.add(normalized)
            blocks.append((block_text, is_preferred))

    scored: list[tuple[int, int, str]] = []
    for index, (block_text, is_preferred) in enumerate(blocks):
        score = _score_text_against_query(block_text, query_terms)
        if is_preferred:
            score += 4
        if score > 0:
            scored.append((score, index, block_text))

    if scored:
        return sorted(scored, key=lambda item: (-item[0], item[1]))

    fallback: list[tuple[int, int, str]] = []
    for index, (block_text, is_preferred) in enumerate(blocks):
        if is_preferred or index == 0:
            fallback.append((1 if is_preferred else 0, index, block_text))
    return sorted(fallback, key=lambda item: (-item[0], item[1]))


def _iter_uploaded_blocks(context_text: str | None, is_preferred: bool) -> list[tuple[str, bool]]:
    text = str(context_text or "").strip()
    if not text:
        return []

    matches = list(re.finditer(r"\[Uploaded File:\s*(.*?)\]", text))
    if not matches:
        return [(text, is_preferred)]

    blocks: list[tuple[str, bool]] = []
    for index, match in enumerate(matches):
        start = match.start()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        block = text[start:end].strip()
        if block:
            blocks.append((block, is_preferred))
    return blocks