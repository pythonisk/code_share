"""Chat Feedback Service.

Stores and retrieves explicit user feedback (thumbs-down + text) in pgvector.
When a user gives thumbs-down with feedback text, the query + feedback are
vectorized together and stored permanently. On future similar queries, this
feedback is retrieved and used to:
  1. Inject answer-shaping instructions into the LLM prompt
  2. Increase retrieval k (fetch more chunks)

Session-level refinements (e.g., "too long", "be more specific") are handled
naturally by the existing chat history context within the same session.
"""

from __future__ import annotations

import logging
import time

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FEEDBACK_TABLE_NAME = "chat_feedback"
FEEDBACK_SIMILARITY_THRESHOLD = 0.93
TURN_FEEDBACK_DOC_TYPE = "chat_feedback"


# ---------------------------------------------------------------------------
# Data Models
# ---------------------------------------------------------------------------


class TurnFeedback(BaseModel):
    """Explicit per-turn feedback from thumbs up/down."""

    original_query: str
    bot_response: str
    session_id: str
    user_id: int
    is_positive: bool
    feedback_text: str | None = None
    kb_id: str | None = None


class EnhancedFeedbackResult(BaseModel):
    """Retrieval result used to improve both search and synthesis."""

    query_expansion_terms: list[str] = Field(default_factory=list)
    extra_k: int = 0
    answer_instructions: str = ""


# ---------------------------------------------------------------------------
# Infrastructure helpers
# ---------------------------------------------------------------------------


def _get_feedback_store():
    """Get or create a PostgresVectorStore for the chat_feedback table."""
    from daan.core.config import get_settings
    from daan.vector_stores.providers.postgres_vector_store import PostgresVectorStore

    settings = get_settings()
    rag_config = settings.load_rag_config()
    vector_store_config = rag_config.get("vector_store_config", {})
    return PostgresVectorStore({
        **vector_store_config,
        "table_name": FEEDBACK_TABLE_NAME,
        "embedding_dimension": int(vector_store_config.get("embedding_dimension", 1536)),
        "schema": vector_store_config.get("schema", "rag_vectors"),
    })


def _get_embedding_provider():
    """Get the configured embedding provider."""
    from daan.llm.embedding_provider import EmbeddingProviderFactory
    from daan.rag.rag_context_builder import load_rag_config, resolve_embedding_config

    rag_config = load_rag_config()
    embedding_config = resolve_embedding_config(rag_config)
    return EmbeddingProviderFactory.create_provider(
        rag_config.get("embedding_provider", "azure_openai"),
        embedding_config,
    )


# ---------------------------------------------------------------------------
# Store feedback (thumbs-down + text)
# ---------------------------------------------------------------------------


def store_turn_feedback(feedback: TurnFeedback) -> str | None:
    """Store explicit turn-level feedback (thumbs down + text).

    Embeds the original query and stores the feedback text in metadata.
    Deduplicates: skips if the same user already gave identical feedback
    for a similar query (cosine >= 0.95).
    """
    if feedback.is_positive or not feedback.feedback_text:
        return None

    from daan.vector_stores.document import RagDocument

    try:
        provider = _get_embedding_provider()
        store = _get_feedback_store()

        embedding = provider.embed_text(feedback.original_query)

        # Dedup check: skip if same user already has near-identical feedback
        dedup_filter: dict = {
            "user_id": {"$eq": str(feedback.user_id)},
            "doc_type": {"$eq": TURN_FEEDBACK_DOC_TYPE},
        }
        if feedback.kb_id:
            dedup_filter["kb_id"] = {"$eq": feedback.kb_id}
        existing = store.similarity_search(
            query_embedding=embedding,
            k=3,
            where=dedup_filter,
        )
        if existing:
            from numpy import dot
            from numpy.linalg import norm

            normalized_feedback = feedback.feedback_text.strip().lower()
            for doc in existing:
                if not doc.embedding:
                    continue
                sim = dot(embedding, doc.embedding) / (norm(embedding) * norm(doc.embedding))
                existing_feedback = (doc.metadata or {}).get("feedback_text", "").strip().lower()
                # Same query (sim>=0.95) AND same feedback text → skip
                if sim >= 0.95 and existing_feedback == normalized_feedback:
                    logger.info(f"[Feedback] Duplicate skipped for user={feedback.user_id}: '{normalized_feedback[:40]}'")
                    return None

        doc_id = f"turn_fb_{feedback.user_id}_{int(time.time() * 1000)}"
        doc = RagDocument(
            id=doc_id,
            content=feedback.original_query,
            metadata={
                "doc_type": TURN_FEEDBACK_DOC_TYPE,
                "user_id": str(feedback.user_id),
                "kb_id": feedback.kb_id or "",
                "feedback_text": feedback.feedback_text.strip(),
                "original_query": feedback.original_query,
                "bot_response_snippet": feedback.bot_response[:300],
                "session_id": feedback.session_id,
                "timestamp": str(int(time.time())),
            },
            source="user_feedback",
            chunk_index=0,
            embedding=embedding,
        )
        store.upsert(doc)
        logger.info(f"[Feedback] Stored turn feedback doc_id={doc_id} for user={feedback.user_id}")
        return doc_id
    except Exception as exc:
        logger.warning(f"[Feedback] Failed to store turn feedback: {exc}")
        return None


# ---------------------------------------------------------------------------
# Retrieve feedback for a query (permanent, cross-session)
# ---------------------------------------------------------------------------


def retrieve_enhanced_feedback(
    query: str,
    user_id: int,
    kb_id: str | None = None,
) -> EnhancedFeedbackResult:
    """Retrieve permanent turn-level feedback (thumbs-down) for similar queries.

    Searches pgvector for past feedback this user gave on similar queries,
    scoped to the same knowledge base.

    Returns:
    - extra_k: additional chunks to retrieve (0 if no feedback found)
    - answer_instructions: text to inject into the LLM prompt
    """
    result = EnhancedFeedbackResult()

    try:
        store = _get_feedback_store()
        provider = _get_embedding_provider()
        query_embedding = provider.embed_text(query)

        search_filter: dict = {
            "user_id": {"$eq": str(user_id)},
            "doc_type": {"$eq": TURN_FEEDBACK_DOC_TYPE},
        }
        if kb_id:
            search_filter["kb_id"] = {"$eq": kb_id}
        docs = store.similarity_search(
            query_embedding=query_embedding,
            k=5,
            where=search_filter,
        )

        if not docs:
            return result

        from numpy import dot
        from numpy.linalg import norm

        feedback_texts: list[str] = []

        for doc in docs:
            if not doc.embedding:
                continue

            similarity = dot(query_embedding, doc.embedding) / (
                norm(query_embedding) * norm(doc.embedding)
            )

            if similarity < FEEDBACK_SIMILARITY_THRESHOLD:
                continue

            stored_query = (doc.metadata or {}).get("original_query", "")
            if not _shares_topic_keyword(query, stored_query):
                logger.info(
                    f"[Feedback] Rejected same-template match (sim={similarity:.3f}) — "
                    f"no shared keyword between '{query[:40]}' and '{stored_query[:40]}'"
                )
                continue

            feedback_text = (doc.metadata or {}).get("feedback_text", "")
            if feedback_text:
                feedback_texts.append(feedback_text)
                logger.info(
                    f"[Feedback] Turn feedback matched (sim={similarity:.3f}): "
                    f"{feedback_text[:60]}"
                )

        if feedback_texts:
            result.answer_instructions = "\n".join(
                f"- {text}" for text in feedback_texts[:5]
            )
            result.extra_k = min(len(feedback_texts) * 2, 6)
            # Extract key terms from feedback to expand the search query
            result.query_expansion_terms = _extract_expansion_terms(feedback_texts)

        logger.info(
            f"[Feedback] Enhanced result: extra_k={result.extra_k}, "
            f"has_instructions={bool(result.answer_instructions)}"
        )
        return result

    except Exception as exc:
        logger.warning(f"[Feedback] Enhanced retrieval failed: {exc}")
        return result


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Common words that don't help retrieval
_STOP_WORDS = frozenset(
    "a an the is are was were be been being have has had do does did will would "
    "shall should may might can could i me my we our you your he she it they them "
    "this that these those in on at to for from by with of and or not no but if "
    "then so too very just also only more most less least about after before between "
    "into through during each every all any both few many much some such how what "
    "which who whom when where why there here answer include show give provide "
    "please want need like daan".split()
)


def _content_tokens(text: str) -> set[str]:
    """Lowercased, alphabetic, non-stop-word tokens used for topical overlap checks."""
    tokens = text.replace(",", " ").replace(".", " ").replace("/", " ").replace("?", " ").split()
    return {
        clean
        for token in tokens
        if (clean := token.strip().lower()) and len(clean) >= 3 and clean.isalpha() and clean not in _STOP_WORDS
    }


def _shares_topic_keyword(query: str, stored_query: str) -> bool:
    """Guard against same-template-different-topic matches (e.g. two 'What X does
    DAAN support?' questions with different X) that can still score high on pure
    embedding similarity. Requires at least one shared content word.
    """
    if not stored_query:
        return True
    current_tokens = _content_tokens(query)
    stored_tokens = _content_tokens(stored_query)
    if not current_tokens or not stored_tokens:
        return True
    return bool(current_tokens & stored_tokens)


def _extract_expansion_terms(feedback_texts: list[str]) -> list[str]:
    """Extract meaningful keywords from feedback text for query expansion.

    Simple keyword extraction — no LLM call needed. Extracts content words
    (nouns, specific terms) by filtering out stop words and short words.

    Example:
        "include JSON output format examples" → ["JSON", "output", "format", "examples"]
        "answer in 2 lines only" → ["lines"]  (not very useful — that's fine)
    """
    words: list[str] = []
    for text in feedback_texts:
        tokens = text.replace(",", " ").replace(".", " ").replace("/", " ").split()
        for token in tokens:
            clean = token.strip().lower()
            if len(clean) >= 3 and clean not in _STOP_WORDS and clean.isalpha():
                words.append(token.strip())

    # Deduplicate while preserving order
    seen: set[str] = set()
    unique: list[str] = []
    for word in words:
        normalized = word.lower()
        if normalized not in seen:
            seen.add(normalized)
            unique.append(word)

    return unique[:5]  # cap at 5 terms
