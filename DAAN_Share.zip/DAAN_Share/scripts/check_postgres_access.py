#!/usr/bin/env python3
"""
Test PostgreSQL connection to Azure PostgreSQL server.
 
Credentials are read from config/.env (or environment variables).
The DB_PASSWORD must be set in config/.env before running.
 
Usage:
    python scripts/test_postgres_connection.py
 
Or override credentials via environment variables:
    $env:DB_PASSWORD="yourpassword"; python scripts/test_postgres_connection.py
"""
 
import os
import sys
from pathlib import Path
 
# Load .env from config/ directory before importing psycopg2
_env_path = Path(__file__).resolve().parents[1] / "config" / ".env"
if _env_path.exists():
    from dotenv import load_dotenv
    load_dotenv(_env_path)
    print(f"Loaded env from: {_env_path}")
 
try:
    import psycopg2
except ImportError:
    print("Error: psycopg2 is required.")
    print("Install with:  pip install psycopg2-binary")
    sys.exit(1)
 
# ── Connection parameters ─────────────────────────────────────────────────────
# These defaults match the credentials from the image.
# Set DB_PASSWORD in config/.env to avoid entering it each time.
HOST     = os.getenv("DB_HOST",     "daan-postgresql-server.postgres.database.azure.com")
PORT     = int(os.getenv("DB_PORT", "5432"))
DATABASE = os.getenv("DB_NAME",     "daan-postgre-dev")
USER     = os.getenv("DB_USER",     "daan_postgresql_admin")
PASSWORD = os.getenv("DB_PASSWORD", "").strip("'")
 
# ── Prompt for password if missing ───────────────────────────────────────────
if not PASSWORD:
    import getpass
    PASSWORD = getpass.getpass(
        f"Enter password for {USER}@{HOST}: "
    )
 
# ── Test connection ───────────────────────────────────────────────────────────
print()
print("=" * 60)
print("  PostgreSQL Connection Test")
print("=" * 60)
print(f"  Host    : {HOST}")
print(f"  Port    : {PORT}")
print(f"  Database: {DATABASE}")
print(f"  User    : {USER}")
print(f"  SSL     : require (Azure PostgreSQL)")
print("=" * 60)
print()
 
conn = None
try:
    print("Connecting...")
    conn = psycopg2.connect(
        host=HOST,
        port=PORT,
        dbname=DATABASE,
        user=USER,
        password=PASSWORD,
        sslmode="require",
        connect_timeout=10,
    )
    conn.autocommit = True
    cursor = conn.cursor()
 
    # Server version
    cursor.execute("SELECT version();")
    version = cursor.fetchone()[0]
    print(f"[OK] Connected successfully!")
    print(f"     Server version : {version}")
 
    # Current database
    cursor.execute("SELECT current_database();")
    current_db = cursor.fetchone()[0]
    print(f"     Current DB     : {current_db}")
 
    # Current user
    cursor.execute("SELECT current_user;")
    current_user = cursor.fetchone()[0]
    print(f"     Current user   : {current_user}")
 
    # List tables in public schema
    cursor.execute(
        "SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename;"
    )
    tables = [row[0] for row in cursor.fetchall()]
    if tables:
        print(f"\n     Tables in public schema ({len(tables)}):")
        for t in tables:
            print(f"       - {t}")
    else:
        print("\n     No tables found in public schema yet (fresh database).")
 
    cursor.close()
    print()
    print("[PASS] All checks passed. Connection is healthy.")
 
except psycopg2.OperationalError as e:
    print(f"[FAIL] Could not connect to PostgreSQL:")
    print(f"       {e}")
    print()
    print("Troubleshooting tips:")
    print("  1. Ensure DB_PASSWORD is set correctly in config/.env")
    print("  2. Verify the Azure PostgreSQL server allows your IP (firewall rules)")
    print("  3. Confirm the server name and database name are correct")
    sys.exit(1)
 
except psycopg2.Error as e:
    print(f"[FAIL] PostgreSQL error: {e}")
    sys.exit(1)
 
finally:
    if conn:
        conn.close()