"""Demo: generate a GitHub Copilot pack for the 'Candidate Profile Screener' use case.

Builds a representative UseCaseConfig (the local dev DB is unseeded) and runs the
new CopilotPackageGenerator, then extracts the ZIP and prints the file tree so the
feature can be verified end-to-end without the platform running.

Run from the service/ directory:
    python -m scripts.demo_copilot_export        # (if on path)
    python scripts/demo_copilot_export.py
"""

import sys
import zipfile
from pathlib import Path

SERVICE_DIR = Path(__file__).resolve().parents[1] / "service"
sys.path.insert(0, str(SERVICE_DIR))

from daan.usecases.export.copilot_generator import CopilotPackageGenerator  # noqa: E402
from daan.usecases.export.schemas import (  # noqa: E402
    AgentMCPMapping,
    AgentOrchestrationStep,
    AgentPromptConfig,
    LLMConfig,
    UseCaseConfig,
)


def build_candidate_profile_screener() -> UseCaseConfig:
    """Representative 3-agent recruiting workflow."""
    agents = [
        AgentPromptConfig(
            agent_id="agent_1_resume_parser",
            role="Resume Parser",
            instructions=(
                "Extract structured fields from raw candidate resumes: name, contact, "
                "years of experience, skills, education, and past roles. Use only data "
                "present in {resume_files}; never invent details."
            ),
            prompt=(
                "Parse the candidate resumes in {resume_files} into a normalized JSON "
                "profile per candidate."
            ),
            expected_outputs="JSON array of candidate profiles with normalized fields.",
            agent_type="dynamic_agent",
        ),
        AgentPromptConfig(
            agent_id="agent_2_jd_matcher",
            role="JD Matcher",
            instructions=(
                "Score each parsed candidate profile against {job_description}. Weight "
                "must-have skills higher than nice-to-haves and flag missing requirements."
            ),
            prompt=(
                "Given the parsed profiles and {job_description}, produce a match score "
                "(0-100) and a short rationale per candidate."
            ),
            expected_outputs="Table of candidate, match score, matched/missing skills, rationale.",
            agent_type="dynamic_agent",
        ),
        AgentPromptConfig(
            agent_id="agent_3_shortlist_reporter",
            role="Shortlist Reporter",
            instructions=(
                "Consolidate the match results into a ranked shortlist and publish the "
                "top candidates as issues in the tracker."
            ),
            prompt=(
                "Rank candidates by match score, produce an executive shortlist summary, "
                "and create a tracker issue for each shortlisted candidate."
            ),
            expected_outputs="Ranked shortlist report + one created issue per shortlisted candidate.",
            agent_type="action_agent",
        ),
    ]

    llm_configs = {
        a.agent_id: LLMConfig(
            agent_id=a.agent_id,
            model="gpt-4o",
            provider="azure_openai",
            temperature=0.3,
            max_tokens=16384,
        )
        for a in agents
    }

    orchestration = [
        AgentOrchestrationStep(
            agent_id=a.agent_id,
            step_index=i,
            input_source="user_input" if i == 0 else "previous_agent",
            input_key="input" if i == 0 else None,
            source_agent_id=agents[i - 1].agent_id if i > 0 else None,
            output_key=a.agent_id,
        )
        for i, a in enumerate(agents)
    ]

    # The reporter agent publishes to Jira via MCP.
    agent_mcp_mappings = {
        "agent_3_shortlist_reporter": AgentMCPMapping(
            agent_id="agent_3_shortlist_reporter",
            mcp_servers=["jira-mcp-server"],
        )
    }

    return UseCaseConfig(
        usecase_id="UC_CP_SCREENER",
        usecase_name="Candidate Profile Screener",
        version="1.0.0",
        description=(
            "you need to screen inbound candidate resumes against a job description and "
            "produce a ranked shortlist."
        ),
        agents=agents,
        orchestration=orchestration,
        llm_configs=llm_configs,
        agent_mcp_mappings=agent_mcp_mappings,
    )


def main() -> None:
    config = build_candidate_profile_screener()
    zip_path = CopilotPackageGenerator(config).generate()
    print(f"Generated: {zip_path}\n")

    out_dir = Path(__file__).resolve().parent / "_copilot_demo_out"
    out_dir.mkdir(exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(out_dir)

    root = out_dir / f"copilot_{config.usecase_id}"
    print("Package tree:")
    for p in sorted(root.rglob("*")):
        rel = p.relative_to(root)
        indent = "  " * (len(rel.parts) - 1)
        print(f"{indent}{p.name}{'/' if p.is_dir() else ''}")

    sample = root / ".github" / "skills" / "candidate-profile-screener" / "SKILL.md"
    if sample.exists():
        print("\n--- SKILL.md ---\n")
        print(sample.read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()
