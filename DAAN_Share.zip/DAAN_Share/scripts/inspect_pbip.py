"""Quick inspector for Power BI zip artifacts."""
import zipfile
import json
import sys
from pathlib import Path

def parse_tmdl_tables(z, names):
    """Parse TMDL table files to extract columns and measures."""
    tmdl_files = [n for n in names if n.endswith('.tmdl') and '/tables/' in n]
    tables = []
    for tf in sorted(tmdl_files):
        content = z.read(tf).decode('utf-8')
        table_name = Path(tf).stem
        columns = []
        measures = []
        current_measure = None
        current_expr_lines = []
        
        for line in content.split('\n'):
            stripped = line.strip()
            if stripped.startswith('column '):
                col_name = stripped.replace('column ', '').strip()
                columns.append(col_name)
            elif stripped.startswith('measure '):
                if current_measure:
                    measures.append((current_measure, ' '.join(current_expr_lines).strip()))
                current_measure = stripped.replace('measure ', '').split('=')[0].strip()
                expr_part = stripped.split('=', 1)[1].strip() if '=' in stripped else ''
                current_expr_lines = [expr_part] if expr_part else []
            elif current_measure and stripped and not stripped.startswith(('formatString', 'lineageTag', 'annotation')):
                if stripped.startswith('```') or stripped.startswith('expression'):
                    continue
                current_expr_lines.append(stripped)
            elif stripped == '' and current_measure:
                pass  # blank line in measure
        
        if current_measure:
            measures.append((current_measure, ' '.join(current_expr_lines).strip()))
        
        tables.append({'name': table_name, 'columns': columns, 'measures': measures})
    return tables


def inspect_zip(zip_path: str):
    z = zipfile.ZipFile(zip_path)
    names = z.namelist()
    
    # Parse TMDL tables
    tables = parse_tmdl_tables(z, names)
    
    if not tables:
        print("ERROR: No table definitions found!")
        return
    
    print(f"=== SEMANTIC MODEL ({len(tables)} tables) ===")
    for t in tables:
        print(f"\n  Table: {t['name']}")
        print(f"    Columns ({len(t['columns'])}): {t['columns']}")
        print(f"    Measures ({len(t['measures'])}):")
        for name, expr in t['measures']:
            print(f"      - {name} = {expr[:80]}")
    
    # Find page JSONs
    page_files = [n for n in names if n.endswith('page.json')]
    print(f"\n=== REPORT PAGES ({len(page_files)}) ===")
    for pf in sorted(page_files):
        page = json.loads(z.read(pf))
        print(f"  Page: {page.get('displayName', 'Unknown')}")
    
    # Find visual JSONs and check bindings
    visual_files = [n for n in names if n.endswith('visual.json')]
    print(f"\n=== VISUALS ({len(visual_files)}) ===")
    issues = []
    for vf in sorted(visual_files):
        vis = json.loads(z.read(vf))
        
        # PBIP format: visual.visualType, visual.query.queryState
        visual_obj = vis.get('visual', {})
        visual_type = visual_obj.get('visualType', 'unknown')
        
        # Get title from visual.vcObjects.title
        vc_objects = visual_obj.get('vcObjects', {})
        title_arr = vc_objects.get('title', [])
        title_text = ''
        if title_arr and isinstance(title_arr, list):
            props = title_arr[0].get('properties', {})
            text_prop = props.get('text', {})
            title_text = text_prop.get('expr', {}).get('Literal', {}).get('Value', '')
            if title_text.startswith("'") and title_text.endswith("'"):
                title_text = title_text[1:-1]
        
        # Check query state for data bindings
        query = visual_obj.get('query', {})
        query_state = query.get('queryState', {})
        
        # Count total projections across all roles (Category, Y, Values, etc.)
        total_projections = 0
        binding_roles = []
        for role, role_data in query_state.items():
            projs = role_data.get('projections', [])
            total_projections += len(projs)
            if projs:
                binding_roles.append(role)
        
        has_data = total_projections > 0
        
        page_section = vf.split('/pages/')[1].split('/')[0] if '/pages/' in vf else '?'
        
        if not has_data:
            issues.append(f"{visual_type} '{title_text}' on page {page_section} - NO DATA")
            status = "NO DATA BINDINGS"
        else:
            status = f"OK ({total_projections} fields: {', '.join(binding_roles)})"
        
        print(f"  [{visual_type:22}] {title_text:40} | {status}")
    
    if issues:
        print(f"\n=== ISSUES FOUND ({len(issues)}) ===")
        for i in issues:
            print(f"  - {i}")
    else:
        print("\n=== ALL VISUALS HAVE DATA BINDINGS ===")
    
    # Check for model.tmdl relationships
    model_tmdl = [n for n in names if n.endswith('model.tmdl')]
    if model_tmdl:
        content = z.read(model_tmdl[0]).decode('utf-8')
        rel_lines = [l.strip() for l in content.split('\n') if 'relationship' in l.lower() or 'fromColumn' in l or 'toColumn' in l]
        if rel_lines:
            print(f"\n=== RELATIONSHIPS ===")
            for rl in rel_lines[:20]:
                print(f"  {rl}")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python inspect_pbip.py <zip_path>")
        sys.exit(1)
    inspect_zip(sys.argv[1])
