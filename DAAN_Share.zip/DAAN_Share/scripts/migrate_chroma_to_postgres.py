"""Migrate knowledge-base vectors from ChromaDB to PostgreSQL/pgvector."""

from __future__ import annotations

import argparse
from importlib import import_module
import sys
from pathlib import Path
from typing import Any
import re


REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_ROOT = REPO_ROOT / "service"
if str(SERVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(SERVICE_ROOT))
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))


def _collection_names(rag_config: dict[str, Any]) -> list[tuple[str, str]]:
    kb_entries = rag_config.get("knowledge_bases", []) or []
    pairs: list[tuple[str, str]] = []
    for kb in kb_entries:
        kb_id = str(kb.get("id") or "").strip()
        if not kb_id:
            continue
        collection_name = str(kb.get("collection") or kb_id).strip() or kb_id
        pairs.append((kb_id, collection_name))
    return pairs


def _normalize_identifier(value: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9_]+", "_", str(value or "")).strip("_").lower()
    return cleaned or "rag_documents"


def _infer_embedding_dimension(payload: dict[str, Any] | None) -> int | None:
    embeddings = _as_list((payload or {}).get("embeddings"))
    for item in embeddings:
        if isinstance(item, list) and item:
            return len(item)
    return None


def _build_chroma_client(persist_dir: Path):
    import chromadb  # pylint: disable=import-outside-toplevel

    return chromadb.PersistentClient(path=str(persist_dir))


def _as_list(values: Any) -> list[Any]:
    if values is None:
        return []
    if isinstance(values, list):
        return values
    try:
        return list(values)
    except TypeError:
        return [values]


def _stage(message: str) -> None:
    print(f"[migrate] {message}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--persist-directory",
        help="Chroma persist directory override",
    )
    parser.add_argument(
        "--database-url",
        help="PostgreSQL URL override. Defaults to DATABASE_URL or config env.",
    )
    parser.add_argument(
        "--table-name",
        default=None,
        help="Optional base table name. Defaults to the KB collection name.",
    )
    parser.add_argument(
        "--schema",
        default="rag_vectors",
        help="Target PostgreSQL schema",
    )
    parser.add_argument(
        "--replace",
        action="store_true",
        help="Delete existing rows for a KB before importing that KB",
    )
    args = parser.parse_args()

    settings_module = import_module("daan.core.config")
    embedding_module = import_module("daan.llm.embedding_provider")
    rag_context_module = import_module("daan.rag.rag_context_builder")
    vector_document_module = import_module("daan.vector_stores.document")
    postgres_store_module = import_module("daan.vector_stores.providers.postgres_vector_store")

    get_settings = settings_module.get_settings
    EmbeddingProviderFactory = embedding_module.EmbeddingProviderFactory
    resolve_embedding_config = rag_context_module.resolve_embedding_config
    RagDocument = vector_document_module.RagDocument
    PostgresVectorStore = postgres_store_module.PostgresVectorStore

    settings = get_settings()
    rag_config = settings.load_rag_config() or {}
    _stage("Loaded RAG configuration")
    embedding_provider_name = rag_config.get("embedding_provider", "azure_openai")
    embedding_config = resolve_embedding_config(rag_config)
    _stage(f"Initializing embedding provider: {embedding_provider_name}")
    embedding_provider = EmbeddingProviderFactory.create_provider(
        provider_name=embedding_provider_name,
        config=embedding_config,
    )

    vector_store_config = dict(rag_config.get("vector_store_config", {}))
    database_url = args.database_url or vector_store_config.get("database_url") or settings.VECTOR_DATABASE_URL
    if not str(database_url).startswith("postgresql"):
        print("Target database must be PostgreSQL.")
        return 1

    _stage(f"Using PostgreSQL vector database: {database_url.split('@')[-1] if '@' in database_url else database_url}")

    persist_dir = Path(args.persist_directory or vector_store_config.get("persist_directory", ".chroma"))
    if not persist_dir.is_absolute():
        persist_dir = Path(__file__).resolve().parents[1] / persist_dir
    if not persist_dir.exists():
        print(f"Chroma persist directory not found: {persist_dir}")
        return 1

    _stage(f"Reading Chroma data from: {persist_dir}")

    client = _build_chroma_client(persist_dir)
    migrated_total = 0
    for kb_id, collection_name in _collection_names(rag_config):
        table_name = _normalize_identifier(args.table_name or collection_name)
        _stage(f"Preparing KB '{kb_id}' from Chroma collection '{collection_name}' into {args.schema}.{table_name}")
        postgres_store = PostgresVectorStore(
            {
                "database_url": database_url,
                "embedding_dimension": int(vector_store_config.get("embedding_dimension", 0) or 0) or 1536,
                "schema": args.schema,
                "table_name": table_name,
            }
        )
        try:
            collection = client.get_collection(collection_name)
        except Exception:
            print(f"Skipping missing Chroma collection: {collection_name}")
            continue

        _stage(f"Exporting rows from collection '{collection_name}'")

        payload = collection.get(include=["documents", "metadatas", "embeddings"])
        ids = _as_list(payload.get("ids"))
        documents = _as_list(payload.get("documents"))
        metadatas = _as_list(payload.get("metadatas"))
        embeddings = _as_list(payload.get("embeddings"))

        if not ids:
            print(f"No records found in collection: {collection_name}")
            continue

        inferred_dimension = _infer_embedding_dimension(payload)
        if inferred_dimension and inferred_dimension != postgres_store.embedding_dimension:
            print(
                f"Skipping {kb_id} because embedding dimension {inferred_dimension} does not match target "
                f"{postgres_store.embedding_dimension}."
            )
            continue

        if args.replace:
            _stage(f"Clearing existing PostgreSQL rows for KB '{kb_id}'")
            deleted = postgres_store.delete_by_session_id(kb_id)
            print(f"Cleared {deleted} existing rows for KB {kb_id}")

        _stage(f"Transforming {len(ids)} Chroma rows into PostgreSQL records")
        rows = []
        for index, doc_id in enumerate(ids):
            metadata = metadatas[index] if index < len(metadatas) else {}
            content = documents[index] if index < len(documents) else ""
            embedding = _as_list(embeddings[index]) if index < len(embeddings) else []
            if len(embedding) == 0:
                continue
            rows.append(
                RagDocument(
                    id=str(doc_id),
                    content=str(content or ""),
                    metadata=dict(metadata or {}),
                    source=str((metadata or {}).get("source") or ""),
                    chunk_index=int((metadata or {}).get("chunk_index", 0) or 0),
                    embedding=[float(value) for value in embedding],
                )
            )

        _stage(f"Writing {len(rows)} rows to PostgreSQL table {args.schema}.{table_name}")
        postgres_store.add_documents(rows)
        migrated_total += len(rows)
        print(f"Migrated {len(rows)} rows from {collection_name} -> {args.schema}.{table_name}")

    _stage("Migration finished")
    print(f"Done. Migrated {migrated_total} total rows.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())