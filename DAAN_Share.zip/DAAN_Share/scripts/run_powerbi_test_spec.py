"""
Test Runner for Power BI Spec Validation
=========================================

Runs the Power BI report generation simulation using pre-written test spec files
instead of the normal AGENT_8 output. This lets us test Agent 9 + Validator behavior
against controlled, varied spec inputs.

Usage:
    .venv\\Scripts\\python.exe scripts/run_powerbi_test_spec.py <spec_file> [--session csv|excel]

Examples:
    .venv\\Scripts\\python.exe scripts/run_powerbi_test_spec.py service/daan/native_tools/power_bi/test_specs/csv_spec_01_supply_chain_overview.md --session csv
    .venv\\Scripts\\python.exe scripts/run_powerbi_test_spec.py service/daan/native_tools/power_bi/test_specs/excel_spec_01_service_overview.md --session excel

Sessions:
    csv   -> 30a99ee8-e082-4ca0-8279-a51c989c30d3 (Product, Purchase, Sales, Transportation CSVs)
    excel -> 7a254e0f-2fd0-4086-b9d6-00f93c796310 (raw_data.xlsx with IT incident data)

The script:
    1. Reads the spec file
    2. Backs up existing AGENT_8/output.md (if any)
    3. Writes the spec as AGENT_8/output.md
    4. Runs report-only simulation
    5. Restores the backup
"""
import argparse
import asyncio
import json
import shutil
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Add service to path for imports
sys.path.insert(0, str(PROJECT_ROOT / "service"))

SESSION_MAP = {
    "csv": "30a99ee8-e082-4ca0-8279-a51c989c30d3",
    "excel": "7a254e0f-2fd0-4086-b9d6-00f93c796310",
}

PROMPT_FILE = PROJECT_ROOT / "z_powerbi_prompt.md"


def detect_session(spec_path: Path) -> str:
    """Auto-detect session from spec filename."""
    name = spec_path.stem.lower()
    if name.startswith("csv_"):
        return "csv"
    elif name.startswith("excel_"):
        return "excel"
    return ""


def load_spec(spec_path: Path) -> str:
    """Load the test spec markdown."""
    if not spec_path.exists():
        raise FileNotFoundError(f"Spec file not found: {spec_path}")
    return spec_path.read_text(encoding="utf-8")


async def run_test(spec_path: Path, session_key: str) -> None:
    """Run the Power BI report generation with a test spec."""
    # Lazy import to avoid import errors before path setup
    from simulate_powerbi import (
        load_context_map,
        get_agent_config,
        build_report_generation_input,
        run_agent,
        AGENT_IDS,
    )

    session_id = SESSION_MAP[session_key]
    spec_content = load_spec(spec_path)

    # Paths
    session_dir = PROJECT_ROOT / "session_storage" / session_id
    agent8_dir = session_dir / "agents" / "AGENT_8"
    agent9_dir = session_dir / "agents" / "AGENT_9"
    output_md = agent8_dir / "output.md"
    backup_md = agent8_dir / "output.md.bak"

    # Backup existing spec
    agent8_dir.mkdir(parents=True, exist_ok=True)
    had_backup = False
    if output_md.exists():
        shutil.copy2(output_md, backup_md)
        had_backup = True

    try:
        # Write test spec
        output_md.write_text(spec_content, encoding="utf-8")

        # Load context map and run
        context_map = load_context_map(session_id)

        print("=" * 80)
        print("POWER BI TEST SPEC SIMULATION")
        print("=" * 80)
        print(f"  Spec file: {spec_path.name}")
        print(f"  Session:   {session_key} ({session_id})")
        print(f"  Spec size: {len(spec_content)} chars")
        print(f"  Lines:     {spec_content.count(chr(10)) + 1}")

        # Count visuals (rows minus header)
        visual_count = spec_content.count("\n|") - 1  # subtract header separator
        print(f"  Visuals:   ~{visual_count}")

        print("\n" + "=" * 80)
        print("STAGE: Report Generation (Power BI Project)")
        print("=" * 80)

        agent_config = get_agent_config(context_map, AGENT_IDS["report_generation"])
        input_msg = build_report_generation_input(spec_content)

        start = time.time()
        output = await run_agent(agent_config, input_msg, session_id, "report_generation")
        elapsed = time.time() - start

        # Save agent 9 output
        agent9_dir.mkdir(parents=True, exist_ok=True)
        test_output_name = f"test_{spec_path.stem}_output.md"
        test_output_path = agent9_dir / test_output_name
        test_output_path.write_text(output, encoding="utf-8")

        print(f"\n  Output saved to: {test_output_path}")
        print(f"\n{'=' * 80}")
        print(f"DONE in {elapsed:.1f}s")
        print(f"{'=' * 80}")

        # Check for artifacts
        artifacts_dir = session_dir / "artifacts"
        if artifacts_dir.exists():
            projects = [d.name for d in artifacts_dir.iterdir() if d.is_dir()]
            if projects:
                print(f"\n  Generated projects: {projects}")
                latest = artifacts_dir / projects[-1]
                pbip_files = list(latest.rglob("*.pbip"))
                if pbip_files:
                    print(f"  PBIP file: {pbip_files[0]}")

    finally:
        # Restore backup
        if had_backup:
            shutil.copy2(backup_md, output_md)
            backup_md.unlink()
        elif output_md.exists():
            output_md.unlink()


def list_specs() -> None:
    """List available test specs."""
    specs_dir = PROJECT_ROOT / "service" / "daan" / "native_tools" / "power_bi" / "test_specs"
    if not specs_dir.exists():
        print("No test_specs directory found.")
        return

    print("\nAvailable test specs:")
    print("-" * 60)
    for f in sorted(specs_dir.glob("*.md")):
        lines = f.read_text(encoding="utf-8").strip().split("\n")
        visual_count = len(lines) - 2  # minus header + separator
        session = "csv" if f.stem.startswith("csv_") else "excel"
        print(f"  [{session:5}] {f.name} ({visual_count} visuals)")


def main():
    parser = argparse.ArgumentParser(description="Run Power BI test specs")
    parser.add_argument("spec_file", nargs="?", help="Path to spec .md file")
    parser.add_argument(
        "--session", choices=["csv", "excel"],
        help="Session to use (auto-detected from filename if not specified)"
    )
    parser.add_argument("--list", action="store_true", help="List available test specs")

    args = parser.parse_args()

    if args.list:
        list_specs()
        return

    if not args.spec_file:
        parser.print_help()
        print("\n")
        list_specs()
        return

    spec_path = Path(args.spec_file)
    if not spec_path.is_absolute():
        spec_path = PROJECT_ROOT / spec_path

    # Detect or use session
    session_key = args.session or detect_session(spec_path)
    if not session_key:
        print("ERROR: Cannot detect session from filename. Use --session csv|excel")
        sys.exit(1)

    # Change to scripts dir so simulate_powerbi imports work
    import os
    os.chdir(PROJECT_ROOT / "scripts")
    sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

    asyncio.run(run_test(spec_path, session_key))


if __name__ == "__main__":
    main()
