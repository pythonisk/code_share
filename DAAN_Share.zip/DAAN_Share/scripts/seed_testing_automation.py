"""
Seed Script — Denodo to Fabric Migration Testing Automation Use Case

Reads config/usecase_testing.yaml and populates DAAN5's database with:
  - Archetype  : "Data Engineering"
  - UseCase    : UC_TA_001 — Denodo to Fabric Migration Testing Automation
  - Agents     : AGENT_TA_01 … AGENT_TA_06 with prompts and configurations
  - Mappings   : UseCaseArchetypeMapping + UseCaseAgentMapping

Usage (from the service/ directory with the venv activated):
    python ../scripts/seed_testing_automation.py

Re-running is safe — existing records are detected and skipped / updated.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Bootstrap the Python path so DAAN modules are importable
# ---------------------------------------------------------------------------
_SCRIPT_DIR = Path(__file__).resolve().parent          # scripts/
_SERVICE_DIR = _SCRIPT_DIR.parent / "service"          # service/
_WORKSPACE_ROOT = _SCRIPT_DIR.parent                   # repo root

for p in (_SERVICE_DIR, _WORKSPACE_ROOT):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

# Also set the working directory to service/ so relative imports work
os.chdir(str(_SERVICE_DIR))

import yaml
from sqlalchemy.orm import Session

from daan.core.database import SessionLocal, init_db
from daan.models.archetype import (
    Agent,
    Archetype,
    GeneratedPrompt,
    UseCase,
    UseCaseAgentMapping,
    UseCaseArchetypeMapping,
)

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
_CONFIG_PATH = _WORKSPACE_ROOT / "config" / "usecase_testing.yaml"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_config() -> dict:
    if not _CONFIG_PATH.exists():
        raise FileNotFoundError(f"usecase_testing.yaml not found at {_CONFIG_PATH}")
    with _CONFIG_PATH.open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def _get_or_create_archetype(db: Session, name: str, description: str) -> Archetype:
    arch = db.query(Archetype).filter_by(name=name).first()
    if arch:
        print(f"  [archetype] '{name}' already exists (id={arch.id}) — skipping.")
        return arch
    arch = Archetype(name=name, description=description)
    db.add(arch)
    db.flush()
    print(f"  [archetype] Created '{name}' (id={arch.id}).")
    return arch


def _get_or_create_usecase(db: Session, cfg: dict) -> UseCase:
    uc = db.query(UseCase).filter_by(usecaseid=cfg["usecase_id"]).first()
    if uc:
        print(f"  [usecase] '{cfg['usecase_id']}' already exists — updating fields.")
        uc.name = cfg["name"]
        uc.task = cfg.get("task")
        uc.role = cfg.get("role")
        uc.premium = cfg.get("premium", "false")
        uc.dag = cfg.get("dag")
        uc.flow_of_agents = cfg.get("flow_of_agents")
        uc.category = cfg.get("category")
        agent_names = [a["agent_name"] for a in cfg.get("agents", [])]
        uc.agents_involved = ", ".join(agent_names)
        return uc

    agent_names = [a["agent_name"] for a in cfg.get("agents", [])]
    uc = UseCase(
        usecaseid=cfg["usecase_id"],
        name=cfg["name"],
        task=cfg.get("task"),
        role=cfg.get("role"),
        premium=cfg.get("premium", "false"),
        dag=cfg.get("dag"),
        flow_of_agents=cfg.get("flow_of_agents"),
        category=cfg.get("category"),
        agents_involved=", ".join(agent_names),
    )
    db.add(uc)
    db.flush()
    print(f"  [usecase] Created '{cfg['usecase_id']}'.")
    return uc


def _ensure_archetype_usecase_mapping(
    db: Session, archetype: Archetype, usecase: UseCase
) -> None:
    exists = (
        db.query(UseCaseArchetypeMapping)
        .filter_by(usecase_id=usecase.usecaseid, archetype_id=archetype.id)
        .first()
    )
    if not exists:
        db.add(UseCaseArchetypeMapping(usecase_id=usecase.usecaseid, archetype_id=archetype.id))
        db.flush()
        print(f"  [mapping] Linked '{usecase.usecaseid}' ↔ archetype '{archetype.name}'.")
    else:
        print(f"  [mapping] Archetype ↔ UseCase mapping already exists — skipping.")


def _get_or_create_prompt(db: Session, agent_id: str, prompt_text: str) -> GeneratedPrompt:
    # Find existing prompt linked through an Agent record
    agent = db.query(Agent).filter_by(agent_id=agent_id).first()
    if agent and agent.prompt_id:
        prompt = db.query(GeneratedPrompt).filter_by(id=agent.prompt_id).first()
        if prompt:
            prompt.prompt_text = prompt_text
            print(f"    [prompt] Updated prompt for agent '{agent_id}'.")
            return prompt

    prompt = GeneratedPrompt(prompt_name=f"prompt_{agent_id}", prompt_text=prompt_text)
    db.add(prompt)
    db.flush()
    print(f"    [prompt] Created prompt for agent '{agent_id}' (id={prompt.id}).")
    return prompt


def _upsert_agent(db: Session, agent_cfg: dict, usecase_id: str) -> Agent:
    agent_id = agent_cfg["agent_id"]
    prompt_text = (agent_cfg.get("prompt") or "").strip()
    prompt = _get_or_create_prompt(db, agent_id, prompt_text)

    agent = db.query(Agent).filter_by(agent_id=agent_id).first()
    if agent:
        print(f"    [agent] '{agent_id}' already exists — updating.")
    else:
        agent = Agent(agent_id=agent_id)
        db.add(agent)

    agent.agent_name = agent_cfg.get("agent_name", agent_id)
    agent.role = agent_cfg.get("role", "")
    agent.input_context = (agent_cfg.get("input_context") or "")[:1000]
    agent.output_format = (agent_cfg.get("output_format") or "")[:1000]
    agent.agent_actions = (agent_cfg.get("actions") or "")[:1000]
    agent.output_validators = (agent_cfg.get("output_validators") or "")[:1000]
    agent.guardrails = (agent_cfg.get("guardrails") or "")[:1000]
    agent.mcp_server = (agent_cfg.get("mcp_tools") or "")[:255]
    agent.local_tools = (agent_cfg.get("local_tools") or "")[:1000]
    agent.agent_type = (agent_cfg.get("agent_type") or "dynamic_agent")[:255]
    agent.depend_on = (agent_cfg.get("depend_on") or "")[:255]
    agent.prompt_id = prompt.id

    db.flush()
    return agent


def _ensure_agent_usecase_mapping(
    db: Session,
    agent: Agent,
    usecase_id: str,
    execution_order: int,
) -> None:
    exists = (
        db.query(UseCaseAgentMapping)
        .filter_by(usecase_id=usecase_id, agent_id=agent.agent_id)
        .first()
    )
    if not exists:
        db.add(
            UseCaseAgentMapping(
                usecase_id=usecase_id,
                agent_id=agent.agent_id,
                execution_order=execution_order,
            )
        )
        db.flush()
        print(f"    [mapping] Linked agent '{agent.agent_id}' → usecase '{usecase_id}' (order={execution_order}).")
    else:
        exists.execution_order = execution_order
        print(f"    [mapping] Agent ↔ UseCase mapping updated (order={execution_order}).")


# ---------------------------------------------------------------------------
# Main seeding logic
# ---------------------------------------------------------------------------

def seed() -> None:
    print("=" * 60)
    print("DAAN5 — Testing Automation Use Case Seed")
    print("=" * 60)

    cfg = _load_config()
    print(f"\nLoaded config from: {_CONFIG_PATH}")
    print(f"UseCase: {cfg['usecase_id']} — {cfg['name']}")
    print(f"Archetype: {cfg['archetype']}")
    print(f"Agents: {len(cfg.get('agents', []))}\n")

    # Ensure tables exist (idempotent)
    init_db()

    with SessionLocal() as db:
        # 1. Archetype
        print("[Step 1] Archetype")
        arch = _get_or_create_archetype(
            db,
            name=cfg["archetype"],
            description=(
                "Data engineering and ETL automation use cases covering data pipeline "
                "development, migration validation, and workflow orchestration."
            ),
        )

        # 2. UseCase
        print("\n[Step 2] UseCase")
        usecase = _get_or_create_usecase(db, cfg)

        # 3. Archetype ↔ UseCase mapping
        print("\n[Step 3] Archetype ↔ UseCase mapping")
        _ensure_archetype_usecase_mapping(db, arch, usecase)

        # 4. Agents + prompts + mappings
        print("\n[Step 4] Agents, Prompts, and Mappings")
        for agent_cfg in cfg.get("agents", []):
            print(f"\n  Agent: {agent_cfg['agent_id']} — {agent_cfg['agent_name']}")
            agent = _upsert_agent(db, agent_cfg, usecase.usecaseid)
            _ensure_agent_usecase_mapping(
                db, agent, usecase.usecaseid, agent_cfg.get("execution_order", 0)
            )

        db.commit()
        print("\n" + "=" * 60)
        print("✅ Seed complete. All records committed.")
        print("=" * 60)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    seed()
