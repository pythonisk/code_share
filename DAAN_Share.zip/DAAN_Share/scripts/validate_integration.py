"""
DAAN5 Integration Validation Script
====================================
Validates all MCP server configurations, agent YAMLs, CSV registrations,
Python syntax, environment variable presence, and agent orchestration chains.

Run:  python scripts/validate_integration.py
Exit: 0 = all pass, 1 = failures detected
"""

import ast
import csv
import importlib.util
import os
import sys
from pathlib import Path

import yaml

# ---------------------------------------------------------------------------
# Resolve paths
# ---------------------------------------------------------------------------
REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = REPO_ROOT / "config"
SERVICE_DIR = REPO_ROOT / "service"
DATA_DIR = REPO_ROOT / "data" / "Archetypes" / "Customer Proposed Use Cases"

PASS = []
FAIL = []
WARN = []


def _pass(msg: str):
    PASS.append(msg)


def _fail(msg: str):
    FAIL.append(msg)


def _warn(msg: str):
    WARN.append(msg)


# ---------------------------------------------------------------------------
# 1. Config YAML parsing
# ---------------------------------------------------------------------------
def validate_mcp_config():
    path = CONFIG_DIR / "mcp_servers_registry.yml"
    if not path.exists():
        _fail(f"mcp_servers_registry.yml not found at {path}")
        return
    try:
        cfg = yaml.safe_load(path.read_text(encoding="utf-8"))
        servers = cfg.get("servers", {})
        _pass(f"mcp_servers_registry.yml: parses OK ({len(servers)} server(s))")

        required_servers = ["atlassian-mcp", "snowflake-mcp-server", "databricks-mcp-server"]
        for name in required_servers:
            if name in servers:
                srv = servers[name]
                if srv.get("enabled"):
                    _pass(f"  {name}: enabled")
                else:
                    _warn(f"  {name}: present but disabled")
                transport = srv.get("transport", "")
                if transport not in ("stdio", "streamable_http", "http", "https"):
                    _fail(f"  {name}: unsupported transport '{transport}'")
                if transport == "stdio" and not srv.get("command"):
                    _fail(f"  {name}: stdio transport but no command specified")

                if name == "snowflake-mcp-server":
                    command = str(srv.get("command", "")).strip()
                    args = srv.get("args") or []
                    env_mapping = srv.get("env_mapping") or {}
                    if command != "python":
                        _fail("  snowflake-mcp-server: command must be 'python' for repo-local MCP startup")
                    joined_args = " ".join(args) if isinstance(args, list) else str(args)
                    if "daan.mcp_servers.snowflake_mcp_server" not in joined_args:
                        _fail("  snowflake-mcp-server: args must bootstrap daan.mcp_servers.snowflake_mcp_server")
                    for env_key in [
                        "SNOWFLAKE_ACCOUNT",
                        "SNOWFLAKE_USER",
                        "SNOWFLAKE_PASSWORD",
                        "SNOWFLAKE_DATABASE",
                        "SNOWFLAKE_SCHEMA",
                        "SNOWFLAKE_WAREHOUSE",
                    ]:
                        if env_key not in env_mapping.values():
                            _fail(f"  snowflake-mcp-server: missing env_mapping value {env_key}")
            else:
                _fail(f"  {name}: MISSING from registry")

    except Exception as e:
        _fail(f"mcp_servers_registry.yml: parse error: {e}")


# ---------------------------------------------------------------------------
# 2. Python file syntax validation
# ---------------------------------------------------------------------------
def validate_python_files():
    py_files = [
        SERVICE_DIR / "daan" / "mcp_servers" / "snowflake_mcp_server.py",
        SERVICE_DIR / "daan" / "mcp_servers" / "databricks_mcp_server.py",
        SERVICE_DIR / "daan" / "native_tools" / "DatabricksNotebookPublisher.py",
        SERVICE_DIR / "daan" / "mcp_servers" / "mcp_toolset_provider.py",
        SERVICE_DIR / "daan" / "native_tools" / "tools_loader.py",
    ]
    for fp in py_files:
        if not fp.exists():
            _fail(f"{fp.name}: file not found")
            continue
        try:
            ast.parse(fp.read_text(encoding="utf-8"))
            _pass(f"{fp.name}: syntax OK")
        except SyntaxError as e:
            _fail(f"{fp.name}: syntax error at line {e.lineno}: {e.msg}")


# ---------------------------------------------------------------------------
# 3. Agent YAML validation
# ---------------------------------------------------------------------------
def validate_agent_yamls():
    agents_dir = DATA_DIR / "agents"
    if not agents_dir.exists():
        _fail("agents/ directory not found")
        return

    for yml in sorted(agents_dir.glob("*.y*ml")):
        try:
            data = yaml.safe_load(yml.read_text(encoding="utf-8"))
            agent = data.get("agent", data)  # Handle both nested and flat
            agent_id = agent.get("id", "??")
            _pass(f"{yml.name}: valid (id={agent_id})")

            # Check prompt file exists
            prompt_file = agent.get("prompt_file", "")
            if prompt_file:
                prompt_path = REPO_ROOT / prompt_file
                if not prompt_path.exists():
                    _fail(f"  {yml.name}: prompt_file not found: {prompt_file}")

            # Check for hardcoded absolute paths
            for key, val in agent.items():
                if isinstance(val, str) and ("C:\\" in val or "C:/" in val):
                    _fail(f"  {yml.name}: hardcoded absolute path in '{key}': {val[:80]}")

            # Validate agent_type
            atype = agent.get("agent_type", "")
            if atype and atype not in ("Sub_Agent", "actionagent", "Custom_Action_Agent"):
                _warn(f"  {yml.name}: unexpected agent_type '{atype}'")

        except Exception as e:
            _fail(f"{yml.name}: parse error: {e}")


# ---------------------------------------------------------------------------
# 4. CSV validation
# ---------------------------------------------------------------------------
def validate_csv_files():
    # Agents.csv
    agents_csv = DATA_DIR / "Agents.csv"
    if not agents_csv.exists():
        _fail("Agents.csv not found")
    else:
        try:
            with open(agents_csv, newline="", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
            ids = [r.get("ID", "") for r in rows]
            _pass(f"Agents.csv: {len(rows)} agent(s)")

            # Check required agents
            for req_id in ["AGENT_13", "AGENT_14"]:
                if req_id in ids:
                    _pass(f"  Agents.csv: {req_id} present")
                else:
                    _fail(f"  Agents.csv: {req_id} MISSING")

            if "AGENT_7" in ids:
                _fail("  Agents.csv: AGENT_7 should be removed from the Snowflake flow")

            # Validate each row has required fields
            required_cols = ["ID", "Role", "Agent Name", "AgentType"]
            for row in rows:
                rid = row.get("ID", "??")
                for col in required_cols:
                    if not row.get(col, "").strip():
                        _warn(f"  Agents.csv: {rid} missing '{col}'")
        except Exception as e:
            _fail(f"Agents.csv: parse error: {e}")

    # UseCases.csv
    uc_csv = DATA_DIR / "UseCases.csv"
    if not uc_csv.exists():
        _fail("UseCases.csv not found")
    else:
        try:
            with open(uc_csv, newline="", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
            ids = [r.get("usecaseid", "") for r in rows]
            _pass(f"UseCases.csv: {len(rows)} use case(s)")

            if "UC_CP_006" in ids:
                _pass("  UseCases.csv: UC_CP_006 present")
                row = next((r for r in rows if r.get("usecaseid", "") == "UC_CP_006"), None)
                if row:
                    dag = (row.get("dag", "") or "").strip()
                    if dag == "AGENT_13>AGENT_14":
                        _pass("  UseCases.csv: UC_CP_006 DAG is AGENT_13>AGENT_14")
                    else:
                        _fail(f"  UseCases.csv: UC_CP_006 DAG expected AGENT_13>AGENT_14 but found '{dag}'")
            else:
                _fail("  UseCases.csv: UC_CP_006 MISSING")
        except Exception as e:
            _fail(f"UseCases.csv: parse error: {e}")


# ---------------------------------------------------------------------------
# 5. Environment variable checks
# ---------------------------------------------------------------------------
def validate_env_vars():
    env_file = CONFIG_DIR / ".env"
    if env_file.exists():
        _pass(".env file exists")
    else:
        _warn(".env file not found (needed for runtime credentials)")

    # Validate MCP env: check env_mapping values from registry are available at runtime
    import re
    mcp_registry_path = CONFIG_DIR / "mcp_servers_registry.yml"
    if mcp_registry_path.exists():
        try:
            reg_cfg = yaml.safe_load(mcp_registry_path.read_text(encoding="utf-8")) or {}
            for sname, scfg in (reg_cfg.get("servers") or {}).items():
                if not isinstance(scfg, dict):
                    continue
                env_mapping = scfg.get("env_mapping")
                if not isinstance(env_mapping, dict):
                    continue
                for cred_key, env_var in env_mapping.items():
                    if os.getenv(env_var, ""):
                        _pass(f"  env {env_var}: set")
        except Exception:
            pass


# ---------------------------------------------------------------------------
# 6. Agent orchestration chain validation
# ---------------------------------------------------------------------------
def validate_orchestration():
    """Verify depends_on chains are consistent between agents and use cases."""
    agents_dir = DATA_DIR / "agents"
    if not agents_dir.exists():
        return

    agent_map = {}
    for yml in agents_dir.glob("*.y*ml"):
        try:
            data = yaml.safe_load(yml.read_text(encoding="utf-8"))
            agent = data.get("agent", data)
            aid = agent.get("id", "")
            if aid:
                agent_map[aid] = {
                    "depends_on": agent.get("depends_on", []),
                    "mcp_servers": agent.get("required_mcp_servers", []),
                    "local_tools": agent.get("local_tools", []),
                    "file": yml.name,
                }
        except Exception:
            pass

    if not agent_map:
        agents_csv = DATA_DIR / "Agents.csv"
        if agents_csv.exists():
            with open(agents_csv, newline="", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
            for row in rows:
                agent_id = row.get("ID", "").strip()
                if agent_id:
                    deps = row.get("DependOn", "").strip().strip("[]")
                    dep_list = [part.strip() for part in deps.split(",") if part.strip()]
                    mcp_value = row.get("MCPServer", "").strip().strip("[]")
                    mcp_list = [part.strip() for part in mcp_value.split(",") if part.strip()]
                    agent_map[agent_id] = {
                        "depends_on": dep_list,
                        "mcp_servers": mcp_list,
                        "local_tools": [row.get("LocalTools", "").strip()] if row.get("LocalTools", "").strip() else [],
                        "file": "Agents.csv",
                    }

    # Check AGENT_13 → AGENT_14 chain
    exec_agent = agent_map.get("AGENT_14")
    if exec_agent:
        deps = exec_agent["depends_on"]
        if "AGENT_13" in deps:
            if "AGENT_13" in agent_map:
                _pass("Orchestration: AGENT_13 -> AGENT_14 chain valid")
            else:
                _fail("Orchestration: AGENT_14 depends on AGENT_13 but AGENT_13 not found")
        else:
            _fail("Orchestration: AGENT_14 doesn't list AGENT_13 in depends_on")

        # Check MCP server reference
        if "snowflake-mcp-server" in exec_agent.get("mcp_servers", []):
            _pass("Orchestration: AGENT_14 references snowflake-mcp-server")
        else:
            _warn("Orchestration: AGENT_14 missing snowflake-mcp-server reference")
    else:
        _fail("Orchestration: AGENT_14 not found in Snowflake metadata")

    router_agent = agent_map.get("AGENT_13")
    if router_agent:
        if not router_agent.get("mcp_servers"):
            _pass("Orchestration: AGENT_13 has no MCP server as expected")
        elif router_agent.get("mcp_servers") == ["[]"]:
            _pass("Orchestration: AGENT_13 has no MCP server as expected")
        else:
            _fail("Orchestration: AGENT_13 should not reference an MCP server")
    else:
        _fail("Orchestration: AGENT_13 not found in Snowflake metadata")

    # Verify all depends_on references are resolvable
    for aid, info in agent_map.items():
        for dep in info["depends_on"]:
            if dep and dep not in agent_map:
                _warn(f"Orchestration: {aid} depends on '{dep}' which has no YAML definition")


# ---------------------------------------------------------------------------
# 7. Requirements.txt check
# ---------------------------------------------------------------------------
def validate_requirements():
    req_file = SERVICE_DIR / "requirements.txt"
    if not req_file.exists():
        _fail("requirements.txt not found")
        return
    content = req_file.read_text(encoding="utf-8")
    required_pkgs = ["requests", "mcp", "google-adk", "PyYAML"]
    for pkg in required_pkgs:
        if pkg in content:
            _pass(f"requirements.txt: {pkg} present")
        else:
            _fail(f"requirements.txt: {pkg} MISSING")


# ---------------------------------------------------------------------------
# 8. Prompt file content validation
# ---------------------------------------------------------------------------
def validate_prompts():
    prompt_dir = DATA_DIR / "prompts"
    sf_prompt = prompt_dir / "ExecuteSnowflakeSQL.prompt.md"
    if sf_prompt.exists():
        _fail("ExecuteSnowflakeSQL.prompt.md should be removed because Snowflake agents are DB-backed")
    else:
        _pass("ExecuteSnowflakeSQL.prompt.md removed as expected")

    gen_prompt = prompt_dir / "SnowflakeStoredProcedureGeneration.prompt.md"
    if gen_prompt.exists():
        _fail("SnowflakeStoredProcedureGeneration.prompt.md should be removed because Snowflake agents are DB-backed")
    else:
        _pass("SnowflakeStoredProcedureGeneration.prompt.md removed as expected")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    print(f"DAAN5 Integration Validation")
    print(f"Repository: {REPO_ROOT}")
    print("=" * 60)

    validate_mcp_config()
    validate_python_files()
    validate_agent_yamls()
    validate_csv_files()
    validate_env_vars()
    validate_orchestration()
    validate_requirements()
    validate_prompts()

    print()
    print("=== RESULTS ===")
    for msg in PASS:
        print(f"  \033[92mPASS\033[0m  {msg}")
    for msg in WARN:
        print(f"  \033[93mWARN\033[0m  {msg}")
    for msg in FAIL:
        print(f"  \033[91mFAIL\033[0m  {msg}")

    print()
    total = len(PASS) + len(WARN) + len(FAIL)
    print(f"Total: {len(PASS)} passed, {len(WARN)} warnings, {len(FAIL)} failed (out of {total} checks)")

    if FAIL:
        print("\n*** VALIDATION FAILED ***")
        return 1
    if WARN:
        print("\n*** VALIDATION PASSED WITH WARNINGS ***")
    else:
        print("\n*** ALL CHECKS PASSED ***")
    return 0


if __name__ == "__main__":
    sys.exit(main())
