"""
Bulk SharePoint Ingestion — indexes a large SharePoint folder (e.g. D-AURA)
into a knowledge base without going through the HTTP API, so long runs are
not bound by a client request timeout.

Reuses the exact same pipeline as the RagTool.index_file_structured() call
(RagIndexingService.index_documents), so batching, per-file citations, and
resumability (already-indexed sources are skipped) are identical to running
it through the API.

Resumability: the vector store skips files whose `source` already exists in
the collection, so a crashed/interrupted run can simply be re-launched.
Embedding calls also retry-with-backoff on rate-limit errors internally
(RagIndexingService._embed_with_retry), so this script's own retry loop is a
second safety net for other transient failures (e.g. Graph API hiccups).

Usage (from the service/ directory with the venv activated):
    python ../scripts/ingest_sharepoint_kb.py --kb-id DnA
    python ../scripts/ingest_sharepoint_kb.py --kb-id DnA --limit 20
    python ../scripts/ingest_sharepoint_kb.py --kb-id DnA --folder-path D-AURA --max-retries 10
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys
import time
from pathlib import Path

# ---------------------------------------------------------------------------
# Bootstrap the Python path so DAAN modules are importable
# ---------------------------------------------------------------------------
_SCRIPT_DIR = Path(__file__).resolve().parent          # scripts/
_SERVICE_DIR = _SCRIPT_DIR.parent / "service"          # service/
_WORKSPACE_ROOT = _SCRIPT_DIR.parent                   # repo root

for p in (_SERVICE_DIR, _WORKSPACE_ROOT):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

os.chdir(str(_SERVICE_DIR))

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("ingest_sharepoint_kb")

from daan.core.config import get_settings  # noqa: E402
from daan.native_tools.rag_tool import RagTool  # noqa: E402


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--kb-id", default="DnA", help="Target knowledge base id (default: DnA)")
    parser.add_argument("--folder-path", default=None, help="SharePoint folder to ingest (default: rag_config.yml sharepoint_loader_kwargs.folder_path)")
    parser.add_argument("--limit", type=int, default=None, help="Cap on newly-processed files, for a smoke-test run before a full ingestion")
    parser.add_argument("--max-candidates", type=int, default=None, help="Maximum eligible SharePoint files to try while satisfying --limit")
    parser.add_argument("--no-graph", action="store_true", help="Skip graph store indexing for faster smoke tests (only index vector store)")
    parser.add_argument("--max-retries", type=int, default=10, help="Outer retries on non-embedding transient failures (default: 10)")
    parser.add_argument("--retry-delay-seconds", type=int, default=60, help="Base delay before an outer retry, multiplied by attempt number (default: 60)")
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    settings = get_settings()
    rag_config = settings.load_rag_config()

    document_loaders_config = dict(rag_config.get("document_loaders") or {})
    folder_path = args.folder_path or str(
        (document_loaders_config.get("sharepoint_loader_kwargs") or {}).get("folder_path") or "D-AURA"
    )
    max_candidates = None

    if args.limit is not None:
        # Keep discovery bounded while allowing malformed files to be skipped.
        loader_kwargs = dict(document_loaders_config.get("sharepoint_loader_kwargs") or {})
        loader_kwargs["folder_path"] = folder_path
        loader_kwargs["max_files"] = args.limit
        max_candidates = args.max_candidates or max(args.limit * 20, 20)
        loader_kwargs["max_candidates"] = max_candidates
        document_loaders_config["sharepoint_loader_kwargs"] = loader_kwargs
        rag_config["document_loaders"] = document_loaders_config

    logger.info(
        "kb_id=%s folder=%s limit=%s max_candidates=%s max_retries=%d",
        args.kb_id,
        folder_path,
        args.limit,
        max_candidates,
        args.max_retries,
    )

    tool = RagTool(rag_config)
    attempt = 0
    while True:
        attempt += 1
        try:
            result = asyncio.run(
                tool.index_file_structured(
                    file_path=folder_path,
                    kb_id=args.kb_id,
                    source_type="sharepoint",
                    include_graph_store=not args.no_graph,
                    link_entity_mentions=not args.no_graph,
                )
            )
            logger.info("Ingestion complete: %s", result)
            return
        except Exception as exc:  # noqa: BLE001
            if attempt > args.max_retries:
                logger.error("Giving up after %d attempts: %s", attempt, exc)
                raise
            delay = args.retry_delay_seconds * attempt
            logger.warning(
                "Attempt %d/%d failed (%s); already-indexed files will be skipped on retry. Sleeping %ds.",
                attempt, args.max_retries, exc, delay,
            )
            time.sleep(delay)


if __name__ == "__main__":
    main()
