#!/usr/bin/env python3
"""
Export MySQL database to SQLite.

Usage:
    python scripts/export_mysql_to_sqlite.py --output data/exports/daan-dev.sqlite3
"""

import argparse
import os
import sqlite3
import sys
from pathlib import Path

# Add service directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "service"))

try:
    import pymysql
except ImportError:
    print("Error: pymysql is required. Install with: pip install pymysql")
    sys.exit(1)


# MySQL connection settings from environment or defaults
MYSQL_CONFIG = {
    "host": os.getenv("DB_HOST", "daan-mysql-server.mysql.database.azure.com"),
    "port": int(os.getenv("DB_PORT", 3306)),
    "user": os.getenv("DB_USER", "daan_mysql_admin"),
    "password": os.getenv("DB_PASSWORD", "DevDB@#!@#").strip("'"),
    "database": os.getenv("DB_NAME", "daan-dev"),
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor,
    "ssl": {"ssl": True},  # Enable SSL for Azure MySQL
}


def mysql_to_sqlite_type(mysql_type: str) -> str:
    """Convert MySQL data type to SQLite data type."""
    mysql_type = mysql_type.upper()
    
    # Integer types
    if any(t in mysql_type for t in ["TINYINT", "SMALLINT", "MEDIUMINT", "INT", "BIGINT"]):
        return "INTEGER"
    
    # Floating point types
    if any(t in mysql_type for t in ["FLOAT", "DOUBLE", "DECIMAL", "NUMERIC"]):
        return "REAL"
    
    # Text types
    if any(t in mysql_type for t in ["CHAR", "VARCHAR", "TEXT", "TINYTEXT", "MEDIUMTEXT", "LONGTEXT", "ENUM", "SET"]):
        return "TEXT"
    
    # Binary types
    if any(t in mysql_type for t in ["BLOB", "TINYBLOB", "MEDIUMBLOB", "LONGBLOB", "BINARY", "VARBINARY"]):
        return "BLOB"
    
    # Date/time types
    if any(t in mysql_type for t in ["DATE", "TIME", "DATETIME", "TIMESTAMP", "YEAR"]):
        return "TEXT"
    
    # JSON type
    if "JSON" in mysql_type:
        return "TEXT"
    
    # Boolean
    if "BOOL" in mysql_type:
        return "INTEGER"
    
    return "TEXT"


def get_mysql_tables(cursor) -> list[str]:
    """Get list of all tables in the MySQL database."""
    cursor.execute("SHOW TABLES")
    return [list(row.values())[0] for row in cursor.fetchall()]


def get_table_schema(cursor, table_name: str) -> list[dict]:
    """Get column information for a table."""
    cursor.execute(f"DESCRIBE `{table_name}`")
    return cursor.fetchall()


def get_primary_keys(cursor, table_name: str) -> list[str]:
    """Get primary key columns for a table."""
    cursor.execute(f"SHOW KEYS FROM `{table_name}` WHERE Key_name = 'PRIMARY'")
    return [row["Column_name"] for row in cursor.fetchall()]


def create_sqlite_table(sqlite_cursor, table_name: str, columns: list[dict], primary_keys: list[str]):
    """Create a table in SQLite with the given schema."""
    column_defs = []
    
    for col in columns:
        col_name = col["Field"]
        col_type = mysql_to_sqlite_type(col["Type"])
        nullable = col["Null"] == "YES"
        default = col["Default"]
        
        col_def = f'"{col_name}" {col_type}'
        
        if not nullable:
            col_def += " NOT NULL"
        
        if default is not None:
            if col_type == "TEXT":
                col_def += f" DEFAULT '{default}'"
            else:
                col_def += f" DEFAULT {default}"
        
        column_defs.append(col_def)
    
    # Add primary key constraint
    if primary_keys:
        pk_cols = ", ".join(f'"{pk}"' for pk in primary_keys)
        column_defs.append(f"PRIMARY KEY ({pk_cols})")
    
    create_sql = f'CREATE TABLE IF NOT EXISTS "{table_name}" (\n  ' + ",\n  ".join(column_defs) + "\n)"
    
    try:
        sqlite_cursor.execute(create_sql)
    except sqlite3.Error as e:
        print(f"Error creating table {table_name}: {e}")
        print(f"SQL: {create_sql}")
        raise


def copy_table_data(mysql_cursor, sqlite_conn, table_name: str, columns: list[dict]):
    """Copy all data from MySQL table to SQLite table."""
    col_names = [col["Field"] for col in columns]
    col_list = ", ".join(f"`{c}`" for c in col_names)
    
    mysql_cursor.execute(f"SELECT {col_list} FROM `{table_name}`")
    rows = mysql_cursor.fetchall()
    
    if not rows:
        return 0
    
    placeholders = ", ".join(["?" for _ in col_names])
    quoted_cols = ", ".join(f'"{c}"' for c in col_names)
    insert_sql = f'INSERT INTO "{table_name}" ({quoted_cols}) VALUES ({placeholders})'
    
    sqlite_cursor = sqlite_conn.cursor()
    count = 0
    
    for row in rows:
        values = [row[col] for col in col_names]
        # Convert any non-serializable types
        values = [str(v) if isinstance(v, (bytes, bytearray)) else v for v in values]
        try:
            sqlite_cursor.execute(insert_sql, values)
            count += 1
        except sqlite3.Error as e:
            print(f"Error inserting row into {table_name}: {e}")
            print(f"Values: {values}")
    
    sqlite_conn.commit()
    return count


def export_mysql_to_sqlite(output_path: str, force: bool = False):
    """Export entire MySQL database to SQLite."""
    output_file = Path(output_path)
    
    # Create output directory if needed
    output_file.parent.mkdir(parents=True, exist_ok=True)
    
    # Check if output file exists
    if output_file.exists():
        if force:
            output_file.unlink()
            print(f"Removed existing file: {output_file}")
        else:
            print(f"Error: Output file already exists: {output_file}")
            print("Use --force to overwrite")
            sys.exit(1)
    
    print(f"Connecting to MySQL: {MYSQL_CONFIG['host']}:{MYSQL_CONFIG['port']}/{MYSQL_CONFIG['database']}")
    
    try:
        mysql_conn = pymysql.connect(**MYSQL_CONFIG)
    except pymysql.Error as e:
        print(f"Error connecting to MySQL: {e}")
        sys.exit(1)
    
    print(f"Creating SQLite database: {output_file}")
    sqlite_conn = sqlite3.connect(str(output_file))
    
    try:
        mysql_cursor = mysql_conn.cursor()
        sqlite_cursor = sqlite_conn.cursor()
        
        # Get all tables
        tables = get_mysql_tables(mysql_cursor)
        print(f"Found {len(tables)} tables: {', '.join(tables)}")
        
        # Process each table
        for table in tables:
            print(f"\nProcessing table: {table}")
            
            # Get schema
            columns = get_table_schema(mysql_cursor, table)
            primary_keys = get_primary_keys(mysql_cursor, table)
            
            print(f"  Columns: {len(columns)}, Primary keys: {primary_keys}")
            
            # Create table in SQLite
            create_sqlite_table(sqlite_cursor, table, columns, primary_keys)
            sqlite_conn.commit()
            
            # Copy data
            row_count = copy_table_data(mysql_cursor, sqlite_conn, table, columns)
            print(f"  Copied {row_count} rows")
        
        print(f"\n✓ Export complete: {output_file}")
        print(f"  File size: {output_file.stat().st_size / 1024:.1f} KB")
        
    except Exception as e:
        print(f"Error during export: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        mysql_conn.close()
        sqlite_conn.close()


def main():
    parser = argparse.ArgumentParser(description="Export MySQL database to SQLite")
    parser.add_argument(
        "--output", "-o",
        default="data/exports/daan-dev.sqlite3",
        help="Output SQLite file path (default: data/exports/daan-dev.sqlite3)"
    )
    parser.add_argument(
        "--force", "-f",
        action="store_true",
        help="Overwrite existing output file"
    )
    
    args = parser.parse_args()
    export_mysql_to_sqlite(args.output, args.force)


if __name__ == "__main__":
    main()
