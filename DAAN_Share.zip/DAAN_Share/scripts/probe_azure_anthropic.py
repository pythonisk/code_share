"""Bypass the LiteLLM proxy and hit Azure AI Foundry's Anthropic passthrough
directly, using the SAME credential the LiteLLM 'Claude Creds' row uses.

Auth on Azure AI Foundry usually accepts either 'api-key: <key>' (Azure
convention) or 'Authorization: Bearer <key>'. We try 'api-key' first,
then fall back to Bearer if the first attempt returns 401.

Interpretation:
    non-empty `thinking` text  → LiteLLM proxy layer is scrubbing.
    empty `thinking` text      → Azure AI Foundry (Content Safety or
                                 the Anthropic-passthrough gateway) is
                                 scrubbing; unlock has to happen in Azure.
    400/403 with policy error  → same as above, more explicit.
"""
from __future__ import annotations
import json, os, sys
from pathlib import Path

import httpx


def _load_dotenv() -> None:
    """Populate os.environ from the nearest .env / env_creds.json so ANTHROPIC_API_KEY
    is picked up without having to export it in the shell.
    """
    repo_root = Path(__file__).resolve().parent.parent
    # 1. python-dotenv if installed
    for candidate in (repo_root / ".env", repo_root / "config" / ".env"):
        if candidate.exists():
            try:
                from dotenv import load_dotenv  # type: ignore
                load_dotenv(candidate, override=False)
            except ModuleNotFoundError:
                # Minimal parser: KEY=VALUE lines, ignore comments / blanks / quoting.
                for raw in candidate.read_text(encoding="utf-8").splitlines():
                    line = raw.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, v = line.split("=", 1)
                    k = k.strip()
                    v = v.strip().strip('"').strip("'")
                    os.environ.setdefault(k, v)
    # 2. env_creds.json fallback (this repo ships credentials there)
    creds_file = repo_root / "env_creds.json"
    if creds_file.exists():
        try:
            data = json.loads(creds_file.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                for k, v in data.items():
                    if isinstance(v, (str, int, float)) and str(v):
                        os.environ.setdefault(str(k), str(v))
        except Exception:
            pass


_load_dotenv()

URL = "https://genaicoe.services.ai.azure.com/anthropic/v1/messages"

# Anthropic thinking rules: `adaptive` forbids budget_tokens; `enabled` requires it.
PAYLOADS = {
    "opus-5 adaptive": {
        "model": "claude-opus-5",
        "max_tokens": 8192,
        "thinking": {"type": "adaptive"},
        "output_config": {"effort": "high"},
        "messages": [{
            "role": "user",
            "content": "Explain why the sum of two even numbers is always even. Show reasoning.",
        }],
    },
    "opus-5 enabled": {
        "model": "claude-opus-5",
        "max_tokens": 8192,
        "thinking": {"type": "enabled", "budget_tokens": 2048},
        "messages": [{
            "role": "user",
            "content": "Explain why the sum of two even numbers is always even. Show reasoning.",
        }],
    },
    "sonnet-5 adaptive": {
        "model": "claude-sonnet-5",
        "max_tokens": 8192,
        "thinking": {"type": "adaptive"},
        "output_config": {"effort": "high"},
        "messages": [{
            "role": "user",
            "content": "Explain why the sum of two even numbers is always even. Show reasoning.",
        }],
    },
    "sonnet-5 enabled": {
        "model": "claude-sonnet-5",
        "max_tokens": 8192,
        "thinking": {"type": "enabled", "budget_tokens": 2048},
        "messages": [{
            "role": "user",
            "content": "Explain why the sum of two even numbers is always even. Show reasoning.",
        }],
    },
    "haiku enabled": {
        "model": "claude-haiku-4-5",
        "max_tokens": 8192,
        "thinking": {"type": "enabled", "budget_tokens": 2048},
        "messages": [{
            "role": "user",
            "content": "Explain why the sum of two even numbers is always even. Show reasoning.",
        }],
    },
}


def call(headers: dict, payload: dict) -> httpx.Response:
    return httpx.post(URL, headers=headers, json=payload, timeout=180.0)

def dump(r: httpx.Response) -> None:
    print(f"HTTP {r.status_code}")
    try:
        data = r.json()
    except Exception:
        print(r.text[:4000]); return
    err = data.get("error") or data.get("message")
    if err:
        print(f"error: {json.dumps(err)[:800]}")
    blocks = data.get("content") or []
    print(f"\nreturned {len(blocks)} content block(s):")
    for i, b in enumerate(blocks):
        if not isinstance(b, dict):
            print(f"  [{i}] non-dict: {b!r}"); continue
        btype = b.get("type")
        keys = list(b.keys())
        print(f"  [{i}] type={btype}  keys={keys}")
        # Dump every non-text field verbatim; truncate long text-like fields.
        for k, v in b.items():
            if k == "type":
                continue
            if isinstance(v, str):
                print(f"       {k}: len={len(v)}  preview={v[:200]!r}")
            else:
                print(f"       {k}: {json.dumps(v)[:300]}")
    print(f"\nusage: {data.get('usage')}")
    print(f"stop_reason: {data.get('stop_reason')}")
    # Also dump the entire raw response once for eyeball inspection.
    print(f"\nraw response (first 2000 chars):\n{json.dumps(data)[:2000]}")

def main() -> int:
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        print(
            "[!] ANTHROPIC_API_KEY not found. Looked in os.environ, .env, "
            "config/.env, env_creds.json. Either export it in the shell "
            "(set ANTHROPIC_API_KEY=...) or add it to one of those files."
        )
        return 2

    # Azure AI Foundry's Anthropic passthrough accepts x-api-key (Anthropic-native).
    headers = {
        "x-api-key": key,
        "content-type": "application/json",
        "anthropic-version": "2023-06-01",
    }

    any_ok = False
    for name, payload in PAYLOADS.items():
        print(f"\n=== payload: {name} ===")
        try:
            r = call(headers, payload)
        except Exception as exc:
            print(f"[!] request failed: {exc}")
            continue
        dump(r)
        if r.status_code < 400:
            any_ok = True
    return 0 if any_ok else 1

if __name__ == "__main__":
    sys.exit(main())
