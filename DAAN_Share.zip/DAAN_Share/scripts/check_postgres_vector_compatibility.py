"""Check whether the current PostgreSQL configuration is ready for pgvector usage."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

from sqlalchemy import create_engine, text
from sqlalchemy.engine import make_url
from sqlalchemy.exc import SQLAlchemyError


REPO_ROOT = Path(__file__).resolve().parents[1]
SERVICE_ROOT = REPO_ROOT / "service"
if str(SERVICE_ROOT) not in sys.path:
    sys.path.insert(0, str(SERVICE_ROOT))
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))


def _load_settings() -> Any:
    from daan.core.config import get_settings

    return get_settings()


def _redact_url(database_url: str) -> str:
    try:
        return make_url(database_url).render_as_string(hide_password=True)
    except Exception:
        return database_url


def _infer_embedding_dimension(settings: Any) -> int | None:
    rag_config = settings.load_rag_config() or {}
    provider_name = str(rag_config.get("embedding_provider") or "").strip().lower()

    llm_config = settings.load_yaml_config("config/llm_config.yml") or {}
    embedding_section = llm_config.get("embeddings") or {}
    providers = embedding_section.get("providers") or {}
    provider_config = providers.get(provider_name) or {}

    model_name = str(
        provider_config.get("model")
        or provider_config.get("model_name")
        or provider_config.get("deployment_name")
        or ""
    ).strip().lower()

    dimension_map = {
        "text-embedding-ada-002": 1536,
        "text-embedding-3-small": 1536,
        "text-embedding-3-large": 3072,
        "sentence-transformers/all-minilm-l6-v2": 384,
        "amazon.titan-embed-text-v1": 1536,
        "vertex_ai/textembedding-gecko": 768,
    }

    if model_name in dimension_map:
        return dimension_map[model_name]
    if provider_name == "azure_openai" and "ada-002" in model_name:
        return 1536
    if provider_name == "sentence_transformer" and "minilm-l6-v2" in model_name:
        return 384
    return None


def _check_pgvector(engine) -> dict[str, Any]:
    results: dict[str, Any] = {}
    with engine.connect() as connection:
        results["server_version"] = connection.execute(text("select version()")).scalar_one()
        results["database_name"] = connection.execute(text("select current_database()")).scalar_one()
        results["current_user"] = connection.execute(text("select current_user")).scalar_one()
        results["vector_available"] = bool(
            connection.execute(text("select 1 from pg_available_extensions where name = 'vector' limit 1")).first()
        )
        results["vector_installed"] = bool(
            connection.execute(text("select 1 from pg_extension where extname = 'vector' limit 1")).first()
        )
        results["vector_type"] = bool(
            connection.execute(text("select 1 from pg_type where typname = 'vector' limit 1")).first()
        )

        vector_columns = connection.execute(
            text(
                """
                select n.nspname as schema_name, c.relname as table_name, a.attname as column_name, format_type(a.atttypid, a.atttypmod) as data_type
                from pg_attribute a
                join pg_class c on c.oid = a.attrelid
                join pg_namespace n on n.oid = c.relnamespace
                join pg_type t on t.oid = a.atttypid
                where t.typname = 'vector'
                  and a.attnum > 0
                  and not a.attisdropped
                order by 1, 2, 3
                """
            )
        ).mappings().all()
        results["vector_columns"] = [dict(row) for row in vector_columns]

    return results


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--database-url", help="Override the database URL to check")
    parser.add_argument(
        "--embedding-dimension",
        type=int,
        help="Override the expected embedding dimension for the pgvector column",
    )
    args = parser.parse_args()

    settings = _load_settings()
    rag_config = settings.load_rag_config() or {}
    vector_database_url = args.database_url or settings.VECTOR_DATABASE_URL

    print(f"Vector Database URL: {_redact_url(vector_database_url)}")
    print(f"RAG vector store type: {rag_config.get('vector_store_type', 'chroma')}")

    if not vector_database_url.startswith("postgresql"):
        print("Result: incompatible. VECTOR_DATABASE_URL is not PostgreSQL.")
        return 1

    try:
        engine = create_engine(vector_database_url, future=True, pool_pre_ping=True)
        report = _check_pgvector(engine)
    except SQLAlchemyError as exc:
        print(f"Result: incompatible. Could not connect to PostgreSQL: {exc}")
        return 1
    except Exception as exc:
        print(f"Result: incompatible. Unexpected failure while checking PostgreSQL: {exc}")
        return 1

    try:
        import pgvector  # noqa: F401

        pgvector_python = True
    except ImportError:
        pgvector_python = False

    inferred_dimension = args.embedding_dimension or _infer_embedding_dimension(settings)

    print(f"Server version: {report['server_version']}")
    print(f"Database: {report['database_name']}")
    print(f"User: {report['current_user']}")
    print(f"pgvector Python package installed: {pgvector_python}")
    print(f"pgvector extension available in server: {report['vector_available']}")
    print(f"pgvector extension installed in database: {report['vector_installed']}")
    print(f"vector type present: {report['vector_type']}")

    if inferred_dimension is not None:
        print(f"Inferred embedding dimension: {inferred_dimension}")
    else:
        print("Inferred embedding dimension: unavailable; pass --embedding-dimension if you want a strict check")

    vector_columns = report["vector_columns"]
    if vector_columns:
        print("Existing vector columns:")
        for column in vector_columns:
            print(f"  - {column['schema_name']}.{column['table_name']}.{column['column_name']} ({column['data_type']})")
    else:
        print("Existing vector columns: none found")

    checks_passed = all(
        [
            report["vector_available"],
            report["vector_installed"],
            report["vector_type"],
            pgvector_python,
        ]
    )

    if inferred_dimension is not None and vector_columns:
        expected = f"vector({inferred_dimension})"
        if not any(expected.lower() in str(column["data_type"]).lower() for column in vector_columns):
            print(f"Warning: no existing pgvector column matches the inferred dimension {expected}.")
            checks_passed = False

    if checks_passed:
        print("Result: compatible. PostgreSQL is ready for a pgvector-backed store.")
        return 0

    print("Result: not fully ready. Install pgvector support and/or create the extension before switching the vector store.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
