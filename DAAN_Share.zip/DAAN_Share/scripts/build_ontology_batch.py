"""
Batch Ontology Builder — extracts and publishes an ontology from a large
SharePoint document set (e.g. thousands of D&A pre-sales files) without
manual per-file uploads through the UI.

Reuses the same map-reduce-publish pipeline as the interactive
POST /ontology/generate|merge|publish endpoints:
  MAP    -> ontology_agent.generate_ontology() per document (concurrent)
  REDUCE -> ontology_agent.merge_ontologies() (pure dedup, no LLM cost)
  RESOLVE-> ontology_publisher.resolve_and_enrich_ontology() (identity resolution)
  PUBLISH-> ontology_publisher.publish_ontology() + RagTool.index_ontology_concepts()
  BACKFILL -> OntologyLinker.backfill_existing_chunks() (retag chunks indexed
              before the ontology existed)

Progress is checkpointed to a local JSONL file after every successfully
extracted document, so an interrupted run (Ctrl+C, crash, network blip) can be
resumed without reprocessing already-extracted files or losing LLM spend.

Usage (from the service/ directory with the venv activated):
    python ../scripts/build_kb_ontology_batch.py --kb-id DnA --limit 5 --dry-run
    python ../scripts/build_kb_ontology_batch.py --kb-id DnA
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import asyncio
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Bootstrap the Python path so DAAN modules are importable
# ---------------------------------------------------------------------------
_SCRIPT_DIR = Path(__file__).resolve().parent          # scripts/
_SERVICE_DIR = _SCRIPT_DIR.parent / "service"          # service/
_WORKSPACE_ROOT = _SCRIPT_DIR.parent                   # repo root

for p in (_SERVICE_DIR, _WORKSPACE_ROOT):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

os.chdir(str(_SERVICE_DIR))

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("build_kb_ontology_batch")

from daan.core.config import get_settings  # noqa: E402
from daan.rag.ontology.ontology_agent import generate_ontology, merge_ontologies  # noqa: E402
from daan.rag.ontology.ontology_publisher import (  # noqa: E402
    fetch_existing_entities,
    publish_ontology,
    resolve_and_enrich_ontology,
)
from daan.utils.documentloaders.sharepoint_loader import SharePointDocumentLoader  # noqa: E402

_CHECKPOINT_DIR = _WORKSPACE_ROOT / "data" / "ontology_checkpoints"


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--kb-id", default="DnA", help="Target knowledge base id (default: DnA)")
    parser.add_argument("--folder-path", default=None, help="SharePoint folder to walk (default: rag_config.yml sharepoint_loader_kwargs.folder_path)")
    parser.add_argument("--loader-batch-size", type=int, default=None, help="Files fetched per SharePoint batch (default: rag_config.yml sharepoint_batch_size)")
    parser.add_argument("--map-concurrency", type=int, default=5, help="Concurrent ontology-extraction LLM calls (default: 5)")
    parser.add_argument("--limit", type=int, default=None, help="Stop after extracting this many files (for test runs)")
    parser.add_argument("--dry-run", action="store_true", help="Build the final ontology JSON but skip publish/embed/backfill")
    parser.add_argument("--skip-backfill", action="store_true", help="Skip retagging already-indexed chunks with concept_ids")
    parser.add_argument("--checkpoint-file", default=None, help="Override the JSONL checkpoint path")
    parser.add_argument(
        "--publish-only",
        action="store_true",
        help="Skip the SharePoint crawl entirely; merge/publish directly from the existing checkpoint file",
    )
    return parser.parse_args()


def _load_checkpoint(path: Path) -> dict[str, dict[str, Any]]:
    """Return {filename: ontology} for every document already extracted."""
    done: dict[str, dict[str, Any]] = {}
    if not path.exists():
        return done
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
                done[record["filename"]] = record["ontology"]
            except (json.JSONDecodeError, KeyError):
                logger.warning("Skipping malformed checkpoint line: %r", line[:200])
    return done


def _append_checkpoint(path: Path, filename: str, ontology: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps({"filename": filename, "ontology": ontology}) + "\n")


def _iter_sharepoint_documents(rag_config: dict, folder_path: str, batch_size: int, coverage: dict[str, int]):
    """Yield (filename, text) pairs for every file under ``folder_path``.

    Tallies ``coverage`` (discovered/empty_content) so the caller can confirm
    full drive coverage, since the SharePoint API never reports an upfront count.
    """
    document_loaders_config = dict(rag_config.get("document_loaders") or {})
    loader_kwargs = dict(document_loaders_config.get("sharepoint_loader_kwargs") or {})
    loader_kwargs["folder_path"] = folder_path
    loader = SharePointDocumentLoader(config={"loader_kwargs": loader_kwargs})

    for payload in loader.iter_document_batches(file_path=folder_path, batch_size=batch_size):
        filename = str(payload.get("filename") or "")
        documents = ((payload.get("content") or {}).get("documents")) or []
        text = str(documents[0].get("content") or "") if documents else ""
        coverage["discovered"] += 1
        if filename and text.strip():
            yield filename, text
        else:
            coverage["empty_content"] += 1


def main() -> None:
    args = _parse_args()
    settings = get_settings()
    rag_config = settings.load_rag_config()

    document_loaders_config = dict(rag_config.get("document_loaders") or {})
    folder_path = args.folder_path or str(
        (document_loaders_config.get("sharepoint_loader_kwargs") or {}).get("folder_path") or "D-AURA"
    )
    batch_size = args.loader_batch_size or int(document_loaders_config.get("sharepoint_batch_size", 25) or 25)
    checkpoint_path = Path(args.checkpoint_file) if args.checkpoint_file else _CHECKPOINT_DIR / f"{args.kb_id}_checkpoint.jsonl"

    already_done = _load_checkpoint(checkpoint_path)
    logger.info(
        "kb_id=%s folder=%s batch_size=%d map_concurrency=%d resuming=%d files",
        args.kb_id, folder_path, batch_size, args.map_concurrency, len(already_done),
    )

    existing_entities = fetch_existing_entities(args.kb_id, rag_config)

    processed = 0
    failed = 0
    coverage = {"discovered": 0, "empty_content": 0}
    start_time = time.monotonic()

    def _extract(filename: str, text: str) -> tuple[str, dict[str, Any] | None]:
        try:
            ontology = generate_ontology(
                document_text=text,
                kb_id=args.kb_id,
                existing_entities=existing_entities,
            )
            return filename, ontology
        except Exception as exc:  # noqa: BLE001
            logger.warning("Ontology extraction failed for %r: %s", filename, exc)
            return filename, None

    pending: list[tuple[str, str]] = []

    def _flush(batch: list[tuple[str, str]]) -> None:
        nonlocal processed, failed
        if not batch:
            return
        with ThreadPoolExecutor(max_workers=args.map_concurrency) as executor:
            futures = [executor.submit(_extract, name, text) for name, text in batch]
            for future in as_completed(futures):
                filename, ontology = future.result()
                if ontology is None:
                    failed += 1
                    continue
                _append_checkpoint(checkpoint_path, filename, ontology)
                already_done[filename] = ontology
                processed += 1
        elapsed = time.monotonic() - start_time
        logger.info("Progress: processed=%d failed=%d elapsed=%.0fs", processed, failed, elapsed)

    if not args.publish_only:
        limit_reached = False
        for filename, text in _iter_sharepoint_documents(rag_config, folder_path, batch_size, coverage):
            if filename in already_done:
                continue
            if args.limit is not None and processed + len(pending) >= args.limit:
                limit_reached = True
                break
            pending.append((filename, text))
            if len(pending) >= batch_size:
                _flush(pending)
                pending = []
        _flush(pending)  # always flush the tail batch, including when --limit cut the loop short

        logger.info(
            "Extraction complete: discovered=%d (empty_content=%d) processed=%d failed=%d total_checkpointed=%d limit_reached=%s",
            coverage["discovered"], coverage["empty_content"], processed, failed, len(already_done), limit_reached,
        )
    else:
        logger.info("Publish-only: skipping SharePoint crawl, using %d already-checkpointed files.", len(already_done))

    if not already_done:
        logger.error("No documents were extracted; nothing to merge/publish.")
        return

    candidate = merge_ontologies(list(already_done.values()), kb_id=args.kb_id)
    final_ontology = resolve_and_enrich_ontology(candidate, existing_entities, args.kb_id)
    logger.info(
        "Merged ontology: %d concepts, %d taxonomy edges, %d relationships",
        len(final_ontology.get("concepts", [])),
        len(final_ontology.get("taxonomy", [])),
        len(final_ontology.get("relationships", [])),
    )

    if args.dry_run:
        output_path = _CHECKPOINT_DIR / f"{args.kb_id}_final_ontology.json"
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(final_ontology, indent=2), encoding="utf-8")
        logger.info("Dry run: wrote final ontology to %s (publish skipped).", output_path)
        return

    result = publish_ontology(ontology=final_ontology, kb_id=args.kb_id, rag_config=rag_config)
    logger.info("Published ontology: %s", result)

    from daan.native_tools.rag_tool import RagTool

    rag_tool = RagTool(rag_config)
    embed_result = rag_tool.index_ontology_concepts(kb_id=args.kb_id)
    logger.info("Embedded ontology concepts: %s", embed_result)

    if not args.skip_backfill:
        from daan.rag.graph.ontology_linker import OntologyLinker

        link_ontology, ontology_link_config = rag_tool._ontology_link_settings(args.kb_id)
        if not link_ontology:
            logger.warning(
                "kb_id=%s has link_ontology disabled in rag_config.yml; skipping backfill.", args.kb_id
            )
        else:
            components = rag_tool._build_runtime_components(args.kb_id, include_graph_store=True)
            linker = OntologyLinker(components["graph_store"], ontology_link_config)
            backfill_result = linker.backfill_existing_chunks(components["vector_store"])
            logger.info("Backfilled existing chunks: %s", backfill_result)

    logger.info("Done.")


if __name__ == "__main__":
    main()
