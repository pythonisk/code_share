"""
Power BI Report Generation Simulator

Simulates the DAAN Power BI pipeline locally using session data and local prompt files.
Supports three execution modes for flexible testing.

Modes:
    full         Run full pipeline: Spec Generation → Report Generation
    spec-only    Run only Spec Generation (test DAX formula quality)
    report-only  Run only Report Generation (use existing spec, test PBIP output)

Usage:
    .venv/Scripts/python.exe scripts/simulate_powerbi.py <session_id> [--mode full|spec-only|report-only]

Prompts are loaded from local files (z_spec_gen_prompt.md, z_powerbi_prompt.md)
to allow rapid iteration without touching the remote DB.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from pathlib import Path

# ---------------------------------------------------------------------------
# Path setup
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent
SERVICE_DIR = PROJECT_ROOT / "service"
sys.path.insert(0, str(SERVICE_DIR))

from google.adk.runners import InMemoryRunner
from google.genai import types

from daan.agents.dynamic_builders.dynamic_adk_agent import create_adk_agent

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
APP_NAME = "daan_powerbi_simulator"

PROMPT_FILES = {
    "spec_generation": PROJECT_ROOT / "z_spec_gen_prompt.md",
    "report_generation": PROJECT_ROOT / "z_powerbi_prompt.md",
}

AGENT_IDS = {
    "spec_generation": "AGENT_8",
    "report_generation": "AGENT_9",
}


# ---------------------------------------------------------------------------
# Data Loading
# ---------------------------------------------------------------------------
def load_context_map(session_id: str) -> dict:
    """Load and return the context_map_output.json for a session."""
    path = PROJECT_ROOT / "session_storage" / session_id / "context_map_output.json"
    if not path.exists():
        raise FileNotFoundError(f"No context_map_output.json at {path}")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def get_agent_config(context_map: dict, agent_id: str) -> dict:
    """Extract a specific agent's config from the context map."""
    for agent in context_map.get("agents", []):
        if agent.get("agent_id") == agent_id:
            return agent
    raise ValueError(f"{agent_id} not found in context_map_output.json")


def load_local_prompt(stage: str) -> str:
    """Load a prompt from the local prompt file, overriding what's in context_map."""
    path = PROMPT_FILES[stage]
    if not path.exists():
        raise FileNotFoundError(f"Local prompt not found: {path}")
    return path.read_text(encoding="utf-8")


def load_spec_output(session_id: str) -> str:
    """Load the existing spec generation output (Agent 8's output.md)."""
    path = PROJECT_ROOT / "session_storage" / session_id / "agents" / "AGENT_8" / "output.md"
    if not path.exists():
        raise FileNotFoundError(
            f"No spec output found at {path}. "
            f"Run with --mode full or --mode spec-only first."
        )
    return path.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Input Message Builders
# ---------------------------------------------------------------------------
def build_spec_generation_input(agent_config: dict) -> str:
    """Build the user message for the Spec Generation agent.

    In production, dynamic agents receive the context as their input message.
    """
    context = agent_config.get("context", "")
    return context


def build_report_generation_input(spec_output: str) -> str:
    """Build the user message for the Report Generation agent.

    Action agents receive INPUT_JSON with reviewed_output and dynamic_agent_outputs.
    """
    input_payload = {
        "reviewed_output": f"--- Dashboard Specification ---\n{spec_output}",
        "dynamic_agent_outputs": {
            "AGENT_8": spec_output,
        },
    }
    return "INPUT_JSON:\n" + json.dumps(input_payload, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Agent Execution
# ---------------------------------------------------------------------------
async def run_agent(
    agent_config: dict,
    input_message: str,
    session_id: str,
    stage: str,
) -> str:
    """Run a single agent and return its text output. Prints all events."""
    # Override prompt with local file
    local_prompt = load_local_prompt(stage)
    agent_config = dict(agent_config)  # shallow copy to avoid mutating original
    agent_config["prompt"] = local_prompt

    # Set up data directory for tools
    data_dir = str(PROJECT_ROOT / "session_storage" / session_id / "inputs")
    tool_kwargs = {"data_dir": data_dir}

    # Create ADK agent
    agent = create_adk_agent(
        agent_config,
        pre_loaded_mcp_toolsets=None,
        tool_kwargs=tool_kwargs,
    )

    print(f"\n  Agent created: {agent.name}")
    print(f"  Tools: {[getattr(t, '__name__', type(t).__name__) for t in (agent.tools or [])]}")
    print(f"  Input length: {len(input_message)} chars")

    # Create runner
    runner = InMemoryRunner(agent=agent, app_name=APP_NAME)
    runner.auto_create_session = True

    user_msg = types.Content(
        role="user",
        parts=[types.Part(text=input_message)],
    )

    # Execute and collect events
    event_count = 0
    all_text: list[str] = []

    async for event in runner.run_async(
        user_id="simulate_user",
        session_id=f"sim_{stage}_{session_id[:8]}",
        new_message=user_msg,
    ):
        event_count += 1
        author = (event.author or "unknown").strip()

        if event.content and event.content.parts:
            for part in event.content.parts:
                if hasattr(part, "text") and part.text:
                    all_text.append(part.text)
                    display = part.text[:300] + "..." if len(part.text) > 300 else part.text
                    print(f"  [{event_count}] {author} TEXT ({len(part.text)} chars): {display[:150]}")
                elif hasattr(part, "function_call") and part.function_call:
                    fc = part.function_call
                    args_preview = json.dumps(dict(fc.args), ensure_ascii=False)[:200] if fc.args else ""
                    print(f"  [{event_count}] {author} TOOL_CALL: {fc.name}({args_preview}...)")
                elif hasattr(part, "function_response") and part.function_response:
                    fr = part.function_response
                    resp_str = str(fr.response)[:200] if fr.response else ""
                    print(f"  [{event_count}] {author} TOOL_RESP: {fr.name} → {resp_str}")
        else:
            print(f"  [{event_count}] {author} (no content)")

    print(f"  Total events: {event_count}")
    return "\n".join(all_text)


# ---------------------------------------------------------------------------
# Pipeline Orchestration
# ---------------------------------------------------------------------------
async def run_spec_generation(session_id: str, context_map: dict) -> str:
    """Run the Spec Generation stage and save output."""
    print("\n" + "=" * 80)
    print("STAGE: Spec Generation (Dashboard Specification)")
    print("=" * 80)

    agent_config = get_agent_config(context_map, AGENT_IDS["spec_generation"])
    input_msg = build_spec_generation_input(agent_config)

    output = await run_agent(agent_config, input_msg, session_id, "spec_generation")

    # Save output
    output_dir = PROJECT_ROOT / "session_storage" / session_id / "agents" / "AGENT_8"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "output.md"
    output_path.write_text(output, encoding="utf-8")
    print(f"\n  Spec saved to: {output_path}")

    return output


async def run_report_generation(session_id: str, context_map: dict, spec_output: str) -> str:
    """Run the Report Generation stage and save output."""
    print("\n" + "=" * 80)
    print("STAGE: Report Generation (Power BI Project)")
    print("=" * 80)

    agent_config = get_agent_config(context_map, AGENT_IDS["report_generation"])
    input_msg = build_report_generation_input(spec_output)

    output = await run_agent(agent_config, input_msg, session_id, "report_generation")

    # Save output
    output_dir = PROJECT_ROOT / "session_storage" / session_id / "agents" / "AGENT_9"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "output.md"
    output_path.write_text(output, encoding="utf-8")
    print(f"\n  Report generation output saved to: {output_path}")

    return output


async def run_full_pipeline(session_id: str) -> None:
    """Run Spec Generation → Report Generation sequentially."""
    context_map = load_context_map(session_id)

    spec_output = await run_spec_generation(session_id, context_map)
    await run_report_generation(session_id, context_map, spec_output)


async def run_spec_only(session_id: str) -> None:
    """Run only Spec Generation."""
    context_map = load_context_map(session_id)
    await run_spec_generation(session_id, context_map)


async def run_report_only(session_id: str) -> None:
    """Run only Report Generation using existing spec."""
    context_map = load_context_map(session_id)
    spec_output = load_spec_output(session_id)

    print(f"[INFO] Loaded existing spec ({len(spec_output)} chars)")
    await run_report_generation(session_id, context_map, spec_output)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def list_available_sessions() -> None:
    """Print sessions that have context_map_output.json."""
    sessions_dir = PROJECT_ROOT / "session_storage"
    if not sessions_dir.exists():
        print("  No session_storage directory found.")
        return

    print("\nAvailable sessions:")
    for d in sorted(sessions_dir.iterdir()):
        if d.is_dir() and (d / "context_map_output.json").exists():
            # Check what agents are available
            try:
                cm = json.loads((d / "context_map_output.json").read_text())
                agent_ids = [a.get("agent_id") for a in cm.get("agents", [])]
                has_spec = (d / "agents" / "AGENT_8" / "output.md").exists()
                markers = []
                if "AGENT_8" in agent_ids:
                    markers.append("spec")
                if "AGENT_9" in agent_ids:
                    markers.append("report")
                if has_spec:
                    markers.append("has-spec-output")
                print(f"  {d.name}  [{', '.join(markers)}]")
            except Exception:
                print(f"  {d.name}  [error reading context_map]")


def main():
    parser = argparse.ArgumentParser(
        description="Power BI Report Generation Simulator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Full pipeline (spec → report)
  .venv\\Scripts\\python.exe scripts/simulate_powerbi.py d15acaf0-... --mode full

  # Only generate spec (test DAX quality)
  .venv\\Scripts\\python.exe scripts/simulate_powerbi.py d15acaf0-... --mode spec-only

  # Only generate report (freeze spec, iterate on PBIP generation)
  .venv\\Scripts\\python.exe scripts/simulate_powerbi.py d15acaf0-... --mode report-only
""",
    )
    parser.add_argument(
        "session_id",
        nargs="?",
        help="Session ID to simulate",
    )
    parser.add_argument(
        "--mode",
        choices=["full", "spec-only", "report-only"],
        default="report-only",
        help="Execution mode (default: report-only)",
    )

    args = parser.parse_args()

    if not args.session_id:
        parser.print_help()
        list_available_sessions()
        sys.exit(1)

    # Validate session exists
    session_dir = PROJECT_ROOT / "session_storage" / args.session_id
    if not session_dir.exists():
        print(f"ERROR: Session directory not found: {session_dir}")
        sys.exit(1)

    print(f"{'=' * 80}")
    print(f"POWER BI SIMULATION")
    print(f"{'=' * 80}")
    print(f"  Session: {args.session_id}")
    print(f"  Mode:    {args.mode}")
    print(f"  Prompts: {', '.join(p.name for p in PROMPT_FILES.values() if p.exists())}")

    start = time.time()

    if args.mode == "full":
        asyncio.run(run_full_pipeline(args.session_id))
    elif args.mode == "spec-only":
        asyncio.run(run_spec_only(args.session_id))
    elif args.mode == "report-only":
        asyncio.run(run_report_only(args.session_id))

    elapsed = time.time() - start
    print(f"\n{'=' * 80}")
    print(f"DONE in {elapsed:.1f}s")
    print(f"{'=' * 80}")


if __name__ == "__main__":
    main()
