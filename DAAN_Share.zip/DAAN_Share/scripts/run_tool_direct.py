"""
Directly invoke PowerBIReportGenerator with the corrected agent9_input_schema.json.
Bypasses the LLM entirely — just runs the tool.
"""
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
SERVICE_DIR = PROJECT_ROOT / "service"
sys.path.insert(0, str(SERVICE_DIR))

from daan.native_tools.power_bi_report_generator import PowerBIReportGenerator

SESSION_ID = "7a254e0f-2fd0-4086-b9d6-00f93c796310"
session_dir = PROJECT_ROOT / "session_storage" / SESSION_ID
data_dir = str(session_dir / "inputs")
schema_path = session_dir / "agent9_input_schema.json"

with open(schema_path, "r", encoding="utf-8") as f:
    schema = json.load(f)

print(f"Data dir: {data_dir}")
print(f"Schema: {len(json.dumps(schema))} chars")
print(f"Tables: {[t['name'] for t in schema['semantic_model']['tables']]}")
print(f"Measures: {len(schema['semantic_model']['tables'][0]['measures'])}")
print(f"Pages: {[p['name'] for p in schema['report']['pages']]}")
print(f"Total visuals: {sum(len(p['visuals']) for p in schema['report']['pages'])}")
print()

generator = PowerBIReportGenerator(data_dir=data_dir)
result = generator.create_project(schema)

print("\n" + "=" * 80)
print("RESULT:")
print("=" * 80)
print(result)
