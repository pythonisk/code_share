# Required Environment Variables for Azure Deployment

## Azure App Service Configuration

Set these environment variables in Azure Portal → Your App Service → Configuration → Application settings:

### NextAuth (Authentication)
```
NEXTAUTH_URL=https://your-app-name.azurewebsites.net
NEXTAUTH_SECRET=<generate-a-secure-random-32-char-string>
```

Generate NEXTAUTH_SECRET:
```bash
openssl rand -base64 32
```

### API Configuration
```
# NEXT_PUBLIC_API_BASE_URL is optional for Azure deployments
# The application automatically detects the correct URL:
# - On localhost: uses http://localhost:8000
# - On Azure/production: uses window.location.origin (e.g., https://your-app-name.azurewebsites.net)
# 
# Only set NEXT_PUBLIC_API_BASE_URL in Azure if you need a different backend URL than the deployment URL
# NEXT_PUBLIC_API_BASE_URL=https://your-app-name.azurewebsites.net
```

### Port Configuration (Required for Azure App Service)
```
WEBSITES_PORT=3000
```

### Database (if using Azure MySQL/PostgreSQL)
```
DB_HOST=your-db-server.mysql.database.azure.com
DB_PORT=3306
DB_USER=your_db_user
DB_PASSWORD=your_db_password
DB_NAME=your_db_name
```

### Optional Settings
```
NODE_ENV=production
NEXT_TELEMETRY_DISABLED=1
LOG_LEVEL=INFO
```

## Notes

- **Don't commit secrets** to git
- Use Azure Key Vault for production secrets
- The Dockerfile uses default values for local development
- Azure App Service will override these with actual configuration

## Testing Locally with Docker

Create a `.env` file (don't commit):
```bash
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=local-dev-secret-key-minimum-32-characters-long
NEXT_PUBLIC_API_BASE_URL=http://localhost:3000
```

Run:
```bash
docker run --env-file .env -p 3000:3000 your-image-name
```
